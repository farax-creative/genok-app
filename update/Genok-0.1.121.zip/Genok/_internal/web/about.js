// 설정 → Genok 정보: what this install is, in one place and ready to paste into a bug report.
// The mark, name, plan · version (the status bar's own words), the build date when the build
// carries one, the Claude Code / Codex versions the connect screen already found, the Windows and
// WebView2 versions, then the things people come here for: copy, update check, what changed,
// feedback, licenses. Nothing here shows a key, an account, a path or a date of a subscription.
// Its own file; v2.js setAbout calls window.LOOP_ABOUT for the top of 설정 › Genok 정보 and keeps
// the tour and the manual under it. Uses v2.js globals: tl, esc, toast, setRow, planName,
// brandMark, drawUpdate, fbUrl, fbLink, D, IN_APP, SCREENS.
(function () {
  "use strict";

  const json = (url) => fetch(url).then((r) => r.ok ? r.json() : null).catch(() => null);

  // The WebView2 runtime is the Edge the app window reports; a plain browser tab is not WebView2.
  function webview() {
    const m = IN_APP && /\bEdg\/([\d.]+)/.exec(navigator.userAgent || "");
    return m ? m[1] : "";
  }

  // What the connect screen last learned, read from its cache only: this page never starts a
  // detect (that spawns the CLIs). null = nothing learned yet.
  function tools() {
    const c = window.LOOP_CONNECT, st = c && c.cached ? c.cached() : null;
    const say = (d) => !d ? "" : !d.installed ? tl("about.none") : (d.version || tl("about.installed"));
    return st ? [[tl("about.claude"), say(st.claude)], [tl("about.codex"), say(st.codex)]] : null;
  }

  async function draw(c) {
    c.innerHTML = `<h2 class="seth">${tl("ui.set.about")}</h2><p class="setd">${tl("about.desc")}</p>
      <div class="abt-hero"><span class="abt-mark">${brandMark(44) || `<img src="/mark.svg" alt="" width="44" height="44">`}</span>
        <span class="abt-id"><span class="abt-name">Genok</span><span class="abt-ver" id="abt-ver"></span></span>
        <button class="btn sm press" id="abt-copy">${tl("about.copy")}</button></div>
      <div class="setsec">${tl("about.sec.info")}<button type="button" class="lnk press" id="abt-more" aria-expanded="false" aria-controls="abt-facts">${tl("ui.more1")}</button></div>
      <div id="abt-facts" hidden></div>
      <div class="setsec">${tl("about.sec.more")}</div>
      <div class="srow"><span class="srtx"><span class="srt">${tl("about.update")}</span><span class="srd" id="upds" aria-live="polite">…</span></span><span class="srctl"><button class="btn sm press" id="updchk">${tl("about.check")}</button></span></div>
      <div class="updbox" id="updbox" hidden></div>
      ${setRow(tl("about.changes"), `<span id="abt-notes">${tl("about.changes.d")}</span>`, `<button class="btn sm press" id="abt-hist">${tl("about.history")}</button>`)}
      ${fbUrl() ? setRow(tl("fb.send"), tl("fb.sendd"), fbLink("btn sm press", tl("fb.open"))) : ""}
      ${setRow(tl("about.oss"), tl("about.oss.d"), `<button class="btn sm press" id="abt-oss">${tl("about.view")}</button>`)}
      ${IN_APP ? setRow(tl("app.1"), "", `<button class="btn sm press" data-openweb>${tl("app.3")}</button>`) : ""}`;
    const go = (page) => { setPage = page; setSwap = true; SCREENS.settings(); };
    // 자세히: the rows 정보 복사 puts on the clipboard (tools, data, system), shown in place.
    c.querySelector("#abt-more").onclick = (e) => {
      const f = c.querySelector("#abt-facts"), open = f.hidden;
      f.hidden = !open; e.currentTarget.setAttribute("aria-expanded", String(open));
      e.currentTarget.textContent = open ? tl("itemView.30") : tl("ui.more1");
    };
    c.querySelector("#abt-hist").onclick = () => go("history");
    c.querySelector("#abt-oss").onclick = () => go("oss");
    c.querySelector("#updchk").onclick = () => drawUpdate(true, true);
    drawUpdate(false);

    const [info, list] = await Promise.all([json("/api/appinfo"), json("/api/app-versions"), getAct()]);
    const agents = tools();
    if (!c.isConnected) return;
    const ver = (info && info.version) || D.ver || "";
    const plan = planName();
    c.querySelector("#abt-ver").textContent = ver ? tl("about.planver", {plan, v: ver}) : plan;
    // A row with no value is left out rather than shown as a dash.
    const kept = (rows) => rows.filter((r) => r[1]);
    const row = ([k, v]) => setRow(k, "", `<span class="abt-v">${esc(v)}</span>`);
    const sec = (h, rows) => !rows.length ? "" : (h ? `<div class="setsec">${h}</div>` : "") + rows.map(row).join("");
    const built = kept([[tl("about.built"), info && info.built]]);
    const used = kept(agents || []);
    const sys = kept([[tl("about.os"), info && info.os], [tl("about.webview"), webview()]]);
    // What is kept here (home used to say this in its side column).
    const first = ((ACT.val || {}).about || {}).first;
    const data = kept([[tl("home.i.first"), first && actDate(first)],
      [tl("home.i.count"), tl("home.i.countv", {p: projects().length, n: (D.items || []).length})]]);
    // Nothing learned yet: say so and point at 설정 › 연결, where the check is run.
    const later = `<div class="setsec">${tl("about.sec.tools")}<button class="lnk press" data-connopen>${tl("about.toconn")}</button></div>`
      + [[tl("about.claude"), tl("about.unchecked")], [tl("about.codex"), tl("about.unchecked")]].map(row).join("");
    c.querySelector("#abt-facts").innerHTML = sec("", built) + (agents ? sec(tl("about.sec.tools"), used) : later)
      + sec(tl("home.i.data"), data) + sec(tl("about.sec.system"), sys);
    // This version's own notes, when the version record has them (an update writes them there).
    const cur = (Array.isArray(list) ? list : []).find((v) => v.current);
    // A note carries its Korean lines and one English line: show the reader's own, a line each.
    if (cur && cur.notes) {
      const ko = (document.documentElement.lang || "ko").startsWith("ko"), el = c.querySelector("#abt-notes");
      const mine = String(cur.notes).split("\n").filter((l) => l.trim() && /[가-힣]/.test(l) === ko);
      el.style.whiteSpace = "pre-line"; el.textContent = mine.length ? mine.join("\n") : cur.notes;
    }

    c.querySelector("#abt-copy").onclick = async () => {
      const text = [`Genok ${ver} (${plan})`]
        .concat(built.concat(used, sys).map(([k, v]) => `${k}: ${v}`)).join("\n");
      try { await navigator.clipboard.writeText(text); toast(tl("about.copied")); }
      catch { toast(tl("about.copyfail")); }
    };
  }

  window.LOOP_ABOUT = draw;

  // ------------------------------------------------------------ styles (own file, no v2.css edit)
  const css = `
  .abt-hero { display: flex; align-items: center; gap: 16px; padding: 16px 0 4px; }
  .abt-mark { flex: none; display: inline-flex; color: var(--t1); }
  .abt-id { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
  .abt-name { font-size: 20px; font-weight: 700; letter-spacing: -.01em; color: var(--t1); line-height: 1.2; }
  .abt-ver { font-size: 13px; color: var(--t3); font-variant-numeric: tabular-nums; min-height: 18px; }
  .abt-v { font-size: 14px; font-weight: 500; color: var(--t2, var(--t3)); text-align: right; overflow-wrap: anywhere;
    font-variant-numeric: tabular-nums; user-select: text; }
  #abt-facts .srow { min-height: 44px; padding: 8px 0; }
  #abt-facts .srctl { flex: 0 1 auto; min-width: 0; }
  #abt-facts:not([hidden]), #abt-manual:not([hidden]) { animation: more1in .14s ease-out; }
  @media (prefers-reduced-motion: reduce) { #abt-facts, #abt-manual { animation: none !important; } }
  .abt-foot { margin: 16px 0 4px; font-size: 12px; color: var(--t3); }`;
  const s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);
})();
