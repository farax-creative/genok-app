// 설정 → 3D 앱: pick which installed Blender / Houdini / Cinema 4D version agents render with (apps3d.py).
// One card per app. Before the first scan the card has a [찾기] button; pressing it is the consent
// to read the install list (registered through the normal consent grant, so it shows up in and is
// revocable from 허용한 권한). After the scan every installed version is a selectable row, one is
// marked 기본 (newest until the person chooses), and `loop render` uses that one unless a version
// is asked for. A second switch adds the render allow rule (its own consent, short wording).
// One opt-in switch, 열어 둔 창과 같이 다듬기: agents may co-edit in the open app window through an
// MCP the person already has; rendering stays `loop render` (`loop render --mode` tells agents).
// Cinema 4D 2026.4+ has its own MCP server: the card only says where to switch it on. The access
// token and the client setup stay in Cinema 4D - nothing here reads, stores or sends them.
// Its own file + one LOOP_SETTINGS entry, so v2.js/onboard.js stay untouched.
// Uses v2.js globals: tl, esc, ic, toast, get, post, loopFetch (consent.js).
(function () {
  "use strict";

  // A cube glyph for the settings menu, added beside v2.js's icon paths (P) without editing them.
  try { if (typeof P === "object" && P && !P.cube) P.cube = "M12 3l8 4.5v9L12 21l-8-4.5v-9z M4 7.5l8 4.5 8-4.5 M12 12v9"; } catch (e) { /* older core */ }

  const NAME = {blender: "Blender", houdini: "Houdini", c4d: "Cinema 4D"};
  const APPS = ["blender", "houdini", "c4d"];
  const AGENT = {claude: "Claude Code", codex: "Codex"};   // whose file a preview block changes
  const SCOPE = "read:3d-apps";
  const ED = () => ({commercial: tl("apps3d.ed.commercial"), indie: tl("apps3d.ed.indie"),
    apprentice: tl("apps3d.ed.apprentice"), education: tl("apps3d.ed.education")});
  const same = (a, b) => String(a || "").toLowerCase() === String(b || "").toLowerCase();

  function versionRow(e, isDefault) {
    const usable = e.cli !== false;
    const ed = e.app === "houdini" ? (ED()[e.edition] || (usable ? tl("apps3d.ed.unknown") : "")) : "";
    const tag = ed ? `<span class="a3-tag${e.edition === "apprentice" ? " warn" : ""}">${esc(ed)}</span>` : "";
    const probe = e.app === "houdini" && usable && !e.edition
      ? `<button class="btn sm press" data-probe="1">${tl("apps3d.probe")}</button>` : "";
    return `<div class="a3-row${isDefault ? " on" : ""}${usable ? "" : " off"}" role="radio" aria-checked="${isDefault}"
        ${usable ? 'tabindex="0"' : 'aria-disabled="true"'} data-app="${esc(e.app)}" data-path="${esc(e.path)}" title="${esc(e.path)}">
      <span class="a3-dot" aria-hidden="true"></span>
      <span class="a3-v">${esc(e.version || "?")}</span>${tag}
      ${e.note ? `<span class="a3-note">${esc(e.note)}</span>` : ""}
      <span class="a3-sp"></span>${probe}
      <span class="a3-def">${tl("apps3d.default")}</span></div>`;
  }

  // Cinema 4D only: one quiet line under the versions about its built-in MCP (guidance, no action).
  // mcp is true (2026.4+), false (older) or null (a 2026 whose point release is not known).
  function mcpHint(list) {
    const text = list.some((e) => e.mcp === true) ? tl("apps3d.c4d.mcp_on")
      : list.some((e) => e.mcp == null) ? tl("apps3d.c4d.mcp_maybe") : tl("apps3d.c4d.mcp_old");
    return `<p class="srd a3-hint">${text}</p>`;
  }

  // Only the chosen version shows; the others open on request (`open` keeps that across repaints).
  function card(app, list, d, scanned, open) {
    const defPath = (d && d.default && d.default[app]) || "";
    let body;
    if (!scanned) {
      body = `<p class="srd a3-none">${tl("apps3d.notyet")}</p>`;
    } else if (!list.length) {
      body = `<p class="srd a3-none">${tl("apps3d.none")}</p>`;
    } else {
      const fold = list.length > 1 && list.some((e) => same(e.path, defPath));
      body = `<div class="a3-list${fold && !open ? " fold" : ""}" role="radiogroup" aria-label="${esc(NAME[app])}">${list.map((e) => versionRow(e, same(e.path, defPath))).join("")}</div>
        ${fold ? `<button class="lnk press a3-oth" data-oth="${app}" data-n="${list.length - 1}" aria-expanded="${open ? "true" : "false"}">${open ? tl("apps3d.fold") : tl("apps3d.others", {n: list.length - 1})}</button>` : ""}
        <details class="a3-more"><summary class="srd">${tl("apps3d.details")}</summary>
          ${list.map((e) => `<div class="srd a3-path">${esc(e.version || "?")} · ${esc(e.path)}</div>`).join("")}</details>${app === "c4d" ? mcpHint(list) : ""}`;
    }
    return `<section class="a3-card" data-card="${app}">
      <div class="a3-head"><span class="a3-ico" data-app="${app}" aria-hidden="true">${NAME[app][0]}</span><span class="a3-name">${NAME[app]}</span></div>${body}</section>`;
  }

  function draw(c) {
    css();
    c.innerHTML = `<h2 class="seth">${tl("apps3d.title")}</h2><p class="setd">${tl("apps3d.desc")}</p>
      <div id="a3-body"></div>`;
    const body = c.querySelector("#a3-body");
    let last = null;
    const opened = {};    // app -> the other versions are showing
    let liveOn = false;   // the opt-in before the first scan (GET /api/apps3d needs the read consent)

    async function grantAndLoad(q) {
      body.querySelectorAll("[data-find],[data-rescan]").forEach((b) => { b.disabled = true; b.textContent = tl("apps3d.finding"); });
      try { await post("/api/consent/grant", {scope: SCOPE, remember: true}); } catch (e) { toast(e.message); paint(last, false); return; }
      load(q);
    }

    async function load(q) {
      let d;
      try { d = await loopFetch("/api/apps3d" + (q || "")); }
      catch (e) { toast(e.message); paint(last, false); return; }
      if (d.declined) { paint(last, false); return; }
      last = d; paint(d, true);
    }

    function wireCards(d) {
      body.querySelectorAll("[data-find]").forEach((b) => b.onclick = () => grantAndLoad());
      body.querySelectorAll("[data-rescan]").forEach((b) => b.onclick = () => {
        body.querySelectorAll("[data-rescan]").forEach((x) => { x.disabled = true; x.textContent = tl("apps3d.finding"); });
        load("?refresh=1");
      });
      body.querySelectorAll("[data-probe]").forEach((b) => b.onclick = (ev) => {
        ev.stopPropagation(); b.disabled = true; b.textContent = tl("apps3d.probing"); load("?probe=1");
      });
      body.querySelectorAll("[data-oth]").forEach((b) => b.onclick = () => setOpen(b.dataset.oth, !opened[b.dataset.oth]));
      body.querySelectorAll(".a3-row:not(.off)").forEach((row) => {
        const choose = async () => {
          // The lone visible row is the current choice: pressing it shows the others.
          if (row.classList.contains("on")) { if (row.parentNode.classList.contains("fold")) setOpen(row.dataset.app, true); return; }
          const app = row.dataset.app, path = row.dataset.path;
          const cardEl = row.closest(".a3-card");
          cardEl.querySelectorAll(".a3-row").forEach((r) => { const on = r === row; r.classList.toggle("on", on); r.setAttribute("aria-checked", on ? "true" : "false"); });
          try {
            const r = await post("/api/apps3d/default", {app, path});
            d.default = Object.assign({}, d.default, {[app]: (r.default || {})[app] || path});
            toast(tl("apps3d.picked", {app: NAME[app], v: row.querySelector(".a3-v").textContent}));
            setOpen(app, false);
          } catch (e) { toast(e.message); paint(d, true); }
        };
        row.onclick = choose;
        row.onkeydown = (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); choose(); } };
      });
    }

    function setOpen(app, on) {
      opened[app] = on;
      const cardEl = body.querySelector(`.a3-card[data-card="${app}"]`), b = cardEl && cardEl.querySelector("[data-oth]");
      if (!b) return;
      cardEl.querySelector(".a3-list").classList.toggle("fold", !on);
      b.setAttribute("aria-expanded", on ? "true" : "false");
      b.textContent = on ? tl("apps3d.fold") : tl("apps3d.others", {n: b.dataset.n});
    }

    function paint(d, scanned) {
      const apps = (d && d.apps) || {};
      const allow = (d && d.allow) || {};
      // The preview is a quiet link under the rule's description (not a sibling at body weight);
      // what it opens is an indented code box under the row, one captioned block per file.
      const rule = `<div class="setsec">${tl("apps3d.rule")}</div>
        <div class="srow a3-rule"><span class="srtx"><span class="srt" id="a3-rl">${tl("apps3d.rule.t")}</span>
          <span class="srd">${tl("apps3d.rule.d")}</span>
          ${allow.error ? `<span class="srd warn">${esc(allow.error)}</span>` : ""}
          <button class="press a3-difft" id="a3-difft" aria-expanded="false" aria-controls="a3-pre">${tl("apps3d.diff")}${ic("chev")}</button></span>
          <span class="srctl"><button class="sw press${allow.on ? " on" : ""}" role="switch" aria-labelledby="a3-rl"
            aria-checked="${allow.on ? "true" : "false"}" id="a3-sw"${allow.error ? " disabled" : ""}></button></span></div>
        <div class="a3-diff" id="a3-pre" hidden></div>`;
      const live = d ? !!d.live : liveOn;
      const liveRow = `<div class="srow a3-live"><span class="srtx"><span class="srt" id="a3-ll">${tl("apps3d.live.t")}</span>
          <span class="srd">${more1(tl("apps3d.live.d"), tl("apps3d.live.more"))}</span></span>
          <span class="srctl"><button class="sw press${live ? " on" : ""}" role="switch" aria-labelledby="a3-ll"
            aria-checked="${live ? "true" : "false"}" id="a3-live"></button></span></div>`;
      // One search for both apps (the scan reads the install list once), so one button says so.
      const bar = `<div class="a3-bar"><span class="srd">${tl("apps3d.find_d")}</span>
        ${scanned ? `<button class="btn sm press" data-rescan="1">${tl("apps3d.rescan")}</button>`
                  : `<button class="btn sm press" data-find="1">${tl("apps3d.find_all")}</button>`}</div>`;
      body.innerHTML = bar + APPS.map((a) => card(a, apps[a] || [], d, scanned, opened[a])).join("")
        + liveRow + (scanned ? rule : "");
      wireCards(d || {});
      const lv = body.querySelector("#a3-live");
      lv.onclick = async () => {
        const on = !lv.classList.contains("on");
        lv.classList.toggle("on", on); lv.setAttribute("aria-checked", on ? "true" : "false");
        lv.disabled = true;
        try {
          const r = await post("/api/apps3d/live", {on});
          liveOn = !!r.live; if (last) last.live = liveOn;
        } catch (e) {
          lv.classList.toggle("on", !on); lv.setAttribute("aria-checked", !on ? "true" : "false");
          toast(e.message);
        } finally { lv.disabled = false; }
      };
      const sw = body.querySelector("#a3-sw");
      if (!sw) return;
      sw.onclick = async () => {
        const on = !sw.classList.contains("on");
        sw.classList.toggle("on", on); sw.setAttribute("aria-checked", on ? "true" : "false");
        sw.disabled = true;
        try {
          const r = await loopFetch(on ? "/api/apps3d/allow" : "/api/apps3d/disallow", {json: {}});
          if (r.declined) { sw.classList.remove("on"); sw.setAttribute("aria-checked", "false"); }
          else toast(on ? tl("apps3d.added") : tl("apps3d.removed"));
        } catch (e) {
          sw.classList.toggle("on", !on); sw.setAttribute("aria-checked", !on ? "true" : "false");
          toast(e.message);
        } finally { sw.disabled = false; }
      };
      const dt = body.querySelector("#a3-difft"), pre = body.querySelector("#a3-pre");
      dt.onclick = async () => {
        const open = pre.hidden;
        pre.hidden = !open; dt.setAttribute("aria-expanded", open ? "true" : "false");
        if (!open || pre.dataset.done) return;
        pre.innerHTML = loadingHtml(tl("apps3d.diff_loading"));
        try {
          const p = await post("/api/apps3d/preview", {});
          pre.dataset.done = "1";
          pre.innerHTML = Object.entries(p).map(([k, v]) =>
            `<div class="a3-dh">${AGENT[k] ? agDot(k) : ""}${esc(AGENT[k] || k)}</div><pre class="a3-pre">${esc(v || tl("apps3d.nochange"))}</pre>`).join("");
        } catch (e) { pre.innerHTML = `<p class="srd">${esc(e.message)}</p>`; }
      };
    }

    // Already allowed before (the grant is remembered): scan at once, no button.
    paint(null, false);
    get("/api/apps3d/live").then((r) => { liveOn = !!r.live; if (!last) paint(null, false); }).catch(() => {});
    get("/api/consent").then((r) => { if ((r.scopes || []).indexOf(SCOPE) !== -1) load(); }).catch(() => {});
  }

  function css() {
    if (document.getElementById("a3-css")) return;
    const s = document.createElement("style");
    s.id = "a3-css";
    s.textContent = `
    .a3-card{margin:16px 0 0;padding:16px 16px 12px;border-radius:12px;background:var(--card);border:1px solid var(--line)}
    .a3-head{display:flex;align-items:center;gap:8px;min-height:24px}
    .a3-name{font-size:15px;font-weight:600;color:var(--t1)}
    .a3-sp{flex:1}
    .a3-ico{flex:none;width:28px;height:28px;border-radius:8px;display:grid;place-items:center;background:var(--btn);color:var(--t2);font-size:13px;font-weight:700;line-height:1}
    .a3-bar{display:flex;align-items:center;gap:12px;margin-top:16px}
    .a3-bar .srd{flex:1;min-width:0}
    .a3-bar .btn{flex:none}
    .a3-list.fold .a3-row:not(.on){display:none}
    .a3-oth{display:block;margin:6px 0 0 4px;padding:4px 0;font-size:13px;color:var(--t3)}
    .a3-oth:hover{color:var(--t1)}
    .a3-list{display:flex;flex-direction:column;gap:2px;margin:8px -6px 0}
    .a3-row{display:flex;align-items:center;gap:8px;min-height:40px;padding:0 12px;border-radius:8px;cursor:pointer;color:var(--t2);font-size:14px;transition:background-color .15s,color .15s}
    .a3-row:hover{background:var(--card-hi)}
    .a3-row:focus-visible{outline:2px solid var(--blue);outline-offset:-2px}
    .a3-row.on{background:var(--card-hi);color:var(--t1)}
    .a3-row.off{cursor:default;opacity:.55}
    .a3-row.off:hover{background:none}
    .a3-dot{flex:none;width:16px;height:16px;border-radius:50%;border:1.5px solid var(--t4);position:relative;transition:border-color .15s}
    .a3-dot::after{content:"";position:absolute;inset:3px;border-radius:50%;background:var(--blue);transform:scale(0);transition:transform .35s cubic-bezier(.3,1.4,.5,1)}
    .a3-row.on .a3-dot{border-color:var(--blue)}
    .a3-row.on .a3-dot::after{transform:scale(1)}
    .a3-v{font-weight:600;font-variant-numeric:tabular-nums}
    .a3-def{font-size:12px;font-weight:700;letter-spacing:.05em;color:var(--blue-t);background:var(--blue-w);padding:2px 8px;border-radius:6px;opacity:0;transform:scale(.9);transition:opacity .2s,transform .35s cubic-bezier(.3,1.4,.5,1)}
    .a3-row.on .a3-def{opacity:1;transform:none}
    .a3-note{font-size:12px;color:var(--orange)}
    .a3-tag{display:inline-block;padding:1px 8px;border-radius:6px;background:var(--btn);color:var(--t2);font-size:12px;font-weight:600;letter-spacing:.02em}
    .a3-tag.warn{color:var(--orange)}
    .a3-none{margin:8px 0 2px}
    .a3-more{margin-top:8px}
    .a3-hint{margin:8px 0 2px;overflow-wrap:anywhere}
    .a3-more summary{cursor:pointer;padding:4px 0;list-style-position:inside;width:max-content}
    .a3-path{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;padding:2px 0}
    .a3-difft{align-self:flex-start;display:inline-flex;align-items:center;gap:2px;margin-top:4px;padding:2px 0;font-size:13px;font-weight:500;color:var(--t2)}
    .a3-difft:hover{color:var(--t1)}
    .a3-difft:focus-visible{outline:2px solid var(--blue);outline-offset:2px;border-radius:var(--r-xs)}
    .a3-difft svg.i{width:12px;height:12px;transition:transform .2s var(--ease)}
    .a3-difft[aria-expanded="true"] svg.i{transform:rotate(90deg)}
    .a3-diff{margin:0 0 4px;padding:2px 0 12px 16px;border-left:2px solid var(--line)}
    .a3-dh{margin:8px 0 0;font-size:12px;font-weight:700;letter-spacing:.05em;color:var(--t3)}
    .a3-pre{margin:6px 0 0;padding:8px 12px;border-radius:var(--r-md);background:var(--card);border:1px solid var(--line);color:var(--t2);font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;max-height:260px;overflow:auto}
    .setpage .srow.a3-rule:has(+ .a3-diff:not([hidden])){border-bottom:0}
    #a3-sw:disabled{opacity:.6}
    @media (max-width:520px){.a3-bar{flex-wrap:wrap}.a3-note{flex-basis:100%;order:9}.a3-row{flex-wrap:wrap;padding:8px 12px}.a3-difft{min-height:32px}}
    @media (prefers-reduced-motion:reduce){.a3-dot::after{transform:none;opacity:0;transition:opacity .2s}.a3-row.on .a3-dot::after{opacity:1}.a3-def{transform:none;transition:opacity .2s}}`;
    document.head.appendChild(s);
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "apps3d", icon: "cube", title: "apps3d.title", draw});
})();
