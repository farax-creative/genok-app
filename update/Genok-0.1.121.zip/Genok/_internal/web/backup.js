// 설정 → 데이터 기록: the date timeline of JSON backups (design §10, served by backup.py), with a
// manual backup, a read-only preview, and a restore that shows what changes first. Media is never
// in these - only the metadata. Registered as a callable object, like rules.js.
(function () {
  "use strict";

  const kb = (n) => n < 1024 ? n + " B" : Math.round(n / 1024) + " KB";
  const clock = (iso) => (iso || "").replace("T", " ").slice(0, 16);
  // Literal tl() calls so tests/test_i18n.py sees every key.
  const KIND = () => ({daily: tl("backup.kind.daily"), manual: tl("backup.kind.manual"), safety: tl("backup.kind.safety")});
  const cts = (c) => tl("backup.counts", {p: (c || {}).projects || 0, i: (c || {}).items || 0, c: (c || {}).comments || 0});

  // Bucket an ISO time into 오늘 / 어제 / 이번 주 / a date, like the version history.
  function group(iso) {
    const d = new Date((iso || "").replace(" ", "T"));
    if (isNaN(d)) return tl("day.week");
    const floor = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate());
    const days = Math.round((floor(new Date()) - floor(d)) / 86400000);
    if (days <= 0) return tl("day.1");
    if (days === 1) return tl("day.2");
    if (days < 7) return tl("day.week");
    return `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()}`;
  }

  function rowHTML(b) {
    const d = b.delta && (b.delta.items > 0 || b.delta.comments > 0)
      ? " · " + tl("backup.delta", {i: b.delta.items, c: b.delta.comments}) : "";
    const tag = KIND()[b.kind] ? ` <span class="tag">${KIND()[b.kind]}</span>` : "";
    return `<div class="row" style="flex-wrap:wrap"><span class="tx" style="min-width:190px">
      <div class="t" style="font-size:16px">${esc(clock(b.at))}${tag}</div>
      <div class="s" style="white-space:normal">${cts(b.counts)}${d}</div>
      ${b.memo ? `<div class="s" style="white-space:normal">${esc(b.memo)}</div>` : ""}</span>
      <span style="flex:none;display:flex;gap:6px;margin-left:auto">
        <button class="btn sm press" data-prev="${esc(b.name)}">${tl("backup.preview")}</button>
        <button class="btn sm press" data-restore="${esc(b.name)}">${tl("backup.restore")}</button>
      </span></div>`;
  }

  // The second-copy folder: where it is and how the last copy went, or that there is none.
  function mirrorLine(m) {
    if (!m || !m.folder) return tl("backup.mirror.none");
    const l = m.last;
    if (l && l.ok === false) return tl("backup.mirror.fail", {e: esc(l.error || "")});
    if (l && l.ok) return tl("backup.mirror.last", {t: esc(clock(l.at))});
    return tl("backup.mirror.set");
  }

  function listHTML(list) {
    if (!list.length) return `<div class="row"><span class="tx"><div class="s">${tl("backup.empty")}</div></span></div>`;
    let html = "", last = null;
    for (const b of list) {
      const g = group(b.at);
      if (g !== last) { html += `<div class="sec">${esc(g)}</div>`; last = g; }
      html += rowHTML(b);
    }
    return html;
  }

  async function render(el) {
    let list, mir = null;
    try { list = await fetch("/api/backups").then((r) => r.json()); }
    catch { return; }                             // old server without the endpoint: show nothing
    try { mir = await fetch("/api/backup-mirror").then((r) => (r.ok ? r.json() : null)); } catch { mir = null; }
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="sec" style="padding-top:0">${tl("backup.title")}</div>
      <div class="s" style="margin:-4px 4px 10px">${tl("backup.desc")}</div>
      <div class="row" style="flex-wrap:wrap"><span class="tx" style="min-width:0;flex:1 1 220px">
        <div class="t" style="font-size:15px">${tl("backup.mirror.title")}</div>
        <div class="s" style="white-space:normal">${mirrorLine(mir)}</div>
        <input id="bkmir" class="in" maxlength="400" placeholder="${tl("backup.mirror.ph")}"
          value="${esc((mir && mir.folder) || "")}" style="width:100%;margin-top:6px" spellcheck="false"></span>
        <button class="btn sm press" id="bkmirset" style="align-self:flex-end">${tl("backup.mirror.save")}</button></div>
      <div class="row"><span class="tx"><input id="bkmemo" class="in" maxlength="200"
        placeholder="${tl("backup.memo.ph")}" style="width:100%"></span>
        <button class="btn sm press" id="bknow">${tl("backup.now")}</button></div>
      ${listHTML(list)}
      <div id="bkprev"></div><div style="height:6px"></div>
      <div class="row"><span class="tx"><div class="s" style="white-space:normal">${tl("res.bkD")}</div></span>
        <button class="btn sm press" data-go="storage">${tl("res.bkGo")}</button></div>`;
    el.innerHTML = "";
    el.appendChild(card);

    const prev = card.querySelector("#bkprev");
    const mirIn = card.querySelector("#bkmir"), mirBtn = card.querySelector("#bkmirset");
    const saveMirror = async () => {
      mirBtn.disabled = true;
      try {
        const folder = (mirIn.value || "").trim();
        await post("/api/backups/mirror", {folder});
        toast(folder ? tl("backup.mirror.done") : tl("backup.mirror.off"));
        render(el);
      } catch (err) { toast(err.message); mirBtn.disabled = false; }
    };
    mirBtn.onclick = saveMirror;
    mirIn.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); saveMirror(); } };
    card.querySelector("#bknow").onclick = async (e) => {
      const memo = (card.querySelector("#bkmemo").value || "").trim();
      e.currentTarget.disabled = true;
      try { await post("/api/backups/backup", {memo}); toast(tl("backup.made")); render(el); }
      catch (err) { toast(err.message); e.currentTarget.disabled = false; }
    };
    card.querySelectorAll("[data-prev]").forEach((b) => b.onclick = async () => {
      if (prev.dataset.open === b.dataset.prev) { prev.innerHTML = ""; prev.dataset.open = ""; return; }
      let p;
      try { p = await fetch("/api/backup-preview?name=" + encodeURIComponent(b.dataset.prev)).then((r) => r.json()); }
      catch (err) { toast(err.message); return; }
      prev.dataset.open = b.dataset.prev;
      prev.innerHTML = `<div class="card" style="margin-top:8px"><div class="sec" style="padding-top:0">${tl("backup.preview")} · ${esc(clock(p.at))}</div>
        <div class="s" style="margin:-4px 4px 8px">${cts(p.counts)}</div>`
        + (p.projects && p.projects.length
          ? p.projects.map((pr) => `<div class="row"><span class="tx"><div class="t">${esc(pr.name)}</div>
              <div class="s">${tl("backup.pitem", {i: pr.items, c: pr.comments})}</div></span></div>`).join("")
          : `<div class="row"><span class="tx"><div class="s">${tl("backup.preview.empty")}</div></span></div>`)
        + `<div class="row" style="justify-content:flex-end"><button class="btn sm press" data-close>${tl("ui.close")}</button></div></div>`;
      prev.querySelector("[data-close]").onclick = () => { prev.innerHTML = ""; prev.dataset.open = ""; };
    });
    card.querySelectorAll("[data-restore]").forEach((b) => b.onclick = async () => {
      const name = b.dataset.restore;
      let plan;
      try { plan = await fetch("/api/backup-plan?name=" + encodeURIComponent(name)).then((r) => r.json()); }
      catch { plan = null; }
      let msg;
      if (plan && plan.target) {
        msg = tl("backup.confirm.change", {name, i: plan.target.items, c: plan.target.comments});
        if (plan.overwrites_newer) msg += "\n" + tl("backup.warn.newer");
      } else {
        msg = tl("backup.confirm", {name});
      }
      if (!await askSheet(tl("backup.restore"), msg, !!(plan && plan.overwrites_newer), tl("toggleFav.3"))) return;
      b.disabled = true;
      try { const r = await post("/api/backups/restore", {name});
        toast(tl("backup.restored", {n: r.count})); setTimeout(() => location.reload(), 600); }
      catch (err) { toast(err.message); b.disabled = false; }
    });
  }

  const entry = Object.assign(function (el) { render(el); }, {page: "backup", title: "backup.title"});
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(entry);
})();
