// web/badges.js — tell Claude and Codex apart, and name the account a push ran under (M7).
//
// A small mark (Claude / Codex) and, when more than one account exists, an account chip, shown
// wherever a session authored something: the result header, the version timeline, item cards and
// the Codex comment line. It reads what hub_store now puts on items/versions (agent, account) and
// decorates the DOM v2.js already drew — no core render code is touched. It stays quiet for the
// common case: one agent and one account get no badge at all, so single users see no noise.
//
// Classic script: it shares v2.js's globals (D, esc, ic, iid, gname) and registers into the hooks
// tabs.js set up (LOOP_ITEM_VIEW, LOOP_HOME_CARDS). Korean copy is inline here on purpose - a
// self-contained module keeps the shared i18n file (ko.json) free of merge collisions during the
// parallel parity build; the labels themselves (Claude/Codex) are product names, not translated.
(function () {
  "use strict";

  var EN = function () { return window.I18N_LANG === "en"; };
  var STR = {get default_account() { return EN() ? "Default account" : "기본 계정"; }, get by_account() { return EN() ? "By account" : "계정별"; }, get empty() { return EN() ? "No results yet" : "아직 결과가 없어요"; }};
  var NAME = {claude: "Claude", codex: "Codex"};

  function items() { return (typeof D !== "undefined" && D.items) || []; }

  // Gating: only show a mark once the app actually holds more than one agent / account. account_id
  // falsy means the default account, which still counts as one distinct account.
  function multiAgent() {
    var seen = {};
    items().forEach(function (x) { if (x.agent) seen[x.agent] = 1; });
    return Object.keys(seen).length > 1;
  }
  function multiAccount() {
    var seen = {};
    items().forEach(function (x) { seen[x.account_id || "_default"] = 1; });
    return Object.keys(seen).length > 1;
  }

  // ---- the marks (strings, so they slot into the same places as v2.js's .tag chips) ----
  // force=true skips the "more than one agent" gate: the sessions screen lists both by nature.
  function agentBadge(agent, force) {
    if (!NAME[agent] || (!force && !multiAgent())) return "";
    var cls = agent === "codex" ? "x" : "c";
    return '<span class="lbadge la-' + cls + '" title="' + NAME[agent] + (EN() ? ' session">' : ' 세션">') + agDot(agent) + NAME[agent] + "</span>";
  }
  function accountChip(row) {
    if (!multiAccount()) return "";
    var label = (row && row.account) || STR.default_account;
    return '<span class="lchip" title="' + esc(label) + '">' + esc(label) + "</span>";
  }
  function marks(row) {           // agent + account, in that order, for one item/version/room
    var a = agentBadge(row && row.agent), c = accountChip(row);
    return (a || c) ? '<span class="lmeta">' + a + c + "</span>" : "";
  }

  // ---- CSS: matches v2.css .tag / .ag (22px tall, 12px, radius 6) so a mark sits on the same
  // baseline as the status chip beside it. Claude keeps the app's existing clay tone (.ag.c);
  // Codex gets a cool tone so the two never read the same at a glance. ----
  function injectCss() {
    if (document.getElementById("badges-css")) return;
    var s = document.createElement("style");
    s.id = "badges-css";
    s.textContent = [
      ".lmeta{display:inline-flex;align-items:center;gap:4px;flex-wrap:wrap}",
      ".lbadge,.lchip{flex:none;display:inline-flex;align-items:center;height:22px;padding:0 8px;",
      "border-radius:6px;font-size:12px;font-weight:600;line-height:1;letter-spacing:-.01em}",
      // Neutral pill (refern): the only colour is a 6px dot, so two agents read apart without shouting.
      ".lbadge{background:var(--btn);color:var(--t2)}",
      ".lchip{background:var(--btn);color:var(--t2)}",
      // On a card the marks get their own line under the meta text, which is nowrap+ellipsis.
      ".gi .tx .lmeta,.row .tx .lmeta{margin-top:4px}",
      // A dot on a version thumbnail: which agent cut that version, without crowding the strip.
      ".vth{position:relative}",
      ".vdot{position:absolute;right:3px;top:3px;width:8px;height:8px;border-radius:50%;",
      "box-shadow:0 0 0 2px var(--bg)}",
      ".vdot.la-c{background:#f0a27f}.vdot.la-x{background:#93b6ff}",
      ".row.note.astra .albl+.lbadge{margin-right:2px}",
    ].join("");
    document.head.appendChild(s);
  }

  // ---- item screen: header line, the version timeline, and the Codex comment rows ----
  function decorateItem(box, it, d) {
    var vs = (d && d.versions) || [];
    var cur = null;
    for (var i = 0; i < vs.length; i++) if (vs[i].v === it.v) { cur = vs[i]; break; }
    if (!cur && vs.length) cur = vs[vs.length - 1];

    var head = box.querySelector(".htitle p");
    if (head && cur) head.insertAdjacentHTML("beforeend", marks(cur));

    // A colour dot per version cut, only when the app spans more than one agent.
    if (multiAgent()) {
      var byV = {};
      vs.forEach(function (w) { byV[w.v] = w.agent; });
      box.querySelectorAll(".vtli[data-vt]").forEach(function (b) {
        var ag = byV[b.dataset.vt];
        if (!NAME[ag]) return;
        var th = b.querySelector(".vth");
        if (th && !th.querySelector(".vdot")) {
          var dot = document.createElement("span");
          dot.className = "vdot la-" + (ag === "codex" ? "x" : "c");
          dot.title = NAME[ag];
          th.appendChild(dot);
        }
      });
    }

    // Session-authored comment lines (astra): mark which agent wrote them - the item's newest
    // version's agent - when both agents are in play. Unknown (legacy) stays unmarked.
    if (multiAgent() && cur && NAME[cur.agent]) {
      box.querySelectorAll(".row.note.astra .albl").forEach(function (lbl) {
        if (lbl.nextElementSibling && lbl.nextElementSibling.classList.contains("lbadge")) return;
        lbl.insertAdjacentHTML("afterend", agentBadge(cur.agent));
      });
    }
  }

  // ---- cards (home + library + any [data-item] row): a mark line under the meta text ----
  function byKey(key) {
    var list = items();
    for (var i = 0; i < list.length; i++) if (iid(list[i]) === key) return list[i];
    return null;
  }
  function decorateCards(root) {
    (root || document).querySelectorAll("[data-item]:not([data-bdg])").forEach(function (el) {
      var tx = el.querySelector(".tx");
      if (!tx) return;
      el.setAttribute("data-bdg", "1");           // paint once; survives until v2.js redraws the card
      var x = byKey(el.dataset.item);
      if (!x) return;
      var html = marks(x);
      if (html) tx.insertAdjacentHTML("beforeend", html);
    });
  }

  // v2.js rebuilds #view on every nav; watch it and decorate whatever cards appear. Our own
  // inserts carry no [data-item], so they never re-trigger the pass.
  function watch() {
    var view = document.getElementById("view");
    if (!view) return;
    decorateCards(view);
    new MutationObserver(function () { decorateCards(view); }).observe(view, {childList: true, subtree: true});
  }

  // ---- home: a "계정별" card, only when more than one account has pushed ----
  function drawAccounts(body) {
    var card = body.closest ? body.closest(".homecard") : null;
    if (!multiAccount()) { if (card) card.remove(); return; }   // self-remove: no empty card
    var groups = {}, order = [];
    items().slice().sort(function (a, b) { return (b.at || "") < (a.at || "") ? -1 : 1; })
      .forEach(function (x) {
        var key = x.account || STR.default_account;
        if (!groups[key]) { groups[key] = {projects: {}, recent: []}; order.push(key); }
        var g = groups[key];
        g.projects[gname(x)] = 1;
        if (g.recent.length < 4) g.recent.push(x);
      });
    body.innerHTML = order.map(function (key) {
      var g = groups[key], projs = Object.keys(g.projects);
      var rows = g.recent.map(function (x) {
        return '<button class="row press" data-item="' + esc(iid(x)) + '">' +
          '<span class="tx"><div class="t" style="font-size:15px">' + esc(x.title) + "</div>" +
          '<div class="s">' + esc(gname(x)) + " · " + esc(ago(x.at)) + "</div></span>" +
          ic("chev", "i go") + "</button>";
      }).join("");
      return '<div class="lacct"><div class="lahd"><span class="lchip">' + esc(key) + "</span>" +
        '<em class="num">' + projs.length + "</em></div>" +
        (rows || '<div class="s" style="color:var(--t3)">' + STR.empty + "</div>") + "</div>";
    }).join("");
  }

  // The one badge, shared: sessions.js draws its rows and headers with these too.
  window.LoopBadges = {
    agent: function (a) { injectCss(); return agentBadge(a, true); },
    chip: function (label) { injectCss(); return label ? '<span class="lchip">' + esc(label) + "</span>" : ""; },
  };

  function init() {
    injectCss();
    (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(decorateItem);
    (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({id: "accounts", get title() { return STR.by_account; }, draw: drawAccounts});
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watch);
    else watch();
  }

  init();
})();
