// The menu a right click opens on a row of the chat list (web/project.js draws and wires it).
// This file owns the two pieces of arithmetic behind it, pure and tested in tests/ctxmenu.test.js:
// where the menu goes for a point on the screen, and which choice an arrow key lands on.
(function () {
  "use strict";

  // A menu w x h opened at (x, y) in a window W x H, kept `m` from every edge. It hangs down and
  // to the right of the point; with no room there it flips to the other side of the point, and a
  // menu taller or wider than the window is pinned to the margin (it scrolls inside).
  function place(x, y, w, h, W, H, m) {
    m = m || 0;
    const right = x + w <= W - m, below = y + h <= H - m;
    const left = Math.max(m, Math.min(right ? x : x - w, W - w - m));
    const top = Math.max(m, Math.min(below ? y : y - h, H - h - m));
    return {left: Math.round(left), top: Math.round(top), right, below};
  }

  // The choice a key moves to: `n` choices, `i` the one that has the keyboard (-1: none yet).
  // Down and up go round, Home and End jump. -1 for a key that is not one of these.
  function step(n, i, key) {
    if (!(n > 0)) return -1;
    if (key === "ArrowDown") return i < 0 ? 0 : (i + 1) % n;
    if (key === "ArrowUp") return i < 0 ? n - 1 : (i - 1 + n) % n;
    if (key === "Home") return 0;
    if (key === "End") return n - 1;
    return -1;
  }

  const api = {place, step};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.PjCtx = api;
})();
