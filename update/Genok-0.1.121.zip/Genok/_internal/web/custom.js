// Customisation (design: project identity + "화면"/"사용 방식" settings). This script reuses the
// helpers v2.js defines in the shared script scope (tl, esc, ic, get, post, toast, nav, render,
// load, D, cur, detail, libD, SCREENS). It applies the saved view options as data-* attributes and
// CSS variables on <html> (custom.css turns those into layout), so a change shows at once with no
// reload. The server (custom.py) is the source of truth; localStorage "loop-ui" is only a cache the
// inline head script reads to avoid a flash before this loads.
(function () {
  "use strict";

  var ST = {ui: null, work_mode: "auto", identity: {}};
  var LOCAL = "loop-ui", LAST = "loop-last";

  // Static label maps. Every key is written out as a static string so the i18n test finds it and
  // so a typo cannot silently fall through to the key name.
  var SKIN = LT(() => ([["base", tl("custom.skin.base")], ["astra", tl("custom.skin.astra")]]));
  var THEME = LT(() => ([["dark", tl("custom.theme.dark")], ["light", tl("custom.theme.light")]]));
  var DENSITY = LT(() => ([["comfortable", tl("custom.density.comfortable")], ["compact", tl("custom.density.compact")]]));
  var INSPECTOR = LT(() => ([["right", tl("custom.inspector.right")], ["bottom", tl("custom.inspector.bottom")]]));
  var THUMB = LT(() => ([["s", tl("custom.thumb.s")], ["m", tl("custom.thumb.m")], ["l", tl("custom.thumb.l")]]));
  var SCALE = LT(() => ([["xs", tl("custom.scale.xs")], ["s", tl("custom.scale.s")], ["m", tl("custom.scale.m")], ["l", tl("custom.scale.l")], ["xl", tl("custom.scale.xl")], ["xxl", tl("custom.scale.xxl")]]));
  var ZOOM = {xs: 0.85, s: 0.92, m: 1, l: 1.1, xl: 1.25, xxl: 1.5};
  var ZSTEPS = ["75", "90", "100", "110", "125", "150"];   // Ctrl + wheel, in % of the size above
  var START = LT(() => ([["home", tl("custom.start.home")], ["mine", tl("custom.start.mine")], ["last", tl("custom.start.last")]]));
  var PANEL = LT(() => ({
    directives: tl("custom.panel.directives"), versions: tl("custom.panel.versions"),
    comments: tl("custom.panel.comments"), history: tl("custom.panel.history"),
    side: tl("custom.panel.side"),
  }));
  // The shortcut-hint bar is folded into the general-settings keys toggle (data-pref="keys"),
  // so it is not a per-panel hide option here.
  // "side" is the app menu on the left. It is not hidden by a data-hide flag any more: it folds
  // (v2.js railMin), so every control for it moves the same state. ITEM_PANELS are the cards.
  var PANEL_ORDER = ["directives", "versions", "comments", "history", "side"];
  var ITEM_PANELS = ["directives", "versions", "comments", "history"];

  var EMOJIS = ["🎬", "🎨", "🧩", "🎮", "📦", "🗂", "📁", "🧪", "🔬", "🛠", "⚙️", "📐", "🖼", "🎞", "🎧", "🎵", "📸", "🌀", "💡", "🚀", "🔷", "🔶", "⭐", "📊"];
  // The brand key colours (custom.css maps each to --key/--on-key). Ivory is the default.
  var KEYS = LT(() => ([
    ["ivory", "#efe9dc", tl("custom.key.ivory")], ["blue", "#3d82f2", tl("custom.key.blue")],
    ["coral", "#ff6f59", tl("custom.key.coral")], ["mint", "#2fd4a7", tl("custom.key.mint")],
    ["violet", "#8f7cff", tl("custom.key.violet")], ["amber", "#f5a623", tl("custom.key.amber")],
  ]));
  var COLORS = ["#3d82f2", "#5e6ad2", "#7c5cff", "#d24b8f", "#e0563b", "#e08a2f", "#d9b23a", "#4caf6a", "#2fb8a8", "#2f9bd9", "#8a8f98", "#c04b4b", "#6a8f2f", "#b05fd9", "#4b6fd9"];

  function readLocal() { try { return JSON.parse(localStorage.getItem(LOCAL) || "{}"); } catch (e) { return {}; } }
  function cache() { try { localStorage.setItem(LOCAL, JSON.stringify({ui: ST.ui, work_mode: ST.work_mode})); } catch (e) {} }

  // ---- Apply the options -------------------------------------------------------------------
  // Text on a filled accent: dark on a light colour, white on a dark one (WCAG luminance).
  function onColor(hex) {
    var n = parseInt(String(hex).slice(1), 16);
    var lin = [n >> 16 & 255, n >> 8 & 255, n & 255].map(function (v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    var L = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2];
    return (1.05 / (L + 0.05)) >= ((L + 0.05) / 0.0632) ? "#fff" : "#121212";
  }
  function setAccent(c) {
    var h = document.documentElement;
    if (c) { h.style.setProperty("--accent", c); h.style.setProperty("--accent-on", onColor(c)); h.classList.add("has-accent"); }
    else { h.style.removeProperty("--accent"); h.style.removeProperty("--accent-on"); h.classList.remove("has-accent"); }
  }
  function routeProject() {
    try {
      if (typeof detail !== "undefined" && detail) {
        if (detail[0] === "item") return String(detail[1]).split("/")[0];
        if (detail[0] === "dept") return detail[1];
      }
      if (typeof libD !== "undefined" && libD) return libD;
    } catch (e) {}
    return "";
  }
  // The app accent stays the same on every screen. A project's own colour is only exposed as
  // --pj for small marks (icon, dot): tinting buttons and chips with it clashed with the palette.
  function applyRouteAccent() {
    var pj = routeProject(), id = pj && ST.identity[pj], h = document.documentElement;
    setAccent((ST.ui && ST.ui.accent) || "");
    if (id && id.color) h.style.setProperty("--pj", id.color); else h.style.removeProperty("--pj");
  }
  // 화면 크기 is the app window's own zoom (what Ctrl + / - is in a browser), so every screen lays
  // itself out as it does for a narrower or wider window. CSS zoom on the page was measured and
  // left out: it stretches every vh length and misplaces anything positioned from a measured box.
  // A browser tab has no such switch for a page to press; there the browser's own zoom does it.
  var inApp = function () { return typeof IN_APP !== "undefined" && IN_APP; };
  var zoomNow = 0, zoomWait = false;
  function applyScale(s) {
    var z = Math.round((ZOOM[s] || 1) * zoomPct() * 10) / 1000, api = window.pywebview && window.pywebview.api;
    if (!inApp() || z === zoomNow) return;
    if (api && api.set_zoom) { zoomNow = z; try { api.set_zoom(z); } catch (e) {} return; }
    if (zoomWait) return;                       // the bridge comes up a moment after the page
    zoomWait = true;
    window.addEventListener("pywebviewready", function () { zoomWait = false; applyScale((ST.ui || {}).scale); }, {once: true});
  }
  // Ctrl + / - / 0 and Ctrl + wheel zoom on top of 화면 크기, the way a browser zooms a page: the
  // size chosen in settings is 100% and stays as chosen. The window's own Ctrl + wheel zoom is
  // switched off (winframe.set_zoom): it only fired over some parts (a shown result's frame) and
  // left the window at a size nothing knew about. The zoom shows at once; the save follows, and
  // only the answer to the last step is taken so a quick roll of the wheel never steps back.
  // scale:begin
  var scaleSeq = 0;
  function zoomPct() { var z = String((ST.ui || {}).zoom || "100"); return ZSTEPS.indexOf(z) < 0 ? 100 : +z; }
  function scaleIdx() { return ZSTEPS.indexOf(String(zoomPct())); }
  function scaleTo(to) {
    var i = scaleIdx(), k;
    to = Math.max(0, Math.min(ZSTEPS.length - 1, to));
    k = ZSTEPS[to];
    if (to !== i) { ST.ui.zoom = k; applyScale(ST.ui.scale); cache(); }
    zoomUI(+k, true);
    if (to === i) return;
    var n = ++scaleSeq;
    post("/api/custom/ui", {zoom: k}).then(function (r) { if (n === scaleSeq) adopt({ui: r}); })
      .catch(function (e) { toast(e.message); });
  }
  function scaleKey(e) {
    if (!inApp() || !(e.ctrlKey || e.metaKey) || e.altKey || !ST.ui) return;
    var k = e.key, i = scaleIdx();
    var to = k === "0" ? ZSTEPS.indexOf("100") : k === "+" || k === "=" ? i + 1 : k === "-" || k === "_" ? i - 1 : -9;
    if (to === -9) return;
    e.preventDefault();
    scaleTo(to);
  }
  addEventListener("keydown", scaleKey, true);
  // One notch of a mouse wheel is one step; a touchpad sends many small moves, which add up to one.
  var wheelSum = 0, wheelAt = 0;
  function scaleWheel(dy) {
    var now = Date.now();
    if (now - wheelAt > 300) wheelSum = 0;
    wheelAt = now; wheelSum += dy;
    if (Math.abs(wheelSum) < 50 || !ST.ui) return;
    scaleTo(scaleIdx() + (wheelSum < 0 ? 1 : -1)); wheelSum = 0;
  }
  addEventListener("wheel", function (e) {
    if (!inApp() || !e.ctrlKey || e.altKey) return;
    // A picture opened big (full screen, compare) already zooms with the wheel and a touchpad pinch.
    if (e.target.closest && e.target.closest(".vw,.cvstage")) return;
    e.preventDefault();
    scaleWheel(e.deltaY);
  }, {capture: true, passive: false});
  // Over a shown HTML result the wheel lands in its frame (another origin), so the frame's page
  // hands it over (server.py puts the sender in each shown result).
  addEventListener("message", function (e) {
    var fr = document.querySelector(".media iframe"), d = e.data;
    if (!inApp() || !fr || e.source !== fr.contentWindow || !d || d.loop !== "wheel" || d.mod !== "ctrl" || typeof d.dy !== "number" || !isFinite(d.dy)) return;
    scaleWheel(d.dy);
  });
  // scale:end
  // The zoom in the toolbar, as a browser shows it: a magnifier that is there only while the
  // zoom is off 100%, and a small panel under it (the number, - and +, back to 100%). A step
  // opens the panel for a moment; pressing the magnifier keeps it open until a press elsewhere.
  var zpop = null, zpopT = 0, zheld = false;
  window.zoomChip = function () {
    var p = zoomPct();
    return '<button class="ib press zoomb" data-zoomb aria-label="' + esc(tl("custom.zoom.a", {p: p})) + '" title="' + esc(tl("custom.zoom.a", {p: p})) + '"' + (!inApp() || p === 100 ? " hidden" : "") + ">" + ic(p < 100 ? "zoomout" : "zoomin") + "</button>";
  };
  function zoomClose() { clearTimeout(zpopT); zheld = false; if (zpop) zpop.classList.remove("on"); }
  function zoomUI(p, brief) {
    var btn = null;
    document.querySelectorAll("[data-zoomb]").forEach(function (b) {
      b.hidden = p === 100; b.innerHTML = ic(p < 100 ? "zoomout" : "zoomin");
      b.title = tl("custom.zoom.a", {p: p}); b.setAttribute("aria-label", b.title);
      if (b.getClientRects().length || !btn) btn = b;
    });
    if (!zpop) {
      zpop = document.createElement("div"); zpop.className = "zpop"; zpop.setAttribute("role", "status");
      zpop.innerHTML = '<output class="num"></output><button class="ib press" data-zstep="-1" aria-label="' + esc(tl("custom.zoom.out")) + '">' + ic("minus") + '</button><button class="ib press" data-zstep="1" aria-label="' + esc(tl("custom.zoom.in")) + '">' + ic("plus") + '</button><button class="chip press" data-zstep="0">' + esc(tl("custom.zoom.reset")) + "</button>";
      zpop.addEventListener("click", function (e) {
        var b = e.target.closest("[data-zstep]"); if (!b) return;
        var d = +b.dataset.zstep; zheld = true;
        scaleTo(d ? scaleIdx() + d : ZSTEPS.indexOf("100"));
      });
      zpop.addEventListener("pointerenter", function () { clearTimeout(zpopT); });
      zpop.addEventListener("pointerleave", function () { if (!zheld) zpopT = setTimeout(zoomClose, 900); });
      document.body.appendChild(zpop);
    }
    zpop.firstChild.textContent = p + "%";
    zpop.querySelector('[data-zstep="-1"]').disabled = scaleIdx() === 0;
    zpop.querySelector('[data-zstep="1"]').disabled = scaleIdx() === ZSTEPS.length - 1;
    zpop.querySelector('[data-zstep="0"]').disabled = p === 100;
    // Under the magnifier, kept inside the window; at 100% the magnifier is gone, so it stays put.
    var r = btn && !btn.hidden && btn.getBoundingClientRect();
    if (r && r.width) { zpop.style.top = Math.round(r.bottom + 8) + "px"; zpop.style.left = Math.max(8, Math.round(r.right - zpop.offsetWidth)) + "px"; }
    zpop.classList.add("on");
    clearTimeout(zpopT);
    if (brief && !zheld) zpopT = setTimeout(zoomClose, 1600);
  }
  addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-zoomb]");
    if (b) { if (zpop && zpop.classList.contains("on") && zheld) zoomClose(); else { zheld = true; zoomUI(zoomPct(), false); } return; }
    if (zpop && zpop.classList.contains("on") && !zpop.contains(e.target)) zoomClose();
  }, true);
  addEventListener("keydown", function (e) { if (e.key === "Escape" && zpop && zpop.classList.contains("on")) zoomClose(); });
  // The app's style: the built-in look carries no attribute and no extra sheet; another one is
  // html[data-skin] plus its own stylesheet (web/skin-<name>.css), swapped in place.
  function applySkin(skin) {
    var h = document.documentElement, on = skin && skin !== "base" ? skin : "", link = document.getElementById("skin-css");
    if ((h.dataset.skin || "") === on && (!on || link)) return;
    // A style also rebuilds the shell from its own script (web/skin-<name>.js), so a switch starts the page over.
    if (applySkin.seen) setTimeout(function () { location.reload(); }, 200);
    if (!on) { delete h.dataset.skin; if (link) link.remove(); return; }
    if (!link) { link = document.createElement("link"); link.rel = "stylesheet"; link.id = "skin-css"; document.head.appendChild(link); }
    link.href = "/skin-" + on + ".css";
    h.dataset.skin = on;
  }
  function applyUI() {
    if (!ST.ui) return;
    var h = document.documentElement, u = ST.ui;
    h.dataset.theme = u.theme || "dark";
    h.dataset.density = u.density || "comfortable";
    h.dataset.inspector = u.focus ? "hidden" : (u.inspector || "right");
    h.dataset.thumb = u.thumb || "m";
    applySkin(u.skin); applySkin.seen = true;
    applyScale(u.scale);
    h.dataset.mode = ST.work_mode || "auto";
    h.dataset.unit = u.unit || "project";
    h.dataset.libGroup = u.lib_group || "unit";
    h.dataset.key = u.key || "ivory";
    var hide = u.hide || {}, on = ITEM_PANELS.filter(function (k) { return hide[k]; });
    if (on.length) h.setAttribute("data-hide", on.join(" ")); else h.removeAttribute("data-hide");
    applyRouteAccent();
    try { syncFolds(); } catch (e) {}
  }
  // A "side menu hidden" flag saved before the two controls were made one: fold the menu once
  // (so it can be brought back from its border handle) and clear the flag.
  function adoptLegacySide() {
    try {
      if (!ST.ui || !ST.ui.hide || !ST.ui.hide.side) return;
      railHide(true);
      ST.ui.hide.side = false; post("/api/custom/ui", {hide: {side: false}}).catch(function () {});
    } catch (e) {}
  }
  // v2.js reads the 사용 방식 knobs (sidebar titles, menu order, the unit word, how 결과물 piles)
  // through this, so it never needs to know where they are kept.
  window.LOOP_PREF = function (k) { return ST.ui ? ST.ui[k] : undefined; };

  // The role card on home (on in 메인 + 서브에이전트): how many results the main session pushed
  // itself and how many came in under each subagent/teammate role. A chip opens 결과물 piled by role.
  function roleCard() {
    try {
      if (!ST.ui || !ST.ui.role_card || cur !== "home" || detail) return;
      var view = document.getElementById("view"); if (!view || view.querySelector(".headwrap")) return;
      var items = (typeof D !== "undefined" && D.items) || [], by = {}, main = 0;
      items.forEach(function (x) { if (x.role) by[x.role] = (by[x.role] || 0) + 1; else main++; });
      var roles = Object.keys(by).sort(function (a, b) { return by[b] - by[a] || a.localeCompare(b, "ko"); });
      var chip = function (label, n) {
        return '<button type="button" class="headrole press" data-role-pile>' + esc(label) + ' <em class="num">' + n + "</em></button>";
      };
      var card = document.createElement("div");
      card.className = "card headwrap";
      card.innerHTML = '<div class="sec">' + esc(tl("custom.role.title")) + "</div>"
        + (roles.length ? '<div class="headroles">' + chip(tl("mode.main"), main) + roles.map(function (r) { return chip(r, by[r]); }).join("") + "</div>"
          : '<p class="headnone">' + esc(tl("custom.role.empty")) + "</p>");
      view.insertBefore(card, view.firstChild);
      card.querySelectorAll("[data-role-pile]").forEach(function (b) {
        b.onclick = function () { try { libO("role"); } catch (e) {} location.hash = "#lib"; };
      });
    } catch (e) {}
  }

  // A pencil beside the title on a project screen, to edit its emoji / colour / name.
  function deptPencil() {
    try {
      if (!detail || detail[0] !== "dept") return;
      var h1 = document.querySelector("#top h1.dt"); if (!h1 || h1.querySelector(".identedit")) return;
      var b = document.createElement("button");
      b.className = "identedit press";
      b.setAttribute("aria-label", tl("custom.ident.edit"));
      b.innerHTML = ic("pen") + "<span>" + esc(tl("custom.ident.edit")) + "</span>";
      b.onclick = function () { openPicker(detail[1]); };
      h1.appendChild(b);
    } catch (e) {}
  }

  // ---- Talk to the server ------------------------------------------------------------------
  function setUiKey(patch) {
    return post("/api/custom/ui", patch).then(function (r) { adopt({ui: r}); })
      .catch(function (e) { toast(e.message); });
  }
  // Take the server's resolved options and show them wherever they are drawn: the sidebar when a
  // title, the unit or the menus changed; 결과물's own pile choice is dropped when the default pile
  // changed (so the new one shows); the 사용 방식 page repaints in place, other pages redraw.
  function adopt(r) {
    var was = ST.ui || {}, now = r.ui;
    ST.ui = now; if (r.work_mode) ST.work_mode = r.work_mode;
    applyUI(); cache();
    var moved = function (k) { return JSON.stringify(was[k]) !== JSON.stringify(now[k]); };
    if (moved("lib_group")) { try { localStorage.removeItem("v2-libo"); } catch (e) {} }
    if (moved("starter")) presetMemo = null;
    if (["unit", "names", "menu_hide", "menu_order", "unit_name"].some(moved)) { try { drawChrome(); railPins(allItems()); } catch (e) {} }
    if (cur === "settings") { if (modeBox && modeBox.isConnected) paintMode(); else if (screenBox && screenBox.isConnected) paintScreen(was); else redrawSettings(); }
    else if (["unit", "lib_group", "role_card", "unit_name"].some(moved)) { try { render(); } catch (e) {} }
  }
  // The settings screen drawn again for fresh values, not as a new screen: the page and the menu
  // keep their scroll place, the entrance fade does not replay, and focus returns to the control
  // that was used (found by its place among the page's controls). `top` opens the page at its top.
  var SET_FOCUS = "button,input,select,textarea,gk-select,[tabindex]";
  function redrawSettings(top) {
    var keep = [".setpage", ".setmenu"].map(function (q) { var el = document.querySelector(q); return el ? el.scrollTop : 0; });
    var se = document.scrollingElement || document.documentElement, y = se.scrollTop;
    var pg = document.getElementById("setpage"), a = document.activeElement, at = -1;
    if (pg && a && pg.contains(a)) at = Array.prototype.indexOf.call(pg.querySelectorAll(SET_FOCUS), a);
    SCREENS.settings();
    var w = document.querySelector(".setwrap"); if (w) w.style.animation = "none";
    [".setpage", ".setmenu"].forEach(function (q, i) { var el = document.querySelector(q); if (el && !(top && !i)) el.scrollTop = keep[i]; });
    se.scrollTop = y;
    pg = document.getElementById("setpage");
    if (pg && at >= 0 && !top) { var f = pg.querySelectorAll(SET_FOCUS)[at]; if (f && f.tagName === a.tagName) try { f.focus({preventScroll: true}); } catch (e) {} }
  }
  // Fresh data for whatever screen is open; the settings screen keeps its place.
  function reloadShown() {
    if (typeof load !== "function") { if (cur === "settings") redrawSettings(); return; }
    return load().then(function () { if (cur === "settings") redrawSettings(); else render(); });
  }
  function setSw(b, on) { if (!b) return; b.classList.toggle("on", !!on); b.setAttribute("aria-checked", String(!!on)); }
  var MO = function () { return window.LOOP_MODES; };        // web/modes.js loads after this file
  // One 사용 방식 knob changed. The server keeps it only while it differs from the preset, so its
  // answer says whether the choice is now 커스텀 - or back to the plain preset.
  function setKnob(patch) {
    var was = !!(ST.ui && ST.ui.preset && ST.ui.preset.custom);
    return post("/api/custom/ui", patch).then(function (r) {
      adopt({ui: r});
      var now = !!(r.preset && r.preset.custom), m = MO().name(r.preset ? r.preset.base : ST.work_mode);
      if (now && !was) toast(tl("mode.tocustom", {m: m}));
      else if (!now && was) toast(tl("mode.same", {m: m}));
    }).catch(function (e) { toast(e.message); paintMode(); });
  }
  // A card picked: a preset (the server parks a 커스텀 set first, so nothing is lost), or 커스텀
  // (brings the parked set back). The toast's 되돌리기 returns to what was there.
  function setModeTo(k, quiet) {
    var p = (ST.ui && ST.ui.preset) || {}, before = p.custom ? "custom" : (ST.work_mode || "auto");
    return post("/api/custom/mode", {mode: k}).then(function (r) {
      adopt(r);
      if (!quiet) toastAct(tl("mode.applied", {m: MO().name(k)}), tl("toggleFav.3"), function () { setModeTo(before, true); });
    }).catch(function (e) { toast(e.message); paintMode(); });
  }
  // The first-run wizard saves the mode on the server itself; this applies its result on screen
  // straight away, so the chosen layout is visible without a reload.
  window.LOOP_APPLY_MODE = function (r) {
    if (!r || !r.ui) return;
    adopt(r);
  };
  function saveIdent(name, body) {
    return post("/api/custom/identity", Object.assign({project: name}, body)).then(function (r) {
      ST.identity[name] = r.identity; toast(tl("custom.ident.saved")); closePicker();
      if (typeof load === "function") return reloadShown(); applyUI();
    }).catch(function (e) { toast(e.message); });
  }

  // ---- Small controls ----------------------------------------------------------------------
  function seg(key, opts, val) {
    return '<div class="seg" data-seg="' + key + '">' + opts.map(function (o) {
      return '<button data-v="' + o[0] + '" class="' + (o[0] === val ? "on" : "") + '">' + esc(o[1]) + "</button>";
    }).join("") + "</div>";
  }
  function bindSegs(c) {
    c.querySelectorAll("[data-seg]").forEach(function (s) {
      s.querySelectorAll("button").forEach(function (b) {
        b.onclick = function () { var p = {}; p[s.dataset.seg] = b.dataset.v; setUiKey(p); };
      });
    });
  }
  function swatch(kind, val, active) {
    return '<button class="' + kind + (val === active ? " on" : "") + (val ? "" : " def") + '" data-acc="' + (val || "") + '"'
      + (val ? ' style="background:' + val + '"' : "") + ' aria-label="' + (val || esc(tl("custom.screen.accent.def"))) + '">' + (val ? "" : ic("x")) + "</button>";
  }

  // ---- Settings page: 사용 방식 -------------------------------------------------------------
  // Preset cards on top (web/modes.js), the knobs a preset sets as live controls below. Editing
  // any knob makes the choice 커스텀 on the server (custom.set_ui keeps the edited values);
  // 되돌리기 goes back to the preset. The page repaints in place so the ring glides between cards.
  var modeBox = null, modeRing = null, moreOpen = false, helpOpen = false;
  var NOTIFY = LT(() => ([["all", tl("mode.v.all")], ["main", tl("mode.v.main")], ["asks", tl("mode.v.asks")]]));
  var UNITS = LT(() => ([["project", tl("custom.unit.project")], ["dept", tl("custom.unit.dept")]]));
  function modePreset() { return (ST.ui && ST.ui.preset) || {base: ST.work_mode || "auto", custom: false, changed: [], saved: null}; }
  function knobTag(keys) {
    var ch = modePreset().changed || [];
    if (!keys.some(function (k) { return ch.indexOf(k) >= 0; })) return "";
    return ' <span class="mw-tag">' + esc(tl("mode.tag.custom")) + '</span><button type="button" class="mw-rv press" data-krv="' + keys.join(" ")
      + '" aria-label="' + esc(tl("mode.row.revert")) + '" title="' + esc(tl("mode.row.revert")) + '">' + ic("undo") + "</button>";
  }
  function kseg(k, opts, val, label) {
    return '<div class="seg mw-seg" role="radiogroup" aria-label="' + esc(label) + '">' + opts.map(function (o) {
      var on = o[0] === val;
      return '<button type="button" class="' + (on ? "on" : "") + '" role="radio" aria-checked="' + on + '" data-kseg="' + k + '" data-v="' + esc(o[0]) + '">' + esc(o[1]) + "</button>";
    }).join("") + "</div>";
  }
  function modeRows() {
    var u = ST.ui || {}, L = MO(), on = !!u.role_card;
    var libs = ["unit", "session", "role", "date"].map(function (v) { return [v, L.libName(u, v)]; });
    return setRow(esc(tl("mode.k.unit")) + knobTag(["unit"]), esc(tl("mode.k.unit.d")), kseg("unit", UNITS, u.unit || "project", tl("mode.k.unit")))
      + setRow(esc(tl("mode.k.lib")) + knobTag(["lib_group"]), esc(tl("mode.k.lib.d")), kseg("lib_group", libs, u.lib_group || "unit", tl("mode.k.lib")))
      + setRow(esc(tl("mode.k.role")) + knobTag(["role_card"]), esc(tl("mode.k.role.d")),
          '<button type="button" class="sw' + (on ? " on" : "") + '" role="switch" aria-checked="' + on + '" data-kbool="role_card" aria-label="' + esc(tl("mode.k.role")) + '"></button>')
      + setRow(esc(tl("mode.k.notify")) + knobTag(["notify"]), esc(tl("mode.k.notify.d")), kseg("notify", NOTIFY, u.notify || "all", tl("mode.k.notify")))
      + setRow(esc(tl("mode.k.wait")), esc(tl("mode.k.wait.d")),
          '<button type="button" class="sw' + (ST.session_wait_notify ? " on" : "") + '" role="switch" aria-checked="' + !!ST.session_wait_notify + '" data-waitnotify aria-label="' + esc(tl("mode.k.wait")) + '"></button>')
      + setRow(esc(tl("mode.k.chat")), esc(tl("mode.k.chat.d")),
          '<button type="button" class="sw' + (ST.result_in_chat ? " on" : "") + '" role="switch" aria-checked="' + !!ST.result_in_chat + '" data-chattoo aria-label="' + esc(tl("mode.k.chat")) + '"></button>')
      + setRow(esc(tl("custom.screen.start")) + knobTag(["start"]), esc(tl("mode.k.start.d")), kseg("start", START, u.start || "home", tl("custom.screen.start")))
      + setRow(esc(tl("mode.k.menus")) + knobTag(["menu_hide", "menu_order"]), esc(L.menuSummary(u)),
          '<button type="button" class="btn sm press" data-menued>' + esc(tl("custom.menued.btn")) + "</button>");
  }
  // 더 바꾸기: the knobs no preset card talks about - sidebar names, the detail panel side and
  // which starter views to offer.
  function modeMore() {
    var u = ST.ui || {}, nm = u.names || {}, L = MO(), starter = u.starter || modePreset().base;
    var name = function (k, label, ph) {
      return '<label class="mw-nm"><span>' + esc(label) + '</span><input class="setin" maxlength="12" data-name="' + k + '" value="' + esc(nm[k] || "") + '" placeholder="' + esc(ph) + '"></label>';
    };
    return '<div class="setsec">' + esc(tl("mode.names")) + knobTag(["names"]) + '</div><p class="setd">' + esc(tl("mode.names.d")) + "</p>"
      + '<div class="mw-names">' + name("favs", tl("mode.name.favs"), tl("chrome.1")) + name("menus", tl("mode.name.menus"), tl("MENUS.1"))
      + "</div>"
      + '<div class="setsec">' + esc(tl("mode.etc")) + "</div>"
      + setRow(esc(tl("custom.screen.inspector")) + knobTag(["inspector"]), esc(tl("custom.screen.inspector.d")),
          kseg("inspector", INSPECTOR, u.inspector || "right", tl("custom.screen.inspector")))
      + setRow(esc(tl("mode.k.starter")) + knobTag(["starter"]), esc(tl("mode.starter.d")),
          '<gk-select class="mw-sel" data-starter aria-label="' + esc(tl("mode.k.starter")) + '">' + L.keys.map(function (k) {
            return '<option value="' + k + '"' + (k === starter ? " selected" : "") + ">" + esc(L.name(k)) + "</option>";
          }).join("") + "</gk-select>");
  }
  function drawMode(c) {
    var L = MO(); L.css(); modeBox = c;
    c.innerHTML = '<div class="mw mw-set' + (helpOpen ? " mw-help" : "") + '"><h2 class="seth">' + esc(tl("custom.mode.title")) + '</h2><p class="setd">' + esc(tl("custom.mode.desc")) + "</p>"
      + '<div class="mw-grid n5" role="radiogroup" aria-label="' + esc(tl("custom.mode.title")) + '">'
      + L.keys.concat("custom").map(function (k) { return L.card(k, {}); }).join("") + "</div>"
      + '<p class="mw-banner" id="mw-banner" aria-live="polite"></p>'
      + '<div class="setsec">' + esc(tl("mode.sec")) + '<button type="button" class="lnk press" data-mwhelp aria-expanded="' + helpOpen + '">'
      + esc(helpOpen ? tl("itemView.30") : tl("ui.more1")) + '</button></div><div id="mw-rows"></div>'
      + '<details class="mw-more" id="mw-more"' + (moreOpen ? " open" : "") + '><summary>' + esc(tl("mode.more"))
      + ' <span class="mw-n" id="mw-n" hidden></span>' + ic("chev") + '</summary><div id="mw-morebody"></div></details>'
      + L.glossary() + "</div>";
    modeRing = L.ring(c.querySelector(".mw-grid"));
    c.addEventListener("click", function (e) {
      // 자세히: what each row means and the glossary, shown where they stand (the rows stay usable without them)
      var hb = e.target.closest("[data-mwhelp]");
      if (hb) {
        helpOpen = !helpOpen;
        hb.closest(".mw-set").classList.toggle("mw-help", helpOpen);
        hb.setAttribute("aria-expanded", String(helpOpen)); hb.textContent = helpOpen ? tl("itemView.30") : tl("ui.more1");
        return;
      }
      var w = e.target.closest("[data-waitnotify],[data-chattoo]");
      if (w) {                                   // not a preset knob: a plain setting of its own
        var won = w.getAttribute("aria-checked") !== "true", wk = w.hasAttribute("data-chattoo") ? "result_in_chat" : "session_wait_notify", wb = {};
        w.classList.toggle("on", won); w.setAttribute("aria-checked", String(won));
        ST[wk] = wb[wk] = won;
        post("/api/custom/prefs", wb).catch(function (er) {
          ST[wk] = !won; w.classList.toggle("on", !won); w.setAttribute("aria-checked", String(!won)); toast(er.message);
        });
        return;
      }
      var t = e.target.closest("[data-pick],[data-kseg],[data-kbool],[data-krv],[data-mrevert]"); if (!t) return;
      var u = ST.ui || {}, p = modePreset(), patch = {};
      if (t.dataset.pick) {
        var k = t.dataset.pick;
        if (k === (p.custom ? "custom" : p.base)) return;
        if (k === "custom" && !p.saved) {        // nothing to restore yet: show where 커스텀 is made
          var rows = c.querySelector("#mw-rows"), first = rows.querySelector("button");
          rows.scrollIntoView({behavior: RM() ? "auto" : "smooth", block: "start"});
          if (first) first.focus({preventScroll: true});
          return;
        }
        modeRing.to(t); setModeTo(k);
      } else if (t.dataset.kseg) {
        if (u[t.dataset.kseg] === t.dataset.v) return;
        patch[t.dataset.kseg] = t.dataset.v; setKnob(patch);
      } else if (t.dataset.kbool) { patch[t.dataset.kbool] = !u[t.dataset.kbool]; setKnob(patch); }
      else if (t.dataset.krv) { t.dataset.krv.split(" ").forEach(function (k) { patch[k] = null; }); setKnob(patch); }
      else setModeTo(p.base);
    });
    c.addEventListener("change", function (e) {
      var t = e.target, nm = {};
      if (t.dataset.name) { nm[t.dataset.name] = t.value.trim(); setKnob({names: nm}); }
      else if (t.hasAttribute("data-starter")) setKnob({starter: t.value});
    });
    c.querySelector("#mw-more").addEventListener("toggle", function (e) { moreOpen = e.currentTarget.open; });
    paintMode(true);
  }
  function paintMode(first) {
    if (!modeBox || !modeBox.isConnected || !modeRing) return;
    var L = MO(), p = modePreset(), sel = p.custom ? "custom" : (p.base || "auto"), grid = modeBox.querySelector(".mw-grid");
    var n = (p.changed || []).length || ((p.saved && p.saved.changed) || []).length, from = p.custom ? p.base : (p.saved && p.saved.base);
    grid.querySelectorAll("[data-pick]").forEach(function (b) {
      var on = b.dataset.pick === sel;
      b.classList.toggle("on", on); b.setAttribute("aria-checked", on);
      b.classList.toggle("base", !!p.custom && b.dataset.pick === p.base);
    });
    var sub = grid.querySelector('[data-pick="custom"] .mw-good');
    if (sub) sub.textContent = from && n ? tl("modes.custom.from", {m: L.name(from), n: n}) : tl("modes.custom.good");
    modeRing.to(grid.querySelector('[data-pick="' + sel + '"]'), first);
    modeBox.querySelector("#mw-banner").innerHTML = p.custom
      ? esc(tl("mode.banner", {m: L.name(p.base), n: n})) + ' <button type="button" class="lnk" data-mrevert>' + esc(tl("toggleFav.3")) + "</button>"
      : esc(L.what(sel));
    // Re-render the rows but keep keyboard focus on the control that was used.
    var a = document.activeElement, fk = a && modeBox.contains(a)
      ? (a.dataset.kseg ? '[data-kseg="' + a.dataset.kseg + '"][data-v="' + a.dataset.v + '"]' : a.dataset.kbool ? '[data-kbool="' + a.dataset.kbool + '"]'
        : a.dataset.name ? '[data-name="' + a.dataset.name + '"]' : a.hasAttribute("data-starter") ? "[data-starter]" : "") : "";
    modeBox.querySelector("#mw-rows").innerHTML = modeRows();
    modeBox.querySelector("#mw-morebody").innerHTML = modeMore();
    if (fk) { var f = modeBox.querySelector(fk); if (f) f.focus({preventScroll: true}); }
    var more = ["names", "inspector", "starter"].filter(function (k) { return (p.changed || []).indexOf(k) >= 0; }).length;
    var pill = modeBox.querySelector("#mw-n"); pill.textContent = more ? tl("mode.more.n", {n: more}) : ""; pill.hidden = !more;
  }

  // ---- 단위 이름 (화면): the word for the unit of work, used in every menu and message -----------
  // Words to pick from (the first is the default and is stored as ""), a box for any other word,
  // and two sentences that show the word with its particles before it is saved. A pick saves at
  // once; a typed word saves on Enter or [적용].
  var UNIT_MAX = 8, UNIT_BAD = "<>&\"'`{}";
  // Filled as 부서: tl() reads a 부서 in any text as the unit word, and here it is one of the
  // words to pick, so it must stay itself whatever word is saved.
  function unitWords() { return tl("unit.presets", null, "부서").split("|").filter(Boolean); }
  function unitClean(v) {
    return String(v || "").split("").filter(function (ch) { return ch >= " " && UNIT_BAD.indexOf(ch) < 0; }).join("")
      .split(" ").filter(Boolean).join(" ").slice(0, UNIT_MAX).trim();
  }
  function unitPrev(word) {
    return "<li>" + esc(tl("unit.prev.1", null, word)) + "</li><li>" + esc(tl("unit.prev.2", null, word)) + "</li>";
  }
  function unitSection(u) {
    var words = unitWords(), cur = u.unit_name || "", on = cur || words[0], free = words.indexOf(on) < 0;
    return '<div class="setsec" id="unit-name">' + esc(tl("unit.sec"))
      + (cur ? '<button type="button" class="lnk press un-rs" data-unit-reset>' + esc(tl("unit.reset")) + "</button>" : "") + "</div>"
      + '<p class="setd">' + esc(tl("unit.d")) + "</p>"
      + '<div class="un"><div class="un-pick" role="radiogroup" aria-label="' + esc(tl("unit.sec")) + '">' + words.map(function (w, i) {
        var sel = !free && w === on;
        return '<button type="button" class="un-w press' + (sel ? " on" : "") + '" role="radio" aria-checked="' + sel + '" data-unit-pick="' + esc(i ? w : "") + '">' + esc(w) + "</button>";
      }).join("") + "</div>"
      + '<div class="un-free' + (free ? " on" : "") + '"><label for="un-in">' + esc(tl("unit.free")) + "</label>"
      + '<span class="un-inw"><input class="setin" id="un-in" maxlength="' + UNIT_MAX + '" value="' + esc(free ? cur : "") + '" placeholder="' + esc(tl("unit.free.ph")) + '" autocomplete="off" spellcheck="false" aria-describedby="un-cnt">'
      + '<span class="un-cnt num' + (free && cur.length >= UNIT_MAX ? " full" : "") + '" id="un-cnt">' + (free ? cur.length : 0) + "/" + UNIT_MAX + "</span></span>"
      + '<button type="button" class="btn sm press un-go" data-unit-apply disabled>' + esc(tl("unit.apply")) + "</button></div>"
      + '<div class="un-prev"><span class="un-pk">' + esc(tl("unit.prev")) + '</span><ul id="un-prev" aria-live="polite">' + unitPrev(on) + "</ul></div></div>";
  }
  function saveUnit(word) {
    var was = (ST.ui && ST.ui.unit_name) || "";
    if (word === was) return Promise.resolve();
    return post("/api/custom/ui", {unit_name: word}).then(function (r) {
      adopt({ui: r});
      var now = r.unit_name || "";
      if (now) toastAct(tl("unit.saved", {w: now}), tl("toggleFav.3"), function () { saveUnit(was); });
      else toast(tl("unit.reset.done"));
    }).catch(function (e) { toast(e.message); });
  }
  function bindUnit(c) {
    var inp = c.querySelector("#un-in"); if (!inp) return;
    var go = c.querySelector("[data-unit-apply]"), prev = c.querySelector("#un-prev"), cnt = c.querySelector("#un-cnt");
    var saved = (ST.ui && ST.ui.unit_name) || "", words = unitWords(), box = c.querySelector(".un");
    c.querySelectorAll("[data-unit-pick]").forEach(function (b) { b.onclick = function () { saveUnit(b.dataset.unitPick); }; });
    var rs = c.querySelector("[data-unit-reset]"); if (rs) rs.onclick = function () { saveUnit(""); };
    var typed = function () { return unitClean(inp.value); };
    var apply = function () { var w = typed(); if (w) saveUnit(w === words[0] ? "" : w); };
    inp.oninput = function () {
      var w = typed();
      cnt.textContent = w.length + "/" + UNIT_MAX;
      cnt.classList.toggle("full", w.length >= UNIT_MAX);
      prev.innerHTML = unitPrev(w || saved || words[0]);
      go.disabled = !w || w === (saved || words[0]);
      // While another word is being typed the preview is about it, so the picked word steps back.
      box.classList.toggle("typing", !go.disabled);
    };
    inp.onkeydown = function (e) { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); apply(); } };
    go.onclick = apply;
  }

  // ---- Settings page: 화면 ------------------------------------------------------------------
  // The 화면 page in place after a change: every control takes its saved value where it stands
  // (no rebuild, so the page neither flashes nor jumps to the top, and focus stays put). Only the
  // unit-name block is drawn again, and only when the word itself changed.
  var screenBox = null, screenTab = "look";
  function paintScreen(was) {
    var c = screenBox, u = ST.ui || {}, hide = u.hide || {}, key = u.key || "ivory", acc = u.accent || "";
    var DEF = {theme: "dark", density: "comfortable", thumb: "m", scale: "l", skin: "base"};
    c.querySelectorAll("[data-seg]").forEach(function (s) {
      var v = u[s.dataset.seg] || DEF[s.dataset.seg];
      s.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === v); });
    });
    c.querySelectorAll("[data-key-pick]").forEach(function (b) { var on = b.dataset.keyPick === key; b.classList.toggle("on", on); b.setAttribute("aria-checked", String(on)); });
    c.querySelectorAll("[data-acc]").forEach(function (b) { b.classList.toggle("on", b.dataset.acc === acc); });
    c.querySelectorAll("[data-panelsw]").forEach(function (b) { var p = b.dataset.panelsw; setSw(b, p === "side" ? !railMin() : !hide[p]); });
    setSw(c.querySelector("[data-autoemoji]"), ST.auto_emoji !== false);
    var sec = c.querySelector("#unit-name");
    if (sec && (!was || (was.unit_name || "") !== (u.unit_name || ""))) {
      var a = document.activeElement, fk = !a || !c.contains(a) ? "" : a.hasAttribute("data-unit-pick") ? '[data-unit-pick="' + a.dataset.unitPick + '"]'
        : a.id === "un-in" || a.hasAttribute("data-unit-apply") ? "#un-in" : a.hasAttribute("data-unit-reset") ? "[data-unit-reset]" : "";
      var d = sec.nextElementSibling, box = d && d.nextElementSibling;
      if (box && box.classList.contains("un")) box.remove();
      if (d && d.classList.contains("setd")) d.remove();
      sec.outerHTML = unitSection(u);
      bindUnit(c);
      var f = fk && (c.querySelector(fk) || c.querySelector('[data-unit-pick][aria-checked="true"]') || c.querySelector("#un-in"));
      if (f) try { f.focus({preventScroll: true}); } catch (e) {}
    }
  }
  // What a switch does, shown where it is flipped: the settings dialog covers the item screen
  // these panels live on. The drawing holds no state of its own - custom.css fades each block by
  // the same data-hide / body.railmin the real screen reads, so it cannot disagree with the app.
  function panelPreview() {
    var bars = function (n) { return new Array(n + 1).join("<i></i>"); };
    var blk = function (p, n) { return '<div class="pvb pv-' + p + '" data-pv="' + p + '">' + bars(n) + "</div>"; };
    return '<figure class="pvfig" aria-hidden="true"><div class="pv">' + blk("side", 4)
      + '<div class="pv-main"><div class="pv-media"></div><div class="pv-col"><i class="pv-ttl"></i>'
      + blk("versions", 3) + blk("directives", 2) + blk("history", 1) + blk("comments", 3) + '<i class="pv-cm"></i></div></div></div>'
      + '<figcaption class="pvcap">' + esc(tl("custom.screen.pv")) + "</figcaption></figure>";
  }
  // 썸네일 크기 only shows in an item's file grid: one row of that grid per size, the chosen one lit
  // by html[data-thumb].
  function thumbPreview() {
    return '<span class="pvth" aria-hidden="true">' + [["s", 4], ["m", 3], ["l", 2]].map(function (t) {
      return '<span data-th="' + t[0] + '">' + new Array(t[1] + 1).join("<i></i>") + "</span>";
    }).join("") + "</span>";
  }
  function drawScreen(c) {
    screenBox = c;
    var u = ST.ui || {}, hide = u.hide || {}, acc = u.accent || "";
    var key = u.key || "ivory";
    var keyRow = setRow(tl("custom.screen.key"), tl("custom.screen.key.d"),
      '<div class="keys" role="radiogroup" aria-label="' + esc(tl("custom.screen.key")) + '">' + KEYS.map(function (k) {
        return '<button class="kc press' + (k[0] === key ? " on" : "") + '" role="radio" aria-checked="' + (k[0] === key) + '" data-key-pick="' + k[0]
          + '" style="--kc:' + k[1] + '" title="' + esc(k[2]) + '" aria-label="' + esc(k[2]) + '"></button>';
      }).join("") + "</div>");
    var rows = ""
      + setRow(tl("custom.screen.skin"), tl("custom.screen.skin.d"), seg("skin", SKIN, u.skin || "base"))
      + setRow(tl("custom.screen.theme"), "", seg("theme", THEME, u.theme || "dark"))
      + setRow(tl("custom.screen.density"), "", seg("density", DENSITY, u.density || "comfortable"))
      + setRow(tl("custom.screen.thumb"), "", thumbPreview() + seg("thumb", THUMB, u.thumb || "m"))
      + (inApp() ? setRow(tl("custom.screen.scale"), tl("custom.screen.scale.d"), seg("scale", SCALE, u.scale || "l"))
        : setRow(tl("custom.screen.scale"), tl("custom.screen.scale.web"), ""))
      + setRow(tl("custom.screen.accent"), tl("custom.screen.accent.d"),
          '<div class="accents">' + swatch("ac", "", acc) + COLORS.map(function (col) { return swatch("ac", col, acc); }).join("") + "</div>");
    // The start screen and the detail panel side are 사용 방식 knobs now (drawMode), not look.

    var panels = PANEL_ORDER.map(function (p) {
      var on = p === "side" ? !railMin() : !hide[p];
      return setRow(PANEL[p], p === "side" ? '<span class="pv-pc">' + esc(tl("custom.screen.pv.pc")) + "</span>" : "", '<button class="sw ' + (on ? "on" : "") + '" role="switch" aria-checked="' + on + '" data-panelsw="' + p + '" aria-label="' + esc(PANEL[p]) + '"></button>');
    }).join("");

    var autoOn = ST.auto_emoji !== false;
    var autoRow = setRow(tl("custom.pref.autoemoji"), tl("custom.pref.autoemoji.d"),
      '<button class="sw ' + (autoOn ? "on" : "") + '" role="switch" aria-checked="' + autoOn + '" data-autoemoji aria-label="' + esc(tl("custom.pref.autoemoji")) + '"></button>');

    var unitBox = unitSection(u);

    // Each project is one row that opens its own editor (emoji, colour, name); nothing is
    // changed from the list itself.
    var idns = Object.keys(ST.identity);
    var idlist = idns.length ? idns.map(function (n) {
      var it = ST.identity[n];
      return '<button class="srow go press" data-editp="' + esc(n) + '"><span class="srtx"><span class="srt">' + (it.icon && window.LOOP_ICONS ? LOOP_ICONS.html(it.icon) + " " : it.emoji ? esc(it.emoji) + " " : "") + esc(it.name || n) + "</span></span>"
        + '<span class="srctl">' + (it.color ? '<span class="idot" style="background:' + esc(it.color) + '"></span>' : "") + ic("chev") + "</span></button>";
    }).join("") : setRow("", tl("custom.ident.empty"), "");

    var io = '<div class="pfoot" style="margin-top:8px">'
      + '<button class="btn sm press" id="cust-export">' + esc(tl("custom.io.export")) + "</button>"
      + '<button class="btn sm press" id="cust-import">' + esc(tl("custom.io.import")) + "</button>"
      + '<input type="file" id="cust-file" accept="application/json,.json" hidden></div>';

    // The page is four tabs; only the open one is drawn. The tab is kept across redraws.
    var TABS = [["look", tl("custom.screen.sec.look")], ["layout", tl("custom.screen.tab.layout")],
                ["ident", tl("custom.screen.tab.ident")], ["file", tl("custom.screen.tab.file")]];
    if (!TABS.some(function (t) { return t[0] === screenTab; })) screenTab = "look";
    var body = screenTab === "look"
      ? '<div class="setsec">' + esc(tl("custom.screen.sec.key")) + "</div>" + keyRow
        + '<div class="setsec">' + esc(tl("custom.screen.sec.look"))
        + '<button class="lnk press" id="cust-reset">' + esc(tl("custom.reset")) + "</button></div>" + rows
      : screenTab === "layout"
      ? '<div class="setsec">' + esc(tl("custom.screen.sec.panels")) + "</div>"
        + '<div class="pvlay"><div class="pvrows">' + panels + "</div>" + panelPreview() + "</div>" + unitBox
      : screenTab === "ident"
      ? '<div class="setsec">' + esc(tl("custom.screen.sec.ident")) + "</div>" + autoRow + idlist
      : '<div class="setsec">' + esc(tl("custom.io.sec")) + "</div>" + io;

    c.innerHTML = '<h2 class="seth">' + esc(tl("custom.screen.title")) + '</h2>'
      + '<p class="setd">' + esc(tl("custom.screen.desc")) + "</p>"
      + '<div class="seg stabs" role="tablist">' + TABS.map(function (t) {
          var on = t[0] === screenTab;
          return '<button role="tab" aria-selected="' + on + '" class="' + (on ? "on" : "") + '" data-stab="' + t[0] + '">' + esc(t[1]) + "</button>";
        }).join("") + "</div>" + body;

    c.querySelectorAll("[data-stab]").forEach(function (b) {
      b.onclick = function () {
        if (b.dataset.stab === screenTab) return;
        screenTab = b.dataset.stab; drawScreen(c);
        var pg = c.closest(".setpage"); if (pg) pg.scrollTop = 0;
        var f = c.querySelector('[data-stab="' + screenTab + '"]'); if (f) try { f.focus({preventScroll: true}); } catch (e) {}
      };
    });
    bindSegs(c);
    // A key colour replaces a hand-picked accent, so the choice shows at once everywhere.
    c.querySelectorAll("[data-key-pick]").forEach(function (b) { b.onclick = function () { setUiKey({key: b.dataset.keyPick, accent: ""}); }; });
    c.querySelectorAll("[data-acc]").forEach(function (b) { b.onclick = function () { setUiKey({accent: b.dataset.acc}); }; });
    // Not data-panel: custom.css hides every [data-panel="x"] while panel x is off, and that took
    // the switch away with the panel, so it could not be turned back on.
    c.querySelectorAll("[data-panelsw]").forEach(function (b) {
      b.onclick = function () {
        var vis = b.getAttribute("aria-checked") !== "true", h = {};
        setSw(b, vis);                                    // the knob moves now; the server answer syncs the rest
        if (b.dataset.panelsw === "side") { setLeft(vis); return; }
        h[b.dataset.panelsw] = !vis; setUiKey({hide: h});
      };
      // The row under the pointer (or holding focus) lights its block in the drawing.
      var row = b.closest(".srow"), blk = c.querySelector('.pv [data-pv="' + b.dataset.panelsw + '"]');
      if (!row || !blk) return;
      var hot = function (on) { return function () { blk.classList.toggle("hot", on); }; };
      row.addEventListener("pointerenter", hot(true)); row.addEventListener("pointerleave", hot(false));
      row.addEventListener("focusin", hot(true)); row.addEventListener("focusout", hot(false));
    });
    bindUnit(c);
    c.querySelectorAll("[data-editp]").forEach(function (b) { b.onclick = function () { openPicker(b.dataset.editp); }; });
    var auto = c.querySelector("[data-autoemoji]");
    if (auto) auto.onclick = function (e) {
      var on = e.currentTarget.getAttribute("aria-checked") !== "true";
      setSw(e.currentTarget, on);
      setPrefs({auto_emoji: on});
    };
    var reset = c.querySelector("#cust-reset");
    if (reset) reset.onclick = function () { setUiKey({reset: true}).then(function () { toast(tl("custom.reset.done")); }); };
    var file = c.querySelector("#cust-file");
    if (file) {
      c.querySelector("#cust-export").onclick = exportSettings;
      c.querySelector("#cust-import").onclick = function () { file.click(); };
      file.onchange = function () { var f = file.files[0]; if (f) importSettings(f); };
    }
  }

  function setPrefs(patch) {
    return post("/api/custom/prefs", patch).then(function (r) {
      ST.auto_emoji = r.auto_emoji;
      // On the settings screen only the data is refreshed (the next screen draws from it); the
      // switch already shows the answer, so nothing is rebuilt under the finger.
      if (cur !== "settings") return reloadShown();
      if (screenBox && screenBox.isConnected) paintScreen(ST.ui); else redrawSettings();
      if (typeof load === "function") load();
    }).catch(function (e) { toast(e.message); if (screenBox && screenBox.isConnected) paintScreen(ST.ui); });
  }
  function exportSettings() {
    get("/api/custom/export").then(function (r) {
      var blob = new Blob([JSON.stringify(r, null, 2)], {type: "application/json"});
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = "genok-custom.json";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    }).catch(function (e) { toast(e.message); });
  }
  function importSettings(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data; try { data = JSON.parse(reader.result); } catch (e) { toast(tl("custom.io.bad")); return; }
      post("/api/custom/import", data).then(function (r) {
        ST.ui = r.ui; ST.work_mode = r.work_mode; ST.identity = r.identity || {}; ST.auto_emoji = r.auto_emoji; ST.session_wait_notify = r.session_wait_notify === true; ST.result_in_chat = r.result_in_chat === true; ST.turn_off = r.turn_off || [];
        applyUI(); cache(); toast(tl("custom.io.imported"));
        reloadShown();
      }).catch(function (e) { toast(e.message); });
    };
    reader.readAsText(file);
  }

  // ---- The "보기" quick menu on the item screen --------------------------------------------
  function addViewBtn() {
    var more = document.getElementById("imore"); if (!more || document.getElementById("viewbtn")) return;
    var wrap = document.createElement("span");
    wrap.className = "viewbtn"; wrap.id = "viewbtn";
    wrap.innerHTML = '<button class="ib press" id="viewtgl" aria-label="' + esc(tl("custom.view.title")) + '" title="' + esc(tl("custom.view.title")) + '">' + ic("list") + "</button>"
      + '<div class="viewmenu" id="viewmenu"></div>';
    more.parentNode.insertBefore(wrap, more);
    document.getElementById("viewtgl").onclick = function (e) { e.stopPropagation(); toggleViewMenu(); };
    // The right panel's toggle: the last slot of the top bar, the mirror of the sidebar toggle
    // in the first. Same state as the handle on the border and the row in the menu above.
    var it = document.createElement("button");
    it.type = "button"; it.className = "ib press infotgl"; it.id = "infotgl"; it.dataset.edge = "r"; it.innerHTML = PANEL_ICO;
    more.after(it);
  }
  // One switch row, used by this menu and the sidebar's menu editor: the row is the switch
  // (role=switch + aria-checked), the shared .sw is its knob. `attr` names what it controls.
  function viewSwitch(label, on, attr, desc, off) {
    return '<button type="button" class="vrow" role="switch" aria-checked="' + !!on + '" ' + attr + (off ? " disabled" : "") + '><span class="vr-x"><span class="vr-t">' + label + "</span>"
      + (desc ? '<span class="vr-d">' + esc(desc) + "</span>" : "") + '</span><span class="sw' + (on ? " on" : "") + '" aria-hidden="true"></span></button>';
  }
  function setSwitch(b, on) {
    if (!b) return;
    b.setAttribute("aria-checked", String(!!on));
    var k = b.querySelector(".sw"); if (k) k.classList.toggle("on", !!on);
  }
  // What each row says right now. Focus mode folds both sides, so both side rows read "off" then.
  var VSTATE = {
    focus: function () { return !!(ST.ui && ST.ui.focus); },
    compact: function () { return !!ST.ui && ST.ui.density === "compact"; },
    left: function () { return !railMin() && !VSTATE.focus(); },
    right: function () { return !infoMin() && !VSTATE.focus(); },
    keys: function () { return typeof pref === "function" && !!pref("keys"); },
  };
  function panelShown(p) { return !((ST.ui && ST.ui.hide) || {})[p]; }
  function syncViewMenu() {
    var m = document.getElementById("viewmenu"); if (!m || !m.classList.contains("on")) return;
    m.querySelectorAll("[data-vk]").forEach(function (b) { setSwitch(b, VSTATE[b.dataset.vk]()); });
    m.querySelectorAll("[data-vpanel]").forEach(function (b) { setSwitch(b, panelShown(b.dataset.vpanel)); });
  }
  // The menu stays open while its switches are used (the knob slides, the screen changes behind
  // it). Rows that do nothing on this screen are left out: a phone has no side columns to fold,
  // and with the detail panel set to sit under the work there is no right column either.
  function toggleViewMenu() {
    var m = document.getElementById("viewmenu"); if (!m) return;
    if (m.classList.contains("on")) { m.classList.remove("on"); return; }
    var pc = wide(), right = pc && document.documentElement.dataset.inspector !== "bottom";
    m.innerHTML = (pc ? viewSwitch(esc(tl("custom.view.focus")) + " <kbd>F</kbd>", VSTATE.focus(), 'data-vk="focus"', tl("custom.view.focus.d")) : "")
      + viewSwitch(esc(tl("custom.view.compact")), VSTATE.compact(), 'data-vk="compact"', tl("custom.view.compact.d"))
      + (pc ? viewSwitch(esc(tl("keybar.row")) + " <kbd>?</kbd>", VSTATE.keys(), 'data-vk="keys"') : "")   // X17: the hint bar under the result (web/v2.js)
      + (pc ? '<div class="vsec">' + esc(tl("custom.view.sides")) + "</div>"
        + viewSwitch(esc(tl("custom.panel.side")) + " <kbd>[</kbd>", VSTATE.left(), 'data-vk="left"', tl("custom.view.left.d"))
        + (right ? viewSwitch(esc(tl("custom.view.right")), VSTATE.right(), 'data-vk="right"', tl("custom.view.right.d")) : "") : "")
      + '<div class="vsec">' + esc(pc && right ? tl("custom.view.panels") : tl("custom.view.panels.m")) + "</div>"
      + ITEM_PANELS.map(function (p) { return viewSwitch(esc(PANEL[p]), panelShown(p), 'data-vpanel="' + p + '"'); }).join("");
    m.classList.add("on");
    m.onclick = function (e) {
      var b = e.target.closest(".vrow"); if (!b || b.disabled) return;
      var on = b.getAttribute("aria-checked") !== "true", k = b.dataset.vk, h = {};
      setSwitch(b, on);                                   // the knob moves now; the server answer syncs the rest
      if (k === "focus") setUiKey({focus: on}).then(syncViewMenu);
      else if (k === "compact") setUiKey({density: on ? "compact" : "comfortable"}).then(syncViewMenu);
      else if (k === "keys") { if (typeof keyBarToggle === "function") keyBarToggle(); syncViewMenu(); }
      else if (k === "left") { setLeft(on); syncViewMenu(); }
      else if (k === "right") { setRight(on); syncViewMenu(); }
      else { h[b.dataset.vpanel] = !on; setUiKey({hide: h}).then(syncViewMenu); }
    };
  }
  function closeViewMenu() { var m = document.getElementById("viewmenu"); if (m) m.classList.remove("on"); }

  // ---- Menus that hold switches (X13) -------------------------------------------------------
  // One rule for every menu whose rows are switches: it stays open while they are flipped, and
  // closes on a press outside it, Escape, its own trigger (the trigger's handler toggles), or
  // when the screen under it changes. A menu joins with stayMenu({id, trigger, close}): `id` is
  // the menu element (open = it has .on), `trigger` a selector for what opens it.
  var STAY = [];
  function stayMenu(reg) { STAY.push(reg); }
  function stayShut(skip) {
    var n = 0;
    STAY.forEach(function (r) {
      var m = document.getElementById(r.id);
      if (!m || !m.classList.contains("on") || (skip && skip(r, m))) return;
      r.close(); n++;
    });
    return n;
  }
  document.addEventListener("pointerdown", function (e) {
    var t = e.target;
    stayShut(function (r, m) { return m.contains(t) || !!(t.closest && t.closest(r.trigger)); });
  }, true);
  addEventListener("keydown", function (e) { if (e.key === "Escape") stayShut(); });
  addEventListener("hashchange", function () { stayShut(); });
  // A press inside a result shown in a frame (an HTML page, a PDF) never reaches this document:
  // the window loses focus to the frame instead, and that closes the menu too.
  addEventListener("blur", function () { stayShut(); });
  window.LOOP_STAYMENU = stayMenu;
  stayMenu({id: "viewmenu", trigger: "#viewtgl", close: closeViewMenu});

  // ---- Folding the two side columns ---------------------------------------------------------
  // Left = the app menu (v2.js railMin / toggleRail: one state for the toolbar button, "[", the
  // border handle and the 보기 menu). Right = the item screen's info column (kept here, in
  // localStorage like the rail). Focus mode folds both; un-folding one side from focus leaves the
  // other side folded, so the switch does exactly what its label says.
  function infoMin(v) {
    try { if (v === undefined) return localStorage.getItem("v2-infomin") === "1"; localStorage.setItem("v2-infomin", v ? "1" : "0"); } catch (e) { return false; }
  }
  function leaveFocus() { if (ST.ui) ST.ui.focus = false; applyUI(); setUiKey({focus: false}); }
  function setLeft(show) {
    var focus = VSTATE.focus();
    if (focus && !show) return;
    if (focus) { infoMin(true); leaveFocus(); }
    railHide(!show);
    syncFolds();
  }
  function setRight(show) {
    var focus = VSTATE.focus();
    if (focus && !show) return;
    if (focus) { railHide(true); leaveFocus(); }
    infoMin(!show);
    syncFolds();
  }
  // key: the shortcut shown in the tooltip ("[" folds the menu, "]" the right panel)
  var edgeTip = function (b, shown, what, key) {
    var t = shown ? tl("custom.fold.hide", {p: what}) : tl("custom.fold.show", {p: what});
    b.setAttribute("aria-label", t); b.title = key ? t + " ( " + key + " )" : t; b.setAttribute("aria-expanded", String(shown));
  };
  // Put the handles where the panels are and make them say what a press will do.
  function syncFolds() {
    var rail = document.getElementById("rail");
    document.body.classList.toggle("infomin", infoMin());
    if (rail) {
      var h = document.getElementById("edge-l");
      if (!h) {
        h = document.createElement("div"); h.className = "edgeh"; h.id = "edge-l";
        h.innerHTML = '<button type="button" class="edgeb l press" data-edge="l">' + ic("chev") + "</button>";
        rail.after(h);
      }
      var bl = h.firstChild, left = VSTATE.left();
      var ico = left && railState() === "icons";
      bl.classList.toggle("folded", !left); bl.classList.toggle("ico", ico); edgeTip(bl, left && !ico, tl("custom.panel.side"), "[");
    }
    var grip = document.getElementById("igrip"), col = grip && grip.parentElement.lastElementChild;
    if (grip) {
      var br = grip.querySelector(".edgeb");
      if (!br) {
        br = document.createElement("button"); br.type = "button"; br.className = "edgeb r press"; br.dataset.edge = "r"; br.innerHTML = ic("chev");
        // the grip drags to resize and resets on a double click: a press on the button is neither
        ["pointerdown", "dblclick", "keydown"].forEach(function (n) { br.addEventListener(n, function (e) { e.stopPropagation(); }); });
        grip.appendChild(br);
      }
      edgeTip(br, true, tl("custom.view.right"), "]");
      var box = grip.parentElement.parentElement, tab = box.querySelector(".edger");
      if (!tab) {
        tab = document.createElement("button"); tab.type = "button"; tab.className = "edgeb edger press"; tab.dataset.edge = "r"; tab.innerHTML = ic("chev");
        box.appendChild(tab);
      }
      edgeTip(tab, false, tl("custom.view.right"), "]");
      var tb = document.getElementById("infotgl");
      if (tb) { edgeTip(tb, VSTATE.right(), tl("custom.view.right"), "]"); tb.classList.toggle("on", VSTATE.right()); }
      var gone = !VSTATE.right() && wide() && document.documentElement.dataset.inspector !== "bottom";
      if (col) col.inert = gone;
      tab.tabIndex = gone ? 0 : -1;
    }
    syncViewMenu();
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-edge]"); if (!b) return;
    // The left handle folds the menu to its icons, never away: hiding it altogether stays in the
    // 보기 menu and on "{". A hidden menu comes back in the shape it had.
    if (b.dataset.edge === "l") { var s = railState(); if (s === "off" || VSTATE.focus()) setLeft(true); else setRail(s === "full" ? "icons" : "full"); syncFolds(); }
    else setRight(!VSTATE.right());
  });
  // The handles' tooltips are written once per fold: a language switch writes them again.
  window.addEventListener("loop-lang", function () { try { syncFolds(); } catch (e) {} });
  // Something is up over the page (the full-screen viewer, the stack viewer, search, a sheet, the
  // compare workspace): the page's own layout keys (F, [ and ]) wait, so the layer's keys win and
  // nothing changes behind it unseen.
  function layerUp() {
    var sh = document.getElementById("sheet");
    return !!document.querySelector(".vw,.stk,#ov.on") || !!(sh && sh.classList.contains("on"))
      || document.documentElement.classList.contains("cmpv-lock");
  }
  window.LOOP_LAYER_UP = layerUp;
  // "]" folds the right panel as "[" folds the left menu
  addEventListener("keydown", function (e) {
    if (e.key !== "]" || e.ctrlKey || e.metaKey || e.altKey || !wide() || !document.getElementById("igrip")) return;
    if (e.target.matches && e.target.matches("input,textarea,gk-select,[contenteditable]")) return;
    if (layerUp()) return;
    if (document.documentElement.dataset.inspector === "bottom") return;
    setRight(!VSTATE.right());
  });
  // In focus mode the menu is hidden by the mode, not folded: its toggle leaves the mode instead.
  document.addEventListener("click", function (e) {
    if (!VSTATE.focus() || !e.target.closest || !e.target.closest("[data-railmin]")) return;
    e.stopPropagation(); e.preventDefault(); setLeft(true);
  }, true);
  window.LOOP_FOLDS = syncFolds;          // v2.js calls this when the rail folds some other way ("[", the toolbar)

  // ---- Sidebar menus: hide the ones not used, bring them back ---------------------------------
  // One small editor, opened from 설정 > 사용 방식 > 메뉴. Built-in menus are the menu_hide knob (the
  // server's, so the phone agrees); extension screens are kept per browser in localStorage.
  // A hidden menu is only out of the list: search (Ctrl K) still opens it.
  // 검토함 and 추적 start off (X_OFF): what they do is on the result page already. Turning one on is
  // kept in its own list (v2-xshow), so the older list (v2-xhide) keeps its one meaning, "hidden",
  // and a build from before this reads it as it always did.
  var X_OFF = ["digest", "ledger"];
  function xList(key, set) {
    try {
      if (set) localStorage.setItem(key, JSON.stringify(set));
      var a = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(a) ? a : [];
    } catch (e) { return []; }
  }
  function xHidden(id, hide, show) { return hide.indexOf(id) >= 0 || (X_OFF.indexOf(id) >= 0 && show.indexOf(id) < 0); }
  function xOff(id) { return xHidden(id, xList("v2-xhide"), xList("v2-xshow")); }
  function xSet(id, on) {
    var without = function (key) { return xList(key).filter(function (k) { return k !== id; }); };
    var hide = without("v2-xhide"), show = without("v2-xshow");
    if (!on) hide.push(id); else if (X_OFF.indexOf(id) >= 0) show.push(id);
    xList("v2-xhide", hide); xList("v2-xshow", show);
  }
  function menuHid() { return ((ST.ui && ST.ui.menu_hide) || []).slice(); }
  // What v2.js drawChrome asks: is this extension screen out of the menu (the rail and the phone's tab bar).
  window.LOOP_MENUHIDE = {ext: xOff};
  function menuEdRows() {
    // an extension screen that has its own menu row (대화) is listed once, with the menus.
    // 홈 and 설정 cannot be taken out, so neither is listed: a row with nothing to flip is noise.
    var hid = menuHid(), xt = extTabs().filter(function (t) { return !M(t.id); });
    return "<h3>" + esc(tl("custom.menued.title")) + "</h3>"
      + MENUS.filter(function (m) { return m.k !== "settings" && m.k !== FAV_LOCK; }).map(function (m) {
        return viewSwitch(ic(m.i) + "<span>" + esc(m.n) + "</span>", hid.indexOf(m.k) < 0, 'data-mk="' + m.k + '"', "", false);
      }).join("")
      + xt.map(function (t) {
        return viewSwitch(ic(t.icon) + "<span>" + esc(t.label) + "</span>", !xOff(t.id), 'data-xk="' + esc(t.id) + '"');
      }).join("");
  }
  function openMenuEd(anchor) {
    var m = document.getElementById("menued");
    if (!m) {
      m = document.createElement("div"); m.className = "menued"; m.id = "menued";
      m.setAttribute("role", "dialog"); m.setAttribute("aria-label", tl("custom.menued.title"));
      document.body.appendChild(m);
      m.addEventListener("click", function (e) {
        var b = e.target.closest(".vrow"); if (!b || b.disabled) return;
        var on = b.getAttribute("aria-checked") !== "true";
        setSwitch(b, on);
        if (b.dataset.xk) { xSet(b.dataset.xk, on); try { drawChrome(); } catch (er) {} return; }
        var k = b.dataset.mk, list = menuHid().filter(function (x) { return x !== k; }); if (!on) list.push(k);
        // a favourite stays in 자주 쓰는 whatever is hidden, so hiding it takes it off there too
        if (!on && isFav(k)) toggleFav(k, false);
        setKnob({menu_hide: list});
      });
    }
    m.innerHTML = menuEdRows();
    m.classList.add("on");
    // beside what opened it, kept inside the window
    var r = anchor.getBoundingClientRect(), w = m.offsetWidth, h = m.offsetHeight;
    var x = wide() ? r.right + 8 : r.left, y = wide() ? r.top - 8 : r.bottom + 8;
    m.style.left = Math.max(12, Math.min(x, innerWidth - w - 12)) + "px";
    m.style.top = Math.max(12, Math.min(y, innerHeight - h - 12)) + "px";
    var f = m.querySelector(".vrow:not(:disabled)"); if (f) f.focus({preventScroll: true});
  }
  function closeMenuEd() { var m = document.getElementById("menued"); if (m) m.classList.remove("on"); }
  stayMenu({id: "menued", trigger: "[data-menued]", close: closeMenuEd});
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-menued]");
    if (!t) return;
    e.preventDefault(); e.stopPropagation();
    var m = document.getElementById("menued");
    if (m && m.classList.contains("on")) closeMenuEd(); else openMenuEd(t);
  }, true);

  // ---- Project identity picker (a small modal) ---------------------------------------------
  var pickName = "";
  function ensurePicker() {
    if (document.getElementById("pickov")) return;
    var ov = document.createElement("div");
    ov.className = "pick-ov"; ov.id = "pickov";
    ov.innerHTML = '<div class="pick" role="dialog" aria-modal="true">'
      + '<h3>' + esc(tl("custom.ident.title")) + "</h3><p class=\"psub\" id=\"picksub\"></p>"
      + '<div class="plab">' + esc(tl("custom.ident.emoji")) + '</div><div class="pemos" id="pickemos"></div>'
      + '<div class="plab">' + esc(tl("custom.ident.color")) + '</div><div class="pcols" id="pickcols"></div>'
      + '<div class="plab">' + esc(tl("custom.ident.name")) + '</div><input class="pname" id="pickname" maxlength="60">'
      + '<div class="pfoot"><button class="btn sm press" id="pickreset">' + esc(tl("custom.ident.auto")) + '</button><span class="sp"></span>'
      + '<button class="btn sm press" id="pickcancel">' + esc(tl("custom.ident.cancel")) + '</button>'
      + '<button class="btn sm fill press" id="picksave">' + esc(tl("custom.ident.save")) + "</button></div></div>";
    document.body.appendChild(ov);
    ov.addEventListener("click", function (e) { if (e.target === ov) closePicker(); });
    document.getElementById("pickcancel").onclick = closePicker;
    document.getElementById("pickreset").onclick = function () { saveIdent(pickName, {reset: true}); };
    document.getElementById("picksave").onclick = function () {
      var emo = ov.querySelector(".pemo.on"), col = ov.querySelector(".pcol.on"), was = ST.identity[pickName] || {};
      // An untouched emoji under a styled icon is only its fallback: sending it would drop the icon.
      saveIdent(pickName, {emoji: emo && !(was.icon && emo.dataset.e === was.emoji) ? emo.dataset.e : null, color: col ? col.dataset.c : "", name: document.getElementById("pickname").value.trim()});
    };
  }
  function openPicker(name) {
    ensurePicker();
    pickName = name;
    var id = ST.identity[name] || {}, ov = document.getElementById("pickov");
    document.getElementById("picksub").textContent = name;
    document.getElementById("pickname").value = id.name || name;
    document.getElementById("pickemos").innerHTML = EMOJIS.map(function (e) {
      return '<button class="pemo' + (e === id.emoji ? " on" : "") + '" data-e="' + e + '">' + e + "</button>";
    }).join("");
    document.getElementById("pickcols").innerHTML = '<button class="pcol' + (!id.color ? " on" : "") + '" data-c="" style="background:var(--btn)" title="' + esc(tl("custom.ident.auto")) + '"></button>'
      + COLORS.map(function (col) { return '<button class="pcol' + (col === id.color ? " on" : "") + '" data-c="' + col + '" style="background:' + col + '"></button>'; }).join("");
    ov.querySelectorAll(".pemo").forEach(function (b) { b.onclick = function () { ov.querySelectorAll(".pemo").forEach(function (x) { x.classList.remove("on"); }); b.classList.add("on"); }; });
    ov.querySelectorAll(".pcol").forEach(function (b) { b.onclick = function () { ov.querySelectorAll(".pcol").forEach(function (x) { x.classList.remove("on"); }); b.classList.add("on"); }; });
    ov.classList.add("on");
  }
  function closePicker() { var ov = document.getElementById("pickov"); if (ov) ov.classList.remove("on"); }

  // ---- Keyboard: F toggles focus mode ------------------------------------------------------
  addEventListener("keydown", function (e) {
    if (e.key !== "f" && e.key !== "F") return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.target.closest && e.target.closest("input,textarea,gk-select,[contenteditable]")) return;
    if (layerUp()) return;   // the viewer, a sheet, search: F is not the page's while one is open
    e.preventDefault();
    setUiKey({focus: !(ST.ui && ST.ui.focus)});
  });

  // =========================================================================================
  //  Saved views (design: 저장된 보기). A view is a filtering window over the one dataset - no
  //  modes to switch. web/views.js owns the predicates / sort / group / presets; here we store
  //  them, draw the one-row chip bar (counts on chips, the chosen one kept in view, the scroll
  //  position kept across redraws - hub lessons), pin them to the rail, and expose window.LOOP_VIEWS.
  // =========================================================================================
  var VIEWS = [];            // the saved views (stored); empty means "use the mode's preset"
  var curView = null;        // the applied view's id, or null (the default screen)
  var chipScroll = 0;        // remembered chip-bar scroll, so a redraw keeps its place

  var presetMemo = null;     // the starter views keep their ids until the mode changes
  function seededViews() {
    if (VIEWS.length) return VIEWS;
    var m = (ST.ui && ST.ui.starter) || ST.work_mode || "auto";
    if (!presetMemo || presetMemo.mode !== m) presetMemo = {mode: m, list: presetViews(m)};
    return presetMemo.list;
  }
  // The list to change and save. Starter views become stored ones on the first change, unpinned so
  // the rail does not suddenly grow duplicates of the native screens.
  function editable() {
    var list = JSON.parse(JSON.stringify(seededViews()));
    if (!VIEWS.length) list.forEach(function (v) { v.pin = false; });
    return list;
  }
  function viewById(id) { var a = seededViews(); for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i]; return null; }
  function screenViews(onTurn) { return seededViews().filter(function (v) { return (v.screen === "turn") === onTurn; }); }

  // Enrich an item with the two fields the smart predicates need but the summary cannot carry:
  // the department's flow (v2.js flowOf) and whether the reader favourited it (D.favs).
  function enrich(x) {
    try { if (typeof flowOf === "function") x.flow = flowOf(x); } catch (e) {}
    try { x.fav = !!(typeof D !== "undefined" && D.favs && typeof iid === "function" && D.favs.indexOf(iid(x)) !== -1); } catch (e) {}
    return x;
  }
  function allItems() { return ((typeof D !== "undefined" && D.items) || []).map(enrich); }
  function countView(v, items) { try { return filterItems(items, v).length; } catch (e) { return 0; } }

  function saveViews(list) {
    return post("/api/custom/views", {views: list}).then(function (r) {
      VIEWS = r.views || []; return VIEWS;
    }).catch(function (e) { toast(e.message); return VIEWS; });
  }

  var STATUS_LABEL = LT(() => ({pending: tl("STATUS_T.1"), changes: tl("st.work"), hold: tl("STATUS_T.3"), approved: tl("STATUS_T.4")}));
  function statusName(x) { try { if (typeof stName === "function") return stName(x); } catch (e) {} return STATUS_LABEL[x.status] || x.status || ""; }
  function groupLabel(group, key) {
    if (!key) return "";
    if (group === "status") return STATUS_LABEL[key] || key;
    if (group === "account") {      // key is the account id; show the user-chosen label, never the id
      var hit = ((typeof D !== "undefined" && D.items) || []).filter(function (x) { return (x.account_id || "") === key && x.account; })[0];
      return hit ? hit.account : (key ? key : tl("views.acct.default"));
    }
    if (group === "agent") return key === "claude" ? "Claude" : key === "codex" ? "Codex" : tl("views.agent.none");
    return key;
  }

  // ---- plain words for a view's filter -----------------------------------------------------
  var KIND_NAME = LT(() => ({video: tl("LIB_KINDS.2"), image: tl("LIB_KINDS.3"), html: tl("LIB_KINDS.4"), doc: tl("LIB_KINDS.5")}));
  var AGE_NAME = LT(() => ({today: tl("views.age.today"), "7": tl("views.age.7"), "30": tl("views.age.30")}));
  function describe(v) {
    var f = v.filter || {}, out = [];
    (f.status || []).forEach(function (k) { out.push(STATUS_LABEL[k] || k); });
    (f.smart || []).forEach(function (k) { out.push(SMART_LABEL[k] || k); });
    if (f.project && f.project.length) out.push(f.project.length > 2 ? f.project.slice(0, 2).join(", ") + " +" + (f.project.length - 2) : f.project.join(", "));
    (f.kind || []).forEach(function (k) { out.push(KIND_NAME[k] || k); });
    if (f.age && AGE_NAME[f.age]) out.push(AGE_NAME[f.age]);
    if (f.q) out.push("“" + f.q + "”");
    return out.length ? out.join(" · ") : tl("views.all");
  }
  // What the 보관함 filters are set to right now, as a saved-view filter (null = nothing set).
  function libFilter() {
    try {
      var f = {};
      var sm = {stalled: "read_stuck", undelivered: "unread", tidy: "stalled48", changes: "fixing"}[libF];
      // The status tab the library picked by itself on opening is not a filter the reader set.
      var auto = typeof libFAuto !== "undefined" && libFAuto;
      if (sm && !auto) f.smart = [sm]; else if (libF && libF !== "all" && !auto) f.status = [libF];
      if (libD) {
        var ps = [];
        ((typeof D !== "undefined" && D.items) || []).forEach(function (x) { if (gname(x) === libD && ps.indexOf(x.project) < 0) ps.push(x.project); });
        if (ps.length) f.project = ps;
      }
      if (libK) f.kind = [libK];
      var q = String(libQ || "").trim(); if (q) f.q = q;
      return Object.keys(f).length ? f : null;
    } catch (e) { return null; }
  }
  function sig(f) {
    f = f || {};
    return JSON.stringify(Object.keys(f).sort().map(function (k) { return [k, Array.isArray(f[k]) ? f[k].slice().sort() : f[k]]; }));
  }

  // ---- the one-row chip bar ----------------------------------------------------------------
  function chipBar(vs, items, f) {
    var chips = vs.map(function (v) {
      var n = countView(v, items), on = v.id === curView;
      return '<span class="vwc-w' + (on ? " on" : "") + '" data-vw="' + esc(v.id) + '">'
        + '<button class="vwc press" role="tab" aria-selected="' + on + '" data-view="' + esc(v.id) + '">'
        + (v.emoji ? '<span class="vwc-e">' + esc(v.emoji) + "</span>" : "")
        + '<span class="vwc-t">' + esc(v.name) + '</span><span class="vwc-n">' + n + "</span></button>"
        + '<button class="vwc-m press" data-vmenu="' + esc(v.id) + '" aria-haspopup="menu" aria-label="' + esc(tl("views.more")) + '">' + ic("more") + "</button></span>";
    }).join("");
    var save = f && !vs.some(function (v) { return sig(v.filter) === sig(f); })
      ? '<button class="vwc vwsave press" data-vsave>' + ic("plus") + '<span class="vwc-t">' + esc(tl("views.savethis")) + "</span></button>" : "";
    return '<div class="vwbar" id="vwbar" role="tablist">' + chips + save
      + '<button class="vwc more press" data-viewmanage aria-label="' + esc(tl("views.manage")) + '" title="' + esc(tl("views.manage")) + '">' + ic("list") + "</button></div>";
  }

  // Put the bar on 보관함 / 내 차례: the user's own views, plus "이 필터 저장" while a filter is set.
  // Called after a render and after any click / typing on the screen (the filters redraw only the
  // list below, not the whole page).
  function syncBar() {
    try {
      var view = document.getElementById("view"); if (!view || detail) return;
      var onTurn = (cur === "inbox"); if (!onTurn && cur !== "lib") return;
      var bar = view.querySelector("#vwbar");
      if (bar && bar.querySelector(".vwask")) return;                 // a name is being typed
      var running = curView && viewById(curView);
      var mine = (VIEWS.length || running) ? screenViews(onTurn) : [];
      var f = (!onTurn && !running) ? libFilter() : null;
      if (!mine.length && !f) { if (bar) bar.remove(); return; }
      var box = document.createElement("div");
      box.innerHTML = chipBar(mine, allItems(), f);
      if (bar) bar.replaceWith(box.firstChild); else view.insertBefore(box.firstChild, view.firstChild);
      wireChips(view);
    } catch (e) {}
  }
  function later() { setTimeout(syncBar, 0); }
  document.addEventListener("click", function (e) { if (e.target.closest && e.target.closest("#view") && !e.target.closest("#vwbar")) later(); }, true);
  document.addEventListener("input", function (e) { if (e.target && e.target.id === "libq") later(); }, true);

  function wireChips(scope) {
    var bar = scope.querySelector("#vwbar"); if (!bar) return;
    try { bar.scrollLeft = chipScroll; } catch (e) {}
    bar.addEventListener("scroll", function () { chipScroll = bar.scrollLeft; });
    bar.querySelectorAll("[data-view]").forEach(function (b) { b.onclick = function () { applyView(b.dataset.view); }; });
    bar.querySelectorAll("[data-vmenu]").forEach(function (b) { b.onclick = function (e) { e.stopPropagation(); chipMenu(b.dataset.vmenu, b.parentNode); }; });
    bar.querySelectorAll(".vwc-w").forEach(function (w) {
      w.addEventListener("contextmenu", function (e) { e.preventDefault(); chipMenu(w.dataset.vw, w); });
      // A long press opens the same menu on a phone (no right-click there).
      var t = null, x0 = 0, y0 = 0;
      w.addEventListener("pointerdown", function (e) {
        if (e.pointerType === "mouse") return;
        x0 = e.clientX; y0 = e.clientY;
        t = setTimeout(function () { t = null; w.dataset.lp = "1"; chipMenu(w.dataset.vw, w); }, 480);
      });
      w.addEventListener("pointermove", function (e) { if (t && Math.abs(e.clientX - x0) + Math.abs(e.clientY - y0) > 8) { clearTimeout(t); t = null; } });
      ["pointerup", "pointercancel"].forEach(function (n) { w.addEventListener(n, function () { if (t) { clearTimeout(t); t = null; } }); });
      w.addEventListener("click", function (e) { if (w.dataset.lp) { delete w.dataset.lp; e.stopImmediatePropagation(); e.preventDefault(); } }, true);
    });
    var sv = bar.querySelector("[data-vsave]");
    if (sv) sv.onclick = function () { startSave(sv); };
    var mg = bar.querySelector("[data-viewmanage]");
    if (mg) mg.onclick = function () { setPage = "views"; if (location.hash === "#settings") SCREENS.settings(); else location.hash = "#settings"; };
    dragSort(bar, ".vwc-w", "x", function (ids) { reorder(ids, false); });
    var on = bar.querySelector(".vwc-w.on");
    if (on && on.scrollIntoView) try { on.scrollIntoView({inline: "nearest", block: "nearest"}); } catch (e) {}
  }

  // ---- change the saved list ---------------------------------------------------------------
  function afterChange() {
    presetMemo = null;
    syncBar();
    if (cur === "settings") redrawSettings();
  }
  function saveThis(name) {
    var f = libFilter(); if (!f) return;
    var list = VIEWS.length ? editable() : [];        // the starter examples stay out of a first saved view
    list.push({name: name, emoji: "", screen: "lib", filter: f, pin: false});
    saveViews(list).then(function () { toast(tl("views.saved.n", {n: name})); afterChange(); });
  }
  function startSave(btn) {
    var f = libFilter(); if (!f) return;
    var guess = describe({filter: f}).split(" · ").slice(0, 2).join(" · ").slice(0, 40);
    var form = askName(guess, tl("views.name.ph"), saveThis, syncBar);
    btn.replaceWith(form);
    var i = form.querySelector("input"); i.focus(); i.select();
  }
  function renameView(id, name) {
    var list = editable(); list.forEach(function (v) { if (v.id === id) v.name = name; });
    saveViews(list).then(afterChange);
  }
  function removeView(id) {
    var prev = VIEWS.slice(), v = viewById(id), list = editable().filter(function (x) { return x.id !== id; });
    var was = curView === id; if (was) curView = null;
    saveViews(list).then(function () {
      afterChange();
      if (was && typeof render === "function") render();
      toastAct(tl("views.removed", {n: v ? v.name : ""}), tl("toggleFav.3"), function () { saveViews(prev).then(afterChange); });
    });
  }
  // Move one view a step among the views of its own screen.
  function moveBy(id, d) {
    var list = editable(), me = null, i;
    for (i = 0; i < list.length; i++) if (list[i].id === id) me = list[i];
    if (!me) return;
    var same = list.filter(function (v) { return (v.screen === "turn") === (me.screen === "turn"); });
    var ids = same.map(function (v) { return v.id; }), k = ids.indexOf(id), j = k + d;
    if (j < 0 || j >= ids.length) return;
    ids.splice(k, 1); ids.splice(j, 0, id);
    reorder(ids, me.screen === "turn");
  }
  // New order for one screen's views; the other screen's views keep their places.
  function reorder(ids, onTurn) {
    var list = editable(), by = {};
    list.forEach(function (v) { by[v.id] = v; });
    var q = ids.map(function (id) { return by[id]; }).filter(Boolean), n = 0;
    var out = list.map(function (v) { return ((v.screen === "turn") === onTurn) ? (q[n++] || v) : v; });
    saveViews(out).then(afterChange);
  }
  function editFull(id) {
    var v = viewById(id); if (!v) return;
    editView = JSON.parse(JSON.stringify(v)); setPage = "views";
    if (location.hash === "#settings") SCREENS.settings(); else location.hash = "#settings";
  }
  function chipMenu(id, anchor) {
    var vs = seededViews(), v = viewById(id); if (!v) return;
    var same = vs.filter(function (x) { return (x.screen === "turn") === (v.screen === "turn"); });
    var k = same.indexOf(v);
    vmenu(anchor, [
      {label: tl("views.rename"), fn: function () { renameChip(id); }},
      {label: tl("views.earlier"), off: k <= 0, fn: function () { moveBy(id, -1); }},
      {label: tl("views.later"), off: k >= same.length - 1, fn: function () { moveBy(id, 1); }},
      {label: tl("views.editfull"), fn: function () { editFull(id); }},
      {label: tl("views.delete"), danger: true, fn: function () { removeView(id); }},
    ]);
  }
  function renameChip(id) {
    var w = document.querySelector('#vwbar .vwc-w[data-vw="' + id + '"]'), v = viewById(id); if (!w || !v) return;
    var form = askName(v.name, tl("views.name.ph"), function (n) { renameView(id, n); }, syncBar);
    w.replaceWith(form);
    var i = form.querySelector("input"); i.focus(); i.select();
  }

  // An inline name field (not a modal): Enter saves, Esc or leaving the field with nothing cancels.
  function askName(initial, ph, done, cancel) {
    var f = document.createElement("form"); f.className = "vwask";
    f.innerHTML = '<input class="vwin" maxlength="40" aria-label="' + esc(ph) + '" placeholder="' + esc(ph) + '">'
      + '<button class="vwok press" type="submit" aria-label="' + esc(tl("custom.ident.save")) + '">' + ic("check") + "</button>";
    var inp = f.firstChild, fin = false;
    inp.value = initial || "";
    function end(ok) {
      if (fin) return; fin = true;
      var val = inp.value.trim(); f.remove();
      if (ok && val) done(val); else cancel();
    }
    f.onsubmit = function (e) { e.preventDefault(); end(true); };
    inp.onkeydown = function (e) { if (e.key === "Escape") { e.preventDefault(); end(false); } };
    inp.onblur = function () { setTimeout(function () { end(false); }, 140); };
    f.lastChild.onpointerdown = function (e) { e.preventDefault(); };   // keep focus so the tap saves
    return f;
  }

  // ---- a small popover menu ----------------------------------------------------------------
  window.LOOP_MENU = function (a, i, r) { vmenu(a, i, r); };
  function closeVMenu() { var m = document.getElementById("vwmenu"); if (m) m.remove(); }
  function vmenu(anchor, items, right) {
    closeVMenu();
    var m = document.createElement("div"); m.id = "vwmenu"; m.className = "vwmenu"; m.setAttribute("role", "menu");
    m.innerHTML = items.map(function (it, i) {
      return '<button role="menuitem" class="vwmi press' + (it.danger ? " danger" : "") + '" data-i="' + i + '"' + (it.off ? " disabled" : "") + ">" + esc(it.label) + "</button>";
    }).join("");
    document.body.appendChild(m);
    var r = anchor.getBoundingClientRect(), w = m.offsetWidth, h = m.offsetHeight;
    var left = right ? r.right - w : r.left;
    left = Math.max(8, Math.min(left, innerWidth - w - 8));
    var top = r.bottom + 6; if (top + h > innerHeight - 8) top = Math.max(8, r.top - h - 6);
    m.style.left = left + "px"; m.style.top = top + "px";
    requestAnimationFrame(function () { m.classList.add("on"); });
    m.onclick = function (e) { var b = e.target.closest("[data-i]"); if (!b || b.disabled) return; closeVMenu(); items[+b.dataset.i].fn(); };
    var first = m.querySelector(".vwmi:not([disabled])"); if (first) first.focus();
  }
  document.addEventListener("pointerdown", function (e) { if (!e.target.closest || !e.target.closest("#vwmenu")) closeVMenu(); }, true);
  addEventListener("scroll", closeVMenu, true);
  addEventListener("resize", closeVMenu);
  document.addEventListener("keydown", function (e) {
    var m = document.getElementById("vwmenu"); if (!m) return;
    if (e.key === "Escape") { closeVMenu(); return; }
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      var bs = [].slice.call(m.querySelectorAll(".vwmi:not([disabled])")), i = bs.indexOf(document.activeElement);
      e.preventDefault(); bs[(i + (e.key === "ArrowDown" ? 1 : -1) + bs.length) % bs.length].focus();
    }
  });

  // ---- drag to reorder: 1:1 with the pointer, neighbours slide aside, settles with a spring ----
  // `handle` limits where a drag may start (a grip); without it a mouse drag starts anywhere on the
  // item (touch keeps scrolling, and uses the menu's 앞으로 / 뒤로 instead).
  function dragSort(box, sel, axis, onDone, handle) {
    if (box.dataset.ds) return; box.dataset.ds = "1";
    var H = axis === "x", busy = false;
    box.addEventListener("pointerdown", function (e) {
      if (busy || e.button !== 0) return;
      var el = e.target.closest(sel); if (!el || !box.contains(el)) return;
      if (handle ? !e.target.closest(handle) : e.pointerType !== "mouse") return;
      if (e.target.closest("input,[data-vmenu],[data-rowmenu]")) return;
      var els = [].slice.call(box.querySelectorAll(sel)), i = els.indexOf(el);
      if (els.length < 2) return;
      var x0 = e.clientX, y0 = e.clientY, live = false, idx = i, shift = [];
      var rects = els.map(function (n) { return n.getBoundingClientRect(); });
      var gap = H ? (parseFloat(getComputedStyle(box).columnGap) || 0) : 0;
      var mid = rects.map(function (r) { return H ? r.left + r.width / 2 : r.top + r.height / 2; });
      var span = function (k) { return (H ? rects[k].width : rects[k].height) + gap; };
      function move(ev) {
        var d = H ? ev.clientX - x0 : ev.clientY - y0;
        if (!live) {
          if (Math.abs(H ? ev.clientX - x0 : ev.clientY - y0) < 6) return;
          live = true; box.classList.add("sorting"); el.classList.add("dragging");
          try { el.setPointerCapture(e.pointerId); } catch (er) {}
          el.style.transition = "none";
          box.addEventListener("click", swallow, true);
        }
        el.style.transform = H ? "translateX(" + d + "px)" : "translateY(" + d + "px)";
        var c = mid[i] + d, n = 0;
        els.forEach(function (o, j) {
          if (j === i) return;
          var moved = j < i ? c < mid[j] : c > mid[j];
          shift[j] = moved;
          o.style.transform = moved ? (H ? "translateX(" + (j < i ? span(i) : -span(i)) + "px)" : "translateY(" + (j < i ? span(i) : -span(i)) + "px)") : "";
          if (moved) n += (j < i ? -1 : 1);
        });
        idx = i + n;
      }
      function swallow(ev) { ev.stopPropagation(); ev.preventDefault(); box.removeEventListener("click", swallow, true); }
      function up() {
        removeEventListener("pointermove", move); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
        if (!live) return;
        setTimeout(function () { box.removeEventListener("click", swallow, true); }, 0);
        busy = true;
        var off = 0;
        els.forEach(function (o, j) { if (shift[j]) off += (j > i ? span(j) : -span(j)); });
        el.style.transition = ""; el.style.transform = H ? "translateX(" + off + "px)" : "translateY(" + off + "px)";
        var wait = matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 230;
        setTimeout(function () {
          els.forEach(function (o) { o.style.transform = ""; o.style.transition = ""; });
          box.classList.remove("sorting"); el.classList.remove("dragging"); busy = false;
          if (idx !== i) {
            var ids = els.map(function (o) { return o.dataset.vw || o.dataset.vrow || o.dataset.dept; });
            var mv = ids.splice(i, 1)[0]; ids.splice(idx, 0, mv);
            onDone(ids);
          }
        }, wait);
      }
      addEventListener("pointermove", move); addEventListener("pointerup", up); addEventListener("pointercancel", up);
    });
  }

  window.LOOP_DRAGSORT = dragSort;
  // 내 차례 알림 고르기: which kinds are off, and whether a waiting session pings (v2.js draws the sheet).
  window.LOOP_TURN = {
    off: function () { return ST.turn_off || []; },
    wait: function () { return ST.session_wait_notify === true; },
    set: function (body) {
      var was = {turn_off: ST.turn_off || [], session_wait_notify: ST.session_wait_notify};
      if ("turn_off" in body) ST.turn_off = body.turn_off;
      if ("session_wait_notify" in body) ST.session_wait_notify = body.session_wait_notify;
      return post("/api/custom/prefs", body).catch(function (er) {
        ST.turn_off = was.turn_off; ST.session_wait_notify = was.session_wait_notify; throw er;
      });
    }
  };

  function applyView(id) {
    curView = (curView === id) ? null : id;         // tapping the active chip clears it
    var v = viewById(id), onTurn = v && v.screen === "turn";
    var want = "#" + (onTurn ? "inbox" : "lib");
    if (location.hash === want || (curView === null)) { if (typeof render === "function") render(); }
    else location.hash = want;
  }

  function runRow(x) {
    return '<button class="row press" data-run="' + esc(x.project + "/" + x.id) + '">'
      + '<span class="ico sm">' + (x.icon ? esc(x.icon) : ic("doc")) + "</span>"
      + '<span class="tx"><div class="t" style="font-size:16px">' + esc(x.title || x.id) + "</div>"
      + '<div class="s">' + esc(gname(x)) + " · " + esc(statusName(x))
      + (x.count > 1 ? " · v" + x.count : "") + "</div></span>"
      + (x.new ? '<span class="dot"></span>' : "") + "</button>";
  }
  function renderRun(view, v, items) {
    var list = sortItems(filterItems(items, v), v.sort);
    // "project" grouping means dept only in 팀 모드 (views.js groupName / v2.js gname), so a
    // saved view's "부서별"/"작업별" piles match the rail and project page.
    var groups = groupItems(list, v.group, Date.now(), document.documentElement.dataset.unit === "dept");
    var body = list.length
      ? groups.map(function (g) {
          var head = g[0] ? '<div class="sec">' + esc(groupLabel(v.group, g[0])) + ' <em class="num">' + g[1].length + "</em></div>" : "";
          return head + '<div class="card vlist">' + g[1].map(runRow).join("") + "</div>";
        }).join("")
      : '<div class="card plan none"><p>' + esc(tl("views.empty")) + '</p>'
        + '<button class="btn sm press" data-viewclear>' + esc(tl("views.clear")) + "</button></div>";
    view.innerHTML = chipBar(screenViews(v.screen === "turn"), items) + '<div class="libwrap vrun">' + body + "</div>";
    wireChips(view);
    view.querySelectorAll("[data-run]").forEach(function (b) { b.onclick = function () { location.hash = "#item/" + b.dataset.run; }; });
    var cl = view.querySelector("[data-viewclear]"); if (cl) cl.onclick = function () { curView = null; if (typeof render === "function") render(); };
  }

  // Called from LOOP_AFTER_RENDER: put the chip bar on 보관함 / 내 차례, and take the list over
  // when a view is applied. Leaves every other screen untouched.
  function viewsAfterRender() {
    try {
      var view = document.getElementById("view"); if (!view || detail) return;
      var onTurn = (cur === "inbox"), onLib = (cur === "lib");
      if (!onTurn && !onLib) return;
      var items = allItems();
      var v = curView && viewById(curView);
      if (v && (v.screen === "turn") === onTurn) { renderRun(view, v, items); return; }
      if (curView && v && (v.screen === "turn") !== onTurn) curView = null;   // view is for the other screen
      railPins(items);                                                        // reflect saved pins (removes stale)
      // Only the user's own saved views surface as a chip bar. The built-in presets are starting
      // templates offered in 설정, not a filter forced onto the screen - so 내 차례 / 결과물 keep
      // their own native list and never look like a saved view took the page over. A view still
      // applies only when its chip (or rail pin) is explicitly tapped, above.
      syncBar();
    } catch (e) {}
  }

  // Pinned views also sit in the rail (desktop). The phone surface is the chip bar itself.
  function railPins(items) {
    try {
      var rail = document.getElementById("rail"); if (!rail) return;
      var old = rail.querySelector(".railviews"); if (old) old.remove();
      // Only the user's own saved views pin to the rail; the built-in presets stay templates in
      // 설정, so the rail never duplicates a native screen (e.g. a "할 일" pin beside 내 차례).
      var pins = VIEWS.filter(function (v) { return v.pin; });
      if (!pins.length) return;
      var box = document.createElement("div");
      box.className = "rgrp railviews";
      box.innerHTML = pins.map(function (v) {
        return '<button class="it press" data-railview="' + esc(v.id) + '">'
          + '<span class="pjico">' + (v.emoji ? esc(v.emoji) : ic("bell")) + "</span>"
          + '<span class="rl">' + esc(v.name) + '</span><em class="num">' + countView(v, items) + "</em></button>";
      }).join("");
      var first = rail.querySelector(".rgrp");
      rail.insertBefore(box, first || null);
      box.querySelectorAll("[data-railview]").forEach(function (b) { b.onclick = function () { applyView(b.dataset.railview); }; });
    } catch (e) {}
  }

  // ---- window.LOOP_VIEWS: the extension contract -------------------------------------------
  window.LOOP_VIEWS = {
    list: function () { return seededViews().map(function (v) { return JSON.parse(JSON.stringify(v)); }); },
    get: function (id) { var v = viewById(id); return v ? JSON.parse(JSON.stringify(v)) : null; },
    apply: function (id) { if (viewById(id)) applyView(id); },
    current: function () { return curView; },
    predicate: function (v) { return function (x) { return matchView(enrich(x), v); }; },
    save: function (v) {
      var list = seededViews().slice(), i = -1;
      if (v && v.id) for (var k = 0; k < list.length; k++) if (list[k].id === v.id) { i = k; break; }
      if (!v.id) v = Object.assign({id: newId()}, v);
      if (i >= 0) list[i] = v; else list.push(v);
      return saveViews(list);
    },
    remove: function (id) { return saveViews(seededViews().filter(function (v) { return v.id !== id; })); },
  };

  // ---- Settings page: 보기 (the view manager) ----------------------------------------------
  var SMART_LABEL = LT(() => ({
    need_check: tl("views.smart.need_check"), fixing: tl("views.smart.fixing"),
    unread: tl("views.smart.unread"), read_stuck: tl("views.smart.read_stuck"),
    stalled48: tl("views.smart.stalled48"), session_asks: tl("views.smart.session_asks"),
    await_verify: tl("views.smart.await_verify"), missing_fix: tl("views.smart.missing_fix"),
    has_question: tl("views.smart.has_question"), soon_archive: tl("views.smart.soon_archive"),
    fav: tl("views.smart.fav"),
  }));
  var GROUP_LABEL = LT(() => ({
    none: tl("views.group.none"), project: tl("views.group.project"), account: tl("views.group.account"), agent: tl("views.group.agent"),
    role: tl("views.group.role"), session: tl("views.group.session"), status: tl("views.group.status"), date: tl("views.group.date"),
  }));
  var SORT_LABEL = LT(() => ({new: tl("views.sort.new"), old: tl("views.sort.old"), waited: tl("views.sort.waited"), versions: tl("views.sort.versions")}));
  var editView = null;       // the view being edited in the manager, or null

  // The settings page is a short overview; making, renaming and ordering happen on the chips.
  function vrow(v) {
    return '<div class="srow vwrow" data-vrow="' + esc(v.id) + '">'
      + '<span class="grab" aria-hidden="true">' + ic("grip") + "</span>"
      + '<span class="srtx"><span class="srt">' + (v.emoji ? esc(v.emoji) + " " : "") + esc(v.name) + "</span>"
      + '<span class="srs">' + esc(describe(v)) + (v.pin ? " · " + esc(tl("views.pinned")) : "") + "</span></span>"
      + '<span class="srctl"><button class="ib sm press" data-rowmenu="' + esc(v.id) + '" aria-haspopup="menu" aria-label="' + esc(tl("views.more")) + '">' + ic("more") + "</button></span></div>";
  }
  function drawViews(c) {
    if (editView) return drawViewEdit(c);
    var vs = seededViews(), stored = VIEWS.length > 0;
    var body = [["lib", tl("views.screen.lib")], ["turn", tl("views.screen.turn")]].map(function (g) {
      var xs = vs.filter(function (v) { return (v.screen === "turn") === (g[0] === "turn"); });
      if (!xs.length) return "";
      return '<div class="setsec">' + esc(g[1]) + '</div><div class="vwlist" data-vscreen="' + g[0] + '">' + xs.map(vrow).join("") + "</div>";
    }).join("");
    c.innerHTML = '<div class="vwtop"><h2 class="seth">' + esc(tl("views.title")) + "</h2>"
      + '<button class="ib press" id="vw-more" aria-haspopup="menu" aria-label="' + esc(tl("views.more")) + '">' + ic("more") + "</button></div>"
      + '<p class="setd">' + esc(tl("views.desc")) + "</p>"
      + (stored ? "" : '<p class="setd vwnote">' + esc(tl("views.starter")) + "</p>")
      + (body || '<p class="setd">' + esc(tl("views.none")) + "</p>")
      + '<input type="file" id="vw-file" accept="application/json,.json" hidden>';

    var f = c.querySelector("#vw-file");
    c.querySelector("#vw-more").onclick = function (e) {
      var items = [
        {label: tl("views.new"), fn: function () { editView = {name: "", emoji: "", screen: "lib", filter: {}}; redrawSettings(true); }},
        {label: tl("custom.io.export"), fn: exportViews},
        {label: tl("custom.io.import"), fn: function () { f.click(); }},
      ];
      if (stored) items.push({label: tl("views.reset"), danger: true, fn: function () { var prev = VIEWS.slice(); saveViews([]).then(function () { afterChange(); toastAct(tl("views.reset.done"), tl("toggleFav.3"), function () { saveViews(prev).then(afterChange); }); }); }});
      vmenu(e.currentTarget, items, true);
    };
    f.onchange = function () { var file = f.files[0]; if (file) importViews(file); };
    c.querySelectorAll("[data-rowmenu]").forEach(function (b) {
      b.onclick = function () {
        var id = b.dataset.rowmenu, v = viewById(id); if (!v) return;
        var same = vs.filter(function (x) { return (x.screen === "turn") === (v.screen === "turn"); }), k = same.indexOf(v);
        vmenu(b, [
          {label: tl("views.rename"), fn: function () { renameRow(c, id); }},
          {label: tl("views.editfull"), fn: function () { editFull(id); }},
          {label: tl("views.earlier"), off: k <= 0, fn: function () { moveBy(id, -1); }},
          {label: tl("views.later"), off: k >= same.length - 1, fn: function () { moveBy(id, 1); }},
          {label: tl("views.delete"), danger: true, fn: function () { removeView(id); }},
        ], true);
      };
    });
    c.querySelectorAll(".vwlist").forEach(function (box) {
      dragSort(box, ".vwrow", "y", function (ids) { reorder(ids, box.dataset.vscreen === "turn"); }, ".grab");
    });
  }
  function renameRow(c, id) {
    var row = c.querySelector('.vwrow[data-vrow="' + id + '"] .srt'), v = viewById(id); if (!row || !v) return;
    var form = askName(v.name, tl("views.name.ph"), function (n) { renameView(id, n); }, function () { redrawSettings(); });
    row.replaceWith(form);
    var i = form.querySelector("input"); i.focus(); i.select();
  }
  function drawViewEdit(c) {
    var v = editView, f = v.filter || (v.filter = {}), sm = f.smart || [];
    var chk = function (on) { return '<span class="sw ' + (on ? "on" : "") + '"></span>'; };
    var smart = SMART_KEYS.map(function (k) {
      return '<button class="vrow press" data-sm="' + k + '"><span>' + esc(SMART_LABEL[k] || k) + '</span><span class="sp"></span>' + chk(sm.indexOf(k) !== -1) + "</button>";
    }).join("");
    var groupSel = '<gk-select id="vw-group" aria-label="' + esc(tl("views.f.group")) + '">' + Object.keys(GROUP_LABEL).map(function (g) { return '<option value="' + g + '"' + ((v.group || "none") === g ? " selected" : "") + ">" + esc(GROUP_LABEL[g]) + "</option>"; }).join("") + "</gk-select>";
    var sortSel = '<gk-select id="vw-sort" aria-label="' + esc(tl("views.f.sort")) + '">' + Object.keys(SORT_LABEL).map(function (s) { return '<option value="' + s + '"' + ((v.sort || "new") === s ? " selected" : "") + ">" + esc(SORT_LABEL[s]) + "</option>"; }).join("") + "</gk-select>";
    c.innerHTML = '<h2 class="seth">' + esc(v.id ? tl("views.edit") : tl("views.new")) + "</h2>"
      + setRow(tl("views.f.name"), "", '<input class="pname" id="vw-name" maxlength="40" value="' + esc(v.name || "") + '">')
      + setRow(tl("views.f.emoji"), "", '<input class="pname" id="vw-emoji" maxlength="8" style="width:60px" value="' + esc(v.emoji || "") + '">')
      + setRow(tl("views.f.screen"), "", seg("vw-screen", [["lib", tl("views.screen.lib")], ["turn", tl("views.screen.turn")]], v.screen || "lib"))
      + setRow(tl("views.f.pin"), tl("views.f.pin.d"), '<button class="sw ' + (v.pin ? "on" : "") + '" id="vw-pin" role="switch" aria-checked="' + !!v.pin + '"></button>')
      + '<div class="setsec">' + esc(tl("views.f.smart")) + "</div>" + smart
      + '<div class="setsec">' + esc(tl("views.f.arrange")) + "</div>"
      + setRow(tl("views.f.group"), "", groupSel) + setRow(tl("views.f.sort"), "", sortSel)
      + '<div class="pfoot" style="margin-top:12px"><button class="btn sm press" id="vw-del"' + (v.id ? "" : ' style="visibility:hidden"') + ">" + esc(tl("views.delete")) + "</button><span class=\"sp\"></span>"
      + '<button class="btn sm press" id="vw-cancel">' + esc(tl("custom.ident.cancel")) + "</button>"
      + '<button class="btn sm fill press" id="vw-save">' + esc(tl("custom.ident.save")) + "</button></div>";

    c.querySelectorAll("[data-sm]").forEach(function (b) {
      b.onclick = function () { var k = b.dataset.sm, s = editView.filter.smart || []; var i = s.indexOf(k);
        if (i >= 0) s.splice(i, 1); else s.push(k); editView.filter.smart = s; b.querySelector(".sw").classList.toggle("on", i < 0); };
    });
    c.querySelectorAll('[data-seg="vw-screen"] button').forEach(function (b) { b.onclick = function () { editView.screen = b.dataset.v; b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); }); }; });
    c.querySelector("#vw-pin").onclick = function (e) { editView.pin = e.currentTarget.getAttribute("aria-checked") !== "true"; setSw(e.currentTarget, editView.pin); };
    c.querySelector("#vw-cancel").onclick = function () { editView = null; redrawSettings(true); };
    c.querySelector("#vw-del").onclick = function () { var id = editView.id; editView = null; if (id) LOOP_VIEWS.remove(id).then(function () { redrawSettings(true); }); else redrawSettings(true); };
    c.querySelector("#vw-save").onclick = function () {
      editView.name = c.querySelector("#vw-name").value.trim();
      editView.emoji = c.querySelector("#vw-emoji").value.trim();
      editView.group = c.querySelector("#vw-group").value;
      editView.sort = c.querySelector("#vw-sort").value;
      if (!(editView.filter.smart || []).length) delete editView.filter.smart;
      if (!editView.name) { toast(tl("views.needname")); return; }
      var v = editView; editView = null;
      LOOP_VIEWS.save(v).then(function () { toast(tl("views.saved")); redrawSettings(true); });
    };
  }
  function exportViews() {
    get("/api/custom/views/export").then(function (r) {
      var blob = new Blob([JSON.stringify(r, null, 2)], {type: "application/json"});
      var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "genok-views.json";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    }).catch(function (e) { toast(e.message); });
  }
  function importViews(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data; try { data = JSON.parse(reader.result); } catch (e) { toast(tl("custom.io.bad")); return; }
      post("/api/custom/views/import", data).then(function (r) { VIEWS = r.views || []; toast(tl("custom.io.imported")); redrawSettings(); })
        .catch(function (e) { toast(e.message); });
    };
    reader.readAsText(file);
  }

  // The per-account connect rows moved into web/connect.js so all connection UI lives in one page
  // (the 에이전트 연결 settings page, "계정" section). Head-session reconnect stays here.

  // Head reconnect: on a project/room screen, a control to point feedback at a chosen session.
  function headReconnect() {
    try {
      if (!detail || detail[0] !== "dept") return;
      var view = document.getElementById("view"); if (!view || view.querySelector(".headconn")) return;
      var rooms = (typeof D !== "undefined" && D.board) || [];
      var key = detail[1];
      var room = null;
      for (var i = 0; i < rooms.length; i++) if (rooms[i].dept === key || rooms[i].key === key) { room = rooms[i]; break; }
      if (!room || !room.items || !room.items.length) return;
      var box = document.createElement("div");
      box.className = "card headconn"; box.style.padding = "14px";
      var opts = '<option value="">' + esc(tl("head.newest")) + "</option>";
      (room.sessions || (room.session_id ? [{id: room.session_id, label: room.session_id}] : [])).forEach(function (s) {
        var id = s.id || s; opts += '<option value="' + esc(id) + '"' + (room.head_session_id === id ? " selected" : "") + ">" + esc(s.label || id) + "</option>";
      });
      box.innerHTML = '<div class="sec" style="padding:0 0 8px">' + esc(tl("head.title")) + "</div>"
        + '<p class="s" style="color:var(--t3);margin:0 0 8px">' + esc(tl("head.desc")) + "</p>"
        + '<div class="row" style="gap:8px"><gk-select id="headsel" style="flex:1" aria-label="' + esc(tl("head.title")) + '">' + opts + "</gk-select></div>";
      view.insertBefore(box, view.firstChild);
      box.querySelector("#headsel").onchange = function (e) {
        var target = room.items[0];
        post("/api/head", {project: target.project, id: target.item || target.id, session_id: e.target.value || null})
          .then(function () { toast(tl("head.set")); }).catch(function (er) { toast(er.message); });
      };
    } catch (e) {}
  }

  // ---- Hooks into v2.js --------------------------------------------------------------------
  window.LOOP_AFTER_RENDER = function () {
    applyRouteAccent(); roleCard(); deptPencil(); headReconnect(); viewsAfterRender();
  };
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(function () { addViewBtn(); syncFolds();
    document.documentElement.classList.toggle("ichat-on", !!window.pjEmbed); });   // the chat tab replaces the 세션 기록 card

  // ---- The item screen's 대화 tab: the live chat with the session behind this result ----------
  // project.js draws and streams it (window.pjEmbed, the same pane as the room screen); this is
  // the frame around it: who it is, a link to the full chat, and a grip that sizes the log.
  var CHAT_H = "v2-ichat-h";
  function chatH() { var h = 0; try { h = +localStorage.getItem(CHAT_H) || 0; } catch (e) {} return h; }
  function itemChat(body, it) {
    var enc = encodeURIComponent, name0 = it.dept || it.p;
    body.innerHTML = '<div class="ichat"><div class="ichat-head"><span class="pj-dot ended" id="ichat-dot"></span><b id="ichat-name">' + esc(pname(name0)) + "</b>"
      + '<span class="sp"></span><a class="ichat-open press" id="ichat-open" hidden>' + esc(tl("custom.chat.open")) + ic("chev", "i") + "</a></div>"
      + '<div class="ichat-body pj-mb"><p class="ichat-dim">' + loadingHtml(tl("custom.chat.loading")) + "</p></div>"
      + '<div class="ichat-grip" id="ichat-grip" role="separator" aria-orientation="horizontal" tabindex="0" aria-label="' + esc(tl("custom.chat.grip")) + '" title="' + esc(tl("custom.chat.grip")) + '"><i></i></div></div>';
    var wrap = body.firstChild, pane = wrap.querySelector(".ichat-body"), dot = wrap.querySelector("#ichat-dot");
    var setH = function (h) { wrap.style.setProperty("--ichat-h", Math.round(h) + "px"); };
    if (chatH()) setH(chatH());
    var say = function (text, btn, go) {
      pane.innerHTML = '<p class="ichat-dim">' + esc(text) + "</p>" + (btn ? '<p class="ichat-dim"><button class="btn weak press" id="ichat-go">' + esc(btn) + "</button></p>" : "");
      var b = pane.querySelector("#ichat-go"); if (b) b.onclick = go;
    };
    var open = function () {
      get("/api/session/reach?p=" + enc(it.p) + "&i=" + enc(it.i)).catch(function () { return {}; }).then(function (r) {
        if (!wrap.isConnected) return null;
        return window.pjEmbed(pane, {sid: (r && r.sid) || "", name: name0});
      }).then(function (res) {
        if (!res || !wrap.isConnected) return;
        wrap.querySelector("#ichat-name").textContent = pname(res.name || name0);
        if (res.consent) return say(tl("custom.chat.consent"), tl("custom.chat.retry"), open);
        if (!res.session) return say(tl("custom.chat.none"), tl("custom.chat.start"), function () { location.hash = "#project/" + enc(res.name || name0); });
        var link = wrap.querySelector("#ichat-open");
        link.hidden = false; link.href = "#project/" + enc(res.name) + "/" + enc(res.session.id);
        // Came here from that very conversation: the link goes back to it instead of stacking a second copy.
        link.onclick = function (e) { if (window.LOOP_ITEM_FROM && window.LOOP_ITEM_FROM() === res.session.id) { e.preventDefault(); history.back(); } };
        // The dot follows the pane's own state (project.js refreshes it every few seconds).
        var tick = function () { if (!wrap.isConnected) return; dot.className = "pj-dot " + (res.state() || "ended"); setTimeout(tick, 3000); };
        tick();
      }).catch(function (e) { if (wrap.isConnected) say(e.message || tl("sess.err")); });
    };
    open();
    // The grip sizes the log 1:1 with the pointer; arrows step it. The size is kept for next time.
    var grip = wrap.querySelector("#ichat-grip");
    var clampH = function (h) { return Math.max(160, Math.min(h, innerHeight - 220)); };
    var logEl = function () { return pane.querySelector(".pj-msgs"); };
    grip.onpointerdown = function (e) {
      var m = logEl(); if (!m) return;
      e.preventDefault(); grip.setPointerCapture(e.pointerId);
      var y0 = e.clientY, h0 = m.offsetHeight, h = h0;
      grip.onpointermove = function (ev) { h = clampH(h0 + ev.clientY - y0); setH(h); };
      grip.onpointerup = grip.onpointercancel = function () { grip.onpointermove = grip.onpointerup = grip.onpointercancel = null; try { localStorage.setItem(CHAT_H, Math.round(h)); } catch (er) {} };
    };
    grip.onkeydown = function (e) {
      var m = logEl(), d = e.key === "ArrowDown" ? 24 : e.key === "ArrowUp" ? -24 : 0; if (!m || !d) return;
      e.preventDefault(); var h = clampH(m.offsetHeight + d); setH(h); try { localStorage.setItem(CHAT_H, Math.round(h)); } catch (er) {}
    };
  }
  window.LOOP_ITEM_CHAT = itemChat;
  addEventListener("resize", function () { try { syncFolds(); } catch (e) {} });
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(
    {page: "mode", icon: "sliders", draw: drawMode},
    {page: "screen", icon: "monitor", draw: drawScreen},
    {page: "views", icon: "list", draw: drawViews}
  );

  // Remember the last screen (for the "마지막 화면" start option) and honour the start choice on a
  // fresh open (an empty address bar).
  addEventListener("hashchange", function () { try { if (location.hash) localStorage.setItem(LAST, location.hash); } catch (e) {} });
  (function bootStart() {
    if (location.hash) return;
    var u = readLocal().ui || {};
    if (u.start === "mine") location.replace("#inbox");
    else if (u.start === "last") { var last; try { last = localStorage.getItem(LAST); } catch (e) {} if (last) location.replace(last); }
  })();

  // ---- Boot: apply the cache, then refresh from the server ---------------------------------
  var c = readLocal();
  if (c.ui) { ST.ui = c.ui; ST.work_mode = c.work_mode || "auto"; }
  get("/api/custom").then(function (r) {
    ST.ui = r.ui; ST.work_mode = r.work_mode; ST.identity = r.identity || {}; ST.auto_emoji = r.auto_emoji; ST.session_wait_notify = r.session_wait_notify === true; ST.result_in_chat = r.result_in_chat === true; ST.turn_off = r.turn_off || [];
    VIEWS = r.views || [];
    adoptLegacySide();
    applyUI(); cache(); try { drawChrome(); } catch (e) {}
    // A browser with no cache yet drew its first screen with the default unit word.
    var unitMoved = ((c.ui || {}).unit_name || "") !== (r.ui.unit_name || "");
    if (cur === "settings") redrawSettings();
    else if (unitMoved) { try { render(); } catch (e) {} }
    else if (cur === "lib" || cur === "inbox") viewsAfterRender();
  }).catch(function () {});
})();
