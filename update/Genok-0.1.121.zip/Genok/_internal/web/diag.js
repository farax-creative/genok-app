// 설정 → 문제 진단: save a local diagnostics zip (design v2 §9). It only writes a file on
// this PC and shows where it is; nothing is sent. Its own file + one LOOP_SETTINGS entry.
// Uses v2.js globals: tl, esc, ic, toast, post.
(function () {
  "use strict";

  function draw(c) {
    c.innerHTML = `<h2 class="seth">${tl("diag.title")}</h2>
      <p class="setd">${tl("diag.desc")}</p>
      <div class="card"><div style="padding:12px 14px">
        <div class="s" style="white-space:normal;color:var(--dim,#9aa0a6)">${tl("diag.contents")}</div>
        <div class="s" style="white-space:normal;color:var(--dim,#9aa0a6);margin-top:6px">${more1(tl("diag.redacted"), tl("diag.redacted.more"))}</div>
        <div class="diag-btns">
          <button class="btn fill press" id="diag-save">${tl("diag.save")}</button>
        </div>
        <div id="diag-out" class="diag-out" hidden></div>
      </div></div>`;

    const btn = c.querySelector("#diag-save");
    const out = c.querySelector("#diag-out");
    btn.onclick = async () => {
      btn.disabled = true; const label = btn.textContent; btn.textContent = tl("diag.saving");
      try {
        const r = await post("/api/diag/save", {});
        out.hidden = false;
        out.innerHTML = `<div class="diag-ok">${tl("diag.saved")}</div>
          <div class="diag-path">${esc(r.path || r.name || "")}</div>
          <div class="diag-btns">
            <button class="btn sm press" id="diag-reveal">${tl("diag.reveal")}</button>
            <button class="btn sm press" id="diag-copy">${tl("diag.copy")}</button>
          </div>`;
        out.querySelector("#diag-reveal").onclick = () => post("/api/diag/reveal", {}).catch((e) => toast(e.message));
        out.querySelector("#diag-copy").onclick = async () => {
          try { await navigator.clipboard.writeText(r.path || ""); toast(tl("diag.copied")); }
          catch { toast(r.path || ""); }
        };
      } catch (e) { toast(e.message || tl("diag.err")); }
      finally { btn.disabled = false; btn.textContent = label; }
    };
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "diag", icon: "steth", title: "diag.title", draw});

  // ------------------------------------------------------------ styles (own file, no v2.css edit)
  const css = `
  .diag-btns { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
  .diag-out { margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line, #2a2d33); }
  .diag-ok { font-size: 14px; font-weight: 600; }
  .diag-path { margin-top: 4px; font-size: 12px; color: var(--dim, #9aa0a6);
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace; overflow-wrap: anywhere; }`;
  const s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);
})();
