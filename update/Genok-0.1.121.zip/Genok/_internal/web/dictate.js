// Speaking into a text box: the browser's own speech recognition (no engine of ours). Words land in
// the box as they are heard and stay editable; nothing is sent until the person presses send.
// One piece for every box that takes a sentence: the chat's message box draws its own row
// (project.js) and calls listen(); every other box is in FIELDS below and gets the same three
// controls from attach() - the mic inside the box at its trailing edge, before send.
// Where the browser has none the button is not drawn at all. A window that has the API but no
// service behind it (the PC app) says so on the first try: remembered, the button goes.
(function () {
  "use strict";

  const SPEECH = lsGet("v2-mic-off") ? null : window.SpeechRecognition || window.webkitSpeechRecognition;

  // The boxes that take a sentence, by where the controls go: in a row that already ends in a
  // send button they sit before it; a box standing alone gets them over its own trailing edge.
  // Names, paths, searches and codes are one word and are left alone.
  const ROW = ".cbox > #cm, .vw .vcm input, .pj-all textarea, .sg-reply input, .fl-vf > .fl-vin";
  const ALONE = ".ask .anote, .nedta, .sbox #rj, .pj-ta2, .pj-q input[type=text], .sbox input.tin[data-t], #d-task, #r-task, #rt-text, #cvfvwhy, .pp-box textarea";

  const CSS = `
.pj-wave i,.dct-wave i{flex:none;width:3px;height:3px;border-radius:2px;background:var(--t1);opacity:.45;transition:height .12s ease-out,opacity .12s ease-out}
.pj-wave i.v,.dct-wave i.v{opacity:1}
.dct{flex:none;align-self:flex-end;display:inline-flex;align-items:center;gap:2px}
.dct button{flex:none;position:relative;width:34px;height:34px;padding:0;border:0;border-radius:8px;background:none;color:var(--t3);display:inline-flex;align-items:center;justify-content:center;transition:background-color .14s ease,color .14s ease}
.dct button svg{width:18px;height:18px}
@media(hover:hover){.dct button:hover{background:var(--btn);color:var(--t1)}}
.dct .dct-x,.dct-wave,.dct-mic .i+.i{display:none}
.dct-rec>.dct .dct-x{display:inline-flex}
.dct-rec>.dct button{border-radius:50%;background:var(--btn-hi);color:var(--t1)}
.dct-rec>.dct .dct-mic .i{display:none}.dct-rec>.dct .dct-mic .i+.i{display:block;width:14px;height:14px}
.dct-rec>.dct .dct-wave{display:flex;align-items:center;justify-content:flex-end;gap:3px;width:33px;height:34px;overflow:hidden}
.dct-f{position:relative;display:flex;flex-direction:column;padding-bottom:var(--dct-gap,0px)}
.dct-f>.dct{position:absolute;right:4px;top:0;bottom:var(--dct-gap,0px)}
.dct-f.dct-ta>.dct{right:8px;top:auto;bottom:calc(8px + var(--dct-gap,0px))}
.dct-f.dct-f>:is(input,textarea){padding-right:42px}
.dct-f.dct-f>textarea{padding-right:46px}
.dct-f.dct-f.dct-rec>input{padding-right:116px}
.dct-f.dct-f.dct-rec>textarea{padding-bottom:48px}
.pj-q .dct-f{max-width:480px}
.vw .vcm .dct{margin:0 4px}
.vw .vcm .dct button{color:rgba(255,255,255,.85)}
.vw .vcm.dct-rec .dct button{background:rgba(255,255,255,.16);color:#fff}
.vw .vcm .dct-wave i{background:#fff}
@media(pointer:coarse){
  .dct button{width:36px;height:36px}
  .dct button::after{content:"";position:absolute;inset:-4px}
  .dct-f.dct-f>input{padding-right:46px}
  .dct-f.dct-f>textarea{padding-right:50px}
  .dct-f.dct-f.dct-rec>input{padding-right:122px}
}
@media(prefers-reduced-motion:reduce){.pj-wave i,.dct-wave i,.dct button{transition:none}}`;

  // While it listens the box shows its own row (.pj-rec / .dct-rec): X takes the spoken words away
  // again, stop keeps them in the box, send sends them. The level beside them is drawn from when
  // words arrive (bars) and when none do (dots); the browser gives recognition no loudness to draw.
  let hearing = null;
  const WAVE_N = 30, WAVE_MS = 110;
  // box: what carries the listening class; loose: a box whose send is not ours to hook - it stops
  // listening as soon as anything but the words heard changes the box (sent, cleared, typed in).
  function listen(ta, btn, box, rec, loose) {
    if (hearing) { const same = hearing.btn === btn; hearing.stop(); if (same) return; }
    const wave = box.querySelector(".pj-wave,.dct-wave");
    const r = new SPEECH(), before = ta.value, base = before ? before.replace(/\s*$/, " ") : "";
    let said = "", last = null, open = true, heardAt = 0, timer = 0;
    const sync = () => ta.dispatchEvent(new Event("input", {bubbles: true}));
    // After stop the last words may still arrive: they land only if the box was not touched since.
    const put = (t) => { if (!open || ((!me.on || loose) && ta.value !== last)) return; ta.value = last = base + t; sync(); };
    const off = () => { if (!me.on) return; me.on = false; if (hearing === me) hearing = null; clearInterval(timer);
      box.classList.remove(rec); btn.setAttribute("aria-pressed", "false"); btn.setAttribute("aria-label", tl("pj.mic")); btn.title = tl("pj.mic"); sync(); };
    const me = {on: false, btn,
      stop() { off(); try { r.stop(); } catch (e) {} },
      cut() { open = false; off(); try { r.abort(); } catch (e) {} },
      drop() { open = false; ta.value = before; off(); try { r.abort(); } catch (e) {} ta.focus({preventScroll: true}); }};
    r.lang = LANG() === "ko" ? "ko-KR" : "en-US"; r.continuous = true; r.interimResults = true;
    r.onresult = (e) => { let now = "";
      for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) said += t; else now += t; }
      heardAt = Date.now(); put(said + now); };
    r.onerror = (e) => { off(); if (e.error === "network" || e.error === "service-not-allowed") { lsSet("v2-mic-off", "1"); btn.hidden = true; }
      if (e.error !== "aborted" && e.error !== "no-speech") toast(e.error === "not-allowed" || e.error === "service-not-allowed" ? tl("pj.mic.denied") : tl("pj.mic.fail")); };
    r.onend = () => { off(); open = false; };
    try { r.start(); } catch (e) { toast(tl("pj.mic.fail")); return; }
    hearing = me; me.on = true; last = ta.value;
    wave.innerHTML = "<i></i>".repeat(WAVE_N);
    const bars = [...wave.children], lv = bars.map(() => 0);
    timer = setInterval(() => {
      if (!ta.isConnected || (loose && ta.value !== last)) { me.cut(); return; }   // drawn again under it, or sent
      lv.shift(); lv.push(Date.now() - heardAt < 420 ? 0.3 + Math.random() * 0.7 : 0);
      bars.forEach((b, i) => { b.style.height = lv[i] ? Math.round(6 + lv[i] * 18) + "px" : ""; b.classList.toggle("v", !!lv[i]); });
    }, WAVE_MS);
    box.classList.add(rec); btn.setAttribute("aria-pressed", "true"); btn.setAttribute("aria-label", tl("pj.mic.stop")); btn.title = tl("pj.mic.stop");
  }

  const done = new WeakSet();
  function attach(ta, row) {
    if (done.has(ta)) return;
    done.add(ta);
    const dct = document.createElement("span");
    dct.className = "dct";
    dct.innerHTML = `<button type="button" class="dct-x press" aria-label="${tl("pj.mic.drop")}" title="${tl("pj.mic.drop")}">${ic("x")}</button><span class="dct-wave" aria-hidden="true"></span>
      <button type="button" class="dct-mic press" aria-pressed="false" aria-label="${tl("pj.mic")}" title="${tl("pj.mic")}">${ic("mic")}${ic("stopfill")}</button>`;
    if (row) {
      ta.after(dct);
      // The row lines up on its send button, whatever height the screen gives that.
      const send = dct.nextElementSibling;
      if (send) new ResizeObserver(() => { if (send.offsetHeight) dct.style.height = send.offsetHeight + "px"; }).observe(send);
    } else {
      // The box moves into a holder of its own size; a caret already in it stays where it was.
      const f = document.createElement("span"), cs = getComputedStyle(ta), sel = document.activeElement === ta ? [ta.selectionStart, ta.selectionEnd] : null;
      const up = ta.parentNode, h = up.getBoundingClientRect().height;
      f.className = ta.tagName === "TEXTAREA" ? "dct-f dct-ta" : "dct-f";
      f.style.margin = cs.margin;
      ta.before(f); ta.style.margin = "0"; f.append(ta, dct);
      // A box that stood on a text line had the line's few pixels under it: they stay.
      const gap = h - up.getBoundingClientRect().height;
      if (gap > 0) f.style.setProperty("--dct-gap", gap + "px");
      if (sel) { ta.focus({preventScroll: true}); ta.setSelectionRange(sel[0], sel[1]); }
    }
    const box = dct.parentNode, mic = dct.querySelector(".dct-mic");
    mic.onclick = () => listen(ta, mic, box, "dct-rec", true);
    dct.querySelector(".dct-x").onclick = () => { if (hearing) hearing.drop(); };
    // Esc while it listens takes the words away, as in the chat; it does not also close the box.
    ta.addEventListener("keydown", (e) => { if (e.key === "Escape" && hearing && hearing.btn === mic) { e.preventDefault(); e.stopImmediatePropagation(); hearing.drop(); } }, true);
  }

  const scan = (root) => {
    if (root.matches(ROW)) attach(root, true); else if (root.matches(ALONE)) attach(root, false);
    root.querySelectorAll(ROW).forEach((n) => attach(n, true));
    root.querySelectorAll(ALONE).forEach((n) => attach(n, false));
  };

  window.Dictate = {SPEECH, listen,
    cut() { if (hearing) hearing.cut(); },
    drop() { if (hearing) hearing.drop(); },
    on: () => !!hearing};

  const s = document.createElement("style");
  s.id = "dct-css";
  s.textContent = CSS;
  document.head.appendChild(s);
  if (!SPEECH) return;
  scan(document.body);
  new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) scan(n); })
    .observe(document.body, {childList: true, subtree: true});
})();
