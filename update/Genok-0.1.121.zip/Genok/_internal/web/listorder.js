// The chat list's order (web/project.js draws the list, web/split.js owns the drag gesture).
// The list never reorders itself: rows stand where the person put them, and whatever was made
// after that stacks on top of them, the newest first. This file owns that rule and the
// arithmetic of making room while a row is dragged; tested in tests/listorder.test.js.
(function () {
  "use strict";

  // `rows` in their fixed order: the ones never placed stack on top by creation time, the newest
  // first (a new one lands on top and stays there); then the placed ones (`placed`, a list of
  // keys) as given; a row never placed with no creation time goes last. Ties keep the order they
  // came in. The server's rooms.placed is the same rule.
  function arrange(rows, placed, keyOf, bornOf) {
    const at = new Map(); (placed || []).forEach((k, i) => { if (!at.has(k)) at.set(k, i); });
    return rows.map((r, i) => { const k = keyOf(r), b = String(bornOf(r) || ""); return [r, at.has(k) ? 1 : b ? 0 : 2, at.has(k) ? at.get(k) : 0, b, i]; })
      .sort((a, b) => a[1] - b[1] || a[2] - b[2] || (a[1] === 0 ? (a[3] > b[3] ? -1 : a[3] < b[3] ? 1 : 0) : 0) || a[4] - b[4]).map((p) => p[0]);
  }

  // `keys` with `key` taken out and put right before `ref` (right after it with `after`).
  // A `ref` that is not there (or is the key itself) leaves the order as it was.
  function moved(keys, key, ref, after) {
    if (ref === key || !keys.includes(ref) || !keys.includes(key)) return keys.slice();
    const L = keys.filter((k) => k !== key);
    L.splice(L.indexOf(ref) + (after ? 1 : 0), 0, key);
    return L;
  }

  // Several keys moved at once: `ids` (those of them in `order`, kept in the order they stand in
  // there, whatever order they were named in) are taken out and put together at `at`, a position
  // in the list as it was: right before order[at] (`at` 0 is the very top, order.length the very
  // bottom). A position inside the moved block counts as the block's own place. The others keep
  // their order.
  function movedMany(order, ids, at) {
    const set = new Set(ids), group = order.filter((k) => set.has(k));
    if (!group.length) return order.slice();
    const a = Math.max(0, Math.min(order.length, Math.trunc(at) || 0));
    const rest = order.filter((k) => !set.has(k)), n = order.slice(0, a).filter((k) => !set.has(k)).length;
    rest.splice(n, 0, ...group);
    return rest;
  }

  // Where a dragged unit would land: `mids` are the middles of every unit as they lay when the
  // drag began (the dragged one at `from`), `y` the middle of the dragged copy. It passes a
  // neighbour when its middle crosses the neighbour's.
  function slot(mids, y, from) {
    let to = 0;
    mids.forEach((m, i) => { if (i !== from && m < y) to++; });
    return to;
  }

  // How far each unit moves to make room: `sizes` are the units' pitches (top to next top),
  // the unit at `from` goes to index `to`. The ones it jumps over move by its size the other
  // way; it moves by the sum of theirs.
  function shifts(sizes, from, to) {
    const out = sizes.map(() => 0);
    if (to > from) { for (let j = from + 1; j <= to; j++) { out[j] = -sizes[from]; out[from] += sizes[j]; } }
    else { for (let j = to; j < from; j++) { out[j] = sizes[from]; out[from] -= sizes[j]; } }
    return out;
  }

  // The scroll speed (px per frame) near the top or bottom edge of the list, 0 away from them.
  function edge(y, top, bottom, zone, max) {
    if (y < top + zone) return -Math.ceil(max * Math.min(1, (top + zone - y) / zone));
    if (y > bottom - zone) return Math.ceil(max * Math.min(1, (y - (bottom - zone)) / zone));
    return 0;
  }

  // The strip of the screen a dragged row can be dropped in and that scrolls near its edges, for a
  // list that scrolls with the page (a phone): the visible window less what stands over it (the
  // sticky top bar, the tab bar). `over` are the {top, bottom} the bars cover, in px of the window.
  function window_(innerW, innerH, over) {
    const top = Math.max(0, (over && over.top) || 0), bottom = Math.min(innerH, (over && over.bottom) == null ? innerH : over.bottom);
    return {left: 0, right: innerW, top, bottom: Math.max(top, bottom)};
  }

  const api = {arrange, moved, movedMany, moveMany: movedMany, slot, shifts, edge, window: window_};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;

  // ---- making room in the page ------------------------------------------------------------------
  // start(o): o = {units, unit, box} - the rows (or project groups) that can trade places, the one
  // that was picked up, the list that scrolls. `fold`: rows carried along with it (several picked
  // at once); they leave the list while it is in the hand, the rest slide up into the room. move() follows the dragged copy; drop() says where
  // the copy should settle; done() puts the page back and reports where it landed.
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  let cur = null, waiting = [];
  function css() {
    if (document.getElementById("pj-ord-css")) return;
    const s = document.createElement("style"); s.id = "pj-ord-css";
    s.textContent = `.ord-u{transition:transform var(--m-snap-d,320ms) var(--m-snap,cubic-bezier(.2,.9,.25,1));will-change:transform}
      .ord-src.ord-src.ord-src{opacity:1;position:relative}.ord-src>*{visibility:hidden!important}
      .ord-src::after{content:"";position:absolute;inset:1px;border-radius:var(--r-md,10px);pointer-events:none;
        background:color-mix(in srgb,var(--blue) 10%,transparent);box-shadow:inset 0 0 0 1.5px color-mix(in srgb,var(--blue) 62%,transparent)}
      .ord-fold{display:none!important}
      .ord-on{touch-action:none}
      @media (prefers-reduced-motion:reduce){.ord-u{transition:none}}`;
    document.head.appendChild(s);
  }
  function start(o) {
    const units = o.units, from = units.indexOf(o.unit);
    if (from < 0 || units.length < 2) return null;
    css();
    // `scroller`: what scrolls while the row is carried (the list itself, or the page on a phone).
    const sc = o.scroller || o.box, fold = (o.fold || []).filter((u) => !units.includes(u)), was = fold.length ? units.map((u) => u.getBoundingClientRect().top) : null;
    fold.forEach((u) => u.classList.add("ord-fold"));
    const sy = sc.scrollTop, rects = units.map((u) => u.getBoundingClientRect());
    const tops = rects.map((r) => r.top + sy);
    const sizes = rects.map((r, i) => i + 1 < rects.length ? tops[i + 1] - tops[i] : r.height);
    const st = {units, from, to: from, box: o.box, sc, over: o.over || null, tops, sizes, mids: rects.map((r, i) => tops[i] + r.height / 2), left: rects[from].left, fold, raf: 0, last: null, dead: false};
    units.forEach((u) => u.classList.add("ord-u")); o.unit.classList.add("ord-src"); o.box.classList.add("ord-on");
    // The rows slid up into the room the carried ones left: they start where they were and settle.
    if (was && !RM()) {
      units.forEach((u, i) => { const d = was[i] - rects[i].top; if (d) { u.style.transition = "none"; u.style.transform = `translateY(${d}px)`; } });
      void o.box.offsetHeight;
      units.forEach((u) => { u.style.transition = ""; u.style.transform = ""; });
    }
    cur = st;
    return st;
  }
  function put(st, to) {
    if (to === st.to) return;
    st.to = to;
    shifts(st.sizes, st.from, to).forEach((d, i) => { st.units[i].style.transform = d ? `translateY(${d}px)` : ""; });
  }
  // Where a carried row may go and the scroll starts: the list's own box, or on a phone the window.
  function area(st) {
    if (st.sc !== document.scrollingElement) return st.box.getBoundingClientRect();
    const o = st.over && st.over(); return window_(innerWidth, innerHeight, o);
  }
  // x, y: the pointer; gy, gh: the dragged copy's top and height.
  function move(st, x, y, gy, gh) {
    if (st.dead) return;
    st.last = [x, y, gy, gh];
    const b = area(st), inside = x >= b.left - 24 && x <= b.right + 24 && y >= b.top - 40 && y <= b.bottom + 40;
    put(st, inside ? slot(st.mids, gy + gh / 2 + st.sc.scrollTop, st.from) : st.from);
    const v = inside ? edge(y, b.top, b.bottom, 44, 14) : 0;
    if (v && !st.raf) {
      const tick = () => {
        st.raf = 0; if (st.dead || !st.last) return;
        const bb = area(st), vv = edge(st.last[1], bb.top, bb.bottom, 44, 14), was = st.sc.scrollTop;
        if (!vv) return;
        st.sc.scrollTop = was + vv;
        if (st.sc.scrollTop === was) return;        // the end of the list
        move(st, st.last[0], st.last[1], st.last[2], st.last[3]);
        if (!st.raf) st.raf = requestAnimationFrame(tick);
      };
      st.raf = requestAnimationFrame(tick);
    }
  }
  // Let go (`ok`) or given up: where the dragged copy settles, as a point on the screen.
  function drop(st, ok) {
    st.last = null; if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
    if (!ok) put(st, st.from);
    const d = shifts(st.sizes, st.from, st.to)[st.from];
    return {left: st.left, top: st.tops[st.from] - st.sc.scrollTop + d};
  }
  // The copy has settled: the page is as it was, and {from, to} says what changed (null: nothing).
  function done(st) {
    if (st.dead) return null;
    st.dead = true; if (st.raf) cancelAnimationFrame(st.raf);
    st.fold.forEach((u) => u.classList.remove("ord-fold"));
    st.units.forEach((u) => { u.style.transition = "none"; u.style.transform = ""; u.classList.remove("ord-u", "ord-src"); });
    st.box.classList.remove("ord-on");
    requestAnimationFrame(() => st.units.forEach((u) => { u.style.transition = ""; }));
    if (cur === st) cur = null;
    const w = waiting; waiting = [];
    const res = st.to !== st.from ? {from: st.from, to: st.to} : null;
    setTimeout(() => w.forEach((f) => f()), 0);
    return res;
  }
  // A redraw of the list waits for the row in the hand to land.
  const live = () => !!cur;
  const later = (f) => { if (waiting.length < 4) waiting.push(f); };

  window.PjOrder = Object.assign(api, {start, move, drop, done, live, later, RM});
})();
