// 설정 → 허브에서 가져오기 (design v2 §11, served by migrate.py). The person points the app
// at their existing review-hub folder (D:\ReviewHub). The import is in place: the app is
// simply pointed at the folder, nothing inside it is moved or rewritten. This page scans a
// chosen folder, shows what it holds, and does the import. Callable-object settings section,
// like backup.js / connect.js.
(function () {
  "use strict";

  const val = (el) => (el.querySelector("#mgfolder").value || "").trim();

  // The hidden session project (_세션) is counted apart, the same way in the preview and the check.
  function hiddenNote(c) {
    return c.hidden_items
      ? `<div class="s" style="margin:-4px 4px 8px">${tl("migrate.hidden", {i: c.hidden_items, v: c.hidden_versions})}</div>` : "";
  }

  function counts(c) {
    return `<div class="s" style="margin:2px 4px 8px">`
      + tl("migrate.counts", {p: c.projects, i: c.items, v: c.versions, o: c.open_directives})
      + (c.aliases ? ` · ${tl("migrate.aliases", {n: c.aliases})}` : "")
      + `</div>`
      + hiddenNote(c)
      + (c.sample && c.sample.length
        ? `<div class="chips">${c.sample.map((s) => `<span class="chip">${esc(s.name)} <em class="num">${s.items}</em></span>`).join("")}</div>`
        : "");
  }

  async function scan(el, folder) {
    const box = el.querySelector("#mgresult");
    box.innerHTML = `<div class="s" style="margin:8px 4px">…</div>`;
    let r;
    try { r = await fetch("/api/migrate?folder=" + encodeURIComponent(folder)).then((x) => x.json()); }
    catch { box.innerHTML = `<div class="s" style="margin:8px 4px">${tl("migrate.err")}</div>`; return; }
    const c = r.chosen || {};
    if (!c.found) { box.innerHTML = `<div class="s" style="margin:8px 4px">${tl("migrate.notfound")}</div>`; return; }
    if (!c.compatible) { box.innerHTML = `<div class="s" style="margin:8px 4px">${tl("migrate.incompatible")}</div>`; return; }
    box.innerHTML = counts(c)
      + `<div class="s" style="margin:2px 4px 10px">${tl("migrate.inplace")}</div>`
      + `<button class="btn fill press" id="mgimport">${tl("migrate.import")}</button>`;
    box.querySelector("#mgimport").onclick = async (e) => {
      e.currentTarget.disabled = true;
      try { const done = await post("/api/migrate", {folder});
        toast(tl("migrate.done", {n: done.items})); setTimeout(() => location.reload(), 700); }
      catch (err) { toast(err.message); e.currentTarget.disabled = false; }
    };
  }

  async function draw(el) {
    let now = "";
    try { now = (await fetch("/api/migrate").then((r) => r.json())).current || ""; } catch {}
    const hasPicker = !!(window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder);
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="sec" style="padding-top:0">${tl("migrate.title")}</div>
      <div class="s" style="margin:-4px 4px 10px">${tl("migrate.desc")}</div>`
      + (now ? `<div class="row"><span class="tx"><div class="t" style="font-size:16px">${tl("migrate.current")}</div><div class="s" style="white-space:normal;overflow-wrap:anywhere">${esc(now)}</div></span></div>` : "")
      + `<label class="fld"><span class="s">${tl("migrate.folder")}</span>
          <input class="in" id="mgfolder" type="text" placeholder="${tl("migrate.folder.ph")}" spellcheck="false" autocomplete="off"></label>
        <div class="fldacts">${hasPicker ? `<button class="btn press" id="mgpick">${tl("onboard.pick")}</button>` : ""}<button class="btn press" id="mgscan">${tl("migrate.preview")}</button></div>
        <div id="mgresult"></div><div style="height:6px"></div>`;
    el.appendChild(card);
    const run = () => { const f = val(el); if (f) scan(el, f); };
    card.querySelector("#mgscan").onclick = run;
    // Nothing to preview without a folder: the button is off and says why, not silently dead.
    const need = () => { const b = card.querySelector("#mgscan"), on = !!val(el);
      b.disabled = !on; b.style.opacity = on ? "" : ".4"; b.title = on ? "" : tl("migrate.preview.need"); };
    card.querySelector("#mgfolder").addEventListener("input", need); need();
    const pk = card.querySelector("#mgpick");
    if (pk) pk.onclick = async () => {
      try { const f = await window.pywebview.api.pick_folder(); if (f) { card.querySelector("#mgfolder").value = f; need(); run(); } } catch (e) {}
    };
    card.querySelector("#mgfolder").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); run(); } });
    drawCheck(el, () => val(el) || now);
    drawRegistry(el);
  }

  // ---- relation check (read-only dry run; report saved outside the data folder)
  function checkLabel(key) {
    // One literal tl call per check: tests/test_i18n.py only sees literal keys.
    switch (key) {
      case "comment_version": return tl("migrate.ck.comment");
      case "fixed_in": return tl("migrate.ck.fixed");
      case "locations": return tl("migrate.ck.locations");
      case "status_target": return tl("migrate.ck.status");
      case "pending": return tl("migrate.ck.pending");
      case "aliases": return tl("migrate.ck.aliases");
      case "sessions": return tl("migrate.ck.sessions");
      case "places": return tl("migrate.ck.places");
      case "files": return tl("migrate.ck.files");
      case "locks": return tl("migrate.ck.locks");
      case "broken_json": return tl("migrate.ck.broken");
      case "preparing": return tl("migrate.ck.preparing");
      case "places_unregistered": return tl("migrate.ck.unregistered");
      case "no_agent": return tl("migrate.ck.noagent");
      case "external_links": return tl("migrate.ck.external");
      default: return key;
    }
  }

  const wrapStyle = "margin:2px 4px 0;font-size:13px;color:var(--t3);overflow-wrap:anywhere";

  function checkRows(r) {
    return r.checks.map((c) => {
      const tone = !c.bad ? "approved" : c.level === "bad" ? "stuck" : "";
      const ex = c.bad && c.examples.length
        ? `<div style="${wrapStyle}">${c.examples.map((x) => esc(String(x))).join("<br>")}</div>` : "";
      const note = !c.bad ? ""
        : c.key === "preparing" ? `<div style="${wrapStyle}">${tl("migrate.ck.preparing.note")}</div>`
        : c.key === "places_unregistered" ? `<div style="${wrapStyle}">${tl("migrate.ck.unregistered.note")}</div>` : "";
      return `<div style="padding:8px 4px;border-top:1px solid var(--line, rgba(127,127,127,.15))">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="flex:1;min-width:0;font-size:15px">${esc(checkLabel(c.key))}</span>
          <span class="tag ${tone}">${tl("migrate.ck.count", {bad: c.bad, total: c.total})}</span></div>${ex}${note}</div>`;
    }).join("");
  }

  function drawCheck(el, folderOf) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="sec" style="padding-top:0">${tl("migrate.ck.title")}</div>
      <div class="s" style="margin:-4px 4px 10px">${tl("migrate.ck.desc")}</div>
      <div class="fldacts"><button class="btn press" id="mgcheck">${tl("migrate.ck.run")}</button></div>
      <div id="mgckres"></div><div style="height:6px"></div>`;
    el.appendChild(card);
    const box = card.querySelector("#mgckres");
    card.querySelector("#mgcheck").onclick = async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      box.innerHTML = loadingHtml("");
      try {
        const reg = (el.querySelector("#mgreg") || {}).value || "";
        const r = await post("/api/migrate", {action: "check", folder: folderOf(), registry: reg.trim()});
        const c = r.counts;
        box.innerHTML = `<div class="t" style="margin:8px 4px 2px;font-size:16px;font-weight:600">${
            r.ok ? tl("migrate.ck.ok") : tl("migrate.ck.broken.n", {n: r.bad})}</div>
          <div class="s" style="margin:0 4px 8px">${tl("migrate.ck.counts", {p: c.projects, i: c.items, v: c.versions, e: c.entries})}</div>`
          + hiddenNote(c)
          + checkRows(r)
          + (r.files ? `<div style="${wrapStyle};margin-top:10px">${tl("migrate.ck.saved", {path: esc(r.files.html)})}</div>` : "");
      } catch (err) {
        box.innerHTML = `<div class="s" style="margin:8px 4px">${esc(err.message || tl("migrate.err"))}</div>`;
      }
      btn.disabled = false;
    };
  }

  // ---- DEPARTMENTS.md import (preview first; apply only after the person presses it)
  function regPreview(p) {
    const byGroup = new Map();
    for (const d of p.add) { if (!byGroup.has(d.group)) byGroup.set(d.group, []); byGroup.get(d.group).push(d); }
    const groups = [...byGroup].map(([g, ds]) => `<details style="margin:2px 4px;padding:6px 0">
        <summary style="cursor:pointer;font-size:15px">${esc(g || "—")} <em class="num" style="font-style:normal;color:var(--t3)">${ds.length}</em>${
          ds.some((d) => d.archived) ? ` <span class="tag">${tl("migrate.reg.archived")}</span>` : ""}</summary>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">${ds.map((d) =>
          `<span class="tag" title="${esc(d.folder)}">${esc(d.num + " " + (d.icon ? d.icon + " " : "") + d.name)}</span>`).join("")}</div></details>`).join("");
    const skipped = p.skip.length
      ? `<div style="${wrapStyle}">${tl("migrate.reg.skipped", {names: esc(p.skip.slice(0, 3).map((d) => d.name).join(", "))})}</div>` : "";
    return `<div class="s" style="margin:8px 4px 6px">${tl("migrate.reg.counts", {g: p.groups.length, d: p.total, a: p.add.length, s: p.skip.length})}</div>`
      + (p.numbers_kept ? "" : `<div style="${wrapStyle};margin-bottom:6px">${tl("migrate.reg.renumber")}</div>`)
      + groups + skipped
      + (p.add.length ? `<div style="height:10px"></div><button class="btn fill press" id="mgregapply">${tl("migrate.reg.apply", {n: p.add.length})}</button>`
        : `<div class="s" style="margin:8px 4px">${tl("migrate.reg.nothing")}</div>`);
  }

  async function drawRegistry(el) {
    let def = "";
    try { def = (await fetch("/api/migrate").then((r) => r.json())).departments_md || ""; } catch {}
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="sec" style="padding-top:0">${tl("migrate.reg.title")}</div>
      <div class="s" style="margin:-4px 4px 10px">${tl("migrate.reg.desc")}</div>
      <label class="fld"><span class="s">${tl("migrate.reg.file")}</span>
        <input class="in" id="mgreg" type="text" placeholder="${tl("migrate.reg.file.ph")}" spellcheck="false" autocomplete="off"></label>
      <div class="fldacts"><button class="btn press" id="mgregprev">${tl("migrate.preview")}</button></div>
      <div id="mgregres"></div><div style="height:6px"></div>`;
    el.appendChild(card);
    const input = card.querySelector("#mgreg");
    input.value = def;
    const box = card.querySelector("#mgregres");
    const preview = async () => {
      const path = input.value.trim();
      box.innerHTML = loadingHtml("");
      let r;
      try { r = await fetch("/api/migrate?registry=" + encodeURIComponent(path)).then((x) => x.json()); }
      catch { box.innerHTML = `<div class="s" style="margin:8px 4px">${tl("migrate.err")}</div>`; return; }
      if (!r.registry) { box.innerHTML = `<div class="s" style="margin:8px 4px">${esc(r.error || tl("migrate.reg.notfound"))}</div>`; return; }
      const p = r.registry;
      box.innerHTML = regPreview(p);
      const ap = box.querySelector("#mgregapply");
      if (ap) ap.onclick = async (e) => {
        e.currentTarget.disabled = true;
        try {
          const done = await post("/api/migrate", {action: "registry", registry: p.source, digest: p.digest});
          toast(tl("migrate.reg.done", {n: done.added}));
          preview();
        } catch (err) { toast(err.message); e.currentTarget.disabled = false; }
      };
    };
    card.querySelector("#mgregprev").onclick = preview;
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); preview(); } });
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(
    Object.assign(draw, {page: "migrate", icon: "import", title: tl("migrate.title")}));
})();
