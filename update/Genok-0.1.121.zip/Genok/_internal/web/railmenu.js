// Right click (a long press on touch, Shift F10 or the menu key on a focused row) on the side
// menu and on the cards of the results: the same menu the chat list's rows have (project.js popAt:
// its look, its keys, its place at the pointer), with real choices that call what the buttons on
// those rows already call. Text, fields and links keep whatever a right click did there.
// The pure part, which surface a target is, is tested in tests/railmenu.test.js.
(function () {
  "use strict";

  // Which surface a target belongs to, most specific first. `has(sel)` is target.closest.
  function kind(has) {
    if (has("input,textarea,select,[contenteditable],a[href],.pj-pop,#fl,gk-select")) return "";
    if (has("[data-dept]")) return "dept";
    if (has("[data-item]")) return "item";
    if (has("#rail .it[data-go]")) return "nav";
    if (has("#rail")) return "rail";
    return "";
  }

  const api = {kind};
  if (typeof module !== "undefined" && module.exports) { module.exports = api; return; }
  window.RailMenu = api;

  const q = (s, r) => (r || document).querySelector(s);
  let down = 0, hold = 0, xy = null, held = 0;

  const btn = (a, icon, text, k, cls) => `<button data-a="${a}"${cls ? ` class="${cls}"` : ""}${k ? ` data-k="${k}" aria-keyshortcuts="${k}"` : ""}>${ic(icon)}<span>${esc(text)}</span>${k ? `<kbd aria-hidden="true">${k}</kbd>` : ""}</button>`;
  const newChat = (name) => typeof window.LOOP_NEW_CHAT === "function" ? window.LOOP_NEW_CHAT(name) : nav("project" + (name ? "/" + encodeURIComponent(name) : ""));
  const hasChat = () => typeof extTabs === "function" && extTabs().some((t) => t.id === "project");

  // What each surface offers: [html, run(action)]. Nothing here is a copy of a feature: every
  // action is the function the row's own button or the screen's own control calls.
  function build(k, el) {
    if (k === "dept") {
      const name = el.dataset.dept, pinned = isPinned(name), arch = isArch(name);
      return {label: tl("room.deptMenu"), html: btn("open", "folder", tl("rc.results"), "O")
        + (hasChat() ? btn("chats", "chat", tl("rc.chats"), "C") + btn("new", "plus", tl("mn.new"), "N") : "")
        + `<hr>` + btn("pin", "star", pinned ? tl("pinBtn.1") : tl("pinBtn.2"), "P")
        + (typeof window.pjIconOf === "function" ? btn("icon", "pen", tl("mn.icon"), "I") : "")
        + btn("arch", "archive", arch ? tl("archBtn.1") : tl("archBtn.2"), "A"),
        run: {open: () => nav("dept/" + name), chats: () => nav("project/" + encodeURIComponent(name)), new: () => newChat(name),
          pin: () => togglePin(name), icon: () => window.pjIconOf(el, name), arch: () => toggleArchive(name)}};
    }
    if (k === "item") {
      const key = el.closest("[data-item]").dataset.item, x = (D.items || []).find((i) => iid(i) === key), card = el.closest(".gw");
      const acts = card ? [...card.querySelectorAll("[data-ga]")] : [];
      return {label: tl("rc.item"), html: btn("open", "play", tl("rc.open"), "O") + (x ? btn("dept", "folder", tl("rc.deptOpen"), "D") : "")
        + (acts.length ? `<hr>` + acts.map((b, i) => btn("ga" + i, GACT_IC[b.dataset.ga] || "check", b.getAttribute("aria-label") || b.textContent.trim(), b.dataset.ga === "ok" ? "A" : "", b.dataset.ga === "off" ? "dz" : "")).join("") : ""),
        run: Object.assign({open: () => nav("item/" + key), dept: () => x && nav("dept/" + gname(x))}, ...acts.map((b, i) => ({["ga" + i]: () => b.isConnected && b.click()})))};
    }
    if (k === "nav") {
      const key = el.dataset.key, can = key && !("fixed" in el.dataset) && key !== FAV_LOCK;
      return {label: tl("rc.nav"), html: btn("open", "play", tl("rc.open"), "O")
        + (can ? btn("fav", "star", isFav(key) ? tl("favBtn.1") : tl("favBtn.2"), "F") : ""),
        run: {open: () => el.click(), fav: () => toggleFav(key)}};
    }
    if (k === "rail") {
      const s = railState();
      return {label: tl("rc.rail"), html: (s === "icons" ? btn("full", "sidebar", tl("ui.tb.railFull"), "F") : btn("icons", "sidebar", tl("ui.tb.railIcons"), "I"))
        + btn("off", "minus", tl("rc.railHide"), "H"),
        run: {full: () => setRail("full"), icons: () => setRail("icons"), off: () => setRail("off")}};
    }
    return null;
  }

  // Opens the menu for the surface under `t` at (x, y); false when there is none.
  function open(t, x, y, kb) {
    const k = kind((s) => t.closest(s)); if (!k || typeof window.pjPopAt !== "function") return false;
    const el = k === "dept" ? t.closest("[data-dept]") : k === "item" ? t.closest("[data-item]") : k === "nav" ? t.closest("#rail .it[data-go]") : q("#rail");
    const m = build(k, el); if (!m) return false;
    if (kb && k !== "rail") { const b = el.getBoundingClientRect(); x = b.left + Math.min(40, b.width / 2); y = b.bottom - 6; }
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm"; pop.innerHTML = m.html;
    const off = window.pjPopAt(pop, el, {x, y, row: el, kb, label: m.label});
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); off(); const f = m.run[b.dataset.a]; if (f) f(); });
    return true;
  }

  api.open = open;
  document.addEventListener("pointerdown", (e) => {
    down = performance.now(); clearTimeout(hold); xy = null;
    if (e.pointerType === "mouse" || !e.target.closest || ["", "rail", "item"].includes(kind((s) => e.target.closest(s)))) return;   // a result card's own hold selects it (v2.js)
    const t = e.target, x = e.clientX, y = e.clientY; xy = [x, y];
    // Held without moving: the menu, at the finger. The lift that ends the hold is not a press.
    hold = setTimeout(() => { xy = null; const at = t.isConnected ? t : document.elementFromPoint(x, y);   // a picture that loaded meanwhile was swapped out
      if (at && open(at, x, y, false)) { held = performance.now(); if (navigator.vibrate) navigator.vibrate(12); } }, 520);
  }, true);
  document.addEventListener("pointermove", (e) => { if (xy && Math.hypot(e.clientX - xy[0], e.clientY - xy[1]) > 8) { clearTimeout(hold); xy = null; } }, true);
  ["pointerup", "pointercancel"].forEach((n) => document.addEventListener(n, () => { clearTimeout(hold); xy = null; }, true));
  document.addEventListener("click", (e) => { if (held && performance.now() - held < 1200 && !e.target.closest(".pj-pop")) { held = 0; e.preventDefault(); e.stopPropagation(); } }, true);
  document.addEventListener("contextmenu", (e) => {
    const t = e.target, k = t.closest && kind((s) => t.closest(s)); if (!k) return;
    if (k === "item" && matchMedia("(pointer:coarse)").matches) return;   // a touch screen's hold on a card selects it
    const sel = getSelection(); if (sel && !sel.isCollapsed && t.closest("[data-dept],[data-item],#rail") && t.closest("[data-dept],[data-item],#rail").contains(sel.anchorNode)) return;   // marked text: copy stays
    if (document.body.classList.contains("sorting") || q("#rail .sorting")) return e.preventDefault();
    if (held && performance.now() - held < 1200) return e.preventDefault();   // the hold already answered
    clearTimeout(hold); xy = null;
    const kb = performance.now() - down > 700 && !!document.activeElement && !!t.closest("[data-dept],[data-item],#rail .it") && t.closest("[data-dept],[data-item],#rail .it").contains(document.activeElement);
    if (open(t, e.clientX, e.clientY, kb)) { e.preventDefault(); if (e.pointerType === "touch") held = performance.now(); }
  });
})();
