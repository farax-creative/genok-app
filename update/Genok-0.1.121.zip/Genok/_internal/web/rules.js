// 설정 → 올리기 규칙: turn each push guard/lint on or off (design §3.2, served by rules.py).
// Registered as a callable object so it works both as today's draw-function and as a future
// settings page: LOOP_SETTINGS entries are called with the #ext-settings div.
(function () {
  "use strict";

  // [key, title, description]. Literal tl() calls so tests/test_i18n.py can see each key.
  const rows = () => [
    ["open_directives", tl("rules.open_directives"), tl("rules.open_directives.d")],
    ["summary", tl("rules.summary"), tl("rules.summary.d")],
    ["text_only", tl("rules.text_only"), tl("rules.text_only.d")],
    ["layout", tl("rules.layout"), tl("rules.layout.d")],
    ["numbered_choices", tl("rules.numbered_choices"), tl("rules.numbered_choices.d")],
    ["preview_video", tl("rules.preview_video"), tl("rules.preview_video.d")],
    ["long_note", tl("rules.long_note"), tl("rules.long_note.d")],
    ["dup_content", tl("rules.dup_content"), tl("rules.dup_content.d")],
  ];

  async function draw(el) {
    let rules;
    try { rules = await fetch("/api/rules").then((r) => r.json()); }
    catch { return; }                           // old server without the endpoint: show nothing
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="sec" style="padding-top:0">${tl("rules.title")}</div>
      <div class="s" style="margin:-4px 4px 8px">${tl("rules.desc")}</div>`
      + rows().map(([k, t, d]) => `<div class="row"><span class="tx">
          <div class="t" style="font-size:16px">${t}</div>
          <div class="s" style="white-space:normal">${d}</div></span>
          <button class="sw ${rules[k] ? "on" : ""}" role="switch" aria-checked="${!!rules[k]}"
            data-rule="${k}" aria-label="${t}"></button></div>`).join("")
      + `<div style="height:6px"></div>`;
    el.appendChild(card);
    card.querySelectorAll("[data-rule]").forEach((b) => b.onclick = async () => {
      const key = b.dataset.rule, on = !b.classList.contains("on");
      b.classList.toggle("on", on); b.setAttribute("aria-checked", on);
      try { await post("/api/rules", {key, on}); }
      catch (err) { b.classList.toggle("on", !on); b.setAttribute("aria-checked", !on); toast(err.message); }
    });
  }

  const entry = Object.assign(function (el) { draw(el); }, {page: "rules", title: "rules.title"});
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(entry);
})();
