// 대화 view: the sessions this machine has on disk (Claude Code + Codex), read-only.
// Loaded after v2.js, so it uses v2.js's own globals (SCREENS, V, get, esc, ic, ago, tl,
// toast, nav, RM). The list is grouped by project; a click opens the readable transcript with
// the hub results that session pushed linked inline. Reading is consent-gated server-side:
// a {need_consent} answer is shown as an in-app permission card, never a silent read.
// The nav entry lives in v2.js (MENUS); this file only fills SCREENS.sessions.
(function () {
  "use strict";
  if (typeof SCREENS === "undefined") return;      // not on the v2 shell

  // `project` filters on the client (one fetch serves every folder); `past` opens the fold of
  // older and empty conversations (the server's `shelf`: live | recent | old | empty).
  const S = {agent: "", project: "", account: "", sel: null, list: null, loading: false, past: false, fold: {}};
  const UNKNOWN = "(알 수 없음)";
  const RECENT = 7;                                 // sessions_import.RECENT_DAYS                  // the server's bucket for rows with no folder
  const pname = (p) => p === UNKNOWN ? tl("sx.nofolder") : ((typeof D !== "undefined" && D.ident && D.ident[p] && D.ident[p].name) || p);
  const front = (r) => !r.shelf || r.shelf === "live" || r.shelf === "app" || r.shelf === "recent";

  // Scoped styles, injected once. Kept here so the shared v2.css is untouched. Only v2.css
  // tokens (--t1..--t4, --card, --btn, --line, --blue): the old --fg/--muted fallbacks never
  // resolved on the dark theme, which is what left the filter chips dark-on-dark.
  function css() {
    if (document.getElementById("sess-css")) return;
    const s = document.createElement("style");
    s.id = "sess-css";
    s.textContent = `
    .sx-lead{font-size:13px;color:var(--t3);margin:2px 4px 12px;line-height:1.5}
    .sx-bar{display:flex;gap:8px;align-items:center;margin:0 0 4px;flex-wrap:wrap}
    .sx-seg{display:inline-flex;flex:none;background:var(--btn);border-radius:8px;padding:2px;gap:2px}
    .sx-seg button{height:32px;min-height:0;padding:0 12px;border-radius:6px;font-size:13px;font-weight:600;color:var(--t2);transition:background .15s,color .15s}
    .sx-seg button:hover{color:var(--t1)}
    .sx-seg button[aria-checked="true"]{background:var(--card-hi);color:var(--t1);box-shadow:inset 0 0 0 1px var(--t4)}
    .sx-pick{position:relative;flex:1 1 140px;min-width:0;max-width:340px}
    .sx-pbtn{display:flex;align-items:center;gap:8px;width:100%;height:36px;padding:0 12px 0 12px;border-radius:8px;
      background:var(--btn);color:var(--t1);font-size:13px;font-weight:600;text-align:left}
    .sx-pbtn:hover{background:var(--btn-hi)}
    .sx-pbtn svg.i{width:16px;height:16px;flex:none;color:var(--t3)}
    .sx-pbtn .l{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .sx-pbtn .n{color:var(--t3);font-weight:500;white-space:nowrap}
    .sx-pbtn .k{flex:none;color:var(--t3);font-weight:500;white-space:nowrap}
    .sx-pbtn svg.dn{width:14px;height:14px;flex:none;color:var(--t3);transform:rotate(90deg);fill:currentColor;stroke:none}
    .sx-pop{position:absolute;left:0;top:calc(100% + 6px);z-index:20;width:max(100%,300px);max-width:calc(100vw - 32px);
      background:var(--menu-bg);border:1px solid var(--line);border-radius:var(--menu-r);box-shadow:var(--menu-shadow);
      padding:var(--menu-pad);opacity:0;visibility:hidden;transform:translateY(-4px) scale(.98);transform-origin:top left;
      transition:opacity .16s ease,transform .22s cubic-bezier(.2,.9,.25,1),visibility 0s linear .22s}
    .sx-pop.on{opacity:1;visibility:visible;transform:none;transition:opacity .16s ease,transform .22s cubic-bezier(.2,.9,.25,1)}
    @media (max-width:600px){.sx-bar{position:relative}.sx-pick{position:static}
      .sx-pop{left:0;right:0;width:auto;max-width:none;transform-origin:top right}}
    .sx-q{width:100%;height:36px;border:0;outline:none;border-radius:var(--menu-row-r);background:var(--btn);color:var(--t1);font:inherit;font-size:14px;padding:0 12px;margin-bottom:4px}
    .sx-q:focus-visible{box-shadow:0 0 0 2px var(--blue)}
    .sx-opts{max-height:min(360px,55vh);overflow:auto;overscroll-behavior:contain}
    .sx-oh{font-size:12px;font-weight:600;color:var(--t3);padding:8px 12px 4px}
    .sx-o{display:flex;align-items:center;gap:8px;width:100%;min-height:var(--menu-row);padding:var(--menu-row-pad);border-radius:var(--menu-row-r);font-size:var(--menu-fs);font-weight:500;color:var(--t1);text-align:left}
    .sx-o .l{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .sx-o .n{color:var(--t3);font-size:12px}
    .sx-o.act,.sx-o:hover{background:var(--menu-hover)}
    .sx-o[aria-selected="true"] .l{color:var(--blue-t);font-weight:600}
    .sx-none{font-size:13px;color:var(--t3);padding:8px 8px}
    .sx-acct{flex:0 1 180px}
    .sx-gh{display:flex;align-items:baseline;gap:8px;margin:16px 4px 6px;min-width:0}
    .sx-gh .g{font-size:13px;font-weight:600;color:var(--t2);flex:none;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .sx-gh .p{font-size:12px;color:var(--t4);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .sx-gh .c{font-size:12px;color:var(--t3);flex:none}
    .sx-list .card{margin-bottom:0}
    .sx-new{flex:none;height:36px;padding:0 16px;margin-left:auto;font-size:14px;gap:6px;display:inline-flex;align-items:center}
    .sx-new svg{width:15px;height:15px}
    .sx-add{flex:none;width:26px;height:26px;margin:-4px -4px -4px 4px;border-radius:var(--r-sm);display:grid;place-items:center;color:var(--t3);align-self:center}
    .sx-add svg{width:15px;height:15px}
    @media (hover:hover){.sx-add:hover{background:var(--btn);color:var(--t1)}}
    /* Phone: a pill on the first line beside the agent choice, the size of 새 세션 in the chat list
       (40px tall, a 44px touch area), not a bar across the page. */
    @media (max-width:600px){.sx-seg{order:-2}.sx-new{order:-1;position:relative;height:40px;padding:0 16px;font-size:15px;border-radius:999px}
      .sx-new::after{content:"";position:absolute;inset:-2px 0}}
    .sx-row{cursor:pointer;min-height:56px}
    .sx-chip{flex:none;display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 12px;border-radius:8px;background:var(--btn);color:var(--t2);font-size:13px;font-weight:600}
    .sx-chip b{font-weight:700;color:var(--t1)}
    .sx-chip[aria-pressed="true"]{background:var(--card-hi);color:var(--t1);box-shadow:inset 0 0 0 1px var(--t4)}
    .sx-allread{flex:none;height:36px;padding:0 8px;border-radius:8px;font-size:13px;font-weight:500;color:var(--t3)}
    @media (hover:hover){.sx-allread:hover{color:var(--t1);background:var(--btn)}}
    .sx-ic{position:relative}
    .sx-ic svg.sx-ag{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
    .sx-ic .st{display:none;position:absolute;right:-2px;bottom:-2px;width:9px;height:9px;border-radius:50%;background:var(--green);box-shadow:0 0 0 2px var(--card)}
    .sx-ic.on .st{display:block}
    .sx-row.sx-unr .t{font-weight:700}
    .sx-row.sx-unr .t::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--blue);margin-right:8px;vertical-align:2px}
    .sx-un{color:var(--blue-t);font-weight:600}
    .sx-rd{flex:none;width:30px;height:30px;border-radius:var(--r-sm);display:grid;place-items:center;color:var(--t3)}
    .sx-rd svg{width:16px;height:16px}
    @media (hover:hover){.sx-rd:hover{background:var(--btn);color:var(--t1)}}
    .sx-ic{flex:none;width:34px;height:34px;border-radius:8px;display:grid;place-items:center;background:var(--btn);color:var(--t3)}
    .sx-ic svg{width:18px;height:18px}
    .sx-ic.on{color:var(--t1)}
    .sx-row+.sx-row{border-top:1px solid var(--line)}
    .sx-row .t{font-size:14.5px}
    .sx-row .s{display:flex;align-items:center;gap:6px;height:22px;font-size:12px;margin-top:2px;overflow:hidden}
    .sx-row .s>*{flex:none}
    .sx-row .s .sub{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
    .sx-row .s .dot{width:3px;height:3px;border-radius:50%;background:var(--t4)}
    .sx-live{display:inline-flex;align-items:center;gap:4px;color:#3fd894;font-weight:600}
    .sx-live::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--green)}
    .sx-live b{font-weight:600}
    @media (max-width:600px){.sx-row .sx-live b{display:none}}
    .sx-row .btn.sm{flex:none;height:30px;min-height:0}
    .sx-fold{display:flex;align-items:center;gap:8px;width:100%;margin:20px 0 0;padding:8px 4px;min-height:0;
      border-top:1px solid var(--line);font-size:13px;color:var(--t2);text-align:left}
    .sx-fold span{font-weight:600;flex:none}
    .sx-sync{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 16px;padding:12px 16px;border:1px solid var(--line);border-radius:12px;background:var(--card)}
    .sx-sync span{flex:1 1 240px;min-width:0;color:var(--t2);font-size:13px;line-height:1.5}
    .sx-fold em{font-style:normal;color:var(--t3);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .sx-fold svg.dn{width:14px;height:14px;flex:none;color:var(--t3);transition:transform .2s cubic-bezier(.2,.9,.25,1)}
    .sx-fold[aria-expanded="true"] svg.dn{transform:rotate(90deg)}
    .sx-fold:hover span{color:var(--t1)}
    .sx-conv{display:flex;flex-direction:column;gap:8px;margin-top:4px}
    .sx-conv .bub.it .md{white-space:normal}
    .sx-head .t{font-size:16px;font-weight:700;line-height:1.35;overflow-wrap:anywhere}
    .sx-head .m{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;font-size:12px;color:var(--t3);margin:4px 0 12px}
    .sx-head .m .p{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
    .sx-head .act{display:flex;align-items:center;gap:8px;margin:0 0 16px;font-size:13px;color:var(--t2)}
    .sess-pane .back svg.chev{width:16px;height:16px;transform:rotate(180deg)}
    .sess-pane .back{display:inline-flex;align-items:center;gap:6px;cursor:pointer;color:var(--t3);font-size:14px;padding:4px 0;margin-bottom:8px}
    .sess-pane .back:hover{color:var(--t1)}
    .sess-res{border:1px solid var(--line);border-radius:12px;padding:8px 12px;margin:16px 0 4px}
    .sess-res a{display:flex;align-items:center;gap:12px;padding:8px 0;color:inherit;text-decoration:none;border-bottom:1px solid var(--line)}
    .sess-res a:last-child{border-bottom:0}
    .sx-res .th{position:relative;flex:none;width:56px;height:56px;border-radius:8px;overflow:hidden;background:var(--bg);display:flex;align-items:center;justify-content:center;color:var(--t3)}
    .sx-res .th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
    .sx-res .tx{display:flex;flex-direction:column;gap:2px;min-width:0}
    .ask{border:1px solid var(--line);border-radius:12px;padding:16px;margin:8px 2px}
    .fadein{animation:sessfade .16s ease-out both}
    .sx-still .fadein{animation:none}
    @keyframes sessfade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
    @media (prefers-reduced-motion: reduce){.fadein{animation:sessfadeS .2s ease both}
      @keyframes sessfadeS{from{opacity:0}to{opacity:1}}
      .sx-pop,.sx-pop.on{transform:none}}
    `;
    document.head.appendChild(s);
  }

  // A folder path cut to its last two parts, for a line that has to stay one line; the full
  // path goes in the tooltip.
  const parts = (p) => String(p || "").split(/[\\/]+/).filter(Boolean);
  const shortPath = (p) => { const a = parts(p); return a.length > 2 ? "…\\" + a.slice(-2).join("\\") : a.join("\\"); };
  // A leading emoji or symbol in a title pushes its text off the column the others start on.
  const cleanTitle = (t) => String(t || "").replace(/^[\p{Extended_Pictographic}\p{S}\uFE0F\u200D\s]+/u, "") || String(t || "");

  // ------------------------------------------------------------ list

  async function loadList() {
    S.loading = true;
    const q = new URLSearchParams();
    if (S.agent) q.set("agent", S.agent);
    if (S.account) q.set("account", S.account);
    try { S.list = await loopFetch("/api/sessions?" + q.toString()); }
    catch (e) { S.list = {error: e.message}; }
    S.loading = false;
  }

  // The dialog itself is consent.js's (loopFetch). If the person cancelled it, this quiet state
  // stays, with one way to be asked again.
  function askCard(a) {
    if (window.loopConsentLoc) a = window.loopConsentLoc(a);
    return `<div class="ask fadein">
      <div class="t" style="font-size:16px;font-weight:700;margin-bottom:6px">${esc(a.what)}</div>
      <div class="s" style="margin:0 0 12px">${tl("consent.ask")}</div>
      <button class="btn press" id="sess-retry">${tl("consent.askbtn")}</button></div>`;
  }

  // The shared badge lives in badges.js (loaded first); the fallback is plain text, never a crash.
  const LB = () => window.LoopBadges || {agent: (a) => `<span>${a === "codex" ? "Codex" : "Claude"}</span>`, chip: (l) => `<span>${esc(l)}</span>`};
  const agentMark = (a) => LB().agent(a === "codex" ? "codex" : "claude");

  // Folders by most recent activity (rows arrive newest first), each with its row count and
  // the working directory most of its rows ran in (shown once, in the group header).
  function groupsOf(rows) {
    const G = new Map();
    for (const r of rows) {
      let g = G.get(r.project);
      if (!g) G.set(r.project, g = {name: r.project, rows: [], dirs: new Map()});
      g.rows.push(r);
      if (r.cwd) g.dirs.set(r.cwd, (g.dirs.get(r.cwd) || 0) + 1);
    }
    for (const g of G.values()) { const top = [...g.dirs].sort((a, b) => b[1] - a[1])[0]; g.cwd = top ? top[0] : ""; }
    return [...G.values()];
  }

  // Where a row ran, relative to its group's folder; "" when it is the group's own folder.
  function subOf(cwd, base) {
    if (!cwd || cwd === base) return "";
    for (const sep of ["\\", "/"]) if (base && cwd.startsWith(base + sep)) return cwd.slice(base.length + 1);
    return shortPath(cwd);
  }

  // The row's tile says which agent the conversation is with (one-colour glyphs: a burst for
  // Claude, a prompt for Codex); the small dot on it is the session's state (green = on).
  const AG = {
    claude: `<path d="M12 3.5v17M3.5 12h17M6 6l12 12M18 6 6 18"/>`,
    codex: `<path d="m5 8 4.5 4L5 16M12.5 16.5H19"/>`,
  };
  const agentTile = (r) => `<span class="sx-ic${r.live ? " on" : ""}" aria-hidden="true"><svg class="sx-ag" viewBox="0 0 24 24">${AG[r.agent === "codex" ? "codex" : "claude"]}</svg><i class="st"></i></span>`;
  // Unread conversations by session id (v2.js unreadRooms: answered since it was last opened here).
  const unreadMap = () => new Map((typeof unreadRooms === "function" ? unreadRooms() : []).map((r) => [r.key, r.unread]));

  function rowHTML(r, g, i, un) {
    const dot = `<i class="dot"></i>`;
    const sub = subOf(r.cwd, g.cwd);
    const acct = r.account ? LB().chip(r.account) : "";
    const send = !r.live && r.agent !== "codex"
      ? `<button class="btn sm press" data-app="${esc(r.id)}" title="${esc(tl("sx.app.t"))}">${esc(tl("sx.app"))}</button>` : "";
    return `<div class="row press sx-row fadein${un ? " sx-unr" : ""}" role="button" tabindex="0" data-id="${esc(r.id)}" style="animation-delay:${Math.min(i, 12) * 18}ms">
      ${agentTile(r)}<span class="tx"><div class="t" title="${esc(r.title)}">${esc(cleanTitle(r.title))}</div>
        <div class="s">${agentMark(r.agent)}${acct}${un ? `<span class="sx-un">${esc(tl("sx.new", {n: un}))}</span>${dot}` : ""}${r.live ? `<span class="sx-live" title="${esc(tl("sx.live.t"))}"><b>${esc(tl("sx.live"))}</b></span>` : ""}<span>${esc(ago(r.last))}</span>${dot}<span>${esc(r.count ? tl("sx.msgs", {n: r.count}) : tl("sx.msgs0"))}</span>${sub ? `${dot}<span class="sub" title="${esc(r.cwd)}">${esc(sub)}</span>` : ""}</div></span>
      ${un ? `<button class="sx-rd press" data-read="${esc(r.id)}" title="${esc(tl("sx.read"))}" aria-label="${esc(tl("sx.read"))}">${ic("check")}</button>` : send}${ic("chev", "i go")}</div>`;
  }

  // The project picker: one button, a searchable list under it, recent folders first.
  function pickerHTML(groups) {
    const cur = S.project;
    return `<div class="sx-pick">
      <button class="sx-pbtn press" id="sx-pb" aria-haspopup="listbox" aria-expanded="false">${ic("folder")}
        ${cur ? `<span class="k">${esc(unitWord())}</span>` : ""}<span class="l">${cur ? esc(pname(cur)) : esc(tl("sx.allU"))}</span><span class="n">${cur ? "" : esc(tl("sx.cnt", {n: groups.length}))}</span>${ic("chev", "dn")}</button>
      <div class="sx-pop" id="sx-pop" role="dialog" aria-label="${esc(tl("sx.pick"))}">
        <input class="sx-q" id="sx-q" type="search" placeholder="${esc(tl("sx.find"))}" autocomplete="off" role="combobox" aria-controls="sx-opts" aria-expanded="true">
        <div class="sx-opts" id="sx-opts" role="listbox"></div></div></div>`;
  }

  function wirePicker(root, groups) {
    const pb = root.querySelector("#sx-pb"), pop = root.querySelector("#sx-pop"),
      q = root.querySelector("#sx-q"), box = root.querySelector("#sx-opts");
    if (!pb) return;
    const count = new Map(groups.map((g) => [g.name, g.rows.length]));
    const recent = groups.slice(0, 5).map((g) => g.name);
    const byName = groups.map((g) => g.name).sort((a, b) => (a === UNKNOWN) - (b === UNKNOWN) || a.localeCompare(b, "ko"));
    let act = 0;
    const opt = (v, label, n) => `<button class="sx-o" role="option" data-v="${esc(v)}" aria-selected="${v === S.project}">
      <span class="l">${esc(label)}</span>${n != null ? `<span class="n">${n}</span>` : ""}</button>`;
    const opts = () => [...box.querySelectorAll(".sx-o")];
    const mark = () => opts().forEach((b, i) => b.classList.toggle("act", i === act));
    const fill = () => {
      const t = q.value.trim().toLowerCase();
      if (t) {
        const hit = byName.filter((p) => pname(p).toLowerCase().includes(t));
        box.innerHTML = hit.length ? hit.map((p) => opt(p, pname(p), count.get(p))).join("") : `<div class="sx-none">${esc(tl("sx.nohit"))}</div>`;
      } else {
        const total = groups.reduce((a, g) => a + g.rows.length, 0);
        // "최근" only earns its place when the full list is long enough to need a shortcut.
        box.innerHTML = opt("", tl("sx.allU"), total)
          + (byName.length > recent.length ? `<div class="sx-oh">${esc(tl("sx.recent"))}</div>` + recent.map((p) => opt(p, pname(p), count.get(p))).join("") : "")
          + `<div class="sx-oh">${esc(tl("sx.byname", {u: unitWord(), n: byName.length}))}</div>` + byName.map((p) => opt(p, pname(p), count.get(p))).join("");
      }
      act = 0; mark();
      box.querySelectorAll(".sx-o").forEach((b) => b.onclick = () => choose(b.dataset.v));
    };
    const away = (e) => { if (!e.target.closest(".sx-pick")) open(false); };
    const open = (on) => {
      pop.classList.toggle("on", on); pb.setAttribute("aria-expanded", String(on));
      if (on) { q.value = ""; fill(); setTimeout(() => q.focus(), 0); document.addEventListener("pointerdown", away, true); }
      else document.removeEventListener("pointerdown", away, true);
    };
    const choose = (v) => { open(false); S.project = v; SCREENS.sessions(); };
    pb.onclick = () => open(!pop.classList.contains("on"));
    q.oninput = fill;
    q.onkeydown = (e) => {
      const o = opts();
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault(); if (!o.length) return;
        act = (act + (e.key === "ArrowDown" ? 1 : -1) + o.length) % o.length; mark();
        o[act].scrollIntoView({block: "nearest"});
      } else if (e.key === "Enter") { e.preventDefault(); if (o[act]) choose(o[act].dataset.v); }
      else if (e.key === "Escape") { e.preventDefault(); open(false); pb.focus(); }
    };
  }

  // The entrance fade plays on a fresh draw only. A background refresh (v2.js softDraw: softN > 0)
  // or a second draw within a second shows the rows as they are: a fade that restarts on every
  // refresh never finishes, and with many live sessions that left whole groups invisible.
  let lastAnim = 0;
  function drawList(el) {
    css();
    const d = S.list;
    const root = document.createElement("div");
    const soft = typeof softN !== "undefined" && softN > 0;
    const anim = !soft && Date.now() - lastAnim > 1000;
    if (anim) lastAnim = Date.now();
    root.className = anim ? "sx" : "sx sx-still";
    const agents = [["", tl("sx.all")], ["claude", "Claude"], ["codex", "Codex"]];
    const accts = (d && d.accounts) || [];
    const rowsAll = (d && d.sessions) || [];
    const groupsAll = groupsOf(rowsAll);
    const UN = unreadMap(), unN = rowsAll.filter((r) => UN.has(r.id)).length;
    if (!unN) S.unread = false;
    const fil = `<div class="sx-bar">
      <div class="sx-seg" role="radiogroup" aria-label="${esc(tl("sx.agent"))}">${agents.map(([v, l]) =>
        `<button class="press" role="radio" aria-checked="${v === S.agent}" data-agent="${esc(v)}">${v ? agDot(v) : ""}${esc(l)}</button>`).join("")}</div>
      ${unN ? `<button class="sx-chip press" id="sx-unread" aria-pressed="${!!S.unread}" title="${esc(tl("sx.unread.t"))}">${esc(tl("sx.unread"))} <b>${unN}</b></button>
        <button class="sx-allread press" id="sx-allread" title="${esc(tl("sx.allread.t"))}">${esc(tl("sx.allread"))}</button>` : ""}
      ${groupsAll.length > 1 || S.project ? pickerHTML(groupsAll) : ""}
      ${accts.length > 1 ? `<gk-select class="sx-acct" id="sx-acct" aria-label="${esc(tl("sx.acct"))}">${[["", tl("sx.acct.all")], ...accts.map((a) => [a, a])].map(([v, l]) =>
        `<option value="${esc(v)}"${v === S.account ? " selected" : ""}>${esc(l)}</option>`).join("")}</gk-select>` : ""}
      <button class="btn fill press sx-new" data-newchat="">${ic("plus")}${esc(tl("sx.newchat"))}</button></div>`;

    let body, none = false;
    if (S.loading && !d) body = loadingHtml("", {fill: true});
    else if (d && d.error) body = `<div class="s" style="padding:20px 4px">${esc(d.error)}</div>`;
    else if (d && d.need_consent) body = askCard(d.need_consent);
    else {
      const inProj = (S.project ? rowsAll.filter((r) => r.project === S.project) : rowsAll).filter((r) => !S.unread || UN.has(r.id));
      const synced = ((d && d.app_sync) || []).length > 0;
      const now = inProj.filter(front), past = inProj.filter((r) => !front(r));
      let i = 0;
      const list = (rows) => `<div class="sx-list">` + groupsOf(rows).map((g) =>
        `<div class="sx-gh"><span class="g">${esc(pname(g.name))}</span><span class="p" title="${esc(g.cwd)}">${esc(shortPath(g.cwd))}</span><span class="c">${g.rows.length}</span>${g.name === UNKNOWN ? "" : `<button class="sx-add press" data-newchat="${esc(g.name)}" aria-label="${esc(tl("sx.newin", {p: pname(g.name)}))}" title="${esc(tl("sx.newin", {p: pname(g.name)}))}">${ic("plus")}</button>`}</div>
        <div class="card">${g.rows.slice().sort((a, b) => UN.has(b.id) - UN.has(a.id)).map((r) => rowHTML(r, g, i++, UN.get(r.id))).join("")}</div>`).join("") + `</div>`;
      if (!inProj.length) none = true, body = `<div class="s" style="padding:20px 4px">${esc(S.unread ? tl("sx.none.unread") : tl("sx.none"))}</div>`;
      else {
        body = now.length ? list(now) : `<div class="s" style="padding:16px 4px 4px">${esc(synced ? tl("sx.none.app") : tl("sx.none.recent", {n: RECENT}))}</div>`;
        // Behind folds: what the app archived, what the app does not list, and (for an agent
        // whose app list is not read) the older and empty ones.
        const folds = [
          ["archived", tl("sx.f.arch"), tl("sx.f.arch.s")],
          ["hidden", tl("sx.f.hid"), tl("sx.f.hid.s")],
          ["past", tl("sx.f.past"), tl("sx.f.past.s", {n: RECENT})],
        ];
        for (const [k, label, why] of folds) {
          const rows = past.filter((r) => k === "past" ? (r.shelf === "old" || r.shelf === "empty") : r.shelf === k);
          if (!rows.length) continue;
          const on = !!S.fold[k];
          body += `<button class="sx-fold press" data-fold="${k}" aria-expanded="${on}">${ic("chev", "i dn")}
            <span>${esc(tl("sx.f.n", {l: label, n: rows.length}))}</span><em>${esc(why)}</em></button>`;
          if (on) body += list(rows);
        }
      }
      const na = (d && d.need_app) || [];
      if (na.length) body = `<div class="sx-sync fadein"><span>${esc(tl("sx.sync"))}</span>
        <button class="btn sm press" id="sx-sync" data-agent-sync="${esc(na[0])}">${esc(tl("sx.sync.b", {a: na[0] === "codex" ? "Codex" : "Claude"}))}</button></div>` + body;
      const more = (d && d.need_more) || [];
      // Not connected here: only how many there are, and the way to connect (see project.js unlinkRows).
      ((d && d.unlinked) || []).forEach((u) => { body += `<div class="s" style="padding:14px 4px 4px">${esc(tl("room.unlinked", {agent: u.agent === "codex" ? "Codex" : "Claude Code", n: u.count}))} <button class="lnk" data-golink style="background:none;border:0;color:inherit;text-decoration:underline;cursor:pointer">${tl("room.unlinkedGo")}</button></div>`; });
      if (more.length) body += `<div class="s" style="padding:14px 4px 4px">${esc(tl("sx.more", {w: (window.loopConsentLoc ? window.loopConsentLoc(more[0]) : more[0]).what}))} <button class="lnk" id="sess-more" style="background:none;border:0;color:inherit;text-decoration:underline;cursor:pointer">${esc(tl("sx.more.b"))}</button></div>`;
    }

    const lead = ((d && d.app_sync) || []).length
      ? tl("sx.lead.app")
      : tl("sx.lead.recent", {n: RECENT});
    // With no conversation at all the empty line below says it; the lead would only say it twice.
    root.innerHTML = `${chatTabs("sessions")}${none ? "" : `<div class="sx-lead">${more1(lead, tl("sx.lead.more"), "sxlead")}</div>`}
      ${fil}${body}`;
    el.innerHTML = "";
    el.appendChild(root);

    root.querySelectorAll("[data-agent]").forEach((b) => b.onclick = async () => {
      if (S.agent === b.dataset.agent) return;
      S.agent = b.dataset.agent; S.project = "";
      await loadList(); SCREENS.sessions();
    });
    const ac = root.querySelector("#sx-acct");
    if (ac) ac.onchange = async () => { S.account = ac.value; await loadList(); SCREENS.sessions(); };
    wirePicker(root, groupsAll);
    root.querySelectorAll("[data-newchat]").forEach((b) => b.onclick = () => newChat(b.dataset.newchat));
    // Reading redraws in place, without the entrance fade.
    const still = () => { lastAnim = Date.now(); SCREENS.sessions(); };
    const ub = root.querySelector("#sx-unread");
    if (ub) ub.onclick = () => { S.unread = !S.unread; still(); };
    const ar = root.querySelector("#sx-allread");
    if (ar) ar.onclick = async () => { const p = roomsRead(); still(); await p; if (window.toast) toast(tl("sx.allread.done")); };
    root.querySelectorAll("[data-read]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); roomsRead([b.dataset.read]); still(); });
    root.querySelectorAll("[data-fold]").forEach((b) => b.onclick = () => { S.fold[b.dataset.fold] = !S.fold[b.dataset.fold]; SCREENS.sessions(); });
    const sy = root.querySelector("#sx-sync");
    if (sy) sy.onclick = async () => {
      const r = await loopFetch("/api/sessions/app-sync?agent=" + encodeURIComponent(sy.dataset.agentSync)).catch(() => null);
      if (r && r.ok) { await loadList(); SCREENS.sessions(); }
    };
    root.querySelectorAll("[data-app]").forEach((b) => b.onclick = async (e) => {
      e.stopPropagation();
      try {
        await loopFetch("/api/sessions/open-app", {json: {id: b.dataset.app}});
        if (window.toast) toast(tl("sx.app.ok"));
      } catch (err) { if (window.toast) toast(err.message || tl("sx.app.fail")); }
    });
    root.querySelectorAll(".sx-row").forEach((b) => {
      const open = () => openChat(b.dataset.id);
      b.onclick = (e) => { if (!e.target.closest("[data-app],[data-read]")) open(); };
      b.onkeydown = (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === b) { e.preventDefault(); open(); } };
    });
    const rt = root.querySelector("#sess-retry");
    if (rt) rt.onclick = async () => { await loadList(); SCREENS.sessions(); };
    const mo = root.querySelector("#sess-more");
    if (mo) mo.onclick = () => nav("settings");
  }

  // 새 대화: the one new-conversation sheet (web/project.js newChat), never a second copy. Until
  // that file exports it as window.LOOP_NEW_CHAT, go to its screen and press its own button.
  function newChat(project) {
    if (typeof window.LOOP_NEW_CHAT === "function") return window.LOOP_NEW_CHAT(project || undefined);
    nav("project" + (project ? "/" + encodeURIComponent(project) : ""));
    // The screen may first ask for a permission, so wait for its button for as long as the
    // person stays there (30s at most) rather than giving up while they read the question.
    let n = 0;
    const t = setInterval(() => {
      if (!location.hash.startsWith("#project") || ++n > 300) return clearInterval(t);
      const b = V().querySelector("[data-new]");
      if (b) { clearInterval(t); b.click(); }
    }, 100);
  }

  // One chat for everything: a conversation opens in the project page's chat (web/project.js), live
  // with a message box when it is up, readable with [이어서 하기] when it has ended. Only a
  // conversation with no folder has nowhere to live, so it opens as a plain read-only transcript.
  function openChat(id) {
    const r = ((S.list && S.list.sessions) || []).find((x) => x.id === id);
    if (r && r.project && r.project !== UNKNOWN) { S.sel = null; nav("project/" + encodeURIComponent(r.project) + "/" + encodeURIComponent(r.id)); return; }
    S.sel = id; SCREENS.sessions();
  }

  // ------------------------------------------------------------ transcript

  // A result's picture from the loaded item list (the same thumbnail the library shows).
  function resThumb(r) {
    let it = null;
    try { it = (D.items || []).find((x) => iid(x) === r.project + "/" + r.item); } catch (e) { /* items not loaded */ }
    const k = (typeof KIND !== "undefined" && KIND[(it && it.kind) || "doc"]) || ["doc"];
    return `<span class="th">${ic(k[0])}${it && it.thumb ? `<img src="${esc(it.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : ""}</span>`;
  }

  // Consecutive tool calls fold into one quiet line, so the words carry the page.
  function convHTML(entries) {
    const out = [];
    let tools = [];
    const flush = () => {
      if (!tools.length) return;
      out.push(`<details class="tools"><summary>${ic("tool")}<span>${esc(tl("sx.tools", {n: tools.length}))}</span><em>${esc(tools[tools.length - 1])}</em></summary>
        <div class="tl">${tools.map((t) => `<div>${esc(t)}</div>`).join("")}</div></details>`);
      tools = [];
    };
    for (const e of entries) {
      if (e.kind === "tool") { tools.push(e.text || ""); continue; }
      if (e.kind === "sub" || e.kind === "res" || e.kind === "think") continue;   // parts of a call's line, and thoughts: the chat's own to show
      flush();
      if (e.kind === "user") out.push(`<div class="bub me"><div class="bt">${esc(e.text)}</div></div>`);
      else out.push(`<div class="bub it" data-md="${out.length}"></div>`);
    }
    flush();
    return out.join("");
  }

  // Claude's words go through markdown.js (DOM nodes, never innerHTML); plain text without it.
  function fillMarkdown(box, entries) {
    const said = entries.filter((e) => !["tool", "user", "sub", "res", "think"].includes(e.kind));
    box.querySelectorAll(".bub.it").forEach((b, i) => {
      const text = (said[i] && said[i].text) || "";
      if (typeof renderMarkdown === "function") b.appendChild(renderMarkdown(text, "md"));
      else { const m = document.createElement("div"); m.className = "md"; m.style.whiteSpace = "pre-wrap"; m.textContent = text; b.appendChild(m); }
    });
  }

  async function drawPane(el) {
    css();
    const card = document.createElement("div");
    card.className = "sess-pane";
    card.innerHTML = `<button class="back press">${ic("chev", "i chev")}<span>${esc(tl("sx.back"))}</span></button>
      ${loadingHtml("", {fill: true})}`;
    el.innerHTML = "";
    el.appendChild(card);
    card.querySelector(".back").onclick = () => { S.sel = null; SCREENS.sessions(); };

    let tx;
    const row = (S.list && S.list.sessions || []).find((r) => r.id === S.sel);
    const q = new URLSearchParams({id: S.sel});
    if (row && row.agent) q.set("agent", row.agent);
    try { tx = await loopFetch("/api/sessions/transcript?" + q.toString()); }
    catch (e) { tx = {error: e.message}; }
    if (S.sel == null) return;                        // left the pane while loading

    let body;
    const entries = (tx && tx.entries) || [];
    if (tx.error) body = `<div class="s" style="padding:18px 4px">${esc(tx.error)}</div>`;
    else if (tx.need_consent) body = askCard(tx.need_consent);
    else if (!tx.found) body = `<div class="s" style="padding:18px 4px">${esc(tl("sx.gone"))}</div>`;
    else {
      const head = `<div class="sx-head"><div class="t">${esc(cleanTitle(tx.title) || tl("sx.chat"))}</div>
        <div class="m">${agentMark(tx.agent)}${tx.project ? `<span>${esc(pname(tx.project))}</span>` : ""}
          ${tx.cwd ? `<span class="p" title="${esc(tx.cwd)}">${esc(shortPath(tx.cwd))}</span>` : ""}</div>
        <div class="s" style="margin:0 0 10px">${esc(tl("sx.ro"))}</div></div>`;
      const conv = entries.length ? `<div class="sx-conv">${convHTML(entries)}</div>` : `<div class="s">${esc(tl("sx.nomsg"))}</div>`;
      let res = "";
      if ((tx.results || []).length) {
        res = `<div class="sess-res fadein"><div class="s" style="margin-bottom:4px">${esc(tl("sx.results"))}</div>` +
          tx.results.map((r) => `<a class="sx-res" href="#item/${encodeURIComponent(r.project)}/${encodeURIComponent(r.item)}" data-go="item/${esc(r.project)}/${esc(r.item)}">
            ${resThumb(r)}<span class="tx"><b>${esc(r.title)}</b><span class="c-grey">${esc(r.v)}${r.at ? " · " + esc(ago(r.at)) : ""}</span></span></a>`).join("") + `</div>`;
      }
      body = head + conv + res;
    }
    card.innerHTML = `<button class="back press">${ic("chev", "i chev")}<span>${esc(tl("sx.back"))}</span></button>${body}`;
    const cv = card.querySelector(".sx-conv");
    if (cv) fillMarkdown(cv, entries);
    card.querySelector(".back").onclick = () => { S.sel = null; SCREENS.sessions(); };
    const rt = card.querySelector("#sess-retry");
    if (rt) rt.onclick = () => SCREENS.sessions();
    card.querySelectorAll("[data-go]").forEach((a) => a.onclick = (ev) => { ev.preventDefault(); S.sel = null; nav(a.dataset.go); });
  }

  // ------------------------------------------------------------ screen

  SCREENS.sessions = function () {
    const el = V();
    if (S.sel) { drawPane(el); return; }
    if (!S.list && !S.loading) { drawList(el); loadList().then(() => { if (!S.sel) SCREENS.sessions(); }); return; }
    drawList(el);
  };
})();
