// Workbench shell for the desk style: activity bar, explorer, editor tabs, command box, work table.
// Everything it adds lives outside the containers the app re-renders, or is re-mounted by sync().
(() => {
  const root = document.documentElement, en = root.lang.startsWith("en");
  const t = (ko, e) => (en ? e : ko);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
  const svg = (d) => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
  const IC = {
    home: "M3.5 6.5 5 8l3-3M3.5 12.5 5 14l3-3M3.5 18.5 5 20l3-3M11 7h9.5M11 13h9.5M11 19h9.5",
    project: "M4 5h16v11H10l-6 4z",
    lib: "M8 3h7l4 4v10H8zM15 3v4h4M8 7H5v14h10v-4",
    inbox: "M6 17v-6a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21.5h4",
    depts: "m12 3 9 5-9 5-9-5zM3 13l9 5 9-5",
    usage: "M4 20V11M10 20V4M16 20v-7M2 20h20",
    settings: "M4 7h10M18 7h2M4 17h2M10 17h10M16 5v4M8 15v4",
    all: "M5 12h.01M12 12h.01M19 12h.01",
    search: "M10.5 17a6.5 6.5 0 1 1 0-13 6.5 6.5 0 0 1 0 13zM15.5 15.5 20 20",
    side: "M4 5h16v14H4zM14.5 5v14",
    back: "M14 6l-6 6 6 6", fwd: "M10 6l6 6-6 6", chev: "M9 6l6 6-6 6", x: "M7 7l10 10M17 7 7 17",
  };
  const NAME = {
    home: t("내 작업", "My work"), project: t("대화", "Chats"), lib: t("파일", "Files"), inbox: t("알림", "Inbox"),
    depts: t("부서", "Departments"), usage: t("사용량", "Usage"), settings: t("설정", "Settings"), all: t("더보기", "More"),
  };
  const STATE = [["pending", t("확인 대기", "To review")], ["changes", t("수정 요청", "Changes asked")],
    ["hold", t("보류", "On hold")], ["approved", t("승인", "Approved")]];
  const ACT = {item: "lib"};
  const store = (k, v) => (v === undefined ? JSON.parse(sessionStorage.getItem(k) || "null") : sessionStorage.setItem(k, JSON.stringify(v)));
  const route = () => { const p = location.hash.slice(1).split("/"); return {key: p[0] || "home", p}; };
  const itemHash = (i) => `#item/${encodeURIComponent(i.project)}/${encodeURIComponent(i.id)}`;
  const ago = (iso) => { const m = Math.max(0, (Date.now() - new Date(iso)) / 60000);
    return m < 60 ? t(`${Math.round(m)}분 전`, `${Math.round(m)}m`) : m < 1440 ? t(`${Math.round(m / 60)}시간 전`, `${Math.round(m / 60)}h`) : t(`${Math.round(m / 1440)}일 전`, `${Math.round(m / 1440)}d`); };
  const add = (tag, id, html) => { const e = document.createElement(tag); e.id = id; e.innerHTML = html; document.body.appendChild(e); return e; };
  const actBtn = (k, lab = "") => `<button data-go="${k}" data-act="${k}" aria-label="${NAME[k]}" title="${NAME[k]}">${svg(IC[k])}${k === "inbox" ? '<b class="dk-n" hidden></b>' : ""}${lab && `<span>${lab}</span>`}</button>`;

  let items = [], sessions = [], closed = new Set(store("dk-closed") || ["g:approved"]), tabs = store("dk-tabs") || [];
  let detTab = "res", detHtml = "", inboxHtml = "", pvSel = "", pvHtml = "";

  // PC chrome: title bar with the command box, activity bar, explorer, editor tabs, status line.
  add("header", "dk-title", `<span class="dk-logo"><i></i>GENOK</span>
    <button data-hist="-1" aria-label="${t("뒤로", "Back")}">${svg(IC.back)}</button><button data-hist="1" aria-label="${t("앞으로", "Forward")}">${svg(IC.fwd)}</button>
    <button class="dk-cmd" data-go="search">${svg(IC.search)}<span>${t("검색 또는 명령", "Search or command")}</span><kbd>${/Mac/.test(navigator.platform) ? "⌘K" : "Ctrl K"}</kbd></button>`);
  const act = add("nav", "dk-act", ["home", "project", "lib", "inbox", "depts"].map((k) => actBtn(k)).join("") + '<span class="dk-sp"></span>' + ["usage", "settings"].map((k) => actBtn(k)).join(""));
  act.setAttribute("aria-label", t("작업 전환", "Activities"));
  const exp = add("aside", "dk-exp", "");
  const tabsEl = add("div", "dk-tabs", "");
  const sb = add("div", "dk-sb", "");
  const det = add("aside", "dk-det", "");
  // Lists on PC: the hovered or first result, large, beside the list.
  const pv = add("aside", "dk-pv", "");
  // Phone chrome: workspace line with the command field on top, five labelled items below.
  add("header", "dk-ph", `<button class="dk-ws" data-go="depts"><i></i>Genok${svg(IC.chev)}</button>
    <button class="dk-cmd" data-go="search">${svg(IC.search)}<span>${t("검색 또는 명령", "Search or command")}</span></button>`);
  const bar = add("nav", "dk-bar", ["home", "project", "lib", "inbox", "all"].map((k) => actBtn(k, k === "home" ? t("작업", "Work") : NAME[k])).join(""));
  bar.setAttribute("aria-label", t("작업 전환", "Activities"));

  const dot = (s) => `<i class="dk-st s-${esc(s)}"></i>`;
  const kv = (k, v) => (v ? `<div class="dk-kv"><span>${k}</span><span>${esc(v)}</span></div>` : "");
  const props = (i) => `<div class="dk-kv"><span>${t("상태", "Status")}</span><span>${dot(i.status)}${esc((STATE.find((s) => s[0] === i.status) || [0, i.status])[1])}</span></div>`
    + kv(t("버전", "Version"), i.v) + kv(t("부서", "Department"), i.dept || i.project) + kv(t("에이전트", "Agent"), i.agent)
    + kv(t("날짜", "Date"), new Date(i.at).toLocaleString(root.lang, {dateStyle: "medium", timeStyle: "short"})) + kv(t("파일", "Files"), i.count) + kv(t("코멘트", "Comments"), i.comments);
  const LISTROW = "#view .gi, #view .card .row, #view .turnr";
  const rowItem = (r) => { const n = r.querySelector(".t, .rt")?.textContent.trim(); return items.find((i) => i.title === n); };
  const byState = () => { const known = STATE.map((s) => s[0]);
    return STATE.concat([...new Set(items.map((i) => i.status))].filter((s) => !known.includes(s)).map((s) => [s, s]))
      .map(([k, n]) => ({k, n, rows: items.filter((i) => i.status === k)})).filter((g) => g.rows.length); };
  // Department folders start shut (there are many); for them the stored set lists the open ones.
  const shut = (id) => id.startsWith("d:") !== closed.has(id);
  const fold = (id, n, c) => `<button class="dk-g" data-fold="${esc(id)}" aria-expanded="${!shut(id)}">${svg(IC.chev)}<span title="${esc(n)}">${esc(n)}</span><b>${c}</b></button>`;

  // Files activity: results by project. Everything else: departments with their latest sessions.
  // (The chat screen puts the app's own session list in this slot; see the stylesheet.)
  function drawExplorer() {
    const at = decodeURIComponent(location.hash), {key} = route(), files = ["lib", "item"].includes(key);
    if (key === "inbox") {
      const row = (h, i) => `<a href="#inbox" data-dk-sec="${i}">${dot("pending")}<span>${esc(h.querySelector("h2")?.textContent || "")}</span><em>${esc(h.querySelector(".n")?.textContent || "")}</em></a>`;
      const html = `<div class="dk-eh">${t("탐색기 · 알림", "Explorer · inbox")}</div><div class="dk-tree">${[...document.querySelectorAll("#view > .card > .ch")].map(row).join("")}</div>`;
      if (html !== inboxHtml) exp.innerHTML = inboxHtml = html;
      return;
    }
    inboxHtml = "";
    if (!files) {
      const depts = [...new Set(sessions.map((x) => x.project))].map((p) => ({p, rows: sessions.filter((x) => x.project === p)})).slice(0, 14);
      exp.innerHTML = `<div class="dk-eh">${t("탐색기 · 부서", "Explorer · departments")}</div><div class="dk-tree">` + depts.map((g) => fold("d:" + g.p, g.p, g.rows.length)
        + (shut("d:" + g.p) ? "" : g.rows.slice(0, 4).map((x) => `<a href="#project/${encodeURIComponent(x.project)}/${encodeURIComponent(x.id)}">${dot(x.live ? "live" : "idle")}<span>${esc(x.title || x.named || x.id)}</span><em>${esc(x.agent || "")}</em></a>`).join(""))).join("") + `<a class="dk-all" href="#depts">${t("부서 전체 보기", "All departments")}</a></div>`;
      return;
    }
    const groups = [...new Set(items.map((i) => i.project))].map((p) => ({p, rows: items.filter((i) => i.project === p)}));
    exp.innerHTML = `<div class="dk-eh">${t("탐색기 · 결과물", "Explorer · results")}</div><div class="dk-tree">` + groups.map((g) => fold("p:" + g.p, g.p, g.rows.length)
      + (shut("p:" + g.p) ? "" : g.rows.map((i) => `<a href="${itemHash(i)}" class="${decodeURIComponent(itemHash(i)) === at ? "on" : ""}">${dot(i.status)}<span>${esc(i.title)}</span><em>${esc(i.v)}</em></a>`).join(""))).join("") + "</div>";
  }

  function workTable() {
    const head = `<div class="dk-r dk-h"><span>${t("상태", "Status")}</span><span>${t("제목", "Title")}</span><span>${t("부서", "Department")}</span><span>${t("에이전트", "Agent")}</span><span>${t("업데이트", "Updated")}</span></div>`;
    return head + byState().map((g) => fold("g:" + g.k, g.n, g.rows.length) + (shut("g:" + g.k) ? "" : g.rows.map((i) =>
      `<a class="dk-r" href="${itemHash(i)}"><span>${dot(i.status)}${esc(g.n)}</span><span class="dk-ti">${esc(i.title)}<em>${esc(i.v)}</em></span><span>${esc(i.dept || i.project)}</span><span class="dk-ag a-${esc(i.agent)}">${esc(i.agent || "")}</span><span class="dk-at">${ago(i.at)}</span></a>`).join(""))).join("");
  }

  // Chat: the session's results, changes and facts in a tabbed panel; the header buttons it replaces are pressed from here.
  function drawDet() {
    const st = document.querySelector(".pj-conv .pj-state"); if (!st) return;
    const dept = decodeURIComponent(route().p[1] || ""), txt = (q) => st.querySelector(q)?.textContent.trim() || "";
    const rows = items.filter((i) => i.dept === dept), chg = txt(".pj-chg").replace(/\D/g, "");
    const tab = (k, n, c) => `<button data-dk-tab="${k}" class="${detTab === k ? "on" : ""}">${n}${c ? `<b>${c}</b>` : ""}</button>`;
    const press = (q, n) => (st.querySelector(q) ? `<button class="dk-btn" data-dk-press=".pj-conv .pj-state ${q}">${esc(n)}</button>` : "");
    const body = detTab === "res" ? rows.map((i) => `<a href="${itemHash(i)}">${dot(i.status)}<span>${esc(i.title)}</span><em>${esc(i.v)} · ${ago(i.at)}</em></a>`).join("") || `<p>${t("아직 올린 결과물이 없어요", "No results yet")}</p>`
      : detTab === "chg" ? `<p>${chg ? t(`이 세션이 바꾼 파일 ${chg}개`, `${chg} files changed by this session`) : t("바뀐 파일이 없어요", "No changed files")}</p>${press(".pj-chg", t("변경 내용 열기", "Open changes"))}`
      : kv(t("상태", "Status"), txt(".pj-stl")) + kv(t("부서", "Department"), dept) + kv(t("에이전트", "Agent"), txt(".pj-agw")) + kv(t("창", "Window"), txt(".pj-bg"))
        + kv(t("모델", "Model"), document.querySelector(".pj-mbtn")?.textContent.trim()) + press(".pj-text", txt(".pj-text"));
    const side = t("옆 패널 열기", "Open side panel");
    const html = `<div class="dk-dt">${tab("res", t("결과", "Results"), rows.length)}${tab("chg", t("변경", "Changes"), chg)}${tab("info", t("정보", "Info"))}<button data-dk-press=".pj-strip" aria-label="${side}" title="${side}">${svg(IC.side)}</button></div><div class="dk-db">${body}</div>`;
    if (html !== detHtml) det.innerHTML = detHtml = html;
  }

  function drawProps() {
    const head = document.querySelector(".detailcols.item .htitle"), i = items.find((x) => decodeURIComponent(itemHash(x)) === decodeURIComponent(location.hash));
    if (!head || !i || document.getElementById("dk-props")?.dataset.h === location.hash) return;
    document.getElementById("dk-props")?.remove();
    const d = document.createElement("div"); d.id = "dk-props"; d.dataset.h = location.hash;
    d.innerHTML = props(i);
    head.after(d);
  }

  function drawPv() {
    const {key} = route(), rows = key === "lib" || key === "inbox" ? [...document.querySelectorAll(LISTROW)].filter(rowItem) : [];
    const row = rows.find((r) => itemHash(rowItem(r)) === pvSel) || rows[0], i = row && rowItem(row);
    root.toggleAttribute("data-dk-pv", !!i);
    for (const r of rows) r.classList.toggle("dk-sel", r === row);
    const html = i ? `<div class="dk-pvh"><span>${t("미리보기", "Preview")}</span><a class="dk-btn" href="${itemHash(i)}">${t("열기", "Open")}</a></div>
      <a class="dk-pvi" href="${itemHash(i)}" aria-label="${esc(i.title)}">${i.thumb ? `<img src="${esc(i.thumb)}" alt="">` : `<span>${svg(IC.lib)}${esc(i.kind || "")}</span>`}</a><h3>${esc(i.title)}</h3>${props(i)}` : "";
    if (html !== pvHtml) pv.innerHTML = pvHtml = html;
  }
  const pick = (e) => {
    const r = e.target.closest?.(LISTROW), i = r && rowItem(r);
    if (i && itemHash(i) !== pvSel) { pvSel = itemHash(i); drawPv(); }
  };

  // Phone: full-screen pages get a breadcrumb back to their list instead of a bare back arrow.
  function crumb(box, href, name) {
    if (!box || box.querySelector(":scope > .dk-crumb")) return;
    const a = document.createElement("a"); a.className = "dk-crumb"; a.href = href; a.textContent = name; box.prepend(a);
  }

  function drawTabs() {
    const now = location.hash || "#home";
    tabsEl.innerHTML = tabs.map((x, n) => `<div class="dk-tab ${x.h === now ? "on" : ""}"><a href="${esc(x.h)}">${svg(IC[ACT[x.k] || x.k] || IC.lib)}<span>${esc(x.k === "item" && items.find((i) => itemHash(i) === x.h)?.title || x.n)}</span></a><button data-dk-close="${n}" aria-label="${t("탭 닫기", "Close tab")}">${svg(IC.x)}</button></div>`).join("");
  }

  function visit() {
    const {key, p} = route(), h = location.hash || "#home";
    if (key !== "search" && !tabs.some((x) => x.h === h)) {
      tabs.push({h, k: key, n: key === "item" ? decodeURIComponent(p[2] || p[1] || "") : key === "project" && p[1] ? decodeURIComponent(p[1]) : NAME[key] || decodeURIComponent(key)});
      if (key === "project") tabs = tabs.filter((x) => x.h !== "#project");   // the bare list redirects to a session
      tabs = tabs.slice(-8); store("dk-tabs", tabs);
    }
    drawTabs(); drawExplorer(); sync();
  }

  // Cheap and idempotent: runs after every re-render of the app's own DOM.
  function sync() {
    const {key} = route(), on = ACT[key] || key;
    root.dataset.dkRoute = key;
    root.dataset.dkBar = getComputedStyle(document.getElementById("tabbar")).display === "none" ? "0" : "1";
    for (const b of document.querySelectorAll("[data-act]")) b.classList.toggle("on", b.dataset.act === on || key === "settings" && b.dataset.act === "all");
    const n = document.querySelector("#top .bellb .bcnt")?.textContent || "";
    for (const b of document.querySelectorAll(".dk-n")) { if (b.textContent !== n) b.textContent = n; b.hidden = !n; }
    const home = document.querySelector("#view > .home");
    if (home && items.length && !document.getElementById("dk-work")) {
      const w = document.createElement("div"); w.id = "dk-work"; w.innerHTML = workTable(); home.querySelector("h1.greet").after(w);
    }
    const who = document.querySelector(".pj-conv .pj-agw")?.textContent.trim().split(" ")[0];
    if (who) root.style.setProperty("--dk-who", JSON.stringify(who));
    root.style.setProperty("--dk-topw", document.getElementById("top").offsetWidth + "px");
    drawDet(); drawProps(); drawPv();
    for (const n of document.querySelectorAll(".pj-sgh .nm:not([title])")) n.title = n.textContent;
    // Item: the pane and the phone preview follow the shape of the file on show.
    const files = document.getElementById("sgrid"), shots = document.querySelectorAll("#stage .sl img");
    const im = shots[files ? [...files.children].findIndex((b) => b.classList.contains("on")) : 0] || shots[0];
    if (files) files.parentElement.dataset.dkN = files.children.length;
    if (im?.naturalWidth) root.style.setProperty("--dk-ar", (im.naturalWidth / im.naturalHeight).toFixed(3)); else root.style.removeProperty("--dk-ar");
    if (key === "inbox") drawExplorer();
    crumb(document.querySelector(".pj-conv .pj-nth"), "#project", NAME.project);
    crumb(key === "item" ? document.getElementById("top") : null, "#lib", NAME.lib);
    crumb(document.querySelector(".setmenu"), "#all", NAME.all);
    // Settings: one table. The categories are its group rows and the open one's page sits right under its row.
    const set = document.querySelector(".setmodal");
    if (!set) return;
    if (!document.getElementById("dk-setq")) {
      const q = document.createElement("input"); q.id = "dk-setq"; q.type = "search"; q.placeholder = t("설정 검색", "Search settings"); q.setAttribute("aria-label", q.placeholder);
      const h = document.createElement("div"); h.id = "dk-seth"; h.innerHTML = `<span>${t("설정", "Setting")}</span><span>${t("값", "Value")}</span><span>${t("설명", "Description")}</span>`;
      set.prepend(q, h);
    }
    set.querySelectorAll(".setmi").forEach((b, n) => { b.style.order = 2 * n; if (b.classList.contains("on")) set.querySelector("#setpage").style.order = 2 * n + 1; });
    const q = document.getElementById("dk-setq").value.trim().toLowerCase();
    for (const r of set.querySelectorAll("#setpanel .srow")) r.classList.toggle("dk-off", !!q && !r.textContent.toLowerCase().includes(q));
  }

  // Runs before the app re-renders the menu: pressing the open settings category folds it, any other press opens.
  addEventListener("click", (e) => {
    const mi = e.target.closest(".setmi");
    if (mi) root.toggleAttribute("data-dk-shut", mi.classList.contains("on") && !root.hasAttribute("data-dk-shut"));
  }, true);
  addEventListener("click", (e) => {
    const b = e.target.closest("#dk-title [data-hist],#dk-tabs [data-dk-close],#dk-exp [data-fold],#dk-work [data-fold],[data-dk-tab],[data-dk-press],[data-dk-sec]"); if (!b) return;
    if (b.dataset.hist) return history.go(+b.dataset.hist);
    if (b.dataset.dkTab) { detTab = b.dataset.dkTab; return drawDet(); }
    if (b.dataset.dkPress) return document.querySelector(b.dataset.dkPress).click();
    if (b.dataset.dkSec) { e.preventDefault(); return document.querySelectorAll("#view > .card")[+b.dataset.dkSec].scrollIntoView({block: "start"}); }
    if (b.dataset.fold) {
      const id = b.dataset.fold; closed.has(id) ? closed.delete(id) : closed.add(id); store("dk-closed", [...closed]);
      drawExplorer(); document.getElementById("dk-work")?.remove(); return sync();
    }
    const gone = tabs.splice(+b.dataset.dkClose, 1)[0]; store("dk-tabs", tabs);
    if (gone.h === (location.hash || "#home")) location.hash = (tabs[tabs.length - 1] || {h: "#home"}).h; else drawTabs();
  });
  addEventListener("input", (e) => { if (e.target.id === "dk-setq") sync(); });
  addEventListener("pointerover", pick);
  addEventListener("focusin", pick);
  addEventListener("load", (e) => { if (e.target.closest?.("#stage")) sync(); }, true);
  addEventListener("hashchange", visit);
  let queued = false;
  new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(() => { queued = false; sync(); }); } })
    .observe(document.body, {childList: true, subtree: true});

  visit();
  fetch("/api/items").then((r) => r.json()).then((d) => { items = d.sort((a, b) => (a.at < b.at ? 1 : -1)); drawTabs(); drawExplorer(); sync(); });
  fetch("/api/sessions").then((r) => r.json()).then((d) => { sessions = d.sessions.filter((x) => !x.archived && x.project).sort((a, b) => (a.last < b.last ? 1 : -1)); drawExplorer(); });
  Promise.all([fetch("/api/health").then((r) => r.ok, () => false), fetch("/api/usage").then((r) => r.json(), () => ({}))]).then(([ok, u]) => {
    const pct = (n, w) => (w ? ` · ${n} ${Math.round(w.pct)}%` : "");
    sb.innerHTML = `<span class="${ok ? "ok" : "bad"}"><i></i>${ok ? t("연결됨", "Connected") : t("연결 끊김", "Offline")}</span><span>${esc((pct("Claude 5h", u.claude_rate?.five_hour) + pct("7d", u.claude_rate?.seven_day) + pct("Codex 7d", u.codex_rate?.seven_day)).slice(3))}</span>`;
  });
})();
