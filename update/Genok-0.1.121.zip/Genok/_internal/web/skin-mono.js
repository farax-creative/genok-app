// Shell changes of the mono style. Runs only when this style is the one picked at page load.
// The rail, the tab bar and the icon toolbar are gone; one word ("메뉴") opens a full-screen text
// index of every destination, and icon-only buttons are shown as their own labels.
(() => {
  const H = document.documentElement, en = (H.lang || "").startsWith("en");
  const T = en ? { menu: "Menu", back: "Back", close: "Close", reload: "Reload", fwd: "Forward", all: "Everything else", list: "Sessions", filt: "Filter", prev: "Previous", next: "Next" }
    : { menu: "메뉴", back: "뒤로", close: "닫기", reload: "새로고침", fwd: "앞으로", all: "그 밖의 화면", list: "세션 목록", filt: "필터", prev: "이전", next: "다음" };
  const PLACES = en
    ? [["home", "Home"], ["project", "Chats"], ["lib", "Results"], ["inbox", "Alerts"], ["depts", "Departments"], ["usage", "Usage"], ["search", "Search"], ["settings", "Settings"]]
    : [["home", "홈"], ["project", "대화"], ["lib", "결과물"], ["inbox", "알림"], ["depts", "부서"], ["usage", "사용량"], ["search", "검색"], ["settings", "설정"]];
  // A page that lives under one of the index lines.
  const UNDER = { item: "lib", dept: "depts", all: "settings" };
  const esc = (s) => s.replace(/[&<>"]/g, (c) => "&#" + c.charCodeAt(0) + ";");
  const text = (sel) => (document.querySelector(sel) || {}).textContent || "";

  const bar = document.createElement("div");
  bar.id = "mono-bar";
  bar.innerHTML = `<button id="mono-menu" aria-haspopup="dialog">${T.menu}</button><button id="mono-back">${T.back}</button><button id="mono-list">${T.list}</button><span id="mono-place"></span>`;
  const index = document.createElement("div");
  index.id = "mono-index"; index.setAttribute("role", "dialog"); index.setAttribute("aria-modal", "true"); index.setAttribute("aria-label", T.menu);
  document.body.append(bar, index);

  const place = () => {
    const k = location.hash.slice(1).split(/[/?]/)[0] || "home", at = UNDER[k] || k;
    H.dataset.moAt = k;
    bar.querySelector("#mono-place").textContent = (PLACES.find((p) => p[0] === at) || ["", ""])[1];
    return at;
  };

  // Counts are read off the app's own (hidden) rail, tab bar and bell, so nothing is fetched twice.
  const count = (k) => (k === "inbox" ? text(".bellb .bcnt")
    : text(`#rail [data-go="${k}"] small.cnt`) || text(`#tabbar [data-go="${k}"] .tcnt`)).trim();

  const open = () => {
    const at = place(), lines = PLACES.slice();
    // Screens the rail holds beyond the fixed ones (extensions, routines, ...).
    for (const b of document.querySelectorAll("#rail .it[data-go]")) {
      if (!lines.some((p) => p[0] === b.dataset.go)) lines.push([b.dataset.go, text(`#rail .it[data-go="${b.dataset.go}"] .mn`).trim()]);
    }
    lines.push(["all", T.all]);
    index.innerHTML = `<div class="mo-ix"><button class="mo-x" data-do="close">${T.close}</button><nav>`
      + lines.map(([k, n]) => `<button data-k="${esc(k)}"${k === at ? ' aria-current="page"' : ""}><span>${esc(n)}</span><b>${esc(count(k))}</b></button>`).join("")
      + `</nav><div class="mo-ft"><button data-do="back">${T.back}</button><button data-do="fwd">${T.fwd}</button><button data-do="reload">${T.reload}</button></div></div>`;
    index.classList.add("on");
    index.querySelector('[aria-current], nav button').focus();
  };
  const close = () => { index.classList.remove("on"); index.innerHTML = ""; };

  // Go through the app's own control when there is one, so search, the bell and the rest behave as they do there.
  const go = (k) => {
    const own = document.querySelector(`#rail [data-go="${k}"], #tabbar [data-go="${k}"], .top [data-go="${k}"]`);
    if (own) own.click(); else location.hash = k;
  };

  bar.addEventListener("click", (e) => {
    if (e.target.id === "mono-menu") open();
    if (e.target.id === "mono-back") history.back();
    if (e.target.id === "mono-list") H.toggleAttribute("data-mo-list");
  });
  index.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    const act = b.dataset.do;
    close();
    // Focus goes back to the word that opened the index; a screen that wants it (search) takes it from there.
    document.getElementById("mono-menu").focus();
    if (b.dataset.k) go(b.dataset.k);
    else if (act === "back") history.back();
    else if (act === "fwd") history.forward();
    else if (act === "reload") location.reload();
  });
  addEventListener("keydown", (e) => {
    if (!index.classList.contains("on")) return;
    if (e.key === "Escape") { e.stopPropagation(); close(); document.getElementById("mono-menu").focus(); }
    if (e.key === "Tab") {
      // The index is a dialog: Tab turns round at its two ends.
      const all = index.querySelectorAll("button"), edge = e.shiftKey ? all[0] : all[all.length - 1];
      if (document.activeElement === edge) { e.preventDefault(); (e.shiftKey ? all[all.length - 1] : all[0]).focus(); }
    }
  }, true);
  addEventListener("hashchange", () => { H.removeAttribute("data-mo-list"); place(); });
  // Picking a session in the list (even the open one) shows the conversation again; the library's
  // one word shows the filters the PC column no longer keeps in view.
  document.addEventListener("click", (e) => {
    if (e.target.closest(".pj-srow")) H.removeAttribute("data-mo-list");
    if (e.target.id === "mono-filt") H.toggleAttribute("data-mo-filt");
    // The file line steps with the app's own previous/next buttons.
    if (e.target.dataset.moStep) document.querySelector(".snav." + e.target.dataset.moStep).click();
  });
  place();

  // Icon-only buttons become their label. The app re-renders freely, so newcomers are marked once per frame.
  let queued = false;
  const words = () => {
    queued = false;
    for (const b of document.querySelectorAll(":is(button, a, [role=button])[aria-label]:not([data-mo])")) {
      b.dataset.mo = !b.textContent.trim() && b.querySelector("svg") && b.getAttribute("aria-label").length <= 12 ? "w" : "";
    }
    const sbar = document.querySelector(".sbar");
    if (sbar && document.querySelector(".snav") && !sbar.querySelector(".mo-step")) {
      sbar.insertAdjacentHTML("beforeend", `<button class="mo-step" type="button" data-mo-step="l">${T.prev}</button><button class="mo-step" type="button" data-mo-step="r">${T.next}</button>`);
    }
    const tool = document.querySelector(".ltool");
    if (tool && !tool.querySelector("#mono-filt")) tool.insertAdjacentHTML("beforeend", `<button id="mono-filt" type="button">${T.filt}</button>`);
  };
  new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(words); } }).observe(document.body, { childList: true, subtree: true });
  words();
})();
