// Shell changes of the paper style. Runs only when this style is the one picked at page load.
// The app's menu rail and tab bar are replaced by one drawer (always open on a desktop, a full-height
// fading sheet on a phone) and the home page becomes a start screen with a composer and a few chips.
// Navigation goes through location.hash; everything else is a click on the app's own (hidden) button.
(() => {
  const root = document.documentElement;
  // Paper is one cream page with dark ink whatever the theme option says; the app's own light-theme
  // repairs (code blocks, signal colours) key on data-theme, so the attribute is held at "light" while this style runs.
  const light = () => { if (root.dataset.theme !== "light") root.dataset.theme = "light"; };
  light(); new MutationObserver(light).observe(root, {attributes: true, attributeFilter: ["data-theme"]});
  const T = (ko, en) => (root.lang || "ko").startsWith("en") ? en : ko;
  const wideQ = matchMedia("(min-width:1024px),(min-width:721px) and (pointer:fine)");
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
  const svg = (d) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {menu: svg('<path d="M4 8h16M4 16h10"/>'), pen: svg('<path d="M12 5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-6"/><path d="M18.4 3.6a2 2 0 0 1 2.8 2.8L12 15.6l-3.6.8.8-3.6z"/>'),
    x: svg('<path d="M6 6l12 12M18 6L6 18"/>'), up: svg('<path d="M12 19V5M6 11l6-6 6 6"/>')};

  const LINKS = [["home", T("홈", "Home")], ["lib", T("결과물", "Results")], ["inbox", T("알림", "Inbox")], ["dept", T("부서", "Departments")],
    ["usage", T("사용량", "Usage")], ["search", T("검색", "Search")], ["project", T("모든 대화", "All chats")], ["all", T("전체 메뉴", "Everything")]];
  const drawer = document.createElement("aside");
  drawer.id = "pp-drawer"; drawer.setAttribute("aria-label", T("메뉴", "Menu"));
  drawer.innerHTML = `<div class="pp-dh"><b class="pp-brand">Genok</b><button class="pp-ib pp-x" data-pp-close aria-label="${T("메뉴 닫기", "Close menu")}">${I.x}</button></div>
    <button class="pp-new" data-pp-new>${I.pen}<span>${T("새 대화", "New chat")}</span></button>
    <nav class="pp-links">${LINKS.map(([k, n]) => `<a href="#${k}" data-pp-k="${k}">${n}${k === "inbox" ? '<i class="pp-n"></i>' : ""}</a>`).join("")}</nav>
    <div class="pp-recent" id="pp-recent"></div>
    <div class="pp-foot"><span class="pp-who"></span><button data-pp-click="#top [data-sync]">${T("새로고침", "Refresh")}</button><button data-pp-click="#top .connpill">${T("연결", "Agents")}</button><a href="#settings" data-pp-k="settings">${T("설정", "Settings")}</a>
      <span class="pp-ver"></span><button class="pp-upd" data-pp-click="#status [data-stupd]">${T("업데이트 확인", "Check for updates")}</button></div>`;
  const menuBtn = document.createElement("button");
  menuBtn.id = "pp-menu"; menuBtn.className = "pp-ib"; menuBtn.setAttribute("aria-label", T("메뉴 열기", "Open menu")); menuBtn.innerHTML = I.menu;
  const newBtn = document.createElement("button");
  newBtn.id = "pp-newtop"; newBtn.className = "pp-ib"; newBtn.dataset.ppNew = ""; newBtn.setAttribute("aria-label", T("새 대화", "New chat")); newBtn.innerHTML = I.pen;

  // ---- drawer: open state only matters on a phone; on a desktop it is a fixed column ----
  const setOpen = (on) => { root.classList.toggle("pp-open", on); menuBtn.setAttribute("aria-expanded", on);
    drawer.inert = !on && !wideQ.matches;
    const app = document.querySelector(".app"); if (app) app.inert = on && !wideQ.matches;   // the open sheet covers the page
    if (on) { loadRecent(); drawer.querySelector(".pp-x").focus(); } };
  wideQ.addEventListener("change", () => setOpen(false));

  // ---- recent conversations, newest first, grouped by day ----
  let rooms = [], roomsAt = 0;
  const roomHref = (r) => "#project/" + encodeURIComponent(r.name) + "/" + r.sid;
  const roomTitle = (r) => r.named || r.title || r.name;
  const drawRecent = () => {
    const day = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(), today = day(new Date()), groups = new Map();
    for (const r of rooms.slice(0, 30)) { const t = day(new Date(r.at));
      const g = t >= today ? T("오늘", "Today") : t >= today - 864e5 ? T("어제", "Yesterday") : T("이전", "Earlier");
      groups.set(g, (groups.get(g) || "") + `<a href="${esc(roomHref(r))}"><span>${esc(roomTitle(r))}</span></a>`); }
    drawer.querySelector("#pp-recent").innerHTML = [...groups].map(([g, h]) => `<h3>${g}</h3>${h}`).join("");
    mark(); homeNote();
  };
  // Offline or mid-restart the list simply keeps what it showed last.
  const loadRecent = () => { if (Date.now() - roomsAt < 30000) return; roomsAt = Date.now();
    fetch("/api/project/rooms").then((r) => r.json()).then((d) => { rooms = (d.rooms || []).filter((r) => r.sid && r.at).sort((a, b) => a.at < b.at ? 1 : -1); drawRecent(); }).catch(() => {}); };

  // ---- where we are: lights the drawer link and tells the CSS which top bar to draw ----
  const mark = () => { const h = location.hash || "#home", k = h.slice(1).split("/")[0];
    root.dataset.ppAt = k;
    root.dataset.ppTop = (h.includes("/") && k !== "project") || k === "settings" ? "sub" : "main";   // pages with their own back button keep it
    for (const a of drawer.querySelectorAll("a")) { const on = a.dataset.ppK ? a.dataset.ppK === k && (k !== "project" || !h.includes("/") || root.classList.contains("pp-list")) : decodeURIComponent(a.hash) === decodeURIComponent(h);
      if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); } };
  addEventListener("hashchange", () => { setOpen(false); mark(); loadRecent(); });

  // ---- a new chat is the app's own new-session button on the chat page ----
  let wantNew = false, draft = "";
  const afterRender = () => {
    const nb = wantNew && document.querySelector("[data-newsess]"); if (nb) { wantNew = false; nb.click(); }
    const ta = draft && location.hash.includes("/") && document.querySelector("#pj-ta");
    if (ta) { ta.value = draft; draft = ""; ta.dispatchEvent(new Event("input", {bubbles: true})); ta.focus(); }
    drawer.querySelector(".pp-who").textContent = D.profile_name || "";   // D: the app's loaded data
    drawer.querySelector(".pp-n").textContent = document.querySelector("#top .bcnt")?.textContent || "";
    drawer.querySelector(".pp-ver").textContent = document.querySelector("#status span")?.textContent || "";   // the status strip is not drawn; its version and update check live here
    drawer.querySelector(".pp-upd").hidden = !document.querySelector("#status [data-stupd]");
    home(); lib();
  };
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-pp-new],[data-pp-close],[data-pp-click],[data-pp-chip],[data-pp-filters],#pp-menu,#pp-drawer a"); if (!t) return;
    if ("ppFilters" in t.dataset) return t.setAttribute("aria-expanded", root.classList.toggle("pp-filters"));
    if (t.id === "pp-menu") return setOpen(true);
    if ("ppClose" in t.dataset) { setOpen(false); return menuBtn.focus(); }
    setOpen(false);
    // "All chats" shows the app's full list beside the open conversation on a desktop; pressing it again puts it away
    if (t.matches("a")) { root.classList.toggle("pp-list", t.dataset.ppK === "project" && !root.classList.contains("pp-list")); return mark(); }
    if ("ppNew" in t.dataset) { wantNew = true; if (location.hash === "#project") afterRender(); else location.hash = "#project"; }
    else if (t.dataset.ppClick) document.querySelector(t.dataset.ppClick)?.click();
    else document.querySelectorAll(HOME_SRC)[t.dataset.ppChip]?.click();
  });
  addEventListener("keydown", (e) => { if (e.key === "Escape" && root.classList.contains("pp-open")) { setOpen(false); menuBtn.focus(); } });

  // ---- home: a composer and a few chips in place of the dashboard stack ----
  // The chips are the app's own rows (sessions at work, results waiting); a chip clicks its row.
  const HOME_SRC = ".home .hwork .row, #homerec .hlead, #homerec .hrow:not(.hrest)";
  const homeNote = () => { const n = document.querySelector("#pp-ask .pp-note"); if (!n) return;
    n.textContent = rooms[0] ? T(`"${roomTitle(rooms[0])}" 대화에 이어서 씁니다`, `Continues in "${roomTitle(rooms[0])}"`) : "";
    // a desktop has no drawer column; its recent conversations are the contents list under the composer
    document.querySelector("#pp-ask .pp-toc").innerHTML = rooms.slice(0, 7).map((r) => `<li><a href="${esc(roomHref(r))}"><span>${esc(roomTitle(r))}</span><i></i><time>${new Date(r.at).toLocaleDateString(root.lang || "ko", {month: "short", day: "numeric"})}</time></a></li>`).join(""); };
  const home = () => {
    const g = document.querySelector("#view .home .greet"); if (!g) return;
    let box = document.getElementById("pp-ask");
    if (!box || !box.isConnected) {
      box = document.createElement("form"); box.id = "pp-ask";
      box.innerHTML = `<div class="pp-box"><textarea rows="2" aria-label="${T("무엇을 맡길까요?", "What should we work on?")}" placeholder="${T("무엇을 맡길까요?", "What should we work on?")}"></textarea>
        <button class="pp-send" aria-label="${T("대화로 가져가기", "Take it to the chat")}">${I.up}</button></div><p class="pp-note"></p><div class="pp-chips"></div><ol class="pp-toc" aria-label="${T("최근 대화", "Recent chats")}"></ol>`;
      g.after(box); homeNote();
    }
    // a narrow screen breaks the greeting after the name, not inside the phrase
    if (!g.querySelector("br") && g.innerHTML.includes(", ")) g.innerHTML = g.innerHTML.replace(", ", ", <br>");
    const rows = [...document.querySelectorAll(HOME_SRC)].map((el, i) => ({i, work: el.matches(".row"), t: el.querySelector(".htt, .t")?.textContent.trim() || ""})).filter((r) => r.t);
    const pick = [...rows.filter((r) => r.work).slice(0, 2), ...rows.filter((r) => !r.work)].slice(0, 4);
    const html = pick.map((r) => `<button type="button" data-pp-chip="${r.i}"><small>${r.work ? T("이어서", "Continue") : T("확인", "Review")}</small><span>${esc(r.t)}</span></button>`).join("");
    const chips = box.querySelector(".pp-chips"); if (chips.dataset.sig !== html) { chips.dataset.sig = html; chips.innerHTML = html; }
  };
  // ---- results on a phone: one quiet line (what is shown, the filters behind a word) in place of the control rows ----
  const lib = () => {
    const on = document.querySelector("#libg .lstat button.on"); if (!on) return;
    let line = document.getElementById("pp-libline");
    if (!line) {
      line = document.createElement("p"); line.id = "pp-libline";
      line.innerHTML = `<span></span><button data-pp-filters aria-expanded="${root.classList.contains("pp-filters")}">${T("필터", "Filters")}</button><button data-pp-click='#view > .seg.rs-sw [data-go="storage"]'>${T("용량", "Storage")}</button>`;
      document.getElementById("view").prepend(line);
    }
    const s = on.textContent.trim().replace(/\s+/g, " "); if (line.firstChild.textContent !== s) line.firstChild.textContent = s;
  };
  document.addEventListener("submit", (e) => { if (e.target.id !== "pp-ask") return; e.preventDefault();
    draft = e.target.querySelector("textarea").value.trim(); location.hash = rooms[0] ? roomHref(rooms[0]) : "#project"; });
  document.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.target.closest?.("#pp-ask textarea")) { e.preventDefault(); e.target.form.requestSubmit(); } });

  addEventListener("DOMContentLoaded", () => {
    document.body.append(drawer, menuBtn, newBtn);
    setOpen(false); mark(); loadRecent();
    // The app redraws #view and #top whenever its data changes; our pieces are put back after each redraw.
    new MutationObserver(afterRender).observe(document.getElementById("main"), {childList: true, subtree: true});
  });
})();
