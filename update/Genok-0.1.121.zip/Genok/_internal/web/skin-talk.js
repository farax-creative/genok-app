// Shell changes of the talk style. Runs only when this style is the one picked at page load.
// A messenger shell: its own four destinations (friends, chats, files, more), chats as the first
// screen, a one-row composer whose extras sit behind a plus button. Navigation goes through the
// app's own [data-go] handling and the hash; nothing here writes to the server.
(() => {
  "use strict";
  const en = (document.documentElement.lang || "").startsWith("en");
  const T = (ko, e) => (en ? e : ko);
  const $ = (q, r = document) => r.querySelector(q);

  // The app opens on the chat list, not on the dashboard.
  if (location.hash.length < 2) location.replace("#project");

  const TABS = [
    { go: "depts", ko: "친구", en: "Friends", own: ["depts", "dept"] },
    { go: "project", ko: "채팅", en: "Chats", own: ["project", "sessions"] },
    { go: "lib", ko: "보관함", en: "Files", own: ["lib", "item", "storage"] },
    { go: "all", ko: "더보기", en: "More", own: [] },
  ];
  const segOf = () => location.hash.slice(1).split(/[/?]/)[0];
  const tabOf = () => {
    const seg = segOf();
    return (TABS.find((t) => t.own.includes(seg)) || TABS[3]).go;
  };

  const nav = document.createElement("nav");
  nav.id = "tk-nav";
  nav.setAttribute("aria-label", T("메뉴", "Menu"));
  nav.innerHTML = TABS.map((t) =>
    `<button type="button" data-go="${t.go}"><i class="tk-ic"></i><span>${T(t.ko, t.en)}</span><b class="tk-n" hidden></b></button>`).join("")
    // Desktop only (CSS): search and settings at the foot of the rail.
    + [["search", "search", T("검색", "Search")], ["settings", "gear", T("설정", "Settings")]]
      .map(([go, i, n]) => `<button type="button" class="tk-foot" data-go="${go}" aria-label="${n}" title="${n}"><i class="tk-ic" data-i="${i}"></i></button>`).join("");
  document.body.appendChild(nav);

  // Extras of the chat composer, opened from the plus button.
  const menu = document.createElement("div");
  menu.id = "tk-menu";
  menu.hidden = true;
  menu.setAttribute("role", "menu");
  menu.innerHTML = [["#pj-clip", "photo", T("사진 · 파일", "Photo · file")], [".pj-mbtn", "model", T("모델 · 추론 수준", "Model · effort")],
    ["#pj-mic", "mic", T("말로 입력", "Dictate")], ["[data-chg]", "sync", T("변경 내역", "Changes")],
    ["[data-bglog]", "box", T("화면 기록", "Screen log")], ["#pj-side [data-fold=side]", "people", T("옆 패널", "Side panel")]]
    .map(([q, k, n]) => `<button type="button" role="menuitem" data-tk-do="${q}"><i class="tk-ic" data-i="${k}"></i><span>${n}</span></button>`).join("");
  document.body.appendChild(menu);

  const setText = (el, s) => { if (el && el.textContent !== s) el.textContent = s; };
  const setCount = (b, s) => { setText(b, s); if (b.hidden !== !s) b.hidden = !s; };
  let bell = "";

  const plus = (box, kind) => {
    if (!box || $(".tk-plus", box)) return;
    const b = document.createElement("button");
    b.type = "button"; b.className = "tk-plus press"; b.dataset.tkPlus = kind;
    b.setAttribute("aria-label", T("더 보기", "More"));
    box.appendChild(b);
  };

  // A button that shows or hides a group of the app's own controls (body[data-tk-<key>]).
  const toggle = (host, key, label, first) => {
    if (!host || $(`:scope > [data-tk-tog="${key}"]`, host)) return;
    const b = document.createElement("button");
    b.type = "button"; b.className = "tk-tog press"; b.dataset.tkTog = key;
    b.setAttribute("aria-label", label); b.title = label;
    if (first) host.prepend(b); else host.appendChild(b);
  };
  // A folder or address used as a group name reads as its last part: "c-users-me-documents-shop-site" -> "shop-site".
  const short = (s) => {
    const path = s.match(/(?:^|-)[a-z]-users-[^-]+(?:-(?:documents|desktop|downloads))?(?:-|$)/);
    if (path) return s.slice(path.index + path[0].length).split("-").slice(-2).join("-") || s.slice(0, path.index) || s;
    const url = s.match(/^https?-(.+?)(?:-https?-.*)?$/);
    return url ? url[1] : s;
  };
  const LIB = [["all", "전체", "All"], ["pending", "확인 필요", "To review"], ["finished", "완료", "Done"]];
  let libFirst = true;
  const lib = (view) => {
    const stat = $(".lstat", view);
    if (!stat || !$(":scope > .ltool", view)) return;
    let bar = $(":scope > .tk-lbar", view);
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "tk-lbar";
      bar.innerHTML = `<b class="tk-lt">${T("보관함", "Files")}</b><span class="tk-ltabs" role="tablist">`
        + LIB.map(([k, ko, e]) => `<button type="button" class="press" role="tab" data-lib="${k}">${T(ko, e)}<em class="num"></em></button>`).join("") + "</span>";
      view.prepend(bar);
      toggle(bar, "libf", T("필터", "Filter"));
    }
    const on = $(".on[data-lib]", stat);
    // Opens on everything, like a media drawer; the finer states stay in the filter panel.
    if (libFirst && on && !LIB.some(([k]) => k === on.dataset.lib)) { libFirst = false; $('[data-lib="all"]', stat).click(); return; }
    libFirst = false;
    for (const b of $(".tk-ltabs", bar).children) {
      const src = $(`[data-lib="${b.dataset.lib}"]`, stat);
      const isOn = !!on && on.dataset.lib === b.dataset.lib;
      if (b.classList.contains("on") !== isOn) b.classList.toggle("on", isOn);
      const n = src && $("em", src);
      setText(b.lastChild, n ? n.textContent.trim() : "");
    }
  };

  const MORE = [
    { a: 'data-go="home"', i: "home", ko: "오늘", en: "Today" },
    { a: 'data-go="inbox"', i: "bell", ko: "알림", en: "Alerts", n: 1 },
    { a: 'data-go="search"', i: "search", ko: "검색", en: "Search" },
    { a: 'data-go="settings"', i: "gear", ko: "설정", en: "Settings" },
    { a: "data-sync", i: "sync", ko: "새로고침", en: "Refresh" },
    // Presses the app's own update button; its version text shows under the label.
    { a: "data-tk-upd hidden", i: "down", ko: "업데이트 확인", en: "Check for updates", v: 1 },
  ];
  const tiles = (page) => {
    if (!page || $(".tk-tiles", page)) return;
    const d = document.createElement("div");
    d.className = "tk-tiles";
    d.innerHTML = MORE.map((m) =>
      `<button type="button" class="press" ${m.a}><i class="tk-ic" data-i="${m.i}"></i><span>${T(m.ko, m.en)}</span>${m.v ? "<small></small>" : ""}${m.n ? '<b class="tk-n" hidden></b>' : ""}</button>`).join("");
    const top = $(".alltop", page);
    if (top) top.after(d); else page.prepend(d);
  };

  const sync = () => {
    const at = tabOf();
    for (const b of nav.children) {
      const on = b.dataset.go === at && !b.classList.contains("tk-foot");
      if (b.classList.contains("on") !== on) b.classList.toggle("on", on);
    }
    const unread = $('#tabbar [data-go="project"] .tcnt');
    setCount($('[data-go="project"] .tk-n', nav), unread ? unread.textContent.trim() : "");
    const bc = $("#top .bellb .bcnt");
    const ac = $('.alllinks [data-go="inbox"] b');
    if ($("#top .bellb")) bell = bc ? bc.textContent.trim() : "";
    else if (ac) bell = ac.textContent.trim();
    setCount($('[data-go="all"] .tk-n', nav), bell);

    // Tab titles in the messenger's own words.
    const seg = segOf();
    if (document.body.dataset.tkSeg !== seg) document.body.dataset.tkSeg = seg;
    const tab = TABS.find((t) => t.go === seg);
    if (seg === "inbox") {
      setText($("#top h1:not(.dt)"), T("Genok 알림", "Genok alerts"));
      setText($("#top [data-stack]"), T("하나씩 보기", "One by one"));
    }
    const view = $("#view");
    if (view) lib(view);
    toggle($(".pj-lhd"), "filt", T("필터", "Filter"));
    // A result's bar reads like a shared file: its name, then who sent it and when.
    const dt = $("#top h1.dt"), who = $(".detailcols.item .htitle p");
    if (dt && who) { const w = [...who.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").trim(); if (dt.dataset.tkSub !== w) dt.dataset.tkSub = w; }
    // A message with nothing to show is not drawn as an empty bubble.
    for (const m of document.querySelectorAll(".pj-msgs > .pj-msg:is(.claude, .user):not([data-tk-seen]), .pj-msgs > .pj-msg[data-tk-empty]")) {
      m.dataset.tkSeen = "1";
      if (m.textContent.trim() || $("img, video, pre, table", m)) delete m.dataset.tkEmpty; else m.dataset.tkEmpty = "1";
    }
    if (tab) setText($("#top h1:not(.dt)"), T(tab.ko, tab.en));
    setText($(".pj-lhd > b"), T("채팅", "Chats"));
    for (const n of document.querySelectorAll(".pj-sgh .nm")) setText(n, short(n.textContent));
    const ibt = $(".ibtabs");
    if (ibt && !ibt.dataset.tkTitle) ibt.dataset.tkTitle = T("Genok 알림", "Genok alerts");

    tiles($(".allpage"));
    const upd = $(".tk-tiles [data-tk-upd]"), ver = $("#status > span");
    if (upd) {
      const off = !$("#status [data-stupd]");
      if (upd.hidden !== off) upd.hidden = off;
      setText($("small", upd), ver ? ver.textContent.trim() : "");
    }
    toggle($(".detailcols.item .sbar"), "strip", T("파일 목록", "File list"));
    const tn = $(".tk-tiles .tk-n");
    if (tn) setCount(tn, bell);

    // Room header: one status line under the name, "typing" while the session works.
    const tx = $(".pj-nth .tx");
    if (tx) {
      const stl = $(".pj-stl");
      const busy = !!$(".pj-msgs > .pj-now.on") || !!(stl && stl.classList.contains("live"));
      const s = busy ? T("입력 중…", "typing…") : stl ? stl.textContent.trim() : "";
      if (tx.dataset.tkSt !== s) tx.dataset.tkSt = s;
      // The first character is the room's avatar; an emoji moves there instead of showing twice.
      const ch = [...tx.textContent.trim()][0] || "";
      const emo = /\p{Extended_Pictographic}/u.test(ch) ? "1" : "";
      if (tx.dataset.tkAv !== ch) tx.dataset.tkAv = ch;
      if ((tx.dataset.tkEmo || "") !== emo) tx.dataset.tkEmo = emo;
    }
    plus($(".pj-in .pj-box"), "chat");
    plus($(".cdk .cbox"), "item");
    if (!menu.hidden && !$(".pj-in .tk-plus")) menu.hidden = true;
  };

  let queued = false;
  const later = () => { if (queued) return; queued = true; requestAnimationFrame(() => { queued = false; sync(); }); };
  new MutationObserver(later).observe(document.body, { childList: true, subtree: true });
  addEventListener("hashchange", () => {
    menu.hidden = true;
    for (const k of ["tkTools", "tkFilt", "tkLibf", "tkStrip"]) delete document.body.dataset[k];
    later();
  });

  document.addEventListener("click", (e) => {
    const p = e.target.closest("[data-tk-plus]");
    if (p && p.dataset.tkPlus === "item") { document.body.dataset.tkTools = document.body.dataset.tkTools ? "" : "1"; return; }
    const tg = e.target.closest("[data-tk-tog]");
    if (tg) { const k = "tk" + tg.dataset.tkTog[0].toUpperCase() + tg.dataset.tkTog.slice(1); document.body.dataset[k] = document.body.dataset[k] ? "" : "1"; return; }
    if (p) {
      for (const it of menu.children) it.hidden = !$(it.dataset.tkDo);
      const r = p.getBoundingClientRect();
      menu.style.left = Math.max(8, r.left) + "px";
      menu.style.bottom = (innerHeight - r.top + 8) + "px";
      menu.hidden = !menu.hidden;
      return;
    }
    if (e.target.closest("[data-tk-upd]")) { $("#status [data-stupd]").click(); return; }
    const it = e.target.closest("[data-tk-do]");
    if (it) { menu.hidden = true; const t = $(it.dataset.tkDo); if (t) t.click(); return; }
    if (!menu.hidden) menu.hidden = true;
  });
  addEventListener("keydown", (e) => { if (e.key === "Escape") menu.hidden = true; });

  sync();
})();
