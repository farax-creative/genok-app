// Guided coach-mark tour over the real app, using the onboarding sample item. Replaces the old
// behaviour where "예시 열어보기" silently ended setup. It spotlights real elements (ring + dim +
// a "1 / N" bubble), walks one full review loop on the motion sample (v1 -> example notes -> send ->
// v2 -> confirm the fixes), then hands back to whoever started it. Comparing two versions is a detail
// feature and is left out of the basic walk (the v2 step only says where it lives).
// While it runs, only the control the current step asks for answers: everything outside the
// spotlight is behind the blocker strips, and inside it a capture-phase guard swallows the rest.
//
//   window.LOOP_TOUR.start({onExit})   run the tour; onExit(reason) fires on finish/skip
//   window.LOOP_TOUR_SECTION(el)        the 둘러보기 replay chips for the 일반 settings page
//
// It borrows v2.js's globals (tl, post, toast, esc, nav) by name, like the other feature scripts.
// Motion is a spring on the spotlight rect; prefers-reduced-motion gets a plain fade.
(function () {
  "use strict";

  const E = (s) => (window.esc ? esc(s) : String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c])));
  // t/d are thunks calling tl() with a literal key, so the i18n "every message is used" test sees each.
  // The sample's iid (project/item) is read from /api/onboard so nothing hard-codes its name; the
  // motion-graphic sample may rename it. It is resolved once, before the first step runs.
  let SAMPLE = "샘플/Genok 로고 타이틀";    // fallback until the API answers
  const REDUCE = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------------------------------------------------------------- styling
  const CSS = `
  .tour-layer{position:fixed;inset:0;z-index:9700;pointer-events:none;}
  /* Four blocker strips around the spotlight, so clicks LAND on the highlighted target (it stays
     interactive - drag/play/press) while everything else is caught. The block itself passes through. */
  .tour-block{position:fixed;inset:0;pointer-events:none;background:transparent;}
  .tour-mask{position:fixed;pointer-events:auto;background:transparent;}
  /* The hole is the target's box plus an even 4px (PAD), with the target's own corner radius + PAD;
     the 2px ring is drawn just outside it, so it hugs the target instead of floating off it. */
  .tour-hole{position:fixed;border-radius:12px;pointer-events:none;
    box-shadow:0 0 0 9999px rgba(8,8,8,.78);
    outline:2px solid var(--accent,#6ea8fe);outline-offset:0;
    background:rgba(255,255,255,0);opacity:0;transition:opacity .2s ease;}
  .tour-hole.on{opacity:1;}
  .tour-hole.glow{box-shadow:0 0 0 9999px rgba(8,8,8,.78),0 0 0 5px rgba(110,168,254,.22);}
  /* A second, small ring on the one control to press when the spotlight is wider than it (the play
     button under the video). It breathes so the eye finds it; reduced motion keeps it still. */
  .tour-tap{position:fixed;border-radius:8px;pointer-events:none;display:none;
    outline:2px solid var(--accent,#6ea8fe);outline-offset:2px;animation:tour-tap 1.6s ease-in-out infinite;}
  .tour-tap.on{display:block;}
  @keyframes tour-tap{0%,100%{box-shadow:0 0 0 0 rgba(110,168,254,.45);}50%{box-shadow:0 0 0 8px rgba(110,168,254,0);}}
  /* The bubble grows with the window (a 320px card read small on a large desktop window) and never
     exceeds the viewport minus 16px gutters on a phone. */
  .tour-bubble{position:fixed;pointer-events:auto;width:min(clamp(360px,24vw + 80px,520px),calc(100vw - 32px));
    --tb-bg:#232323;--tb-text:#f2f2f2;--tb-dim:#a0a0a6;--tb-line:#3a3a3a;--tb-btn:#ececec;--tb-btnfg:#141414;
    background:var(--tb-bg);color:var(--tb-text);border:1px solid var(--tb-line);border-radius:16px;
    word-break:keep-all;overflow-wrap:break-word;
    padding:clamp(18px,.8vw + 8px,24px) clamp(20px,.9vw + 9px,26px);
    box-shadow:0 12px 34px rgba(0,0,0,.5);opacity:0;
    transition:opacity .2s ease;}
  /* The bubble follows the app's theme; it appears in place (a fade, no slide). */
  html[data-theme="light"] .tour-bubble{--tb-bg:#fff;--tb-text:#17171a;--tb-dim:#5f5f67;--tb-line:#dadad6;--tb-btn:#17171a;--tb-btnfg:#fff;
    box-shadow:0 12px 34px rgba(0,0,0,.28);}
  .tour-bubble.on{opacity:1;}
  /* A fading-out bubble must not take clicks: a second 넘어가기 while the next step loads restarted it. */
  .tour-bubble:not(.on){pointer-events:none;}
  .tour-count{font-size:clamp(12.5px,.2vw + 10px,14px);color:var(--tb-dim);letter-spacing:.04em;margin:0 0 8px;font-variant-numeric:tabular-nums;}
  .tour-title{font-size:clamp(19px,.6vw + 12px,24px);font-weight:600;line-height:1.3;letter-spacing:-.015em;margin:0 0 8px;text-wrap:balance;}
  .tour-desc{font-size:clamp(15.5px,.45vw + 10px,18px);color:var(--tb-dim);line-height:1.55;margin:0 0 16px;text-wrap:pretty;}
  .tour-do{font-size:clamp(15.5px,.45vw + 10px,18px);line-height:1.55;color:var(--tb-dim);margin:0 0 16px;}
  .tour-row{display:flex;align-items:center;gap:8px;}
  .tour-sp{flex:1;}
  .tour-skip,.tour-back{background:none;border:0;color:var(--tb-dim);font:inherit;font-size:clamp(14px,.2vw + 11px,15px);cursor:pointer;padding:8px 2px;}
  .tour-skip:hover,.tour-back:hover{color:var(--tb-text);}
  .tour-next{background:var(--tb-btn);color:var(--tb-btnfg);border:0;border-radius:8px;font:inherit;font-size:clamp(14.5px,.25vw + 11px,16px);
    font-weight:600;cursor:pointer;padding:8px 20px;transition:transform .12s cubic-bezier(.22,1,.36,1),filter .12s;}
  .tour-next:hover{filter:brightness(1.05);}
  .tour-next:active{transform:scale(.97);}
  /* The corner version label sat on top of bottom-right targets ([세션에 보내기]); hide it meanwhile. */
  body.tour-on #status{visibility:hidden;}
  /* Replay chips in settings (plain text chips, refern style). */
  .tour-chips{display:flex;flex-wrap:wrap;gap:8px;margin:2px 0 4px;}
  .tour-chip{background:none;border:1px solid var(--line,#333);border-radius:999px;color:var(--fg,#f2f2f2);
    font:inherit;font-size:13px;cursor:pointer;padding:6px 16px;transition:border-color .15s;}
  .tour-chip:hover{border-color:var(--accent,#6ea8fe);}
  /* Agent-connect reminder on home. */
  .tour-remind{display:flex;align-items:center;gap:12px;}
  .tour-remind .tx{flex:1;min-width:0;}
  @media (prefers-reduced-motion:reduce){
    .tour-hole{transition:opacity .18s ease;outline-offset:2px;}
    .tour-bubble{transition:opacity .18s ease;}
    .tour-tap{animation:none;}
  }`;

  function injectCSS() {
    if (document.getElementById("tour-css")) return;
    const s = document.createElement("style");
    s.id = "tour-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }

  // ---------------------------------------------------------------- step definitions
  // sel: CSS selector of the element to spotlight (queried fresh each frame so it tracks re-renders).
  // prep: async, gets the app into the state where sel exists (navigate / open a tab).
  // advanceOn: for do-it-yourself steps - a selector; clicking it advances the tour (no 다음 button).
  // The story follows the motion sample (docs/tutorial-motion.md): v1 with three deliberate flaws
  // and three example notes (circle, pin, time) -> send them -> the demo session answers with v2 ->
  // compare -> 통과 -> approve.
  // The phone's tab click smooth-scrolls its card up under the header; the tour then scrolled it
  // back to clear the pinned player, so the page went down and up. Cancel that scroll in the same
  // frame (an instant scrollTo stops a smooth one) and let the step do its single scroll.
  const tab = async (k, sel) => { const b = document.querySelector(`#itabs [data-v="${k}"]`);
    if (b) { const y = window.scrollY; b.click(); window.scrollTo({top: y, behavior: "instant"}); }
    if (sel) await waitFor(sel); };
  const openSample = async (sel) => { if (typeof nav === "function" && decodeURIComponent(location.hash) !== "#item/" + SAMPLE) nav("item/" + SAMPLE); await waitFor(sel || "#itabs"); };
  // act: what the reader does to move on (no 다음 needed): {type: click|play|drag|draw|pin, sel}.
  // sel may be a function (the sample's iid is resolved at start). `then`: for a click that opens
  // another screen, a check that must hold before the tour moves on, so the next step starts on the
  // screen the reader opened themselves rather than one the tour switched to for them.
  // leave: undo whatever the step left switched on (a half-made drawing, a pin mode, a compare drag).
  const latest = () => { const b = document.querySelector(".tolatest"); if (b) { const y = window.scrollY; b.click(); window.scrollTo({top: y, behavior: "instant"}); } };
  // allow: the only controls inside the spotlight that answer during the step (nothing when absent).
  // also: a second element the spotlight grows to include (the play bar under the video).
  // tap: the control to press, ringed on its own when the spotlight is wider than it.
  // keys: plain keys the step lets through to the app (everything else is swallowed, see guard()).
  // proxy: a click on `from` presses `to` instead (the video itself does not play on a click).
  const STEPS = [
    {id: "card", t: () => tl("tour.s1.t"), h: () => tl("tour.h.card"),
     act: {type: "click", sel: () => `[data-item="${SAMPLE}"]`,
       then: () => decodeURIComponent(location.hash) === "#item/" + SAMPLE && !!document.querySelector("#itabs")},
     sel: () => `[data-item="${SAMPLE}"]`, allow: () => `[data-item="${SAMPLE}"]`,
     // A replay rebuilds the sample that the last walk deleted; home may not have heard of it yet.
     prep: async () => { const card = `[data-item="${SAMPLE}"]`;
       if (typeof nav === "function") nav("home"); await waitFor(card, 1200);
       if (!document.querySelector(card)) {
         try { if (typeof load === "function") await load(); if (typeof render === "function") render(); } catch (e) { /* keep going */ }
         await waitFor(card);
       } }},
    {id: "v1", t: () => tl("tour.v1.t"), h: () => tl("tour.h.play"),
     act: {type: "play", sel: "#stage"},
     sel: () => "#stage", also: ".media .sbar", roomBelow: 56, tap: ".media .fplay", allow: () => ".media .fplay", keys: [" "],
     proxy: {from: "#stage video", to: ".media .fplay"},
     prep: async () => { await openSample("#stage"); }},
    {id: "send", t: () => tl("tour.send.t"), h: () => tl("tour.h.send"),
     act: {type: "click", sel: "#cmsend"},
     sel: () => "#cmsend", allow: () => "#cmsend",
     prep: async () => { await openSample(); await tab("cm", "#cmsend"); }},
    {id: "v2", t: () => tl("tour.v2.t"), d: () => tl("tour.v2.d"),
     sel: () => "#vtl",
     prep: async () => {
       await openSample();
       // Skipped [세션에 보내기] with 넘어가기? Send the example notes for them, so the demo answer
       // (v2) still arrives instead of the tour idling ~6s on a version that never comes.
       // A real [세션에 보내기] press is already on its way: give it a moment before sending again.
       if (typeof render === "function") render();
       await waitFor('#vtlstrip [data-vt="v002"]', 1200);
       if (!document.querySelector('#vtlstrip [data-vt="v002"]')) {
         const cut = SAMPLE.indexOf("/");
         try { await post("/api/comments/send", {p: SAMPLE.slice(0, cut), i: SAMPLE.slice(cut + 1), v: "v001"}); }
         catch (e) { /* already sent */ }
       }
       // The item view does not re-render on its own until the next watch tick; nudge it.
       for (let k = 0; k < 12 && !document.querySelector('#vtlstrip [data-vt="v002"]'); k++) {
         if (typeof render === "function") render();
         await waitFor('#vtlstrip [data-vt="v002"]', 500);
       }
     }},
    // On a phone the pinned player leaves too little room for the whole list, so the ring goes on
    // the first fixed request (its two answer buttons) instead of a list cut off by the bottom bar.
    {id: "verify", t: () => tl("tour.s4.t"), h: () => tl("tour.h.verify"),
     act: {type: "click", sel: ".dyes,.dno,.dall"},
     sel: () => (window.innerWidth <= 520 ? ".card.dirs .dir.claimed" : ".card.dirs"), allow: () => ".dyes,.dno,.dall",
     prep: async () => { await openSample(); latest(); await waitFor(".card.dirs .dyes", 4000); }},
    {id: "done", t: () => tl("tour.s6.t"), d: () => tl("tour.s6.d"), center: true, last: true,
     sel: () => null, prep: async () => {}},
  ];

  function waitFor(sel, timeout = 2500) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        const el = document.querySelector(sel);
        if (el) return resolve(el);
        if (Date.now() - t0 > timeout) return resolve(null);
        setTimeout(tick, 50);
      };
      tick();
    });
  }

  // Like waitFor, but resolves only once a match is actually on screen: a nav/tab can render the
  // target a frame late (e.g. the phone's bottom bar after 내 차례), so existence is not enough.
  function waitVisible(sel, timeout = 2500) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        const el = visible(sel);
        if (el || Date.now() - t0 > timeout) return resolve(el || null);
        setTimeout(tick, 50);
      };
      tick();
    });
  }

  // ---------------------------------------------------------------- placement
  // Each step scrolls at most once, smoothly, and only when the target is not already comfortably on
  // screen. The old per-frame "keep it in view" nudging (scrollIntoView + a cover check fighting each
  // other and the sticky player) made the page bounce up and down and left rings under the header.
  const PAD = 4;                                   // even gap between the target and the ring
  const MARGIN = 24;                               // how far a target sits from any edge or bar
  const EDGE = 16, GAP = 14;                       // bubble: gutter to the window edge / to the ring

  // The nearest ancestor that scrolls on its own (the PC right panel, the phone sheet), or null for
  // the page itself.
  function scrollerOf(el) {
    for (let n = el && el.parentElement; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (/(auto|scroll)/.test(cs.overflowY) && n.scrollHeight > n.clientHeight + 1) return n;
    }
    return null;
  }

  // A target inside a fixed bar (the phone's tab bar or decision bar) never scrolls and is never
  // covered by another bar.
  function inFixed(el) {
    for (let n = el; n && n !== document.body; n = n.parentElement) if (getComputedStyle(n).position === "fixed") return true;
    return false;
  }

  // The vertical band a target can occupy without hiding under something that stays put while the
  // page scrolls: sticky headers and players above it, fixed bars below it (the phone's tab bar and
  // decision bar), and the edges of its own scrolling panel. Sticky bars are taken where they sit
  // once stuck, and only those that come before the target in the page (a sticky bar further down
  // never covers it). The bubble may still sit over these bars - they are dimmed.
  function safeBand(el) {
    const vh = window.innerHeight;
    let top = 0, bot = vh;
    if (!el) return {top, bot};
    if (inFixed(el)) return {top, bot};
    const r = el.getBoundingClientRect();
    for (const n of document.querySelectorAll("body *")) {
      const cs = getComputedStyle(n);
      if (cs.position !== "sticky" && cs.position !== "fixed") continue;
      if (n.contains(el) || el.contains(n) || n.closest(".tour-layer")) continue;
      if (cs.display === "none" || cs.visibility === "hidden" || +cs.opacity === 0) continue;
      const b = n.getBoundingClientRect();
      if (!b.width || !b.height || b.right <= r.left || b.left >= r.right) continue;   // not over the target's column
      let y0 = b.top;
      if (cs.position === "sticky") {
        const sp = scrollerOf(n), base = sp ? sp.getBoundingClientRect().top : 0;
        if (cs.top !== "auto") y0 = base + parseFloat(cs.top);
        else if (cs.bottom !== "auto") y0 = (sp ? sp.getBoundingClientRect().bottom : vh) - parseFloat(cs.bottom) - b.height;
        const before = !!(n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
        if ((y0 + b.height / 2 < vh / 2) !== before) continue;   // a top bar after the target / a bottom bar before it
      }
      if (b.height > vh * 0.75) continue;                           // a full-height column (the rail), not a bar
      if (y0 + b.height / 2 < vh / 2) top = Math.max(top, y0 + b.height);
      else bot = Math.min(bot, y0);
    }
    const sp = scrollerOf(el);
    if (sp) { const s = sp.getBoundingClientRect(); top = Math.max(top, s.top); bot = Math.min(bot, s.bottom); }
    if (bot - top < 80) return {top: 0, bot: vh};                  // bars cover nearly everything: ignore them
    return {top, bot};
  }

  // Resolves with the target once its box has stopped moving (a video loading its size, a tab
  // rendering late), so the one scroll below is computed from the final layout. The selector is
  // re-queried every tick: a re-render (최신 버전으로, a watch tick) swaps the element out, and a
  // detached element measures as an empty box at 0,0.
  function waitStable(sel, timeout = 1500) {
    return new Promise((resolve) => {
      if (!sel) return resolve(null);
      const t0 = Date.now();
      let last = null, same = 0;
      const tick = () => {
        const el = visible(sel), r = el ? el.getBoundingClientRect() : null;
        const k = r ? [r.left, r.top, r.width, r.height].map(Math.round).join() : "";
        same = k && k === last ? same + 1 : 0; last = k;
        if (same >= 3 || Date.now() - t0 > timeout) return resolve(el || null);
        setTimeout(tick, 60);
      };
      tick();
    });
  }

  // Resolves once the page and `sp` have stopped scrolling (a smooth scroll has landed).
  function waitScrollEnd(sp, timeout = 1200) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      let last = null, same = 0;
      const tick = () => {
        const k = window.scrollY + "," + (sp ? sp.scrollTop : 0);
        same = k === last ? same + 1 : 0; last = k;
        if (same >= 4 || Date.now() - t0 > timeout) return resolve();
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }

  // Can the bubble sit beside a target at `top`..`bottom` (viewport y) without touching it?
  function bubbleRoom(r, top, bottom) {
    const vw = document.documentElement.clientWidth || window.innerWidth, vh = window.innerHeight;
    const bw = bubble ? bubble.offsetWidth : 360, bh = bubble ? bubble.offsetHeight : 200;
    return top - PAD >= bh + GAP + EDGE || vh - bottom - PAD >= bh + GAP + EDGE
      || r.left - PAD >= bw + GAP + EDGE || vw - r.right - PAD >= bw + GAP + EDGE;
  }

  // Scroll the target into the comfortable band once: not at all when it is already there, else by
  // the smallest amount (its top at the band's top when it is taller than the band), preferring a
  // spot that leaves the bubble room on some side. The panel the target lives in scrolls first; the
  // page takes whatever the panel cannot.
  async function settleInView(el, roomBelow = 0) {
    if (!el || inFixed(el)) return;
    const band = safeBand(el), r = el.getBoundingClientRect();
    const lo = band.top + MARGIN, h = r.height;
    // Room asked for below the target (its controls) is kept only while the target still fits.
    const hi = band.bot - MARGIN - roomBelow >= lo + h ? band.bot - MARGIN - roomBelow : band.bot - MARGIN;
    let dy = 0;
    if (h > hi - lo || r.top < lo) dy = r.top - lo;
    else if (r.bottom > hi) dy = r.bottom - hi;
    if (h <= hi - lo && !bubbleRoom(r, r.top - dy, r.bottom - dy)) {
      // No side has room for the bubble where the target would land: try it at either end of the band.
      if (bubbleRoom(r, lo, lo + h)) dy = r.top - lo;
      else if (bubbleRoom(r, hi - h, hi)) dy = r.bottom - hi;
    }
    if (Math.abs(dy) < 2) return;
    const behavior = REDUCE() ? "auto" : "smooth";
    const sp = scrollerOf(el);
    let rest = dy;
    if (sp) {
      const want = Math.max(0, Math.min(sp.scrollHeight - sp.clientHeight, sp.scrollTop + rest));
      rest -= want - sp.scrollTop;
      sp.scrollTo({top: want, behavior});
    }
    if (Math.abs(rest) >= 1) window.scrollTo({top: Math.max(0, window.scrollY + rest), behavior});
    await waitScrollEnd(sp);
  }

  // ---------------------------------------------------------------- runtime
  let layer = null, hole = null, bubble = null, block = null, tapRing = null;
  let band = {top: 0, bot: 0};                     // the current step's safe band (see safeBand)
  let snap = false;                                // the page scrolled: move the ring with it, no spring
  let goSeq = 0;                                   // bumps on every go(); a stale go() stops early
  let raf = 0, rect = null, vel = null, target = null, curStep = -1, exiting = false;
  let onExit = null, keyH = null, actionH = null, resizeH = null, scrollH = null, guardOff = null, hideH = null;

  // The first match that is actually on screen: some controls exist twice (the PC side panel and
  // the phone's bottom bar) with one hidden per width.
  function visible(sel) {
    if (!sel) return null;
    for (const el of document.querySelectorAll(sel)) {
      const r = el.getBoundingClientRect();
      if (r.width || r.height) return el;
    }
    return null;
  }

  // Seed the spotlit video on a bright frame. preload="metadata" leaves it parked on a black lead-in
  // poster, so the highlight lands on a black rectangle instead of the video the step is talking about.
  // A paused video still sitting at the very start is nudged to ~88% (the sample's finished title).
  // Never touches a video the user has started playing or scrubbed.
  function brightenVideo(el) {
    if (!el) return;
    const v = (el.matches && el.matches("video")) ? el : (el.querySelector && el.querySelector("video"));
    if (!v) return;
    const seek = () => { try {
      if (v.paused && v.currentTime < 0.25 && isFinite(v.duration) && v.duration > 1) v.currentTime = v.duration * 0.88;
    } catch (e) { /* seeking may be disallowed; the poster just stays */ } };
    if (v.readyState >= 1) seek(); else v.addEventListener("loadedmetadata", seek, {once: true});
  }

  // The target's live box plus PAD on every side (the hole; the ring is drawn just outside it).
  // `also` (optional) is a second element the box grows to include.
  function measure(sel, also) {
    const el = visible(sel);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    let x0 = r.left, y0 = r.top, x1 = r.right, y1 = r.bottom;
    const ex = also ? visible(also) : null;
    if (ex) { const q = ex.getBoundingClientRect();
      x0 = Math.min(x0, q.left); y0 = Math.min(y0, q.top); x1 = Math.max(x1, q.right); y1 = Math.max(y1, q.bottom); }
    return {x: x0 - PAD, y: y0 - PAD, w: x1 - x0 + PAD * 2, h: y1 - y0 + PAD * 2};
  }

  // The small ring on the control to press, redrawn every frame with the spotlight.
  function applyTap(s) {
    if (!tapRing) return;
    const el = s && s.tap && hole && hole.classList.contains("on") ? visible(s.tap) : null;
    tapRing.classList.toggle("on", !!el);
    if (!el) return;
    const r = el.getBoundingClientRect();
    tapRing.style.left = r.left + "px"; tapRing.style.top = r.top + "px";
    tapRing.style.width = r.width + "px"; tapRing.style.height = r.height + "px";
  }

  // What is actually drawn: the hole cut to the viewport and the step's safe band, so the ring never
  // runs off the window or tucks under the header; the part of a target hidden under a bar stays dim.
  // The PAD margin itself may overlap a bar's edge (a player pinned right under the header), so a
  // target that is fully visible keeps an even ring.
  function clip(r) {
    if (!r) return r;
    const vw = document.documentElement.clientWidth || window.innerWidth, vh = window.innerHeight;
    const x0 = Math.max(r.x, 1), x1 = Math.min(r.x + r.w, vw - 1);
    const y0 = Math.max(r.y, band.top - PAD, 1), y1 = Math.min(r.y + r.h, band.bot + PAD, vh - 1);
    return {x: x0, y: y0, w: Math.max(0, x1 - x0), h: Math.max(0, y1 - y0)};
  }

  function applyRect(r) {
    if (!hole || !r) return;
    const c = clip(r);
    hole.style.left = c.x + "px"; hole.style.top = c.y + "px";
    hole.style.width = c.w + "px"; hole.style.height = c.h + "px";
    applyMasks(c);
  }

  // Size the four blocker strips so they cover the whole viewport except the hole rect (the whole
  // highlighted target stays clickable and draggable). On a no-target / center step
  // (block.dataset.all === "1") the top strip covers everything.
  function applyMasks(r) {
    if (!block || block.children.length < 4) return;
    const vw = window.innerWidth, vh = window.innerHeight, m = block.children;
    const set = (el, x, y, w, h) => { el.style.left = x + "px"; el.style.top = y + "px";
      el.style.width = Math.max(0, w) + "px"; el.style.height = Math.max(0, h) + "px"; };
    if (block.dataset.all === "1" || !r) {
      set(m[0], 0, 0, vw, vh); set(m[1], 0, 0, 0, 0); set(m[2], 0, 0, 0, 0); set(m[3], 0, 0, 0, 0);
      return;
    }
    set(m[0], 0, 0, vw, r.y);                          // top
    set(m[1], 0, r.y + r.h, vw, vh - (r.y + r.h));     // bottom
    set(m[2], 0, r.y, r.x, r.h);                       // left
    set(m[3], r.x + r.w, r.y, vw - (r.x + r.w), r.h);  // right
  }

  // The ring follows the target's live box every frame (a tab rendering late, the player resizing,
  // draw mode). A layout change eases over with a critically-damped, interruptible spring; a scroll
  // moves the ring in lockstep with the page. It never scrolls the page itself.
  function loop() {
    raf = requestAnimationFrame(loop);
    const s = STEPS[curStep];
    const sel = s && !s.center && s.sel();
    const t = sel ? measure(sel, s.also) : null;
    if (t) target = t;
    applyTap(s);
    if (!target) return;
    if (!rect || snap || REDUCE()) { rect = {...target}; vel = {x: 0, y: 0, w: 0, h: 0}; snap = false; applyRect(rect); positionBubble(clip(rect)); return; }
    const resp = 0.3, damp = 1.0, dt = 1 / 60;
    const w = 2 * Math.PI / resp, k = w * w, f = 2 * damp * w;
    for (const key of ["x", "y", "w", "h"]) {
      const a = k * (target[key] - rect[key]) - f * vel[key];
      vel[key] += a * dt; rect[key] += vel[key] * dt;
      if (Math.abs(target[key] - rect[key]) < 0.3 && Math.abs(vel[key]) < 0.3) { rect[key] = target[key]; vel[key] = 0; }
    }
    applyRect(rect);
    positionBubble(clip(rect));
  }

  // Place the bubble so it NEVER overlaps the spotlit target (hard rule bubble ∩ target = ∅): pick a
  // side of the target that has room for the bubble, placing it fully outside on that axis, then clamp
  // the cross-axis inside the viewport. A right-panel target (its centre in the right 45%) prefers the
  // LEFT so the bubble sits over the dimmed player. With no room on any side, dock to the roomiest edge.
  function positionBubble(r) {
    if (!bubble) return;
    // clientWidth leaves out the page scrollbar, so the bubble never tucks under it.
    const vw = document.documentElement.clientWidth || window.innerWidth, vh = window.innerHeight;
    let edge = EDGE, gap = GAP;
    if (bubble.style.width) bubble.style.width = "";   // back to its natural width; narrowed below if needed
    let bw = bubble.offsetWidth, bh = bubble.offsetHeight;
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(v, hi));
    if (!r || !r.w || !r.h) {                         // no target: dock bottom-centre
      bubble.style.left = clamp((vw - bw) / 2, edge, vw - bw - edge) + "px";
      bubble.style.top = Math.max(edge, vh - bh - 24) + "px";
      return;
    }
    const room = {below: vh - (r.y + r.h), above: r.y, right: vw - (r.x + r.w), left: r.x};
    const fitsWith = () => ({below: room.below >= bh + gap + edge, above: room.above >= bh + gap + edge,
      right: room.right >= bw + gap + edge, left: room.left >= bw + gap + edge});
    let fits = fitsWith();
    // A big player can leave a side just short of room: tighten the gutters before ever overlapping.
    if (!Object.values(fits).some(Boolean)) { edge = 8; gap = 8; fits = fitsWith(); }
    // Still nothing (a player filling a wide window): narrow the bubble into the wider side column.
    const col = Math.max(room.left, room.right) - gap - edge;
    if (!Object.values(fits).some(Boolean) && col >= 280 && col < bw) {
      bubble.style.width = Math.floor(col) + "px";
      bw = bubble.offsetWidth; bh = bubble.offsetHeight; fits = fitsWith();
    }
    const rightPanel = (r.x + r.w / 2) > vw * 0.55;   // target lives in the right panel
    // Order of preference. On a phone (narrow) below/above read best; a right-panel target goes left.
    const order = vw <= 520 ? ["below", "above", "left", "right"]
      : rightPanel ? ["left", "below", "above", "right"] : ["below", "above", "right", "left"];
    const side = order.find((s) => fits[s]) ||
      Object.keys(room).reduce((a, b) => (room[a] >= room[b] ? a : b));   // else roomiest edge
    let left, top;
    if (side === "below")      { top = r.y + r.h + gap;  left = r.x + r.w / 2 - bw / 2; }
    else if (side === "above") { top = r.y - bh - gap;   left = r.x + r.w / 2 - bw / 2; }
    else if (side === "right") { left = r.x + r.w + gap; top = r.y + r.h / 2 - bh / 2; }
    else                       { left = r.x - bw - gap;  top = r.y + r.h / 2 - bh / 2; }
    // If the chosen side had no room (fallback), pin flush to that edge instead of overhanging.
    if (!fits[side]) {
      if (side === "below") top = vh - bh - edge; else if (side === "above") top = edge;
      else if (side === "right") left = vw - bw - edge; else left = edge;
    }
    left = clamp(left, edge, vw - bw - edge); top = clamp(top, edge, vh - bh - edge);
    // Docked with no room, the bubble may lie over part of the spotlight - but never over the one
    // control the step asks for: slide it above or below that control when it would.
    const s = STEPS[curStep], tp = s && s.tap ? visible(s.tap) : null;
    if (tp) {
      const q = tp.getBoundingClientRect();
      const hit = (t) => !(left > q.right + gap || left + bw < q.left - gap || t > q.bottom + gap || t + bh < q.top - gap);
      if (hit(top)) {
        const under = q.bottom + gap, over = q.top - gap - bh;
        if (under + bh <= vh - edge) top = under; else if (over >= edge) top = over;
      }
    }
    bubble.style.left = left + "px";
    bubble.style.top = top + "px";
  }

  function clearAction() {
    if (actionH) { actionH(); actionH = null; }
  }

  // A toast left over from the reader's own move (승인했어요 · 되돌리기) must not ride along into the
  // next steps.
  function clearToast() {
    const t = document.getElementById("toast");
    if (t) t.classList.remove("on");
  }

  function renderBubble(i) {
    const s = STEPS[i];
    bubble.dataset.step = s.id;               // exposes the current step id (aids QA / testing)
    const isAction = !!s.act;
    // A do-it-yourself step moves on by itself once the reader does it; the quiet 넘어가기 is the way
    // out when they'd rather not (or the video can't autoplay), so no step can trap the tour.
    const next = isAction
      ? `<button class="tour-back" data-tour-next>${E(tl("tour.pass"))}</button>`
      : `<button class="tour-next" data-tour-next>${E(s.last ? tl("tour.done") : tl("tour.next"))}</button>`;
    bubble.innerHTML = `<div class="tour-count">${E(tl("tour.count", {n: i + 1, total: STEPS.length}))}</div>
      <div class="tour-title">${E(s.t())}</div>
      ${isAction ? `<div class="tour-do">${E(s.h ? s.h() : tl("tour.do"))}</div>` : `<div class="tour-desc">${E(s.d())}</div>`}
      <div class="tour-row">
        <button class="tour-skip" data-tour-skip>${E(tl("tour.skip"))}</button>
        <span class="tour-sp"></span>${next}</div>`;
    bubble.querySelector("[data-tour-skip]").onclick = () => finish("skip");
    const nb = bubble.querySelector("[data-tour-next]");
    if (nb) nb.onclick = () => (s.last ? finish("done") : go(i + 1));
  }

  async function go(i) {
    if (exiting) return;
    if (i < 0) i = 0;
    if (i >= STEPS.length) return finish("done");
    const prev = curStep;
    curStep = i;
    const me = ++goSeq;                              // a newer go() (a fast 이전/넘어가기) wins
    clearAction();
    clearToast();
    if (prev >= 0 && prev !== i && STEPS[prev].leave) { try { await STEPS[prev].leave(); } catch (e) { /* view moved on */ } }
    const s = STEPS[i];
    bubble.classList.remove("on");
    hole.classList.remove("on", "glow");
    try { await s.prep(); } catch (e) { /* keep going; the target may still resolve */ }
    if (exiting || me !== goSeq) return;
    // Wait until the target is on screen and its layout has settled, then scroll it (once) to a
    // comfortable spot before measuring, so the ring lands on its final place.
    if (!s.center) await waitVisible(s.sel());
    let tEl = s.center ? null : await waitStable(s.sel());
    if (exiting || me !== goSeq) return;
    renderBubble(i);                                 // rendered (still hidden) so its size can be planned for
    await settleInView(tEl, s.roomBelow || 0);
    if (exiting || me !== goSeq) return;
    if (tEl && !tEl.isConnected) tEl = visible(s.sel());
    if (tEl && s.id === "v1") brightenVideo(tEl);   // spotlight the video, not its black poster (item 5)
    // A step with no target (done): hide the hole, centre the bubble.
    const hasTarget = !!tEl && !!measure(s.sel(), s.also);
    band = safeBand(tEl);
    hole.style.display = hasTarget ? "" : "none";
    if (hasTarget) {
      const rad = parseFloat(getComputedStyle(tEl).borderTopLeftRadius) || 0;
      hole.style.borderRadius = Math.round(Math.max(6, rad + PAD)) + "px";
    }
    // With the four blocker strips the spotlit target always stays clickable (drag / play / press),
    // so action steps no longer drop the blocker. A step with no target blocks the whole screen.
    block.dataset.all = hasTarget ? "0" : "1";
    if (!hasTarget) applyMasks(null);
    rect = null; vel = null; target = hasTarget ? measure(s.sel(), s.also) : null;
    if (hasTarget) {
      // Seed rect AND vel together so the spring never runs on an uninitialised velocity.
      applyRect(target); rect = {...target}; vel = {x: 0, y: 0, w: 0, h: 0};
      requestAnimationFrame(() => hole.classList.add("on", "glow"));
    }
    if (!raf) loop();                              // the loop runs the whole step and tracks reflows
    positionBubble(hasTarget ? clip(target) : null);
    requestAnimationFrame(() => bubble.classList.add("on"));
    if (s.act) armAction(s, i);
  }

  // Everything inside the spotlight except the step's own control is swallowed here, in the capture
  // phase and ahead of armAction (registered first), so a press on 비교, a version thumbnail or a
  // drawing tool does nothing while the tour is up. The tour's own bubble always answers. Touch
  // events are stopped but not cancelled, so a finger can still scroll the page.
  function allowedBy(s, t) {
    if (!s || !s.allow || !t || !t.closest) return false;
    return !!t.closest(s.allow());
  }
  function armGuard() {
    const inTour = (e) => e.target && e.target.closest && e.target.closest(".tour-layer");
    const ptr = (e) => {
      // Script-made events are the tour's own (a step's prep pressing a tab, the proxy below).
      if (!e.isTrusted || inTour(e)) return;
      const s = STEPS[curStep];
      if (allowedBy(s, e.target)) return;
      e.stopImmediatePropagation();
      if (!e.type.startsWith("touch")) e.preventDefault();
      if (e.type === "click" && s && s.proxy && e.target.closest && e.target.closest(s.proxy.from)) {
        const to = visible(s.proxy.to); if (to) to.click();
      }
    };
    const key = (e) => {
      if (inTour(e) || e.key === "Escape" || e.ctrlKey || e.metaKey || e.altKey || /^F\d+$/.test(e.key)) return;
      const s = STEPS[curStep];
      if (s && s.keys && s.keys.includes(e.key)) return;
      e.stopImmediatePropagation(); e.preventDefault();
    };
    const types = ["pointerdown", "pointerup", "mousedown", "mouseup", "click", "dblclick", "auxclick",
      "contextmenu", "touchstart", "touchend", "dragstart"];
    types.forEach((t) => document.addEventListener(t, ptr, {capture: true, passive: false}));
    document.addEventListener("keydown", key, true);
    return () => { types.forEach((t) => document.removeEventListener(t, ptr, {capture: true}));
      document.removeEventListener("keydown", key, true); };
  }

  // Wire the "do it yourself" trigger for a step. Listens in the capture phase and ignores clicks in
  // the tour's own bubble, so 이전 / 넘어가기 / 건너뛰기 never count as the action.
  function armAction(s, i) {
    const a = {...s.act, sel: typeof s.act.sel === "function" ? s.act.sel() : s.act.sel};
    // With `then` (the click opens another screen) move on as soon as that screen is up; otherwise
    // wait 550ms so the reader sees their own move land first.
    let passed = false;                              // a double click must not skip a step
    const pass = () => {
      if (passed) return; passed = true;
      if (!a.then) return setTimeout(() => { if (curStep === i && !exiting) go(i + 1); }, 550);
      const t0 = Date.now();
      const tick = () => { if (curStep !== i || exiting) return;
        if (a.then() || Date.now() - t0 > 5000) go(i + 1); else setTimeout(tick, 60); };
      setTimeout(tick, 60);
    };
    const inTour = (e) => e.target && e.target.closest && e.target.closest(".tour-layer");
    const on = (type, fn) => { document.addEventListener(type, fn, true); return () => document.removeEventListener(type, fn, true); };
    const offs = [];
    if (a.type === "click") {
      offs.push(on("click", (e) => { if (!inTour(e) && e.target.closest(a.sel)) pass(); }));
    } else if (a.type === "play") {
      offs.push(on("play", (e) => { if (e.target.closest && e.target.closest(a.sel)) pass(); }));
    } else if (a.type === "drag") {
      let from = null;
      offs.push(on("pointerdown", (e) => { from = (!inTour(e) && e.target.closest(a.sel)) ? {x: e.clientX, y: e.clientY} : null; }));
      offs.push(on("pointermove", (e) => { if (from && Math.hypot(e.clientX - from.x, e.clientY - from.y) > 28) { from = null; pass(); } }));
      offs.push(on("pointerup", () => { from = null; }));
    } else if (a.type === "draw") {
      // the reader turned drawing on and put down a stroke
      offs.push(on("pointerup", (e) => { if (e.target.closest && e.target.closest(".drawl canvas")) setTimeout(() => {
        if (typeof drawing !== "undefined" && drawing && drawing.strokes && drawing.strokes.length) pass(); }, 60); }));
    } else if (a.type === "pin") {
      // the reader turned pin mode on and tapped the picture
      offs.push(on("click", (e) => { if (!inTour(e) && e.target.closest && e.target.closest("#stage") && !e.target.closest(".stools")) setTimeout(() => {
        if (typeof pin !== "undefined" && pin) pass(); }, 80); }));
    }
    actionH = () => offs.forEach((f) => f());
  }

  function finish(reason) {
    if (exiting) return; exiting = true;
    clearAction();
    { const cs = STEPS[curStep]; if (cs && cs.leave) { try { cs.leave(); } catch (e) { /* view moved on */ } } }
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    if (keyH) { document.removeEventListener("keydown", keyH); keyH = null; }
    if (guardOff) { guardOff(); guardOff = null; }
    if (resizeH) { window.removeEventListener("resize", resizeH); resizeH = null; }
    if (scrollH) { window.removeEventListener("scroll", scrollH, true); scrollH = null; }
    if (hideH) { window.removeEventListener("pagehide", hideH); hideH = null; }
    document.body.classList.remove("tour-on");
    if (bubble) bubble.classList.remove("on");
    if (hole) hole.classList.remove("on");
    const cb = onExit; onExit = null;
    if (tapRing) tapRing.classList.remove("on");
    setTimeout(async () => { if (layer) layer.remove(); layer = hole = bubble = block = tapRing = null;
      await cleanSample();
      if (typeof cb === "function") try { cb(reason); } catch (e) { /* caller's problem */ } }, 220);
  }

  // The sample lives only while the tour runs: it has no session behind it, so left in, a comment
  // on it would go to nobody (and it would sit among real work and count in the home numbers).
  // Every way out removes it: 마치기, 건너뛰기, Esc (all through finish), and closing or reloading
  // the page mid-tour (pagehide, below). It goes back to home first so nothing is showing the item
  // being deleted; replaying the tour from 설정 rebuilds it.
  async function cleanSample() {
    try {
      if (typeof nav === "function") nav("home");
      await post("/api/onboard/sample/remove", {});
      if (typeof load === "function") await load();
      if (typeof render === "function") render();
    } catch (e) { /* the sample stays for now; the next page load or server start clears it */ }
  }

  function start(opts) {
    if (layer) return;                              // already running
    if (window.LOOP_REPAINT) window.LOOP_REPAINT.rescueBody(document);   // never start on a black body
    injectCSS();
    onExit = (opts && opts.onExit) || null;
    exiting = false; curStep = -1;
    layer = document.createElement("div"); layer.className = "tour-layer";
    // Four blocker strips (top/bottom/left/right) instead of one full-screen sheet, so the spotlit
    // target keeps receiving pointer events - the user can play the video, drag on it, press the
    // button - while every click outside the hole is still caught. applyRect() sizes the strips.
    block = document.createElement("div"); block.className = "tour-block";
    for (let m = 0; m < 4; m++) block.appendChild(document.createElement("div")).className = "tour-mask";
    hole = document.createElement("div"); hole.className = "tour-hole";
    bubble = document.createElement("div"); bubble.className = "tour-bubble";
    tapRing = document.createElement("div"); tapRing.className = "tour-tap";
    layer.appendChild(block); layer.appendChild(hole); layer.appendChild(tapRing); layer.appendChild(bubble);
    document.body.appendChild(layer);
    keyH = (e) => { if (e.key === "Escape") finish("skip"); };
    document.addEventListener("keydown", keyH);
    guardOff = armGuard();
    document.body.classList.add("tour-on");
    // A resize re-reads the bars the ring must stay clear of; a scroll (the reader's own) moves the
    // ring with the page in lockstep. Neither scrolls anything; the loop picks up the new box.
    const cur = () => { const s = STEPS[curStep]; return s && !s.center ? visible(s.sel()) : null; };
    resizeH = () => { const el = cur(); if (el) { band = safeBand(el); snap = true; } };
    scrollH = () => { snap = true; };
    window.addEventListener("resize", resizeH);
    window.addEventListener("scroll", scrollH, true);
    // Closed or reloaded mid-tour: finish() never runs, so ask for the removal on the way out.
    hideH = () => { try { fetch("/api/onboard/sample/remove", {method: "POST", keepalive: true,
      headers: {"Content-Type": "application/json"}, body: "{}"}).catch(() => {}); } catch (e) { /* next load clears it */ } };
    window.addEventListener("pagehide", hideH);
    // Resolve the sample's iid from the API (never hard-coded) and make sure it is present, then
    // start. Both are best-effort; the fallback iid keeps the tour working offline.
    Promise.all([
      fetch("/api/onboard").then((r) => r.json()).then((st) => {
        if (st && st.sample_project && st.sample_item) SAMPLE = st.sample_project + "/" + st.sample_item;
      }).catch(() => {}),
      // reset: a sample already walked (v002, approved) starts over at v1 so the loop can be replayed.
      post("/api/onboard/sample", {reset: true, lang: window.I18N_LANG}).catch(() => {}),
    ]).then(() => go(0));
  }

  window.LOOP_TOUR = {start};

  // ---------------------------------------------------------------- settings: replay chips
  // Rendered at the top of the 일반 page by v2.js (and reused by the settings redesign). Plain text
  // chips: replay just the tour, or reopen the whole first-run setup.
  window.LOOP_TOUR_SECTION = function (el) {
    if (!el) return;
    injectCSS();
    el.innerHTML = `<div class="setsec">${E(tl("onboard.steptour"))}</div>
      <p class="setd" style="margin:-2px 0 10px">${E(tl("onboard.reopendesc"))}</p>
      <div class="tour-chips">
        <button class="tour-chip" data-tour-replay>${E(tl("tour.replay"))}</button>
        <button class="tour-chip" data-tour-reopen>${E(tl("onboard.reopen"))}</button>
      </div>`;
    el.querySelector("[data-tour-replay]").onclick = () => start({});
    el.querySelector("[data-tour-reopen]").onclick = () => {
      if (window.LOOP_ONBOARD && window.LOOP_ONBOARD.open) window.LOOP_ONBOARD.open();
    };
  };

  // ---------------------------------------------------------------- home: agent-connect reminder
  // A quiet card shown once onboarding is done but no agent is CONNECTED yet (e.g. the connect step
  // was skipped, or an agent is only detected/logged in). It self-hides only when Genok's hook
  // is actually installed for an agent - being installed + logged in is "감지됨", not "연결됨".
  // Agent-neutral wording (O12).
  // /api/connect at most once per 10s: home draws its cards twice on boot.
  let connMemo = null, connAt = 0;
  const connectState = () => {
    if (!connMemo || Date.now() - connAt > 10000) {
      connAt = Date.now();
      connMemo = fetch("/api/connect").then((r) => r.json()).catch(() => { connMemo = null; return null; });
    }
    return connMemo;
  };
  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({
    id: "agent-remind", title: "",
    draw: async (host) => {
      // The .homecard shell v2.js created. closest(), not parentElement: a soft redraw draws into a
      // detached host whose parent is <body>, which must never be hidden.
      const sec = host.closest(".homecard");
      if (sec) sec.style.display = "none";            // stay hidden until we know
      let st, conn;
      try {
        // onboard.js's boot fetch is shared, so home does not ask /api/onboard a second time.
        st = await (window.LOOP_ONBOARD && window.LOOP_ONBOARD.state
          ? window.LOOP_ONBOARD.state() : fetch("/api/onboard").then((r) => r.json()));
        if (!st || !st.onboarded) return;             // brand-new users see the wizard, not this
        conn = await connectState();
      } catch { return; }
      // Connected == our hook is present for that agent, not merely detected/logged in.
      const hooked = (d) => !!(d && d.pieces && d.pieces.hook && d.pieces.hook.present === true);
      if (conn && (hooked(conn.claude) || hooked(conn.codex))) return;   // an agent is really connected
      const el = document.createElement("div");
      el.className = "tour-remind";
      el.innerHTML = `<span class="ico sm c-blue">${typeof ic === "function" ? ic("plug") : ""}</span>
        <span class="tx"><div class="t" style="font-size:15px">${E(tl("tour.ccremind"))}</div></span>
        <button class="btn sm press" data-remind-connect>${E(tl("tour.ccconnect"))}</button>`;
      host.appendChild(el);
      if (sec) sec.style.display = "";
      el.querySelector("[data-remind-connect]").onclick = () => {
        if (window.LOOP_ONBOARD && window.LOOP_ONBOARD.open) window.LOOP_ONBOARD.open();
      };
    },
  });
})();
