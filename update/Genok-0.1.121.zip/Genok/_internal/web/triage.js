// Going through what waits, fast (home, 알림 · 할 일, 결과물): the words a search matches on, and a
// phone row pulled sideways - right approves it, left puts it off (나중에). The row follows the
// finger 1:1, is let go with the finger's speed into the app's spring and can be caught again on
// the way; short of the line it springs back. Reduced motion: nothing slides, the mark fades in
// over the row's end. The arithmetic is at the top, pure and tested in tests/triage.test.js;
// the springs and the look of the mark are web/swipe.js's (PjSwipe, .sw-tray).
(function () {
  "use strict";

  const S = () => typeof window === "undefined" ? require("./swipe.js") : window.PjSwipe;

  // A search is its words, in any order: every one of them has to be in the text.
  const words = (q) => String(q || "").toLowerCase().split(/\s+/).filter(Boolean);
  const match = (hay, q) => { const h = String(hay || "").toLowerCase(); return words(q).every((w) => h.includes(w)); };

  // How far a pull counts as meant, for a row `w` px wide.
  const commit = (w) => Math.min(140, w * 0.4);

  // Where the row stands for `d` px of finger travel. 1:1 to a side that does something
  // (o.ok: right, o.later: left); a side that does nothing only gives a little.
  function rowAt(d, o) {
    if (d > 0 && !o.ok) return S().rubber(d, S().OVER);
    if (d < 0 && !o.later) return -S().rubber(-d, S().OVER);
    return d;
  }

  // What a row let go at `x` with `v` px/s does: {to, fire}. Past the line, or thrown hard
  // enough to get most of the way by itself, it fires; otherwise it goes back.
  function rowEnd(x, v, w, o) {
    const r = S().rest(x, v), c = commit(w);
    if (x > 0 && o.ok && (x >= c || (x > 48 && r >= w * 0.6))) return {to: w + 24, fire: "ok"};
    if (x < 0 && o.later && (x <= -c || (x < -48 && r <= -w * 0.6))) return {to: 0, fire: "later"};
    return {to: 0, fire: ""};
  }

  const api = {words, match, commit, rowAt, rowEnd};
  if (typeof module !== "undefined" && module.exports) { module.exports = api; return; }
  window.Triage = api;

  // ---- in the page ------------------------------------------------------------------------------
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const ROW = "#view .row[data-tk][data-item], #view .home [data-tk][data-item]";
  let drag = null;              // the finger that is down: {id, el, sx, sy, axis, base, pts}
  let row = null;               // the row that is out of place: {el, tray, par, x, v, raf, w, o, key, side, st}
  let guardAt = -1e9;

  // What a pull may do to this result: approve it (not while it asks a question - that is
  // answered on its page), put it off. Only what is the person's turn can be pulled at all.
  function can(key) {
    const x = D.items.find((y) => iid(y) === key);
    if (!x || !stMine(x)) return null;
    return {ok: x.status !== "approved" && !(x.asked > 0 && stK(x) === "ask"), later: true, x};
  }

  function make(el, o) {
    const par = el.parentNode, tray = document.createElement("div");
    if (getComputedStyle(par).position === "static") par.style.position = "relative";
    par.classList.add("tgp");
    tray.className = "sw-tray";
    tray.style.cssText = `left:${el.offsetLeft}px;top:${el.offsetTop}px;width:${el.offsetWidth}px;height:${el.offsetHeight}px`;
    par.insertBefore(tray, el);
    el.classList.add("sw-on");
    return {el, tray, par, x: 0, v: 0, raf: 0, w: el.offsetWidth, o, key: el.dataset.item, side: "", st: "drag"};
  }
  function mark(r, side) {
    if (r.side === side) return;
    r.side = side;
    const [icon, text] = side === "ok" ? ["check", tl("STATUS_T.4")] : ["clock", tl("palActs.2")];
    r.tray.className = "sw-tray " + (side === "ok" ? "l" : "r") + (RM() ? " fade" : "");
    r.tray.innerHTML = r.o[side] ? `<span class="sw-h" role="img" aria-label="${esc(text)}">${ic(icon)}<span aria-hidden="true">${esc(text)}</span></span>` : "";
  }
  function set(r, x) {
    r.x = x;
    const rm = RM(), ax = Math.abs(x), t = r.tray;
    if (ax < 0.5) { r.el.style.translate = ""; t.style.clipPath = "inset(0 100% 0 0)"; t.classList.remove("arm"); return; }
    mark(r, x > 0 ? "ok" : "later");
    const p = Math.min(1, ax / 64), arm = r.o[r.side] && ax >= commit(r.w);
    // The moment the pull is enough is felt as well as seen (where the phone can).
    if (arm && !t.classList.contains("arm") && r.st === "drag" && navigator.vibrate) navigator.vibrate(8);
    t.classList.toggle("arm", arm);
    t.style.setProperty("--sw-s", rm ? "1" : (0.6 + 0.4 * p).toFixed(3));
    t.style.setProperty("--sw-o", rm ? "1" : p.toFixed(3));
    if (rm) {
      r.el.style.translate = "";
      t.style.clipPath = x > 0 ? "inset(0 calc(100% - 72px) 0 0 round var(--r-lg,14px))" : "inset(0 0 0 calc(100% - 72px) round var(--r-lg,14px))";
      t.style.opacity = p.toFixed(3); t.style.zIndex = "2";
      return;
    }
    r.el.style.translate = `${x.toFixed(1)}px 0`;
    const gap = Math.max(0, ax - 6).toFixed(1);
    t.style.clipPath = x > 0 ? `inset(0 calc(100% - ${gap}px) 0 0)` : `inset(0 0 0 calc(100% - ${gap}px))`;
  }
  function drop(r) {
    cancelAnimationFrame(r.raf);
    r.el.style.translate = ""; r.el.classList.remove("sw-on");
    r.tray.remove(); r.par.classList.remove("tgp");
    if (row === r) row = null;
  }
  // Let go: the spring carries it to `to` from the finger's speed, then `done`.
  function go(r, v, to, done) {
    cancelAnimationFrame(r.raf);
    r.st = "anim";
    const end = () => { r.v = 0; set(r, to); done(); };
    if (RM()) { r.tray.style.opacity = to ? "1" : "0"; r.raf = requestAnimationFrame(() => setTimeout(end, 170)); return; }
    let x = r.x, last = performance.now();
    const tick = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      [x, v] = S().step(x, v, to, dt); r.v = v;
      if (S().still(x, v, to)) return end();
      set(r, x); r.raf = requestAnimationFrame(tick);
    };
    r.raf = requestAnimationFrame(tick);
  }

  addEventListener("pointerdown", (e) => {
    if (drag || !e.isPrimary || e.pointerType === "mouse" || typeof D === "undefined") return;
    const el = e.target.closest ? e.target.closest(ROW) : null;
    // A row on its way back is caught where it is.
    if (row && row.el === el && row.st === "anim") {
      cancelAnimationFrame(row.raf); row.st = "drag";
      drag = {id: e.pointerId, el, sx: e.clientX, sy: e.clientY, axis: "x", base: e.clientX - row.x, pts: []};
      return;
    }
    if (row && row.st !== "fire") drop(row);
    if (!el || row) return;
    const o = can(el.dataset.item); if (!o) return;
    drag = {id: e.pointerId, el, o, sx: e.clientX, sy: e.clientY, axis: "", pts: []};
  }, {capture: true, passive: true});

  addEventListener("pointermove", (e) => {
    const d = drag; if (!d || e.pointerId !== d.id) return;
    // The list was drawn again under the finger: the row that was held is gone.
    if (!d.el.isConnected) { drag = null; if (row) { row.tray.remove(); row.par.classList.remove("tgp"); cancelAnimationFrame(row.raf); row = null; } return; }
    if (!d.axis) {
      const a = S().lock(e.clientX - d.sx, e.clientY - d.sy);
      if (!a) return;
      if (a === "y") { drag = null; return; }
      row = make(d.el, d.o);
      d.axis = "x"; d.base = e.clientX;
      try { d.el.setPointerCapture(d.id); } catch (err) { /* the finger is already up */ }
    }
    const raw = e.clientX - d.base;
    set(row, rowAt(raw, row.o)); d.pts.push({x: raw, t: e.timeStamp});
    if (d.pts.length > 8) d.pts.shift();
  }, {capture: true, passive: true});

  const up = (e) => {
    const d = drag; if (!d || e.pointerId !== d.id) return;
    drag = null;
    if (d.axis !== "x" || !row) return;
    guardAt = performance.now();
    const r = row, v = e.type === "pointerup" ? S().velocity(d.pts, e.timeStamp) : 0;
    const end = e.type === "pointerup" ? rowEnd(r.x, v, r.w, r.o) : {to: 0, fire: ""};
    if (end.fire === "later") snoozeSheet(r.key);       // the sheet comes up while the row goes back
    if (end.fire !== "ok") return go(r, v, 0, () => drop(r));
    go(r, v, end.to, () => {
      // Gone to the right: the gap it left closes, then the list is drawn without it (되돌리기 in the toast).
      const el = r.el; el.style.visibility = "hidden"; drop(r);
      if (el.isConnected) tkFold(el, () => approveMany([r.o.x])); else approveMany([r.o.x]);
    });
    r.st = "fire";
  };
  addEventListener("pointerup", up, {capture: true, passive: true});
  addEventListener("pointercancel", up, {capture: true, passive: true});

  // The press that ends a pull opens nothing.
  addEventListener("click", (e) => {
    if (performance.now() - guardAt < 350 && e.target.closest && e.target.closest(ROW)) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  addEventListener("hashchange", () => { if (row) drop(row); });
})();
