// 설정 → 베타: features to try before they ship to everyone. For now one choice, the theme:
// the new glass design is the lab-3 switch in v2.js (localStorage "genok-lab"), off by default.
// Its own small file + one LOOP_SETTINGS entry. Uses v2.js globals: tl, setRow.
(function () {
  "use strict";

  const now = () => { try { return localStorage.getItem("genok-lab") === "3" ? "3" : "0"; } catch (e) { return "0"; } };

  function draw(c) {
    const cur = now();
    const opt = (v, t) => `<button class="press ${cur === v ? "on" : ""}" data-beta="${v}" aria-pressed="${cur === v}">${t}</button>`;
    c.innerHTML = `<h2 class="seth">${tl("beta.title")}</h2>
      <p class="setd">${tl("beta.desc")}</p>
      ${setRow(tl("beta.theme"), tl("beta.theme.new.s"), `<div class="seg" role="group" aria-label="${tl("beta.theme")}">${opt("0", tl("beta.theme.base"))}${opt("3", tl("beta.theme.new"))}</div>`)}`;
    c.querySelectorAll("[data-beta]").forEach((b) => { b.onclick = () => {
      if (b.dataset.beta === now()) return;
      try { localStorage.setItem("genok-lab", b.dataset.beta); } catch (e) { return; }
      // The lab switch is read once at start, so the choice takes effect on a reload. A ?lab= in the
      // address would win over the stored choice, so it is dropped first (replace() alone would not
      // reload when only the hash is left to differ).
      const u = new URL(location.href); u.searchParams.delete("lab");
      history.replaceState(null, "", u); location.reload();
    }; });
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "beta", icon: "star", title: "beta.title", draw});
})();
