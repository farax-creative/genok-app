// Project page (P5): a department's sessions, one session's conversation with a chat box,
// its results and open comments beside it, and per-session controls (켜기 · 새로 켜기 · 정리).
//
// Loaded after v2.js, so it reads v2.js's globals (get, esc, ic, nav, toast, ago, RM, wide, D,
// iid, vShort, sheet, closeSheet, copyText) and joins the app as an extension screen through
// window.LOOP_TABS (web/tabs.js). Sub-navigation lives in the hash:
//   #project                 pick a department (a wide window opens the most recent one instead)
//   #project/~all            the pick list itself, also on a wide window
//   #project/<name>/~new     a session not opened yet: the chat is ready, the first line opens it
//   #project/<name>          its session cards
//   #project/<name>/<sid>    one session: conversation | results + open comments
//   #project/~multi/<sid,…>  up to six rooms side by side with one line to all of them (M13)
// Look follows the refern reference: dark neutral panels, UPPERCASE 11px section labels,
// full-width neutral buttons, state line before the action, tiny dots instead of colored fills.
(function () {
  "use strict";
  if (typeof window === "undefined" || typeof get !== "function") return;

  const CSS = `
  .pj{max-width:100%;overflow-x:hidden;padding-bottom:calc(96px + env(safe-area-inset-bottom))}
  .pj-lab{display:flex;align-items:center;gap:8px;margin:16px 2px 8px;font-size:12px;font-weight:600;letter-spacing:.08em;
    text-transform:uppercase;color:var(--t3)}
  .pj-lab .n{color:var(--t4);letter-spacing:0}
  .pj-lab .sp{flex:1}
  .pj-lab button{font-size:12px;letter-spacing:0;text-transform:none;color:var(--t3);font-weight:500}
  .pj-lab button:hover{color:var(--t1)}
  .pj-head{display:flex;align-items:center;gap:16px;padding:6px 2px 4px}
  .pj-head .em{font-size:30px;line-height:1;flex:none}
  .pj-head .tx{min-width:0;flex:1}
  .pj-head h1{margin:0;font-size:22px;font-weight:700;letter-spacing:-.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-head .fo{font-size:12px;color:var(--t3);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-back{font-size:13px;color:var(--t3);padding:6px 2px;display:inline-flex;align-items:center;gap:4px}
  .pj-back:hover{color:var(--t1)}
  .pj-btn{height:36px;padding:0 16px;border-radius:8px;background:var(--btn);color:var(--t1);font-size:14px;font-weight:600;
    display:inline-flex;align-items:center;justify-content:center;gap:6px;white-space:nowrap;transition:background .15s}
  .pj-btn:hover{background:var(--btn-hi)} .pj-btn:disabled{opacity:.45;cursor:default}
  .pj-btn.full{width:100%}
  .pj-btn.light{background:#dcdcdc;color:#141414} .pj-btn.light:hover{background:#eee}
  /* On a light page the pale pill read as switched off: it goes to ink there. */
  html[data-theme="light"] .pj-btn.light{background:#111114;color:#fff} html[data-theme="light"] .pj-btn.light:hover{background:#2a2a30}
  .pj-text{height:34px;padding:0 12px;border-radius:8px;font-size:14px;color:var(--t3);font-weight:500}
  .pj-text:hover{color:var(--t1);background:var(--btn)}
  .pj-grid{display:grid;gap:8px;grid-template-columns:repeat(auto-fill,minmax(230px,1fr))}
  .pj-card{position:relative;text-align:left;background:var(--card);border-radius:var(--r-card);padding:12px 16px;
    display:flex;flex-direction:column;gap:8px;min-width:0;border:1px solid transparent;transition:background .15s,border-color .15s}
  .pj-card:hover{background:var(--card-hi)}
  .pj-card.on{border-color:rgba(255,255,255,.16);background:var(--card-hi)}
  .pj-card .r1{display:flex;align-items:flex-start;gap:8px}
  .pj-card .t{flex:1;min-width:0;font-size:14.5px;font-weight:600;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;
    -webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
  .pj-card .r2{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--t3);flex-wrap:wrap}
  .pj-dot{width:7px;height:7px;border-radius:50%;flex:none;background:var(--t4)}
  .pj-dot.live{background:var(--sr-work,var(--green))} .pj-dot.idle{background:var(--orange)}
  .pj-ag,.pj-bg{display:inline-flex;align-items:center;flex:none;box-sizing:border-box;height:18px;padding:0 6px;border:1px solid var(--line);border-radius:6px;
    font-size:12px;font-weight:600;letter-spacing:.02em;line-height:1;color:var(--t2);white-space:nowrap}
  .pj-bg{color:var(--t3)}
  .pj-stl{display:inline-flex;align-items:center;height:18px;line-height:1;white-space:nowrap}
  .pj-stl.stale{color:var(--blue-t)} .pj-stl.stuck{color:var(--red)}
  .pj-ico{display:inline-flex;flex:none;width:14px;height:14px;color:var(--t3)} .pj-ico svg{width:100%;height:100%}
  .pj-ico.stale{color:var(--blue-t)}
  .pj-more{flex:none;width:28px;height:28px;margin:-4px -6px 0 0;border-radius:8px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center}
  .pj-more:hover{background:var(--btn);color:var(--t1)}
  .pj-more svg{width:16px;height:16px}
  .pj-pop{position:fixed;z-index:400;min-width:176px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);max-height:calc(100dvh - 16px);overflow-y:auto;overscroll-behavior:contain;transform-origin:top right}
  .pj-pop.wide{width:300px}
  .pj-pop button{display:flex;width:100%;align-items:center;color:var(--t1);text-align:left}
  body .pj-pop button.two{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;height:auto;min-height:var(--menu-row);padding:8px 12px}
  .pj-pop button small{font-size:12px;line-height:1.4;color:var(--t3);font-weight:400;white-space:normal}
  body .pj-pop button:disabled,body .pj-pop button[aria-disabled="true"]{color:var(--t4);cursor:default}
  body .pj-pop button[aria-disabled="true"]:hover{background:none}
  .pj-pop button[aria-disabled="true"] small{color:var(--orange)}
  .pj-pop hr{border:0;border-top:1px solid var(--line);margin:4px 2px}
  /* A row's menu: an icon and a name of a few words per choice, the rare ones folded under 더 보기. */
  .pj-pop.cm{width:max-content;min-width:184px;max-width:min(260px,calc(100vw - 16px))}
  body .pj-pop.cm button{gap:8px;white-space:nowrap}
  .pj-pop.cm button>svg{flex:none;width:16px;height:16px;fill:currentColor;color:var(--t3)}
  /* The menu beside [새 세션]: three short names, each with an outline glyph of one weight. */
  body .pj-pop.pj-nm{min-width:132px}
  .pj-tmr .pj-btn svg.lu{width:18px;height:18px;fill:none;color:var(--t2)}
  .pj-pop.cm button>svg.up{transform:rotate(-90deg)}.pj-pop.cm button>svg.dn{transform:rotate(90deg)}
  .pj-pop.cm button[aria-disabled="true"]>svg{color:var(--t4)}
  .pj-pop.cm button>svg.cv{width:12px;height:12px;margin-left:auto;color:var(--t4);transition:transform .18s cubic-bezier(.2,.9,.25,1)}
  .pj-pop.cm button[aria-expanded="true"]>svg.cv{transform:rotate(90deg)}
  .pj-pop.cm .mx[hidden]{display:none}
  .pj-pop.cm .mx{margin:2px 0 0;padding:2px 0 2px 8px;border-radius:var(--r-sm);background:color-mix(in srgb,var(--t1) 4%,transparent)}
  .pj-pop.cm button.dz:not([aria-disabled]){color:var(--red)}.pj-pop.cm button.dz:not([aria-disabled])>svg{color:var(--red)}
  @media(prefers-reduced-motion:reduce){.pj-pop.cm button>svg.cv{transition:none}}
  /* The letter that runs a choice while the menu is open, at the row's right end. */
  .pj-pop.cm button>.mk{margin-left:auto;padding-left:16px;display:inline-flex;gap:4px}
  @media(pointer:coarse){.pj-pop.cm button>.mk{display:none}}
  @media(pointer:coarse),(max-width:600px){.pj-pop.cm{min-width:216px}body .pj-pop.cm button{height:44px;gap:12px;font-size:15px}.pj-pop.cm button>svg{width:18px;height:18px}}
  .pj-empty{color:var(--t3);font-size:13px;padding:24px 4px;text-align:center;line-height:1.6}
  .pj-cols{display:grid;gap:16px;grid-template-columns:minmax(0,1fr);align-items:start}
  /* html.pj3 = the page has room for the list, a 380px chat and the results side by side
     (threeCols() below measures the page, so a folded app menu or a wide window both count). */
  html.pj3 .pj-cols{grid-template-columns:var(--rw,232px) minmax(0,1fr) var(--sw,300px);gap:16px;
      transition:grid-template-columns var(--m-snap-d,.45s) var(--m-snap,cubic-bezier(.2,.9,.25,1))}
  html.pj3 .pj-cols.no-rail{--rw:40px} html.pj3 .pj-cols.no-side{--sw:40px}
  /* The list and the results drag wider from their inner edge (v2.css .cgrip, v2.js wireColGrip). */
  html.pj3 .pj-cols{position:relative}
  html.pj3 .pj-cols>.pj-g{display:block;position:absolute;top:0;bottom:0;height:auto;width:14px;z-index:2}
  html.pj3 .pj-cols>.pj-g.l{left:calc(var(--rw,232px) + 1px)} html.pj3 .pj-cols>.pj-g.r{right:calc(var(--sw,300px) + 2px)}
  html.pj3 .pj-cols.no-rail>.pj-g.l,html.pj3 .pj-cols.no-side>.pj-g.r{display:none}
  /* The grip is only its short handle here. v2.css draws a full-height hairline for the item page;
     in this grid it read as a stray line through the chat, and while a panel opened it stood at the
     final edge before the column got there. It comes in once the column has arrived. */
  html.pj3 body:not(.gripping) .pj-cols>.pj-g:not(:hover):not(:focus-visible)::before{background:transparent}
  /* With a mouse the handle rests unseen too (a lone pill between two cards read as a stray bar);
     it shows under the pointer, on keyboard focus and while dragging. Touch keeps it in sight. */
  @media(hover:hover){html.pj3 body:not(.gripping) .pj-cols>.pj-g:not(:hover):not(:focus-visible)::after{background:transparent}}
  html.pj3 .pj-cols>.pj-g{animation:pj-gin .16s ease .42s backwards}
  @keyframes pj-gin{from{opacity:0}}
  body.gripping .pj-cols>.pj-g{animation:none}
  /* A panel that opens is not squeezed while its column grows from the 40px strip: its rows keep
     the width the column is heading for and are uncovered instead (a 70px column wrapped the
     heading one letter per line and stacked the cards' marks on top of each other). */
  html.pj3 .pj-cols>.pj-rail,html.pj3 #pj-side{overflow-x:hidden}
  html.pj3 .pj-cols:not(.no-rail)>.pj-rail>*{min-width:calc(var(--rw,232px) - 18px)}
  html.pj3 .pj-cols:not(.no-side) #pj-side>*{min-width:calc(var(--sw,300px) - 12px)}
  body.gripping .pj-cols{transition:none}
  html.pj3 .pj-body{display:contents}
  @media(prefers-reduced-motion:reduce){.pj-cols{transition:none!important}html.pj3 .pj-cols>.pj-g{animation:none}}
  .pj-fbtn{flex:none;width:26px;height:26px;margin:-6px -2px -6px 0;border-radius:8px;color:var(--t3);display:none;align-items:center;justify-content:center}
  .pj-fbtn svg{width:16px;height:16px}
  .pj-fbtn.r svg,.pj-strip.r svg{transform:scaleX(-1)}
  .pj-lab .pj-fbtn:hover{background:var(--btn);color:var(--t1)}
  html.pj3 .pj-fbtn{display:inline-flex}
  .pj-strip{display:flex;flex-direction:column;align-items:center;gap:8px;width:40px;height:100%;min-height:120px;padding:8px 0;border-radius:8px;
    background:var(--card);color:var(--t2);font-size:13px;font-weight:600;transition:background .15s,color .15s}
  .pj-strip:hover{background:var(--card-hi);color:var(--t1)}
  .pj-strip svg{width:18px;height:18px;flex:none}
  /* Under the panel icon: what is inside, as a small icon over its count. The words are in the
     button's label and tooltip, never turned on their side. */
  .pj-strip .c{display:flex;flex-direction:column;align-items:center;gap:4px;color:var(--t3)}
  .pj-strip .c svg{width:15px;height:15px}
  .pj-strip .c b{min-width:18px;height:16px;padding:0 4px;border-radius:8px;background:var(--btn);color:var(--t2);
    font-size:12px;font-weight:600;line-height:16px;letter-spacing:0;text-align:center;font-variant-numeric:tabular-nums}
  .pj-strip .c.hot b{background:var(--orange);color:#141414}
  .pj-strip:hover .c{color:var(--t2)}
  /* Results not looked at yet: the strip takes the accent and the count becomes their number. It
     moves once (.pop: the number springs in under a wash that fades), never in a loop. */
  .pj-strip{position:relative}
  .pj-strip.new{background:color-mix(in srgb,var(--blue) 14%,var(--card));color:var(--blue-t);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 42%,transparent)}
  .pj-strip.new:hover{background:color-mix(in srgb,var(--blue) 22%,var(--card));color:var(--blue-t)}
  .pj-strip .c.new,.pj-strip.new:hover .c.new{color:var(--blue-t)}
  .pj-strip .c.new b{background:var(--blue);color:var(--on-blue,#fff)}
  .pj-strip.pop::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:var(--blue);opacity:0;animation:pj-wash .9s ease-out 1}
  .pj-strip.pop .c.new b,.pj-nb.pop{animation:pj-pop var(--m-pop-d,.5s) var(--m-pop,cubic-bezier(.34,1.56,.64,1)) 1 backwards}
  @keyframes pj-wash{from{opacity:.4}}
  @keyframes pj-pop{from{transform:scale(.3)}}
  .pj-nb{display:inline-grid;place-items:center;min-width:17px;height:17px;margin-left:6px;padding:0 4px;border-radius:8px;background:var(--blue);color:var(--on-blue,#fff);
    font-size:12px;font-weight:700;line-height:1;letter-spacing:0;font-variant-numeric:tabular-nums;vertical-align:1px}
  @media(prefers-reduced-motion:reduce){.pj-strip.pop::after{display:none}.pj-strip.pop .c.new b,.pj-nb.pop{animation:none}}
  /* The results as small rows (the panel head's switch): picture and one line of title. */
  .pj-fbtn.pj-rdn{display:inline-flex;position:relative}
  .pj-fbtn[aria-pressed="true"]{background:var(--btn);color:var(--t1)}
  .pj-fbtn:focus-visible,.pj-strip:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-dn1 .pj-res{gap:8px;min-height:36px;padding:4px 8px 4px 4px;margin-bottom:2px;border-radius:8px;background:none}
  .pj-dn1 .pj-res:hover{background:var(--card)}
  .pj-dn1 .pj-res .th{width:28px;height:28px;border-radius:6px;background:var(--card)}
  .pj-dn1 .pj-res:hover .th{background:var(--bg)}
  .pj-dn1 .pj-res .th svg{width:14px;height:14px} .pj-dn1 .pj-res .th .play{display:none}
  .pj-dn1 .pj-res .t,.pj-dn1 .pj-item .t{display:block;font-size:13px;font-weight:500;white-space:nowrap;text-overflow:ellipsis}
  .pj-dn1 .pj-res .s,.pj-dn1 .pj-item .s{display:none}
  .pj-dn1 .pj-item{min-height:36px;padding:4px 8px;margin-bottom:2px;border-radius:8px;background:none}
  .pj-dn1 .pj-item:hover{background:var(--card)}
  .pj-dn1 .pj-lab{margin-top:16px;margin-bottom:6px}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-dn1 .pj-res,.pj-dn1 .pj-item{min-height:44px}.pj-dn1 .pj-res .th{width:32px;height:32px}
    .pj-fbtn.pj-rdn::before{content:"";position:absolute;inset:-9px}}
  .pj-seg{margin:6px 0 4px}
  html.pj3 .pj-seg{display:none}
  .pj-conv{position:relative;background:var(--card);border-radius:var(--r-card);display:flex;flex-direction:column;min-width:0;overflow:hidden}
  .pj-state{display:flex;align-items:center;gap:8px;padding:12px 16px;font-size:13px;color:var(--t2);border-bottom:1px solid var(--line)}
  .pj-state .sp{flex:1}
  .pj-state>span{white-space:nowrap}
  .pj-state>button{flex:none;white-space:nowrap}
  .pj-acts{display:flex;flex-wrap:wrap;gap:6px;padding:8px 16px;border-bottom:1px solid var(--line)}
  .pj-act{display:inline-flex;align-items:baseline;gap:6px;min-height:32px;padding:4px 12px;border-radius:8px;background:var(--btn);color:var(--t1);
    font-size:13px;font-weight:600;white-space:nowrap;transition:background .15s}
  .pj-act small{font-size:11.5px;font-weight:500;color:var(--t3)}
  .pj-act:hover:not(:disabled){background:var(--btn-hi)}
  .pj-act:disabled{opacity:.5;cursor:default}
  .pj-act.pri{background:#dcdcdc;color:#141414} .pj-act.pri small{color:#555} .pj-act.pri:hover:not(:disabled){background:#eee}
  .pj-mb .pj-acts{display:none}
  /* A session that ended keeps one small way back beside its state; the rest is in its menu. */
  .pj-state>.pj-act{align-items:center;min-height:26px;padding:4px 12px;font-size:12px}
  @media(pointer:coarse){.pj-state>.pj-act{min-height:32px;padding:4px 12px;font-size:13px}}
  .pj-row.busy{opacity:.55;pointer-events:none}
  .pj-note button{margin-left:8px;height:24px;padding:0 8px;border-radius:6px;background:var(--btn);color:var(--t1);font-size:12px;font-weight:600}
  .pj-note button:hover{background:var(--btn-hi)}
  .pj-q{overflow-wrap:anywhere}
  .pj-qq{margin-top:8px}
  .pj-qq>div:has(>[data-qpick]){display:flex;align-items:baseline;gap:8px;color:var(--t2)}   /* a long description wraps beside its option, not under it */
  .pj-q [data-qpick]{flex:none;margin:4px 0 0}
  .pj-q [data-qpick][aria-pressed="true"]{background:var(--t1);color:var(--card)}
  .pj-q input{display:block;width:100%;max-width:480px;height:28px;margin-top:8px;padding:0 8px;border:1px solid var(--line);border-radius:6px;background:none;color:var(--t1);font:inherit}
  .pj-qa{margin-top:8px}
  .pj-qa button:first-child{margin-left:0}
  @media(pointer:coarse){.pj-q button,.pj-q input{height:36px}.pj-q input{font-size:16px}}
  .pj-msgs{display:flex;flex-direction:column;gap:12px;padding:16px;overflow-y:auto;overscroll-behavior:contain;
    height:calc(100vh - 535px);height:calc(100dvh - 535px);min-height:260px;scroll-behavior:auto}
  /* Desktop: the three columns fill exactly the room between the toolbar and the status bar (fit() sets
     --pjh from what is really there), the log takes whatever the chrome around it leaves and scrolls,
     and the composer stays at the bottom edge of the panel. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){
    main:has(.pj-cols){padding-bottom:12px}
    .pj{padding-bottom:0}
    .pj-cols{height:var(--pjh,calc(var(--vh,100dvh) - 230px));min-height:0;align-items:stretch}
    .pj-rail,#pj-side{min-height:0;overflow-y:auto;overscroll-behavior:contain}
    .pj-body{display:flex;flex-direction:column;min-height:0;height:100%}
    .pj-body>.pj-conv{flex:1 1 auto;min-height:0}
    .pj-body>#pj-side{flex:1 1 auto}
    .pj-wrap{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
    .pj-msgs{flex:1 1 auto;height:auto;min-height:0}
  }
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){html:not(.pj3) .pj-cols{display:flex;flex-direction:column}html:not(.pj3) .pj-rail{flex:none;max-height:40%}html:not(.pj3) .pj-body{flex:1 1 auto}}
  html.pj3 .pj-body{display:contents}html.pj3 .pj-conv,html.pj3 #pj-side{min-height:0}
  /* Korean breaks between words, not inside them; a long path or address may still break anywhere. */
  /* The app shell disables text selection on body; conversation text opts back in. */
  .pj-msg{max-width:88%;font-size:14.5px;line-height:1.6;white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere;min-width:0;-webkit-user-select:text;user-select:text;cursor:text}
  .pj-holding{outline:1.5px solid color-mix(in srgb,var(--blue) 45%,transparent);outline-offset:-1px;filter:brightness(1.08)}
  /* Keep native selection handles and the system copy menu available on touch screens. */
  .pj-msgs .pj-msg.user,.pj-msgs .pj-msg.claude{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default}
  .pj-msg a{color:var(--blue-t);text-decoration:underline;text-underline-offset:2px;overflow-wrap:anywhere}
  /* A long press on a list card lifts it (menu / reorder): no text loupe or callout from the phone. */
  @media(pointer:coarse){.pj-srow,.pj-card{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}}
  .pj-msg.user{align-self:flex-end;background:var(--btn-hi);padding:8px 12px;border-radius:12px 12px 4px 12px}
  .pj-msg.claude{align-self:flex-start;color:var(--t1)}
  /* Wide pane: the header, the bars and the box span it, the talk keeps a reading measure. The
     column is left-aligned under the title; the person's bubbles end at the column's right edge. */
  @media(min-width:1500px){body .pj-conv .pj-wrap .pj-msgs{padding-right:max(16px,calc(100% - max(1120px,70%)))}}
  .pj-msg.claude{max-width:min(88%,820px)}.pj-msg.user{max-width:min(88%,720px)}
  .pj-msg.tool{align-self:flex-start;color:var(--t3);font-size:12px;font-family:ui-monospace,Menlo,Consolas,monospace;
    max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* The log is a column that scrolls, so nothing in it may give up its height: a tool line (it clips
     its own overflow, so its floor is 0) used to shrink to nothing in a long chat and leave only the
     row gap behind - 36 calls in a row read as 500px of nothing. A run of them sits closer together. */
  .pj-msgs>*{flex:none}
  .pj-msg.tool+.pj-msg.tool,.pj-tfold+.pj-msg.tool{margin-top:-8px}
  /* A long run of tool lines is one quiet row and its last two lines; the row opens the rest in place. */
  .pj-msg.tool.fd{display:none}
  /* A subagent's run: one quiet line that opens on its brief and its report. */
  .pj-sub{align-self:flex-start;max-width:min(100%,820px);min-width:0;margin-left:-6px;font-size:13px;line-height:20px;color:var(--t3)}
  .pj-sub.fd{display:none}
  .pj-sub+.pj-sub,.pj-subsum+.pj-sub{margin-top:-8px}
  .pj-subh{display:flex;align-items:flex-start;gap:8px;max-width:100%;min-height:28px;padding:4px 6px;border-radius:8px;text-align:left}
  @media(hover:hover){.pj-subh:hover,.pj-subsum button:hover{background:var(--btn)}}
  .pj-subh .smk{flex:none;display:grid;place-items:center;width:14px;height:20px}
  .pj-subh .smk svg{width:14px;height:14px} .pj-subh .smk .pj-spin{width:10px;height:10px}
  .pj-sub[data-st="bad"] .smk,.pj-sub[data-st="bad"] .sst{color:var(--red)} .pj-sub[data-st="run"] .sst{color:var(--t1)}
  .pj-subh .stx{min-width:0;overflow-wrap:anywhere;font-variant-numeric:tabular-nums}
  .pj-subh .stx b{font-weight:600;color:var(--t2)} .pj-subh .sds{color:var(--t2)}
  .pj-subh>svg{flex:none;width:12px;height:12px;margin-top:4px;transform:rotate(90deg);transition:transform .16s ease}
  .pj-subh[aria-expanded="true"]>svg{transform:rotate(-90deg)}
  .pj-subb{margin:4px 0 4px 22px;padding:2px 0 2px 12px;border-left:1px solid var(--line);font-size:13.5px;line-height:1.6;color:var(--t2);-webkit-user-select:text;user-select:text}
  .pj-subb h5{margin:8px 0 2px;font-size:12px;font-weight:600;line-height:18px;color:var(--t3)} .pj-subb h5:first-child{margin-top:0}
  .pj-subb .bf,.pj-subb .rp{white-space:pre-wrap;overflow-wrap:anywhere} .pj-subb .bf{max-height:220px;overflow-y:auto} .pj-subb .no{color:var(--t3)}
  .pj-subsum{align-self:flex-start;display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;max-width:100%;font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-subsum button{position:relative;margin-left:-4px;padding:2px 4px;border-radius:6px;font-weight:600;color:var(--t2)}
  @media(pointer:coarse){.pj-subh{min-height:44px;align-items:center}.pj-subh>svg{margin-top:0}.pj-subsum button::after{content:"";position:absolute;inset:-12px -6px}}
  @media(prefers-reduced-motion:reduce){.pj-subh>svg{transition:none}}
  .pj-tfold{align-self:flex-start;display:inline-flex;align-items:center;gap:4px;min-height:22px;margin:-2px 0 0 -6px;padding:0 4px 0 6px;border-radius:6px;
    font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums;cursor:pointer}
  .pj-tfold:hover{background:var(--btn);color:var(--t2)}
  .pj-tfold svg{width:12px;height:12px;flex:none;transform:rotate(90deg);transition:transform .16s ease}
  .pj-tfold[aria-expanded="true"] svg{transform:rotate(-90deg)}
  @media(pointer:coarse){.pj-tfold{min-height:32px}}
  @media(prefers-reduced-motion:reduce){.pj-tfold svg{transition:none}}
  .fl-body .pj-msg.claude:has(+.pj-tfold) .fl-meta{display:none}
  /* The first look reads the end of a long record: this row at the head of the log brings what was said before it. */
  .pj-older{align-self:center;display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:28px;padding:0 12px;border-radius:999px;
    font-size:12px;line-height:18px;color:var(--t3);cursor:pointer}
  .pj-older:hover{background:var(--btn);color:var(--t1)}
  .pj-older:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-older .pj-spin{display:none} .pj-older[aria-busy="true"] .pj-spin{display:block}
  @media(pointer:coarse){.pj-older{min-height:44px;padding:0 16px;font-size:13px}}
  /* The log is what was said; what a turn did is one quiet row per run that opens on its lines
     (2026-10-08; before that the lines were hidden outright, user 2026-10-05). A line opens on
     the command, what came back, and an edit's diff. */
  .pj-msg.tool.act{white-space:normal;overflow:visible;max-width:min(100%,820px);min-width:0;margin-left:-6px}
  .pj-msg.act>.ah{display:flex;align-items:center;gap:6px;max-width:100%;min-width:0;padding:1px 6px;border-radius:6px;font:inherit;color:inherit;text-align:left;cursor:pointer}
  .pj-msg.act>.ah:hover{background:var(--btn);color:var(--t2)}
  .pj-msg.act>.ah:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-msg.act>.ah b{flex:none;font-weight:600;color:var(--t2)}
  .pj-msg.act .aw{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-msg.act .am{flex:none;display:inline-flex;gap:6px;font-variant-numeric:tabular-nums} .pj-msg.act .am:empty{display:none}
  .pj-msg.act .am i,.pj-chgs .n i{font-style:normal} .pj-msg.act .bad{color:var(--red,#d9534f)}
  .pj-msg.act i.da,.pj-chgs i.da{color:var(--green,#3a9d5d)} .pj-msg.act i.dd,.pj-chgs i.dd{color:var(--red,#d9534f)}
  .pj-msg.act>.ab{margin:4px 0 8px 6px;padding-left:10px;border-left:1px solid var(--line);-webkit-user-select:text;user-select:text}
  .pj-msg.act pre{margin:0 0 4px;font:inherit;line-height:18px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow-y:auto}
  .pj-msg.act pre.ac{color:var(--t2)} .pj-msg.act pre.ar.bad{color:var(--red,#d9534f)}
  .pj-msg.act .at{font-family:var(--font,inherit);font-size:13px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow-y:auto}
  .pj-msg.act .an{display:flex;align-items:center;gap:10px;font-family:var(--font,inherit)}
  .pj-msg.act .an button{position:relative;padding:2px 4px;margin-left:-4px;border-radius:6px;font-weight:600;color:var(--t2);cursor:pointer}
  .pj-diff{margin:0 0 6px;max-width:100%;overflow-x:auto;border:1px solid var(--line);border-radius:8px;font:12px/18px ui-monospace,Menlo,Consolas,"Pretendard Variable",monospace;color:var(--t2)}
  .pj-diff>div{white-space:pre;padding:0 8px;min-width:max-content}
  .pj-diff .dh{color:var(--t3)} .pj-diff .da{background:rgba(58,157,93,.14)} .pj-diff .dd{background:rgba(217,83,79,.14)}
  .pj-dnone{font-size:12px;line-height:18px;color:var(--t3)}
  .pj-msg.user.clip>.ut{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:8;overflow:hidden}
  .pj-msg.user>.um{display:block;position:relative;margin-top:4px;font-size:12px;line-height:18px;font-weight:600;color:var(--t2);cursor:pointer}
  .pj-quote{position:absolute;z-index:3;min-height:28px;padding:0 10px;border:1px solid var(--line);border-radius:999px;background:var(--bg);color:var(--t1);font-size:12px;font-weight:600;box-shadow:0 2px 8px rgba(0,0,0,.18)}
  @media(pointer:coarse){.pj-quote{min-height:44px;padding:0 16px;font-size:13px}.pj-msg.user>.um::after{content:"";position:absolute;inset:-13px -10px}}
  /* A line kept (고정): its mark sits under the copy button. A pointer shows it on hover; on a kept
     line it stays, so the line is known at a glance and a finger can let it go. */
  .pj-bk{position:absolute;display:grid;place-items:center;width:28px;height:24px;border-radius:6px;color:var(--t3);opacity:0;transition:opacity .14s ease,background-color .14s ease,color .14s ease}
  .pj-bk svg{width:14px;height:14px;fill:currentColor}
  .pj-msg.claude>.pj-bk{left:100%;top:24px}
  .pj-msg.user>.pj-bk{right:calc(100% + 28px);top:-4px}
  /* A kept line wears a plate: with a pale accent the colour alone is the text colour and says nothing. */
  .pj-msg[data-mk]>.pj-bk{opacity:1;color:var(--blue-t);background:var(--blue-w)}
  .pj-bk:focus-visible{opacity:1;outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-msg:hover>.pj-bk{opacity:1}.pj-bk:hover{color:var(--t1);background:var(--btn)}}
  @media(pointer:coarse){.pj-msg:not([data-mk])>.pj-bk{display:none}.pj-msg.claude>.pj-bk{top:0}.pj-msg.user>.pj-bk{right:100%;top:0}.pj-bk::after{content:"";position:absolute;inset:-10px -8px}}
  /* 차례 목록 and 자주 쓰는 문구: one line and a quiet line under it per row, in the app's sheet. */
  .pj-tl .tl-rows{display:flex;flex-direction:column;gap:2px;margin:0 -8px 8px}
  .pj-tl .tl-row{display:flex;align-items:center;gap:4px;min-width:0}
  .pj-tl .tl-go{flex:1;min-width:0;display:block;min-height:44px;padding:6px 8px;border-radius:10px;text-align:left}
  .pj-tl .tl-go .t{display:block;font-size:14px;line-height:1.45;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-tl.sn .tl-go .t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:pre-wrap;overflow-wrap:anywhere}
  .pj-tl .tl-go .s{display:block;margin-top:2px;font-size:12px;line-height:1.4;color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-tl .tl-x{flex:none;display:grid;place-items:center;width:44px;height:44px;border-radius:10px;color:var(--t3)}
  .pj-tl .tl-x svg{width:16px;height:16px;fill:currentColor}
  .pj-tl .tl-none{margin:4px 0 8px;font-size:13px;line-height:1.5;color:var(--t3)}
  .pj-tl .tl-go:focus-visible,.pj-tl .tl-x:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){.pj-tl .tl-go:hover,.pj-tl .tl-x:hover{background:var(--card-hi)}.pj-tl .tl-x:hover{color:var(--t1)}}
  /* A result the session pushed, in the log where it was pushed: it opens the result. */
  .pj-rc{align-self:flex-start;flex:none;display:flex;align-items:center;gap:10px;max-width:min(88%,420px);min-height:48px;padding:6px 14px 6px 6px;border-radius:12px;background:var(--card);text-align:left}
  .pj-rc .th{position:relative;flex:none;display:grid;place-items:center;width:36px;height:36px;border-radius:8px;overflow:hidden;background:var(--bg);color:var(--t3)}
  .pj-rc .th svg{width:16px;height:16px;fill:currentColor} .pj-rc .th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover} .pj-rc .th .play{display:none}
  .pj-rc .tx{min-width:0} .pj-rc .t{font-size:13.5px;font-weight:600;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .pj-rc .s{font-size:12px;line-height:1.4;color:var(--t3)}
  .pj-rc:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-rc:hover{background:var(--card-hi)}}
  /* The result a comment line names, as a way to it. */
  .pj-lk{font:inherit;color:inherit;text-decoration:underline;text-underline-offset:3px;text-decoration-color:color-mix(in srgb,currentColor 45%,transparent);cursor:pointer}
  /* What the list's search found inside the records, under the sessions it found by name. */
  .pj-talk{margin:12px 0 8px}
  .pj-talk .h{padding:0 12px 4px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-tk{display:block;width:100%;min-height:44px;padding:8px 12px;border-radius:var(--r-lg);text-align:left}
  .pj-tk .t{display:flex;gap:6px;font-size:13px;font-weight:600;line-height:1.4;color:var(--t1)} .pj-tk .t span{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .pj-tk .t i{flex:none;font-style:normal;font-weight:500;color:var(--t3)}
  .pj-tk .x{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:2px;font-size:12.5px;line-height:1.45;color:var(--t3);overflow-wrap:anywhere}
  .pj-tk mark{background:none;color:var(--t1);font-weight:600}
  .pj-tk:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){.pj-tk:hover{background:var(--card-hi)}}
  .pj-files.pj-chgs .rw{display:block;padding:0} .pj-chgs .rw>button{display:flex;gap:8px;width:100%;min-height:44px;align-items:center;padding:8px 2px;text-align:left;cursor:pointer}
  .pj-files.pj-chgs .dv,.pj-files.pj-chgs .dv div{display:block;min-width:0;padding:0;border-top:0;font-size:inherit}
  .pj-files.pj-chgs .dv{padding-bottom:8px} .pj-files.pj-chgs .pj-diff{border:1px solid var(--line);font-size:12px} .pj-files.pj-chgs .pj-diff>div{padding:0 8px;min-width:max-content}
  @media(pointer:coarse){.pj-msg.act>.ah{min-height:44px}.pj-msg.act .an button::after{content:"";position:absolute;inset:-12px -6px}}
  /* The session's task list, on demand: one quiet line above the box that opens on the items. */
  .pj-todo{padding:6px 12px 0;font-size:12px;line-height:18px;color:var(--t3)} .pj-todo[hidden]{display:none}
  .pj-todo>button{display:flex;align-items:center;gap:6px;max-width:100%;min-width:0;padding:2px 6px;margin-left:-6px;border-radius:6px;color:inherit;text-align:left;cursor:pointer}
  .pj-todo>button:hover{background:var(--btn);color:var(--t2)}
  .pj-todo>button b{flex:none;font-weight:600;color:var(--t2);font-variant-numeric:tabular-nums}
  .pj-todo>button span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-todo>button svg{width:12px;height:12px;flex:none;transform:rotate(90deg)} .pj-todo>button[aria-expanded="true"] svg{transform:rotate(-90deg)}
  .pj-todo ul{list-style:none;margin:2px 0 4px;padding:0;max-height:min(40vh,260px);overflow-y:auto}
  .pj-todo li{display:flex;gap:8px;padding:2px 0;color:var(--t2);overflow-wrap:anywhere}
  .pj-todo li::before{content:"";flex:none;width:10px;height:10px;margin-top:4px;border-radius:50%;border:1.5px solid var(--t3);box-sizing:border-box}
  .pj-todo li.in_progress{color:var(--t1)} .pj-todo li.in_progress::before{border-color:var(--accent,var(--t1));background:radial-gradient(var(--accent,var(--t1)) 38%,transparent 42%)}
  .pj-todo li.completed{color:var(--t3);text-decoration:line-through} .pj-todo li.completed::before{background:var(--t3)}
  @media(pointer:coarse){.pj-todo>button{min-height:44px}}
  /* When a line was said, small and quiet, the way a messenger shows it: beside my bubble (which
     leaves room for it), under what the session wrote. A run from one side within a minute shows
     it once, on its last line; a new day gets a line of its own across the log. */
  .pj-tm{font-size:12px;line-height:16px;font-weight:400;letter-spacing:0;color:var(--t3);font-variant-numeric:tabular-nums;
    white-space:nowrap;-webkit-user-select:none;user-select:none}
  .pj-tm[hidden]{display:none}
  .pj-msg.user{position:relative;max-width:min(88%,calc(100% - 72px))}
  .pj-msg.user>.pj-tm{position:absolute;right:100%;bottom:0;margin-right:6px}
  .pj-msg.claude>.pj-tm{display:block;margin-top:4px}
  .fl-body .pj-msg.claude>.pj-tm{display:none}
  .pj-day{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:11.5px;line-height:16px;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-day:before,.pj-day:after{content:"";flex:1;height:1px;background:var(--line)}
  /* The session's lines are read as markdown (markdown.js, the same reader as a pushed document). */
  .pj-md{white-space:normal}
  /* Reading: a paragraph apart from the next by most of a line, list rows apart, headings a size up,
     the bold words at full weight. One block run into the next read as a wall of text. */
  .pj-md p,.pj-md ul,.pj-md ol{margin:0 0 12px}
  .pj-md li{margin:6px 0}.pj-md li>:is(p,ul,ol){margin-bottom:6px}
  .pj-md h1,.pj-md h2{font-size:1.2em;font-weight:700;line-height:1.4;margin:20px 0 8px}
  .pj-md h3,.pj-md h4{font-size:1.08em;font-weight:700;line-height:1.45;margin:16px 0 6px}
  .pj-md strong{font-weight:700}
  .pj-md>:first-child{margin-top:0}.pj-md>:last-child{margin-bottom:0}
  .pj-md code,.pj-msg.tool{font-family:ui-monospace,Menlo,Consolas,"Pretendard Variable",monospace}
  .pj-md code{font-size:12px}
  .pj-md pre{max-width:100%;margin:0 0 6px}
  /* A word said in code is a small chip in a warm tone, so it stands out of the sentence around it. */
  .pj-md :not(pre)>code{padding:1px 5px;border-radius:6px;background:color-mix(in srgb,var(--t1) 7%,transparent);box-shadow:inset 0 0 0 1px var(--line);
    color:color-mix(in srgb,var(--red) 72%,var(--t1))}
  /* A table: one rounded frame, rows parted by a line, the head quiet, the first column the row's name.
     A cell folds between words (the chat's own break-anywhere crushed a narrow column to "Op / us");
     the frame scrolls only when a single word is wider than the room. */
  .pj-md .doc-table{max-width:100%;margin:0 0 12px;border-radius:12px;box-shadow:inset 0 0 0 1px var(--line);overflow-x:auto}
  .pj-md table{width:100%;border-collapse:collapse;font-size:.93em;line-height:1.5}
  .pj-md th,.pj-md td{border:0;border-top:1px solid var(--line);padding:10px 12px;text-align:left;vertical-align:top;overflow-wrap:break-word;word-break:keep-all}
  .pj-md thead th{border-top:0;font-weight:500;color:var(--t2);background:color-mix(in srgb,var(--t1) 5%,transparent)}
  .pj-md td:first-child{font-weight:700}
  /* Code in a cell folds anywhere, so it is plain warm text there (a chip broken over six lines read as
     a stack of boxes) and its column keeps a floor: a cramped table scrolls a little before it goes four letters wide. */
  .pj-md td code{overflow-wrap:anywhere;padding:0;background:none;box-shadow:none}
  .pj-md td:has(code){min-width:112px}
  /* Copy: one small button per line of the chat (beside the bubble, in the room it leaves free)
     and one per code block. A pointer shows it on hover or focus and it fades where it is; a
     finger holds the line (or the code block) instead, so it has no button there. */
  .pj-msg.claude{position:relative}
  .pj-cp{position:absolute;display:grid;place-items:center;width:28px;height:24px;border-radius:6px;color:var(--t3);opacity:0;transition:opacity .14s ease,background-color .14s ease,color .14s ease}
  .pj-cp svg{width:14px;height:14px;fill:currentColor}
  .pj-msg.claude>.pj-cp{left:100%;top:0}
  .pj-msg.user>.pj-cp{right:100%;top:-4px}
  /* A code block: a head with its name and the copy button (always there, a finger has it too), and
     the code wrapped under it. Long lines fold: nothing in the chat slides sideways. */
  .pj-prew{position:relative;max-width:100%;margin:0 0 12px;border-radius:12px;overflow:hidden;box-shadow:inset 0 0 0 1px var(--line)}
  .pj-prew::before{content:attr(data-l);display:block;height:36px;padding:0 48px 0 12px;font-size:12px;font-weight:500;line-height:36px;color:var(--t3);background:color-mix(in srgb,var(--t1) 5%,transparent);
    border-bottom:1px solid var(--line);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}
  .pj-md .pj-prew pre{margin:0;padding:10px 12px;border-radius:0;white-space:pre-wrap;overflow-wrap:anywhere;word-break:normal;line-height:1.55}
  .pj-prew>.pj-cp{right:4px;top:4px;width:28px;height:28px;opacity:1}
  .pj-cp:focus-visible{opacity:1;outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-msg:hover>.pj-cp,.pj-prew:hover>.pj-cp{opacity:1}.pj-cp:hover{color:var(--t1);background:var(--btn)}}
  /* A finger: the code's button is a 44px press; the last answer keeps one copy button under it
     (the older lines are held instead). */
  @media(pointer:coarse){.pj-msg>.pj-cp{display:none}
    .pj-prew::before{height:44px;line-height:44px;font-size:13px}
    .pj-prew>.pj-cp{right:0;top:0;width:44px;height:44px}.pj-prew>.pj-cp svg{width:18px;height:18px}
    .pj-msgs>.pj-msg.claude:nth-last-child(1 of .pj-msg.claude)>.pj-cp{display:grid;position:static;opacity:1;width:44px;height:44px;margin:4px 0 -8px -13px}
    .pj-msgs>.pj-msg.claude:nth-last-child(1 of .pj-msg.claude)>.pj-cp svg{width:18px;height:18px}}
  @media(prefers-reduced-motion:reduce){.pj-cp{transition:none}}
  /* A line of mine on its way: it is on the screen at once, dimmed with a small ring until the
     server has it; one that did not get through stays, outlined, with the way to send it again. */
  .pj-msg.pending{opacity:.68}
  .pj-msg .tg{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:4px;font-size:12px;line-height:16px;color:var(--t3);
    font-family:inherit;white-space:nowrap;height:auto;min-height:0;max-width:none;padding:0;border-radius:0;background:none;font-weight:400}
  .pj-msg .tg .pj-spin{width:9px;height:9px}
  .pj-msg.failed{box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--red) 60%,transparent)}
  .pj-msg .tg.bad{color:var(--red);flex-wrap:wrap;white-space:normal;margin-top:6px}
  .pj-msg .tg.bad svg{width:12px;height:12px;flex:none}
  .pj-msg .tg button{height:22px;padding:0 8px;border-radius:6px;background:var(--bg);color:var(--t1);font-size:11.5px;font-weight:600}
  .pj-msg .tg button:hover{background:var(--card)}
  /* The message box is one field: picture, text and send inside a single border. Focus is the
     field's own edge taking the accent with a soft ring around it (v2.css --focus-line/--focus-glow),
     not a heavy outline on the text area alone. */
  .pj-in{padding:8px 12px 12px;border-top:1px solid var(--line)}
  .pj-box{display:flex;align-items:flex-end;gap:2px;padding:4px;border-radius:12px;background:var(--bg);border:1px solid var(--line);cursor:text;
    transition:border-color .14s ease,box-shadow .14s ease}
  @media(hover:hover){.pj-box:hover:not(:focus-within){border-color:color-mix(in srgb,var(--t4) 70%,transparent)}}
  .pj-box:focus-within{border-color:var(--focus-line);box-shadow:0 0 0 3px var(--focus-glow)}
  .pj-go{flex:none;width:34px;height:34px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;
    background:var(--t1);color:var(--bg);transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  .pj-go svg{width:17px;height:17px}
  .pj-go .pj-spin{display:none}
  @media(hover:hover){.pj-go:hover:not(:disabled){background:color-mix(in srgb,var(--t1) 86%,var(--bg))}}
  .pj-go:active:not(:disabled){background:color-mix(in srgb,var(--t1) 74%,var(--bg))}
  .pj-go:disabled{background:var(--btn);color:var(--t3);box-shadow:inset 0 0 0 1px var(--line);cursor:default}
  .pj-go.busy:disabled svg{display:none} .pj-go.busy:disabled .pj-spin{display:block}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-go,.pj-box .pj-clip{width:36px;height:36px}
    /* The send button keeps its 36px look; the area a finger can hit is 44px. */
    .pj-go{position:relative}.pj-go::before{content:"";position:absolute;inset:-4px;border-radius:50%}}
  html[data-theme="light"] .pj-go:not(:disabled){background:#111114;color:#fff}
  @media(hover:hover){html[data-theme="light"] .pj-go:hover:not(:disabled){background:#2a2a30}}
  html[data-theme="light"] .pj-go:active:not(:disabled){background:#3a3a41}
  @media(prefers-reduced-motion:reduce){.pj-box,.pj-go,.pj-clip{transition:none}}
  /* Who receives the next message: one line, the same wherever something is about to be sent. */
  .pj-to{display:flex;align-items:center;gap:6px;min-width:0;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-to:empty{display:none}
  .pj-to .k{flex:none} .pj-to .pj-em{flex:none;font-size:13px;width:auto} .pj-to .pj-ag{flex:none}
  .pj-to b{flex:0 1 auto;min-width:0;font-weight:600;color:var(--t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-to .s{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-conv>.pj-to{padding:8px 12px 0;border-top:1px solid var(--line)}
  /* 가림 모드 is on: said once, quietly, over the box, with the way back beside it. */
  .pj-rd{display:flex;align-items:center;gap:6px;padding:6px 12px 0;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-rd[hidden]{display:none}
  .pj-rd svg{flex:none;width:14px;height:14px}
  .pj-rd button{position:relative;font-weight:600;color:var(--t2);text-decoration:underline;text-underline-offset:3px}
  .pj-rd button::after{content:"";position:absolute;inset:-13px -10px}
  .pj-rd+.pj-to{border-top:0;padding-top:2px}
  .pj-conv>.pj-to+.pj-in{border-top:0;padding-top:6px}
  .pj-all+.pj-to{padding:6px 12px 0} .pj-nfoot .pj-to{margin-bottom:6px}
  .pj-head .ow{display:flex;align-items:center;gap:6px;min-width:0;max-width:100%;margin-top:4px;padding:0;font-size:12px;color:var(--t3);text-align:left}
  .pj-head .ow .t{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--t2)}
  .pj-head .ow .k,.pj-head .ow .st{flex:none}
  .pj-gh .pj-gn{display:inline-flex;align-items:center;width:22px;height:22px;justify-content:center;border-radius:6px;color:var(--t4)}
  .pj-gh .pj-gn svg{width:13px;height:13px}
  @media(hover:hover){.pj-gh .pj-gn:hover{background:var(--btn);color:var(--t1)}}
  .pj-in textarea{flex:1;min-width:0;resize:none;background:none;border:0;border-radius:0;color:var(--t1);outline:none;
    font:inherit;font-size:14.5px;line-height:1.5;letter-spacing:inherit;word-break:keep-all;overflow-wrap:anywhere;
    padding:6px 6px;min-height:34px;max-height:160px}
  .pj-in textarea::placeholder{color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-item{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:8px 12px;border-radius:8px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-item:hover{background:var(--card-hi)}
  .pj-item .tx{flex:1;min-width:0}
  .pj-item .t{font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-item .s{font-size:12px;color:var(--t3);margin-top:1px}
  .pj-item .cm{font-size:12px;font-weight:600;color:var(--orange)}
  .pj-cur{display:flex;align-items:center;gap:8px;width:100%;background:var(--card);border-radius:var(--r-card);padding:12px 16px;text-align:left;min-width:0}
  .pj-cur .t{flex:1;min-width:0;font-size:14.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-cur .s{font-size:12px;color:var(--t3)}
  .pj-dlg h3{margin:2px 0 4px;font-size:16px;font-weight:600;letter-spacing:-.01em;line-height:1.4}
  .pj-dlg .acts{display:flex;flex-direction:column;gap:6px;margin-top:20px}
  .pj-dlg .row2{display:flex;gap:6px;justify-content:center}
  .pj-access .hint{white-space:normal;overflow-wrap:anywhere}
  .pj-access dl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px 16px;margin:20px 0}
  .pj-access-run dl{margin-top:0;padding-top:20px;border-top:1px solid var(--line)}
  .pj-access dt,.pj-access dd{margin:0;overflow-wrap:anywhere}
  .pj-access dd{color:var(--t2);text-align:right}
  .pj-access [data-access-settings]{min-height:44px;width:100%;white-space:normal;margin-top:12px}
  .pj-dot.stuck{background:var(--red)}
  .pj-un{flex:none;min-width:18px;height:18px;padding:0 4px;border-radius:8px;background:var(--blue);color:#fff;font-size:12px;font-weight:700;line-height:18px;text-align:center}
  .pj-rbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 8px;margin:0 0 8px;padding:8px 12px;border-radius:var(--r-sm);background:var(--btn);font-size:12px;line-height:1.5;color:var(--t2)}
  .pj-rbar>span:first-child{flex:1 1 180px;min-width:0}.pj-rbar .a{display:flex;gap:6px;flex:none}
  .pj-rbar .pj-btn{height:30px;padding:0 12px;font-size:12px}
  .pj-conv>.pj-rbar{flex:none;margin:0 12px 8px}
  .pj-note{padding:8px 16px;font-size:12px;line-height:1.5;color:var(--t2);border-bottom:1px solid var(--line);background:var(--card)}
  .pj-note.bad{color:var(--red)}
  .pj-note:empty{display:none}
  .pj-note b{font-weight:600;color:var(--t1)}
  .pj-chg{display:inline-flex;align-items:center;gap:6px;height:24px;padding:0 8px;border-radius:6px;background:var(--btn);
    color:var(--t2);font-size:12px;font-weight:600;flex:none;transition:background .15s}
  .pj-chg:hover{background:var(--btn-hi);color:var(--t1)}
  .pj-chg .a{color:var(--green)} .pj-chg .d{color:var(--red)}
  .pj-files{display:flex;flex-direction:column;margin:8px 0 2px;max-height:52vh;overflow:auto}
  .pj-files div{display:flex;gap:8px;padding:8px 2px;border-top:1px solid var(--line);font-size:13px;min-width:0}
  .pj-files .p{flex:1;min-width:0;overflow-wrap:anywhere;color:var(--t1)}
  .pj-files .n{flex:none;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-log{margin:8px 0 0;padding:12px;max-height:56vh;overflow:auto;background:var(--bg);border-radius:8px;
    font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;color:var(--t2);white-space:pre-wrap;overflow-wrap:anywhere}
  .pj-unread{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600;letter-spacing:.08em;color:var(--red);flex:none}
  .pj-unread:before,.pj-unread:after{content:"";flex:1;height:1px;background:currentColor;opacity:.35}
  .pj-att{display:flex;gap:8px;flex-wrap:wrap;padding:8px 12px 0}
  .pj-att .th{position:relative;width:56px;height:56px;border-radius:8px;overflow:hidden;background:var(--bg)}
  .pj-att img{width:100%;height:100%;object-fit:cover;display:block}
  .pj-att .th.doc{display:flex;align-items:center;gap:6px;width:auto;height:36px;max-width:min(220px,100%);padding:0 8px 0 10px;border:1px solid var(--line);font-size:12px;color:var(--t2)}
  .pj-att .th.doc button{position:relative;top:auto;right:auto;flex:none} @media(pointer:coarse){.pj-att .th.doc{height:44px}}
  .pj-att .th.doc>svg{flex:none;width:14px;height:14px;color:var(--t3)} .pj-att .th.doc span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-att button{position:absolute;top:2px;right:2px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;
    display:inline-flex;align-items:center;justify-content:center}
  .pj-att button svg{width:11px;height:11px}
  /* Pictures stand on their own above the words (mine: on the right), a tidy row of the same height. */
  .pj-pics{align-self:flex-end;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px;max-width:min(88%,460px);min-width:0}
  .pj-pics+.pj-msg{margin-top:-6px}
  .pj-pics.pending{opacity:.68}
  /* What the session sent (SendUserFile) sits on its side of the chat: pictures open in the viewer, other files in a tab. */
  .pj-pics.sent{align-self:flex-start;justify-content:flex-start}
  .pj-sent{align-self:flex-start;display:flex;flex-wrap:wrap;gap:6px;max-width:min(88%,460px);min-width:0}
  .pj-file{display:inline-flex;align-items:center;gap:6px;min-width:0;max-width:100%;min-height:32px;padding:4px 12px;border:1px solid var(--line);border-radius:10px;color:var(--t1);font-size:13px;text-decoration:none}
  .pj-file span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-file svg{flex:none;width:14px;height:14px;color:var(--t3)}
  @media(pointer:coarse){.pj-file{min-height:44px}}
  .pj-pic{flex:none;display:flex;justify-content:center;height:132px;min-width:72px;max-width:100%;padding:0;border-radius:12px;overflow:hidden;background:var(--btn);cursor:zoom-in}
  .pj-pics.one .pj-pic{height:200px}
  .pj-pic img{display:block;flex:none;height:100%;width:auto}
  .pj-md img{display:block;max-width:min(100%,360px);max-height:240px;margin:6px 0;border-radius:12px;cursor:zoom-in}
  /* What the session is doing right now, under the newest line. It keeps its room when it goes
     quiet, so the log does not move when the work ends. */
  .pj-now{align-self:flex-start;display:flex;align-items:center;gap:8px;max-width:100%;min-width:0;height:20px;font-size:12px;line-height:20px;color:var(--t3);transition:opacity .18s ease}
  .pj-now:not(.on){opacity:0;pointer-events:none}
  .pj-now .mk{flex:none;display:flex;align-items:center;--orb-ink:var(--sr-work,var(--t2))}
  .pj-now .mk i.st-dot{width:8px;height:8px;margin:0 3px;border-radius:50%;background:var(--sr-work,var(--t2))}
  .pj-now .tx{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--t2)}
  /* A row that carries a button (a line the session is holding) grows to fit it. */
  .pj-now:has([data-peeraccept]){height:auto}
  .pj-now .tx:has([data-peeraccept]){display:flex;align-items:center;gap:10px;overflow:visible}
  .pj-now .tx span{color:var(--t3)}
  .pj-now.bad{height:auto;align-items:flex-start}
  .pj-now.bad .tx{white-space:normal;color:var(--red)}
  .pj-now.bad .mk{color:var(--red);padding-top:4px}
  .pj-now.bad .mk svg{width:13px;height:13px}
  /* not ".sec": that is the app's section-label class (a margin and a heavier weight) */
  .pj-now .nsec{flex:none;margin:0;white-space:pre;font-variant-numeric:tabular-nums;text-transform:none;letter-spacing:0;font:inherit;line-height:20px;color:var(--t3)}
  .pj-conv.drop{outline:2px dashed var(--t4);outline-offset:-6px}
  .pj-clip{flex:none;width:34px;height:34px;border-radius:8px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center;
    transition:background-color .14s ease,color .14s ease}
  .pj-clip:hover{background:var(--btn);color:var(--t1)}
  .pj-clip svg{width:18px;height:18px}
  /* Speaking into the box. The mic sits beside send. While it listens the row is only what the
     words need: take them away, the level, stop (the words stay), send (they go at once). */
  .pj-mic .i+.i,.pj-vx,.pj-wave{display:none}
  .pj-in .pj-box.pj-rec :is(#pj-clip,.pj-mwrap,.pj-pjn,.pj-enter,.pj-agseg){display:none}
  .pj-in .pj-box.pj-rec .pj-vx{display:inline-flex}
  .pj-in .pj-box.pj-rec :is(.pj-vx,.pj-mic){border:0;border-radius:50%;background:var(--btn);color:var(--t1)}
  @media(hover:hover){.pj-in .pj-box.pj-rec :is(.pj-vx,.pj-mic):hover{background:var(--btn-hi)}}
  .pj-box.pj-rec .pj-mic .i{display:none}.pj-box.pj-rec .pj-mic .i+.i{display:block;width:14px;height:14px}
  .pj-box.pj-rec .pj-wave{flex:1 1 0;min-width:0;height:34px;display:flex;align-items:center;justify-content:flex-end;gap:3px;padding:0 8px;overflow:hidden}
  .pj-wrap{position:relative}
  /* The way down to the newest line: a round button over the log's bottom edge, there only while
     the end is out of sight. Lines that arrived meanwhile are a count on it, not a second control. */
  .pj-newpill{position:absolute;left:50%;bottom:12px;width:32px;height:32px;margin-left:-16px;border-radius:50%;
    display:grid;place-items:center;background:var(--btn-hi);color:var(--t1);
    box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--t1) 16%,transparent),0 4px 14px rgba(0,0,0,.32);
    opacity:0;visibility:hidden;translate:0 4px;transition:opacity .14s ease,translate .14s ease,background-color .14s ease,visibility 0s .14s}
  .pj-newpill.on{opacity:1;visibility:visible;translate:none;transition-delay:0s}
  .pj-newpill svg{width:16px;height:16px;transform:rotate(180deg)}
  .pj-newpill b{position:absolute;top:-7px;right:-9px;min-width:17px;height:17px;padding:0 4px;border-radius:8px;display:grid;place-items:center;
    background:var(--blue);color:var(--on-blue,#fff);font-size:12px;font-weight:700;line-height:1;font-variant-numeric:tabular-nums;box-shadow:0 0 0 2px var(--card)}
  .pj-newpill b:empty{display:none}
  .pj-newpill:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  .pj-msgs:focus{outline:none}
  /* Find in this conversation (Ctrl+F, or its menu): a bar over the log's top edge that fades in
     place. Matches are marked by the highlight API, so no line is drawn again for it. */
  .pj-find{position:absolute;top:8px;right:12px;z-index:3;display:flex;align-items:center;gap:2px;max-width:calc(100% - 24px);padding:4px 4px 4px 12px;border-radius:12px;
    background:var(--btn-hi);color:var(--t1);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--t1) 16%,transparent),0 4px 14px rgba(0,0,0,.32);
    opacity:0;visibility:hidden;transition:opacity .14s ease,visibility 0s .14s}
  .pj-find.on{opacity:1;visibility:visible;transition-delay:0s}
  .pj-find>svg{flex:none;width:15px;height:15px;color:var(--t3)}
  .pj-find input{flex:1 1 auto;min-width:0;width:190px;height:30px;padding:0 6px;border:0;background:none;color:inherit;font:inherit;font-size:14px;outline:none}
  .pj-find input::-webkit-search-cancel-button{display:none}
  .pj-find .n{flex:none;min-width:36px;text-align:right;font-size:12px;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap}
  .pj-find button{flex:none;width:30px;height:30px;border-radius:8px;display:grid;place-items:center;color:var(--t2)}
  .pj-find button:hover{background:var(--btn);color:var(--t1)}
  .pj-find button:disabled{color:var(--t4);background:none}
  .pj-find button svg{width:15px;height:15px}
  .pj-find [data-fd="1"] svg{transform:rotate(180deg)}
  ::highlight(pj-find){background-color:color-mix(in srgb,var(--blue) 32%,transparent);color:inherit}
  ::highlight(pj-find-on){background-color:var(--blue);color:var(--on-blue,#fff)}
  @media (prefers-reduced-motion:reduce){.pj-find{transition:none}}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    .pj-find{left:10px;right:10px;max-width:none;padding-left:12px}
    .pj-find input{width:auto;height:40px;font-size:16px}
    .pj-find button{width:44px;height:44px}}
  @media(hover:hover){.pj-newpill:hover{background:color-mix(in srgb,var(--t1) 12%,var(--btn-hi))}}
  @media(pointer:coarse){.pj-newpill::after{content:"";position:absolute;inset:-6px}}
  @media(prefers-reduced-motion:reduce){.pj-newpill{translate:none;transition:opacity .14s ease,visibility 0s .14s}}
  .pj-tip{display:flex;align-items:center;gap:8px;padding:8px 16px;font-size:12px;color:var(--t2);border-bottom:1px solid var(--line)}
  .pj-tip[hidden]{display:none}
  .pj-tip span{flex:1;min-width:0}
  .pj-tip button{flex:none;width:24px;height:24px;border-radius:6px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center}
  .pj-tip button:hover{background:var(--btn);color:var(--t1)}
  .pj-tip svg{width:12px;height:12px}
  .pj-spin{flex:none;width:12px;height:12px;border-radius:50%;border:1.5px solid var(--t4);border-top-color:var(--t1);animation:pj-turn .9s linear infinite}
  @keyframes pj-turn{to{transform:rotate(360deg)}}
  @media(prefers-reduced-motion:reduce){.pj-spin{animation:none}}
  .pj-state .off{color:var(--orange);font-size:12px}
  .pj-msg .tg.ok{color:var(--green)}
  .pj-rail{min-width:0}
  .pj-rail .pj-lab:first-child{margin-top:4px}
  .pj-row{padding:8px 12px;gap:4px;border-radius:8px;margin-bottom:4px}
  .pj-row .t{font-size:13px;-webkit-line-clamp:1}
  .pj-row .r1{align-items:center;gap:8px}
  .pj-row .r2{gap:6px;font-size:11.5px}
  .pj-row .pj-more{margin:-2px -4px -2px 0}
  .pj-fold{display:flex;align-items:center;gap:6px;width:100%;padding:8px 2px;margin-top:4px;font-size:12px;color:var(--t3);text-align:left}
  .pj-fold:hover{color:var(--t1)}
  .pj-unl{display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;padding:8px 2px 4px;margin-top:4px;font-size:12px;line-height:1.5;color:var(--t3)}
  .pj-unl>span{flex:1 1 180px;min-width:0;word-break:keep-all}
  .pj-unl .pj-text{flex:none;height:28px;padding:0 8px;margin:0 -8px 0 0;font-size:12px;color:var(--t2)}
  .pj-fold svg{width:12px;height:12px;transition:transform .2s cubic-bezier(.2,.9,.25,1)}
  .pj-fold[aria-expanded="true"] svg{transform:rotate(90deg)}
  .pj-res{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:8px;border-radius:12px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-res:hover{background:var(--card-hi)}
  .pj-res .th{position:relative;flex:none;width:64px;height:64px;border-radius:8px;overflow:hidden;background:var(--bg);
    display:flex;align-items:center;justify-content:center;color:var(--t3)}
  .pj-res .th svg{width:22px;height:22px}
  .pj-res .th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
  .pj-res .th .play{position:absolute;right:4px;bottom:4px;width:18px;height:18px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;
    display:flex;align-items:center;justify-content:center}
  .pj-res .th .play svg{width:10px;height:10px}
  .pj-res .tx{flex:1;min-width:0}
  .pj-res .t{font-size:13px;font-weight:600;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
  .pj-res .s{font-size:12px;color:var(--t3);margin-top:2px}
  .pj-head{position:relative}
  .pj-top{display:flex;align-items:center;gap:8px;margin:4px 0 2px;flex-wrap:wrap;min-width:0}
  .pj-top .sp{flex:1}
  /* Phone: search and 새 세션 share the first row, the quieter links the second. */
  @media(max-width:479px){.pj-top .pj-search{order:-2;flex:1 1 calc(100% - 120px)}.pj-top .pj-search~[data-new]{order:-1}}
  .pj-search{flex:1;min-width:0;height:36px;padding:0 12px;border-radius:8px;background:var(--card);border:1px solid var(--line);
    color:var(--t1);font:inherit;font-size:14px}
  .pj-search::placeholder{color:var(--t3)}
  .pj-search:focus{outline:none;border-color:var(--focus-line);box-shadow:0 0 0 3px var(--focus-glow)}
  .pj-em{display:inline-flex;align-items:center;justify-content:center;flex:none;width:24px;height:24px;font-size:16px;line-height:1;overflow:hidden;white-space:nowrap}
  .pj-head .em{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;overflow:hidden;white-space:nowrap}
  .sbox.pj-wide{overflow:hidden}
  .sbox.pj-wide>.pj-new{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.sbox.pj-wide{width:min(880px,calc(100vw - 48px))}}
  .pj-ntop{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
  .pj-dlg .pj-ntop .seg,.pj-dlg .pj-nrow .seg,.pj-dlg .pj-nfoot>div>.seg{margin-top:0}
  .pj-dlg .pj-ntop .pj-search{flex:1 1 180px;width:auto}
  .pj-pg{flex:1 1 auto;min-height:132px;overflow-y:auto;overscroll-behavior:contain;margin:8px -6px 0;padding:0 6px 8px}
  .pj-pgg{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
  /* Phone, 새로 만들기 open: the box left the list a strip. The sheet's body scrolls as one and the foot stays in view. */
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.sbox.pj-wide>.pj-new:has(>.pj-mkbox:not([hidden])){overflow-y:auto;overscroll-behavior:contain}
    .pj-new:has(>.pj-mkbox:not([hidden]))>.pj-pg{flex:none;min-height:0;overflow:visible;display:flex;flex-direction:column}
    .pj-pg>.pj-gh:has(+.pj-pgg>.pj-mk),.pj-pg>.pj-pgg:has(>.pj-mk){order:-1} .pj-pgg:has(>.pj-mk){grid-template-columns:minmax(0,1fr)}   /* the one being made shows first, under its box */
    .pj-new:has(>.pj-mkbox:not([hidden]))>.pj-nfoot{position:sticky;bottom:0;z-index:1;background:var(--card)}}
  @media(min-width:640px){.pj-pgg{grid-template-columns:repeat(3,minmax(0,1fr))}}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.pj-pgg{grid-template-columns:repeat(4,minmax(0,1fr))}}
  .pj-gh{display:flex;align-items:center;gap:6px;position:sticky;top:0;z-index:1;background:var(--card);padding:8px 2px 4px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-gh .n{color:var(--t4);font-variant-numeric:tabular-nums} .pj-gh .sp{flex:1}
  .pj-gh .pj-text{height:26px;padding:0 8px;font-size:12px}
  .pj-pc{display:flex;align-items:center;gap:8px;min-width:0;height:44px;padding:0 8px;border-radius:8px;background:var(--bg);border:1px solid transparent;
    text-align:left;font-size:13px;color:var(--t1);transition:background .15s,border-color .15s}
  .pj-pc:hover{background:var(--btn)}
  .pj-pc.on{background:var(--btn-hi);border-color:var(--t4)}
  .pj-pc.pj-mk{border:1px dashed var(--line2,var(--t4))}
  .pj-pc.pj-mk.on{border-style:solid}
  .pj-pc.pj-mk .pj-em svg{width:16px;height:16px}
  .pj-pc:focus-visible{outline:2px solid var(--t2);outline-offset:1px}
  .pj-pc .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-pc .pj-ck{width:18px;height:18px;opacity:0;transform:scale(.5);
    transition:transform .45s linear(0,.19 6%,.56 14%,.85 22%,1.01 30%,1.06 38%,1.05 46%,1.02 56%,1 68%,1),opacity .15s}
  .pj-pc.on .pj-ck{opacity:1;transform:none;background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-nfoot{flex:none;border-top:1px solid var(--line);padding-top:8px}
  .pj-nfoot .pj-ta2{min-height:56px;margin-top:0}
  .pj-nfoot [data-modebox]:not(:empty){margin-bottom:8px}
  .pj-nfoot .pj-hint{margin-top:8px;word-break:keep-all;overflow-wrap:anywhere} .pj-nfoot .pj-hint.err{color:var(--red)}
  .pj-nrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
  /* The very first chat (from the home guide, no project yet): the line and one button. The rest waits behind 더 보기. */
  .pj-first .pj-search,.pj-first .pj-mkbtn,.pj-first .pj-mkbox,.pj-first .pj-pg,.pj-first .pj-to,.pj-first [data-modelbox]{display:none!important}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.sbox.pj-wide:has(>.pj-first){width:min(480px,calc(100vw - 48px))}}
  .pj-first .pj-nfoot{border-top:0;padding-top:12px} .pj-first .pj-ta2{min-height:72px}
  .pj-new:not(.pj-first) [data-more]{display:none}
  .pj-nrow .sp{flex:1} .pj-nrow .pj-btn{min-width:112px}
  .pj-nrow>[data-modelbox]{min-width:0;max-width:100%;display:flex;flex-direction:column;align-items:flex-start}
  .pj-nrow>[data-modelbox][hidden]{display:none}
  .pj-new .pj-nrow{align-items:flex-start}
  @media(max-width:639px){.pj-nrow>[data-modelbox]{flex:1 1 100%;align-items:stretch}.pj-nrow>[data-modelbox] .seg{display:flex}.pj-nrow>[data-modelbox] .seg button{flex:1 1 auto;min-width:0;padding-left:6px;padding-right:6px}}
  .pj-mcap{margin:6px 2px 0;font-size:12px;line-height:1.4;color:var(--t3)}
  .pj-mcap:empty{display:none}
  @media(max-width:639px){.pj-nrow .pj-btn{flex:1 1 100%}.pj-nrow .sp{display:none}}
  .pj-pg.pj-res{display:flex;flex-direction:column;gap:4px}
  .pj-rr{display:flex;align-items:center;gap:8px;flex:none;width:100%;min-height:48px;padding:6px 12px;border-radius:8px;background:var(--bg);text-align:left;transition:opacity .2s,background .15s}
  button.pj-rr:hover{background:var(--btn)}
  .pj-rr .tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .pj-rr .t{font-size:14px;color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-rr .s{font-size:12px;line-height:1.45;color:var(--t3);word-break:keep-all;overflow-wrap:break-word}
  .pj-rr.wait{opacity:.55} .pj-rr.new .s,.pj-rr.keep .s{color:var(--t2)} .pj-rr.fail .s{color:var(--red)}
  .pj-rr .pj-ck{background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-rr .pj-ck.no{background:none;border-color:var(--t4);color:var(--t2);font-size:12px;font-weight:700}
  @media(prefers-reduced-motion:reduce){.pj-pc .pj-ck{transform:none;transition:opacity .2s}}
  .pj-badge{flex:none;min-width:20px;height:20px;padding:0 6px;border-radius:8px;background:var(--red);color:#fff;
    font-size:12px;font-weight:700;letter-spacing:0;display:inline-flex;align-items:center;justify-content:center;font-variant-numeric:tabular-nums}
  .pj-last{font-size:13px;line-height:1.45;color:var(--t2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
    overflow:hidden;word-break:break-word;min-height:2.9em}
  .pj-last b{font-weight:600;color:var(--t3)}
  .pj-card .r2 .sp{flex:1}
  .pj-pinmk{display:inline-flex;color:var(--t2)} .pj-pinmk svg{width:12px;height:12px}
  .pj-chips{display:flex;gap:6px;flex-wrap:wrap}
  .pj-chip{height:30px;padding:0 12px;border-radius:16px;background:var(--btn);color:var(--t1);font-size:13px;font-weight:500;
    display:inline-flex;align-items:center;gap:6px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-chip:hover{background:var(--btn-hi)}
  .pj-chip em{font-style:normal;color:var(--t3);font-size:12px}
  .pj-tag{flex:none;font-size:12px;font-weight:600;color:var(--t3);border:1px solid var(--line);border-radius:6px;padding:0 6px;line-height:18px}
  .pj-tag.on{color:var(--green);border-color:currentColor}
  .pj-hint{margin-top:8px;font-size:12px;line-height:1.5;color:var(--t3);overflow-wrap:anywhere}
  .pj-hint code{font:12px ui-monospace,Menlo,Consolas,monospace;color:var(--t1);background:var(--bg);padding:1px 4px;border-radius:6px;user-select:all}
  .pj-dlg .seg{margin-top:12px}
  .pj-dlg .pj-lab{margin-top:16px}
  .pj-dlg .pj-search{width:100%}
  .pj-dl{display:flex;flex-direction:column;gap:2px;margin-top:6px;max-height:30vh;overflow-y:auto;overscroll-behavior:contain}
  .pj-dl button{display:flex;align-items:center;gap:8px;width:100%;min-height:40px;padding:0 12px;border-radius:8px;text-align:left;
    font-size:14px;color:var(--t1);transition:background .15s}
  .pj-dl button:hover{background:var(--btn)}
  .pj-dl button.on{background:var(--btn-hi)}
  .pj-dl .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-ck{flex:none;width:20px;height:20px;border-radius:50%;border:1.5px solid var(--t4);display:inline-flex;align-items:center;justify-content:center;color:transparent}
  .pj-ck svg{width:12px;height:12px}
  .pj-dl button.on .pj-ck{background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-ta2{width:100%;resize:vertical;background:var(--bg);border:1px solid var(--line);border-radius:8px;color:var(--t1);
    font:inherit;font-size:14.5px;line-height:1.45;padding:8px 12px;min-height:72px;max-height:40vh}
  .pj-ta2:focus{outline:none;border-color:var(--focus-line);box-shadow:0 0 0 1px var(--focus-line),0 0 0 4px var(--focus-glow)}
  .pj-mtabs{display:none;gap:6px;overflow-x:auto;margin:8px 0 0;padding-bottom:2px;scrollbar-width:none}
  .pj-mtabs::-webkit-scrollbar{display:none}
  .pj-mtabs button{flex:none;height:32px;padding:0 12px;border-radius:16px;background:var(--card);color:var(--t2);font-size:13px;
    font-weight:500;white-space:nowrap;max-width:60vw;overflow:hidden;text-overflow:ellipsis}
  .pj-mtabs button.on{background:var(--btn-hi);color:var(--t1);font-weight:600}
  .pj-mgrid{display:grid;gap:8px;margin-top:12px;grid-template-columns:repeat(2,minmax(0,1fr))}
  .pj-mgrid.n1{grid-template-columns:minmax(0,1fr)}
  @media(min-width:1100px){.pj-mgrid.n3,.pj-mgrid.n5,.pj-mgrid.n6{grid-template-columns:repeat(3,minmax(0,1fr))}}
  .pj-mp{min-width:0;display:flex;flex-direction:column;gap:6px}
  .pj-mhead{display:flex;align-items:center;gap:8px;min-width:0;padding:0 2px}
  .pj-mhead .t{font-size:14px;font-weight:600;flex:none;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-mhead .s{font-size:12px;color:var(--t3);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-mhead .sp{flex:1}
  .pj-mhead .pj-more{margin:0}
  .pj-mb [data-col="side"],.pj-mb .pj-seg,.pj-mb .pj-tip{display:none!important}
  .pj-mb .pj-msgs{height:calc(var(--vh,100dvh) - 400px);min-height:240px}
  .pj-mgrid.r2 .pj-mb .pj-msgs{height:calc((var(--vh,100dvh) - 470px) / 2);min-height:200px}
  .pj-all{display:flex;gap:8px;align-items:flex-end;margin-top:8px;padding:8px;border-radius:var(--r-card);background:var(--card)}
  .pj-all textarea{flex:1;min-width:0;resize:none;background:var(--bg);border:0;border-radius:8px;color:var(--t1);
    font:inherit;font-size:14.5px;line-height:1.45;padding:8px 12px;min-height:38px;max-height:120px}
  .pj-all .pj-btn{height:38px}
  .pj-all textarea:focus{outline:none;box-shadow:0 0 0 1px var(--focus-line),0 0 0 4px var(--focus-glow)}
  @media(max-width:759px){.pj-mtabs{display:flex}.pj-mgrid{grid-template-columns:minmax(0,1fr)}
    .pj-mp{display:none}.pj-mp.focus{display:flex}.pj-mb .pj-msgs,.pj-mgrid.r2 .pj-mb .pj-msgs{height:calc(var(--vh,100dvh) - 430px);min-height:240px}}
  .pj-agt{display:flex;align-items:center;gap:8px;padding:8px 8px 8px 12px;border-radius:8px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-agt .go{flex:1;min-width:0;display:flex;align-items:center;gap:8px;text-align:left}
  .pj-agt .tx{flex:1;min-width:0}
  .pj-agt .t{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-agt .s{font-size:12px;color:var(--t3);margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-agt .stp{flex:none;height:30px;padding:0 12px;border-radius:8px;font-size:12px;font-weight:600;color:var(--t1);background:var(--btn)}
  .pj-agt .stp:hover{background:var(--btn-hi)}
  /* html.pj2 = room for the list beside the chat but not for the results as well: two columns,
     the results stay behind the 대화 / 결과물 switch. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){html.pj2 .pj-cols{display:grid;grid-template-columns:minmax(240px,min(340px,40%)) minmax(0,1fr);gap:16px}
    html.pj2 .pj-rail{max-height:none}}
  /* The list beside the chat, in the app menu's own row shape: 새 세션, a search field, a filter,
     then one row per session under its project's name; sessions made outside this app are folded
     at the bottom. */
  .pj-rail>.pj-btn.full{margin:2px 0 8px}
  :root{--ag-claude:#c9805a;--ag-codex:#5b9bd5}
  html[data-theme="light"]{--ag-claude:#b0643c;--ag-codex:#3b7dbd}
  .pj-ag.cl,.pj-agw.cl{color:var(--ag-claude)} .pj-ag.cx,.pj-agw.cx{color:var(--ag-codex)}
  .pj-ag.cl{border-color:color-mix(in srgb,var(--ag-claude) 40%,transparent)} .pj-ag.cx{border-color:color-mix(in srgb,var(--ag-codex) 40%,transparent)}
  .pj-lhd{display:flex;flex-wrap:wrap;justify-content:flex-end;align-items:center;gap:8px;margin:2px 0 12px 8px;container-type:inline-size}
  .pj-lhd b{flex:1;min-width:0;font-size:19px;font-weight:700;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  /* 보기: one button for how the list looks (view, size, order). It says what it is. */
  .pj-tgs{display:inline-flex;flex:none;gap:8px}
  .pj-tg{flex:none;display:inline-flex;gap:2px;padding:2px;border-radius:999px;background:var(--btn)}
  .pj-tg button{display:grid;place-items:center;width:30px;height:28px;border-radius:999px;color:var(--t3);transition:background-color .14s ease,color .14s ease}
  .pj-tg button svg{width:15px;height:15px;fill:currentColor}
  .pj-tg button.on{background:var(--btn-hi);color:var(--t1)}
  .pj-tg button:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-tg button:not(.on):hover{color:var(--t1)}}
  @media(pointer:coarse){.pj-tg button{width:40px;height:36px}.pj-tg button svg{width:17px;height:17px}}
  @media(prefers-reduced-motion:reduce){.pj-tg button{transition:none}}
  .pj-vwb{position:relative;flex:none;display:inline-flex;align-items:center;gap:4px;height:34px;padding:0 8px 0 12px;border-radius:999px;color:var(--t2);font-size:13px;font-weight:600;white-space:nowrap;
    box-shadow:inset 0 0 0 1px var(--line);transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  .pj-vwb svg{flex:none;width:15px;height:15px}
  .pj-vwb .cv{width:11px;height:11px;color:var(--t3);transform:rotate(90deg);transition:transform .2s var(--ease)}
  .pj-vwb[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-vwb[aria-expanded="true"] .cv{transform:rotate(-90deg)}
  .pj-vwb:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(hover:hover){.pj-vwb:hover{background:var(--card-hi);color:var(--t1)}}
  /* The menu under it: how the list looks on two small segmented rows, then what it can do to
     the order as plain menu rows. The same surface, row height and hairline as every other menu. */
  .pj-pop.vm{width:236px}
  .pj-vm{display:flex;flex-direction:column;gap:6px;padding:4px}
  .pj-dlg .pj-vm{gap:8px;padding:0}
  .pj-vm .vr{display:flex;align-items:center;gap:8px;min-height:30px}
  .pj-vm .vl{flex:none;width:34px;font-size:12px;font-weight:600;line-height:14px;letter-spacing:.02em;color:var(--t4)}
  .pj-vm .seg{flex:1 1 0;min-width:0;margin:0;padding:2px;gap:2px;border-radius:var(--r-md,10px)}
  body .pj-vm .seg button{flex:1 1 0;width:auto;min-width:0;height:28px;padding:0 6px;display:flex;flex-direction:row;align-items:center;justify-content:center;gap:4px;
    text-align:center;font-size:12px;font-weight:600;line-height:16px;color:var(--t3);border-radius:var(--r-sm);white-space:nowrap}
  body .pj-vm .seg button.on{background:var(--btn-hi);color:var(--t1)}
  body .pj-vm .seg button:focus-visible,body .pj-vm .va:focus-visible,body .pj-vm .vrs:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  .pj-vm svg{flex:none;width:14px;height:14px;fill:currentColor}
  .pj-vm hr{border:0;border-top:1px solid var(--line);margin:2px 0}
  .pj-vm .vo{flex:1 1 0;min-width:0;display:flex;gap:4px}
  body .pj-vm .va{display:flex;align-items:center;flex:1 1 0;width:auto;min-width:0;height:30px;padding:0 6px;justify-content:center;gap:4px;font-size:12px;font-weight:600;line-height:16px;color:var(--t2);
    border-radius:var(--r-md,10px);box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap}
  .pj-vm .va svg{color:var(--t3)}
  body .pj-vm .vrs{flex:none;width:auto;align-self:flex-end;white-space:nowrap;height:24px;min-height:0;padding:0 6px;margin:-2px 0 0;font-size:11.5px;font-weight:500;color:var(--t3);border-radius:var(--r-sm)}
  body .pj-vm .vrs:disabled{color:var(--t4);opacity:.6}
  @media(hover:hover){body .pj-vm .seg button:not(.on):hover{background:none;color:var(--t1)}body .pj-vm .va:hover{color:var(--t1);background:var(--card-hi)}body .pj-vm .vrs:not(:disabled):hover{color:var(--t1);background:none;text-decoration:underline}}
  @media(pointer:coarse){body .pj-vm .seg button{height:40px;font-size:14px}.pj-vm .vl{width:40px;font-size:12px}body .pj-vm .va{height:42px;font-size:14px}body .pj-vm .vrs{height:36px;font-size:13px}.pj-vm svg{width:16px;height:16px}}
  @media(pointer:coarse){body .pj-vm .seg button{min-height:44px;font-size:14px}}
  /* 새 세션 and its caret are one pill: the pill owns the colour and the shape, so no seam shows
     between the halves at any zoom; the caret half is a full 34px with a soft rule before it. */
  .pj-newg{display:inline-flex;flex:none;border-radius:999px;background:#dcdcdc;color:#141414;transition:transform .18s var(--ease)}
  html[data-theme="light"] .pj-newg{background:#111114;color:#fff}
  .pj-newg:active{transform:scale(.97)}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn{height:34px;background:none;color:inherit;transform:none;transition:background-color .14s ease}
  :is(.pj-lhd,.pj-rail) .pj-newb{padding:0 8px 0 12px;border-radius:999px 0 0 999px;font-size:13px;font-weight:600;gap:6px;white-space:nowrap}
  :is(.pj-lhd,.pj-rail) .pj-newb svg{width:14px;height:14px;flex:none}
  :is(.pj-lhd,.pj-rail) .pj-newc{position:relative;width:34px;padding:0 2px 0 0;border-radius:0 999px 999px 0;justify-content:center}
  :is(.pj-lhd,.pj-rail) .pj-newc::before{content:"";position:absolute;left:0;top:10px;bottom:10px;width:1px;background:currentColor;opacity:.2}
  :is(.pj-lhd,.pj-rail) .pj-newc svg{width:12px;height:12px;flex:none;transform:rotate(90deg);transition:transform .2s var(--ease)}
  :is(.pj-lhd,.pj-rail) .pj-newc[aria-expanded="true"] svg{transform:rotate(-90deg)}
  @media(hover:hover){html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:hover{background:rgba(255,255,255,.42)}html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:hover{background:rgba(255,255,255,.14)}}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:active,html :is(.pj-lhd,.pj-rail) .pj-newg .pj-newc[aria-expanded="true"]{background:rgba(0,0,0,.1)}
  html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:active,html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-newc[aria-expanded="true"]{background:rgba(255,255,255,.22)}
  /* The keyboard's ring goes round the whole pill and the half it is on is tinted like a hover: a ring
     round one half alone (a 999px corner on one side only) was drawn in pieces. */
  .pj-newg:has(.pj-btn:focus-visible){outline:2px solid var(--focus-line);outline-offset:2px}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:focus-visible{outline:none;background:rgba(255,255,255,.42)}
  html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:focus-visible{background:rgba(255,255,255,.14)}
  @container (max-width:300px){.pj-vwb>span{display:none}}
  @container (max-width:165px){.pj-lhd .pj-newb span{display:none}.pj-lhd .pj-newb{padding:0 8px 0 12px}}
  @media(pointer:coarse){
    html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn{height:40px}
    :is(.pj-lhd,.pj-rail) .pj-newb{padding:0 12px 0 16px;font-size:15px}
    :is(.pj-lhd,.pj-rail) .pj-newc{width:44px}
    :is(.pj-lhd,.pj-rail) .pj-newc::before{top:12px;bottom:12px}
    .pj-vwb{height:40px;padding:0 12px 0 12px;font-size:15px}
    .pj-vwb::after,:is(.pj-lhd,.pj-rail) .pj-newg .pj-btn::after{content:"";position:absolute;inset:-2px 0}
    :is(.pj-lhd,.pj-rail) .pj-newb{position:relative}
  }
  @media(prefers-reduced-motion:reduce){.pj-newg,.pj-vwb,.pj-vwb .cv,:is(.pj-lhd,.pj-rail) .pj-newc svg{transition:none}.pj-newg:active{transform:none}}
  .pj-srow .sr-1 .pj-pinmk{flex:none;align-self:center;margin:0 -2px 0 -4px;color:var(--t3)}
  .pj-srows.sm .sr-1 .pj-pinmk{margin:0}
  /* The project's face before a title: identity, where the orb is state. Text-sized and flat. */
  .pj-face{flex:none;display:inline-grid;place-items:center;width:16px;height:16px;font-size:13px;line-height:1;color:var(--t2)}
  .pj-face .phi{display:block;width:16px;height:16px}
  .pj-face.hv .phi{width:15px;height:15px}
  .pj-face.ph.tint{color:color-mix(in srgb,var(--em-c) 70%,var(--t1))}
  .pj-srow .sr-1 .pj-face{align-self:center;margin-right:-2px}
  .pj-srows.sm .sr-1 .pj-face{margin-right:-2px}
  .pj-srow.mut .pj-face,.pj-olds .pj-srow .pj-face{opacity:.7}
  .pj-nth .t .pj-face{width:18px;height:18px;font-size:15px;margin-right:8px;vertical-align:-3px}
  .pj-nth .t .pj-face .phi{width:18px;height:18px} .pj-nth .t .pj-face.hv .phi{width:17px;height:17px}
  .pj-nth .t .pj-pinmk{margin-right:6px;vertical-align:-1px}
  .pj-fx .tin{margin-top:6px}
  .pj-fx .lbl{margin-top:16px}
  .pj-fx .seg.wide{margin:6px 0 0}
  .pj-fx [data-pv]{margin-top:0}
  .pj-fx [data-pv]:not(:empty){margin-top:8px}
  .pj-fx .btn.xl{width:100%;margin-top:16px}
  .pj-fx .fx-nm{display:grid;grid-template-columns:48px minmax(0,1fr);gap:8px;margin-top:6px}
  .pj-fx .fx-nm .tin{margin-top:0}
  .fx-ico{position:relative;width:48px;height:48px;border:0;border-radius:var(--r-md);background:var(--card-hi);box-shadow:inset 0 0 0 1px var(--line);display:grid;place-items:center;cursor:pointer;padding:0}
  .fx-pen{position:absolute;right:-4px;bottom:-4px;width:18px;height:18px;border-radius:50%;background:var(--card);box-shadow:0 0 0 1px var(--line);display:grid;place-items:center;color:var(--t2,var(--t3))}
  .fx-pen svg{width:10px;height:10px;fill:currentColor}
  .fx-loc .btn.sm,.pj-ov .btn.sm:not(.fill),.ip-c.auto{background:color-mix(in srgb,var(--t1) 9%,transparent);box-shadow:inset 0 0 0 1px var(--line)}
  @media (hover:hover){.fx-loc .btn.sm:hover,.pj-ov .btn.sm:not(.fill):not(:disabled):hover{background:color-mix(in srgb,var(--t1) 15%,transparent)}}
  .fx-ico .pj-em{width:34px;height:34px;font-size:22px;border-radius:8px}
  @media (hover:hover){.fx-ico:hover{background:var(--btn-hi)}}
  .fx-ico:focus-visible,.fx-reset:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
  .pj-em.tint,.pj-head .em.tint{background:color-mix(in srgb,var(--em-c) 26%,transparent);border-radius:8px}
  .pj-head .em.tint{border-radius:11px;font-size:24px}
  .pj-sgl .pj-em.tint{width:22px;height:22px;font-size:14px;border-radius:6px}
  .fx-loc{display:flex;align-items:center;gap:8px;margin-top:6px;padding:8px 12px 8px 16px;border-radius:var(--r-md);background:var(--card-hi);min-width:0}
  .fx-path{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
  .fx-par{display:flex;min-width:0;font-size:12px;line-height:1.4;color:var(--t2,var(--t3))}
  .fx-par .h{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-par .t{flex:0 0 auto;max-width:62%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-new{display:flex;align-items:center;gap:6px;min-width:0;font-size:15px;line-height:1.35;color:var(--t1)}
  .fx-new svg{flex:none;width:16px;height:16px;fill:currentColor;color:var(--t3)}
  .fx-new b{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-new b.none{font-weight:400;color:var(--t3);font-size:13px}
  .fx-loc .btn.sm{flex:none;gap:4px} .fx-loc .btn.sm svg,.pj-ov .btn.sm svg{width:15px;height:15px;fill:currentColor}
  .fx-loc.ed{padding:0;background:none;gap:8px;align-items:stretch}
  .fx-loc.ed .tin{flex:1;min-width:0;margin-top:0;font-size:14px}
  .fx-loc.ed .btn.sm{height:auto;min-height:40px;padding:0 12px}
  .fx-res{margin-top:8px;padding:0 2px}
  .pj-mkbox{margin-top:8px;padding:12px;border-radius:var(--r-md);background:var(--card);border:1px solid var(--line)}
  .pj-mkbox[hidden]{display:none}
  .pj-mkbox .lbl{font-size:13px;color:var(--t3);font-weight:600;margin:8px 0 6px} .pj-mkbox .lbl:first-child{margin-top:0}
  .pj-mkbox .tin{width:100%;box-sizing:border-box;height:40px;border:0;outline:none;background:var(--card-hi);border-radius:var(--r-md);padding:0 12px;font:inherit;font-size:14px;color:var(--t1)}
  .pj-mkbox .tin:focus-visible,.fx-loc.ed .tin:focus-visible{box-shadow:0 0 0 2px var(--blue)}
  .pj-mkbtn{flex:none;gap:4px} .pj-mkbtn svg{width:15px;height:15px;fill:currentColor}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-mkbox .tin,.fx-loc.ed .tin{font-size:16px;height:44px}}
  .pj-fx .fx-note{margin-top:8px;line-height:1.5}
  .fx-reset{border:0;background:none;padding:0;margin-left:4px;font:inherit;color:var(--blue-t,var(--blue));cursor:pointer;border-radius:4px;position:relative}
  .fx-reset::before{content:"";position:absolute;inset:-10px -6px}
  .pj-fx [hidden]{display:none}
  /* Each agent carries its own colour here as in the lists, so the pick reads at a glance. */
  .pj-fx .agdot{opacity:.55;transition:opacity .16s var(--ease)}
  .pj-fx .on .agdot{opacity:1}
  /* A short window: the sheet tightens rather than scrolls. */
  @media (max-height:940px){
    .pj-fx .lbl{margin-top:8px} .pj-fx .tin,.pj-fx .fx-nm,.pj-fx .seg.wide{margin-top:4px}
    .pj-fx .tin{padding-top:8px;padding-bottom:8px} .pj-fx .fx-ico{height:auto}
    .pj-fx .fx-note{margin-top:4px;line-height:1.35} .pj-fx .btn.xl{margin-top:8px;min-height:44px;padding-top:8px;padding-bottom:8px}
    .pj-fx [data-pv]:not(:empty){margin-top:6px} .pj-fx > .hint:first-of-type{margin-bottom:0}
  }
  .pj-ov{position:fixed;z-index:400;box-sizing:border-box;width:min(380px,calc(100vw - 16px));max-height:min(520px,calc(100dvh - 16px));display:flex;flex-direction:column;gap:8px;padding:12px;
    background:var(--menu-bg,var(--card));border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--menu-shadow,0 12px 40px rgba(0,0,0,.35));color:var(--t1);font-size:14px}
  .pj-ov .sp{flex:1}
  .pj-ov button{font:inherit;color:inherit;cursor:pointer}
  .pj-ov button:focus-visible,.pj-ov input:focus-visible{outline:2px solid var(--blue);outline-offset:1px}
  .pj-ov .btn:disabled{opacity:.4;cursor:default}
  .pj-ov .fp-none{margin:0;padding:16px 8px;color:var(--t3);font-size:13px;text-align:center}
  /* The folder chooser: places down the left, the address bar and the folders beside them, one
     row of actions underneath. Hairlines and the app's small radii; nothing is a pill. */
  .pj-fp{width:min(540px,calc(100vw - 16px));height:min(396px,calc(100dvh - 16px));max-height:none;display:grid;grid-template-columns:148px minmax(0,1fr);grid-template-rows:minmax(0,1fr) auto;gap:0;padding:0;overflow:hidden;font-size:13px}
  .pj-fp:focus{outline:none}
  .fp-side{display:flex;flex-direction:column;gap:6px;min-width:0;min-height:0;padding:12px 8px;border-right:1px solid var(--line);overflow-y:auto;scrollbar-width:none}
  .fp-side::-webkit-scrollbar,.fp-pl::-webkit-scrollbar,.fp-cr::-webkit-scrollbar{display:none}
  .fp-sh{padding:0 8px;font-size:11.5px;font-weight:500;letter-spacing:.01em;color:var(--t4)}
  .fp-pl{display:flex;flex-direction:column;gap:1px;min-width:0}
  .fp-pc{display:flex;align-items:center;gap:8px;min-width:0;height:28px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;font-size:13px;font-weight:400;color:var(--t2,var(--t3));text-align:left}
  .fp-pc svg{flex:none;width:14px;height:14px;fill:currentColor;color:var(--t4)}
  .fp-pc span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fp-pc.on{background:var(--btn-hi);color:var(--t1);font-weight:500} .fp-pc.on svg{color:var(--t2,var(--t3))}
  .fp-pc[data-p="pc"]{margin-top:8px;position:relative;overflow:visible}
  .fp-pc[data-p="pc"]::before{content:"";position:absolute;left:8px;right:8px;top:-5px;height:1px;background:var(--line)}
  .fp-main{display:flex;flex-direction:column;gap:6px;min-width:0;min-height:0;padding:12px 12px 8px}
  .fp-bar{display:flex;align-items:center;gap:4px;min-width:0}
  .fp-up,.fp-ed{flex:none;width:28px;height:28px;border:0;border-radius:var(--r-xs);background:none;display:grid;place-items:center;padding:0;color:var(--t3)}
  .fp-up svg{width:14px;height:14px;fill:currentColor} .fp-up:disabled{opacity:.3;cursor:default}
  .fp-ad{flex:1;min-width:0;height:30px;display:flex;align-items:center;border-radius:var(--r-sm);box-shadow:inset 0 0 0 1px var(--line);cursor:text;transition:box-shadow .15s ease,background-color .15s ease}
  .fp-ad.ed{background:var(--card-hi);box-shadow:inset 0 0 0 1.5px var(--blue)}
  .fp-ad.busy{opacity:.6}
  .fp-cr{flex:1;min-width:0;height:100%;display:flex;align-items:center;margin-right:16px;padding:0 2px 0 4px;overflow-x:auto;scrollbar-width:none;white-space:nowrap}
  .fp-cr.cut{-webkit-mask-image:linear-gradient(90deg,transparent,#000 22px);mask-image:linear-gradient(90deg,transparent,#000 22px)}
  .fp-cr button{flex:none;border:0;background:none;height:24px;padding:0 4px;border-radius:6px;font-size:13px;color:var(--t3);max-width:150px;overflow:hidden;text-overflow:ellipsis}
  .fp-cr button[aria-current]{color:var(--t1);font-weight:500}
  .fp-cr i{flex:none;display:grid;place-items:center;color:var(--t4)} .fp-cr i svg{width:9px;height:9px;fill:currentColor}
  .fp-ed{width:26px;height:26px;margin-right:2px;color:var(--t4)} .fp-ed svg{width:13px;height:13px;fill:currentColor}
  .fp-ad.ed .fp-cr,.fp-ad.ed .fp-ed{display:none}
  .fp-ad-in{flex:1;min-width:0;height:100%;border:0;background:none;padding:0 8px;font:inherit;font-size:13px;color:var(--t1);outline:none}
  .pj-ov .fp-ad-in:focus-visible{outline:none}
  .fp-ad-in[hidden]{display:none}
  .fp-ad-in::placeholder{color:var(--t4)}
  .fp-er{margin:0 2px 0 34px;font-size:12px;line-height:1.45;color:var(--red-t,#ff6b77);overflow-wrap:anywhere}
  .fp-er[hidden]{display:none}
  .fp-ls{flex:1 1 0;min-height:0;overflow-y:auto;margin:0 -4px;padding:0 4px;overscroll-behavior:contain}
  .fp-row{display:flex;align-items:center;gap:8px;width:100%;height:30px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;text-align:left;font-size:13px;color:var(--t1)}
  .fp-row span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fp-row svg{flex:none;width:15px;height:15px;fill:currentColor;color:var(--t3)} .fp-row svg:last-child{width:10px;height:10px;color:var(--t4);opacity:0}
  @media (hover:hover){.fp-row:hover,.fp-pc:not(.on):hover,.fp-cr button:hover,.fp-up:not(:disabled):hover,.fp-ed:hover,.fp-txt:not(:disabled):hover{background:color-mix(in srgb,var(--t1) 7%,transparent)}
    .fp-row:hover svg:last-child{opacity:1}.fp-ed:hover,.fp-up:not(:disabled):hover,.fp-txt:not(:disabled):hover{color:var(--t1)}}
  .pj-fp .fp-row:focus-visible{outline:none;background:var(--btn-hi);box-shadow:inset 0 0 0 1px var(--line)} .fp-row:focus-visible svg:last-child{opacity:1}
  .pj-fp .fp-none{padding:34px 12px 0;color:var(--t4);font-size:12px;line-height:1.5} .pj-fp .fp-none.more{padding:8px 12px 6px}
  .fp-new{display:flex;align-items:center;gap:8px;padding:0 0 4px 8px}
  .fp-new svg{flex:none;width:15px;height:15px;fill:currentColor;color:var(--t3)}
  .fp-new input{flex:1;min-width:0;height:30px;border:0;border-radius:var(--r-xs);background:var(--card-hi);padding:0 8px;font:inherit;font-size:13px;color:var(--t1);outline:none}
  .pj-fp .fp-new input:focus-visible{outline:none;box-shadow:inset 0 0 0 1.5px var(--blue)}
  .fp-new .btn.sm{height:30px;padding:0 12px;font-size:13px;font-weight:500}
  .fp-ft{grid-column:1/-1;display:flex;flex-wrap:wrap;align-items:center;gap:8px 4px;min-width:0;padding:8px 12px 8px 8px;border-top:1px solid var(--line)}
  .fp-say{flex:1 1 100%;margin:0 0 0 8px;font-size:12px;line-height:1.45;color:var(--t3);overflow-wrap:anywhere}
  .fp-txt{display:inline-flex;align-items:center;gap:6px;height:30px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;font-size:13px;font-weight:500;color:var(--t2,var(--t3));white-space:nowrap}
  .fp-txt svg{flex:none;width:13px;height:13px;fill:currentColor;color:var(--t3)} .fp-txt:disabled{opacity:.4;cursor:default}
  .fp-ft .btn.sm.fill{height:30px;padding:0 12px;font-size:13px;font-weight:600}
  @media (prefers-reduced-motion:reduce){.fp-ad{transition:none}}
  /* A narrow window: the places lie along the top in one quiet row. */
  @media (max-width:556px){
    .pj-fp{grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto}
    .fp-side{flex-direction:row;padding:8px 8px 8px;border-right:0;border-bottom:1px solid var(--line);overflow:visible}
    .fp-sh{display:none} .fp-pl{flex-direction:row;gap:2px;overflow-x:auto;scrollbar-width:none}
    .fp-pc{flex:none;max-width:150px} .fp-pc[data-p="pc"]{margin:0 0 0 8px} .fp-pc[data-p="pc"]::before{left:-5px;right:auto;top:6px;width:1px;height:16px}
    .fp-main{padding-top:8px} .pj-fp{height:min(476px,calc(100dvh - 16px))}
  }
  .pj-ip{width:min(344px,calc(100vw - 16px))}
  .ip-top{display:flex;align-items:center;gap:6px;min-height:32px}
  .ip-top .btn.sm{gap:4px}
  .ip-h{font-size:13px;font-weight:600;color:var(--t3)}
  .ip-sug,.ip-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:2px}
  .ip-grid{flex:1 1 auto;min-height:120px;max-height:192px;overflow-y:auto;border-radius:var(--r-md);background:var(--bg);padding:4px;align-content:start;overscroll-behavior:contain}
  .ip-grid .fp-none{grid-column:1/-1}
  .ip-sug button,.ip-grid button{aspect-ratio:1;border:0;border-radius:8px;background:none;padding:0;font-size:20px;line-height:1;display:grid;place-items:center;overflow:hidden}
  .ip-sug button.on,.ip-grid button.on{background:var(--blue-w,var(--btn-hi));box-shadow:inset 0 0 0 2px var(--blue-t,var(--blue))}
  @media (hover:hover){.ip-sug button:hover,.ip-grid button:hover{background:var(--btn-hi)}}
  .ip-seg{display:flex;gap:2px;padding:2px;border-radius:var(--r-sm);box-shadow:inset 0 0 0 1px var(--line)}
  .ip-seg button{flex:1 1 0;min-width:0;height:26px;border:0;border-radius:calc(var(--r-sm) - 2px);background:none;padding:0 2px;font-size:12px;font-weight:550;letter-spacing:-.01em;color:var(--t3);white-space:nowrap}
  .ip-seg button.on{background:color-mix(in srgb,var(--t1) 11%,transparent);color:var(--t1)}
  @media (hover:hover){.ip-seg button:not(.on):hover{color:var(--t1)}}
  .ip-seg button:focus-visible,.ip-sug button:focus-visible,.ip-grid button:focus-visible{outline:2px solid var(--blue);outline-offset:-2px}
  .pj-em .phi,.pj-head .em .phi,.pj-ip .phi{display:block}
  .ip-sug button[data-i],.ip-grid button[data-i]{color:var(--t1)}
  .ip-grid button[data-i]{content-visibility:auto;contain-intrinsic-size:auto 38px}
  .pj-em.ph.tint,.pj-head .em.ph.tint{color:color-mix(in srgb,var(--em-c) 72%,var(--t1))}
  .ip-q{height:34px;border:0;border-radius:var(--r-sm);background:var(--card-hi);padding:0 12px;font:inherit;font-size:14px;color:var(--t1);outline:none;width:100%;box-sizing:border-box}
  .ip-cols{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  .ip-c{width:26px;height:26px;border:0;border-radius:50%;padding:0;background:var(--em-c);position:relative}
  .ip-c::before{content:"";position:absolute;inset:-4px}
  .ip-c.on{box-shadow:0 0 0 2px var(--menu-bg,var(--card)),0 0 0 4px var(--em-c)}
  .ip-c.auto{width:auto;height:28px;padding:0 12px;border-radius:99px;font-size:13px;font-weight:550}
  .ip-c.auto.on{box-shadow:inset 0 0 0 1.5px var(--blue-t,var(--blue));background:var(--blue-w,var(--btn-hi));color:var(--blue-t,var(--t1))}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    .ip-sug,.ip-grid{grid-template-columns:repeat(auto-fill,minmax(44px,1fr))}
    .ip-sug button,.ip-grid button{min-height:44px;font-size:22px}
    .ip-c{width:32px;height:32px} .ip-c::before{inset:-6px} .ip-c.auto{height:36px} .ip-cols{gap:12px}
    .fp-row{height:44px;font-size:15px} .fp-pc{height:36px;font-size:14px} .fp-up{width:40px;height:40px} .fp-ed{width:36px;height:36px} .fp-ad{height:40px} .fp-cr button{height:34px;font-size:14px}
    .pj-ov .btn.sm,.fp-txt,.fp-ft .btn.sm.fill,.fp-new .btn.sm{height:40px} .fp-txt,.fp-ft .btn.sm.fill{font-size:14px} .fp-new input,.fp-ad-in{height:40px;font-size:16px} .ip-q{height:44px;font-size:16px} .ip-seg button{height:36px;font-size:14px}
    .fp-er{margin-left:46px}
  }
  .pj-sq{display:block;width:100%;height:40px;font-size:15px;border-radius:var(--r-lg)}
  .pj-sfil{margin:8px 0 0}
  /* Claude | Codex under the tabs: two small chips, each with its tool's mark and how many it would show. */
  .pj-agf{display:flex;gap:6px;margin:6px 0 0}
  .pj-agf button{flex:0 1 auto;min-width:0;display:inline-flex;align-items:center;gap:4px;height:26px;padding:0 8px 0 8px;border-radius:999px;font-size:12px;font-weight:600;line-height:1;color:var(--t3);
    background:none;box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap;transition:background-color .14s ease,color .14s ease,box-shadow .14s ease}
  .pj-agf button .agdot{margin:0}
  .pj-agf button .num{font-size:12px;font-weight:500;font-variant-numeric:tabular-nums;color:var(--t4)}
  .pj-agf button.on{color:var(--t1);background:color-mix(in srgb,var(--ag-claude) 14%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--ag-claude) 46%,transparent)}
  .pj-agf button.cx.on{background:color-mix(in srgb,var(--ag-codex) 15%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--ag-codex) 46%,transparent)}
  .pj-agf button.on .num{color:var(--t2)}
  .pj-agf button:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(hover:hover){.pj-agf button:not(.on):hover{color:var(--t1);background:var(--card-hi)}}
  @media(pointer:coarse){.pj-agf{gap:8px;margin-top:8px}.pj-agf button{height:34px;padding:0 12px 0 12px;font-size:14px}.pj-agf button .dot{width:8px;height:8px}}
  .pj-none{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:center;gap:4px 8px}
  .pj-fclr{height:28px;padding:0 12px;border-radius:999px;font-size:12px;font-weight:600;color:var(--t1);background:var(--btn)}
  .pj-fclr:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(hover:hover){.pj-fclr:hover{background:var(--btn-hi)}}
  @media(pointer:coarse){.pj-fclr{height:36px;padding:0 16px;font-size:14px}}
  .pj-srows{margin-top:8px}
  .pj-sfil{container-type:inline-size}
  .pj-sfil button{min-width:0;padding:0 4px;white-space:nowrap}
  @container (max-width:230px){.pj-sfil button{font-size:12px;letter-spacing:-.02em}}
  /* One row shape for both views: the project's icon (or its indent), the title, a quiet line
     under it, when. Titles start on one axis (42px) whichever view is on. */
  .pj-srow{position:relative;display:flex;align-items:center;gap:8px;width:100%;height:56px;padding:0 12px 0 8px;margin-top:2px;border-radius:var(--r-lg);
    text-align:left;color:var(--t1);cursor:pointer;-webkit-tap-highlight-color:transparent;transition:background-color .14s ease,transform .18s var(--ease)}
  .pj-srow.inert{cursor:default}
  @media(hover:hover){.pj-srow:hover{background:var(--card-hi)}}
  .pj-srow.on{background:color-mix(in srgb,var(--t1) 10%,transparent)}
  /* On a phone the bar above already says 대화. */
  @media(max-width:699px){.pj-lhd{margin-left:0}.pj-lhd b{display:none}.pj-lhd .pj-vwb{margin-right:auto}}
  .pj-lhd.ph{margin-bottom:8px}
  /* A phone: 새 세션 waits in the thumb's corner, over the list and above the tab bar. */
  .pj-newg.pj-fab{position:fixed;z-index:8;right:calc(16px + env(safe-area-inset-right));bottom:calc(78px + env(safe-area-inset-bottom));box-shadow:0 6px 20px rgba(0,0,0,.34),0 0 0 1px rgba(0,0,0,.06)}
  html .pj-rail .pj-newg.pj-fab .pj-btn{height:48px}
  .pj-rail .pj-fab .pj-newb{padding:0 12px 0 16px;font-size:16px}
  .pj-rail .pj-fab .pj-newb svg{width:16px;height:16px}
  .pj-rail .pj-fab .pj-newc::before{top:14px;bottom:14px}
  .pj-rail:has(.pj-fab){padding-bottom:72px}
  body.pjchat .pj-fab,body.typing .pj-fab{display:none}
  .pj-lhd.ph .pj-sq{flex:1;min-width:0;width:auto;margin:0}
  .pj-srow:focus-visible,.pj-sgh:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  .pj-srow .sr-e{flex:none;width:24px;height:24px;display:grid;place-items:center}
  .pj-srow .sr-e .pj-em{font-size:16px}
  /* The cell before a row says where the session was opened: Claude Code in its orange with a
     spark, Codex in its blue with code brackets (the two colours 사용량 already draws them in).
     Shape and colour both, so neither is needed alone. */
  .pj-srow .sr-e.ag{border-radius:8px;color:var(--ag-claude);background:color-mix(in srgb,var(--ag-claude) 15%,transparent)}
  .pj-srow .sr-e.ag.cx{color:var(--ag-codex);background:color-mix(in srgb,var(--ag-codex) 16%,transparent)}
  .pj-srow .sr-e.ag svg{width:14px;height:14px}
  .pj-srow .sr-x{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .pj-srow .sr-1{display:flex;align-items:baseline;gap:8px;min-width:0}
  .pj-srow .sr-2{display:flex;align-items:center;gap:6px;min-width:0;height:18px;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-srow .sr-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14.5px;font-weight:600;line-height:20px;letter-spacing:-.005em}
  .pj-srow .sr-s{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-srow .sr-w{flex:none;min-width:28px;text-align:right;font-size:12px;line-height:20px;color:var(--t3);font-variant-numeric:tabular-nums;transition:opacity .12s ease}
  .pj-srow .sr-i{flex:none;display:inline-flex;align-items:center;height:18px}
  .pj-srow .sr-i i{width:7px;height:7px;border-radius:50%;background:var(--green)}
  .pj-srow .sr-dup{flex:none;position:relative;font-size:11px;font-weight:600;line-height:18px;padding:0 6px;border:0;border-radius:6px;background:var(--btn);color:var(--t2);font-variant-numeric:tabular-nums;cursor:pointer}
  .pj-srow.tw{margin-left:16px;width:calc(100% - 16px)}
  .pj-srow .sr-dup::before{content:"";position:absolute;inset:-10px -8px}
  .pj-srow .sr-dup:hover,.pj-srow .sr-dup[aria-expanded="true"]{color:var(--t1)}
  .pj-srow .sr-ask{flex:none;font-size:12px;font-weight:600;line-height:18px;padding:0 6px;border-radius:6px;color:var(--orange);
    background:color-mix(in srgb,var(--orange) 14%,transparent)}
  .pj-srow.mut .sr-t,.pj-olds .pj-srow .sr-t{color:var(--t2);font-weight:500}
  /* The row's menu: with a pointer it takes the place of the time while the row is pointed at or
     focused; on a touch screen it is always there, at the row's end. */
  .pj-srow .sr-m,.pj-sgl .sr-m{position:relative;flex:none;width:28px;height:28px;margin:0;z-index:1}
  .sr-m::after{content:"";position:absolute;inset:0}
  @media(hover:hover) and (pointer:fine){
    .pj-srow .sr-m{position:absolute;right:6px;top:6px;opacity:0;transition:opacity .12s ease,background-color .14s ease}
    .pj-sgl .sr-m{opacity:0;transition:opacity .12s ease,background-color .14s ease}
    .pj-srow .sr-m::after,.pj-sgl .sr-m::after{inset:-3px}
    .pj-srow:hover .sr-m,.pj-srow:focus-within .sr-m,.pj-sgl:hover .sr-m,.pj-sgl:focus-within .sr-m,.sr-m[aria-expanded="true"]{opacity:1}
    .pj-srow:hover .sr-m~.sr-x .sr-w,.pj-srow:focus-within .sr-m~.sr-x .sr-w{opacity:0}
  }
  @media not ((hover:hover) and (pointer:fine)){
    .pj-srow{height:60px;padding-right:4px}
    .pj-srow .sr-m,.pj-sgl .sr-m{width:44px;height:44px;color:var(--t4)}
    .pj-srow .sr-x{order:1}.pj-srow .sr-m{order:2}
  }
  /* 작게: one line a row. The title, how it is doing (the dot, 내 차례), when. */
  .pj-srows.sm .pj-srow{height:36px;margin-top:1px;border-radius:var(--r-md)}
  .pj-srows.sm .sr-x{flex-direction:row;align-items:center;gap:8px}
  .pj-srows.sm .sr-1{display:contents}
  .pj-srows.sm .sr-t{font-size:13px;font-weight:500}
  .pj-srows.sm .sr-2{order:1;flex:none;height:auto}
  .pj-srows.sm .sr-s{display:none}
  .pj-srows.sm .sr-w{order:2;line-height:18px}
  .pj-srows.sm .sr-e .pj-em{font-size:15px}
  .pj-srows.sm .pj-sgrp{margin-top:4px}
  .pj-srows.sm .pj-sdv{margin-top:8px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-srow .sr-m{top:4px}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-srow{height:44px}}
  /* 폴더별: the project's name once, its sessions under it on the title axis. */
  .pj-sgrp{margin-top:6px}
  .pj-sgrp:first-child,.pj-sdv:first-child{margin-top:0}
  .pj-sgl{display:flex;align-items:center;gap:2px;min-width:0;padding-right:6px}
  .pj-sgh{flex:1;min-width:0;display:flex;align-items:center;gap:8px;height:36px;padding:0 4px 0 8px;border-radius:var(--r-md);text-align:left;
    color:var(--t2);font-size:13px;font-weight:600;transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  @media(hover:hover){.pj-sgh:hover{color:var(--t1)}}
  .pj-sgh .pj-em{font-size:16px}
  .pj-sgh .nm{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-sgh .n{flex:none;margin-left:-4px;color:var(--t4);font-weight:500;font-variant-numeric:tabular-nums}
  .pj-sgh .cv{flex:none;width:12px;height:12px;color:var(--t4);transform:rotate(90deg);transition:transform .2s var(--ease)}
  .pj-sgh[aria-expanded="false"] .cv{transform:none}
  .pj-sgl .sr-m{order:2}
  /* 꺼진 부서: the departments with nothing up and no row in the list, behind one fold at its end
     (and found by the search). Each says the talk 켜기 brings back. No motion. */
  .pj-on{flex:none;height:26px;padding:0 12px;border-radius:999px;font-size:12px;font-weight:600;line-height:26px;white-space:nowrap;color:var(--t1);background:var(--btn);transition:background-color .14s ease}
  .pj-on:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-on[disabled],.pj-on[aria-disabled="true"]{color:var(--t3);cursor:default}
  .pj-card .pj-on{display:inline-block;color:var(--t1)}
  @media(hover:hover){.pj-on:not([disabled]):hover{background:var(--btn-hi)}}
  @media(pointer:coarse){.pj-on{height:40px;padding:0 16px;font-size:14px;line-height:40px}}
  /* What 켜기 offers: the talks a department had, then 새로 시작. A menu beside the button, the
     bottom sheet on a phone; the same lines are the second step of 찾아서 켜기. */
  .pj-onp button[aria-current="true"]{background:var(--btn)}
  body .pj-pop.pj-onp{width:auto;min-width:184px;max-width:min(300px,calc(100vw - 16px))}
  body .pj-pop.pj-onp button.two{white-space:normal;min-width:0} .pj-onp button.two span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
  .pj-onp small{font-size:12px;color:var(--t3)}
  #sheet .pj-onp{display:flex;flex-direction:column;gap:4px}
  #sheet .pj-onp .h{font-size:16px;font-weight:700;margin:0 44px 8px 4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #sheet .pj-onp button[data-i],#sheet .pj-onp button[data-a],#sheet .pj-fo button[data-fd]{display:flex;align-items:center;gap:8px;width:100%;min-width:0;min-height:52px;padding:8px 12px;border-radius:12px;text-align:left;font-size:16px;color:var(--t1)}
  #sheet .pj-onp button.two{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px}
  #sheet .pj-onp button svg{flex:none;width:18px;height:18px;fill:currentColor;color:var(--t3)}
  #sheet .pj-onp small{font-size:13px}
  #sheet .pj-onp hr{width:100%;border:0;border-top:1px solid var(--line);margin:4px 0}
  #sheet .pj-onp button:focus-visible,#sheet .pj-fo button:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){#sheet .pj-onp button[data-i]:hover,#sheet .pj-onp button[data-a]:hover,#sheet .pj-fo button[data-fd]:hover{background:var(--btn)}}
  /* 찾아서 켜기: one title, the search field, the departments. */
  .pj-fo{display:flex;flex-direction:column;gap:8px;min-width:0}
  /* 말로 만들기: a line, then the card it became, then what was made. One sheet, changed in place. */
  .pj-tm{display:flex;flex-direction:column;min-width:0}
  .pj-tm h3{margin-right:44px}
  .pj-tm .pj-ta2{margin-top:8px;min-height:68px;font-size:16px;resize:none}
  .pj-tm .hint{margin:2px 0 0}
  .pj-tmr{display:flex;align-items:center;gap:8px;margin-top:16px}
  .pj-tmr .sp{flex:1}
  .pj-tmr .pj-text{margin-left:-12px}
  .pj-tmr .pj-btn{min-width:76px;justify-content:center;gap:6px}
  .pj-tmr .pj-btn svg.lu{color:inherit}
  .pj-tm .lbl{margin-top:12px}
  .pj-tm .tin{margin-top:4px;width:100%}
  .pj-tm .tm-nm{display:grid;grid-template-columns:44px minmax(0,1fr);gap:8px;margin-top:4px}
  .pj-tm .tm-nm .tin{margin-top:0}
  .pj-tm .tm-em{display:grid;place-items:center;border-radius:8px;background:var(--btn);font-size:20px;line-height:1;cursor:pointer}
  .pj-tm .tm-em[aria-expanded="true"]{box-shadow:0 0 0 1.5px var(--focus-line)}
  .pj-tm .tm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(36px,1fr));gap:2px;max-height:156px;margin-top:8px;padding:4px;border-radius:8px;background:var(--btn);overflow-y:auto;overscroll-behavior:contain}
  .pj-tm .tm-grid[hidden]{display:none}
  .pj-tm .tm-grid button{height:36px;border-radius:6px;font-size:20px;line-height:1;display:grid;place-items:center}
  @media (hover:hover){.pj-tm .tm-grid button:hover,.pj-tm .tm-gs button:hover{background:var(--card-hi)}}
  .pj-tm .tm-gs{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
  .pj-tm .tm-gs:empty,.tm-gs:not(.on){display:none}
  .pj-tm .tm-gs button{height:28px;padding:0 10px;border-radius:14px;background:var(--btn);font-size:13px;color:var(--t2)}
  .pj-tm [data-par] .lbl{margin-top:8px}
  .pj-tm .tm-par{display:flex;align-items:center;gap:8px;margin-top:4px}
  .pj-tm .tm-par .tin{flex:1;min-width:0;margin-top:0}
  .pj-tm button.tm-at{width:100%;padding:4px 0;color:inherit;font:inherit;text-align:left;cursor:pointer}
  .pj-tm button.tm-at svg:last-child{margin-left:auto;opacity:.7}
  .pj-tm [data-pv]{min-height:20px;margin-top:8px;font-size:13px;line-height:1.5;color:var(--t3)}
  .pj-tm .tm-at{display:flex;align-items:center;gap:6px;min-width:0}
  .pj-tm .tm-at svg{flex:none;width:14px;height:14px;fill:currentColor}
  .pj-tm .tm-at span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
  .pj-tm .tm-done{display:flex;flex-direction:column;align-items:center;gap:4px;padding:16px 0 4px;text-align:center}
  .pj-tm .tm-done .e{font-size:40px;line-height:1.1}
  .pj-tm .tm-done b{max-width:100%;font-size:16px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-tm .tm-done span{font-size:14px;color:var(--t3)}
  .pj-fo h3{margin-right:44px}
  .pj-fo .rows{display:flex;flex-direction:column;gap:2px;max-height:min(52vh,420px);overflow-y:auto;margin:0 -4px;padding:0 4px}
  .pj-fo button[data-fd] .ox{flex:1;min-width:0;display:flex;flex-direction:column;line-height:1.35}
  .pj-fo button[data-fd] .nm{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-fo button[data-fd] .bk{font-size:13px;color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-fo button[data-fd] .oe{flex:none;width:24px;display:grid;place-items:center}
  .pj-fo .pj-fob{align-self:flex-start;display:inline-flex;align-items:center;gap:4px;height:40px;padding:0 12px 0 4px;margin:-6px 0 0 -4px;border-radius:8px;color:var(--t2);font-size:15px;font-weight:600}
  .pj-fo .pj-fob svg{width:18px;height:18px;fill:currentColor;transform:rotate(180deg)}
  @media(prefers-reduced-motion:reduce){.pj-on{transition:none}}
  /* 세션: 오늘 / 어제 / 이전, said once each. */
  .pj-sdv{margin-top:16px;padding:0 8px 4px;font-size:12px;font-weight:600;line-height:18px;color:var(--t3)}
  .pj-srows .pj-fold{padding:8px 12px 6px 42px}
  .pj-srows .pj-oldb,.pj-srows .pj-tidb{margin-top:8px;padding:12px 12px;border-top:1px solid var(--line);font-size:13px}
  .pj-srows .pj-oldb+.pj-tidb,.pj-srows .pj-tidb+.pj-oldb{margin-top:0;border-top:0;padding-top:0}
  .pj-apart .pj-sgl,.pj-olds .pj-sgl{padding:8px;color:var(--t3);font-weight:600;font-size:12px}
  .pj-srows>.pj-empty{padding:28px 12px;text-align:center}
  @media(prefers-reduced-motion:reduce){.pj-srow,.pj-sgh,.pj-sgh .cv{transition:none}}
  /* Each session is its own block: a surface with a hairline and a lit top edge, the state orb
     before the title, and the orb's light bleeding faintly into the block (one still gradient,
     nothing animates). Colour is kept for two states: a quiet amber for 내 차례 and a muted red
     for 막힘; the rest is the text ink. Ended and long-unused sessions recede to a hairline. */
  :root{--sr-work:#55d2ac;--sr-gw:85,210,172;--sr-ink:#efe9dc;--sr-turn:#e2b45c;--sr-stuck:#c46c6c;--sr-g:239,233,220;--sr-gt:226,180,92;--sr-gs:196,108,108;--sr-ga:1;
    --sr-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 9%,transparent),inset 0 1px 0 color-mix(in srgb,var(--t1) 6%,transparent);
    --sr-edge-on:inset 0 0 0 1px color-mix(in srgb,var(--t1) 24%,transparent);--sr-lift:0 1px 2px rgba(0,0,0,.4)}
  html[data-theme="light"]{--sr-work:#086b50;--sr-gw:16,150,112;--sr-ink:#3c4250;--sr-turn:#a36a10;--sr-stuck:#b4545c;--sr-g:60,66,80;--sr-gt:214,150,40;--sr-gs:200,90,98;--sr-ga:.75;
    --sr-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 11%,transparent);--sr-edge-on:inset 0 0 0 1px color-mix(in srgb,var(--t1) 34%,transparent);
    --sr-lift:0 1px 2px rgba(15,23,42,.07)}
  .pj-srows{--ts:36px}
  .pj-srows.sm{--ts:24px}
  .pj-srows .pj-srow{height:60px;gap:12px;padding:0 12px 0 12px;margin-top:6px;background:var(--card);box-shadow:var(--sr-edge),var(--sr-lift);
    overflow:hidden;isolation:isolate;--orb-ink:var(--sr-ink)}
  .pj-srows.sm .pj-srow{height:40px;gap:8px;padding:0 12px 0 8px;margin-top:4px}
  @media(hover:hover){.pj-srows .pj-srow:hover{background:var(--card-hi)}}
  .pj-srows .pj-srow.on{background:var(--btn);box-shadow:var(--sr-edge-on),var(--sr-lift)}
  .pj-srows .pj-srow.s-ended,.pj-srows .pj-srow.s-stale{background:none;box-shadow:inset 0 0 0 1px var(--line)}
  @media(hover:hover){.pj-srows .pj-srow.s-ended:hover,.pj-srows .pj-srow.s-stale:hover{background:var(--card)}}
  .pj-srows .pj-srow.s-ended.on,.pj-srows .pj-srow.s-stale.on{background:var(--btn);box-shadow:var(--sr-edge-on)}
  .pj-srows .pj-srow.s-turn{--orb-ink:var(--sr-turn);box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.26),var(--sr-lift)}
  .pj-srows .pj-srow.s-turn.on{box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.5),var(--sr-lift)}
  .pj-srows .pj-srow.s-stuck{--orb-ink:var(--sr-stuck)}
  /* 내 차례 is said by colour alone: the orb's tile and the line under the title. The row keeps its place. */
  .pj-srow .sr-ask{display:none}
  .pj-srow .sr-s{transition:color .2s ease}
  .pj-srows .pj-srow.s-turn .sr-s{color:var(--sr-turn)}
  @media(prefers-reduced-motion:reduce){.pj-srow .sr-s{transition:none}}
  .pj-srow::before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;
    background:radial-gradient(130px 80px at 28px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),calc(var(--a) * var(--sr-ga) * .35)) 45%,rgba(var(--g),0) 100%)}
  .pj-srows.sm .pj-srow::before{background:radial-gradient(90px 50px at 20px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),0) 100%)}
  .pj-srow.s-live{--g:var(--sr-g);--a:.085} .pj-srow.s-turn{--g:var(--sr-gt);--a:.2}
  .pj-srow.s-idle{--g:var(--sr-g);--a:.03} .pj-srow.s-stuck{--g:var(--sr-gs);--a:.15}
  .pj-srow.s-ended::before,.pj-srow.s-stale::before,.pj-srow.s-new::before{display:none}
  .pj-srow .sr-e{width:var(--ts);height:var(--ts)}
  .pj-srow .sr-o rl-orb{display:block}
  .pj-srow.s-idle .sr-o rl-orb{opacity:.62}
  .pj-srow.s-ended .sr-o rl-orb,.pj-srow.s-new .sr-o rl-orb{opacity:.42}
  .pj-srow .sr-o>i{width:5px;height:5px;border-radius:50%;background:var(--t4)}
  .pj-srows.sm .sr-o>i{width:4px;height:4px}
  /* The compact list's state mark for working / 내 차례 / stuck: a still dot in the state's colour, no motion. */
  .pj-srows.sm .sr-o>i.st-dot{width:8px;height:8px;background:var(--sr-work)}
  .pj-srows.sm .pj-srow.s-turn .sr-o>i.st-dot{background:var(--sr-turn)}
  .pj-srows.sm .pj-srow.s-stuck .sr-o>i.st-dot{background:var(--sr-stuck)}
  .pj-srows.sm .pj-srow.s-turn::after{display:none}
  /* The tool the session was opened in: a dot in its colour (and its name, in the two-line view). */
  .pj-srow .agd{margin:0 6px 0 1px}
  .pj-srow.mut .agd,.pj-srow.s-ended .agd,.pj-srow.s-stale .agd{opacity:.6}
  .pj-srow .sr-ad{display:none}
  .pj-srows.sm .sr-ad{display:inline-block;margin:0 1px}
  .pj-srows.sm .sr-ask{order:1}
  .pj-srows .pj-fold{padding-left:59px}
  .pj-srows.sm .pj-fold{padding-left:42px}
  @media(hover:hover) and (pointer:fine){.pj-srows .pj-srow .sr-m,.pj-srows.sm .pj-srow .sr-m{top:calc(50% - 14px)}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows .pj-srow{padding-right:4px}.pj-srows.sm .pj-srow{height:44px}}
  /* 작게: one line a row and no card, as a sidebar. The state is the small orb, the
     row's ground only says pointed-at or open; names line up under their group's name. */
  .pj-srows.sm{--ts:16px}
  .pj-srows.sm .pj-srow{height:32px;gap:8px;padding:0 8px;margin-top:2px;border-radius:8px}
  .pj-srows.sm .pj-srow,.pj-srows.sm .pj-srow.s-ended,.pj-srows.sm .pj-srow.s-stale,.pj-srows.sm .pj-srow.s-turn{background:none;box-shadow:none}
  @media(hover:hover){.pj-srows.sm .pj-srow:hover,.pj-srows.sm .pj-srow.s-ended:hover,.pj-srows.sm .pj-srow.s-stale:hover{background:color-mix(in srgb,var(--t1) 6%,transparent)}}
  .pj-srows.sm .pj-srow.on,.pj-srows.sm .pj-srow.s-ended.on,.pj-srows.sm .pj-srow.s-stale.on,.pj-srows.sm .pj-srow.s-turn.on{background:color-mix(in srgb,var(--t1) 11%,transparent);box-shadow:none}
  .pj-srows.sm .pj-srow::before{display:none}
  /* On screen in a split pane (.vis, set by splitMarks): the row's ground is lifted a little and a
     short tick stands at its left edge, in the colour of the focused pane's ring; both sit under
     whatever the row's state draws (the ring, the glow, the sweep). The focused pane's row is .on,
     as ever, and its tick is full. The tick is a ground layer: ::before and ::after are the state's. */
  .pj-srows .pj-srow.vis:not(.on){background-color:color-mix(in srgb,var(--btn) 75%,var(--card))}
  .pj-srows.sm .pj-srow.vis:not(.on){background-color:color-mix(in srgb,var(--t1) 7.5%,transparent)}
  @media(hover:hover){.pj-srows .pj-srow.vis:not(.on):hover{background-color:var(--btn)}
    .pj-srows.sm .pj-srow.vis:not(.on):hover{background-color:color-mix(in srgb,var(--t1) 9.5%,transparent)}}
  .pj-srow.vis{--vis-c:color-mix(in srgb,var(--blue) 72%,transparent)} .pj-srow.vis.on{--vis-c:var(--blue)}
  .pj-cols .pj-rail .pj-srows .pj-srow.vis{background-image:linear-gradient(var(--vis-c),var(--vis-c));background-repeat:no-repeat;background-size:3px 20px;background-position:5px 50%}
  .pj-cols .pj-rail .pj-srows .pj-srow.vis.on{background-size:3px 28px}
  .pj-cols .pj-rail .pj-srows.sm .pj-srow.vis{background-size:3px 14px;background-position:3px 50%}
  .pj-cols .pj-rail .pj-srows.sm .pj-srow.vis.on{background-size:3px 20px}
  /* Its row is folded away under the project's name: the name carries a small dot. */
  .pj-sgl.vis .pj-sgh .sp::before{content:"";display:block;width:6px;height:6px;margin:0 0 0 2px;border-radius:50%;background:color-mix(in srgb,var(--blue) 70%,transparent)}
  .pj-srows.sm .pj-srow .sr-x{flex-direction:row;align-items:center;gap:8px}
  .pj-srows.sm .pj-sgl~.pj-srow{padding-left:16px}
  .pj-srows.sm .sr-1{display:contents}
  .pj-srows.sm .sr-t{font-size:13px;font-weight:500;line-height:20px;letter-spacing:0}
  .pj-srows.sm .pj-srow.on .sr-t,.pj-srows.sm .pj-srow.s-turn .sr-t{font-weight:600}
  .pj-srows.sm .pj-srow.s-turn .sr-w{color:var(--sr-turn)}
  /* A reply not read yet: a dot in the row's own left padding, so nothing in the row moves for it. */
  .pj-srows .pj-srow.s-turn::after{content:"";position:absolute;left:3px;top:calc(50% - 3px);width:6px;height:6px;border-radius:50%;background:var(--blue);pointer-events:none}
  .pj-srows.sm .pj-srow.s-turn::after{left:1.5px;top:calc(50% - 2.5px);width:5px;height:5px}
  .pj-srows.sm .pj-sgl~.pj-srow.s-turn::after{left:6px}
  /* Picking several: each row's mark takes the dot's place and a picked row is tinted. The bar
     stands where the list's head was, as tall as it, and fades in where it is. */
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr])::after{content:none}
  /* The mark takes the state glyph's own slot (it is faded out), so nothing moves when picking starts. */
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e{position:relative}
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e>*{opacity:0}
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e::after{content:"";position:absolute;left:50%;top:50%;width:18px;height:18px;margin:-9px 0 0 -9px;box-sizing:border-box;border:1.5px solid var(--t3);border-radius:50%;transition:background-color .14s ease,border-color .14s ease}
  .pj-rail.picking .pj-srows.sm .pj-srow:is([data-sid],[data-dr]) .sr-e::after{width:16px;height:16px;margin:-8px 0 0 -8px}
  .pj-rail.picking .pj-srows .pj-srow.pk .sr-e::after{border-color:var(--blue);background:var(--blue) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M2.8 6.3l2.2 2.2 4.2-4.8' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/12px no-repeat}
  .pj-rail.picking .pj-srows .pj-srow.pk,.pj-rail.picking .pj-srows.sm .pj-srow.pk{background:color-mix(in srgb,var(--blue) 13%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 42%,transparent)}
  .pj-rail.picking .pj-srow{user-select:none;-webkit-user-select:none}
  /* The bar stays at the top of what scrolls (the list; on a page that scrolls, under the top bar) so
     a long list never carries it away; a fade under it covers the gap it leaves. */
  .pj-lhd.pj-pick{position:sticky;top:var(--pk-top,0);z-index:4;background:var(--bg)}
  .pj:has(>.pj-cols .pj-pick){overflow-x:clip}   /* the page's own side clip made it a scroller that never scrolls: nothing could stick in it */
  .pj-lhd.pj-pick::after{content:"";position:absolute;left:0;right:0;top:100%;height:12px;pointer-events:none;background:linear-gradient(var(--bg),transparent)}
  .pj-lhd.pj-pick{flex-wrap:nowrap;gap:2px;min-height:34px}   /* one line at every width: the list header may wrap, this bar must not */
  .pj-lhd.pj-pick.new{animation:pj-pkf .18s ease both}
  @keyframes pj-pkf{from{opacity:0}}
  .pj-lhd.pj-pick b{display:block;visibility:visible;flex:1;min-width:0;margin:0 8px 0 4px;font-size:14px;font-weight:600;letter-spacing:0;line-height:30px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-pb .pj-pl{display:none;font-size:13px;font-weight:600;line-height:1}
  .pj-pb.lb{display:inline-flex;align-items:center;justify-content:center;gap:6px}
  @container (min-width:372px){.pj-pb.lb{width:auto;padding:0 8px;gap:4px}.pj-pb.lb .pj-pl{display:inline}}
  /* The two that act on the picked rows say what they do at every width: as icons alone nobody found them. */
  .pj-pb.tx{width:auto;padding:0 6px}.pj-pb.tx .pj-pl{display:inline}
  @container (max-width:371px){.pj-pb.tx svg{display:none}}
  /* The way into picking several, in plain sight beside the list's head. */
  .pj-pkb{flex:none;height:32px;padding:0 8px;border-radius:8px;color:var(--t2);font-size:13px;font-weight:500;white-space:nowrap;transition:background-color .14s ease,color .14s ease}
  .pj-pkb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-pkb:hover{background:var(--btn);color:var(--t1)}}
  @media(pointer:coarse){.pj-pkb{height:40px;padding:0 12px;font-size:15px}}
  @media(prefers-reduced-motion:reduce){.pj-pkb{transition:none}}
  .pj-pb.dz:not([aria-disabled]){color:var(--red)}
  @media(hover:hover){.pj-pb.dz:not([aria-disabled]):hover{background:color-mix(in srgb,var(--red) 14%,transparent)}}
  .pj-pb{flex:none;display:grid;place-items:center;width:30px;height:30px;border-radius:8px;color:var(--t2);transition:background-color .14s ease}
  .pj-pb svg{width:16px;height:16px;fill:currentColor}
  .pj-pb[aria-disabled="true"]{color:var(--t4);cursor:default}
  .pj-pb.dz:not([aria-disabled]){color:var(--red)}
  .pj-pb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-pb:not([aria-disabled]):hover{background:var(--btn)}}
  @media(pointer:coarse){.pj-lhd.pj-pick{min-height:40px}.pj-pb{width:40px;height:40px}.pj-pb svg{width:18px;height:18px}}
  @media(prefers-reduced-motion:reduce){.pj-pb{transition:none}}
  /* The list's head stays where it is while the rows scroll under it (the list, or the page on a phone:
     --lh-top is the page's top bar then). Opaque; the hairline under it shows only once rows have gone
     beneath (.scr). One 8px grid: 32px lines 4px apart, 8px to the first row. */
  .pj-lh{position:sticky;top:var(--lh-top,0);z-index:3;display:flex;flex-direction:column;gap:4px;padding:4px 0 8px;background:var(--lh-bg,var(--bg));box-shadow:0 1px 0 transparent;transition:box-shadow .16s ease}
  .pj-rail.scr .pj-lh{box-shadow:0 1px 0 var(--line)}
  .pj:has(>.pj-cols .pj-lh){overflow-x:clip}   /* as for the picking bar: a page that clips sideways by scrolling lets nothing stick */
  .pj-rail .pj-lh>*{margin:0}
  .pj-lh+.pj-srows{margin-top:0}
  .pj-lh .pj-lhd.pj-pick::after{content:none}
  .pj-lh .pj-lhd.pj-pick{background:none}
  .pj-lsr{display:flex;align-items:center;gap:4px;min-width:0}
  .pj-mrb{position:relative;flex:none;display:grid;place-items:center;width:32px;height:32px;border-radius:8px;color:var(--t3);transition:background-color .14s ease,color .14s ease}
  .pj-mrb svg{width:16px;height:16px;fill:currentColor}
  .pj-mrb[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-mrb.fx::after{content:"";position:absolute;right:5px;top:5px;width:6px;height:6px;border-radius:50%;background:var(--blue)}
  .pj-mrb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-mrb:hover{background:var(--btn);color:var(--t1)}}
  /* What 더보기 folds: how the list looks as plain icon buttons, then Claude | Codex. */
  .pj-lmo{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px;min-width:0}
  .pj-lmo[hidden]{display:none}
  .pj-lmo .pj-tgs{gap:8px}
  .pj-lmo .pj-tg{padding:0;gap:2px;border-radius:8px;background:none}
  .pj-lmo .pj-tg button{width:32px;height:32px;border-radius:8px}
  .pj-lmo .pj-tg button.on{background:var(--btn)}
  .pj-lmo .pj-agf{margin:0}
  .pj-lmo .pj-agf button{position:relative;height:28px}
  .pj-lmo .pj-agf button::after{content:"";position:absolute;inset:-2px 0}
  /* With a mouse 새 세션 is a quiet row of the list's own shape, its caret at the row's end (a phone keeps
     the pill in the thumb's corner). */
  .pj-rail .pj-lsr .pj-sq{flex:1;min-width:0;width:auto;height:32px;min-height:32px;font-size:13px;border-radius:8px}
  .pj-rail .pj-lh .pj-lhd:not(.ph){flex-wrap:nowrap;justify-content:flex-start}
  .pj-rail .pj-lsr~.pj-lhd.pj-pick{min-height:32px}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){
    .pj-cols:not(.no-rail)>.pj-rail>.pj-lh{margin-top:-4px}   /* over the column's own 4px, so nothing shows above it once it sticks */
    .pj-rail .pj-lh .pj-sfil{padding:2px;border-radius:8px}
  }
  html .pj-lh .pj-lhd .pj-newg{flex:1;min-width:0;border-radius:8px;background:none;color:var(--t1);transform:none;outline-offset:-2px}
  html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn{height:32px}
  .pj-lh .pj-lhd .pj-newb{flex:1;min-width:0;justify-content:flex-start;padding:0 8px;gap:8px;border-radius:8px;font-size:13px;font-weight:500}
  .pj-lh .pj-lhd .pj-newb svg{width:16px;height:16px;color:var(--t3)}
  .pj-lh .pj-lhd .pj-newc{width:32px;padding:0;border-radius:8px;color:var(--t3)}
  .pj-lh .pj-lhd .pj-newc::before{content:none}
  html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn:is(:active,:focus-visible,[aria-expanded="true"]){background:color-mix(in srgb,var(--t1) 10%,transparent)}
  @media(hover:hover){html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn:hover{background:color-mix(in srgb,var(--t1) 6%,transparent)}}
  @media(pointer:coarse),(max-width:720px){
    .pj-lh{gap:8px}
    .pj-mrb,.pj-lmo .pj-tg button{width:40px;height:40px}
    .pj-rail .pj-lsr .pj-sq,html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn{height:40px;min-height:40px}
    .pj-lh .pj-lhd .pj-newc{width:40px}
    .pj-rail .pj-lsr~.pj-lhd.pj-pick{min-height:40px}
    .pj-lmo .pj-agf button{height:36px}
  }
  @media(prefers-reduced-motion:reduce){.pj-lh,.pj-mrb{transition:none}}
  .pj-dlg .pj-dsub{margin:0 0 4px;font-size:13px;line-height:1.5;color:var(--t3)}
  /* Flat list: the session's name, then what was said in the room left over. The excerpt gives
     way first; the name is only cut once the excerpt is gone. */
  .pj-srows.sm .sr-t.nm{flex:0 1 auto;font-weight:600}
  .pj-srows.sm .sr-q{flex:1 1 0;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;line-height:20px;color:var(--t3)}
  .pj-srows.sm .sr-2{order:1;flex:none;height:auto} .pj-srows.sm .sr-s,.pj-srows.sm .sr-ask{display:none}
  .pj-srows.sm .sr-w{order:2;min-width:0;font-size:11.5px;line-height:18px}
  .pj-srows.sm .sr-ad{display:inline-block;margin:0 1px;width:5px;height:5px}
  .pj-srows.sm .sr-1 .pj-pinmk{margin:0;order:1} .pj-srows.sm .sr-1 .pj-pinmk svg{width:11px;height:11px}
  .pj-srows.sm .sr-1 .pj-face{margin-right:-2px}
  .pj-srows.sm .pj-srow .sr-e .pj-em{width:16px;height:16px;font-size:13px;border-radius:6px;background:none}
  .pj-srows.sm .pj-srow .sr-e .pj-em .phi{width:16px;height:16px}
  .pj-srows.sm .sr-o>i{width:5px;height:5px}
  .pj-srows.sm .pj-srow .sr-m,.pj-srows.sm .pj-sgl .sr-m{width:24px;height:24px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-srow .sr-m{top:calc(50% - 12px);right:4px}
    .pj-srows.sm .pj-srow:hover .sr-m~.sr-x .sr-2,.pj-srows.sm .pj-srow:focus-within .sr-m~.sr-x .sr-2,.pj-srows.sm .pj-srow:hover .sr-m~.sr-x .pj-pinmk,.pj-srows.sm .pj-srow:focus-within .sr-m~.sr-x .pj-pinmk{opacity:0}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-srow{height:40px;padding-right:0}
    .pj-srows.sm .pj-srow .sr-m,.pj-srows.sm .pj-sgl .sr-m{width:40px;height:40px}}
  .pj-srows.sm .pj-sgrp{margin-top:8px}
  .pj-srows.sm .pj-sgl{padding:0 4px 0 8px}
  .pj-srows.sm .pj-sgh{height:28px;gap:8px;padding:0 4px 0 8px;font-size:12px;font-weight:600;color:var(--t3);border-radius:8px}
  .pj-srows.sm .pj-sgh .pj-em,.pj-srows.sm .pj-sgl .pj-em.tint{width:16px;height:16px;font-size:13px;border-radius:6px;background:none}
  .pj-srows.sm .pj-sgh .pj-em .phi{width:16px;height:16px}
  .pj-srows.sm .pj-sgh .n{margin-left:-2px;font-size:11.5px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-sgh[aria-expanded="true"] .cv{opacity:0;transition:opacity .12s ease}
    .pj-srows.sm .pj-sgl:hover .cv,.pj-srows.sm .pj-sgh:focus-visible .cv{opacity:1}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-sgh{height:36px}.pj-srows.sm .pj-sgl{padding-right:0}}
  .pj-srows.sm .pj-fold{padding:0 8px 0 40px;margin-top:0;height:24px;font-size:12px}
  .pj-srows.sm .pj-sdv{margin-top:8px}
  /* 크게: the two-line cards, with less air around them: closer cards, a lower group line. */
  .pj-srows:not(.sm) .pj-srow{height:56px;margin-top:4px}
  .pj-srows:not(.sm) .pj-sgrp{margin-top:8px}
  .pj-srows:not(.sm) .pj-sgl{padding:0 4px 0 0}
  .pj-srows:not(.sm) .pj-sgh{height:32px}
  .pj-srows:not(.sm) .pj-fold{padding-top:4px;padding-bottom:4px;margin-top:0}
  @media(pointer:coarse){.pj-srows .pj-fold{min-height:40px}}
  /* the rows that close the list (older, hidden, same-name) start where the session rows do */
  .pj-srows>.pj-fold{padding-left:12px}
  .pj-srows.sm>.pj-fold{padding-left:8px}
  .pj-srows:not(.sm) .sr-q{display:none}
  .pj-srow .sr-st{color:var(--sr-work);font-weight:600}
  /* 작업 중: the working hue on the orb, and one slow light travelling along the row's top edge.
     Only its transform animates (its own layer: nothing is laid out or repainted around it). */
  .pj-srows .pj-srow.s-live{--orb-ink:var(--sr-work);overflow:hidden}
  .pj-srows .pj-srow.s-live::after{content:"";position:absolute;left:0;top:0;width:42%;height:1px;pointer-events:none;will-change:transform;
    background:linear-gradient(90deg,rgba(var(--sr-gw),0),rgba(var(--sr-gw),.85) 50%,rgba(var(--sr-gw),0));
    transform:translateX(-100%);animation:pj-sheen 5.2s linear infinite}
  html[data-theme="light"] .pj-srows .pj-srow.s-live::after{height:2px}
  @keyframes pj-sheen{to{transform:translateX(240%)}}
  @media(prefers-reduced-motion:reduce){.pj-srows .pj-srow.s-live::after{animation:none;transform:none;width:60%;
    background:linear-gradient(90deg,rgba(var(--sr-gw),.6),rgba(var(--sr-gw),0))}}
  .pj-olds>.pj-card{opacity:.72}
  /* The chat's own head when the list is beside it: the conversation's name and one line under it. */
  .pj-nth{flex:none;display:flex;align-items:center;gap:8px;padding:16px 12px 12px 16px;border-bottom:1px solid var(--line)}
  .pj-nth .tx{flex:1;min-width:0}
  .pj-nth .t{font-size:16px;font-weight:600;letter-spacing:-.01em;line-height:1.35;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-nth .s{margin-top:2px;font-size:12px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-nth .pj-more{margin:0}
  .pj-nth [data-list]{margin-left:-8px}
  .pj-nth [data-list] svg{width:18px;height:18px}
  .pj-listonly>.pj-body{display:none}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-nth{padding:8px 8px 8px 16px}.pj-nth .t{font-size:16px}
    .pj-nth~.pj-wrap .pj-msgs{padding:16px}
    /* A phone's open chat is the whole screen (body.pjchat, phoneChat()): the name on top, the log
       taking what is left, the message box on the bottom edge. Its height is the part of the
       screen that can be seen (--pj-vh/--pj-vt follow visualViewport), so the box sits right on
       the keyboard and the page under it has nothing to scroll. */
    body.pjchat{overflow:hidden}
    body.pjchat .tabbar,body.pjchat #m-goo,body.pjchat .pj-seg,body.pjchat:not(.inapp) #top{display:none}
    body.pjchat #view>.pj{animation:none;padding-bottom:0}
    body.pjchat .pj-conv{touch-action:pan-y;position:fixed;z-index:4;left:0;right:0;top:var(--pj-vt,0px);height:var(--pj-vh,100dvh);border-radius:0;background:var(--bg)}
    body.pjchat .pj-wrap{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
    body.pjchat .pj-msgs{flex:1 1 auto;height:auto;min-height:0}
    body.pjchat .pj-conv>.pj-in{padding-bottom:max(12px,env(safe-area-inset-bottom))}
    /* What a thumb presses is 44px: back, results, the picture button (send and the model chip already are). */
    body.pjchat .pj-nth{gap:4px;padding-top:calc(4px + env(safe-area-inset-top));padding-bottom:4px;padding-left:calc(6px + env(safe-area-inset-left));padding-right:calc(6px + env(safe-area-inset-right))}
    body.pjchat.inapp .pj-nth{padding-top:4px}
    body.pjchat .pj-nth [data-list],body.pjchat .pj-nth [data-res]{display:inline-flex;position:relative;width:44px;height:44px;margin:0;border-radius:50%;color:var(--t1)}
    body.pjchat .pj-nth [data-list] svg,body.pjchat .pj-nth [data-res] svg{width:22px;height:22px}
    body.pjchat .pj-nth [data-res] .pj-nb{position:absolute;top:4px;right:2px;margin:0}
    body.pjchat .pj-nth .tx{padding:4px 0}
    body.pjchat .pj-box .pj-clip{position:relative}
    body.pjchat .pj-box .pj-clip::after{content:"";position:absolute;inset:-6px}
    /* The keyboard leaves little room: the first-visit tip and the standing note give theirs to the log. */
    body.pjchat.pj-kb .pj-tip,body.pjchat.pj-kb .pj-note{display:none}
    body.pjchat.pj-kb .pj-note:has(.pj-q){display:block}   /* a question being answered is typed into the note itself */
    /* So does everything else that is not the conversation. The state line folds into the name's
       row as its mark alone (the words, the chips and the menu come back with the keyboard down),
       the name's row is exactly its 44px buttons, and the box is one line of text over its
       buttons with no room around it. Nothing moves in: the rows are simply not there. */
    body.pjchat.pj-kb .pj-nth{padding-top:env(safe-area-inset-top);padding-bottom:0;border-bottom:1px solid var(--line)}
    body.pjchat.pj-kb.inapp .pj-nth{padding-top:0}
    body.pjchat.pj-kb .pj-nth:has(+#pj-state) .tx{padding-right:16px}
    body.pjchat.pj-kb .pj-nth~#pj-state .pj-state{position:absolute;top:env(safe-area-inset-top);right:calc(50px + env(safe-area-inset-right));height:44px;padding:0;border:0;pointer-events:none}
    body.pjchat.pj-kb.inapp .pj-nth~#pj-state .pj-state{top:0}
    body.pjchat.pj-kb .pj-nth~#pj-state .pj-state>:not(:first-child),body.pjchat.pj-kb .pj-nth~#pj-state .pj-acts{display:none}
    body.pjchat.pj-kb .pj-nth~.pj-wrap .pj-msgs{padding-top:8px;padding-bottom:8px}
    body.pjchat.pj-kb .pj-conv>.pj-in{padding:2px 8px 4px}
    body.pjchat.pj-kb .pj-box{padding:6px 8px 6px 12px;gap:4px 6px}
    body.pjchat.pj-kb .pj-box #pj-ta{min-height:0;padding:2px 2px 4px}}
  .pj-nth [data-res]{display:none}
  .pj-nth+.pj-state{display:none}
  /* An open session: its state row is the one line under the name (state · project · agent).
     The standing "goes straight through" note and the first-visit tip are not repeated here. */
  .pj-nth:has(+#pj-state){border-bottom:0;padding-bottom:0}
  .pj-stx{display:none;min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-nth~#pj-state .pj-stx{display:inline}
  .pj-nth.pn~#pj-state .pj-stp{display:none}   /* the title above already is the project's name */
  .pj-nth~#pj-state .pj-state{padding:2px 12px 8px 16px;font-size:12px;color:var(--t3);gap:6px}
  .pj-nth~#pj-state .pj-state .pj-more{margin:-8px 0}
  .pj-nth~#pj-tip{display:none}
  .pj-nth~#pj-note:not(:has(div:not(.nl))){display:none}
  /* Who receives the line is said by the pills under the text, not by a line above the box. */
  .pj-nth~.pj-to{display:none}
  .pj-nth~.pj-in,.pj-nth~.pj-to+.pj-in{border-top:0;padding:4px 16px 16px}
  .pj-pjn{display:none}
  .pj-nth~.pj-in .pj-pjn{display:inline-flex;align-items:center;gap:6px;flex:0 1 auto;min-width:0;height:32px;padding:0 12px;border:1px solid var(--line);
    border-radius:999px;font-size:13px;color:var(--t2);white-space:nowrap}
  .pj-pjn .pj-em{flex:none;font-size:13px;width:auto}
  .pj-pjn span:last-child{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-nth~.pj-in .pj-clip{width:32px;height:32px;margin-left:-2px;border:1px solid var(--line);border-radius:999px}
  .pj-nth~.pj-in .pj-clip svg{width:15px;height:15px}
  /* A session that is up keeps its actions in the menu beside its state; one that ended shows them. */
  .pj-nth~#pj-state:not(:has(.pj-stl.ended)) .pj-acts{display:none}
  .pj-nth~.pj-wrap .pj-msgs{padding:16px 20px;gap:16px}
  .pj-nth~.pj-wrap .pj-msg.user,.pj-nth~.pj-wrap .pj-msg.claude{font-size:17px;line-height:1.7}
  .pj-nth~.pj-wrap .pj-md :is(p,ul,ol){margin-bottom:16px}.pj-nth~.pj-wrap .pj-md li{margin:8px 0}
  .pj-nth~.pj-wrap .pj-md>:last-child{margin-bottom:0}
  .pj-nth~.pj-wrap .pj-msg.user{padding:8px 16px;border-radius:16px 16px 4px 16px}
  /* A window on a desk reads at the size of the rest of the app (13-15px); 16px is the phone's. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.pj-nth~.pj-wrap .pj-msg.user,.pj-nth~.pj-wrap .pj-msg.claude{font-size:14.5px;line-height:1.6}
    .pj-nth~.pj-wrap .pj-md :is(p,ul,ol){margin-bottom:12px}.pj-nth~.pj-wrap .pj-md li{margin:6px 0}.pj-nth~.pj-wrap .pj-md>:last-child{margin-bottom:0}
    .pj-nth~.pj-wrap .pj-msg.user{padding:8px 12px;border-radius:12px 12px 4px 12px}}
  /* The message box, two rows in one field: the text, and under it picture / model / send. */
  .pj-box{flex-wrap:wrap;align-items:center;gap:6px;padding:8px 12px 8px 16px;border-radius:16px}
  .pj-box:focus-within{border-color:color-mix(in srgb,var(--t1) 26%,transparent);box-shadow:none}
  .pj-box textarea{order:-1;flex:1 0 100%;padding:2px 2px 8px}
  .pj-box .pj-clip{margin-left:-6px}
  .pj-box .pj-go{border-radius:50%;margin-left:auto}
  .pj-enter{margin-left:auto;padding-right:6px;font-size:12px;color:var(--t4);white-space:nowrap}
  html[data-theme="light"] .pj-enter{color:var(--t3)}
  .pj-enter+.pj-go{margin-left:0}
  @media(max-width:899px){.pj-enter{display:none}.pj-enter+.pj-go{margin-left:auto}}
  .pj-mwrap{position:relative;display:inline-flex;min-width:0}
  .pj-mwrap:empty{display:none}
  /* How full the conversation is: a quiet number that only takes a colour when it matters. */
  .pj-ctx{flex:none;align-self:center;display:inline-flex;align-items:baseline;gap:4px;font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap}
  .pj-ctx small{font-size:inherit;opacity:.8}
  .pj-ctx.hot{color:var(--orange)} html[data-theme="light"] .pj-ctx.hot{color:#b77400}
  .pj-gauge{flex:none;align-self:center;position:relative;display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:4px;border-radius:50%;color:var(--t3);cursor:pointer;transition:background-color .12s ease,color .12s ease}
  .pj-gauge::before{content:"";position:absolute;inset:-6px}
  .pj-gauge:hover,.pj-gauge[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-gauge svg{display:block;width:14px;height:14px;transform:rotate(-90deg)}
  .pj-gauge circle{fill:none;stroke-width:2.5;stroke:currentColor}
  .pj-gauge circle.tr{opacity:.28} .pj-gauge circle.ar{stroke-linecap:round}
  .pj-gauge.hot circle.ar{stroke:var(--orange)}
  .pj-upop{padding:14px 12px 12px;transition:opacity .14s ease-out;opacity:0}
  .pj-upop.on{opacity:1}
  .pj-upop h5{margin:0 6px 8px;font-size:12px;font-weight:600;line-height:16px;color:var(--t3)}
  .pj-upop .w{display:grid;grid-template-columns:auto 1fr auto;align-items:baseline;column-gap:8px;row-gap:6px;margin:0 6px;font-variant-numeric:tabular-nums}
  .pj-upop .w+.w{margin-top:12px}
  .pj-upop .w .k{font-size:13px;font-weight:600;line-height:18px;color:var(--t1)}
  .pj-upop .w .t{font-size:12px;line-height:18px;color:var(--t3);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-upop .w .v{font-size:12px;line-height:18px;color:var(--t2)}
  .pj-upop .w .bar{grid-column:1/-1;display:block;height:4px;border-radius:2px;background:var(--btn);overflow:hidden}
  .pj-upop .w .bar i{display:block;height:100%;border-radius:2px;background:var(--t2)}
  .pj-upop .w:first-child .bar i{background:var(--blue-t)}
  .pj-upop .w.hot .bar i,.pj-upop .w.hot:first-child .bar i{background:var(--orange)}
  .pj-upop .s{margin:8px 6px 0;font-size:12px;line-height:1.45;color:var(--t3)}
  .pj-upop hr{margin:12px 0}
  .pj-upop .go{display:inline-flex;align-items:center;height:28px;margin:12px 6px 0;padding:0 10px;border-radius:var(--r-md);background:var(--btn);font-size:12px;font-weight:600;color:var(--t1);cursor:pointer}
  .pj-upop .go:hover{background:var(--btn-hi)}
  /* A phone's row has no room for one more thing: the number takes the place of the chip's caret and dot. */
  .pj-box.pj-tight .pj-mwrap:has(.pj-gauge) .pj-mbtn :is(.cv,.sep){display:none}
  .pj-box .pj-agseg{flex:none}
  /* On a phone the switch is as tall as the chip beside it; the press area keeps its height. */
  @media(max-width:560px){.pj-box .pj-agseg button{position:relative;height:28px;padding:0 12px}.pj-box .pj-agseg button::after{content:"";position:absolute;inset:-8px 0}}
  /* The model chip: what this conversation runs on, and above it the popover that changes it.
     The popover grows out of the chip on a stepped spring (see open()); the chip only eases its hover. */
  .pj-mbtn{position:relative;display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px 0 8px;border:1px solid var(--line);
    border-radius:999px;color:var(--t2);font-size:13px;font-weight:500;white-space:nowrap;cursor:pointer;min-width:0;max-width:100%;transition:background-color .14s ease,transform .18s var(--ease)}
  .pj-mbtn:hover{background:var(--btn)}
  .pj-mbtn[aria-expanded="true"]{border-color:var(--blue);background:var(--btn)}
  .pj-mbtn .sk{flex:none;width:14px;height:14px;color:var(--t3)}
  .pj-mbtn .mn{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-mbtn .sep{color:var(--t4)}
  .pj-mbtn b{color:var(--t1);font-weight:700}
  .pj-mbtn .dt{flex:none;width:7px;height:7px;border-radius:50%;background:var(--blue)}
  .pj-mbtn .dt.w{width:8px;height:8px;background:none;box-shadow:inset 0 0 0 1.5px var(--t1)}
  .pj-mbtn .cv{flex:none;width:11px;height:11px;transform:rotate(90deg);color:var(--t3)}
  .pj-feedback{margin:8px 12px;color:var(--t3);font-size:13px}.pj-feedback summary{cursor:pointer;min-height:44px;padding:12px 0}.pj-feedback-row{padding:12px 0;border-top:1px solid var(--line)}.pj-feedback-row p{white-space:pre-wrap;overflow-wrap:anywhere;margin:8px 0;color:var(--t2)}.pj-feedback-row button{font-size:13px;min-height:44px}
  .pj-mpop{position:absolute;left:0;bottom:calc(100% + 8px);z-index:6;width:264px;box-sizing:border-box;padding:16px 12px 12px;border-radius:var(--menu-r);
    background:var(--menu-bg);border:1px solid var(--line);box-shadow:var(--menu-shadow);cursor:default;text-align:left;white-space:normal;overflow:auto}
  .pj-mpop .hd{display:flex;align-items:center;gap:8px;min-height:24px;margin:0 6px}
  .pj-mpop h4{flex:1;min-width:0;margin:0;font-size:15px;font-weight:600;line-height:1.3;color:var(--t1)}
  .pj-mpop .mx{display:none;flex:none;position:relative;width:28px;height:28px;margin:-2px 0;border-radius:50%;align-items:center;justify-content:center;color:var(--t2);background:var(--btn);cursor:pointer}
  .pj-mpop .mx::before{content:"";position:absolute;inset:-8px}
  .pj-mpop .mx .i{width:14px;height:14px}
  .pj-mpop p{margin:0 6px}
  .pj-mpop .wn{margin-top:4px;font-size:12px;line-height:1.45;color:var(--t3)}
  .pj-mpop .lb{display:flex;align-items:baseline;gap:6px;margin:12px 6px 6px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-mpop .lb small{font-size:12px;font-weight:500;color:var(--t4)}
  .pj-mrow{display:flex;align-items:center;gap:8px;width:100%;box-sizing:border-box;min-height:44px;padding:4px 6px;border-radius:var(--r-sm);text-align:left;cursor:pointer}
  .pj-mrow:hover{background:var(--btn)}
  .pj-mrow .ck{flex:none;display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:auto;color:var(--t1);opacity:0}
  .pj-mrow .ck .i{display:block;width:16px;height:16px;margin:0}
  .pj-mpop.off .pj-mrow,.pj-mpop.off .pj-mem,.pj-mpop.off .pj-meff{opacity:.45;pointer-events:none}
  .pj-mrow[aria-checked="true"] .ck{opacity:1}
  .pj-mpop .lb b{margin-left:auto;font-weight:600;color:var(--t1)}
  .pj-mem.em{margin:0 6px;--em-fill:var(--blue);--em-knob:var(--on-blue,#fff)}
  .pj-meff[hidden]{display:none}
  .pj-mrow .tx{flex:1;min-width:0}
  .pj-mrow .nm{display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;font-size:14px;font-weight:600;line-height:1.3;color:var(--t1)}
  .pj-mrow .nm em{font-style:normal;font-size:12px;font-weight:600;line-height:16px;padding:0 6px;border-radius:999px;color:var(--t2);box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap}
  .pj-mrow[aria-checked="true"] .nm em{color:var(--blue);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 45%,transparent)}
  .pj-mrow .ds{display:block;margin-top:1px;font-size:12px;line-height:1.35;color:var(--t3)}
  .pj-mpop .nt{margin-top:6px;font-size:11.5px;line-height:1.45;color:var(--t3)}
  .pj-meff{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:2px;padding:4px;border-radius:8px;background:var(--bg)}
  .pj-meff button{height:30px;min-width:0;border-radius:8px;font-size:12px;color:var(--t2);cursor:pointer}
  .pj-meff button:hover{color:var(--t1)}
  .pj-meff button[aria-checked="true"]{background:var(--btn-hi);color:var(--t1);font-weight:700}
  .pj-mpop .ed{margin-top:8px;min-height:17px;font-size:12px;line-height:1.4;color:var(--t2)}
  .pj-mpop hr{margin:12px 0 8px;border:0;border-top:1px solid var(--line)}
  .pj-box.pj-tight .pj-pjn,.pj-box.pj-tight .pj-enter{display:none}
  .pj-box.pj-tight .pj-enter+.pj-go{margin-left:auto}
  /* The mic is send's neighbour on the right: it takes the push where the Enter hint is not shown. */
  .pj-in .pj-box button.pj-mic{margin-left:0}
  .pj-in .pj-box .pj-mic+.pj-go{margin-left:0}
  @media(max-width:899px){.pj-in .pj-box button.pj-mic{margin-left:auto}}
  .pj-in .pj-box.pj-tight button.pj-mic{margin-left:auto}
  .pj-in .pj-box.pj-rec button:is(.pj-mic,.pj-vx){margin-left:0}
  @media (pointer:coarse),(max-width:720px){
    .pj-mbtn::before{content:"";position:absolute;inset:-6px 0}
    .pj-meff button{height:44px}
    .pj-mem .em-track{height:44px}
    .pj-mpop .mx{display:inline-flex}
  }
  @media(max-width:380px){.pj-meff button{font-size:11.5px}}
  html.pj3 .pj-conv.pj-draft{grid-column:2/-1}
  .pj-draft .pj-empty{margin:auto}
  .pj-pendc .pj-msgs{height:auto;min-height:0} .pj-pendc .pj-empty b{display:block;color:var(--t1)}
  .pj-draft .pj-empty b{display:block;color:var(--t1);font-size:16px;font-weight:600;margin-bottom:4px}
  .pj-anim{animation:pj-in .16s ease-out both}
  /* A page that is redrawn in place (a refresh, another session in the same view): nothing comes in again */
  #view.still .pj-anim{animation:none}
  /* Another conversation in the same column: its lines settle in, the frame around them never moves */
  .pj-msgs.pj-swap{animation:pj-swap .13s ease-out}
  @keyframes pj-swap{from{opacity:.6}}
  /* Lines still on their way: the shared loader (loading.js), in the middle of the chat */
  .pj-wait{margin:auto;padding:0;width:100%}
  @media(prefers-reduced-motion:reduce){.pj-msgs.pj-swap{animation:none}}
  @keyframes pj-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  @media(prefers-reduced-motion:reduce){.pj-anim{animation:pj-fade .2s ease both}
    @keyframes pj-fade{from{opacity:0}to{opacity:1}}}
  /* Phone pass over the conversation (mchat68). The chat is the screen: one header row, a message
     box that is one row until something is typed, and the model popover as a bottom sheet that
     fades where it is. Sizes: 44px to press, 13px to read. */
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    /* The state folds into the name's row: its mark, and the menu. The words and the project /
       agent line say what the name and the chip beside it already say. An ended session keeps its row (its actions). */
    body.pjchat .pj-nth:has(+#pj-state .pj-stl:not(.ended)){padding-right:calc(70px + env(safe-area-inset-right))}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)){height:0}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state{position:absolute;top:env(safe-area-inset-top);right:env(safe-area-inset-right);z-index:1;height:48px;padding:0;gap:0;border:0;pointer-events:none}
    body.pjchat.inapp .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state{top:0}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>.pj-more{pointer-events:auto;margin:2px 4px 2px 6px!important;width:44px;height:44px;border-radius:50%}   /* over the button's inline margin: that pulled it past the edge and against the mark */
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>:is(.pj-stl,.pj-stx,.sp){position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
    /* Only the menu takes a press there: 변경 and 로그 were drawn over the header's own button and answered nothing.
       The chips (창 없음, 옮겨짐, 오프라인) go too: they widened the row over the results button; the list row keeps them. */
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>:is(.pj-chg,[data-bglog],.pj-bg,.off){display:none}
    body.pjchat.pj-kb .pj-nth{padding-right:calc(6px + env(safe-area-inset-right))}
    /* The log: no clock on every line, the last one keeps its time; the tool lines read at 13px. */
    body.pjchat .pj-msgs>.pj-msg .pj-tm{display:none}
    body.pjchat .pj-msgs>.pj-msg:last-child .pj-tm{display:block}
    body.pjchat .pj-msgs>.pj-msg.user:last-child>.pj-tm{display:block}
    .pj-msg.tool,.pj-tfold,.pj-msg .tg,.pj-day{font-size:13px}
    .pj-md code{font-size:14px}
    .pj-tfold{position:relative}.pj-tfold::after{content:"";position:absolute;inset:-10px -6px}
    .pj-msg .tg button{position:relative}.pj-msg .tg button::after{content:"";position:absolute;inset:-11px -4px}
    /* The picture waiting to go: its remove mark is a 44px press, the picture stays small. */
    .pj-att .th button{position:relative}.pj-att .th button::after{content:"";position:absolute;inset:-12px}
    /* The message box: the words on their own row, the buttons under them. One shared row cut the words short. */
    body.pjchat .pj-conv>.pj-in,body.pjchat .pj-nth~.pj-in{padding:4px 10px max(10px,env(safe-area-inset-bottom))}
    body.pjchat .pj-box #pj-ta{font-size:16px}
    .pj-box.pj-rec .pj-wave{height:44px}
    /* The model chip: 44px to press, the same look. */
    .pj-mbtn{min-width:44px;height:44px;font-size:14px}.pj-mbtn::before{inset:-4px 0}
    .pj-box .pj-clip{width:44px;height:44px}
    .pj-nth~.pj-in .pj-clip{width:44px;height:44px;margin-left:-8px;border:0}
    .pj-nth~.pj-in .pj-clip svg{width:20px;height:20px}
    .pj-box .pj-agseg button{height:36px;font-size:14px}.pj-box .pj-agseg button::after{inset:-4px 0}
    /* The model popover is a bottom sheet: it fades in place, over a veil that closes it. It floats
       clear of the screen's edges with a grabber, close on the left of a centred title, and the
       models as one card of rows with a line between them. */
    .pj-mscrim{position:fixed;inset:0;z-index:79;background:rgba(0,0,0,.4)}
    .pj-mpop.sheet{display:block;position:fixed;left:8px!important;right:8px;top:auto!important;bottom:max(8px,env(safe-area-inset-bottom));width:auto!important;max-height:min(82vh,82dvh)!important;z-index:80;margin:0;
      padding:20px 12px 12px;border-radius:28px;overscroll-behavior:contain;transform:none!important}
    .pj-mpop.sheet::before{content:"";position:absolute;top:8px;left:50%;width:36px;height:4px;margin-left:-18px;border-radius:2px;background:var(--t4)}
    .pj-mpop.sheet .hd{position:relative;justify-content:center;min-height:44px;margin:0 0 8px}
    .pj-mpop.sheet h4{flex:none;max-width:calc(100% - 104px);font-size:16px;text-align:center}
    .pj-mpop.sheet .mx{position:absolute;left:0;top:0;width:44px;height:44px;margin:0;box-shadow:inset 0 0 0 1px var(--line)}.pj-mpop.sheet .mx .i{width:16px;height:16px}
    .pj-mpop.sheet [data-g="model"]{padding:0 16px;border-radius:20px;background:var(--card)}
    .pj-mpop.sheet .pj-mrow{min-height:60px;padding:10px 0;border-radius:0}
    .pj-mpop.sheet .pj-mrow:hover{background:none}
    .pj-mpop.sheet .pj-mrow+.pj-mrow{border-top:1px solid var(--line)}
    .pj-mpop.sheet .wn{margin-bottom:8px;text-align:center}
    .pj-mpop.sheet .wn,.pj-mpop.sheet .lb,.pj-mpop.sheet .lb small,.pj-mpop.sheet .ed,.pj-mpop.sheet .us,.pj-mpop.sheet .pj-mrow .ds{font-size:13px}
    .pj-mpop.sheet .pj-mrow .nm{font-size:16px}.pj-mpop.sheet .pj-mrow .nm em{font-size:12px}
    .pj-mpop.sheet .nt{display:none}
  }
  `;
  function ensureCss() {
    if (document.getElementById("pj-style")) return;
    const s = document.createElement("style"); s.id = "pj-style"; s.textContent = CSS;
    document.head.appendChild(s);
  }

  const LABEL = LT(() => ({live: tl("pj.st.live"), idle: tl("pj.st.idle"), stale: tl("pj.st.stale"), stuck: tl("pj.st.stuck"), ended: tl("pj.st.ended")}));
  // Outline icons this screen needs that the app set (v2.js, filled) does not have: Phosphor regular.
  const ICO = {panel: ic("sidebar"), moon: ic("moon")};
  // 대기 is a session that just finished a turn; one nobody has touched for two hours is still
  // up (and still costs a slot), which is a different thing to act on: its own word, icon and colour.
  const STALE_MS = 2 * 3600 * 1000;
  const kindOf = (st, last) => st === "idle" && last && Date.now() - Date.parse(last) > STALE_MS ? "stale" : (st || "ended");
  const dot = (st) => st === "stale" ? `<span class="pj-ico stale">${ICO.moon}</span>` : `<span class="pj-dot ${st}"></span>`;
  const mark = (st, last) => { const k = kindOf(st, last); return dot(k) + `<span class="pj-stl ${k}">${LABEL[k] || k}</span>`; };
  const agentTag = (a) => `<span class="pj-ag ${a === "codex" ? "cx" : "cl"}">${window.agDot(a)}${a === "codex" ? "Codex" : "Claude"}</span>`;
  const enc = encodeURIComponent;
  // What a session is called in the flat list, a chat's head, a pane's head and a float block:
  // the standing session's fixed name, else the name it was given (Claude's custom title, or the
  // app's own title when that is not the first message again), else its project's shown name.
  // What was said (the title the folder view shows) tells same-named sessions apart in the tooltip.
  const sessName = (s, pn) => s.fixed || s.named || pname(pn);
  const title = (s) => s.fixed || (s.title && s.title !== "(제목 없음)" ? s.title : tl("pjx.sessOf", {id: s.id.slice(0, 8)}));
  // A list preview is one line of plain words: the marks of markdown (bold, code, a link's address,
  // a heading or list sign) are dropped, what they wrap is kept.
  const flat1 = (t) => (typeof inlineRuns === "function" ? inlineRuns(String(t || "")).map((r) => r.t === "img" ? "" : r.v).join("") : String(t || ""))
    .replace(/^\s*(?:#{1,6}|>|[-*+]|\d+[.)])\s+/gm, "").replace(/```\w*/g, "").replace(/\s+/g, " ").trim();
  // The inbox stamps a line with a note saying who is speaking; the person typed one sentence.
  // chat-order:begin (pure; tests/chatorder.test.js runs this block on its own)
  const unnote = (t) => String(t || "").replace(/^\[Genok\] 사용자가[^\n]*:\s*/, "").trim();
  // Whether a transcript line is the one I sent. The transcript trims it, may end its lines
  // differently, and cuts a long one short with an ellipsis: none of that makes it another line.
  const lineKey = (t) => unnote(t).replace(/\r\n?/g, "\n").replace(/[ \t]+\n/g, "\n").trim();
  const sameLine = (mine, theirs) => { const a = lineKey(mine), b = lineKey(theirs);
    return a === b || (b.length > 200 && b.endsWith("…") && a.startsWith(b.slice(0, -1))); };
  // Where a line that is not in the transcript yet stands: before the first thing the session
  // wrote after it was sent (-1 = last). `ats` are the timestamps of what the session wrote.
  const pendSlot = (ats, at) => at ? ats.findIndex((t) => Date.parse(t) > at) : -1;
  // chat-order:end

  // ---- dialogs: refern-style rows, one calm primary, quieter secondary --------------------------
  // Resolves with the button's value; a swipe/scrim/Esc dismissal resolves "cancel".
  // Waits a beat first so a sheet that just closed has finished before the next one opens.
  function ask(html, wire) {
    return new Promise((res) => setTimeout(res, 320)).then(() => new Promise((res) => {
      let done = false;
      const fin = (v) => { if (done) return; done = true; clearInterval(t); document.removeEventListener("keydown", key, true); res(v); };
      let first = null;
      // Enter presses the dialog's first (primary) button, unless a field or another button has the focus.
      const key = (e) => {
        if (e.key !== "Enter" || e.isComposing || !first || !first.isConnected || first.disabled) return;
        const a = document.activeElement;
        if (a && a !== first && /^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(a.tagName) && a.closest(".pj-dlg")) return;
        e.preventDefault(); e.stopPropagation(); first.click();
      };
      sheet(`<div class="pj-dlg">${html}</div>`, (box) => {
        box.querySelectorAll("[data-v]").forEach((b) => b.onclick = () => { fin(b.dataset.v); closeSheet(); });
        first = box.querySelector(".acts [data-v]:not([data-v='cancel'])");
        if (wire) wire(box);
      });
      document.addEventListener("keydown", key, true);
      const t = setInterval(() => { const s = document.getElementById("sheet"); if (!s || !s.classList.contains("on")) fin("cancel"); }, 200);
    }));
  }
  // One question, one dim line under it (the text after the first "? "), two buttons side by side.
  // `kind` is given only for a harmless, reversible confirm: it gets "다시 묻지 않기", and once that
  // was ticked the question is skipped. Nothing that deletes or stops passes a kind.
  const confirmDlg = (msg, go, kind, danger, m = /^(.*?\?)\s+(\S.*)$/s.exec(msg || "")) => kind && noAsk()[kind] ? Promise.resolve("ok") : ask(
    `<div class="cf"><h3>${esc(m ? m[1] : msg)}</h3>${m ? `<p class="cf-sub">${esc(m[2])}</p>` : ""}
     ${kind ? `<label class="cf-never"><input type="checkbox" id="cf-never">${tl("noask.box")}</label>` : ""}
     <div class="acts cf-acts"><button class="pj-btn ${danger ? "danger" : "light"} full press" data-v="ok">${esc(go || tl("pjx.go"))}</button>
     <button class="pj-btn full press" data-v="cancel">${tl("libDraw.22")}</button></div></div>`, (box) => {
      const ok = box.querySelector("[data-v='ok']"), was = ok.onclick;
      ok.onclick = () => { const c = box.querySelector("#cf-never"); if (kind && c && c.checked) noAskSet(kind); was(); };
    });
  // The app's shared consent dialog (web/consent.js) answers every {need_consent} / 428.
  // "cancelled" is thrown on a decline so callers stay quiet.
  // A server that wants more than one "are you sure" answers {need_confirm: <level>, what, go};
  // the level goes back as body.confirm until it stops asking (stop asks twice).
  // `tick(true|false)`: the request is out / a question is on the screen (the busy mark follows it).
  async function act(path, body, depth, tick) {
    if (tick) tick(true);
    const j = await loopFetch(path, {method: "POST", json: body || {}});
    if (j.declined) throw new Error("cancelled");
    if (j.need_confirm && (depth || 0) < 4) {
      if (tick) tick(false);
      if ((await confirmDlg(srvT(j.what) || tl("pjx.goAsk"), srvT(j.go), undefined, true)) !== "ok") throw new Error("cancelled");
      return act(path, Object.assign({}, body, {confirm: Number(j.need_confirm) || 1}), (depth || 0) + 1, tick);
    }
    return j;
  }
  const infoDlg = (msg) => ask(`<div class="cf"><h3>${esc(msg)}</h3><div class="acts cf-acts"><button class="pj-btn light full press" data-v="ok">${tl("pjx.ok")}</button></div></div>`);
  // A GET that may need consent; returns the {need_consent, declined} body if declined.
  const readOrAsk = (path) => loopFetch(path);

  // ---- routing + per-screen state ---------------------------------------------------------------
  function where() {
    let raw = location.hash.slice(1); try { raw = decodeURIComponent(raw); } catch (e) {}
    const seg = raw.split("/");
    return {name: seg[1] || "", sid: seg[2] || ""};
  }
  const deptMore = new Set();                          // projects whose fold of older sessions is unfolded (the list, beside the chat)
  let gen = 0, tab = "conv", listOpen = false, showTidied = "", showPast = false, showOld = false, lastSid = "";
  const timers = new Set();
  const convs = {};                                   // sid -> {entries, offset, results, queued, draft, pend, state}
  const aborts = new Set();                          // open long-polls, cut when the page changes
  // A chat's own loops (start) belong to the box it is drawn in: they go on while that box shows
  // that chat, across redraws of the page around it, and end when the box is gone or shows another.
  const runs = new Set();                            // {body, ac}
  // The box's loop ends. Only the loop: start() calls this for the box drawSession just wired,
  // and taking the press listener with it left every button in the chat dead (0.1.67).
  const endLoop = (body) => { const r = body && body._pjRun; if (!r) return; r.ac.abort(); runs.delete(r); body._pjRun = null; };
  // The box is about to show something else: its loop ends, and so does what a press in it did.
  const endRun = (body) => {
    if (body && body._pjClick) { body.removeEventListener("click", body._pjClick); body._pjClick = null; }
    endLoop(body);
  };
  const stop = (all) => { timers.forEach(clearTimeout); timers.clear(); aborts.forEach((a) => a.abort()); aborts.clear();
    runs.forEach((r) => { if (all || !r.body.isConnected || r.body._pjRun !== r) { r.ac.abort(); runs.delete(r); } }); };

  // ---- keep what is on screen -------------------------------------------------------------------
  // A redraw makes the page like its new html and keeps the nodes that are there: a row stays the
  // same element (its hover, its focus, the list's scroll), only what changed in it is written.
  // Rows are matched by their session, groups by their project, the rest by place and kind.
  // The list and the chat are drawn by their own code (MKEEP): only their attributes follow.
  const MKEEP = ".pj-rail,#pj-body";
  const mKey = (n) => n.nodeType !== 1 ? "" : n.dataset.sid ? "s:" + n.dataset.sid : n.dataset.g ? "g:" + n.dataset.g : n.dataset.grip ? "grip:" + n.dataset.grip
    : n.id ? "#" + n.id : n.classList.contains("pj-rail") ? "rail" : n.classList.contains("pj-cols") ? "cols" : "";
  const mBar = (n) => n.nodeType === 1 && n.classList.contains("pj-rbar");   // put there by readBar, not by the html
  function mPool(root) {
    const pool = new Map();
    const walk = (n) => [...n.children].forEach((c) => { const k = mKey(c); if (k && !pool.has(k)) pool.set(k, c); if (!c.matches(MKEEP) && !c.nodeName.includes("-")) walk(c); });
    walk(root); return pool;
  }
  // Move a node without losing what it holds: its scroll positions, and (moveBefore) its hover and animations.
  function mMove(parent, n, before) {
    if (n.parentNode === parent && n.nextSibling === before) return;
    if (parent.moveBefore && n.isConnected && parent.isConnected) { try { parent.moveBefore(n, before); return; } catch (e) { /* not movable that way */ } }
    const sc = n.nodeType === 1 ? [...n.querySelectorAll(".pj-msgs")].map((m) => [m, m.scrollTop]) : [];
    parent.insertBefore(n, before);
    sc.forEach(([m, y]) => { m.scrollTop = y; });
  }
  const mData = (n) => [...n.attributes].map((x) => x.name).filter((x) => x.startsWith("data-")).join();
  function morph(a, b, pool) {
    const own = a.classList.contains("pj-cols");     // its classes and widths are set while the page settles
    if (mData(a) !== mData(b)) a.onclick = a.onkeydown = a.oninput = null;   // another button now: its old press is not kept
    [...a.attributes].forEach((x) => { if (!b.hasAttribute(x.name) && !(own && (x.name === "style" || x.name === "class"))) a.removeAttribute(x.name); });
    [...b.attributes].forEach((x) => { if (own && (x.name === "style" || x.name === "class")) return; if (a.getAttribute(x.name) !== x.value) a.setAttribute(x.name, x.value); });
    if (a.matches(MKEEP) || a.nodeName.includes("-")) return;
    morphKids(a, b, pool);
  }
  // keep:begin
  // The longest run of kept children that are already in their new order: these never move, the
  // others are carried to their place (one row that changed its place moves alone).
  function mStay(ms, olds) {
    const at = new Map(olds.map((n, i) => [n, i])), seq = ms.filter((m) => m && at.has(m)), tails = [], prev = [];
    seq.forEach((m, j) => {
      const v = at.get(m); let lo = 0, hi = tails.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (at.get(seq[tails[mid]]) < v) lo = mid + 1; else hi = mid; }
      prev[j] = lo ? tails[lo - 1] : -1; tails[lo] = j;
    });
    const stay = new Set();
    for (let j = tails.length ? tails[tails.length - 1] : -1; j >= 0; j = prev[j]) stay.add(seq[j]);
    return stay;
  }
  // keep:end
  function morphKids(a, b, pool) {
    const olds = [...a.childNodes], used = new Set(), news = [...b.childNodes]; let i = 0;
    const cur = () => { while (i < olds.length && (olds[i].parentNode !== a || used.has(olds[i]) || mBar(olds[i]))) i++; return olds[i] || null; };
    const fit = (x, y) => x.nodeType === y.nodeType && x.nodeName === y.nodeName && (x.nodeType !== 1 || (!mKey(x) && (x.classList[0] || "") === (y.classList[0] || "")));
    const ms = news.map((nb) => { const k = mKey(nb); if (!k) return null; let m = pool.get(k) || null; if (m && m.nodeName !== nb.nodeName) m = null; if (m) pool.delete(k); return m; });
    const stay = mStay(ms.filter((m) => m && m.parentNode === a), olds);
    news.forEach((nb, j) => {
      let at = cur(), m = ms[j];
      if (m && stay.has(m)) while (at && at !== m) { i++; at = cur(); }      // what stood before it goes later, or goes away
      if (!m && !mKey(nb) && at) {
        if (fit(at, nb)) m = at;
        else if (nb.nodeType === 1 && nb.classList.length) {
          // Something left from before it (a row of chips that is gone): the box that is still wanted is further on.
          const o = olds.slice(i + 1).find((x) => x.parentNode === a && !used.has(x) && !mBar(x) && x.nodeType === 1 && fit(x, nb));
          if (o) { while (at && at !== o) { i++; at = cur(); } m = o; }
        }
      }
      if (!m) {
        // A new box around rows that are on screen: the box is new, the rows in it are the same ones.
        if (nb.nodeType === 1 && !mKey(nb) && !nb.matches(MKEEP) && !nb.nodeName.includes("-") && nb.querySelector("[data-sid],[data-g]")) {
          const sh = nb.cloneNode(false); a.insertBefore(sh, at); return void morphKids(sh, nb, pool);
        }
        return void a.insertBefore(nb, at);
      }
      used.add(m);
      if (m !== at) mMove(a, m, at);
      if (nb.nodeType === 1) morph(m, nb, pool); else if (m.nodeValue !== nb.nodeValue) m.nodeValue = nb.nodeValue;
    });
    olds.forEach((n) => { if (n.parentNode === a && !used.has(n) && !mBar(n)) a.removeChild(n); });
  }
  stop.sweep = () => runs.forEach((r) => { if (!r.body.isConnected || r.body._pjRun !== r) { r.ac.abort(); runs.delete(r); } });
  const morphTo = (root, html) => { const t = root.cloneNode(false); t.innerHTML = html; morphKids(root, t, mPool(root)); };
  // An embedded pane (pjEmbed, the item screen's chat tab) lives as long as its element does.
  const live = (my) => my && my.embed ? my.embed.isConnected : my === gen && location.hash.startsWith("#project");

  async function draw(el) {
    if (el && el._pjEmbed) return el._pjEmbed();      // an embedded pane redraws itself, not the room screen
    if (ORD && ORD.live()) return ORD.later(() => draw(el));   // a row is in the hand: the list waits for it to land
    if (SW && SW.live()) return SW.later(() => draw(el));      // so does a row or a chat pulled sideways (web/swipe.js)
    ensureCss(); stop();
    if (!el.classList.contains("pj") || !el.querySelector(".pj-cols")) shownCur = null;   // side by side: set again once a chat is drawn
    const my = ++gen, {name, sid} = where();
    if (lastSid && lastSid !== sid && convs[lastSid]) convs[lastSid].divTs = undefined;   // next visit re-reads the marker
    lastSid = sid;
    // Scope our padding/overflow to a wrapper: #view is shared with every other screen.
    if (!el.classList.contains("pj")) { const w = document.createElement("div"); w.className = "pj"; el.appendChild(w); el = w; }
    if (!name || name === ALL) return drawPick(el, my, name === ALL);
    // A phone shows one chat at a time: a side-by-side address opens its first project alone.
    if (name === MULTI && phoneList()) return location.replace("#project/" + enc(sid.split(",")[0] || ""));
    if (name === MULTI) return drawMulti(el, sid.split(","), my);
    listAt = false;
    return drawProject(el, name, sid, my);
  }

  // ---- #project: pick a department (M13: the hub's room list) ---------------------------------
  // The pick screen is the hub's room list: every department with its current session (its pin,
  // else a live one, else the newest), the last line said, and how many replies are unread.
  let topPins = new Set();
  const topPinned = (s) => topPins.has(s.id || s.sid);
  const topOrder = (list) => list.slice().sort((a, b) => Number(topPinned(b)) - Number(topPinned(a)));
  let roomsCache = null, roomQ = "", bgOpen = false, mFocus = 0;
  let roomsSeen = null, bundSeen = [], groupsSeen = [];               // the last list we showed: painted first, then refreshed
  // Panels folded by the person (wide screens), kept on this device.
  // Without the three columns (threeCols()) there are none to fold: the same two choices are the session list toggle
  // ("list", stored when open) and the 대화 / 결과물 tab ("tab", stored when on 결과물).
  // dense = the list in one-line rows, rdense = the results as small rows. side starts folded: it is
  // open only once the person opened it ("0"), so its key is written both ways.
  const FOLD = {rail: "rl-pj-rail", side: "rl-pj-side", list: "rl-pj-list", tab: "rl-pj-tab", dense: "rl-pj-dense", rdense: "rl-pj-rdense", more: "rl-pj-more"};
  // `dense` (one-line rows in the chat list) is on until 크게 is chosen; `side` likewise until it is opened.
  const folded = (k) => { const dflt = k === "side"; try { const v = localStorage.getItem(FOLD[k]); return dflt ? v !== "0" : v === "1"; } catch (e) { return dflt; } };
  const setFold = (k, on) => { try { on ? localStorage.setItem(FOLD[k], "1") : k === "side" ? localStorage.setItem(FOLD[k], "0") : localStorage.removeItem(FOLD[k]); } catch (e) { /* this visit only */ } };
  // A result not looked at yet = its item still carries the app's own 새 버전 mark (D.items[].new,
  // cleared by opening the item: /api/seen), unless this session's results were already looked
  // through here with the panel open. That second half is kept on this device, per session:
  // {sid: {"project/item": version seen in the panel}}, the 60 sessions used last.
  const RSEEN = "rl-pj-rseen", rkey = (r) => r.project + "/" + r.item;
  const rseen = () => { try { return JSON.parse(localStorage.getItem(RSEEN) || "{}") || {}; } catch (e) { return {}; } };
  const unseenRes = (sid, res) => { const m = rseen()[sid] || {};
    return res.filter((r) => { let it = null; try { it = (D.items || []).find((x) => iid(x) === rkey(r)); } catch (e) { /* items not loaded yet */ }
      return !!(it && it.new) && m[rkey(r)] !== r.v; }).length; };
  const seeRes = (sid, res) => { try { const all = rseen(), m = {}; res.forEach((r) => { m[rkey(r)] = r.v; });
    delete all[sid]; all[sid] = m; const ks = Object.keys(all); while (ks.length > 60) delete all[ks.shift()];
    localStorage.setItem(RSEEN, JSON.stringify(all)); } catch (e) { /* this visit only */ } };
  listOpen = folded("list");
  const MULTI = "~multi", MAXP = 6, ALL = "~all", NEW = "~new";
  // The pick list's address: on a wide window #project itself opens the most recent room.
  const listHash = () => wide() ? "project/" + ALL : "project";
  // What the room list left out: ended sessions this app did not open. `only` counts the ones in
  // folders that hold nothing else (those folders are not listed); oldRooms is those folders, read
  // when the fold is opened.
  let oldInfo = {only: 0}, oldRooms = null, roomsAt = 0;
  let seenAt = "";                                    // the chat last drawn (project/session)
  const turnHeld = new Set();                         // rows the 내 차례 tab keeps while it is open
  let sessQ = "", sessF = "all";                      // the list's search words and filter (all | turn | busy)
  // Claude | Codex: which tool's sessions the list shows (all | claude | codex). Kept on this device.
  const AG_KEY = "rl-pj-agent", AGS = ["all", "claude", "codex"];
  let sessA = (() => { try { const v = localStorage.getItem(AG_KEY); return AGS.includes(v) ? v : "all"; } catch (e) { return "all"; } })();
  const setAgent = (v) => { sessA = AGS.includes(v) ? v : "all"; try { localStorage.setItem(AG_KEY, sessA); } catch (e) { /* this visit only */ } };
  // How the list beside the chat is laid out, kept on this device: "flat" = every session by its
  // title, newest first (what a device that never chose gets); "folder" = sessions under their
  // project. A device whose storage is closed keeps the choice for this visit.
  const VIEW_KEY = "rl-pj-view", GFOLD_KEY = "rl-pj-gfold";
  let viewNow = "", gfoldNow = null;
  const dupOpen = new Set();                           // lead rows (by key) whose same-titled older sessions are unfolded
  let dupSids = [];                                  // older sessions sharing a title with a newer one, as the list last drew them
  // A row's sid -> the older same-titled sessions standing folded behind it, as the list last drew
  // them. Hiding the row hides these too: left behind, the next one came up under the same title
  // and the row looked as if it had never gone.
  let dupUnder = new Map();
  const withTwins = (sids) => [...new Set([].concat(...sids.map((id) => [id].concat(dupUnder.get(id) || []))))];
  const byRecent = () => { try { return localStorage.getItem("loop.sess.recent") === "1"; } catch (e) { return false; } };
  const setRecent = (on) => { try { localStorage.setItem("loop.sess.recent", on ? "1" : "0"); } catch (e) { /* this visit only */ } };
  const listView = () => { if (viewNow) return viewNow; try { return localStorage.getItem(VIEW_KEY) === "folder" ? "folder" : "flat"; } catch (e) { return "flat"; } };
  const setView = (v) => { viewNow = v === "folder" ? "folder" : "flat"; try { localStorage.setItem(VIEW_KEY, viewNow); } catch (e) { /* this visit only */ } };
  // The projects folded shut in 폴더별 (by name).
  const gfold = () => { if (!gfoldNow) { try { gfoldNow = new Set(JSON.parse(localStorage.getItem(GFOLD_KEY) || "[]")); } catch (e) { gfoldNow = new Set(); } } return gfoldNow; };
  const setGfold = (name, shut) => { const g = gfold(); shut ? g.add(name) : g.delete(name); try { localStorage.setItem(GFOLD_KEY, JSON.stringify([...g].slice(-200))); } catch (e) { /* this visit only */ } };
  const railPops = {};                                // the header's open menus, by name
  const railRows = new Map();                         // session id -> {s, name}: what a row's menu acts on
  let ctxAt = null;                                   // {x, y, row, kb, label}: the next menu opens at this point (popAt takes it)
  // The list's order (web/listorder.js): what the person placed, kept on the server for the PC and
  // the phone alike. `ordKeys` is every key of each list as last drawn, shown or folded away.
  const ORD = window.PjOrder;
  const SW = window.PjSwipe;                          // a phone's sideways gestures (web/swipe.js)
  let listOrd = {depts: [], sess: {}, flat: []}, ordSaving = 0, ordAt = -1, railNow = null;
  const ordKeys = {depts: [], sess: {}, flat: []};
  // A phone has one list: every session. Until the person has placed one by hand (a long press, then
  // carrying it, the same order the desktop keeps: listOrd.flat) the one that last had something
  // happen is on top; from then on the list is fixed like the desktop's, what is made later stacking
  // on top. The 폴더별 / 크게 choices (the desktop's, kept as saved) are not offered. While a finger
  // is on the screen or the list is still scrolling, and for a second after, the order shown stands;
  // it is caught up afterwards.
  const phoneList = () => innerWidth < 1024 && matchMedia("(pointer:coarse)").matches;
  let phoneOrd = null, phoneTouch = false, phoneAt = -1e9, phoneT = 0;
  const phoneHeld = () => phoneTouch || performance.now() - phoneAt < 1000;
  const phoneLater = () => { clearTimeout(phoneT); phoneT = setTimeout(() => { if (phoneHeld()) return phoneLater(); if (railNow && phoneList()) railNow(); }, 1050); };
  addEventListener("touchstart", () => { phoneTouch = true; }, {capture: true, passive: true});
  ["touchend", "touchcancel"].forEach((t) => addEventListener(t, (e) => { phoneTouch = e.touches.length > 0; phoneAt = performance.now(); }, {capture: true, passive: true}));
  addEventListener("scroll", () => { phoneAt = performance.now(); }, {capture: true, passive: true});
  function phoneOrder(L, keyOf) {
    const at = (o) => String(o.at || o.born || "");
    const fresh = L.slice().sort((a, b) => !!b.draft - !!a.draft || at(b).localeCompare(at(a)));
    if (!phoneOrd || !phoneHeld()) { phoneOrd = fresh.map(keyOf); return fresh; }
    const was = new Map(phoneOrd.map((k, i) => [k, i])), i = (o) => was.has(keyOf(o)) ? was.get(keyOf(o)) : -1;
    const out = fresh.sort((a, b) => i(a) - i(b));
    if (out.some((o, j) => keyOf(o) !== phoneOrd[j])) phoneOrd = out.map(keyOf);
    phoneLater();
    return out;
  }
  const ordPlaced = () => listOrd.depts.length + listOrd.flat.length + Object.keys(listOrd.sess).length > 0;
  function ordSave(order) {
    ordSaving++;
    post("/api/project/order", {order}).then((r) => { if (ordSaving === 1 && r && r.order) listOrd = r.order; })
      .catch((e) => toast(e.message)).finally(() => { ordSaving--; ordAt = performance.now(); });
  }
  // The order a list read brought is taken unless it was asked for before the last save had
  // landed: that answer still holds the order from before the drop and put the row back.
  const ordFresh = (t0) => !ordSaving && t0 > ordAt;
  // The rows that can trade places with `row`: the sessions of its project (폴더별), every session
  // (세션), or the projects themselves for a project's name and a project shown as one row.
  function ordUnits(row) {
    const box = row.closest(".pj-rail"), rows = box && box.querySelector(".pj-srows");
    // Not the rows that stand outside the order: the old ones, the open one shown apart, and a
    // same-titled twin unfolded under its newest (it always stands right under it).
    if (!rows || !rows.contains(row) || row.closest(".pj-olds,.pj-apart") || row.classList.contains("tw")) return null;
    const grp = row.closest(".pj-sgrp"), sess = row.matches(".pj-srow[data-sid]");
    // Pinned sessions are held on top (topOrder), so a row trades places on its own side of the
    // pins only (PjOrder.peers); with newest-first on nothing is held, and placing a row ends it (ordCommit).
    const side = (L) => { const us = L.filter((u) => !u.closest(".pj-olds,.pj-apart") && !u.classList.contains("tw")); if (byRecent()) return us;
      const ks = new Set(ORD.peers(us.map((u) => u.dataset.sid), row.dataset.sid, (k) => topPins.has(k))); return us.filter((u) => ks.has(u.dataset.sid)); };
    if (!grp) return sess ? {box, unit: row, units: side([...rows.querySelectorAll(".pj-srow[data-sid]")]), scope: "flat", key: (u) => u.dataset.sid} : null;
    if (sess && grp.querySelector(".pj-sgl")) return {box, unit: row, units: side([...grp.querySelectorAll(".pj-srow[data-sid]")]), scope: "sess", name: row.dataset.pn, key: (u) => u.dataset.sid};
    return grp.dataset.g ? {box, unit: grp, units: [...rows.querySelectorAll(".pj-sgrp[data-g]")], scope: "depts", key: (u) => u.dataset.g} : null;
  }
  // The unit at `from` now stands where the one at `to` stood: said relative to that neighbour, so
  // rows folded away or filtered out keep their places around it.
  // The picked rows that go with `u.unit` when it is in the hand (it is one of them; two or more
  // sessions of this list), else none. A project's name carries no picked rows.
  function ordMany(u) {
    if (!u || !pickOn || u.scope === "depts" || !picked.has(u.key(u.unit))) return [];
    const g = u.units.filter((x) => picked.has(u.key(x)));
    return g.length > 1 && u.units.length > g.length ? g : [];
  }
  function ordCommit(u, from, to) {
    // Newest-first lets the clock order the rows, so a row put somewhere went straight back. Placing
    // one by hand ends it: the list is kept as it stood on the screen, with the row where it was put.
    if (byRecent()) {
      listOrd = u.scope === "flat" ? Object.assign({}, listOrd, {flat: ordKeys.flat.slice()}) : Object.assign({}, listOrd, {depts: ordKeys.depts.slice(), sess: Object.assign({}, ordKeys.sess)});
      setRecent(false); toast(tl("ord.fixedNow"));
    }
    const keys = u.units.map(u.key), full = u.scope === "sess" ? ordKeys.sess[u.name] || keys : ordKeys[u.scope];
    // Picked rows move together: the grabbed one lands where it would have alone, the others follow it.
    const base = full.length ? full : u.every || keys;
    const ri = base.indexOf(keys[to]);
    const next = u.many ? (ri < 0 ? base.slice() : ORD.movedMany(base, u.many, ri + (to > from ? 1 : 0)))
      : ORD.moved(base, keys[from], keys[to], to > from);
    if (u.scope === "sess") listOrd = Object.assign({}, listOrd, {sess: Object.assign({}, listOrd.sess, {[u.name]: next})});
    else listOrd = Object.assign({}, listOrd, {[u.scope]: next});
    ordSave(listOrd);
    if (!RM()) u.box._ms = "";                        // already where it landed: nothing to carry there
    if (railNow && u.box.isConnected) railNow();
  }
  // 한 번 정렬: the list is put in that order once and kept as the person's own order. It is not
  // a mode: nothing sorts again afterwards, and what is made later still lands on top.
  let ordLast = null;                                 // {list, groups, every}: the rows of the last drawn list
  function ordOnce(kind) {
    const L = ordLast; if (!L || phoneList()) return false;
    const txt = (a, b) => String(a).localeCompare(String(b), "ko"), late = (a, b) => String(b.at || "").localeCompare(String(a.at || ""));
    const ids = (rows) => rows.filter((o) => o.sid).sort(kind === "name" ? (a, b) => txt(a.t, b.t) : late).map((o) => o.sid);
    const sess = {}; L.groups.forEach((g) => { const k = ids(g.all); if (k.length) sess[g.r.name] = k; });
    // A project is as recent as its most recent session, not only the one it opens on.
    const gAt = new Map(L.groups.map((g) => [g.r.name, g.all.reduce((m, o) => String(o.at || "") > m ? String(o.at) : m, String(g.r.at || ""))]));
    listOrd = {depts: L.list.slice().sort(kind === "name" ? (a, b) => txt(pname(a.name), pname(b.name)) : (a, b) => (gAt.get(b.name) || "").localeCompare(gAt.get(a.name) || "")).map((r) => r.name), sess, flat: ids(L.every)};
    ordSave(listOrd);
    return true;
  }
  // 위로 이동 / 아래로 이동 from a menu: one place, among the rows on the screen.
  function ordStep(row, by) {
    const u = row && row.isConnected && ordUnits(row); if (!u) return;
    const i = u.units.indexOf(u.unit), j = i + by; if (i < 0 || j < 0 || j >= u.units.length) return;
    const k = u.key(u.unit), box = u.box;
    ordCommit(u, i, j);
    const n = [...box.querySelectorAll(u.scope === "depts" ? ".pj-sgrp[data-g]" : ".pj-srow[data-sid]")].find((x) => u.key(x) === k);
    const f = n && (n.matches(".pj-srow") ? n : n.querySelector(".pj-sgh,.pj-srow"));
    if (f) { f.focus({preventScroll: true}); f.scrollIntoView({block: "nearest"}); }
  }
  const ordItems = (row) => { const u = row && ordUnits(row); if (!u || u.units.length < 2) return "";
    const i = u.units.indexOf(u.unit), b = (d, off) => `<button data-mv="${d}"${off ? ` aria-disabled="true"` : ""}>${ic("chev", d < 0 ? "i up" : "i dn")}<span>${d < 0 ? tl("ord.up") : tl("ord.down")}</span></button>`;
    return b(-1, i <= 0) + b(1, i >= u.units.length - 1); };
  // 더 보기 in a row's menu: the rare choices unfold in place (a phone has no room for a second
  // menu beside the first), and the menu stays inside the window as it grows.
  const moreRow = (inner) => inner ? `<hr><button data-mx aria-expanded="false">${ic("more")}<span>${tl("mn.more")}</span>${ic("chev", "i cv")}</button><div class="mx" hidden>${inner}</div>` : "";
  const moreWire = (pop) => { const b = pop.querySelector("[data-mx]"), x = pop.querySelector(".mx"); if (!b) return;
    b.onclick = (e) => { e.stopPropagation(); const on = x.hidden; x.hidden = !on; b.setAttribute("aria-expanded", String(on));
      pop.style.top = Math.max(8, Math.min(parseFloat(pop.style.top) || 8, innerHeight - 8 - pop.offsetHeight)) + "px";
      if (on && b === document.activeElement) { const f = x.querySelector("button"); if (f) f.focus({preventScroll: true}); } }; };
  const ordWire = (pop, row) => pop.querySelectorAll("[data-mv]").forEach((b) => b.onclick = (e) => { e.stopPropagation();
    if (b.getAttribute("aria-disabled")) return; pop.remove(); ordStep(row, +b.dataset.mv); });
  const draftModel = {};                              // project -> {model, effort} picked for the session not opened yet
  const draftAgent = {};   // Claude or Codex picked on the new-session draft, per department
  const drafts = {};                                  // project -> what was typed for a session not opened yet
  // A new-session draft is only a screen (nothing exists on disk), so hiding one forgets what it
  // holds and takes its row out of the list; 새 세션 brings it back. An empty draft left by opening
  // another session is gone with the route, so none piles up. `dropDraft` returns what to restore.
  // draft-hide:begin
  const draftGone = new Set();
  function dropDraft(name) {
    const was = {text: drafts[name], agent: draftAgent[name], m: draftModel[name], mc: draftModel["codex\n" + name]};
    delete drafts[name]; delete draftAgent[name]; delete draftModel[name]; delete draftModel["codex\n" + name];
    draftGone.add(name);
    return was;
  }
  function backDraft(name, was) {
    draftGone.delete(name);
    if (was.text) drafts[name] = was.text;
    if (was.agent) draftAgent[name] = was.agent;
    if (was.m) draftModel[name] = was.m;
    if (was.mc) draftModel["codex\n" + name] = was.mc;
  }
  // Which rows the list holds comes from the data and the filter only, never from which row is open:
  // a hidden session is listed only while 숨긴 세션 is on. One that is open anyway (opened from a link)
  // is shown apart (openApart), so opening a row never adds or removes a row.
  const listed = (s, showAll) => showAll || !s.tidied;
  // The hidden sessions are shown only in the project they were opened in, and only until the
  // next hide: kept on across projects, sessions put away came back everywhere.
  const tidOn = () => !!showTidied && showTidied === where().name;
  // draft-hide:end
  // Search that forgives how a name was typed: case, spaces / _ / -, and the look-alikes O-0 and
  // l-I-1 ("A20" finds "A2O"). Used by the room list and the 새 대화 picker alike.
  const foldQ = (s) => String(s || "").toLowerCase().replace(/[\s_\-]+/g, "").replace(/o/g, "0").replace(/[li|]/g, "1");
  // Both names find it: the one the screens show and the one the register keeps (a group too).
  const hay = (r) => foldQ(r.name + " " + pname(r.name) + " " + String(r.folder || "").split(/[\\/]/).slice(-2).join(" ") + " " + (r.group || "") + " " + gpname(r.group || ""));
  // One glyph per project. A joined emoji this machine cannot join draws as two or three side by
  // side and pushes the name out of line, so that one falls back to its first part (measured once).
  const emSeen = {};
  let emCtx = null;
  function em1(e) {
    e = String(e || "");
    if (e.indexOf("‍") < 0) return e;
    if (!(e in emSeen)) {
      emSeen[e] = e;
      try {
        emCtx = emCtx || document.createElement("canvas").getContext("2d");
        emCtx.font = "18px " + getComputedStyle(document.body).fontFamily;
        if (emCtx.measureText(e).width > emCtx.measureText("\u{1F642}").width * 1.4) emSeen[e] = e.split("‍")[0];
      } catch (x) { /* no canvas: leave it as written */ }
    }
    return emSeen[e];
  }
  // c: the colour the person picked for it (a soft tile behind the picture); none, as before.
  // i: an icon in a style other than emoji ("duotone/rocket", web/icons.js), drawn in place of
  // the emoji; a build or a device that does not know the icon shows the emoji, as before.
  const icoHtml = (i) => (i && window.LOOP_ICONS && window.LOOP_ICONS.html(i)) || "";
  // A project's face beside a title (a list row, a pane's head): the styled icon or the emoji at
  // text size, no tile behind it. Nothing when the project has neither. Bold and fill carry more
  // ink than the title beside them, so they are drawn a little smaller (`hv`).
  const faceMk = (e, c, i) => { const h = icoHtml(i); return h || e ? `<span class="pj-face${h ? " ph" + (/^(bold|fill)\//.test(i) ? " hv" : "") : ""}${tintAttr(c) ? " tint" : ""}"${tintAttr(c)} aria-hidden="true">${h || esc(em1(e))}</span>` : ""; };
  // The title beside a face: the emoji the title opens with is not said twice (web/emoji.js bare).
  // `face`: a face is drawn there. Labels, tooltips and the search keep the name as it is.
  const unEm = (t, face) => face && window.LOOP_EMOJI && window.LOOP_EMOJI.bare ? window.LOOP_EMOJI.bare(t) : t;
  const emAs = (cls, e, c, i) => { const h = icoHtml(i); return `<span class="${cls}${h ? " ph" : ""}${tintAttr(c) ? " tint" : ""}"${tintAttr(c)}>${h || esc(em1(e))}</span>`; };
  const em = (e, c, i) => emAs("pj-em", e, c, i);
  // The same on a picture that is already on the page.
  const emPut = (el, e, c, i) => { const h = icoHtml(i); if (h) el.innerHTML = h; else el.textContent = em1(e); el.classList.toggle("ph", !!h); el.classList.toggle("tint", !!c); el.style.setProperty("--em-c", c || "transparent"); };
  const icoOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).icon || (D.ident && D.ident[name] && D.ident[name].icon) || "";
  const colOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).color || "";
  const emoOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).emoji || (D.ident && D.ident[name] && D.ident[name].emoji) || "";
  // "받는 곳": which project, which conversation, which agent gets what is about to be sent.
  // `conv` is the conversation's title (or what will be opened); `n` > 1 names several at once.
  const toLine = (o) => `<span class="k">${esc(tl("room.to"))}</span>` + (o.n > 1
    ? `<b>${esc(tl("room.toN", {n: o.n}))}</b><span class="s">${esc(o.names.map(pname).join(", "))}</span>`
    : `${o.emoji ? em(o.emoji, "", icoOf(o.name)) : ""}<b>${esc(unEm(pname(o.name), o.emoji))}</b>${o.conv ? `<span class="s">· ${esc(unEm(o.conv, o.emoji))}</span>` : ""}`) + (o.agent ? agentTag(o.agent) : "");
  // An agent that is not connected here: its conversations are not listed (the server sends only
  // how many there are). One quiet row per agent says so and leads to 설정 › 연결.
  let unlinkedSeen = [];
  const unlinkRows = () => unlinkedSeen.map((u) => `<div class="pj-unl"><span>${esc(tl("room.unlinked", {agent: u.agent === "codex" ? "Codex" : "Claude Code", n: u.count}))}</span><button class="pj-text press" data-golink>${tl("room.unlinkedGo")}</button></div>`).join("");
  document.addEventListener("click", (e) => { if (e.target.closest?.("[data-golink]")) { setPage = "connect"; setShowPage = true; location.hash = "#settings"; } });
  // row-sync:begin
  // One state per conversation. The chat's header asks the server every few seconds; the list
  // was only read when the page was drawn, so a conversation that had ended in the header went
  // on as "작업 중" in its row (and in the 작업 중 count) for as long as the box was being typed
  // in. What the server last said about a session is written onto its row here, wherever the
  // row is: the open project's sessions and the other projects' rows. True when a row changed.
  // `turn` is one of them: left out, a row of the open project kept the my-turn mark it had when
  // the page was drawn for as long as the box was typed in, though the session had long gone on.
  const ROW_KEYS = ["state", "busy", "last", "title", "unread", "turn"];
  function syncRow(all, rooms, id, st) {
    if (!id || !st || !st.state) return false;
    let ch = false;
    const s = (all || []).find((x) => x.id === id);
    if (s) {
      ROW_KEYS.forEach((k) => { if (k in st && s[k] !== st[k]) { s[k] = st[k]; if (k !== "busy") ch = true; } });
      if (!!s.cut !== !!st.cut) { s.cut = !!st.cut; ch = true; }
    }
    (rooms || []).forEach((r) => {
      if (r.sid === id && r.state !== st.state) { r.state = st.state; ch = true; }
      if (r.sid === id && "turn" in st && !!r.turn !== !!st.turn) { r.turn = !!st.turn; ch = true; }
      (r.more || []).forEach((m) => { if (m.sid === id && m.state !== st.state) { m.state = st.state; ch = true; }
        if (m.sid === id && "turn" in st && !!m.turn !== !!st.turn) { m.turn = !!st.turn; ch = true; } });
    });
    return ch;
  }
  // A session the person has just answered is not theirs to answer, whatever the list last heard:
  // the rows are read every few seconds and the session takes a moment to take the line up, so the
  // row left behind turned orange again. It counts as answered until the session does something
  // after the answer (`at`, its last activity, is newer than `sent`), and for ANS_MS at most.
  const ANS_MS = 10 * 60000;
  const answered = (sent, at, now) => { if (!sent || now < sent || now - sent > ANS_MS) return false;
    const t = at ? Date.parse(at) : NaN; return !(isFinite(t) && t > sent); };
  // A line sent to Codex that its record never took, with nothing running any more: not "보냄".
  const LOST_MS = 15000;
  const lostLine = (p, st, now) => !!(p && !p.busy && !p.failed && p.sentAt && st && st.found !== false && !st.busy && now - p.sentAt > LOST_MS);
  // row-sync:end
  let rowSync = null, listTimer = 0;
  // When each session was last answered from here ({sid: ms}), kept on this device so a reload
  // does not bring the my-turn mark back. PjAnswered is the same question for the other screens.
  const ANS_KEY = "rl-pj-answered";
  let ansAt = (() => { try { return JSON.parse(localStorage.getItem(ANS_KEY) || "{}") || {}; } catch (e) { return {}; } })();
  const isAnswered = (sid, at) => answered(ansAt[sid], at, Date.now());
  window.PjAnswered = isAnswered;
  // `on` false: the answer did not get through, so it is the person's turn as before.
  function ansMark(sid, on) {
    const now = Date.now(); Object.keys(ansAt).forEach((k) => { if (now - ansAt[k] > ANS_MS) delete ansAt[k]; });
    if (on) ansAt[sid] = now; else delete ansAt[sid];
    try { localStorage.setItem(ANS_KEY, JSON.stringify(ansAt)); } catch (e) { /* storage off: this visit only */ }
    if (on && typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.turn = false; });
    if (typeof drawChrome === "function") drawChrome();
    if (railNow) railNow();
  }
  const LIST_EVERY = 10000;
  // The room list read quietly (no dialog): the timer below must never put a question up.
  async function quietRooms() {
    const t0 = performance.now(), r = await get("/api/project/rooms");
    if (r && r.rooms && !r.declined && !r.need_consent) { topPins = new Set(r.top_pins || []); roomsSeen = roomsCache = r.rooms; groupsSeen = r.groups || []; oldInfo = {only: r.old_only || 0}; unlinkedSeen = r.unlinked || []; roomsAt = Date.now();
      if (r.order && ordFresh(t0)) listOrd = r.order; }
  }
  async function loadRooms() {
    const t0 = performance.now(), r = await readOrAsk("/api/project/rooms");
    if (!r.declined) { topPins = new Set(r.top_pins || []); roomsSeen = roomsCache = r.rooms || []; groupsSeen = r.groups || []; oldInfo = {only: r.old_only || 0}; unlinkedSeen = r.unlinked || []; roomsAt = Date.now();
      if (r.order && ordFresh(t0)) listOrd = r.order; }
    return r;
  }
  const loadOld = () => get("/api/project/rooms?old=1").then((r) => {
    const have = new Set((roomsCache || roomsSeen || []).map((x) => x.name));
    oldRooms = (r.rooms || []).filter((x) => !have.has(x.name));
  }).catch(() => { oldRooms = []; });
  const bundlesOf = () => get("/api/room-bundles").then((b) => b.bundles || []).catch(() => []);
  const goMulti = (ids) => nav("project/" + MULTI + "/" + ids.map(enc).join(","));

  function roomCard(r, cls) {
    const st = r.state || "ended";
    const said = r.sid ? (r.who === "user" ? `<b>${tl("room.me")}</b> ` : "") + esc(Redact.show(flat1(unnote(r.last))) || tl("room.noLine")) : esc((darkRoom(r) && backLine(r.back)) || tl("room.noSession"));
    return `<button class="pj-card press${cls ? " " + cls : ""}" data-p="${esc(r.name)}"${cls === "cur" ? ` aria-current="true"` : ""}>
      <div class="r1">${em(r.emoji, r.color, r.icon)}<div class="t">${esc(unEm(pname(r.name), r.emoji || icoHtml(r.icon)))}</div>
        ${r.unread ? `<span class="pj-badge" aria-label="${esc(tl("room.unread", {n: r.unread}))}">${r.unread > 99 ? "99+" : r.unread}</span>` : ""}</div>
      <div class="pj-last">${said}</div>
      <div class="r2">${r.sid ? mark(st, r.at) : ""}${agentTag(r.agent)}${r.pinned ? `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>` : ""}${r.copies ? `<span>${esc(tl("room.copies", {n: r.copies}))}</span>` : ""}${ctxRow(r.context)}<span class="sp"></span>${darkRoom(r) ? onBtnHtml(r.name, "span") : `<span>${r.at ? ago(r.at) : ""}</span>`}</div></button>`;
  }
  // 켜기 on a card: it is a button inside the card's own, so the press stays with it.
  const wireOn = (box, redraw) => box.querySelectorAll(".pj-card [data-on]").forEach((b) => {
    const go = (e) => { e.preventDefault(); e.stopPropagation(); if (b.getAttribute("aria-disabled") !== "true") askOn(b, b.dataset.on, redraw); };
    b.onclick = go; b.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") go(e); };
  });

  async function drawPick(el, my, all) {
    // A wide window does not stop at the list: the most recent conversation opens with the list
    // beside it, ready to type in. The list alone is #project/~all (and every narrow window).
    // Which one: the conversation that was open last in this run of the app, else the row the list
    // shows first as it is sorted and narrowed now (it used to be the newest project's own session,
    // which in 세션 view is not the top row, and could be one that ended long ago).
    const jump = (list) => {
      // A phone does the same with its one pane: 대화 is the list of every session (the same list,
      // as a page), with the chat last looked at under it; a row opens its chat over the list.
      if (!all && phoneList()) { const r = list.find((x) => x.sid && x.name === lastChat.name) || list.find((x) => x.sid); if (!r) return false;
        listAt = true; drawProject(el, r.name, r.name === lastChat.name ? lastChat.sid : "", my); return true; }
      if (all || !wide()) return false;
      const was = lastOpen && list.some((x) => x.name === lastOpen.name) ? lastOpen : null;
      const any = list.find((x) => x.sid);             // every row narrowed away: the first project, as before
      const r = was || topRow(list) || (any ? {name: any.name} : null);
      if (r) location.replace("#project/" + enc(r.name) + (r.sid ? "/" + enc(r.sid) : ""));
      return !!r;
    };
    if (roomsSeen && jump(roomsSeen)) return;
    // What we showed last time goes up at once (the list is the same nine times out of ten);
    // the fresh answer replaces it when it lands. Only the very first open waits, and says why.
    if (roomsSeen) pickPaint(el, {}, bundSeen, roomsSeen, true);
    else el.innerHTML = `${chatTabs("project")}${loadingHtml(tl("room.loading"), {fill: true})}`;
    let d, bund;
    try { [d, bund] = await Promise.all([loadRooms(), bundlesOf()]); }
    catch (e) { if (live(my)) { if (roomsSeen) toast(e.message); else el.innerHTML = `<div class="pj-empty">${esc(e.message)}</div>`; } return; }
    if (!live(my) || jump(roomsCache || [])) return;
    bundSeen = bund;
    const q = el.querySelector("[data-q]"), typing = q && document.activeElement === q, at = typing ? q.selectionStart : 0;
    pickPaint(el, d, bund, roomsCache || [], false);
    if (typing) { const n = el.querySelector("[data-q]"); if (n) { n.focus(); try { n.setSelectionRange(at, at); } catch (e) { /* not a text field */ } } }
  }
  // Write html into a part of the list only when it is not what stands there: the list is read
  // again on every refresh round, and rebuilding the same rows moved the page under the finger.
  // still:begin
  const put = (el, html) => { if (el._was === html && el.firstChild) return; el.innerHTML = html; el._was = html; };
  // still:end
  function pickPaint(el, d, bund, list, stale) {
    // A phone: newest first, and nothing that opens several chats side by side.
    const ph = phoneList();
    if (ph) { list = list.slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || ""))); bund = []; }
    const unread = list.reduce((n, r) => n + (r.unread || 0), 0);
    const shell = `${chatTabs("project")}<div class="pj-top">
        ${list.length > 6 ? `<input class="pj-search" type="search" data-q placeholder="${esc(tl("room.search"))}" aria-label="${esc(tl("room.search"))}" value="${esc(roomQ)}">` : `<span class="sp"></span>`}
        ${ph ? "" : `<button class="pj-text press" data-multi>${tl("room.multi")}</button>`}
        <button class="pj-text press" data-opt>${tl("room.newOpt")}</button>
        <button class="pj-text press" data-fixed>${tl("room.fixed.new")}</button>
        <button class="pj-btn light press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button></div>
      ${d.need_consent || d.declined ? `<div class="pj-empty">${tl("room.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("room.askAgain")}</button></div>` : ""}
      ${bund.length ? `<div class="pj-lab">${tl("room.bundles")}</div><div class="pj-chips">${bund.map((b, i) => `<button class="pj-chip press" data-bund="${i}">${esc(b.name)}<em>${b.ids.length}</em></button>`).join("")}</div>` : ""}
      <div class="pj-lab" data-rl></div>
      <div id="pj-rg"></div>
      <div id="pj-old"></div>${unlinkRows()}
      <button class="pj-fold press" data-bg aria-expanded="${bgOpen}">${ic("chev", "i")}<span>${tl("room.bg")}</span></button>
      <div id="pj-bgl"></div>`;
    if (el._was !== shell || !el.querySelector(":scope>#pj-rg")) { el.innerHTML = shell; el._was = shell; }
    // The count and the unread number change on their own; they are not a reason to build the page again.
    put(el.querySelector("[data-rl]"), `${tl("room.rooms")} <span class="n">${list.length}</span>${unread ? `<span class="pj-badge">${unread > 99 ? "99+" : unread}</span>` : ""}`);
    const rg = el.querySelector("#pj-rg");
    const grid = () => {
      const q = foldQ(roomQ);
      const shown = q ? list.filter((r) => (hay(r) + foldQ(r.last)).includes(q)) : list;
      put(rg, shown.length ? `<div class="pj-grid">${shown.map(roomCard).join("")}</div>`
        : `<div class="pj-empty">${list.length ? tl("room.noMatch") : tl("room.none")}</div>`);
      rg.querySelectorAll("[data-p]").forEach((b) => b.onclick = () => nav("project/" + enc(b.dataset.p)));
      wireOn(rg, () => { if (rg.isConnected) draw(el); });
    };
    grid();
    const q = el.querySelector("[data-q]");
    if (q) q.oninput = () => { roomQ = q.value; grid(); };
    // 새 세션 needs no first line and no choices: the most recent project's chat opens empty,
    // ready to type in. Everything else (another project, Codex, a model) is the sheet beside it.
    // A project whose folder is gone is never the one picked here; when that passes over the
    // one talked in last, the page says so.
    el.querySelector("[data-new]").onclick = () => {
      const d = newDefault(list); if (!d.room) return newChat();
      if (d.skipped) toast(tl("room.newLost", {was: pname(d.skipped.name), name: pname(d.room.name)}), 5000);
      nav("project/" + enc(d.room.name) + "/" + NEW);
    };
    el.querySelector("[data-opt]").onclick = () => newChat();
    el.querySelector("[data-fixed]").onclick = (e) => newStanding(e.currentTarget);
    drawOld(el.querySelector("#pj-old"));
    const mb = el.querySelector("[data-multi]");
    if (mb) mb.onclick = () => pickPanes([], goMulti);
    el.querySelectorAll("[data-bund]").forEach((b) => b.onclick = () => goMulti(bund[+b.dataset.bund].ids));
    const rt = el.querySelector("[data-retry]");
    if (rt) rt.onclick = () => draw(el);
    const bl = el.querySelector("#pj-bgl"), bf = el.querySelector("[data-bg]");
    bf.onclick = () => { bgOpen = !bgOpen; bf.setAttribute("aria-expanded", bgOpen); drawBg(bl); };
    if (!stale) drawBg(bl);
  }

  // Folders that hold only sessions made outside this app, all ended: one folded row under the
  // list, opened in place. Nothing is deleted; a session in them opens like any other.
  function drawOld(box) {
    if (!box) return;
    const n = oldInfo.only;
    put(box, n ? `<button class="pj-fold press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n})}</span></button>`
      + (showOld ? `<div class="pj-grid pj-olds pj-anim">${oldRooms ? oldRooms.map((r) => roomCard(r)).join("") : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`}</div>` : "") : "");
    const b = box.querySelector("[data-old]"); if (!b) return;
    b.onclick = () => { showOld = !showOld; if (showOld) oldRooms = null; drawOld(box); };
    box.querySelectorAll("[data-p]").forEach((c) => c.onclick = () => nav("project/" + enc(c.dataset.p)));
    if (showOld && !oldRooms) loadOld().then(() => { if (box.isConnected) drawOld(box); });
  }

  // Every session Claude Code keeps in the background, whatever department it belongs to.
  async function drawBg(box) {
    if (!bgOpen) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`;
    let d;
    try { d = await readOrAsk("/api/project/background"); } catch (e) { box.innerHTML = `<div class="pj-empty">${esc(e.message)}</div>`; return; }
    if (!box.isConnected) return;
    if (d.declined || d.need_consent) { box.innerHTML = ""; return; }
    const rows = d.rows || [];
    box.innerHTML = rows.length ? `<div class="pj-anim">${rows.map((r, i) => `<button class="pj-item press" data-bgi="${i}">
        ${em(r.emoji)}
        <span class="tx"><div class="t">${esc(pname(r.dept || "") || r.name || r.id || "")}</div><div class="s">${esc(r.name || "")}${r.id ? " · " + esc(r.id) : ""}${r.agent === "codex" ? " · Codex" : ""}</div></span>
        ${r.pinned ? `<span class="pj-pinmk">${ic("tack")}</span>` : ""}
        <span class="pj-tag ${r.busy ? "on" : ""}">${esc(r.busy ? tl("room.bgBusy") : tl("room.bgIdle"))}</span></button>`).join("")}</div>`
      : `<div class="pj-empty" style="text-align:left;padding:6px 2px">${tl("room.bgNone")}</div>`;
    box.querySelectorAll("[data-bgi]").forEach((b) => b.onclick = () => bgSheet(rows[+b.dataset.bgi], () => drawBg(box)));
  }
  async function bgSheet(r, again) {
    let log = "";
    if (r.id) {
      const l = await readOrAsk("/api/project/agent-log?id=" + enc(r.id)).catch((e) => ({error: e.message}));
      if (l.declined) return;
      log = l.text || l.error || "";
    }
    sheet(`<div class="pj-dlg"><h3>${esc(pname(r.dept || "") || r.name || "")}</h3>
      <pre class="pj-log">${esc(log || tl("room.bgNoScreen"))}</pre>
      ${r.id ? `<div class="pj-hint">${esc(tl("room.bgAttach"))} <code>claude attach ${esc(r.id)}</code></div>` : ""}
      <div class="acts">${r.sid && r.dept ? `<button class="pj-btn light full press" data-go>${tl("room.openChat")}</button>` : ""}
        <button class="pj-btn full press" data-stop>${tl("room.stop")}</button></div></div>`, (box) => {
      const g = box.querySelector("[data-go]");
      if (g) g.onclick = () => { closeSheet(); nav("project/" + enc(r.dept) + "/" + enc(r.sid)); };
      box.querySelector("[data-stop]").onclick = async () => {
        closeSheet();
        try {
          const x = r.agent === "codex" ? await act("/api/session/stop", {sid: r.sid}) : await act("/api/session/bg-stop", {id: r.id});
          toast(x.message || tl("room.stopped")); again();
        } catch (e) { if (e.message !== "cancelled") toast(e.message); }
      };
    });
  }

  // ---- 새 대화: department (search, recent first), Claude | Codex, keep | new, first line, model --
  // 새 대화: a card grid of every department, filed under the register's groups. One pick works as
  // before (open it and go there). Several get the same first line each, two at a time, and the
  // sheet stays to say how each one went; one that fails does not stop the others.
  async function newChat(preset) {
    ensureCss();                                        // opened from home (the first-use guide) before the chat page ever drew
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const rooms = (roomsCache || []).slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
    const by = {};
    rooms.forEach((r) => { by[r.name] = r; });
    // The first-use guide passes {text, mk, agent}: the first line and a new project's name, already filled in.
    const pre = preset && typeof preset === "object" ? preset : null;
    if (pre) preset = "";
    const sel = new Set(preset && by[preset] ? [preset] : []);
    let agent = (pre && pre.agent === "codex") || (preset && by[preset] && by[preset].agent === "codex") ? "codex" : "claude", mode = "auto", model = "", q = "", running = false;   // model: "" until a segment is pressed (nothing is passed)
    const nowOf = {};                                   // project -> what a new session there starts on (/api/session/model `now`)
    const named = groupsSeen.filter((g) => rooms.some((r) => r.group === g));
    const sections = [...named.map((g) => [g, rooms.filter((r) => r.group === g)]),
      [named.length ? tl("room.pk.other") : "", rooms.filter((r) => !named.includes(r.group))]].filter((s) => s[1].length);
    const canKeep = (r) => !!(r.sid && (r.agent || "claude") === agent);
    const isUp = (r) => canKeep(r) && !!r.state && r.state !== "ended";
    // Where one department's line goes. Left alone, the conversation it has gets the line (one
    // conversation per department); only the switch opens another.
    const modeOf = (r, n) => mode === "new" ? "new" : mode === "keep" ? ((n > 1 ? isUp(r) : canKeep(r)) ? "keep" : "new") : canKeep(r) ? "keep" : "new";
    const SEGLAB = {mode: tl("room.mode"), model: tl("room.model"), agent: "Claude / Codex"};
    const seg = (k, opts, cur) => `<div class="seg pj-seg2" data-seg="${k}" role="group" aria-label="${esc(SEGLAB[k])}">${opts.map(([v, l]) =>
      `<button class="${v === cur ? "on" : ""} press" data-v2="${v}" aria-pressed="${v === cur}">${k === "agent" ? window.agDot(v) : ""}${esc(l)}</button>`).join("")}</div>`;
    sheet(`<div class="pj-dlg pj-new"><h3>${tl("room.newTitle")}</h3>
      <div class="pj-ntop">${seg("agent", [["claude", "Claude"], ["codex", "Codex"]], agent)}
        <input class="pj-search" type="search" data-q placeholder="${esc(tl("room.searchOnly"))}" aria-label="${esc(tl("room.searchOnly"))}">
        <button type="button" class="btn sm press pj-mkbtn" data-mk aria-expanded="false">${ic("plus")}<span>${tl("room.mkOpen")}</span></button></div>
      <div class="pj-mkbox" data-mkbox hidden><div class="lbl">${tl("room.mkName")}</div>
        <input class="tin" data-mkn type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.mkNamePh"))}" aria-label="${esc(tl("room.mkName"))}">
        ${onThisPc() ? `<div class="lbl">${tl("room.loc.label")}</div><div class="fx-loc ed"><input class="tin" data-mkp type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("room.loc.label"))}"><button type="button" class="btn sm press" data-loc aria-haspopup="dialog" aria-expanded="false">${ic("folder")}<span>${tl("room.loc.pick")}</span></button></div>` : ""}</div>
      <div class="pj-pg" data-pg role="listbox" aria-multiselectable="true" aria-label="${esc(tl("room.dept"))}"></div>
      <div class="pj-nfoot"><div data-modebox></div>
        <div class="pj-to" data-to aria-live="polite"></div>
        <textarea class="pj-ta2" data-text rows="2" placeholder="${esc(tl("room.firstPh"))}" aria-label="${esc(tl("room.first"))}"></textarea>
        <div class="pj-hint" data-hint></div>
        <div class="pj-nrow"><div data-modelbox></div>
          <button type="button" class="pj-text press" data-more>${tl("room.firstMore")}</button>
          <span class="sp"></span><button class="pj-btn light press" data-go>${tl("room.start")}</button></div></div></div>`, (box) => {
      box.classList.add("pj-wide");
      const pg = box.querySelector("[data-pg]"), mb = box.querySelector("[data-modebox]"), hint = box.querySelector("[data-hint]");
      const go = box.querySelector("[data-go]"), ta = box.querySelector("[data-text]"), qi = box.querySelector("[data-q]"), to = box.querySelector("[data-to]");
      let cur = [];
      // The first chat ever (the guide's line, no project yet): only the line, the agent and [시작].
      let first = !!(pre && pre.mk && !rooms.length);
      const root0 = box.querySelector(".pj-new"), moreB = box.querySelector("[data-more]");
      root0.classList.toggle("pj-first", first);
      moreB.onclick = () => { first = false; root0.classList.remove("pj-first"); sync(); };
      // 새로 만들기: a name typed in its own box (never the search box) that is no project yet shows
      // as one more card, picked; starting it makes the folder in the place shown, registers the
      // project and opens the chat. The place is a field: typed, pasted or picked.
      let mkRoot = "", mkPar = "", mkName = "";
      const mkb = box.querySelector("[data-mk]"), mkbox = box.querySelector("[data-mkbox]"), mkn = box.querySelector("[data-mkn]"), mkp = box.querySelector("[data-mkp]"), mkloc = mkbox.querySelector("[data-loc]");
      const body = (j, text) => Object.assign({name: j.r.name, agent, text, model, mode: j.mode, sid: j.mode === "keep" ? j.r.sid || "" : ""},
        j.r.fresh ? Object.assign({create: true}, mkp ? {parent: mkPar.toLowerCase() === mkRoot.toLowerCase() ? "" : mkPar} : {}) : {});
      get("/api/depts").then((d) => { mkRoot = d.default_root || ""; mkPar = d.parent || mkRoot; if (mkp && !mkp.value) mkp.value = mkPar; if (box.isConnected) sync(); }).catch(() => {});
      const fresh = () => {
        const nm = mkName.trim();
        return nm && !rooms.some((r) => r.name.toLowerCase() === nm.toLowerCase()) ? nm : "";
      };
      const wireSeg = () => box.querySelectorAll("[data-seg]").forEach((sg) => sg.querySelectorAll("[data-v2]").forEach((b) => b.onclick = () => {
        const k = sg.dataset.seg, v = b.dataset.v2;
        // A model segment pressed is a pick; pressed again it is let go, and the start passes nothing.
        if (k === "model") { model = model === v ? "" : v; return paintModel(); }
        if (k === "agent") { agent = v; mode = "auto"; } else mode = v;
        sg.querySelectorAll("[data-v2]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        sync();
      }));
      // The model row has no "default": the model a new session really starts on is the segment
      // that is marked (the chip's own resolver, per project), with a line saying how that is
      // known. It is only shown: until a segment is pressed no model is passed. Projects that
      // start on different models, or none that can be named, leave every segment unmarked.
      let newNames = [];
      const paintModel = () => {
        const mbx = box.querySelector("[data-modelbox]");
        newNames.forEach((nm) => { if (nowOf[nm] !== undefined) return; nowOf[nm] = null;
          get("/api/session/model?name=" + enc(nm)).then((r) => { nowOf[nm] = r.now || {}; if (box.isConnected) paintModel(); }).catch(() => { nowOf[nm] = {}; if (box.isConnected) paintModel(); }); });
        const got = newNames.map((nm) => nowOf[nm]), ready = got.length && got.every(Boolean);
        const keys = ready ? [...new Set(got.map((x) => x.family || x.name || ""))] : [];
        const now = keys.length === 1 && keys[0] ? got[0] : null, LIST = ["haiku", "sonnet", "opus"];
        const own = now && !LIST.includes(now.family);     // a model outside the row: a segment under its own name
        const cur = model || (now ? (own ? "" : now.family) : null);
        const cap = model ? (model === "auto" ? tl("room.modelAuto") : "") : !ready ? "" : now ? (MTAG[now.source] ? tl("room.modelShown", {how: MTAG[now.source]()}) : "")
          : keys.length > 1 ? tl("room.modelMixed") : tl("room.modelNone");
        mbx.innerHTML = seg("model", [...(own ? [["", now.name]] : []), ["haiku", "Haiku"], ["sonnet", "Sonnet"], ["opus", "Opus"], ["auto", tl("room.auto")]], cur)
          + `<div class="pj-mcap" aria-live="polite">${esc(cap)}</div>`;
        wireSeg();
      };
      const cardH = (r) => {
        const on = sel.has(r.name);
        return `<button class="pj-pc press ${on ? "on" : ""} ${isUp(r) ? "up" : ""}" role="option" aria-selected="${on}" tabindex="-1" data-dn="${esc(r.name)}"${isUp(r) ? ` title="${esc(tl("room.pk.up"))}"` : ""}>
          ${em(r.emoji, "", r.icon)}<span class="t">${esc(pname(r.name))}</span>${r.sid ? dot(kindOf(r.state || "ended", r.at)) : ""}<span class="pj-ck">${ic("check")}</span></button>`;
      };
      const roam = (c) => pg.querySelectorAll("[data-dn]").forEach((x) => { x.tabIndex = x === c ? 0 : -1; });
      const paintGrid = () => {
        const f = foldQ(q);
        cur = sections.map(([g, rs]) => [g, f ? rs.filter((r) => hay(r).includes(f)) : rs]).filter((s) => s[1].length);
        // A register group can be renamed for the screens here (its pencil); the leftover section is not one.
        const gren = (g) => groupsSeen.includes(g) ? `<button class="pj-gn press" data-gren="${esc(g)}" aria-label="${esc(tl("room.groupRename"))}" title="${esc(tl("room.groupRename"))}">${ic("pen")}</button>` : "";
        const nm = fresh();
        if (nm && !by[nm]) by[nm] = {name: nm, fresh: true};
        pg.innerHTML = (cur.length ? cur.map(([g, rs], i) => `${g ? `<div class="pj-gh"><span class="g">${esc(gpname(g))}</span><span class="n">${rs.length}</span>${gren(g)}<span class="sp"></span>
            <button class="pj-text press" data-gall="${i}"></button></div>` : ""}<div class="pj-pgg">${rs.map(cardH).join("")}</div>`).join("")
          : nm ? "" : `<div class="pj-empty">${rooms.length ? tl("room.noMatch") : tl("room.mkEmpty")}</div>`)
          + (nm ? `<div class="pj-gh"><span class="g">${tl("room.mkHead")}</span></div><div class="pj-pgg"><button class="pj-pc pj-mk press ${sel.has(nm) ? "on" : ""}" role="option" aria-selected="${sel.has(nm)}" tabindex="-1" data-dn="${esc(nm)}">
            <span class="pj-em">${ic("plus")}</span><span class="t">${esc(tl("room.mkCard").replace("{n}", nm))}</span><span class="pj-ck">${ic("check")}</span></button></div>` : "");
        roam(pg.querySelector("[data-dn].on") || pg.querySelector("[data-dn]"));
      };
      const sync = () => {
        pg.querySelectorAll("[data-dn]").forEach((c) => {
          const r = by[c.dataset.dn], on = sel.has(c.dataset.dn);
          c.classList.toggle("on", on); c.setAttribute("aria-selected", on); c.classList.toggle("up", isUp(r));
        });
        pg.querySelectorAll("[data-gall]").forEach((b) => { b.textContent = cur[+b.dataset.gall][1].every((r) => sel.has(r.name)) ? tl("room.pk.none") : tl("room.pk.all"); });
        const picks = [...sel].map((n) => by[n]), n = picks.length;
        const ups = picks.filter(isUp).length, anyKeep = n > 1 ? ups > 0 : picks.some(canKeep);
        if (!anyKeep) mode = "auto";
        mb.innerHTML = anyKeep ? seg("mode", n > 1 ? [["keep", tl("room.pk.keepUp")], ["new", tl("room.pk.allNew")]]
          : [["keep", tl("room.keep")], ["new", tl("room.fresh")]], mode === "auto" ? (picks.some((r) => modeOf(r, n) === "keep") ? "keep" : "new") : mode) : "";
        const keeps = picks.filter((r) => modeOf(r, n) === "keep").length, news = n - keeps;
        box.querySelector("[data-modelbox]").hidden = (n > 0 && !news) || agent === "codex";
        newNames = agent === "codex" ? [] : picks.filter((r) => modeOf(r, n) === "new").map((r) => r.name);
        hint.textContent = !n ? tl("room.pk.hint0")
          : n === 1 && picks[0].fresh ? tl("room.mkHint").replace("{f}", (mkPar ? mkPar.replace(/[\\/]+$/, "") + "\\" : "") + picks[0].name)
          : n === 1 ? (keeps ? (isUp(picks[0]) ? tl("room.pk.hintUp") : tl("room.hintKeep")) : agent === "codex" ? tl("room.hintCodex") : tl("room.hintNew"))
          : keeps && news ? tl("room.pk.hintMix", {news, keeps})
          : keeps ? tl("room.pk.hintKeeps", {n: keeps})
          : tl("room.pk.hintNews", {n: news});
        if (first && n === 1 && picks[0].fresh) hint.textContent = tl("room.firstHint", {n: picks[0].name});
        hint.classList.remove("err");
        // Codex picked but it cannot answer on this PC yet: say which step is missing and lead
        // to the connect card, instead of letting the start fail with an error.
        const cx = agent === "codex" && window.LOOP_CONNECT && window.LOOP_CONNECT.step ? window.LOOP_CONNECT.step("codex") : "";
        if (cx === "install" || cx === "login") {
          hint.innerHTML = `${esc(cx === "install" ? tl("room.cxNeedInstall") : tl("room.cxNeedLogin"))} <button type="button" class="lnk press" data-connopen>${esc(tl("room.cxConnect"))}</button>`;
          hint.classList.add("err");
        }
        // Who gets the first line: the project, the conversation (the one that is up, or a new one), the agent.
        to.innerHTML = !n ? "" : n > 1 ? toLine({n, names: picks.map((r) => r.name), agent})
          : toLine({name: picks[0].name, emoji: picks[0].emoji, agent,
            conv: keeps ? (picks[0].fixed || (picks[0].title && picks[0].title !== "(제목 없음)" ? picks[0].title : tl("room.keep"))) : tl("room.toNew")});
        go.disabled = !n;
        go.textContent = n > 1 ? tl("room.pk.startN", {n}) : tl("room.start");
        paintModel();
      };
      const toggle = (name) => { if (sel.has(name)) sel.delete(name); else sel.add(name); sync(); };
      pg.onclick = (e) => {
        const gr = e.target.closest("[data-gren]");
        if (gr) return groupRename(gr.dataset.gren, () => { paintGrid(); sync(); });
        const g = e.target.closest("[data-gall]"), c = e.target.closest("[data-dn]");
        if (g) {
          const rs = cur[+g.dataset.gall][1], all = rs.every((r) => sel.has(r.name));
          rs.forEach((r) => { if (all) sel.delete(r.name); else sel.add(r.name); });
          return sync();
        }
        if (!c) return;
        toggle(c.dataset.dn); roam(c);
        // The fast path: one click on a card, type, Enter.
        if (e.detail > 0 && wide() && sel.size === 1 && sel.has(c.dataset.dn) && !ta.value) ta.focus({preventScroll: true});
      };
      pg.onkeydown = (e) => {
        const c = e.target.closest("[data-dn]");
        if (!c || e.isComposing) return;
        const cards = [...pg.querySelectorAll("[data-dn]")], i = cards.indexOf(c), top = (x) => x.getBoundingClientRect().top;
        let to = null;
        if (e.key === "ArrowRight") to = cards[i + 1];
        else if (e.key === "ArrowLeft") to = cards[i - 1];
        else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          const r0 = c.getBoundingClientRect(), down = e.key === "ArrowDown";
          const pool = (down ? cards.slice(i + 1) : cards.slice(0, i).reverse()).filter((x) => Math.abs(top(x) - r0.top) > 4);
          if (pool.length) {
            const y = top(pool[0]), dx = (x) => Math.abs(x.getBoundingClientRect().left - r0.left);
            to = pool.filter((x) => Math.abs(top(x) - y) < 4).sort((a, b) => dx(a) - dx(b))[0];
          } else if (!down) { e.preventDefault(); return qi.focus(); }
        } else if (e.key === "Home") to = cards[0];
        else if (e.key === "End") to = cards[cards.length - 1];
        else if (e.key === " ") { e.preventDefault(); return toggle(c.dataset.dn); }
        else if (e.key === "Enter") { e.preventDefault(); if (!sel.has(c.dataset.dn)) toggle(c.dataset.dn); return start(); }
        else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) return ta.focus();   // typing goes to the first line
        else return;
        e.preventDefault();
        if (to) { roam(to); to.focus(); }
      };
      qi.oninput = () => { q = qi.value; paintGrid(); sync(); };
      mkb.onclick = () => {
        const open = mkbox.hidden;
        mkbox.hidden = !open; mkb.setAttribute("aria-expanded", open);
        if (open) mkn.focus({preventScroll: true}); else { mkn.value = ""; mkn.oninput(); }
      };
      mkn.oninput = () => {
        mkName = mkn.value;
        // a half-typed new name is not a pick: only the name in the box right now can be made
        Object.keys(by).forEach((n) => { if (by[n].fresh && n !== fresh()) { sel.delete(n); delete by[n]; } });
        const nm = fresh();
        if (nm) { by[nm] = {name: nm, fresh: true}; sel.add(nm); }
        paintGrid(); sync();
      };
      mkn.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); if (fresh()) ta.focus(); } };
      if (pre && pre.mkOpen) setTimeout(() => { if (box.isConnected && mkbox.hidden) mkb.onclick(); }, 0);
      if (mkp) {
        mkp.oninput = () => { mkPar = typedPath(mkp.value) || mkRoot; sync(); };
        mkloc.onclick = () => { if (mkloc.getAttribute("aria-expanded") === "true") return;
          folderPop(mkloc, mkPar, fresh(), (p) => { mkPar = p; mkp.value = p; sync(); }, () => { mkp.focus(); mkp.select(); }); };
      }
      qi.onkeydown = (e) => {
        if (e.isComposing || e.keyCode === 229) return;
        const cards = pg.querySelectorAll("[data-dn]");
        if (e.key === "ArrowDown" && cards[0]) { e.preventDefault(); roam(cards[0]); cards[0].focus(); }
        else if (e.key === "Enter") { e.preventDefault(); if (cards.length === 1) { sel.add(cards[0].dataset.dn); sync(); ta.focus(); } }
      };
      // Enter starts on a keyboard (Shift+Enter is a new line); on a phone Enter stays a new line.
      ta.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229 && wide()) { e.preventDefault(); start(); } };

      const bulk = (jobs, text) => {
        const root = box.querySelector(".pj-new");
        root.innerHTML = `<h3 data-bh aria-live="polite"></h3><div class="pj-pg pj-res" data-res role="list"></div>
          <div class="pj-nfoot"><div class="pj-hint" data-bhint></div><div class="pj-nrow" data-bact></div></div>`;
        const res = root.querySelector("[data-res]"), bh = root.querySelector("[data-bh]"), ba = root.querySelector("[data-bact]"), bhint = root.querySelector("[data-bhint]");
        const TXT = {wait: tl("room.bulk.wait"), run: tl("room.starting"), new: tl("room.bulk.new"), keep: tl("room.bulk.keep"), fail: tl("room.bulk.fail"), skip: tl("room.bulk.skip")};
        let stop = false;
        const count = (...st) => jobs.filter((j) => st.includes(j.st)).length;
        const paint = () => {
          const ok = count("new", "keep"), bad = count("fail"), left = count("wait", "run"), skip = count("skip");
          bh.textContent = left ? tl("room.bulk.prog", {n: jobs.length, done: jobs.length - left}) : bad || skip ? tl("room.bulk.part", {ok, bad: bad + skip}) : tl("room.bulk.allOk", {n: ok});
          res.innerHTML = jobs.map((j, i) => {
            const tag = j.sid && !left ? "button" : "div";
            const say = j.st === "run" && j.mode === "keep" ? tl("room.sending") : TXT[j.st] + (j.msg ? " · " + j.msg : "");
            return `<${tag} class="pj-rr ${j.st}${tag === "button" ? " press" : ""}" role="listitem"${tag === "button" ? ` data-open="${i}"` : ""}>${em(j.r.emoji, "", j.r.icon)}
              <span class="tx"><span class="t">${esc(pname(j.r.name))}</span><span class="s">${esc(say)}</span></span>
              ${j.st === "new" || j.st === "keep" ? `<span class="pj-ck">${ic("check")}</span>` : j.st === "fail" || j.st === "skip" ? `<span class="pj-ck no">!</span>` : ""}</${tag}>`;
          }).join("");
          res.querySelectorAll("[data-open]").forEach((b) => b.onclick = () => { const j = jobs[+b.dataset.open]; closeSheet(); nav("project/" + enc(j.r.name) + "/" + enc(j.sid)); });
          if (left) { bhint.textContent = tl("room.bulk.going"); ba.innerHTML = ""; return; }
          const sids = jobs.map((j) => j.sid).filter(Boolean);
          bhint.textContent = bad ? tl("room.bulk.badHint") : skip ? tl("room.bulk.skipHint") : tl("room.bulk.okHint");
          ba.innerHTML = `${bad + skip ? `<button class="pj-btn press" data-again>${tl("room.bulk.again")}</button>` : ""}
            ${sids.length > 1 ? `<button class="pj-btn press" data-side>${tl("room.bulk.side")}</button>` : ""}<span class="sp"></span><button class="pj-btn light press" data-close>${tl("ui.close")}</button>`;
          const ag = ba.querySelector("[data-again]"), sd = ba.querySelector("[data-side]");
          if (ag) ag.onclick = () => runAll(jobs.filter((j) => j.st === "fail" || j.st === "skip"));
          if (sd) sd.onclick = () => { closeSheet(); goMulti(sids.slice(0, MAXP)); };
          ba.querySelector("[data-close]").onclick = () => { closeSheet(); if (location.hash === "#project") render(); };
          ba.querySelector("[data-close]").focus({preventScroll: true});
        };
        const one = async (j) => {
          j.st = "run"; j.msg = ""; paint();
          try {
            const r = await act("/api/session/new", body(j, text));
            j.sid = r.sid || ""; j.st = r.kept ? "keep" : "new"; j.msg = r.kept || r.sid ? "" : tl("room.bulk.soon");
          } catch (e) {
            if (e.message === "cancelled") { j.st = "skip"; j.msg = tl("room.bulk.denied"); stop = true; }
            else { j.st = "fail"; j.msg = e.message; }
          }
          paint();
        };
        const runAll = async (list) => {
          stop = false; running = true;
          list.forEach((j) => { j.st = "wait"; j.msg = ""; });
          paint();
          let i = 0;
          const worker = async () => { while (i < list.length && !stop) await one(list[i++]); };
          // The first one alone: it is the one that may ask for permission. If it did, the rest go
          // one at a time so two permission dialogs never stack; otherwise two at a time.
          let asked = false;
          const watch = setInterval(() => { if (document.querySelector(".cs-box")) asked = true; }, 120);
          if (list.length) await one(list[i++]);
          clearInterval(watch);
          await Promise.all(asked ? [worker()] : [worker(), worker()]);
          list.forEach((j) => { if (j.st === "wait") { j.st = "skip"; j.msg = tl("room.bulk.skipped"); } });
          running = false; roomsCache = null;
          if (root.isConnected) paint();
          else toast(count("fail", "skip") ? tl("room.bulk.part", {ok: count("new", "keep"), bad: count("fail", "skip")}) : tl("room.pk.startN", {n: count("new", "keep")}));
        };
        runAll(jobs);
      };
      async function start() {
        if (running) return;
        const text = ta.value.trim(), picks = [...sel].map((n) => by[n]).filter(Boolean);
        if (!picks.length) return toast(tl("room.hintPick"));
        if (!text) { ta.focus(); return toast(tl("room.needFirst")); }
        const jobs = picks.map((r) => ({r, mode: modeOf(r, picks.length), st: "wait", msg: "", sid: ""}));
        if (jobs.length > 1) return bulk(jobs, text);
        running = true; go.disabled = true; go.innerHTML = loadingHtml(tl("room.starting"), {inline: true});
        try {
          const r = await act("/api/session/new", body(jobs[0], text));
          closeSheet(); toast(r.message || tl("room.started")); roomsCache = null;
          started(r.name || picks[0].name);
          // Claude has not named the new session yet: the page waits for it instead of opening
          // the project's older one (V11 #3).
          if (!r.kept && (r.sid || r.job)) pendNew[r.name || picks[0].name] = {job: r.job, sid: r.sid, text, at: Date.now()};
          nav("project/" + enc(r.name || picks[0].name) + (r.sid ? "/" + enc(r.sid) : ""));
        } catch (e) {
          running = false; go.disabled = false; go.textContent = tl("room.start");
          if (jobs[0].r.fresh) roomsCache = null;      // it may have been made even though the chat did not start
          // The reason stays on the sheet (a toast is gone before a long one is read).
          // Said once: on the sheet while it is up, as a toast only when it is not.
          if (e.message !== "cancelled") { hint.textContent = e.message; hint.classList.add("err"); if (!hint.isConnected) toast(e.message); }
        }
      }
      go.onclick = start;
      paintGrid(); sync();
      if (pre) {
        ta.value = pre.text || "";
        if (pre.mk) { mkbox.hidden = false; mkb.setAttribute("aria-expanded", true); mkn.value = pre.mk; mkn.oninput(); }
      }
      if (!wide()) return;
      if (sel.size) ta.focus({preventScroll: true}); else qi.focus({preventScroll: true});
    });
  }

  // new-default:begin
  // Where [새 세션] opens when nothing is selected: the project talked in last (its newest line),
  // else the first one listed. A project whose folder is gone (`lost`) is passed over, and
  // `skipped` names it when it would have been the pick, so the page can say so.
  function newDefault(list) {
    const at = (r) => String(r.at || ""), newest = (rs) => rs.reduce((a, b) => (at(b) > at(a) ? b : a), rs[0]);
    const had = (list || []).filter((r) => r.sid), ok = had.filter((r) => !r.lost);
    const room = ok.length ? newest(ok) : (list || []).find((r) => !r.lost) || null;
    const was = had.length ? newest(had) : null;
    return {room, skipped: room && was && was.lost ? was : null};
  }
  // new-default:end
  // A first line was really taken by a session: the first-use guide moves on from this, not from a click.
  const started = (name) => { try { window.dispatchEvent(new CustomEvent("loop:session-new", {detail: {name}})); } catch (e) { /* old engine */ } };
  // The guide's [대화 시작]: the same composer as [새 세션] with the first line already in the box.
  // No project yet: the new-chat sheet, with a new project's name filled in as well.
  window.LOOP_FIRST_LINE = async function (text, agent) {
    if (!roomsCache) { try { await loadRooms(); } catch (e) { toast(e.message); return false; } }
    const d = newDefault(roomsCache || []);
    if (!d.room) { await newChat({text, agent, mk: tl("onboard.ohFirstProj")}); return true; }
    if (!drafts[d.room.name]) drafts[d.room.name] = text;
    if (agent === "codex") draftAgent[d.room.name] = "codex";
    nav("project/" + enc(d.room.name) + "/" + NEW);
    return true;
  };
  window.LOOP_NEW_CHAT = newChat;      // the sessions screen's [새 대화] and per-group "+" open the same sheet
  // A session opened a moment ago that has no id yet, by project: {job, text, at}.
  const pendNew = {};
  // new-wait:begin
  const PEND_MAX = 90000;
  const PEND_SID = 20000;                              // a session that has its id is listed within moments; after this the pane says so
  // The session opened a moment ago (`pp`) that the page at `sid` waits for, else null. With no id
  // in the address it is the one Claude has not named yet. With an id it is that very session
  // while the list does not have it: the page waits there and never opens the empty draft or an
  // older session in its place (0.1.64: a Codex line sent from the draft "just disappeared").
  function pendFor(pp, sid, listed, now) {
    if (!pp) return null;
    if (sid) return pp.sid === sid && !listed ? pp : null;
    return !pp.sid && now - pp.at < PEND_MAX ? pp : null;
  }
  // Whether the answer kept from last time (`v`) is worth painting before the fresh one arrives.
  // Not on a page that already shows this very chat (`same`: a refresh - the kept answer is older
  // than what is drawn and would take a new row out for a moment), and not when it does not know
  // the session asked for (a new one: the page would open another chat in the meantime).
  function seenPaint(v, sid, isNew, same) {
    if (!v || same) return false;
    return !sid || isNew || (v.sessions || []).some((s) => s.id === sid);
  }
  // new-wait:end
  const draftErr = {}, draftCode = {};   // why the first line did not go, and the server's code for it
  const draftBusy = {};                              // name -> the first line still on its way (survives a redraw)
  let readOffer = null;                               // that offer, while its bar is up
  // Nothing is read until [허용] is pressed; [닫기] only takes the bar away.
  function readBar(box, redraw, after) {
    if (!readOffer || box.querySelector(".pj-rbar")) return;
    const bar = document.createElement("div");
    bar.className = "pj-rbar"; bar.setAttribute("role", "status");
    bar.innerHTML = `<span>${tl("room.readBar")}</span><span class="a"><button class="pj-btn light press" data-ok>${tl("room.readBarOk")}</button><button class="pj-btn press" data-no>${tl("room.readBarNo")}</button></span>`;
    const scope = readOffer.scope;
    bar.querySelector("[data-ok]").onclick = () => { readOffer = null; bar.remove();
      post("/api/consent/grant", {scope}).then(redraw).catch((e) => toast(e.message)); };
    bar.querySelector("[data-no]").onclick = () => { readOffer = null; bar.remove(); };
    if (after) after.after(bar); else box.prepend(bar);
  }
  let offered = false;                               // the Codex record read was offered this run                                 // why the last first line did not go out, per project (shown in the draft until the next try)

  // A group's display name (the register and the folders keep the real one). Empty puts it back.
  function groupRename(g, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("room.groupRename")}</h3>
      <input class="pj-search" data-gn maxlength="60" spellcheck="false" value="${esc(gpname(g))}" placeholder="${esc(g)}" aria-label="${esc(tl("room.groupRename"))}" style="width:100%;margin-top:10px">
      <div class="pj-hint">${esc(tl("room.groupRenameNote", {name: g}))}</div>
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-gn]");
      setTimeout(() => { inp.focus(); inp.select(); }, 50);
      const save = async () => {
        try {
          const r = await post("/api/custom/identity", {group: g, name: inp.value.trim()});
          D.gident = r.group_names || {}; closeSheet(); toast(tl("room.groupRenamed"));
          if ((r.renamed || []).length) await load();      // its members' names followed it
          if (again) again(); else render();
        } catch (e) { toast(e.message); }
      };
      box.querySelector("[data-go]").onclick = save;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); } };
    });
  }
  window.LOOP_GROUP_RENAME = groupRename;
  // A session's name here (the record keeps its own title). Empty puts the record's back.
  function sessRename(s, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("pj.name.h")}</h3>
      <input class="pj-search" data-sn maxlength="120" spellcheck="false" value="${esc(s.renamed ? s.title : "")}" placeholder="${esc(title(s))}" aria-label="${esc(tl("pj.name.h"))}" style="width:100%;margin-top:10px">
      <div class="pj-hint">${tl("pj.name.note")}</div>
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-sn]");
      setTimeout(() => { inp.focus(); inp.select(); }, 50);
      const save = async () => {
        try {
          await post("/api/sessions/rename", {id: s.id, name: inp.value.trim()});
          closeSheet(); await load(); if (again) again(); else render();
        } catch (e) { toast(e.message); }
      };
      box.querySelector("[data-go]").onclick = save;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); } };
    });
  }

  // ---- several rooms at once: #project/~multi/<sid>,<sid>… (up to 6) ------------------------------
  async function pickPanes(have, done) {
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const rooms = (roomsCache || []).filter((r) => r.sid && !have.includes(r.sid)), sel = new Set(), room = MAXP - have.length;
    sheet(`<div class="pj-dlg"><h3>${tl("room.pickTitle")}</h3><div class="pj-hint" style="margin-top:0">${esc(tl("room.pickHint", {n: room}))}</div>
      <div class="pj-dl pj-pick" style="max-height:48vh">${rooms.map((r) => `<button class="press" data-ps="${esc(r.sid)}" aria-pressed="false">
          ${em(r.emoji, "", r.icon)}<span class="t">${esc(pname(r.name))}</span>${dot(r.state || "ended")}<span class="pj-ck">${ic("check")}</span></button>`).join("")
        || `<div class="pj-empty">${tl("room.noSession")}</div>`}</div>
      <div class="acts"><button class="pj-btn light full press" data-go disabled>${tl("room.openPanes")}</button></div></div>`, (box) => {
      const go = box.querySelector("[data-go]");
      box.querySelectorAll("[data-ps]").forEach((b) => b.onclick = () => {
        const id = b.dataset.ps;
        if (sel.has(id)) sel.delete(id); else if (sel.size < room) sel.add(id); else return toast(tl("room.max", {n: MAXP}));
        b.setAttribute("aria-pressed", sel.has(id)); b.classList.toggle("on", sel.has(id));
        go.disabled = !sel.size; go.textContent = sel.size ? tl("room.openN", {n: sel.size}) : tl("room.openPanes");
      });
      go.onclick = () => { closeSheet(); done([...have, ...sel]); };
    });
  }
  function saveBundle(ids, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("room.saveBundle")}</h3>
      <input class="pj-search" data-bn maxlength="40" placeholder="${esc(tl("room.bundleName"))}" aria-label="${esc(tl("room.bundleName"))}" style="width:100%;margin-top:10px">
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-bn]"), go = box.querySelector("[data-go]");
      setTimeout(() => inp.focus(), 50);
      const save = async () => {
        const name = inp.value.trim(); if (!name) return inp.focus();
        try { await post("/api/room-bundles", {name, ids}); closeSheet(); toast(tl("room.saved")); again(); }
        catch (e) { toast(e.message); }
      };
      go.onclick = save;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); } };
    });
  }
  async function drawMulti(el, ids, my) {
    ids = [...new Set(ids.filter(Boolean))].slice(0, MAXP);
    tab = "conv";                                      // panes show only the chat
    if (!ids.length) return nav(listHash());
    el.innerHTML = loadingHtml(tl("room.loading"), {fill: true});
    const [infos, bund] = await Promise.all([
      Promise.all(ids.map((id) => get("/api/project/session?id=" + enc(id)).catch(() => ({found: false})))),
      bundlesOf(), roomsCache ? null : loadRooms().catch(() => null)]);
    if (!live(my)) return;
    const panes = ids.map((id, i) => Object.assign({}, infos[i], {id}));
    if (mFocus >= panes.length) mFocus = 0;
    const emo = (p) => ((roomsCache || []).find((r) => r.name === p.project) || {}).emoji || "";
    const n = panes.length, allPh = tl("room.sendAll", {n});
    el.innerHTML = `<button class="pj-back press" data-b>← ${tl("room.rooms")}</button>
      <div class="pj-top"><div class="pj-lab" style="margin:0">${tl("room.multi")} <span class="n">${n}</span></div><span class="sp"></span>
        ${bund.map((b, i) => `<button class="pj-chip press" data-bund="${i}">${esc(b.name)}</button>`).join("")}
        <button class="pj-text press" data-save>${tl("room.saveBundle")}</button>
        ${n < MAXP ? `<button class="pj-btn press" data-add>${ic("plus")}<span>${tl("room.addPane")}</span></button>` : ""}</div>
      <div class="pj-all"><textarea rows="1" data-all placeholder="${esc(allPh)}" aria-label="${esc(allPh)}"></textarea>
        <button class="pj-btn light press" data-allgo>${tl("room.sendAllGo")}</button></div>
      <div class="pj-to">${toLine({n: Math.max(2, panes.filter((p) => p.found && p.project).length), names: panes.filter((p) => p.found && p.project).map((p) => p.project)})}</div>
      <div class="pj-mtabs" role="tablist">${panes.map((p, i) => `<button class="press ${i === mFocus ? "on" : ""}" role="tab" aria-selected="${i === mFocus}" data-mt="${i}">${esc(emo(p))} ${esc(pname(p.project || "") || p.id.slice(0, 8))}</button>`).join("")}</div>
      <div class="pj-mgrid n${n} r${n > 3 ? 2 : 1}">${panes.map((p, i) => `<section class="pj-mp pj-anim ${i === mFocus ? "focus" : ""}" data-mp="${i}" aria-label="${esc(pname(p.project || ""))}">
        <div class="pj-mhead">${em(emo(p), "", icoOf(p.project)).replace("<span ", '<span style="font-size:16px" ')}<span class="t">${esc(pname(p.project || ""))}</span>
          <span class="s">${p.found ? esc(title(p)) : ""}</span><span class="sp"></span>
          <button class="pj-more press" data-big="${i}" aria-label="${esc(tl("room.bigger"))}" title="${esc(tl("room.bigger"))}">${ic("full")}</button>
          <button class="pj-more press" data-x="${i}" aria-label="${esc(tl("room.closePane"))}" title="${esc(tl("room.closePane"))}">${ic("x")}</button></div>
        <div class="pj-mb"></div></section>`).join("")}</div>`;
    el.querySelector("[data-b]").onclick = () => nav(listHash());
    el.querySelectorAll("[data-bund]").forEach((b) => b.onclick = () => goMulti(bund[+b.dataset.bund].ids));
    el.querySelector("[data-save]").onclick = () => saveBundle(ids, () => draw(el));
    const add = el.querySelector("[data-add]");
    if (add) add.onclick = () => pickPanes(ids, goMulti);
    el.querySelectorAll("[data-x]").forEach((b) => b.onclick = () => { const rest = ids.filter((_, i) => i !== +b.dataset.x); rest.length ? goMulti(rest) : nav(listHash()); });
    el.querySelectorAll("[data-big]").forEach((b) => b.onclick = () => { const p = panes[+b.dataset.big]; nav("project/" + enc(p.project || "") + "/" + enc(p.id)); });
    el.querySelectorAll("[data-mt]").forEach((b) => b.onclick = () => {
      mFocus = +b.dataset.mt;
      el.querySelectorAll("[data-mt]").forEach((x, i) => { x.classList.toggle("on", i === mFocus); x.setAttribute("aria-selected", i === mFocus); });
      el.querySelectorAll("[data-mp]").forEach((x, i) => x.classList.toggle("focus", i === mFocus));
    });
    panes.forEach((p, i) => {
      const body = el.querySelector(`[data-mp="${i}"] .pj-mb`);
      if (!p.found || !p.project) { body.innerHTML = `<div class="pj-empty">${tl("room.gone")}</div>`; return; }
      body.dataset.multi = "1";
      drawSession(body, el, p.project, p, my);
    });
    // One line to every open room: each goes through that room's own route (live inbox, hold, wake).
    const all = el.querySelector("[data-all]"), allGo = el.querySelector("[data-allgo]");
    const grow = () => { all.style.height = "auto"; all.style.height = Math.min(all.scrollHeight, 120) + "px"; };
    all.addEventListener("input", grow);
    const sendAll = async () => {
      const text = all.value.trim(); if (!text || allGo.disabled) return;
      allGo.disabled = true; all.value = ""; grow();
      let ok = 0;
      for (const [i, p] of panes.entries()) {
        if (!p.found || !p.project) continue;
        const body = el.querySelector(`[data-mp="${i}"] .pj-mb`), c = C(p.id), pe = {text, tag: tl("room.sending"), busy: true, at: Date.now()};
        c.pend.push(pe); c.stick = true; paint(body, c, false, c.entries.length);
        try {
          const r = await act("/api/session/tell", {sid: p.id, text}); ansMark(p.id, true);
          pe.tag = r.routed === "live" ? tl("room.sent") : (r.message || tl("room.sent")); pe.busy = false; ok++;
          if (p.agent !== "codex" && r.routed !== "hook") c.waiting = true;
          if (c.kick) c.kick();
        } catch (e) { c.pend.splice(c.pend.indexOf(pe), 1); if (e.message !== "cancelled") toast(e.message); }
        paint(body, c, false, c.entries.length);
      }
      allGo.disabled = false;
      if (ok) toast(tl("room.sentAll", {n: ok}));
    };
    allGo.onclick = sendAll;
    let composing = false;
    all.addEventListener("compositionstart", () => { composing = true; });
    all.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    all.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); sendAll();
    });
  }

  // A menu opens under its button, on the page itself: inside a card or the chat panel it was cut
  // off by their overflow whenever the column was narrower than the menu. Kept inside the window,
  // flipped above the button when there is no room below; gone on an outside press, Esc or a scroll.
  function popAt(pop, btn) {
    document.body.appendChild(pop);
    const at = ctxAt; ctxAt = null;                   // a right click: at the pointer, not under a button
    const b = btn.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight, m = 8;
    const below = at ? at.y + h <= innerHeight - m : !btn.closest(".pj-fab") && b.bottom + 4 + h <= innerHeight - m;   // the phone's floating button opens upward, clear of the tab bar
    if (at) {
      const p = window.PjCtx.place(at.x, at.y, w, h, innerWidth, innerHeight, m);
      pop.style.left = p.left + "px"; pop.style.top = p.top + "px";
      pop.style.transformOrigin = (p.below ? "top " : "bottom ") + (p.right ? "left" : "right");
    } else {
      pop.style.left = Math.max(m, Math.min(b.right - w, innerWidth - w - m)) + "px";
      pop.style.top = Math.max(m, below ? b.bottom + 4 : b.top - 4 - h) + "px";
      pop.style.transformOrigin = below ? "top right" : "bottom right";
    }
    if (window.Motion && Motion.menuIn) Motion.menuIn(pop);
    else if (!RM()) pop.animate([{opacity: 0, transform: "scale(.96)"}, {opacity: 1, transform: "none"}], {duration: 180, easing: "cubic-bezier(.2,.9,.25,1)"});
    const off = () => { if (window.Motion && Motion.menuOut) Motion.menuOut(pop); else pop.remove(); document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", key, true);
      removeEventListener("scroll", off, true); removeEventListener("resize", off); removeEventListener("hashchange", off); removeEventListener("blur", off); };
    const out = (e) => { if (!pop.contains(e.target)) off(); };
    const back = at && at.row && at.row.isConnected ? at.row : btn;   // where the keyboard goes back to
    const key = (e) => {
      if (!pop.isConnected) return off();              // closed by a choice: its keys are the page's again (Esc then closes the sheet that choice opened)
      if (e.key === "Escape") { e.stopPropagation(); off(); back.focus({preventScroll: true}); return; }
      // A choice's own letter (shown beside it) runs it: by the key's place, so it answers in 한글
      // mode too. Not with a modifier held, nor while a syllable is being composed.
      if (pop.isConnected && /^Key[A-Z]$/.test(e.code || "") && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && !e.isComposing) {
        const k = [...pop.querySelectorAll("button[data-k]")].find((x) => x.dataset.k === e.code.slice(3) && !x.closest("[hidden]"));
        if (k) { e.preventDefault(); e.stopPropagation(); k.click(); return; }
      }
      if (!at) return;
      // Opened from a row: up and down walk the choices, Home and End jump, Tab leaves and closes.
      if (e.key === "Tab") { off(); back.focus({preventScroll: true}); return; }
      const list = [...pop.querySelectorAll("button")].filter((x) => !x.closest("[hidden]")), to = window.PjCtx.step(list.length, list.indexOf(document.activeElement), e.key);
      if (to < 0) return;
      e.preventDefault(); e.stopPropagation(); list[to].focus({preventScroll: true});
    };
    if (at) {
      pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", at.label || "");
      pop.querySelectorAll("button").forEach((x) => { x.setAttribute("role", "menuitem"); x.tabIndex = -1; });
      const f = pop.querySelector("button:not([aria-disabled])") || pop.querySelector("button");
      if (f && at.kb) f.focus({preventScroll: true});
    }
    setTimeout(() => { document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", key, true);
      addEventListener("scroll", off, true); addEventListener("resize", off); addEventListener("hashchange", off); if (at) addEventListener("blur", off); }, 0);
    return off;
  }

  // The caret beside [새 세션]: the quieter way to start. 새 세션 itself stays one press.
  const pinMk = () => `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>`;
  function newMenu(btn) {
    // A second press on the caret closes the menu it opened (the outside-press already did).
    if (popBusy("new")) return;
    if (btn.getAttribute("aria-expanded") === "true" || performance.now() - (btn._shut || 0) < 320) return;
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm pj-nm"; pop.setAttribute("role", "menu");
    const it = (k, i, t) => `<button role="menuitem" data-a="${k}">${ic(i)}<span>${t}</span></button>`;
    pop.innerHTML = it("find", "power", tl("room.nmOn")) + it("make", "plus", tl("room.nmMake"));
    const off = popAt(pop, btn);      // off, not only removed: its Esc listener would swallow the sheet's Esc
    expanded("new", "[data-newmenu]", pop);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); off();
      if (b.dataset.a === "find") return findOn();
      // Another device may not make a folder here by itself: it keeps the way that starts a talk.
      if (b.dataset.a === "make" && !onThisPc()) return newChat({mkOpen: true});
      talkMake(b.dataset.a === "fixed" ? "fixed" : "dept"); });
  }

  // 말로 만들기 (만들기 and 담당 in that menu): one line of what the work is, and the connected
  // CLI proposes a name and a role for it (/api/depts/propose makes nothing). The proposal fills a
  // card the person can change, and only the card's button creates, through the same calls the
  // typed forms use. With no proposal the card opens with the person's own words and says so.
  async function talkMake(kind) {
    ensureCss();
    const fixed = kind === "fixed", head = fixed ? tl("room.fixed.new") : tl("room.mkNew");
    const path = fixed ? "/api/session/standing" : "/api/depts/create";
    let seq = 0, text = "", agents = {}, defRoot = "", parent = "", groups = [];
    get("/api/depts").then((d) => { agents = d.agents || {}; defRoot = d.default_root || ""; parent = d.parent || defRoot; groups = d.groups || []; }).catch(() => {});
    sheet(`<div class="pj-dlg pj-tm"></div>`, (box) => {
      const root = box.querySelector(".pj-tm");
      const fade = () => { if (!RM()) root.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease"}); };
      const own = (t) => fixed ? {name: "", task: t.slice(0, 200)} : {name: "", role: t.slice(0, 40), group: ""};
      // sug: true the CLI's proposal, false it was asked and nothing came, null the person skipped it.
      const card = (p, sug) => {
        const agent = !agents.claude && agents.codex ? "codex" : "claude";
        let pseq = 0, ready = "", busy = false, timer = 0, auto = "";
        const f2 = fixed ? ["task", tl("room.fixed.task"), 200] : ["role", tl("depts.role"), 40];
        root.innerHTML = `<h3>${sug ? tl("room.tm.sug") : head}</h3>${sug === false ? `<p class="hint">${tl("room.tm.none")}</p>` : ""}
          <div class="lbl">${tl("room.fixed.name")}</div>
          <div class="tm-nm"><button type="button" class="tm-em press" data-em aria-expanded="false" aria-label="${esc(tl("depts.emoji"))}" title="${esc(tl("depts.emoji"))}"></button><input class="tin" data-n type="text" maxlength="60" spellcheck="false" autocomplete="off" aria-label="${esc(tl("room.fixed.name"))}"></div>
          <div class="tm-grid" data-eg role="listbox" aria-label="${esc(tl("depts.emoji"))}" hidden></div>
          <div class="lbl">${f2[1]}</div><input class="tin" data-f2 type="text" maxlength="${f2[2]}" autocomplete="off" aria-label="${esc(f2[1])}">
          ${fixed ? "" : `<div class="lbl">${tl("depts.group")}</div><input class="tin" data-g type="text" maxlength="40" autocomplete="off" aria-label="${esc(tl("depts.group"))}"><div class="tm-gs" data-gs></div>`}
          <div data-pv aria-live="polite"></div>
          ${fixed || !onThisPc() ? "" : `<div data-par hidden><div class="lbl">${tl("depts.folder.where")}</div><div class="tm-par"><input class="tin" data-pin type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("depts.folder.where"))}">${sysPick() ? `<button type="button" class="pj-text press" data-ppick>${tl("room.loc.pick")}</button>` : ""}</div></div>`}
          <div class="pj-tmr"><button type="button" class="pj-text press" data-tmback>${tl("room.tm.back")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-go disabled>${tl("depts.pv.make")}</button></div>`;
        fade();
        const q = (x) => root.querySelector(x), nameEl = q("[data-n]"), f2El = q("[data-f2]"), gEl = q("[data-g]"), pv = q("[data-pv]"), go = q("[data-go]"), emEl = q("[data-em]"), parEl = q("[data-par]");
        nameEl.value = p.name || ""; f2El.value = p[f2[0]] || ""; if (gEl) gEl.value = p.group || "";
        const body = (dry) => Object.assign({name: nameEl.value.trim(), agent, [f2[0]]: f2El.value.trim()}, fixed ? {} : {group: gEl.value.trim(), create: true},
          onThisPc() ? {parent: String(parent).toLowerCase() === String(defRoot).toLowerCase() ? "" : parent} : {}, p.emoji ? {emoji: p.emoji} : {}, dry ? {dry_run: true} : {});
        const key = () => JSON.stringify(body(true));
        const sync = () => { go.disabled = busy || !ready || ready !== key(); emEl.textContent = p.emoji || auto || ""; };
        const preview = async () => {
          const my = ++pseq, k = key();
          if (!nameEl.value.trim()) { ready = ""; auto = ""; pv.innerHTML = ""; return sync(); }
          try {
            const v = (await post(path, body(true))).preview;
            if (my !== pseq || !root.isConnected) return;
            auto = v.emoji || "";
            pv.innerHTML = (parEl ? `<button type="button" class="tm-at press" data-atedit aria-expanded="${!parEl.hidden}" title="${esc(v.folder)}">` : `<div class="tm-at" title="${esc(v.folder)}">`) + `${ic("folder")}<span><bdi>${esc(v.folder)}</bdi></span>${parEl ? ic("pen") + "</button>" : "</div>"}` + (v.warnings || []).map((w) => `<p class="hint">${esc(w)}</p>`).join("");
            ready = k;
          } catch (err) {
            if (my !== pseq || !root.isConnected) return;
            pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = "";
          }
          sync();
        };
        const later = () => { ready = ""; sync(); clearTimeout(timer); timer = setTimeout(preview, 220); };
        const make = async () => {
          if (go.disabled) return;
          busy = true; sync();
          try {
            const r = await act(path, body(false));
            if (fixed) {
              roomsCache = null; closeSheet();
              toast(tl("room.fixed.made", {n: r.title || r.name}));
              return nav("project/" + enc(r.name));
            }
            if (!r || !r.dept) { busy = false; return sync(); }
            roomsCache = null; if (railNow) railNow();
            const pn = r.dept.name;
            root.innerHTML = `<div class="tm-done"><span class="e" aria-hidden="true">${esc(r.dept.emoji || "")}</span><b>${esc(pname(pn))}</b><span role="status">${tl("room.tm.done")}</span></div>
              <div class="pj-tmr"><button type="button" class="pj-text press" data-sclose>${tl("itemView.114")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-on>${icl("play")}<span>${tl("room.on")}</span></button></div>`;
            fade();
            const on = root.querySelector("[data-on]");
            on.onclick = async () => { closeSheet(); if (!roomsCache) { try { await loadRooms(); } catch (e) { /* the start says why */ } } turnOn(pn, null, () => { if (railNow) railNow(); }); };
            if (wide()) on.focus({preventScroll: true});
          } catch (err) {
            busy = false; sync();
            if (err.message !== "cancelled") { pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = ""; sync(); }
          }
        };
        // The face is a button: the fitting few first, then every one. The pick goes out with the rest.
        const egEl = q("[data-eg]"), EM = window.LOOP_EMOJI;
        emEl.onclick = () => {
          const on = egEl.hidden; egEl.hidden = !on; emEl.setAttribute("aria-expanded", on);
          if (!on || !EM) return;
          const first = EM.suggest(nameEl.value || f2El.value, [], 8), all = EM.search("", 2000).map((o) => o.e).filter((e) => !first.includes(e));
          egEl.innerHTML = first.concat(all).map((e) => `<button type="button" role="option" data-e="${e}" aria-label="${e}">${e}</button>`).join("");
        };
        egEl.onclick = (ev) => { const b = ev.target.closest("[data-e]"); if (!b) return; p.emoji = b.dataset.e; egEl.hidden = true; emEl.setAttribute("aria-expanded", false); later(); };
        // The groups there are, one press each, on show only while the field is being filled: a
        // name being typed narrows them, and one that is already a group offers the others.
        const gsEl = q("[data-gs]");
        const drawGs = () => { if (!gsEl) return;
          const v = gEl.value.trim(), lv = v.toLowerCase(), all = !v || groups.includes(v);
          gsEl.innerHTML = groups.filter((g) => g !== v && (all || g.toLowerCase().includes(lv))).map((g) => `<button type="button" class="press" data-g1="${esc(g)}">${esc(g)}</button>`).join(""); };
        if (gsEl) {
          gsEl.onpointerdown = (ev) => ev.preventDefault();      // the press must not take the field's focus, which closes the row
          gsEl.onclick = (ev) => { const b = ev.target.closest("[data-g1]"); if (!b) return; gEl.value = b.dataset.g1; gEl.blur(); later(); };
          gEl.addEventListener("input", drawGs);
          // The sheet is centred, so a taller card would lift the fields above: the card is held where it
          // stood and grows downward, as far as the window lets it.
          const hold = (y0) => { if (!wide()) return; box.style.translate = ""; const r = box.getBoundingClientRect(); box.style.translate = `0 ${Math.round(Math.min(y0 - r.top, Math.max(0, innerHeight - 12 - r.bottom)))}px`; };
          let top0 = 0;
          gEl.addEventListener("focus", () => { top0 = box.getBoundingClientRect().top; drawGs(); gsEl.classList.add("on"); hold(top0); if (!RM()) gsEl.animate([{opacity: 0}, {opacity: 1}], {duration: 120, easing: "ease"}); });
          gEl.addEventListener("input", () => hold(top0));
          gEl.addEventListener("blur", () => { gsEl.classList.remove("on"); box.style.translate = ""; });
        }
        // Where the folder goes: the line opens a field for the place it is made in.
        const pinEl = q("[data-pin]"), ppick = q("[data-ppick]");
        if (parEl) {
          pinEl.value = parent;
          pv.onclick = (ev) => { if (!ev.target.closest("[data-atedit]")) return; parEl.hidden = !parEl.hidden; if (!parEl.hidden) { pinEl.focus(); pinEl.select(); } };
          pinEl.oninput = () => { parent = pinEl.value.trim().replace(/^"+|"+$/g, "").trim() || defRoot; later(); };
          if (ppick) ppick.onclick = async () => { let got = null; try { got = await sysPick()(parent); } catch (e) { /* no dialog */ }
            if (got) { pinEl.value = parent = String(got); later(); } else pinEl.focus(); };
        }
        [nameEl, f2El, gEl].forEach((i) => { if (!i) return; i.oninput = later;
          i.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } }); });
        q("[data-tmback]").onclick = () => { pseq++; clearTimeout(timer); write(); };
        go.onclick = make;
        sync(); preview();
        if (wide()) setTimeout(() => { if (nameEl.isConnected) { nameEl.focus({preventScroll: true}); if (!sug) nameEl.select(); } }, 60);
      };
      const write = () => {
        root.innerHTML = `<h3>${head}</h3>
          <textarea class="pj-ta2" data-tx rows="2" maxlength="400" placeholder="${esc(tl("room.tm.ph"))}" aria-label="${esc(tl("room.tm.ph"))}"></textarea>
          <div class="pj-tmr"><button type="button" class="pj-text press" data-self>${tl("room.tm.self")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-ask><span class="pj-spin" hidden></span><span data-l></span></button></div>`;
        fade();
        const tx = root.querySelector("[data-tx]"), go = root.querySelector("[data-ask]"), lab = go.querySelector("[data-l]"), spin = go.querySelector(".pj-spin");
        let busy = false;
        tx.value = text;
        const sync = () => { go.disabled = !busy && !tx.value.trim(); spin.hidden = !busy; lab.textContent = busy ? tl("libDraw.22") : tl("room.tm.next"); tx.readOnly = busy; go.setAttribute("aria-busy", busy); };
        const run = async () => {
          if (busy) { seq++; busy = false; return sync(); }      // a press while it waits takes the question back
          text = tx.value.trim();
          if (!text) return;
          const my = ++seq; busy = true; sync();
          let r = null;
          try { r = await post("/api/depts/propose", {text, kind}); } catch (e) { r = null; }
          if (my !== seq || !root.isConnected) return;
          card(r && r.proposal ? r.proposal : own(text), !!(r && r.suggested));
        };
        go.onclick = run;
        root.querySelector("[data-self]").onclick = () => { seq++; text = tx.value.trim(); card(own(text), null); };
        tx.oninput = sync;
        tx.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); if (!busy) run(); } };
        sync();
        if (wide()) setTimeout(() => { if (tx.isConnected) tx.focus({preventScroll: true}); }, 60);
      };
      write();
    });
  }

  // ---- small panels that open over a sheet: the folder chooser and the icon picker -----------------
  // One appears at the button that opened it (a hair smaller, 140ms) and goes back into it; closed half-way,
  // it leaves from where the opening had got to. Reduced motion: a fade. A scroll inside it keeps
  // it open, and Tab stays inside it. off(false) closes without taking the focus back.
  function popFrom(pop, btn, o = {}) {
    document.body.appendChild(pop);
    // Below the button, else above it, else wherever it fits whole; fit() again when its size changes.
    const fit = () => {
      if (!btn.isConnected) return;
      const b = btn.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight, m = 8;
      const below = b.bottom + 6 + h <= innerHeight - m, above = b.top - 6 - h >= m;
      const left = Math.max(m, Math.min(o.align === "left" ? b.left : b.right - w, innerWidth - w - m));
      const top = below ? b.bottom + 6 : above ? b.top - 6 - h : Math.max(m, innerHeight - h - m);
      pop.style.left = Math.round(left) + "px"; pop.style.top = Math.round(top) + "px";
      pop.style.transformOrigin = `${Math.round(b.left + b.width / 2 - left)}px ${Math.round(b.top + b.height / 2 - top)}px`;
    };
    fit();
    if (pop.animate) pop.animate(RM() ? [{opacity: 0}, {opacity: 1}] : [{opacity: 0, transform: "scale(.98)"}, {opacity: 1, transform: "none"}],
      RM() ? {duration: 180, easing: "ease"} : {duration: 140, easing: "ease-out"});
    btn.setAttribute("aria-expanded", "true");
    let gone = false;
    const off = (refocus) => {
      if (gone) return; gone = true;
      if (btn.isConnected) btn.setAttribute("aria-expanded", "false");
      document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", key, true);
      removeEventListener("resize", size); removeEventListener("hashchange", away);
      if (window.Motion && Motion.menuOut) Motion.menuOut(pop); else pop.remove();
      if (refocus !== false && btn.isConnected) btn.focus({preventScroll: true});
      if (o.onOff) o.onOff();
    };
    const away = () => off(false);
    const out = (e) => { if (!pop.contains(e.target)) off(false); };
    const size = () => { if (!pop.contains(document.activeElement)) off(false); };   // a phone keyboard coming up is not a reason to close
    const key = (e) => {
      if (!pop.isConnected) return off(false);
      if (e.key === "Escape") { e.stopPropagation(); e.preventDefault(); if (!(o.onEsc && o.onEsc(e))) off(); return; }
      if (e.key !== "Tab") return;
      const f = [...pop.querySelectorAll("button,input")].filter((x) => !x.disabled && x.tabIndex >= 0 && x.offsetParent !== null);
      if (!f.length) return;
      const a = f[0], z = f[f.length - 1], at = document.activeElement;
      if (!pop.contains(at)) { e.preventDefault(); a.focus(); }
      else if (e.shiftKey && at === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && at === z) { e.preventDefault(); a.focus(); }
    };
    setTimeout(() => { if (gone) return; document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", key, true);
      addEventListener("resize", size); addEventListener("hashchange", away); }, 0);
    off.fit = fit;
    return off;
  }
  // Arrow keys move along a row or a grid of buttons; only the one in use takes Tab.
  function rove(box, sel = "button") {
    const cells = () => [...box.querySelectorAll(sel)].filter((x) => !x.disabled);
    const mark = (to) => { cells().forEach((c) => { c.tabIndex = c === to ? 0 : -1; }); };
    box.addEventListener("keydown", (e) => {
      const d = {ArrowLeft: -1, ArrowRight: 1, ArrowUp: "u", ArrowDown: "d", Home: "h", End: "e"}[e.key];
      if (d === undefined) return;
      const list = cells(), i = list.indexOf(document.activeElement); if (i < 0) return;
      const top = list[0].offsetTop, cols = Math.max(1, list.filter((c) => c.offsetTop === top).length);
      const j = d === "h" ? 0 : d === "e" ? list.length - 1 : i + (d === "u" ? -cols : d === "d" ? cols : d);
      if (j < 0 || j >= list.length) return;
      e.preventDefault(); e.stopPropagation(); mark(list[j]); list[j].focus();
    });
    return () => { const list = cells(); mark(list.find((c) => c.classList.contains("on")) || list[0]); };
  }

  const typedPath = (s) => String(s || "").trim().replace(/^"+|"+$/g, "").trim();
  const onThisPc = () => ["127.0.0.1", "localhost", "::1", "[::1]", ""].includes(location.hostname);
  // The system's own folder chooser: only the app window has it (app_main._Api.pick_folder).
  const sysPick = () => (window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder) ? window.pywebview.api.pick_folder : null;
  // A path as two parts, so a long one gives way in the middle: everything up to the last folder,
  // and the last folder itself.
  const splitPath = (p) => { p = String(p || "").replace(/[\\/]+$/, ""); const i = Math.max(p.lastIndexOf("\\"), p.lastIndexOf("/"));
    return i < 0 ? ["", p] : [p.slice(0, i), p.slice(i)]; };

  // 위치 바꾸기: where the new folder goes. Folders of this PC, one level at a time (the server
  // sends folder names only and refuses any place nothing may be made in). pick(path) on 여기로 정하기.
  // none() when Explorer's own chooser gave nothing back (closed, or it could not open): the caller
  // puts the caret in its path field, so that button never does nothing.
  async function folderPop(btn, start, name, pick, none) {
    document.querySelectorAll(".pj-pop,.pj-ov").forEach((p) => p.remove());
    let v;
    try { v = await post("/api/depts/folders", {path: start || ""}); } catch (e) { return toast(e.message); }
    if (!btn.isConnected) return;
    const pop = document.createElement("div");
    pop.className = "pj-ov pj-fp"; pop.tabIndex = -1; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.loc.change"));
    pop.innerHTML = `<div class="fp-side"><div class="fp-sh" aria-hidden="true">${tl("room.loc.places")}</div>
        <div class="fp-pl" data-pl role="group" aria-label="${esc(tl("room.loc.places"))}"></div></div>
      <div class="fp-main">
        <div class="fp-bar"><button type="button" class="fp-up press" data-up aria-label="${esc(tl("room.loc.up"))}" title="${esc(tl("room.loc.up"))}">${ic("up")}</button>
          <div class="fp-ad" data-addr><nav class="fp-cr" data-cr aria-label="${esc(tl("room.loc.path"))}"></nav>
            <input class="fp-ad-in" data-in type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.addrPh"))}" aria-label="${esc(tl("room.loc.edit"))}" hidden>
            <button type="button" class="fp-ed press" data-ed aria-label="${esc(tl("room.loc.edit"))}" title="${esc(tl("room.loc.editTip"))}">${ic("pen")}</button></div></div>
        <p class="fp-er" data-er role="alert" hidden></p>
        <div class="fp-ls" data-ls></div>
      </div>
      <div class="fp-ft"><p class="fp-say" data-say></p>
        <button type="button" class="fp-txt press" data-nf>${ic("plus")}<span>${tl("room.loc.newFolder")}</span></button>
        ${sysPick() ? `<button type="button" class="fp-txt fp-nat press" data-nat>${ic("ext")}<span>${tl("room.loc.explorer")}</span></button>` : ""}
        <span class="sp"></span><button type="button" class="btn sm fill press" data-ok>${tl("room.loc.here")}</button></div>`;
    const q = (s) => pop.querySelector(s);
    const pl = q("[data-pl]"), cr = q("[data-cr]"), ls = q("[data-ls]"), say = q("[data-say]"), ok = q("[data-ok]"), nf = q("[data-nf]"), up = q("[data-up]");
    const addr = q("[data-addr]"), inp = q("[data-in]"), er = q("[data-er]");
    const placeName = (p) => p.kind === "docs" ? tl("room.loc.docs") : p.kind === "desktop" ? tl("room.loc.desktop") : p.label;
    const placeIcon = (p) => ic(p.kind === "recent" ? "clock" : p.kind === "default" ? "home" : "folder");
    const fail = (text) => { er.textContent = text || ""; er.hidden = !text; off.fit && off.fit(); };
    let seq = 0;
    const paint = (focus) => {
      const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
      pl.innerHTML = (v.places || []).map((p) => `<button type="button" class="fp-pc press${same(p.path, v.path) ? " on" : ""}" data-p="${esc(p.path)}" title="${esc(p.path)}">${placeIcon(p)}<span>${esc(placeName(p))}</span></button>`).join("")
        + `<button type="button" class="fp-pc press${v.path ? "" : " on"}" data-p="pc">${ic("server")}<span>${tl("room.loc.pc")}</span></button>`;
      cr.innerHTML = `<button type="button" class="press" data-p="pc"${v.path ? "" : ' aria-current="true"'}>${tl("room.loc.pc")}</button>`
        + (v.crumbs || []).map((c, i, a) => `<i aria-hidden="true">${ic("chev")}</i><button type="button" class="press" data-p="${esc(c.path)}"${i === a.length - 1 ? ' aria-current="true"' : ""}>${esc(c.name)}</button>`).join("");
      cr.scrollLeft = cr.scrollWidth; cr.classList.toggle("cut", cr.scrollWidth > cr.clientWidth + 1);
      up.disabled = !v.up;
      ls.innerHTML = ((v.dirs || []).map((d) => `<button type="button" class="fp-row press" data-p="${esc(d.path)}">${ic(v.path ? "folder" : "server")}<span>${esc(d.name)}</span>${ic("chev")}</button>`).join("")
          || `<p class="fp-none">${tl("room.loc.empty")}</p>`)
        + (v.more ? `<p class="fp-none more">${tl("room.loc.more")}</p>` : "");
      ls.scrollTop = 0;
      ok.disabled = nf.disabled = !v.can;
      say.textContent = !v.can ? tl("room.loc.sayPc") : name ? tl("room.loc.say", {n: name}) : tl("room.loc.sayNew");
      fail(v.why);
      if (focus) (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    };
    const go = async (path, focus = true) => {
      const my = ++seq;
      try { const got = await post("/api/depts/folders", {path}); if (my !== seq || !pop.isConnected) return; v = got; paint(focus); off.fit(); }
      catch (e) { if (my === seq) toast(e.message); }
    };
    // The address bar. A press on a folder name goes there; a press on the empty part of the bar,
    // the pen, Ctrl+L, F4 or Alt+D turns it into a field holding the whole path, selected: copy it,
    // or paste or type another and press Enter. The server checks what was typed ({typed}); a path
    // it cannot open is said under the bar and the chooser stays where it was. Esc or leaving the
    // field brings the folder names back.
    const editing = () => addr.classList.contains("ed");
    const edit = () => {
      if (editing()) return inp.select();
      addr.classList.add("ed"); inp.hidden = false; inp.value = v.path || "";
      inp.focus({preventScroll: true}); inp.select();
    };
    const unedit = (focus) => {
      if (!editing()) return;
      addr.classList.remove("ed"); inp.hidden = true; fail(v.why);
      cr.scrollLeft = cr.scrollWidth;
      if (focus) (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    };
    const typed = async () => {
      const text = inp.value, my = ++seq;
      addr.classList.add("busy");
      let got = null;
      try { got = await post("/api/depts/folders", {path: text, typed: true}); }
      catch (e) { got = {err: "x", why: e.message}; }
      addr.classList.remove("busy");
      if (my !== seq || !pop.isConnected) return;
      if (got.err) {
        // The server's own sentence for a protected folder says which kind it is (Korean only).
        const said = {missing: tl("room.loc.err.missing"), network: tl("room.loc.err.network"), slow: tl("room.loc.err.slow"), form: tl("room.loc.err.form"),
          blocked: (window.I18N_LANG || "ko") === "ko" ? "" : tl("room.loc.err.blocked")}[got.err];
        fail(said || got.why);
        if (editing()) { inp.focus({preventScroll: true}); inp.select(); }
        return;
      }
      v = got; unedit(false); paint(true); off.fit();
    };
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); e.stopPropagation(); typed(); }
      else if (e.key !== "Escape" && e.key !== "Tab") e.stopPropagation();   // Backspace and the arrows are the field's own here
    });
    inp.addEventListener("input", () => { if (!er.hidden) fail(""); });
    inp.addEventListener("blur", () => setTimeout(() => { if (pop.isConnected && document.activeElement !== inp && document.hasFocus()) unedit(false); }, 0));
    addr.addEventListener("click", (e) => { if (!e.target.closest("button") && !editing()) edit(); });
    q("[data-ed]").onclick = (e) => { e.stopPropagation(); edit(); };
    pop.addEventListener("click", (e) => { const b = e.target.closest("[data-p]"); if (b && !b.closest(".fp-new")) go(b.dataset.p); });
    up.onclick = () => { if (v.up) go(v.up); };
    // Ctrl+L, F4, Alt+D: the path field, from anywhere in the chooser. Backspace goes up one unless
    // a field has the caret. In the list ↑↓ Home End walk the folders, ← goes up, → or Enter opens.
    pop.addEventListener("keydown", (e) => {
      const k = e.key, field = e.target.tagName === "INPUT";
      if (k === "F4" || ((k === "l" || k === "L") && (e.ctrlKey || e.metaKey) && !e.altKey) || ((k === "d" || k === "D") && e.altKey && !e.ctrlKey)) { e.preventDefault(); e.stopPropagation(); return edit(); }
      if (field) return;
      if (k === "Backspace" && v.up) { e.preventDefault(); return go(v.up); }
      if (!ls.contains(e.target)) return;
      const rows = [...ls.querySelectorAll(".fp-row")], i = rows.indexOf(document.activeElement);
      const to = {ArrowDown: i + 1, ArrowUp: i - 1, Home: 0, End: rows.length - 1}[k];
      if (to !== undefined) { e.preventDefault(); const t = rows[Math.max(0, Math.min(rows.length - 1, to))]; if (t) { t.focus({preventScroll: true}); t.scrollIntoView({block: "nearest"}); } }
      else if (k === "ArrowLeft" && v.up) { e.preventDefault(); go(v.up); }
      else if (k === "ArrowRight" && i >= 0) { e.preventDefault(); go(rows[i].dataset.p); }
    });
    // 새 폴더: a name typed in place, made on Enter, and the chooser steps into it.
    const endNew = () => { const r = ls.querySelector(".fp-new"); if (r) r.remove(); };
    nf.onclick = () => {
      if (ls.querySelector(".fp-new")) return ls.querySelector(".fp-new input").focus();
      const row = document.createElement("div");
      row.className = "fp-new";
      row.innerHTML = `${ic("folder")}<input type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.newPh"))}" aria-label="${esc(tl("room.loc.newPh"))}"><button type="button" class="btn sm fill press" disabled>${tl("room.loc.newMake")}</button>`;
      ls.prepend(row); ls.scrollTop = 0;
      const inp = row.querySelector("input"), mk = row.querySelector("button");
      inp.oninput = () => { mk.disabled = !inp.value.trim(); };
      const make = async () => {
        if (mk.disabled) return; mk.disabled = true;
        try { const r = await post("/api/depts/mkdir", {path: v.path, name: inp.value.trim()}); if (pop.isConnected) go(r.path); }
        catch (e) { toast(e.message); mk.disabled = false; inp.focus(); }
      };
      mk.onclick = make;
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } });
      inp.focus({preventScroll: true});
    };
    const nat = q("[data-nat]");
    if (nat) nat.onclick = async () => {
      nat.disabled = true;
      let p = null;
      try { p = await sysPick()(v.path || ""); } catch (e) { /* no dialog */ }
      nat.disabled = false;
      if (p) { if (pop.isConnected) await go(String(p)); } else if (none) { off(); none(); }
    };
    let off = {};   // paint() asks for a fit before the panel is on the page
    paint(false);
    off = popFrom(pop, btn, {onEsc: () => {
      if (editing()) { unedit(true); return true; }
      if (!ls.querySelector(".fp-new")) return false; endNew(); nf.focus(); return true; }});
    ok.onclick = () => { if (!v.can) return; pick(v.path); off(); };
    cr.scrollLeft = cr.scrollWidth;   // the first paint ran before it was on the page: the folder in hand is the end that shows
    (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    return off;
  }

  // 아이콘·색: the picture a project shows in the lists and the colour behind it. The pictures are
  // the app's emoji set (web/emoji.js); the colours are the app's own swatches (custom.js COLORS,
  // the yellow ones left out). An emoji is a picture and cannot be tinted, so the colour is a soft
  // tile behind it. st = {name, emoji, auto, color}; change({emoji?, color?}) on every pick
  // ("" = back to automatic).
  const TINTS = ["#e0563b", "#e08a2f", "#4caf6a", "#2fb8a8", "#2f9bd9", "#3d82f2", "#5e6ad2", "#7c5cff", "#b05fd9", "#d24b8f", "#8a8f98"];
  const tintAttr = (c) => /^#[0-9a-f]{6}$/i.test(c || "") ? ` style="--em-c:${c}"` : "";
  let randPool = null;
  function randomEmoji(not) {
    const EM = window.LOOP_EMOJI;
    if (!randPool) {
      const seg = window.Intl && Intl.Segmenter ? new Intl.Segmenter() : null;
      const all = EM ? EM.CONCEPTS.flatMap((c) => seg ? [...seg.segment(c[1])].map((x) => x.segment) : []) : [];
      randPool = [...new Set(all)];
      if (!randPool.length) randPool = EM ? EM.ALL.slice(0, 400).map((o) => o.e) : ["🗂"];
    }
    let e = not;
    for (let i = 0; i < 8 && e === not; i++) e = randPool[Math.floor(Math.random() * randPool.length)];
    return e;
  }
  // 스타일: emoji, or the Phosphor set in one of four weights (web/icons.js). The tab last used is
  // the person's default on this device; an icon already saved opens in the style it was saved in.
  const ICON_STYLES = ["regular", "bold", "fill", "duotone", "emoji"];
  const iconStyle = () => { try { const v = localStorage.getItem("v2-icon-style"); return ICON_STYLES.includes(v) ? v : "regular"; } catch (e) { return "regular"; } };
  function iconPop(btn, st, change, o = {}) {
    document.querySelectorAll(".pj-pop,.pj-ov").forEach((p) => p.remove());
    const EM = window.LOOP_EMOJI, IC = window.LOOP_ICONS;
    const had = IC && IC.parse(st.icon);
    let style = !IC ? "emoji" : had ? had.style : st.emoji ? "emoji" : iconStyle();
    const names = {emoji: tl("room.icon.st.emoji"), regular: tl("room.icon.st.regular"), bold: tl("room.icon.st.bold"), fill: tl("room.icon.st.fill"), duotone: tl("room.icon.st.duotone")};
    const pop = document.createElement("div");
    pop.className = "pj-ov pj-ip"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.icon.change"));
    pop.innerHTML = `<div class="ip-top"><span class="ip-h">${tl("room.icon.icon")}</span><span class="sp"></span>
        <button type="button" class="btn sm press" data-rand>${ic("dice")}<span>${tl("room.icon.random")}</span></button>
        <button type="button" class="btn sm press" data-auto>${tl("room.icon.auto")}</button></div>
      <div class="ip-sug" data-sug role="group" aria-label="${esc(tl("room.icon.suggest"))}"></div>
      <input class="ip-q" data-q type="search" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.icon.search"))}" aria-label="${esc(tl("room.icon.search"))}">
      ${IC ? `<div class="ip-seg" data-seg role="group" aria-label="${esc(tl("room.icon.style"))}">${ICON_STYLES.map((k) => `<button type="button" class="press" data-st="${k}">${names[k]}</button>`).join("")}</div>` : ""}
      <div class="ip-grid" data-grid role="group" aria-label="${esc(tl("room.icon.all"))}"></div>
      <div class="ip-top"><span class="ip-h">${tl("room.icon.color")}</span></div>
      <div class="ip-cols" data-cols role="group" aria-label="${esc(tl("room.icon.color"))}"></div>
      <div class="ip-foot"><button type="button" class="btn sm fill press" data-ipdone>${tl("lib.fil.done")}</button></div>`;
    const q = (s) => pop.querySelector(s);
    const sug = q("[data-sug]"), grid = q("[data-grid]"), cols = q("[data-cols]"), qEl = q("[data-q]"), seg = q("[data-seg]");
    const shown = () => st.emoji || st.auto || "";
    const isE = (e) => !st.icon && e === shown(), isI = (n) => st.icon === style + "/" + n;
    const kind = () => (style === "emoji" ? "e" : "i");
    const cell = (e, n) => `<button type="button" class="press${isE(e) ? " on" : ""}" data-e="${esc(e)}" title="${esc(n || e)}" aria-label="${esc(n || e)}" aria-pressed="${isE(e)}">${esc(e)}</button>`;
    const cellI = (n) => `<button type="button" class="press${isI(n) ? " on" : ""}" data-i="${n}" title="${n.replace(/-/g, " ")}" aria-label="${n.replace(/-/g, " ")}" aria-pressed="${isI(n)}">${IC.svg(style, n)}</button>`;
    const seatS = rove(sug), seatG = rove(grid), seatC = rove(cols), seatT = seg ? rove(seg) : () => {};
    const drawSeg = () => { if (seg) { seg.querySelectorAll("[data-st]").forEach((b) => { const on = b.dataset.st === style; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); }); seatT(); } };
    const drawSug = () => {
      sug.innerHTML = kind() === "e" ? (EM ? EM.suggest(st.name || "", [], 7) : []).map((e) => cell(e)).join("") : IC.suggest(st.name || "", 7).map(cellI).join("");
      seatS();
    };
    const drawGrid = () => {
      const v = qEl.value, res = kind() === "e" ? (EM ? EM.search(v, v.trim() ? 400 : 2000) : []).map((x) => cell(x.e, x.n)) : IC.search(v, 2000).map(cellI);
      grid.innerHTML = res.length ? res.join("") : `<p class="fp-none">${tl("depts.emoji.none")}</p>`;
      seatG();
    };
    const drawCols = () => {
      cols.innerHTML = `<button type="button" class="ip-c auto press${st.color ? "" : " on"}" data-c="" aria-pressed="${!st.color}">${tl("room.icon.auto")}</button>`
        + TINTS.map((c, i) => `<button type="button" class="ip-c press${c === st.color ? " on" : ""}" data-c="${c}" style="--em-c:${c}" aria-label="${esc(tl("room.icon.colorN", {n: i + 1}))}" aria-pressed="${c === st.color}"></button>`).join("");
      seatC();
    };
    const mark = () => pop.querySelectorAll("[data-e],[data-i]").forEach((b) => { const on = b.dataset.i ? isI(b.dataset.i) : isE(b.dataset.e); b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
    const setEmoji = (e) => { st.emoji = e; st.icon = ""; mark(); change({emoji: e, icon: ""}); };
    const setIcon = (n) => { st.icon = style + "/" + n; mark(); change({icon: st.icon}); };
    // The picked one in the middle of the grid, so a tab opens on what is in use.
    const reveal = () => { const on = grid.querySelector(".on"); grid.scrollTop = on ? Math.max(0, on.offsetTop - grid.offsetTop - (grid.clientHeight - on.offsetHeight) / 2) : 0; };
    // Another style: between two drawn sets the same icons stay where they are (only the drawing
    // changes, and the icon in use changes with it); emoji and icons each keep their own place.
    const tops = {};
    const setStyle = (k) => {
      if (k === style || !ICON_STYLES.includes(k)) return;
      const was = kind(), cur = IC.parse(st.icon);
      tops[was] = grid.scrollTop; style = k;
      try { localStorage.setItem("v2-icon-style", k); } catch (e) { /* this time only */ }
      drawSeg();
      if (was === "i" && kind() === "i") {
        pop.querySelectorAll("[data-i]").forEach((b) => b.firstElementChild.firstElementChild.setAttribute("href", `/icons/ph-${k}.svg#${b.dataset.i}`));
        if (cur) { st.icon = k + "/" + cur.name; change({icon: st.icon}); }
        return mark();
      }
      drawSug(); drawGrid();
      if (kind() in tops) grid.scrollTop = tops[kind()]; else if (st.icon || st.emoji) reveal();
    };
    pop.addEventListener("click", (ev) => {
      const t = ev.target.closest("[data-st]"); if (t) return setStyle(t.dataset.st);
      const i = ev.target.closest("[data-i]"); if (i) return setIcon(i.dataset.i);
      const b = ev.target.closest("[data-e]"); if (b) return setEmoji(b.dataset.e);
      const c = ev.target.closest("[data-c]"); if (c) { st.color = c.dataset.c; drawCols(); cols.querySelector(".on").focus({preventScroll: true}); change({color: st.color}); }
    });
    q("[data-rand]").onclick = () => {
      if (kind() === "e") return setEmoji(randomEmoji(shown()));
      let n = ""; for (let i = 0; i < 8 && (!n || isI(n)); i++) n = IC.NAMES[Math.floor(Math.random() * IC.NAMES.length)];
      setIcon(n); reveal();
    };
    q("[data-auto]").onclick = () => { st.emoji = ""; st.icon = ""; mark(); change({emoji: "", icon: ""}); if (o.autoCloses) off(); };
    let qT = 0; qEl.oninput = () => { clearTimeout(qT); qT = setTimeout(() => { delete tops.e; delete tops.i; drawGrid(); grid.scrollTop = 0; }, 120); };
    drawSeg(); drawSug(); drawGrid(); drawCols();
    const off = popFrom(pop, btn, {align: o.align || "left", onOff: o.onOff});
    q("[data-ipdone]").onclick = () => off();
    if (st.icon || st.emoji) reveal();               // a pick of the person's own; an automatic one opens at the top
    if (wide()) q("[data-rand]").focus({preventScroll: true});
    return off;
  }
  // A header button says it is open for as long as its menu is in the page, across redraws of
  // the header (the list is read again every few seconds).
  const popOpen = (k) => !!(railPops[k] && railPops[k].isConnected);
  const popBusy = (k) => popOpen(k) || performance.now() - (railPops[k + "@"] || 0) < 320;
  function expanded(k, q, pop) {
    railPops[k] = pop;
    const say = (v) => document.querySelectorAll(q).forEach((b) => b.setAttribute("aria-expanded", v));
    say("true");
    const mo = new MutationObserver(() => { if (pop.isConnected) return; mo.disconnect(); if (railPops[k] === pop) railPops[k] = null; railPops[k + "@"] = performance.now(); say("false"); });
    mo.observe(pop.parentNode, {childList: true});
  }
  // 보기: how the list looks, chosen in one place. Beside the button with a pointer, a sheet from
  // the bottom on a phone. A choice shows at once and the menu stays for the next one.
  // 작게 | 크게 marks, on the icon set's 256 grid with its 16-unit line.
  const SZI = (() => { const bar = (y) => `<rect x="32" y="${y - 8}" width="192" height="16" rx="8"/>`, pic = (d) => `<svg class="i" viewBox="0 0 256 256" aria-hidden="true">${d}</svg>`;
    return {sm: pic(bar(56) + bar(104) + bar(152) + bar(200)),
      md: pic(`<path d="M208,136H48a16,16,0,0,0-16,16v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,56H48V152H208v40Zm0-144H48A16,16,0,0,0,32,64v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V64A16,16,0,0,0,208,48Zm0,56H48V64H208v40Z"/>`)}; })();
  function viewMenu(btn, again) {
    if (popBusy("view")) return;
    // Marks from the app's icon set (Phosphor, regular weight); the three it has no key for are
    // drawn on the same 256 grid with the same 16-unit line.
    const bar = (y, w) => `<rect x="32" y="${y - 8}" width="${w || 192}" height="16" rx="8"/>`, pic = (d) => `<svg class="i" viewBox="0 0 256 256" aria-hidden="true">${d}</svg>`;
    const VI = {flat: ic("list"), folder: ic("folder"), sm: pic(bar(56) + bar(104) + bar(152) + bar(200)),
      md: pic(`<path d="M208,136H48a16,16,0,0,0-16,16v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,56H48V152H208v40Zm0-144H48A16,16,0,0,0,32,64v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V64A16,16,0,0,0,208,48Zm0,56H48V64H208v40Z"/>`),
      name: pic(bar(64) + bar(128, 136) + bar(192, 80)), recent: ic("clock"), reset: ic("sync")};
    const opt = (attr, v, on, label) => `<button class="press${on ? " on" : ""}" data-${attr}="${v}" aria-pressed="${on}">${VI[v]}<span>${label}</span></button>`;
    const act1 = (attr, v, label) => `<button class="va press" data-${attr}="${v}">${VI[v]}<span>${label}</span></button>`;
    const body = () => { const v = listView(), sm = folded("dense");
      return `<div class="vr"><span class="vl" id="pj-vm1">${tl("room.view")}</span><div class="seg" role="group" aria-labelledby="pj-vm1">${opt("view", "flat", v === "flat", tl("room.vFlat"))}${opt("view", "folder", v === "folder", tl("room.vFolder"))}</div></div>
        <div class="vr"><span class="vl" id="pj-vm2">${tl("room.size")}</span><div class="seg" role="group" aria-labelledby="pj-vm2">${opt("size", "sm", sm, tl("room.zSm"))}${opt("size", "md", !sm, tl("room.zMd"))}</div></div>
        <hr><div class="vr"><span class="vl" id="pj-vm3">${tl("ord.once")}</span><div class="vo" role="group" aria-labelledby="pj-vm3">${act1("once", "name", tl("ord.byName"))}${act1("once", "recent", tl("ord.byRecent"))}</div></div>
        <button class="vrs" data-reset="reset"${ordPlaced() ? "" : " disabled"}>${tl("ord.reset")}</button>`; };
    const wire = (host) => { const vm = host.querySelector(".pj-vm");
      const paint = (focus) => { vm.innerHTML = body(); vm.querySelectorAll("button").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const d = b.dataset;
        if (d.view) setView(d.view); else if (d.size) setFold("dense", d.size === "sm");
        else if (d.once) { if (ordOnce(d.once)) toast(tl("ord.onceDone")); }
        else { listOrd = {depts: [], sess: {}, flat: []}; ordSave(null); toast(tl("ord.resetDone")); }
        again(!!d.view); paint(Object.keys(d)[0] + "=" + Object.values(d)[0]); });
        if (focus) { const [k, v] = focus.split("="), f = vm.querySelector(`[data-${k}="${v}"]`); if (f) f.focus({preventScroll: true}); } };
      paint(); };
    if (!wide()) return sheet(`<div class="pj-dlg"><h3>${tl("room.view")}</h3><div class="pj-vm"></div></div>`, wire);
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop vm"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.view"));
    pop.innerHTML = `<div class="pj-vm"></div>`;
    wire(pop); popAt(pop, btn); expanded("view", "[data-viewmenu]", pop);
    // Opened from the keyboard: the keys carry on inside it.
    if (btn.matches(":focus-visible")) { const f = pop.querySelector("button.on"); if (f) f.focus({preventScroll: true}); }
    // Wider than what is left of its button: it stays over the list it changes, not over the menu beside it.
    const col = btn.closest(".pj-rail");
    if (col) pop.style.left = Math.max(parseFloat(pop.style.left), Math.min(col.getBoundingClientRect().left, innerWidth - pop.offsetWidth - 8)) + "px";
  }

  // 담당 세션 만들기: one named session to keep talking to, in a new folder of its own. The sheet
  // makes the project only; where the folder goes is shown (and can be changed on this PC) before
  // anything is made, with the icon it will carry in the lists. Its chat opens empty, and the
  // first line typed there opens the session that keeps the name. `from` is the button it was
  // opened with: on the PC the dialog grows from that side.
  async function newStanding(from) {
    let agents = {}, defRoot = "", parent = "";
    try { const d = await get("/api/depts"); agents = d.agents || {}; defRoot = d.default_root || ""; parent = d.parent || defRoot; } catch (e) { /* offer Claude alone */ }
    let agent = !agents.claude && agents.codex ? "codex" : "claude", seq = 0, ready = "", busy = false, timer = 0, made = "";
    const here = onThisPc(), st = {name: "", emoji: "", auto: "", color: "", icon: ""};
    const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
    sheet(`<h3>${tl("room.fixed.new")}</h3><p class="hint">${tl("room.fixed.lead")}</p>
      <div class="lbl">${tl("room.fixed.name")}</div>
      <div class="fx-nm"><button type="button" class="fx-ico press" data-ico aria-haspopup="dialog" aria-expanded="false" aria-label="${esc(tl("room.icon.change"))}" title="${esc(tl("room.icon.change"))}"><span class="pj-em" data-em></span><i class="fx-pen" aria-hidden="true">${ic("pen")}</i></button>
        <input class="tin" data-n type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.fixed.namePh"))}" aria-label="${esc(tl("room.fixed.name"))}"></div>
      <div class="lbl">${tl("room.fixed.task")}</div>
      <input class="tin" data-t type="text" maxlength="200" autocomplete="off" placeholder="${esc(tl("room.fixed.taskPh"))}" aria-label="${esc(tl("room.fixed.task"))}">
      ${agents.claude && agents.codex ? `<div class="lbl">${tl("depts.agent")}</div>
      <div class="seg wide" data-ag role="group" aria-label="${esc(tl("depts.agent"))}">${[["claude", "Claude Code"], ["codex", "Codex"]].map(([v, l]) =>
        `<button type="button" class="press${v === agent ? " on" : ""}" data-v2="${v}" aria-pressed="${v === agent}">${window.agDot(v)}${l}</button>`).join("")}</div>` : ""}
      <div class="lbl">${tl("room.loc.label")}</div>
      ${here ? `<div class="fx-loc ed"><input class="tin" data-pin type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("room.loc.label"))}"><button type="button" class="btn sm press" data-loc aria-haspopup="dialog" aria-expanded="false">${ic("folder")}<span>${tl("room.loc.pick")}</span></button></div>
      <div class="fx-new fx-res" data-path>${ic("folder")}<b data-pn></b></div>`
      : `<div class="fx-loc"><div class="fx-path" data-path><div class="fx-par"><span class="h" data-ph></span><span class="t" data-pt></span></div><div class="fx-new">${ic("folder")}<b data-pn></b></div></div></div>`}
      <p class="hint fx-note">${tl("room.loc.note")}${here ? ` <button type="button" class="fx-reset press" data-reset hidden>${tl("room.loc.reset")}</button>` : " " + tl("room.loc.onPc")}</p>
      <div data-pv aria-live="polite"></div>
      <button type="button" class="btn xl fill press" data-go disabled>${tl("depts.pv.make")}</button>`, (box) => {
      box.classList.add("pj-fx");
      if (from && from.isConnected && wide()) {              // grows from the side its button is on
        const b = from.getBoundingClientRect(), r = box.getBoundingClientRect();
        box.style.transformOrigin = `${Math.round(b.left + b.width / 2 - r.left)}px ${Math.round(b.top + b.height / 2 - r.top)}px`;
      }
      const q = (s) => box.querySelector(s);
      const nameEl = q("[data-n]"), taskEl = q("[data-t]"), pv = q("[data-pv]"), go = q("[data-go]"), ico = q("[data-ico]"), emEl = q("[data-em]");
      const loc = q("[data-loc]"), reset = q("[data-reset]"), pin = q("[data-pin]");
      const body = (dry) => Object.assign({name: nameEl.value.trim(), task: taskEl.value.trim(), agent},
        here ? {parent: same(parent, defRoot) ? "" : parent} : {}, st.emoji ? {emoji: st.emoji} : {}, st.color ? {color: st.color} : {}, st.icon ? {icon: st.icon} : {}, dry ? {dry_run: true} : {});
      const key = () => nameEl.value.trim() + "|" + agent + "|" + parent;
      const sync = () => { go.disabled = busy || !ready || ready !== key(); };
      // Where it goes: the place in a quiet line (a long one gives way in the middle), the new
      // folder's own name under it.
      const place = () => {
        const [h, t] = splitPath(parent), n = made || nameEl.value.trim();
        // The field is the person's while the caret is in it; otherwise it shows the place in use.
        if (pin) { if (document.activeElement !== pin) pin.value = parent; } else { q("[data-ph]").textContent = h; q("[data-pt]").textContent = t; }
        q("[data-pn]").textContent = n || tl("room.loc.nameSlot"); q("[data-pn]").classList.toggle("none", !n);
        q("[data-path]").title = parent + (n ? "\\" + n : "");
        if (reset) reset.hidden = same(parent, defRoot);
      };
      // Before a name is typed there is nothing to draw an emoji from: a plain line icon stands in.
      const face = () => emPut(emEl, st.emoji || st.auto || "🗂", st.color, st.icon || (st.emoji || st.auto ? "" : "regular/folder"));
      // The folder that would be made and the icon the name gets, asked of the server (nothing
      // is written by this).
      const preview = async () => {
        const my = ++seq, k = key(), n = nameEl.value.trim();
        st.name = n; made = "";
        if (!n) { ready = ""; st.auto = ""; pv.innerHTML = ""; face(); place(); return sync(); }
        get("/api/depts/emoji?name=" + enc(n)).then((r) => { if (my === seq && box.isConnected) { st.auto = r.emoji || ""; face(); } }).catch(() => {});
        try {
          // A typed place is checked the chooser's way first: it answers with the reason instead of a failed request.
          if (here && !same(parent, defRoot)) { const f = await post("/api/depts/folders", {path: parent}); if (my !== seq || !box.isConnected) return; if (f.why) throw new Error(f.why); }
          const p = (await post("/api/session/standing", body(true))).preview;
          if (my !== seq || !box.isConnected) return;
          made = splitPath(p.folder)[1].slice(1);
          if (p.parent && !here) parent = p.parent;
          pv.innerHTML = (p.warnings || []).map((w) => `<p class="hint">${esc(w)}</p>`).join("");
          ready = k;
        } catch (err) {
          if (my !== seq || !box.isConnected) return;
          pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = "";
        }
        place(); sync();
      };
      const later = () => { ready = ""; sync(); made = ""; place(); clearTimeout(timer); timer = setTimeout(preview, 220); };
      nameEl.oninput = later;
      box.querySelectorAll("[data-v2]").forEach((b) => b.onclick = () => {
        agent = b.dataset.v2;
        box.querySelectorAll("[data-v2]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        later();
      });
      ico.onclick = () => { if (ico.getAttribute("aria-expanded") === "true") return; iconPop(ico, st, face); };
      // A typed or pasted path is as good as a picked one (Explorer's "경로로 복사" wraps it in
      // quotes); the server checks it either way and says why not under the form.
      if (pin) pin.oninput = () => { parent = typedPath(pin.value) || defRoot; later(); };
      if (loc) loc.onclick = () => { if (loc.getAttribute("aria-expanded") === "true") return;
        folderPop(loc, parent, made || nameEl.value.trim(), (p) => { parent = p; if (pin) pin.value = p; place(); clearTimeout(timer); ready = ""; sync(); preview(); },
          () => { if (pin) { pin.focus(); pin.select(); } }); };
      if (reset) reset.onclick = () => { parent = defRoot; if (pin) pin.value = parent; place(); ready = ""; sync(); preview(); if (loc) loc.focus({preventScroll: true}); };
      const make = async () => {
        if (go.disabled) return;
        busy = true; sync();
        try {
          const r = await act("/api/session/standing", body(false));
          roomsCache = null; closeSheet();
          toast(tl("room.fixed.made", {n: r.title || r.name}));
          nav("project/" + enc(r.name));
        } catch (err) {
          busy = false; sync();
          if (err.message !== "cancelled") { pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = ""; sync(); }
        }
      };
      go.onclick = make;
      [nameEl, taskEl, pin].forEach((i) => i && i.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } }));
      face(); place(); preview();
      if (wide()) setTimeout(() => { if (nameEl.isConnected) nameEl.focus({preventScroll: true}); }, 60);
    });
  }

  // 아이콘·색 바꾸기 for a project that already exists: the same picker, saved as the person's
  // own choice (/api/custom/identity) on every pick; the lists are drawn again when it closes.
  function iconOf(btn, name, again) {
    const r = (roomsCache || []).find((x) => x.name === name) || {};
    const st = {name: pname(name), emoji: r.emoji || emoOf(name), auto: "", color: r.color || "", icon: r.icon || icoOf(name)};
    const face = btn.parentElement && btn.parentElement.querySelector(".pj-em,.em");
    let dirty = false, pend = Promise.resolve();
    iconPop(btn, st, (ch) => { dirty = true; pend = pend.then(async () => {
      try {
        const got = await post("/api/custom/identity", Object.assign({project: name}, ch));
        if (got.identity) { D.ident = Object.assign({}, D.ident, {[name]: got.identity}); }
        if (ch.emoji) r.emoji = ch.emoji;
        if ("color" in ch) r.color = ch.color;
        if ("icon" in ch) r.icon = ch.icon;
        if (typeof window.k3FaceSet === "function") window.k3FaceSet(name);
        if (face && face.isConnected) emPut(face, st.emoji || (got.identity && got.identity.emoji) || face.textContent, st.color, st.icon);
      } catch (e) { toast(e.message); }
    }); }, {align: "right", autoCloses: true, onOff: () => { if (dirty) pend.then(() => { roomsCache = null; if (again) again(); if (typeof drawChrome === "function") drawChrome(); }); }});
  }

  // The department header's own menu: open a terminal session (this PC), 정리 like the hub.
  function headMenu(btn, name, registered, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    const it = (a, icon, label, cls) => `<button data-a="${a}"${cls ? ` class="${cls}"` : ""}>${ic(icon)}<span>${label}</span></button>`;
    // The last one ENDS sessions (it was called 정리, the same word as hiding one from the list);
    // the server asks before it does.
    pop.innerHTML = it("sheet", "plus", tl("mn.new")) + (phoneList() ? "" : it("multi", "grid", tl("room.toMulti")))
      + moreRow((registered ? it("open", "code", tl("room.openTerm")) : "") + it("icon", "pen", tl("mn.icon")) + ordItems(btn.closest(".pj-sgl,.pj-srow")))
      + `<hr>` + it("tidy", "stop", tl("room.tidyDept"), "dz");
    const ordRow = btn.closest(".pj-sgl,.pj-srow");
    popAt(pop, btn);
    ordWire(pop, ordRow); moreWire(pop);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = async (e) => {
      e.stopPropagation(); pop.remove();
      if (b.dataset.a === "open") return openDept(name);
      if (b.dataset.a === "icon") return iconOf(btn, name, again);
      if (b.dataset.a === "sheet") return newChat(name);
      if (b.dataset.a === "multi") {
        const r = (roomsCache || []).find((x) => x.name === name);
        return pickPanes(r && r.sid ? [r.sid] : [], goMulti);
      }
      const was = btn.innerHTML;
      try {
        const r = await act("/api/session/tidy-dept", {name}, 0, (on) => { btn.disabled = on; btn.innerHTML = on ? loadingHtml("", {inline: true}) : was; }); showTidied = "";
        toast(r.message || tl("room.tidied")); if (r.stopped && again) again();
      }
      catch (err) { if (err.message !== "cancelled") toast(err.message); }
      finally { btn.disabled = false; btn.innerHTML = was; }
    });
  }

  // "← 대화" goes back to the list the room was opened from: 프로젝트별 (#project) or 최근 순
  // (#sessions). The origin is noted when the address moves from a list into a room and kept while
  // moving between rooms; it lives in sessionStorage so a reload keeps it. A room opened by its
  // address alone (a link, a new tab) has no origin and falls back to 프로젝트별.
  const isRoom = (h) => /^project\/./.test(h) && h !== "project/" + ALL;
  let lastHash = location.hash.slice(1), roomFrom = "project";
  try { if (isRoom(lastHash) && sessionStorage.getItem("v2-roomfrom") === "sessions") roomFrom = "sessions"; } catch {}
  addEventListener("hashchange", () => {
    const h = location.hash.slice(1);
    if (isRoom(h) && !isRoom(lastHash)) {
      roomFrom = lastHash.split(/[/?]/)[0] === "sessions" ? "sessions" : "project";
      try { sessionStorage.setItem("v2-roomfrom", roomFrom); } catch {}
    }
    lastHash = h;
  });
  const backToList = () => nav(roomFrom === "sessions" ? roomFrom : listHash());
  // A phone's list page (#project) and the chat opened from it. `listAt`: this draw is the list
  // page. A chat opened from the list is one step ahead of it, so going back to the list is the
  // browser's own Back (and its back swipe); a chat reached any other way puts the list in its place.
  let listAt = false, lastChat = {name: "", sid: ""}, listY = 0, listHop = "", seenPrev = "";
  const fromList = (hash) => { listY = scrollY; nav(hash); listHop = location.hash; };
  const toList = () => { if (listHop && listHop === location.hash && history.length > 1) history.back(); else location.replace("#project"); };

  // ---- #project/<name>[/<sid>] ---------------------------------------------------------------------
  // What /api/project last said, per project: a conversation picked in the list is shown from
  // it at once, and the answer that follows only writes what differs.
  const projSeen = {};
  // When the person last pressed or typed: what changes by itself afterwards does not glide.
  let actedAt = -1e9;
  ["pointerdown", "keydown"].forEach((t) => addEventListener(t, () => { actedAt = performance.now(); }, true));
  async function drawProject(el, name, sid, my) {
    let v, shown = "", wait = 0, up = false;
    const seen = projSeen[name];
    // A page that is up stays up: the list, the chat's frame and what is typed are kept, and only
    // what changed is written. The loading page is for a cold start alone (a link straight to a
    // conversation with nothing drawn yet), and only once the answer has taken 300ms.
    // The last answer is painted only when it brings the picked chat sooner (seenPaint): a page
    // that already shows this chat waits the moment for the fresh answer, so a row that came
    // since is never taken out and put back.
    if (el.querySelector(".pj-cols")) {
      up = true;
      if (!pendNew[name] && seenPaint(seen && seen.v, sid, sid === NEW, seenAt === name + "/" + (sid || ""))) { shown = seen.k; projShow(el, name, sid, my, seen.v); }
    } else {
      const cold = () => {
        if (!live(my) || el.querySelector(".pj-cols") || el.querySelector("rl-load")) return;   // a loader already up stays as it is
        el.innerHTML = loadingHtml(tl("room.loading"), {fill: true});
      };
      // Nothing drawn yet: the loader is put in at once (its mark still waits its own 250ms, so a fast
      // answer shows nothing), instead of leaving a blank page for 300ms first.
      if (!el.firstElementChild) cold(); else { wait = setTimeout(() => { cold(); }, 300); timers.add(wait); }
    }
    try { v = await readOrAsk("/api/project?name=" + enc(name)); }
    catch (e) { clearTimeout(wait); if (live(my) && !shown && !up) el.innerHTML = `<div class="pj-empty">${esc(e.message)}</div>`; return; }
    clearTimeout(wait);
    if (!live(my)) return;
    const k = JSON.stringify(v);
    if (!v.need_consent) projSeen[name] = {k, v: JSON.parse(k)};
    if (k !== shown) projShow(el, name, sid, my, v);
    stop.sweep();
  }
  function projShow(el, name, sid, my, v) {
    // The list is shown, but Codex's records are not read yet (an install that connected Codex
    // before connecting asked for it): offered once, as a bar over the session list that holds
    // nothing up. From then on it waits in settings, like a question answered "later".
    if (v.offer_consent && !offered) {
      offered = true; readOffer = v.offer_consent;
      post("/api/consent/defer", {scope: readOffer.scope}).catch(() => {});
    }
    if (v.need_consent) {
      el.innerHTML = `<button class="pj-back press" data-b>← ${tl("menu.chat")}</button>
        <div class="pj-empty">${tl("pjx.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("pjx.askAgain")}</button></div>`;
      el.querySelector("[data-b]").onclick = backToList;
      el.querySelector("[data-retry]").onclick = () => draw(el);
      return;
    }
    // Ended sessions this app did not open (s.old) stay out of the list: one folded row at its
    // bottom shows them in place. One of them opened by its address is shown like any other.
    const open1 = sid && sid !== NEW ? sid : "", shows = (s) => listed(s, tidOn());
    topPins = new Set(v.top_pins || []);
    const all = v.sessions || [], vis = all.filter((s) => shows(s) && !s.old);
    const olds = all.filter((s) => s.old && shows(s));
    all.forEach((s) => { s.pinned = !!v.pin && s.id === v.pin; if (s.pinned && v.standing) s.fixed = v.standing; });
    const hidden = all.filter((s) => s.tidied).length;
    // The chat is the page: with no session in the address, the one that is up (or the newest) opens.
    // The department's own session (its pin) comes first, like the hub's room.
    // A session opened a moment ago with no id yet: wait for it here, do not open an older one.
    // One that has its id but is not in the list yet (its record is not read yet, or may not be
    // read at all) waits the same way: the page never falls back to the empty draft with the line gone.
    const hit = sid && sid !== NEW ? all.find((s) => s.id === sid) : null, pp = pendNew[name];
    const pn = pendFor(pp, sid, !!hit, Date.now());
    if (!pn) delete pendNew[name];
    const cur = pn || sid === NEW ? null : hit || vis.find((s) => s.pinned) || pickCurrent(vis);
    // 새 세션, or a project with no session to open: the chat is there anyway, ready to type in.
    // Nothing is opened (and nothing is sent for the person) until the first line goes out.
    if (sid === NEW) draftGone.delete(name);
    const draft = !cur && !pn;
    // A standing project nobody has talked to yet: the empty chat is the standing session to come.
    const fixedNew = draft && v.standing && !v.pin ? v.standing : "";
    // (An older session opened by its address no longer unfolds the old rows: railHTML shows it apart.)
    if (cur) lastOpen = {name, sid: cur.id};
    // The project's own conversation (its pin): said in words under the name, not only a pin mark.
    const own = all.find((s) => s.pinned);
    const head = Object.assign({}, v.dept, {fixed: fixedNew, fresh: sid === NEW});
    const three = document.documentElement.classList.toggle("pj3", threeNow());   // decided once per draw
    const two = document.documentElement.classList.toggle("pj2", !three && twoNow());
    const cols2 = three || two;                        // the list sits beside the chat
    tab = folded("tab") ? "side" : "conv";             // panes and the embed reset it to the chat
    // One pane (a phone): the list and the chat are two pages. A chat opened from anywhere else
    // shows the chat; its back arrow shows the list.
    const page = listAt && !cols2;                     // a phone's 대화: the list is the page (#project)
    const at = page ? "~list" : name + "/" + (sid || "");
    if (!cols2 && at !== seenAt) listOpen = false;
    if (page) listOpen = true;
    seenAt = at;
    const seenWas = seenPrev; seenPrev = at;
    const showRail = cols2 || listOpen || !!pn;
    const listOnly = !cols2 && listOpen && !pn;
    const bare = cols2 || !!cur || draft;              // the chat names itself: no page head above it
    const railOff = three && cur && folded("rail");
    const upN = vis.filter((s) => s.state !== "ended").length;
    // Folded (wide screens only): the list becomes a 40px strip that opens it again, and the chat
    // takes the room. Drawn in place so the chat under it keeps its scroll and its draft.
    const rail = () => {
      railNow = rail;
      const box = el.querySelector(".pj-rail"); if (!box) return;
      if (ORD && ORD.live()) return ORD.later(rail);
      if (SW && SW.live()) return SW.later(rail);
      box.dataset.pn = name;                           // split.js: the project the session rows belong to
      const off = three && cur && folded("rail"), y = box.scrollTop;
      // Where each row is now, to carry it to its new place (briefly) when the person moved it.
      const rk = (r) => r.dataset.sid || "p:" + r.dataset.p, ms = [listView(), sessQ, sessF, sessA].join("|");
      const was = box._ms === ms ? new Map([...box.querySelectorAll(".pj-srows .pj-srow")].map((r) => [rk(r), r.getBoundingClientRect().top])) : null;
      el.querySelector(".pj-cols").classList.toggle("no-rail", !!off);
      const html = off ? `<button class="pj-strip pj-anim press" data-fold="rail" aria-expanded="false" aria-label="${tl("pjx.listOpenUp", {n: upN})}" title="${tl("pjx.listOpenUp", {n: upN})}">${ICO.panel}<span class="c" aria-hidden="true">${ic("list")}<b>${upN}</b></span></button>`
        : railHTML(vis, cur, hidden, three && !!cur, {olds, draft, name, head, open: cur, rooms: bare ? roomsCache || roomsSeen || [] : null});
      // While the search field is being typed in only the rows change: the field, its caret and a
      // Korean syllable still being composed stay as they are.
      const sq0 = box.querySelector(".pj-sq"), rows0 = box.querySelector(".pj-srows");
      if (!off && sq0 && rows0 && sq0 === document.activeElement) {
        const t = document.createElement("div"); t.innerHTML = html;
        const r1 = t.querySelector(".pj-srows"); if (r1) rows0.replaceWith(r1);
      } else {
        // A redraw (the list is read again every few seconds) keeps the row the keyboard is on.
        const f = document.activeElement, fr = f && box.contains(f) && f.closest(".pj-srow,.pj-sgh"), fk = fr && fr === f ? [fr.dataset.sid, fr.dataset.p, fr.dataset.gf] : null;
        if (!off && box._off === false && box.firstElementChild) morphTo(box, html); else box.innerHTML = html;
        const sq1 = box.querySelector(".pj-sq"); if (sq1 && sq1.value !== sessQ) sq1.value = sessQ;
        if (fk) { const n = [...box.querySelectorAll(".pj-srow,.pj-sgh")].find((x) => (fk[0] && x.dataset.sid === fk[0]) || (!fk[0] && fk[1] && !x.dataset.sid && x.dataset.p === fk[1]) || (fk[2] && x.dataset.gf === fk[2])); if (n) n.focus({preventScroll: true}); }
      }
      // The selection bar is one line; where the header it replaces was two, the list keeps its place.
      const lh = !off && box.querySelector(".pj-lhd");
      // (as margin, not padding: the bar sticks, and what it covers while it does must stay one line tall)
      if (lh) { if (!lh.classList.contains("pj-pick")) lhdH = lh.offsetHeight; else { lh.style.marginBottom = ""; const d = lhdH - lh.offsetHeight; if (d > 0) lh.style.marginBottom = (parseFloat(getComputedStyle(lh).marginBottom) || 0) + d + "px"; } }
      if (!off) readBar(box, () => draw(el));
      box.scrollTop = y;
      lhFit(box); box.onscroll = () => lhMark(box);
      box._ms = ms; box._off = !!off;
      // Only after something the person did (a filter, a fold, a session closed). A list that
      // changed by itself (a refresh, a session that started elsewhere) is simply drawn anew.
      if (was && was.size && performance.now() - actedAt < 700) {
        const B = box.getBoundingClientRect(), rm = RM();
        box.querySelectorAll(".pj-srows .pj-srow").forEach((r) => { const t0 = was.get(rk(r)); if (t0 == null) return;
          const t1 = r.getBoundingClientRect().top, d = t0 - t1;
          if (Math.abs(d) < 2 || (t1 > B.bottom && t0 > B.bottom) || (t1 < B.top - 60 && t0 < B.top - 60)) return;
          r.animate(rm ? [{opacity: .35}, {opacity: 1}] : [{transform: `translateY(${d}px)`}, {transform: "none"}], {duration: rm ? 200 : 120, easing: rm ? "ease" : "ease-out"}); });
      }
      const hm = box.querySelector("[data-hm]");
      if (hm) hm.onclick = (e) => { e.stopPropagation(); headMenu(e.currentTarget, name, head.registered, () => draw(el)); };
      const sq = box.querySelector(".pj-sq");
      if (sq) sq.oninput = () => { sessQ = sq.value; rail(); };
      box.querySelectorAll("[data-f]").forEach((b) => b.onclick = () => { sessF = b.dataset.f; rail(); });
      // Claude | Codex: a press shows that tool's sessions alone, the same press again shows all.
      box.querySelectorAll("[data-ag]").forEach((b) => b.onclick = () => { const k = b.dataset.ag; setAgent(sessA === k ? "all" : k); rail(); const n = box.querySelector(`[data-ag="${k}"]`); if (n) n.focus({preventScroll: true}); });
      const fc = box.querySelector("[data-fclear]");
      if (fc) fc.onclick = () => { sessQ = ""; sessF = "all"; setAgent("all"); rail(); const n = box.querySelector(".pj-sq"); if (n) n.focus({preventScroll: true}); };
      // 세션 | 폴더별, a project folded or opened, the menus on a row and on a project's name.
      const refocus = (q) => { const b = box.querySelector(q); if (b) b.focus({preventScroll: true}); };
      box.querySelectorAll("[data-tg]").forEach((b) => b.onclick = () => {
        const [k, v] = b.dataset.tg.split("=");
        if (b.getAttribute("aria-pressed") === "true") return;
        if (k === "view") setView(v); else setFold("dense", v === "sm");
        rail(); if (k === "view") box.scrollTop = 0; refocus(`[data-tg="${k}=${v}"]`);
      });
      box.querySelectorAll("[data-srt]").forEach((b) => b.onclick = () => { setRecent(!byRecent()); rail(); box.scrollTop = 0; refocus("[data-srt]"); });
      const lm = box.querySelector("[data-lmore]");
      if (lm) lm.onclick = () => { setFold("more", !folded("more")); rail(); refocus("[data-lmore]"); };
      box.querySelectorAll("[data-gf]").forEach((b) => b.onclick = () => { const i = [...box.querySelectorAll("[data-gf]")].indexOf(b); setGfold(b.dataset.gf, b.getAttribute("aria-expanded") === "true"); rail(); const n = box.querySelectorAll("[data-gf]")[i]; if (n) n.focus({preventScroll: true}); });
      box.querySelectorAll("[data-gm]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const r = (roomsCache || roomsSeen || []).find((x) => x.name === b.dataset.gm);
        headMenu(b, b.dataset.gm, b.dataset.gm === name ? head.registered : !!(r && r.registered), () => draw(el)); });
      box.querySelectorAll("[data-sm]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const h = railRows.get(b.dataset.sm); if (h) menu(b, h.s, h.name, () => draw(el)); });
      box.querySelectorAll("[data-dm]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); draftMenu(b, b.dataset.dm, () => draw(el)); });
      // The new-session row has no session to open; while picking, a click only picks it.
      box.querySelectorAll("[data-dr]").forEach((c) => c.onclick = (e) => { if (!e.target.closest("[data-dm],.pj-pop")) pickClick(e, c); });
      // Up and down walk the rows (and the projects' names); down from the search field enters the
      // list, up from the first row goes back to it. No motion: it is pressed over and over.
      box.onkeydown = (e) => {
        if (e.altKey || e.ctrlKey || e.metaKey || e.isComposing) return;
        const t = e.target, at0 = t.closest && t.closest(".pj-srows .pj-srow,.pj-srows .pj-sgh");
        if ((e.key === "Enter" || e.key === " ") && at0 === t && t.matches(".pj-srow[data-p]")) { e.preventDefault(); return t.click(); }
        const d = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0; if (!d) return;
        const field = box.querySelector(".pj-sq"), stops = [...box.querySelectorAll(".pj-srows .pj-srow[tabindex],.pj-srows .pj-sgh")];
        if (t === field) { if (d > 0 && stops[0]) { e.preventDefault(); stops[0].focus(); } return; }
        if (at0 !== t) return;                         // inside a menu button: its own keys
        e.preventDefault();
        const to = stops[stops.indexOf(t) + d];
        if (to) to.focus(); else if (d < 0 && field) field.focus();
      };
      const nb = box.querySelector("[data-newsess]");
      if (nb) nb.onclick = () => { listOpen = false; if (page) return fromList("project/" + enc(name) + "/" + NEW); if (sid === NEW) draw(el); else nav("project/" + enc(name) + "/" + NEW); };
      const nm = box.querySelector("[data-newmenu]");
      if (nm) nm.onclick = (e) => { e.stopPropagation(); newMenu(nm); };
      const pk = box.querySelector("[data-pickon]");
      if (pk) pk.onclick = () => { pickStay = true; pickShow(); refocus("[data-pk=off]"); };
      const ob = box.querySelector("[data-old]");
      if (ob) ob.onclick = () => {
        showOld = !showOld;
        if (showOld && bare && oldInfo.only) { oldRooms = null; loadOld().then(() => { if (live(my)) rail(); }); }
        rail();
      };
      box.querySelectorAll("[data-p]").forEach((c) => c.onclick = () => { listOpen = false; if (page) return fromList("project/" + enc(c.dataset.p)); if (c.dataset.p !== name || sid === NEW) nav("project/" + enc(c.dataset.p)); else if (listOnly) draw(el); });
      const dup = box.querySelector("[data-dup]");
      if (dup) dup.onclick = async () => {
        try {
          const done = (await act("/api/session/tidy-many", {sids: dupSids.slice(), end: true})).sids || []; roomsCache = null; draw(el);
          toastAct(tl("pick.tidyDone", {n: done.length}), tl("pick.undo"), () => post("/api/session/untidy", {sids: done}).then(() => { roomsCache = null; draw(el); }).catch((e) => toast(e.message)));
        } catch (e) { toast(e.message); }
      };
      const tid = box.querySelector("[data-tid]");
      if (tid) tid.onclick = () => { showTidied = tidOn() ? "" : where().name; draw(el); };
      box.querySelectorAll("[data-dupx]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const k = b.dataset.dupx; dupOpen.has(k) ? dupOpen.delete(k) : dupOpen.add(k); draw(el); });
      box.querySelectorAll("[data-pm]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const k = b.dataset.pm; deptMore.has(k) ? deptMore.delete(k) : deptMore.add(k); draw(el); });
      const fold = box.querySelector("[data-past]");
      if (fold) fold.onclick = () => { showPast = !showPast; draw(el); };
      box.querySelectorAll("[data-sid]").forEach((c) => {
        const go = (e) => {
          if (e.target.closest("[data-more],[data-sm],[data-dupx],.pj-pop")) return;
          if (pickClick(e, c)) return;
          listOpen = false; setFold("list", false);
          if (cols2 && !c.classList.contains("on")) {
            box.querySelectorAll(".pj-srow.on").forEach((n) => { n.classList.remove("on"); n.removeAttribute("aria-current"); });
            c.classList.add("on"); c.setAttribute("aria-current", "true");
          }
          if (page) return fromList("project/" + enc(c.dataset.pn || name) + "/" + c.dataset.sid);
          if (listOnly && cur && c.dataset.sid === cur.id) draw(el); else nav("project/" + enc(c.dataset.pn || name) + "/" + c.dataset.sid);
        };
        c.onclick = go;
        c.onkeydown = (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === c) { e.preventDefault(); go(e); } };
      });
      box.querySelectorAll("[data-more]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); menu(b, all.find((s) => s.id === b.dataset.more), name, () => draw(el)); });
      splitMarks(el);
      box.querySelectorAll("[data-pk]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); pickDo(b.dataset.pk, b, () => draw(el)); });
      pickMarks(box);
      if (!off) talkPut(box);
    };
    el.onclick = (e) => {
      const f = e.target.closest("[data-fold]"); if (!f) return;
      const k = f.dataset.fold; setFold(k, !folded(k));
      // Side by side: the side that was just opened takes its room from the other side before it
      // takes a pane away; whenever a different number of panes fits, the page is drawn again.
      const o = k === "rail" ? "side" : "rail";
      if (splitDrawn(el) > 1 && !folded(k) && !folded(o) && splitCap(el) < splitDrawn(el)) { setFold(o, true); return draw(el); }
      if (splitWant(el) !== splitDrawn(el) || splitStale(el)) return draw(el);
      const fp = el.querySelector(".pj-pane.focus");
      if (k === "rail") rail();
      else { const c = fp ? convs[fp.dataset.pane] : cur && C(cur.id); el.querySelector(".pj-cols").classList.toggle("no-side", folded("side")); if (c) side(el.querySelector("#pj-side"), c.room || name, c); }
      colGrips(el);                                    // the side that opened takes its width from the other, never from the chat's 380px
      const back = el.querySelector(`[data-fold="${k}"]`); if (back) back.focus({preventScroll: true});
    };
    const y0 = (el.querySelector(".pj-rail") || {}).scrollTop || 0;      // the list keeps its place across a redraw
    const kept = !!el.querySelector(":scope>.pj-cols");
    const shell = (bare ? "" : `<button class="pj-back press" data-b>← ${tl("menu.chat")}</button>
      <div class="pj-head">${emAs("em", head.emoji, head.color, head.icon || icoOf(name))}
        <div class="tx"><h1>${esc(pname(name))}</h1><div class="fo">${esc(head.folder || "")}</div>
          ${own ? `<button class="ow press" data-own="${esc(own.id)}"><span class="k">${esc(tl("room.owner"))}</span><span class="t">${esc(title(own))}</span><span class="st">· ${esc(LABEL[kindOf(own.state, own.last)] || own.state || "")}</span>${agentTag(own.agent)}</button>`
            : all.length ? `<div class="ow"><span class="k">${esc(tl("room.ownerNone"))}</span></div>` : ""}</div>
        ${showRail && !railOff ? "" : `<button class="pj-btn light press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button>`}
        <button class="pj-more press" data-hm aria-label="${esc(tl("room.deptMenu"))}" style="margin:0">${ic("more")}</button></div>`) + `
      ${(cur || draft) && !bare ? `<button class="pj-cur press" data-cur aria-expanded="${listOpen}" style="margin-top:8px">${dot(cur ? kindOf(cur.state, cur.last) : "ended")}<span class="t">${esc(cur ? title(cur) : fixedNew || tl("room.newSess"))}</span>
         <span class="s">${listOpen ? tl("pjx.listFold") : tl("pjx.listOpenN", {n: vis.length})}</span></button>` : ""}
      <div class="pj-cols${three && cur && folded("side") ? " no-side" : ""}${listOnly ? " pj-listonly" : ""}" style="margin-top:${bare ? 4 : 14}px">
        ${showRail ? `<div class="pj-rail"></div>` : ""}
        <div class="pj-body" id="pj-body"></div>
        ${three && cur ? ["l", "r"].map((k) => `<div class="cgrip pj-g ${k}" data-grip="${k}" role="separator" aria-orientation="vertical" tabindex="0" aria-label="${esc(k === "l" ? tl("room.gripL") : tl("room.gripR"))}" title="${esc(tl("room.gripTip"))}"></div>`).join("") : ""}</div>`;
    if (kept) {
      morphTo(el, shell);
      const pc = el.querySelector(":scope>.pj-cols");
      pc.classList.toggle("no-side", !!(three && cur && folded("side"))); pc.classList.toggle("pj-listonly", !!listOnly); pc.style.marginTop = (bare ? 4 : 14) + "px";
    } else el.innerHTML = shell;
    rail();
    // The list keeps up on its own: what the open chat's header learns goes onto its row at once
    // (rowSync), and every row is read again every few seconds. Only the list is drawn again, so
    // the chat, its scroll and the line being typed are not touched - the page's own 30s redraw
    // is skipped while a text box has the caret, which in a chat is nearly always.
    rowSync = (id, st) => { if (live(my) && syncRow(all, roomsCache, id, st)) rail(); };
    clearInterval(listTimer);
    const myTimer = listTimer = setInterval(async () => {
      if (!live(my) || !el.isConnected) return clearInterval(myTimer);
      if (document.hidden || !el.querySelector(".pj-rail")) return;
      try {
        const [f] = await Promise.all([get("/api/project?name=" + enc(name)), quietRooms()]);
        if (!live(my)) return;
        (f.sessions || []).forEach((n) => syncRow(all, null, n.id, n));
        rail();
      } catch (e) { /* offline: the chat says so */ }
    }, LIST_EVERY);
    const rb = el.querySelector(".pj-rail");
    if (rb && cols2) rb.scrollTop = y0;
    // The projects in the list are the room list's: read again when it is not fresh.
    if ((cols2 || listOnly) && (!roomsCache || Date.now() - roomsAt > 15000)) loadRooms().then(() => { if (live(my)) rail(); }).catch(() => {});
    colGrips(el);
    const bk = el.querySelector("[data-b]");
    if (bk) bk.onclick = backToList;
    const ow = el.querySelector("[data-own]");
    if (ow) ow.onclick = () => { listOpen = false; nav("project/" + enc(name) + "/" + enc(ow.dataset.own)); };
    const cb = el.querySelector("[data-cur]");
    if (cb) cb.onclick = () => { listOpen = !listOpen; setFold("list", listOpen); draw(el); };
    shownCur = three && cur ? {id: cur.id, p: name} : null;
    const sp = shownCur ? splitPlan(el, cur, name) : null;
    // What the chat column shows. The same thing as before is left as it is: its lines, its
    // scroll, its box and its loops carry on. Another conversation is drawn into the same column.
    const pb0 = el.querySelector("#pj-body"), bkey = [sp ? "split" : cur ? "s:" + cur.id : pn ? "pend" : "draft:" + name, three, cols2, bare].join("|");
    const same = pb0._pjKey === bkey && pb0.firstElementChild;
    el.querySelector(".pj-cols").classList.toggle("pj-sp", !!sp);
    if (!sp) { const old = pb0.querySelector(":scope>.pj-split"); if (old) old.remove(); }
    if (sp) splitDraw(el, sp, name, all, my);
    else if (cur) {
      if (!same || !pb0._pjRun) {
        const swap = kept && !same && !!pb0.querySelector(":scope>.pj-conv");
        drawSession(pb0, el, name, cur, my);
        const m = swap && pb0.querySelector("#pj-msgs"); if (m) m.classList.add("pj-swap");
      }
    }
    else if (pn) {
      // The line that was sent stays on the page while its session is on the way.
      const pb = pb0; endRun(pb);
      pb.innerHTML = `<div class="pj-pendc" data-pend><div class="pj-msgs">${pendRow({text: pn.text, busy: !pn.late, tag: pn.late ? "" : tl("room.pendNew")}, 0)}</div>
        ${pn.late ? `<div class="pj-empty" role="alert">${tl("room.openLate")}<br><button class="pj-btn light press" style="margin-top:12px" data-recheck>${tl("room.recheck")}</button></div>` : ""}</div>`;
      const rc = pb.querySelector("[data-recheck]");
      if (rc) rc.onclick = () => { pn.late = false; pn.at = Date.now(); roomsCache = null; draw(el); };
      waitNew(name, pn, my);
    }
    // On a phone the draft opens unfocused: a focused box means body.typing, which hides the tab bar.
    else if (!same) { endRun(pb0); drawDraft(pb0, name, head, wide()); }
    pb0._pjKey = bkey;
    // Beside the list the chat names itself: the conversation, then project · agent · when.
    const conv = !sp && bare && el.querySelector("#pj-body .pj-conv");
    const nth0 = conv && conv.querySelector(":scope>.pj-nth");
    if (nth0) nth0.remove();
    if (conv) conv.insertAdjacentHTML("afterbegin", `<div class="pj-nth${cur && !sessName(cur, name).includes(pname(name)) ? "" : " pn"}">${cols2 ? "" : `<button class="pj-more press" data-list aria-label="${esc(tl("room.listBack"))}" title="${esc(tl("room.listBack"))}">${ic("back")}</button>`}<div class="tx"><div class="t">${(cur ? cur.fixed : fixedNew) ? pinMk() : ""}${esc(cur ? sessName(cur, name) : fixedNew || tl("room.newSess"))}</div>
      ${cur ? "" : `<div class="s">${esc([pname(name), (draftAgent[name] || head.agent) === "codex" ? "Codex" : "Claude Code", tl("room.draftRow")].join(" · "))}</div>`}</div>
      ${railOff ? `<button class="pj-btn press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button>` : ""}
      ${cur && !cols2 ? `<button class="pj-more press" data-res data-t="side" aria-label="${esc(tl("pj.tab.side"))}" title="${esc(tl("pj.tab.side"))}">${ic("tray")}</button>` : ""}</div>`);
    const nb = el.querySelector("[data-new]");
    if (nb) nb.onclick = () => nav("project/" + enc(name) + "/" + NEW);
    const lb = el.querySelector("[data-list]");
    if (lb) lb.onclick = () => { if (phoneList()) return toList(); listOpen = true; draw(el); };
    if (!cols2 && !page && (cur || draft)) lastChat = {name, sid: cur ? cur.id : NEW};
    // The list comes back where it was left.
    if (page && seenWas !== "~list" && listY) { const y = listY; scrollTo(0, y); requestAnimationFrame(() => { if (seenAt === "~list") scrollTo(0, y); }); }
    const hm = el.querySelector("[data-hm]");
    if (hm) hm.onclick = (e) => { e.stopPropagation(); headMenu(e.currentTarget, name, head.registered, () => draw(el)); };
    const rsb = el.querySelector("[data-res]"), sideTab = el.querySelector(`.pj-seg [data-t="side"]`);
    if (rsb && sideTab) { rsb.onclick = () => sideTab.click(); const c = C(cur.id); side(el.querySelector("#pj-side"), name, c); }
    // Phone: the list is closed, so the bar goes under the chat's own header.
    if (!showRail) { let h = el.querySelector("#pj-body .pj-nth"); if (h && h.nextElementSibling && h.nextElementSibling.classList.contains("pj-state")) h = h.nextElementSibling; readBar(h ? h.parentNode : el.querySelector("#pj-body"), () => draw(el), h); }
    fit(); requestAnimationFrame(fit); phoneChat();
  }

  // Ask for the new session's id until Claude names it, then open that session (it is pinned by
  // then). Leaving the page stops the asking; after PEND_MAX the page falls back to the list.
  async function waitNew(name, pn, my) {
    while (pn.sid && live(my) && pendNew[name] === pn) {
      // It has its id: wait for the list to show it. Late is said in the pane, and the asking goes on.
      const v = await get("/api/project?name=" + enc(name)).catch(() => null);
      if (!live(my) || pendNew[name] !== pn) return;
      if (v && (v.sessions || []).some((s) => s.id === pn.sid)) { roomsCache = null; return render(); }
      if (!pn.late && Date.now() - pn.at > PEND_SID) { pn.late = true; return render(); }
      await new Promise((ok) => setTimeout(ok, pn.late ? 5000 : 1000));
    }
    while (live(my) && pendNew[name] === pn) {
      const r = await get("/api/project/job-session?job=" + enc(pn.job) + "&name=" + enc(name)).catch(() => null);
      if (!live(my) || pendNew[name] !== pn) return;
      if (r && r.sid) { delete pendNew[name]; roomsCache = null; return nav("project/" + enc(name) + "/" + enc(r.sid)); }
      if (Date.now() - pn.at > PEND_MAX) { delete pendNew[name]; toast(tl("room.pendLate")); return render(); }
      await new Promise((ok) => setTimeout(ok, 1500));
    }
  }

  // The list (left) and the results (right) drag wider from their inner edge: the item screen's
  // grip (v2.js wireColGrip), widths kept on this device like its --ipw.
  const PJW = {l: ["v2-pjrw2", [180, 300, 440], "--rw"], r: ["v2-pjsw", [240, 300, 560], "--sw"]};
  // Not dragged yet: the list grows a little with a wide window (300px up to 360px at 2250).
  const pjw0 = (k) => k === "l" ? Math.round(Math.max(PJW.l[1][1], Math.min(360, innerWidth * .16))) : PJW[k][1][1];
  const pjw = (k) => { try { return +localStorage.getItem(PJW[k][0]) || pjw0(k); } catch (e) { return pjw0(k); } };
  function colGrips(el) {
    const cols = el.querySelector(".pj-cols"); if (!cols) return;
    const px = (k) => parseFloat(getComputedStyle(cols).getPropertyValue(PJW[k][2])) || PJW[k][1][1];
    // Side by side the list gives way (down to its narrowest) until every pane has the chat's 380px.
    const chat = splitDrawn(el) > 1 ? splitDrawn(el) * 380 + (splitDrawn(el) - 1) * SP.GAP : 380;
    Object.keys(PJW).forEach((k) => {
      const [key, range, prop] = PJW[k], other = k === "l" ? "r" : "l";
      // The chat keeps at least 380px whatever the two sides ask for.
      const clamp = (w) => Math.round(Math.max(range[0], Math.min(w, range[2], cols.clientWidth - px(other) - 36 - chat)));
      el.style.setProperty(prop, clamp(pjw(k)) + "px");
      const g = cols.querySelector(`[data-grip="${k}"]`);
      if (!g || g.dataset.wired || typeof wireColGrip !== "function") return;   // fitted again on a width change
      g.dataset.wired = "1";
      wireColGrip(g, {range, dir: k === "l" ? 1 : -1, width: () => px(k),
        apply: (w) => { w = clamp(w); el.style.setProperty(prop, w + "px"); return w; },
        save: (w) => { try { localStorage.setItem(key, Math.round(w)); } catch (e) { /* this visit only */ } }});
    });
  }

  // The list, the chat and the results sit side by side when the page itself has room for the
  // narrowest three (180 + 380 + 240 and the gaps: PJW below): a 1280 window, or 1100 with the
  // app menu folded. Narrower: one at a time (at 1100 with the menu open the chat column was 138px
  // wide and its menu was clipped away). It used to be the window width (1360), which ignored a
  // folded menu. A draw measures (threeNow) and marks <html> with .pj3 for the CSS above;
  // threeCols() is the shape that was drawn, so everything between two draws agrees with it.
  const THREE_MIN = 880;
  const threeNow = () => { const v = document.getElementById("view"); return wide() && (v ? v.clientWidth : innerWidth - 350) >= THREE_MIN; };
  const threeCols = () => document.documentElement.classList.contains("pj3");
  // Two columns (list | chat) need less: any window from 1024 where the page keeps 620px.
  const TWO_MIN = 620;
  const twoNow = () => { const v = document.getElementById("view"); return wide() && (v ? v.clientWidth : innerWidth - 350) >= TWO_MIN; };
  // The session the page opens on: one that is up (working first), else the newest.
  const pickCurrent = (vis) => vis.find((s) => s.state === "live") || vis.find((s) => s.state === "idle" || s.state === "stuck") || vis[0] || null;

  // The conversation shown last (this run of the app only): 대화 opens on it again.
  let lastOpen = null, lhdH = 0;
  // The list's head sticks at the top of what scrolls: the list itself, or the page (then under the
  // page's top bar). `.scr` (rows have gone under it) draws the hairline below it.
  function lhMark(box) { box.classList.toggle("scr", box._lhOwn ? box.scrollTop > 0 : box.getBoundingClientRect().top < box._lhTop - 1); }
  function lhFit(box) {
    if (!box.querySelector(".pj-lh")) return;
    box._lhOwn = /auto|scroll/.test(getComputedStyle(box).overflowY);
    // Whatever bar is pinned over the list's column (the top bar; a style may bring its own): the head stops under it.
    let top = 0;
    if (!box._lhOwn) {
      const r = box.getBoundingClientRect();
      for (let y = -1, k = 0; y < top && k < 3; k++) for (let n of document.elementsFromPoint(r.left + r.width / 2, (y = top) + 1)) {   // bars may be stacked
        while (n && n !== document.body && !/fixed|sticky/.test(getComputedStyle(n).position)) n = n.parentElement;
        const b = n && n !== document.body && !box.contains(n) ? Math.round(n.getBoundingClientRect().bottom) : 0;
        if (b < innerHeight / 3) top = Math.max(top, b);                                    // a sheet over the page is not a bar
      }
    }
    // The head covers the rows under it with the colour of the panel it sits on, whatever the style made that.
    let bg = "";
    for (let e = box; e && !bg; e = e.parentElement) { const c = getComputedStyle(e).backgroundColor; if (!/^transparent$|, 0\)$/.test(c)) bg = c; }
    box.style.setProperty("--lh-bg", bg || "var(--bg)");
    box._lhTop = top;
    box.style.setProperty("--lh-top", box._lhTop + "px"); lhMark(box);
  }
  addEventListener("scroll", () => { const box = document.querySelector(".pj-rail"); if (box && box._lhOwn === false) lhMark(box); }, {passive: true});
  // Another theme or style: the panel's colour is read again (once more after a colour transition has run).
  new MutationObserver(() => { const fit = () => { const box = document.querySelector(".pj-rail"); if (box) lhFit(box); }; fit(); setTimeout(fit, 400); })
    .observe(document.documentElement, {attributes: true, attributeFilter: ["data-theme", "data-skin"]});
  // The first session row of the list as it would be drawn with no project open: the same rows,
  // order, view and filters as the list beside the chat (railHTML itself, read back).
  const topRow = (rooms) => {
    const t = document.createElement("template");
    t.innerHTML = railHTML([], null, 0, false, {rooms, name: "", head: {}, olds: []});
    const r = t.content.querySelector(".pj-srows .pj-srow[data-sid]");
    return r ? {name: r.dataset.pn, sid: r.dataset.sid} : null;
  };

  // The compact list: what is up first; finished sessions fold under one line (open when the
  // one being read is among them).
  // `x`: {olds, draft, name, head, rooms}. With `rooms` (the list sits beside the chat) it is the
  // whole list: 새 세션 on top, one card per project with the open project's sessions under its
  // card, and at the very bottom one folded row for the sessions made outside this app.
  function railHTML(vis, cur, hidden, canFold, x) {
    x = x || {};
    const up = vis.filter((s) => s.state !== "ended"), done = vis.filter((s) => s.state === "ended");
    const open = showPast || (cur && done.some((s) => s.id === cur.id));
    const sel = cur ? cur.id : "";
    const foldBtn = canFold ? `<span class="sp"></span><button class="pj-fbtn press" data-fold="rail" aria-expanded="true" aria-label="${tl("pjx.listFold")}" title="${tl("pjx.listFold")}">${ICO.panel}</button>` : "";
    const newBtn = `<button class="pj-btn light full press" data-newsess>${ic("plus")}<span>${tl("room.newSess")}</span></button>`;
    const sess = (x.draft ? `<div class="pj-card pj-row on" aria-current="true"><div class="r1">${dot("ended")}<div class="t">${tl("room.newSess")}</div></div>
        <div class="r2"><span>${tl("room.draftRow")}</span></div></div>` : "")
      + (up.length ? up.map((s) => card(s, sel)).join("") : x.draft ? "" : `<div class="pj-empty" style="text-align:left;padding:6px 2px">${tl("pjx.noneUp")}</div>`)
      + (done.length ? `<button class="pj-fold press" data-past aria-expanded="${open}">${ic("chev", "i")}<span>${tl("pjx.past", {n: done.length})}</span></button>`
        + (open ? done.map((s) => card(s, sel)).join("") : "") : "")
      + (hidden ? `<button class="pj-fold press" data-tid><span>${tidOn() ? tl("room.tidHide") : tl("room.tidShow", {n: hidden})}</span></button>` : "");
    const olds = x.olds || [], oldN = olds.length + (x.rooms ? oldInfo.only : 0);
    const others = x.rooms && showOld && oldInfo.only ? (oldRooms ? oldRooms.filter((r) => r.name !== x.name).map((r) => roomCard(r)).join("") : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`) : "";
    const old = oldN ? `<button class="pj-fold press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n: oldN})}</span></button>`
      + (showOld ? `<div class="pj-olds pj-anim">${olds.map((s) => card(s, sel)).join("")}${others}</div>` : "") : "";
    if (!x.rooms) return newBtn + `<div class="pj-lab">${tl("pjx.sess")} <span class="n">${up.length}</span>${foldBtn}</div>` + sess + old + unlinkRows();
    // Beside the chat: plain rows. The open project lists its sessions (what is up, then the
    // five newest that ended, the rest behind a fold); every other project shows the one it
    // would open on. "내 차례" is a reply not read yet, "작업 중" a session that is working.
    const list = ORD.arrange(x.rooms.some((r) => r.name === x.name) ? x.rooms
      : [...x.rooms, {name: x.name, emoji: x.head.emoji, agent: x.head.agent, registered: x.head.registered, sid: null}], listOrd.depts, (r) => r.name, (r) => r.born);
    ordKeys.depts = list.map((r) => r.name); ordKeys.sess = {};
    const PAST = 5, NEAR = 3, named = (t, name) => t && t !== "(제목 없음)" ? t : pname(name);
    const phone = phoneList(), flat = phone || listView() === "flat", norm = (t) => String(t || "").trim().toLowerCase();
    // One row: the session's title, its project, how it is doing, when. `same`: the title says
    // nothing the project's name does not, so the name is not said twice.
    railRows.clear();
    const seenRows = new Set();                       // the sessions the list below really draws
    const row = (r, o) => {
      if (o.turn && o.sid && isAnswered(o.sid, o.at)) o.turn = false;   // answered a moment ago: not the person's until the session moves on
      if (o.sid && !railRows.has(o.sid)) railRows.set(o.sid, {name: r.name, s: o.s || {id: o.sid, title: o.t, state: o.st || "ended", agent: o.agent || "claude", pinned: !!o.pinned, unread: +!!o.turn}});
      return Object.assign({pn: r.name, emo: r.emoji, ico: r.icon || "", col: r.color || "", k: o.st ? kindOf(o.st, o.at) : "", live: o.st === "live", same: norm(o.t) === norm(pname(r.name)) || norm(o.t) === norm(r.name)}, o);
    };
    const ofS = (r, s) => row(r, {t: flat ? sessName(s, r.name) : title(s), x: s.title && s.title !== "(제목 없음)" ? s.title : "", pin: !!s.fixed, st: s.state, at: s.last, born: s.started, agent: s.agent, on: s.id === sel, turn: !!s.turn && s.id !== sel, sid: s.id, s, ctx: s.context});
    // The standing session leads its project and is never folded away, ended or not.
    const own = vis.find((s) => s.fixed), rest = done.filter((s) => s !== own);
    // Every session the list knows: all of the open project's, and for the others the one each
    // would open on plus its newer ones (`more`, absent from an older server: then that one alone).
    const rowsOf = (r) => {
      if (r.name === x.name) return (x.draft && !draftGone.has(x.name) ? [row(r, {t: x.head.fixed || tl("room.newSess"), pin: !!x.head.fixed, draft: true, on: true, dr: true})] : [])
        .concat((own ? [own] : []).concat(up.filter((s) => s !== own), rest).map((s) => ofS(r, s)));
      if (!r.sid) return [row(r, {t: r.fixed || pname(r.name), pin: !!r.fixed, draft: true, mut: true, none: !r.fixed})];
      return [row(r, {t: r.fixed || (flat ? sessName(r, r.name) : named(r.title, r.name)), x: flat1(r.last) || r.first || (r.title !== "(제목 없음)" && r.title) || "", pin: !!r.fixed, st: r.state, at: r.at, born: r.sborn, agent: r.agent, turn: !!r.turn, sid: r.sid, pinned: r.pinned, ctx: r.context})]
        .concat((r.more || []).map((m) => row(r, {t: flat ? sessName(m, r.name) : title({id: m.sid, title: m.title}), x: m.first || (m.title !== "(제목 없음)" && m.title) || "", st: m.state, at: m.at, born: m.born, agent: m.agent, turn: !!m.turn, sid: m.sid, ctx: m.context})));
    };
    const groups = list.map((r) => ({r, all: rowsOf(r)})), every = [].concat(...groups.map((g) => g.all));
    // Two sessions of one project under the same title: when each began is said after it (o.began).
    dupSids = [];
    const dupLead = new Map(), dupN = new Map();          // an older twin's sid -> its newest's key; that key -> how many it stands for
    groups.forEach((g) => {
      const by = {};
      g.all.forEach((o) => { if (o.sid) (by[norm(o.t)] = by[norm(o.t)] || []).push(o); });
      // The older ones of a shared title can be put away in one press (dupSids): never one that is
      // pinned, open, at work or waiting on the person.
      // Until then they stand folded behind the newest one, which says how many (dupLead, dupN).
      Object.values(by).forEach((os) => {
        if (os.length < 2) return;
        const byNew = os.slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
        const put = byNew.slice(1).filter((o) => !o.pin && !(o.s && o.s.pinned) && !o.turn && !o.on && ["", "ended", "idle", "stale"].includes(o.k));
        if (!put.length) return;
        dupSids.push(...put.map((o) => o.sid));
        const lead = byNew[0].sid || "p:" + byNew[0].pn;
        put.forEach((o) => dupLead.set(o.sid, lead));
        dupN.set(lead, put.length);
      });
      Object.values(by).forEach((os) => { if (os.length > 1) os.forEach((o) => { const ms = tmMs(o.born); if (ms != null) o.began = new Date(ms).toLocaleString(tmLoc(), {month: "short", day: "numeric", hour: "numeric", minute: "2-digit"}); }); });
    });
    // 꺼진 부서: registered, nothing of it up, and no session of it in the list. The list is of
    // sessions, so it is not in it (nor found by the search): [새 세션]'s caret finds it and turns
    // it on. Not while one that was just started is still on its way into the list.
    const dark = groups.filter((g) => darkRoom(g.r) && g.r.name !== x.name && !g.all.some((o) => o.sid)
      && !(Date.now() - (startedAt[g.r.name] || 0) < START_HOLD)).map((g) => g.r), darkN = new Set(dark.map((r) => r.name));
    ordLast = {list, groups, every};
    // Three things narrow the list and they add up: the words looked for, 전체 | 내 차례 | 작업 중,
    // and Claude | Codex (offered only while both have sessions here). Each count says how many
    // rows that choice would show with the other two as they are.
    const q = foldQ(sessQ), agOf = (o) => o.agent === "codex" ? "codex" : "claude";
    const agBoth = new Set(every.filter((o) => o.sid).map(agOf)).size > 1, agF = agBoth ? sessA : "all";
    const okQ = (o) => !q || foldQ(o.t + " " + (o.x || "") + " " + o.pn + " " + pname(o.pn)).includes(q);
    // 작업 중 never holds a 내 차례 row: a session stopped on a prompt is the person's, though its process is up.
    // 내 차례: a row that was opened from this tab stays in it until the person leaves the tab
    // (it would otherwise go from under the pointer). The count is of the ones still waiting.
    if (sessF === "turn") every.forEach((o) => { if (o.turn && o.sid) turnHeld.add(o.sid); }); else turnHeld.clear();
    const okS = (o) => sessF === "all" || (sessF === "turn" ? o.turn || (!!o.sid && turnHeld.has(o.sid)) : o.live && !o.turn);
    const okA = (o) => agF === "all" || (o.draft && o.on) || agOf(o) === agF;
    const nTurn = every.filter((o) => o.turn && okQ(o) && okA(o)).length, nBusy = every.filter((o) => o.live && !o.turn && okQ(o) && okA(o)).length;
    const nAg = (k) => every.filter((o) => o.sid && agOf(o) === k && okQ(o) && okS(o)).length;
    const plain = !q && sessF === "all" && agF === "all";
    const keep = (o) => okS(o) && okQ(o) && okA(o) && !(plain && dupLead.has(o.sid) && !dupOpen.has(dupLead.get(o.sid)));
    dupUnder = new Map();
    if (plain) dupLead.forEach((lead, sid) => { if (!dupOpen.has(lead)) dupUnder.set(lead, (dupUnder.get(lead) || []).concat(sid)); });
    // Under the title: what it is doing (said only while it is up), the project in 세션 view unless
    // the title already is its name, Codex where it is not Claude.
    const sub = (o, lead, gm) => [o.draft ? tl("room.draftRow") : o.turn ? tl("room.fTurn") : o.k && o.k !== "ended" ? LABEL[o.k] : "", lead && o.x && o.x !== o.t ? o.x : lead && !o.same ? pname(o.pn) : "", gm && o.agent === "codex" ? "Codex" : ""].filter(Boolean).join(" · ") || LABEL.ended;
    const more = (attr, label) => `<button class="pj-more sr-m press" ${attr} aria-haspopup="menu" aria-label="${esc(label)}" title="${esc(label)}">${ic("more")}</button>`;
    // lead: the project's icon stands before the row (세션 view, and a project shown as one row);
    // without it the row sits under its project's name. `gm`: the menu is the project's own.
    // Before the title: how the session is doing, as an orb (web/orb.js). Working turns slowly;
    // 내 차례, 대기 and 막힘 barely move; an ended one is a still ring and a long-unused one a dot.
    // Each orb starts elsewhere in its cycle (from the session's id), so rows never move in step.
    // A project shown as one row keeps the project's own icon there. The tool the session was
    // opened in is said under the title: a dot in the tool's colour and its name.
    const agName = (o) => o.agent === "codex" ? "Codex" : "Claude Code";
    const ORB = {live: ["working", .5, 30], turn: ["listening", .15, 15], idle: ["breathing", .1, 15], stuck: ["solving", .08, 15]};
    const stOf = (o) => o.turn ? "turn" : o.k || "new";
    const phase = (id) => { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return (h % 2110) / 10; };
    const orb = (o) => {
      const k = stOf(o), m = ORB[k];
      // Ended, new and stale rows carry a quiet dot: a still dotted ring there read as a spinner.
      if (!m) return "<i></i>";
      // The compact list has no room for the orb at its full size, and a small one looks broken:
      // working, 내 차례 and stuck are a still dot there (the orb comes back in the 내 차례 / 작업 중 tabs).
      if (sm && k !== "idle") return `<i class="st-dot"></i>`;
      return `<rl-orb state="${m[0]}" size="20" px="${sm ? 14 : 24}" speed="${m[1]}" fps="${m[2]}" phase="${phase(keyOf(o))}" aria-label=""></rl-orb>`;
    };
    const stName = (o) => o.turn ? tl("room.fTurn") : o.draft ? tl("room.draftRow") : LABEL[o.k] || LABEL.ended;
    const agDot = (o, own) => `<i class="agdot agd${own ? " sr-ad" : ""}${o.agent === "codex" ? " cx" : ""}"${own ? ` role="img" aria-label="${agName(o)}" title="${agName(o)}"` : ""}></i>`;
    const cell = (o, gm) => gm ? `<span class="sr-e">${em(o.emo, o.col, o.ico)}</span>`
      : `<span class="sr-e sr-o" role="img" aria-label="${esc(stName(o))}" title="${esc(stName(o))}">${orb(o)}</span>`;
    // One line a row: how it is doing, who runs it and what was said are in the tooltip.
    const tip = (o, gm) => [stName(o), !gm && o.agent ? agName(o) : ""].filter(Boolean).join(" · ") + (o.x ? "\n" + o.x : "");
    // The card's state word takes the working hue; the rest of its line stays quiet.
    const stWord = (line, o) => stOf(o) === "live" && line.startsWith(esc(LABEL.live)) ? `<b class="sr-st">${esc(LABEL.live)}</b>` + line.slice(esc(LABEL.live).length) : line;
    const mk = (o, lead, gm) => {
      if (o.sid) seenRows.add(o.sid);
      const inert = !o.sid && o.pn === x.name;        // the chat being typed in: nothing to open
      const lc = cell(o, gm), who = !gm && !!o.agent;
      // In the flat list the name is the session's, so what was said follows it on the same line.
      const said = lead && !gm && o.x && o.x !== o.t ? `<span class="sr-q">${esc(Redact.show(o.x))}</span>` : "";
      const say = [o.t, o.began, stName(o), who ? agName(o) : "", o.at ? ago(o.at) : ""].filter(Boolean).join(", ");
      const face = lead && !gm ? faceMk(o.emo, o.col, o.ico) : "", shown = unEm(o.t, face || (gm && (o.emo || icoHtml(o.ico))));
      const twins = plain && dupN.get(keyOf(o)), twinOn = dupOpen.has(keyOf(o));
      const dupx = twins ? `<button class="sr-dup press" data-dupx="${esc(keyOf(o))}" aria-expanded="${twinOn}" aria-label="${esc(tl("room.dupMore", {n: twins}))}" title="${esc(tl("room.dupMore", {n: twins}))}">+${twins}</button>` : "";
      return `<div class="pj-srow s-${stOf(o)}${inert ? " inert" : " press"}${o.agent === "codex" ? " cx" : ""}${o.on ? " on" : ""}${o.mut ? " mut" : ""}${twinOf(o) ? " tw" : ""}" ${inert ? "" : `role="button" tabindex="0" aria-label="${esc(Redact.show(say))}" `}title="${esc(Redact.show(tip(o, gm)))}" ${o.sid ? `data-sid="${esc(o.sid)}" data-pn="${esc(o.pn)}"` : o.dr ? `data-dr="${esc(o.pn)}"` : inert ? "" : `data-p="${esc(o.pn)}"`}${o.on ? ` aria-current="true"` : ""}>
        ${lc}${gm ? more(`data-gm="${esc(o.pn)}"`, tl("room.deptMenu")) : o.sid ? more(`data-sm="${esc(o.sid)}"`, tl("pj.menu")) : o.dr ? more(`data-dm="${esc(o.pn)}"`, tl("pj.menu")) : ""}<span class="sr-x"><span class="sr-1">${face}<span class="sr-t${said ? " nm" : ""}">${esc(Redact.show(shown))}${o.began ? ` · ${esc(o.began)}` : ""}</span>${said}${topPinned(o) ? `<span class="pj-pinmk" title="${esc(tl("session.top.mark"))}">${ic("pin")}</span>` : ""}${o.pin ? pinMk() : ""}<span class="sr-w">${o.at ? esc(ago(o.at)) : ""}</span></span>
        <span class="sr-2"><span class="sr-s">${stWord(esc(Redact.show(sub(o, lead && !gm, gm))), o)}${who ? ` · ${agDot(o)}${agName(o)}` : ""}</span>${who ? agDot(o, true) : ""}${ctxRow(o.ctx)}${dupx}${o.turn ? `<span class="sr-ask">${tl("room.fTurn")}</span>` : ""}</span></span></div>`;
    };
    // A fixed order: a new session lands on top and stays there (a chat not opened yet is the
    // newest of all), and a row the person moved stays where it was put. In 폴더별 a standing
    // session leads its project until it is moved. What a session says or does never moves its row.
    // The compact list is for scanning everything; a filtered tab holds a few rows, which get the full-size orb.
    const sm = !phone && folded("dense") && sessF === "all", when = (o) => String(o.at || "");
    // 폴더별 | 세션 제목 and 크게 | 작게 (a new install opens in 폴더별, 작게): one click each, behind the head's 더보기.
    const tgl = (k, opts, label) => `<span class="pj-tg" role="group" aria-label="${esc(label)}">${opts.map(([v, i, t, on]) =>
      `<button class="press${on ? " on" : ""}" data-tg="${k}=${v}" aria-pressed="${on}" aria-label="${esc(t)}" title="${esc(t)}">${i}</button>`).join("")}</span>`;
    const keyOf = (o) => o.sid || "p:" + o.pn;
    // The twins a row unfolded stand right under it, newest first, wherever the order had them.
    const twinOf = (o) => (plain && o.sid && dupOpen.has(dupLead.get(o.sid)) ? dupLead.get(o.sid) : "");
    const stack = (rows) => {
      const tw = new Map();
      rows.forEach((o) => { const l = twinOf(o); if (l) tw.set(l, (tw.get(l) || []).concat(o)); });
      if (!tw.size) return rows;
      tw.forEach((os) => os.sort((a, b) => String(b.at || "").localeCompare(String(a.at || ""))));
      return [].concat(...rows.filter((o) => !twinOf(o)).map((o) => [o].concat(tw.get(keyOf(o)) || [])));
    };
    const bornOf = (o) => o.draft ? "~~" : !flat && o.pin ? "~" : o.born || "";
    // 최신순: the one switch that lets the clock order the rows (newest activity first), until it is turned off.
    const recent = byRecent(), newest = (L) => L.slice().sort((a, b) => Number(!!b.draft) - Number(!!a.draft) || when(b).localeCompare(when(a)));
    const order = (L, placed) => recent ? newest(L) : ORD.arrange(L, placed, keyOf, bornOf);
    // With 최신순 on the clock orders every row: a pinned session keeps its pin mark, not the top.
    const pinTop = (L) => recent ? L : topOrder(L);
    const tid = hidden ? `<button class="pj-fold pj-tidb press" data-tid><span>${tidOn() ? tl("room.tidHide") : tl("room.tidShow", {n: hidden})}</span></button>` : "";
    let rows;
    if (flat) {
      // 세션: every session by its title, in the one fixed order (no 오늘 / 어제 runs: the rows
      // no longer follow the clock).
      const L = every.filter((o) => !o.none);
      const all = pinTop(recent ? newest(L) : phone && !listOrd.flat.length ? phoneOrder(L, keyOf) : order(L, listOrd.flat));
      ordKeys.flat = all.filter((o) => o.sid).map(keyOf);
      rows = stack(all.filter(keep)).map((o) => mk(o, true)).join("");
    } else {
      // 폴더별: a project's name, then its sessions. A project that is one session wearing the
      // project's own name (a standing session, or a folder with a single talk named after it)
      // is one row, not a name with the same name under it.
      const shut = gfold();
      const top = (g) => g.all.reduce((m, o) => (when(o) > m ? when(o) : m), "");
      const gs = recent ? groups.slice().sort((a, b) => top(b).localeCompare(top(a))) : groups;
      if (recent) ordKeys.depts = gs.map((g) => g.r.name);   // as drawn: what a row placed by hand is kept from (ordCommit)
      rows = gs.map((g) => {
        const r = g.r, here = r.name === x.name, mine = pinTop(order(g.all, listOrd.sess[r.name])), hit = stack(mine.filter(keep));
        ordKeys.sess[r.name] = mine.filter((o) => o.sid).map(keyOf);
        if (!hit.length || darkN.has(r.name)) return "";
        const n = Math.max(r.sessions || 0, g.all.filter((o) => o.sid).length);
        if (g.all.length === 1 && n <= 1 && (g.all[0].same || g.all[0].none)) return `<div class="pj-sgrp" data-g="${esc(r.name)}">${mk(g.all[0], true, true)}</div>`;
        const open = !plain || !shut.has(r.name);
        // Where nothing is being looked for: the open project keeps its fold of older sessions, the
        // others show their newest few and the way to the rest.
        // Which few another project shows is still its newest (and the one it opens on); where they stand is not.
        // Every project folds the same way, open or not: its standing session and its newest few. Which
        // rows these are comes from the data (the standing pin, when each was last active), never from
        // which session is open, so opening one moves only the highlight. The fold's button toggles that
        // project's own fold (deptMore), it does not open the project.
        const wide = deptMore.has(r.name), pinOf = (o) => !!(topPinned(o) || o.pin || o.pinned);
        const near = new Set(hit.slice().sort((a, b) => pinOf(b) - pinOf(a) || when(b).localeCompare(when(a))).slice(0, NEAR).map(keyOf));
        const show = !plain || wide ? hit : hit.filter((o) => near.has(keyOf(o)) || topPinned(o) || (o.draft && o.on));
        const tail = !plain || hit.length <= NEAR ? "" : `<button class="pj-fold press" data-pm="${esc(r.name)}" aria-expanded="${wide}">${ic("chev", "i")}<span>${wide ? tl("room.pastHide") : tl("room.pastMore", {n: hit.length - NEAR})}</span></button>`;
        return `<div class="pj-sgrp" data-g="${esc(r.name)}"><div class="pj-sgl"><button class="pj-sgh press" data-gf="${esc(r.name)}" aria-expanded="${open}" title="${esc(pname(r.name))}">${em(r.emoji, r.color, r.icon)}<span class="nm">${esc(unEm(pname(r.name), r.emoji || icoHtml(r.icon)))}</span><span class="n">${n || ""}</span><span class="sp" style="flex:1"></span>${ic("chev", "i cv")}</button>${more(`data-gm="${esc(r.name)}"`, tl("room.deptMenu"))}</div>`
          + (open ? show.map((o) => mk(o, false)).join("") + tail : "") + `</div>`;
      }).join("");
    }
    // Nothing looked for and nothing here: say so (the older sessions below speak for themselves), not "no match".
    // Nothing under what is chosen: it says what is chosen, and one press clears all of it.
    const chosen = [agF === "codex" ? "Codex" : agF === "claude" ? "Claude" : "", sessF === "turn" ? tl("room.fTurn") : sessF === "busy" ? tl("room.fBusy") : "", sessQ.trim() ? `"${sessQ.trim()}"` : ""].filter(Boolean).join(" · ");
    rows = rows || (!plain ? `<div class="pj-empty pj-none"><span>${esc(tl("room.noMatchF", {what: chosen}))}</span><button class="pj-fclr press" data-fclear>${tl("room.fClear")}</button></div>` : oldN ? "" : `<div class="pj-empty">${tl("room.noSession")}</div>`);
    const home = list.find((r) => r.name === x.name);
    const oldRows = oldN && showOld ? `<div class="pj-olds pj-anim"><div class="pj-sgl"><span>${tl("room.oldLab")}</span></div>`
      + olds.map((s) => mk(ofS(home, s), true)).join("")
      + (oldInfo.only ? (oldRooms ? oldRooms.filter((r) => r.name !== x.name).map((r) => mk(row(r, {t: pname(r.name), st: r.state, at: r.at, agent: r.agent}), true)).join("")
        : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`) : "") + `</div>` : "";
    const oldBtn = oldN && plain ? `<button class="pj-fold pj-oldb press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n: oldN})}</span></button>` + oldRows : "";
    // The open session when the list does not draw it (opened from a link; hidden, older, or past the
    // fold): in its own marked spot on top, so it never takes a place among the rows or moves them.
    const op = x.open && x.open.id && !seenRows.has(x.open.id) && home ? ofS(home, x.open) : null;
    const apartHtml = op && keep(op) ? `<div class="pj-apart"><div class="pj-sgl"><span>${tl("room.openApart")}</span></div>${mk(op, true)}</div>` : "";
    const chip = (k, t, n) => `<button class="press${sessF === k ? " on" : ""}" data-f="${k}" aria-pressed="${sessF === k}">${t}${n ? ` <span class="num">${n}</span>` : ""}</button>`;
    const agChip = (k, t) => `<button class="press${k === "codex" ? " cx" : ""}${agF === k ? " on" : ""}" data-ag="${k}" aria-pressed="${agF === k}" title="${esc(tl("room.agOnly", {name: t}))}">${window.agDot(k)}<span>${t}</span><span class="num">${nAg(k)}</span></button>`;
    const agRow = agBoth ? `<div class="pj-agf" role="group" aria-label="${esc(tl("room.agFilter"))}">${agChip("claude", "Claude")}${agChip("codex", "Codex")}</div>` : "";
    // On a phone the search field and 새 세션 share one line.
    const newg = (c) => `<span class="pj-newg${c}"><button class="pj-btn pj-newb" data-newsess>${ic("plus")}<span>${tl("room.newSess")}</span></button><button class="pj-btn pj-newc" data-newmenu aria-haspopup="menu" aria-expanded="${popOpen("new")}" aria-label="${esc(tl("room.fixed.more"))}" title="${esc(tl("room.fixed.more"))}">${ic("chev")}</button></span>`;
    const sq = `<input class="pj-search pj-sq" type="search" value="${esc(sessQ)}" placeholder="${esc(tl("room.sessSearch"))}" aria-label="${esc(tl("room.sessSearch"))}">`;
    // The head (.pj-lh) stays put while the rows scroll under it: the search field with 더보기 beside it,
    // 새 세션, the three tabs. 더보기 folds how the list looks (view, size, order) and Claude | Codex; a dot
    // on it says a tool is chosen while it is shut. While picking, the bar takes 새 세션's line only.
    const moreOn = folded("more");
    const tgs = `<span class="pj-tgs">` + tgl("view", [["flat", ic("list"), tl("room.vFlat"), flat], ["folder", ic("folder"), tl("room.vFolder"), !flat]], tl("room.view")) + tgl("size", [["md", SZI.md, tl("room.zMd"), !sm], ["sm", SZI.sm, tl("room.zSm"), sm]], tl("room.size")) + `<span class="pj-tg"><button class="press${recent ? " on" : ""}" data-srt aria-pressed="${recent}" aria-label="${esc(tl("room.sortNew"))}" title="${esc(tl("room.sortNew"))}">${ic("sort-descending")}</button></span></span>`;
    const mrb = `<button class="pj-mrb press${agF !== "all" && !moreOn ? " fx" : ""}" data-lmore aria-expanded="${moreOn}" aria-label="${esc(tl("mn.more"))}" title="${esc(tl("mn.more"))}">${ic("sliders")}</button>`;
    return `<div class="pj-lh">${phone ? "" : `<div class="pj-lsr">${sq}${mrb}</div>`}` + (pickOn ? pickBar() : `<div class="pj-lhd${phone ? " ph" : ""}">${phone ? sq : newg("")}<button class="pj-pkb press" data-pickon>${tl("mn.pick")}</button></div>`) + `
      <div class="seg wide pj-sfil" role="group" aria-label="${esc(tl("room.sessSearch"))}">${chip("all", tl("room.fAll"))}${chip("turn", tl("room.fTurn"), nTurn)}${chip("busy", tl("room.fBusy"), nBusy)}</div>${phone ? agRow : `<div class="pj-lmo"${moreOn ? "" : " hidden"}>${tgs}${agRow}</div>`}</div>
      <div class="pj-srows${sm ? " sm" : ""}">${apartHtml}${rows}${plain && dupSids.length ? `<button class="pj-fold press" data-dup><span>${tl("room.dupHide", {n: dupSids.length})}</span></button>` : ""}${plain ? tid : ""}${oldBtn}${plain ? unlinkRows() : ""}</div>${phone && !pickOn ? newg(" pj-fab") : ""}`;
  }

  // ---- a session not opened yet -----------------------------------------------------------------
  // 새 세션 opens nothing by itself (Claude Code has no documented way to hold a background
  // session open without a first line, and a line is never sent in the person's name): the chat
  // is drawn empty with the box ready, and the first line typed opens the real session with it.
  // The model is the one chosen for new sessions (the line under the box changes it).
  // The model chip in the box's lower row and the popover above it: which model and how deep a
  // think this conversation gets. The chip names the pick where the next line will run on it (a
  // session not opened yet, an ended one that resumes with flags, a background job the server
  // starts again on it), with a hollow dot until it is really in effect; else what the session
  // is running on (/api/session/model says which, in `when`). A session opened in a window takes
  // no pick here: its rows are off. A draft keeps its pick here until its first line.
  const MSPARK = `<svg class="sk" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"/></svg>`;
  // No "default" row: the model a session runs on (or will start with) is the row that is marked,
  // with a small tag saying how that is known (now.source). Until a row is pressed nothing is
  // passed, so Claude Code's own default is what runs. A model that is not one of the list gets a
  // first row under its own name. Where nothing says which model it is, no row is marked and the
  // chip reads "모델": no name is made up.
  const MDESC = {"": (src) => src === "run" ? tl("mdl.dKeep") : tl("mdl.dSet"), fable: () => tl("mdl.dFable"), opus: () => tl("mdl.dOpus"),
    sonnet: () => tl("mdl.dSonnet"), haiku: () => tl("mdl.dHaiku")};
  const MTAG = {run: () => tl("mdl.tRun"), set: () => tl("mdl.tSet"), app: () => tl("mdl.tApp"), recent: () => tl("mdl.tRecent")};
  const EDESC = {"": () => tl("mdl.eDef0"), low: () => tl("mdl.eLow"), medium: () => tl("mdl.eMedium"),
    high: () => tl("mdl.eHigh"), xhigh: () => tl("mdl.eXhigh"), max: () => tl("mdl.eMax")};
  // The effort switch reads in the reader's language; the raw step names stay in the data.
  const ESHORT = {low: () => tl("mdl.sLow"), medium: () => tl("mdl.sMedium"), high: () => tl("mdl.sHigh"), xhigh: () => tl("mdl.sXhigh"), max: () => tl("mdl.sMax")};
  // Codex has the same chip over its own names: the models and the levels each one takes come from
  // the installed Codex (the server asks it), so a draft keeps a Codex pick apart from a Claude one.
  // chat-meter:begin
  // A token count as a person says it, a turn's few thousand still showing: 88300 -> "8.8만" / "88.3k".
  const ctxTok = (n) => {
    const f = (v, u) => (v >= 100 ? Math.round(v) : Math.round(v * 10) / 10) + u;
    return LANG() === "ko" ? (n >= 10000 ? f(n / 10000, "만") : n >= 1000 ? f(n / 1000, "천") : String(n)) : n >= 1e6 ? f(n / 1e6, "M") : n >= 1000 ? f(n / 1000, "k") : String(n);
  };
  // How full a conversation is, as one small number (the share where the CLI's record gives one,
  // else the length), orange from 90%. The whole sentence is the tooltip. `k` is the server's `context`.
  function ctxChip(k) {
    if (!k || !k.tokens) return "";
    const up = k.delta ? "+" + ctxTok(k.delta) : "";
    const say = [k.pct != null ? tl("ctx.pct", {pct: k.pct}) : tl("ctx.len", {n: ctxTok(k.tokens)}), k.window ? ctxTok(k.tokens) + " / " + ctxTok(k.window) : "", up ? tl("ctx.turn", {n: up}) : ""].filter(Boolean).join(" · ");
    return `<span class="pj-ctx${k.pct >= 90 ? " hot" : ""}" role="img" aria-label="${esc(say)}" title="${esc(say)}">${k.pct != null ? k.pct + "%" : ctxTok(k.tokens)}</span>`;
  }
  // Beside the model chip: a small ring for how full the conversation is. No number and no red;
  // the numbers are one press away (useCard). Orange only from 90%, where the CLI is about to compact.
  function ctxGauge(k) {
    if (!k || !k.tokens) return "";
    const C = 2 * Math.PI * 5.5, f = k.pct != null ? Math.max(0, Math.min(100, k.pct)) / 100 : 0;
    const say = k.pct != null ? tl("ctx.pct", {pct: k.pct}) : tl("ctx.len", {n: ctxTok(k.tokens)});
    return `<button class="pj-gauge press${k.pct >= 90 ? " hot" : ""}" data-gauge aria-haspopup="dialog" aria-expanded="false" aria-label="${esc(say)}" title="${esc(say)}"><svg viewBox="0 0 16 16" aria-hidden="true"><circle class="tr" cx="8" cy="8" r="5.5"/>${f ? `<circle class="ar" cx="8" cy="8" r="5.5" stroke-dasharray="${(C * f).toFixed(2)} ${C.toFixed(2)}"/>` : ""}</svg></button>`;
  }
  // The gauge's popover: the conversation's memory, then the plan's windows as far as there is a
  // reading (r: ConnUse.read's answer, or null), then the way to the whole usage screen.
  function useCard(k, r, when) {
    const row = (name, t, v, pct, hot) => `<div class="w${hot ? " hot" : ""}"><span class="k">${esc(name)}</span><span class="t">${esc(t || "")}</span><span class="v">${esc(v)}</span>`
      + (pct != null ? `<span class="bar" aria-hidden="true"><i style="width:${Math.max(2, Math.min(100, pct))}%"></i></span>` : "") + `</div>`;
    const size = k.window ? `${ctxTok(k.tokens)} / ${ctxTok(k.window)}` : ctxTok(k.tokens);
    const ctx = row(tl("use.ctx"), k.window && k.pct != null ? size : "", k.pct != null ? k.pct + "%" : size, k.pct, k.pct >= 90)
      + (k.pct >= 90 ? `<p class="s">${tl("use.ctxFull")}</p>` : k.delta ? `<p class="s">${esc(tl("use.turn", {n: ctxTok(k.delta)}))}</p>` : "");
    const wins = !r ? "" : (r.five != null ? row(tl("connuse.t.h5"), r.fiveResets ? tl("uz.reset", {t: when(r.fiveResets)}) : "", tl("connuse.v", {n: r.five}), r.five, r.five >= 90) : "")
      + (r.pct != null ? row(tl("connuse.t.wk"), r.resets ? tl("uz.reset", {t: when(r.resets)}) : "", tl("connuse.v", {n: r.pct}), r.pct, r.pct >= 90) : "");
    return `${ctx}<hr><h5>${tl("use.plan")}</h5>${wins || `<p class="s">${tl("connuse.none")}</p>`}<button type="button" class="go press" data-ugo>${tl("use.more")}</button>`;
  }
  // The same number on a list row or a widget block: only for who asked for it in settings (a bare
  // "93%" beside a session reads as nothing), and with the word in front.
  function ctxRow(k) {
    try { if (localStorage.getItem("v2-ctxrows") !== "1") return ""; } catch { return ""; }
    return ctxChip(k).replace(/(title="[^"]*">)/, "$1" + `<small>${esc(tl("ctx.word"))}</small>`);
  }
  // chat-meter:end
  const draftKey =(name, agent) => (agent === "codex" ? "codex\n" : "") + name;
  function modelChip(wrap, at) {                      // at: {sid} of a conversation, or {name, agent} of a draft
    let v = null, pop = null, sp = null, closing = false, wt = 0, sc = null;
    // The effort control is one mounted element kept across redraws of the popover, so its thumb
    // travels from where it was. Anything with this mount(el, {steps, value, onChange}) fits here.
    let em = null, emHost = null, emKey = "";
    const effortCtl = (host, o) => window.EffortMove.mount(host, o);
    const effLabel = (e) => e ? (ESHORT[e] ? ESHORT[e]() : e) : tl("room.modelBase");
    const effSay = (e) => {                             // while dragging: the level under the thumb, in words
      const a = pop && pop.querySelector("[data-el]"), b = pop && pop.querySelector(".ed");
      if (a) a.textContent = effLabel(e);
      if (b) b.textContent = e ? (EDESC[e] ? EDESC[e]() : "") : cx() ? tl("mdl.cx.eDef0") : EDESC[""]();
    };
    const dk = draftKey(at.name, at.agent);
    const url = "/api/session/model?" + (at.sid ? "sid=" + enc(at.sid) : "name=" + enc(at.name) + (at.agent === "codex" ? "&agent=codex" : ""));
    const pick = () => at.sid ? v.choice : draftModel[dk] || {model: "", effort: ""};
    const cx = () => v.agent === "codex";
    // The levels on offer: Claude's are one list, Codex's belong to the model that would run.
    const levels = (p) => cx() ? ((v.models.find((m) => m.id === (p.model || v.now.family)) || {}).efforts || []) : v.efforts;
    const live = () => v.when === "start" || v.when === "next";
    const off = () => v.when === "restart";              // a window's own session: nothing here changes it
    // A pick on a job takes a moment (it is started again), or waits for the answer in progress:
    // ask again until the server says it is in effect.
    const watch = () => {
      clearTimeout(wt);
      if (!at.sid || !v || !v.waits || v.stuck || v.when !== "next") return;
      wt = setTimeout(async () => {
        if (!wrap.isConnected) return;
        try { v = await get(url); } catch (e) { /* asked again below */ }
        show(pop && pop.contains(document.activeElement) && document.activeElement.parentNode ? document.activeElement.parentNode.dataset.g : "");
      }, 2000);
    };
    const face = () => {
      const p = pick(), m = live() && v.models.find((x) => x.id === p.model);
      // An effort nothing names is left out rather than called "default". The dot: filled while the next line will change something, hollow while a pick waits.
      return {model: m ? m.name : v.now.name || tl("mdl.none"), effort: (live() && p.effort) || v.now.effort || "",
        dot: v.waits ? "w" : live() && ((p.model && p.model !== v.now.family) || (p.effort && p.effort !== v.now.effort)) ? "on" : ""};
    };
    // The gauge beside the chip opens its own small card: fades in place, shut by a press outside or Esc.
    let up = null;
    const useWhen = (t) => { const d = new Date(t * 1000), hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
      return d.toDateString() === new Date().toDateString() ? hm : `${d.getMonth() + 1}/${d.getDate()} ${hm}`; };
    const useFill = () => {
      up.innerHTML = useCard(v.context, window.ConnUse && ConnUse.now ? ConnUse.now(cx() ? "codex" : "claude") : null, useWhen);
      const cr = (wrap.closest(".pj-conv") || document.body).getBoundingClientRect(), wr = wrap.getBoundingClientRect(), gr = wrap.querySelector(":scope>.pj-gauge").getBoundingClientRect();
      const w = Math.min(264, cr.width - 16);
      up.style.width = w + "px";
      up.style.left = Math.max(cr.left + 8, Math.min(gr.left + gr.width / 2 - w / 2, cr.right - 8 - w)) - wr.left + "px";
      up.style.maxHeight = Math.max(160, wr.top - cr.top - 16) + "px";
    };
    const useOut = (e) => { if (e.type === "keydown" ? e.key === "Escape" : !up.contains(e.target) && !e.target.closest("[data-gauge]")) useShut(); };
    const useShut = () => {
      if (!up) return;
      const old = up; up = null;
      document.removeEventListener("pointerdown", useOut, true); document.removeEventListener("keydown", useOut, true);
      const g = wrap.querySelector(":scope>.pj-gauge"); if (g) g.setAttribute("aria-expanded", "false");
      old.classList.remove("on"); setTimeout(() => old.remove(), 160);
    };
    const useOpen = () => {
      shut();
      up = document.createElement("div");
      up.className = "pj-mpop pj-upop"; up.setAttribute("role", "dialog"); up.setAttribute("aria-label", tl("connuse.title"));
      up.onclick = (e) => { e.stopPropagation(); if (e.target.closest("[data-ugo]")) { useShut(); location.hash = "usage"; } };
      wrap.appendChild(up); useFill();
      wrap.querySelector(":scope>.pj-gauge").setAttribute("aria-expanded", "true");
      requestAnimationFrame(() => up && up.classList.add("on"));
      document.addEventListener("pointerdown", useOut, true); document.addEventListener("keydown", useOut, true);
    };
    wrap.addEventListener("click", (e) => { if (e.target.closest("[data-gauge]")) { e.stopPropagation(); if (up) useShut(); else useOpen(); } });
    const html = () => {
      // nowId: the row of what really runs ("" = a row of its own, null = not known, no row marked).
      const p = pick(), listed = v.models.some((m) => m.id === v.now.family), nowId = listed ? v.now.family : v.now.name ? "" : null;
      // The model that runs is the marked row and carries the word for why (in use, the default).
      // "기본" is a row of its own only while what runs is not one of the listed models.
      const on = p.model || nowId || "", eon = p.effort || v.now.effort || "";
      const rows = nowId ? v.models : [{id: "", name: tl("room.modelBase") + (nowId === "" ? " · " + v.now.name : "")}, ...v.models];
      const tag = cx() && v.now.source === "set" ? tl("mdl.cx.tSet") : MTAG[v.now.source] ? MTAG[v.now.source]() : "";
      const desc = (id) => cx() ? (id ? "" : v.now.source === "run" ? tl("mdl.dKeep") : tl("mdl.cx.dSet")) : MDESC[id]?.(v.now.source) || "";
      const lv = levels(p);
      // One line of explanation at most: why a pick is not in effect, else the note on versions.
      const wn = off() ? tl("mdl.wRestart") : v.when === "move" ? tl("mdl.wMove") : v.waits && v.stuck ? tl("mdl.wFail") : v.waits && v.busy ? tl("mdl.wBusy") : v.waits && v.when === "next" && !cx() ? tl("mdl.wApply") : "";
      // One tab stop per group: the marked one, else the first.
      const radio = (on, val, first) => `role="radio" aria-checked="${on}" tabindex="${on || first ? 0 : -1}" data-v="${esc(val)}"${off() ? ` aria-disabled="true"` : ""}`;
      // An effort that is known is marked like the model; "기본" stays only while nothing says it.
      const effs = v.now.effort ? lv : ["", ...lv];
      return `<div class="hd"><h4 id="pj-mh">${tl("mdl.title")}</h4><button class="mx press" data-mx aria-label="${tl("mdl.close")}" title="${tl("mdl.close")}">${ic("x")}</button></div>${wn ? `<p class="wn">${wn}</p>` : ""}
        <div role="radiogroup" aria-label="${tl("mdl.model")}" data-g="model">${rows.map((m, i) =>
          `<button class="pj-mrow" ${radio(m.id === on, m.id, on == null && !i)}><span class="tx"><span class="nm">${esc(m.name)}${m.id === nowId && tag ? `<em>${esc(tag)}</em>` : ""}</span>${desc(m.id) ? `<span class="ds">${esc(desc(m.id))}</span>` : ""}</span><span class="ck" aria-hidden="true">${ic("check")}</span></button>`).join("")}</div>
        ${wn ? "" : `<p class="nt">${cx() ? (nowId == null && !p.model ? tl("mdl.cx.unknown") : tl("mdl.cx.note")) : nowId == null && !p.model ? tl("mdl.unknown") : tl("mdl.note")}</p>`}
        ${lv.length ? `<div class="lb" id="pj-mle">${tl("mdl.effSub")}<b data-el>${esc(effLabel(eon))}</b></div>
        ${window.EffortMove ? `<div data-em></div>` : ""}<div class="pj-meff" role="radiogroup" aria-labelledby="pj-mle" data-g="effort"${window.EffortMove ? " hidden" : ""}>${effs.map((e) =>
          `<button ${radio(e === eon, e)}>${esc(e ? (ESHORT[e]?.() || e) : tl("room.modelBase"))}</button>`).join("")}</div>
        <p class="ed" aria-live="polite">${esc(eon ? (EDESC[eon] ? EDESC[eon]() : "") : cx() ? tl("mdl.cx.eDef0") : EDESC[""]())}</p>` : ""}`;
    };
    // Where it fits: left edge on the chip's, pulled back inside the chat panel, never taller than the room above.
    // On a phone's open chat the popover is a bottom sheet over a veil; it only fades.
    const sheetMode = () => !wide() && document.body.classList.contains("pjchat");
    const place = () => {
      if (pop && pop.classList.contains("sheet")) return;
      const cr = (wrap.closest(".pj-conv") || document.body).getBoundingClientRect(), br = wrap.getBoundingClientRect();
      const w = cr.width < 420 ? cr.width - 16 : 264;      // a phone: the full width, 8px each side
      pop.style.width = w + "px";
      pop.style.left = Math.max(cr.left + 8, Math.min(br.left, cr.right - 8 - w)) - br.left + "px";
      pop.style.maxHeight = Math.max(160, br.top - cr.top - 16) + "px";
      pop.style.transformOrigin = `${Math.round(br.width / 2 - parseFloat(pop.style.left))}px 100%`;
    };
    const show = (focus) => {
      if (!wrap.isConnected || !v || v.hidden) { wrap.innerHTML = ""; pop = null; return; }
      watch();
      let b = wrap.querySelector("[data-mb]");
      if (!b) {
        wrap.innerHTML = `<button class="pj-mbtn press" data-mb aria-haspopup="dialog" aria-expanded="false"></button>`;
        b = wrap.querySelector("[data-mb]");
        b.onclick = (e) => { e.stopPropagation(); if (pop && !closing) shut(); else open(); };
      }
      const f = face();
      b.title = f.dot === "w" ? (v.when === "move" ? tl("mdl.wMove") : v.stuck ? tl("mdl.wFail") : v.busy ? tl("mdl.wBusy") : tl("mdl.chipWait")) : tl("mdl.chip");
      b.setAttribute("aria-label", tl("mdl.chip") + ": " + f.model + (f.effort ? ", " + f.effort : ""));
      b.innerHTML = `${MSPARK}<span class="mn">${esc(f.model)}</span>${f.effort ? `<span class="sep">·</span><b>${esc(f.effort)}</b>` : ""}${f.dot ? `<span class="dt ${f.dot}"></span>` : ""}${ic("chev", "i cv")}`;
      // Beside the chip: how full the conversation is, without opening anything.
      const was = wrap.querySelector(":scope>.pj-gauge"), chip = ctxGauge(v.context);
      if (!was) b.insertAdjacentHTML("afterend", chip);
      else if (was.outerHTML.replace(' aria-expanded="true"', ' aria-expanded="false"') !== chip) { was.outerHTML = chip; const g = up && wrap.querySelector(":scope>.pj-gauge"); if (g) g.setAttribute("aria-expanded", "true"); }
      if (up) { if (v.context && v.context.tokens) useFill(); else useShut(); }
      if (!pop) return;
      pop.innerHTML = html();
      pop.classList.toggle("off", off());
      const slot = pop.querySelector("[data-em]");
      if (slot) {
        const p = pick(), lv = levels(p), val = p.effort || v.now.effort || "";
        const steps = (v.now.effort ? lv : ["", ...lv]).map((e) => ({id: e, label: effLabel(e)})), key = steps.map((s) => s.id).join();
        if (!em) {
          emHost = document.createElement("div"); emHost.className = "pj-mem";
          em = effortCtl(emHost, {steps, value: val, ariaLabel: tl("mdl.effSub"), onChange: (id) => set("effort", id), onInput: effSay});
          emKey = key; slot.replaceWith(emHost);
        } else { slot.replaceWith(emHost); if (key !== emKey) { em.setSteps(steps, val); emKey = key; } else em.setValue(val); }
        if (focus === "effort") emHost.querySelector(".em-track").focus({preventScroll: true});
      }
      place();
      if (focus) { const r = pop.querySelector(`[data-g="${focus}"] [aria-checked="true"]`); if (r) r.focus({preventScroll: true}); }
    };
    const set = async (g, val) => {
      if (off()) { show(g); return; }
      const p = Object.assign({}, pick(), {[g]: val});
      if (p.effort && !levels(p).includes(p.effort)) p.effort = "";     // a level the newly picked model does not take
      if (!at.sid) { if (p.model || p.effort) draftModel[dk] = p; else delete draftModel[dk]; show(g); return; }
      v.choice = p;
      v.waits = !live() && !!((p.model && p.model !== v.now.family) || (p.effort && p.effort !== v.now.effort));
      show(g);
      try { v = await post("/api/session/model", {sid: at.sid, model: p.model, effort: p.effort}); }
      catch (e) { toast(e.message); try { v = await get(url); } catch (e2) { /* keeps what it shows */ } }
      show(pop && pop.contains(document.activeElement) ? g : "");
    };
    const onKey = (e) => { if (e.key === "Escape" && pop) { e.stopPropagation(); shut(); const b = wrap.querySelector("[data-mb]"); if (b) b.focus(); } };
    // Open and close grow from the chip on one stepped spring, so a press mid-way turns it round
    // from where it is. Reduced motion: no movement, a short fade.
    const draw = (x) => { if (!pop) return; pop.style.opacity = Math.max(0, Math.min(1, x * 1.5)).toFixed(3);
      if (sc) sc.style.opacity = Math.max(0, Math.min(1, x)).toFixed(3);
      pop.style.transform = x > 0.999 || pop.classList.contains("sheet") ? "" : `translateY(${((1 - x) * 8).toFixed(2)}px) scale(${(0.9 + 0.1 * x).toFixed(4)})`; };
    let portalWatch = null;
    const out = (e) => { if (pop && !wrap.contains(e.target) && !pop.contains(e.target)) shut(); };
    const gone = () => { if (portalWatch) portalWatch.disconnect(); portalWatch = null;
      if (pop) pop.remove(); if (sc) sc.remove(); if (em) em.destroy(); pop = sp = em = emHost = sc = null; closing = false; };
    const shut = () => {
      if (!pop || closing) return;
      closing = true; pop.style.pointerEvents = "none";
      const b = wrap.querySelector("[data-mb]");
      if (b) b.setAttribute("aria-expanded", "false");
      document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", onKey, true); removeEventListener("resize", place);
      if (sp && !RM()) sp.set(0);
      else if (pop.animate) { if (sc) sc.animate([{opacity: 1}, {opacity: 0}], {duration: 140, easing: "ease-out", fill: "forwards"});
        const a = pop.animate([{opacity: 1}, {opacity: 0}], {duration: 140, easing: "ease-out", fill: "forwards"}); a.onfinish = a.oncancel = gone; }
      else gone();
    };
    const open = () => {
      useShut();
      if (!pop) {
        pop = document.createElement("div");
        pop.className = "pj-mpop"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-labelledby", "pj-mh");
        if (sheetMode()) {
          pop.classList.add("sheet");
          sc = document.createElement("div"); sc.className = "pj-mscrim"; document.body.appendChild(sc);
          sc.onclick = (e) => { e.stopPropagation(); shut(); };
          const a = document.activeElement; if (a && a.matches && a.matches("textarea,input")) a.blur();   // the keyboard goes down: the sheet has the room
        }
        // Fixed sheets must escape the composer's clipping and transform contexts.
        (sc ? document.body : wrap).appendChild(pop);
        if (sc) { portalWatch = new MutationObserver(() => { if (!wrap.isConnected) {
          document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", onKey, true);
          removeEventListener("resize", place); gone();
        } }); portalWatch.observe(document.body, {childList: true, subtree: true}); }
        pop.onclick = (e) => {
          e.stopPropagation();
          if (e.target.closest("[data-mx]")) { shut(); const b = wrap.querySelector("[data-mb]"); if (b) b.focus({preventScroll: true}); return; }
          // The marked row can be pressed too: shown as the default it passes nothing, pressed it is a pick.
          const r = e.target.closest("[role=radio]"), g = r && r.parentNode.dataset.g;
          if (r && (r.getAttribute("aria-checked") !== "true" || pick()[g] !== r.dataset.v)) set(g, r.dataset.v);
        };
        // Arrows move the choice inside a group, as radios do; Tab goes on to the next group.
        pop.onkeydown = (e) => {
          const r = e.target.closest("[role=radio]"), d = {ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1}[e.key];
          if (!r || !d) return;
          e.preventDefault();
          const all = [...r.parentNode.querySelectorAll("[role=radio]")];
          set(r.parentNode.dataset.g, all[(all.indexOf(r) + d + all.length) % all.length].dataset.v);
        };
        if (window.Motion && Motion.phys && !RM()) { sp = Motion.phys(0, 520, 40, draw); sp.rest = () => { if (closing) gone(); }; draw(0); }
        else if (pop.animate) { pop.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); if (sc) sc.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
      } else if (!sp) { pop.getAnimations().forEach((a) => { a.onfinish = a.oncancel = null; a.cancel(); }); }   // caught while fading out
      closing = false; pop.style.pointerEvents = "";
      wrap.querySelector("[data-mb]").setAttribute("aria-expanded", "true");
      document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", onKey, true); addEventListener("resize", place);
      show("model");
      if (sp) sp.set(1);
      // The session may have ended or started since the chip was drawn: ask again, quietly.
      get(url).then((r) => { v = r; if (pop) show(pop.contains(document.activeElement) ? document.activeElement.parentNode.dataset.g : ""); else show(); }).catch(() => {});
    };
    get(url).then((r) => { v = r; show(); }).catch(() => {});
    // An answer may come from another model than the chip names (started again, switched inside
    // the session): when the chat grows the chip asks again, at most every 8s, and shows what is true.
    const msgs = at.sid && window.MutationObserver && (wrap.closest(".pj-conv") || document).querySelector("#pj-msgs");
    if (msgs) {
      let last = Date.now(), due = 0;
      const mo = new MutationObserver(() => {
        if (!wrap.isConnected) return mo.disconnect();
        if (due) return;
        due = setTimeout(() => { due = 0; last = Date.now();
          if (!wrap.isConnected || document.hidden) return;
          get(url).then((r) => { if (!v || JSON.stringify([r.now, r.choice, r.when, r.waits, r.context]) === JSON.stringify([v.now, v.choice, v.when, v.waits, v.context])) return;
            v = r; show(); }).catch(() => {}); }, Math.max(1500, 8000 - (Date.now() - last)));
      });
      mo.observe(msgs, {childList: true, subtree: true});
    }
    // The lower row holds picture, chip, department and send; where the box is too narrow for all
    // of them the department (the header says it too) and the Enter hint give way.
    const box = wrap.closest(".pj-box");
    if (box && window.ResizeObserver) new ResizeObserver(([e]) => box.classList.toggle("pj-tight", e.contentRect.width < 520)).observe(box);
  }
  function drawDraft(body, name, head, focus) {
    // Which one answers is picked here, before the first line: the department's own is only the start.
    // It sits in the box beside the model chip (the state row above is hidden under the chat's own header).
    let agent = draftAgent[name] || (head.agent === "codex" ? "codex" : "claude");
    // Once only: the dim line under a first Codex draft (kept in this browser, like other prefs).
    const cxSeen = () => { try { return localStorage.getItem("genok.cxapphint") === "1"; } catch (err) { return true; } };
    const pick = `<div class="seg pj-seg2 pj-agseg" data-agseg role="group" aria-label="Claude / Codex">${[["claude", "Claude"], ["codex", "Codex"]].map(([v, l]) =>
      `<button class="${v === agent ? "on" : ""} press" data-v2="${v}" aria-pressed="${v === agent}">${window.agDot(v)}${l}</button>`).join("")}</div>`;
    body.innerHTML = `<div class="pj-conv pj-draft" data-col="conv">
        <div class="pj-state">${dot("ended")}<span>${esc(head.fixed || tl("room.newSess"))}</span><span class="sp"></span></div>
        <div class="pj-wrap"><div class="pj-msgs" id="pj-msgs"><div class="pj-empty pj-anim"><b>${tl("room.draftHead")}</b>${tl("room.draftSub")}</div></div></div>
        <div class="pj-to" id="pj-to">${toLine({name, emoji: head.emoji || emoOf(name), conv: head.fixed || tl("room.toNew"), agent})}</div>
        <div class="pj-in"><div class="pj-box">
          <textarea id="pj-ta" rows="1" placeholder="${esc(tl("room.draftPh"))}" aria-label="${esc(tl("room.draftPh"))}"></textarea>
          ${pick}<span class="pj-mwrap" id="pj-ml"></span><span class="pj-pjn">${em(head.emoji || emoOf(name), "", head.icon || icoOf(name))}<span>${esc(unEm(pname(name), head.emoji || emoOf(name) || icoHtml(head.icon || icoOf(name))))}</span></span><span class="pj-enter">${tl("room.enterSend")}</span>
          ${micHtml()}
          <button class="pj-go press" id="pj-send" aria-label="${tl("pj.send")}" title="${tl("pj.send")}" disabled>${ic("up")}<span class="pj-spin" aria-hidden="true"></span></button></div></div>
        <div class="pj-hint" id="pj-cxh" style="margin:6px 14px 0"${agent === "codex" && !cxSeen() ? "" : " hidden"}>${tl("connect.cx_app")}</div>
      </div>`;
    const ta = body.querySelector("#pj-ta"), go = body.querySelector("#pj-send"), box0 = body.querySelector(".pj-box");
    let sending = false;
    ta.value = drafts[name] || "";
    body.querySelectorAll("[data-agseg] [data-v2]").forEach((b) => b.onclick = () => {
      if (sending || b.dataset.v2 === agent) return;
      // In place: the header, the typed text and the caret stay where they are.
      agent = draftAgent[name] = b.dataset.v2;
      body.querySelectorAll("[data-agseg] [data-v2]").forEach((x) => { const on = x.dataset.v2 === agent; x.classList.toggle("on", on); x.setAttribute("aria-pressed", on); });
      const to = body.querySelector("#pj-to");
      const cxh = body.querySelector("#pj-cxh"); if (cxh) cxh.hidden = agent !== "codex" || cxSeen();
      if (to) to.innerHTML = toLine({name, emoji: head.emoji || emoOf(name), conv: head.fixed || tl("room.toNew"), agent});
      const hs = body.querySelector(".pj-nth .s");   // the chat's own header says who answers
      if (hs) hs.textContent = [pname(name), agent === "codex" ? "Codex" : "Claude Code", tl("room.draftRow")].join(" · ");
      const m = body.querySelector("#pj-ml");
      if (m) { const n = m.cloneNode(false); m.replaceWith(n); modelChip(n, {name, agent}); }   // a fresh node: the old chip's late answers land nowhere
      ta.focus({preventScroll: true});
    });
    const sync = () => {
      go.disabled = sending || !ta.value.trim(); go.classList.toggle("busy", sending);
      // Measured while the screen was not laid out yet, scrollHeight is 0 and "0px" would stick
      // (the empty box cut its own placeholder in half): an empty or unmeasured box keeps its CSS height.
      if (!ta.value || !ta.scrollHeight) { ta.style.height = ""; return; }
      ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 160) + "px";
    };
    ta.addEventListener("input", () => { drafts[name] = ta.value; sync(); });
    box0.addEventListener("click", (e) => { if (e.target === box0) ta.focus(); });
    // What the pane shows: the invitation, the line on its way, or why it did not go (with a way to
    // try again). The typed text stays in the box until a session has really taken it.
    const msgs = body.querySelector("#pj-msgs"), invite = msgs.innerHTML;
    const failed = (why) => {
      // Folder trust is Claude Code's own question: one button opens it there, then try again.
      const tf = draftCode[name] === "folder_untrusted" ? `<button class="pj-btn light press" style="margin:12px 6px 0 0" data-tf>${tl("perm.cli_cc_btn")}</button>` : "";
      msgs.innerHTML = `<div class="pj-empty" role="alert" data-serr><b>${tl("room.sendFail")}</b>${esc(why)}<br>${tf}<button class="pj-btn${tf ? "" : " light"} press" style="margin-top:12px" data-again>${tl("room.retry")}</button></div>`;
      msgs.querySelector("[data-again]").onclick = () => send();
      if (tf) msgs.querySelector("[data-tf]").onclick = () => post("/api/connect/trust-folder", {name}).then(() => toast(tl("perm.cli_opened"))).catch((e) => toast(e.message));
    };
    if (draftErr[name]) failed(draftErr[name]);
    // Drawn again while the first line is still on its way: it is still shown as on its way.
    const going = (text) => { sending = true; ta.readOnly = true; sync(); msgs.innerHTML = pendRow({text, busy: true, tag: tl("room.sending")}, 0); };
    if (draftBusy[name]) going(draftBusy[name]);
    const send = async () => {
      Dictate.cut();
      const text = ta.value.trim(); if (!text || sending) return;
      delete draftErr[name]; delete draftCode[name];
      draftBusy[name] = text; going(text);
      try {
        // What the chip picked goes with the first line; nothing picked sends nothing.
        const dm = draftModel[draftKey(name, agent)] || {}, m = {};
        if (dm.model) m.model = dm.model;
        if (dm.effort) m.effort = dm.effort;
        // Only 새 세션 pressed by the person opens another; otherwise the server sends the line
        // to the conversation the project has, and opens one when it has none.
        const r = await act("/api/session/new", Object.assign({name, agent, text}, head.fresh ? {mode: "new"} : {}, m));
        delete draftBusy[name];
        started(r.name || name);
        delete drafts[name]; delete draftModel[name]; delete draftModel[draftKey(name, "codex")]; delete draftAgent[name]; roomsCache = null;
        if (agent === "codex") { try { localStorage.setItem("genok.cxapphint", "1"); } catch (err) { /* shown again next time */ } }
        // Claude has not named it yet: the page waits for it (waitNew) instead of an older one.
        // One with an id waits for the list the same way, so the page never opens something else.
        if (r.sid || r.job) pendNew[r.name || name] = {job: r.job, sid: r.sid, text, at: Date.now()};
        nav("project/" + enc(r.name || name) + (r.sid ? "/" + enc(r.sid) : ""));
      } catch (e) {
        delete draftBusy[name];
        sending = false; ta.readOnly = false; sync();
        if (e.message === "cancelled") msgs.innerHTML = invite;
        else { draftErr[name] = e.message || tl("room.failed"); draftCode[name] = e.code; failed(draftErr[name]); if (!msgs.isConnected) toast(draftErr[name]); }   // said once: in the pane when it is up
        if (!msgs.isConnected && where().name === name) render();   // the pane was drawn again meanwhile
      }
    };
    go.onclick = send;
    micWire(body, ta);
    // Enter sends, Shift+Enter breaks the line; the Enter that ends a composition does not send.
    let composing = false;
    ta.addEventListener("compositionstart", () => { composing = true; });
    ta.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    ta.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); send();
    });
    sync();
    const ml = body.querySelector("#pj-ml");
    if (ml) modelChip(ml, {name, agent});
    if (focus) setTimeout(() => { if (ta.isConnected) ta.focus({preventScroll: true}); }, 60);
  }

  function card(s, selSid) {
    const k = kindOf(s.state, s.last);
    return `<div class="pj-card pj-row press ${s.id === selSid ? "on" : ""}${busy[s.id] ? " busy" : ""}" data-sid="${esc(s.id)}" role="button" tabindex="0"${busy[s.id] ? ` aria-busy="true"` : ""}>
      <div class="r1">${dot(k)}<div class="t">${esc(Redact.show(title(s)))}</div>${s.unread && s.id !== selSid ? `<b class="pj-un num" aria-label="${tl("room.unread", {n: s.unread})}">${s.unread >= 99 ? "99+" : s.unread}</b>` : ""}
        <button class="pj-more press" data-more="${esc(s.id)}" aria-label="${tl("pj.menu")}">${ic("more")}</button></div>
      <div class="r2"><span class="pj-stl ${k}">${esc(busy[s.id] || LABEL[k] || k)}</span>${agentTag(s.agent)}${window.RLAcct ? RLAcct.chip(s) : ""}${s.bg ? `<span class="pj-bg">${tl("pj.bg")}</span>` : ""}${s.moved ? `<span class="pj-bg">${tl("pj.moved")}</span>` : ""}${s.pinned ? `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>` : ""}${ctxRow(s.context)}<span>${s.last ? ago(s.last) : ""}</span></div></div>`;
  }

  // Projects being opened right now, and when one was last opened from the list (its new session
  // takes a moment to be read into the list; 켜기 stays away meanwhile so it is not pressed twice).
  const UP_ST = ["live", "idle", "stuck"], START_HOLD = 90000, starting = new Set(), startedAt = {};
  // A session just opened for a department: once the list has it, it is the one shown (while the
  // person is still on that department's page).
  async function followStart(pn) {
    for (const t0 = Date.now(); Date.now() - t0 < START_HOLD;) {
      await new Promise((ok) => setTimeout(ok, 2000));
      const d = await get("/api/project/rooms").catch(() => null), r = d && (d.rooms || []).find((v) => v.name === pn);
      if (!r || !r.sid || !UP_ST.includes(r.state)) continue;
      roomsCache = null;
      if (location.hash === "#project/" + enc(pn)) nav("project/" + enc(pn) + "/" + enc(r.sid));
      return;
    }
  }
  // 켜기 (the list beside the chat and the phone's cards share it). `redraw` paints the caller's list.
  const darkRoom = (r) => !!r.registered && !r.sid && !r.fixed && !UP_ST.includes(r.state) && !r.copies;
  // `pick`: the past talk to bring back ({sid, title, agent}), or null for a new session.
  async function turnOn(pn, pick, redraw) {
    if (starting.has(pn)) return;
    const b = pick;
    starting.add(pn); redraw();
    let ok = false;
    if (b) await control("open", {id: b.sid, agent: b.agent || "claude", state: "ended", title: b.title}, pn, () => { ok = true; });
    else ok = await openDept(pn);
    starting.delete(pn);
    if (!ok) return redraw();
    startedAt[pn] = Date.now(); roomsCache = null; sessQ = "";
    if (b) return nav("project/" + enc(pn) + "/" + enc(b.sid));
    nav("project/" + enc(pn)); followStart(pn);
  }
  // The talks a department that is off had, newest first (the first is where Enter lands), then
  // 새로 시작: one press on a line does it. `shut` closes what holds the lines.
  const pastOf = (pn) => { const r = (roomsCache || roomsSeen || []).find((v) => v.name === pn), bk = r && r.back; return bk ? (bk.past && bk.past.length ? bk.past : [bk]) : []; };
  function onLines(pn) {
    const past = pastOf(pn), r = (roomsCache || roomsSeen || []).find((v) => v.name === pn), n = (r && r.back && r.back.n) || 0;
    const line = (m, i) => `<button class="two" role="menuitem" data-i="${i}"${i ? "" : ` aria-current="true"`}><span>${esc(m.title && m.title !== "(제목 없음)" ? m.title : pname(pn))}</span><small>${m.at ? esc(ago(m.at)) : ""}</small></button>`;
    return past.map(line).join("") + (n > past.length ? `<button role="menuitem" data-a="past">${ic("list")}<span>${tl("room.offPast", {n})}</span></button>` : "")
      + `<hr><button role="menuitem" data-a="fresh">${ic("plus")}<span>${tl("room.offFresh")}</span></button>`;
  }
  function onWire(box, pn, shut, redraw) {
    const past = pastOf(pn);
    box.querySelectorAll("button[data-i],button[data-a]").forEach((m) => m.onclick = (e) => {
      e.stopPropagation(); shut();
      if (m.dataset.a === "past") { showOld = true; return nav("project/" + enc(pn)); }
      turnOn(pn, m.dataset.a === "fresh" ? null : past[+m.dataset.i], redraw);
    });
    const first = box.querySelector("button[data-i]"); if (first) first.focus({preventScroll: true});
    box.onkeydown = (e) => { if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
      const l = [...box.querySelectorAll("button[data-i],button[data-a]")], i = l.indexOf(document.activeElement); if (i < 0) return;
      e.preventDefault(); l[(i + (e.key === "ArrowDown" ? 1 : l.length - 1)) % l.length].focus({preventScroll: true}); };
  }
  // 켜기 asks which. One with no past talk starts new at once. Beside the button on a wide window,
  // the bottom sheet on a phone.
  function askOn(btn, pn, redraw) {
    if (starting.has(pn)) return;
    if (!pastOf(pn).length) return turnOn(pn, null, redraw);
    if (!wide()) return sheet(`<div class="pj-onp" role="menu" aria-label="${esc(pname(pn))}"><b class="h">${esc(pname(pn))}</b>${onLines(pn)}</div>`, (box) => onWire(box.querySelector(".pj-onp"), pn, closeSheet, redraw));
    document.querySelectorAll(".pj-pop").forEach((n) => n.remove());
    const pop = document.createElement("div"); pop.className = "pj-pop cm pj-onp"; pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", tl("room.on"));
    pop.innerHTML = onLines(pn);
    const off = popAt(pop, btn);
    onWire(pop, pn, off, redraw);
  }
  // {unit} 찾아서 켜기 (the caret beside [새 세션]): every department, the ones that are off too.
  // One that is off and had talks shows them in place (the lines 켜기 offers); one that had none
  // starts new; one that is on opens its new-session page.
  async function findOn() {
    ensureCss();
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const rooms = (roomsCache || []).filter((r) => r.registered).slice().sort((a, b) => String(b.at || (b.back && b.back.at) || "").localeCompare(String(a.at || (a.back && a.back.at) || "")));
    const redraw = () => { if (railNow) railNow(); };
    let q = "";
    sheet(`<div class="pj-dlg pj-fo"></div>`, (box) => {
      const root = box.querySelector(".pj-fo");
      const fade = () => { if (!RM()) root.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease"}); };
      const row = (r) => { const sub = darkRoom(r) ? backLine(r.back) : r.sid ? (r.title && r.title !== "(제목 없음)" ? r.title : "") : "";
        return `<button class="press" data-fd="${esc(r.name)}"><span class="oe">${em(r.emoji, r.color, r.icon)}</span><span class="ox"><span class="nm">${esc(unEm(pname(r.name), r.emoji || icoHtml(r.icon)))}</span>${sub ? `<span class="bk">${esc(sub)}</span>` : ""}</span>${r.sid && UP_ST.includes(r.state) ? dot(kindOf(r.state, r.at)) : ""}</button>`; };
      const rows = () => { const f = foldQ(q), hit = f ? rooms.filter((r) => (hay(r) + foldQ((r.back && r.back.title) || "")).includes(f)) : rooms;
        return hit.length ? hit.map(row).join("") : `<div class="pj-empty">${tl("room.noMatch")}</div>`; };
      const pick = (pn) => {
        const r = rooms.find((v) => v.name === pn); if (!r) return;
        if (!darkRoom(r)) { closeSheet(); return nav("project/" + enc(pn) + "/" + NEW); }
        if (!pastOf(pn).length) { closeSheet(); return turnOn(pn, null, redraw); }
        root.innerHTML = `<button type="button" class="pj-fob press" data-fback>${ic("chev")}<span>${esc(pname(pn))}</span></button><div class="pj-onp" role="menu" aria-label="${esc(pname(pn))}">${onLines(pn)}</div>`;
        fade();
        root.querySelector("[data-fback]").onclick = list;
        onWire(root.querySelector(".pj-onp"), pn, closeSheet, redraw);
      };
      const list = () => {
        root.innerHTML = `<h3>${tl("room.findOn")}</h3><input class="pj-search" type="search" data-q value="${esc(q)}" placeholder="${esc(tl("room.searchOnly"))}" aria-label="${esc(tl("room.searchOnly"))}"><div class="rows" data-rows>${rows()}</div>`;
        fade();
        const qi = root.querySelector("[data-q]"), rw = root.querySelector("[data-rows]");
        qi.oninput = () => { q = qi.value; rw.innerHTML = rows(); };
        qi.onkeydown = (e) => { if (e.isComposing || e.keyCode === 229) return; const f = rw.querySelector("[data-fd]");
          if (e.key === "Enter" && f) { e.preventDefault(); pick(f.dataset.fd); } else if (e.key === "ArrowDown" && f) { e.preventDefault(); f.focus(); } };
        rw.onclick = (e) => { const b = e.target.closest("[data-fd]"); if (b) pick(b.dataset.fd); };
        rw.onkeydown = (e) => { if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return; const l = [...rw.querySelectorAll("[data-fd]")], i = l.indexOf(document.activeElement); if (i < 0) return;
          e.preventDefault(); if (e.key === "ArrowUp" && !i) return qi.focus(); const to = l[i + (e.key === "ArrowDown" ? 1 : -1)]; if (to) to.focus(); };
        if (wide()) qi.focus({preventScroll: true});
      };
      list();
    });
  }
  const onBtnHtml = (pn, tag) => starting.has(pn) ? `<${tag} class="pj-on" data-on="${esc(pn)}" ${tag === "button" ? "disabled" : `role="button" aria-disabled="true"`} aria-busy="true">${tl("room.onBusy")}</${tag}>`
    : `<${tag} class="pj-on press" data-on="${esc(pn)}"${tag === "button" ? "" : ` role="button" tabindex="0"`}>${tl("room.on")}</${tag}>`;
  const backLine = (b) => b ? [b.title && b.title !== "(제목 없음)" ? b.title : "", b.at ? ago(b.at) : ""].filter(Boolean).join(" · ") : "";
  async function openDept(name) {                     // true once it opened; why not is said in a toast
    try {
      if (window.RLAcct && !(await RLAcct.confirmStart([name]))) return false;
      const res = await act("/api/depts/open", {name});
      toast((res && res.note) || tl("pjx.done.open"));
      if (res && res.via === "bg" && window.RLAcct) RLAcct.watchStart(name);
      return !!res;
    }
    catch (e) { if (e.message !== "cancelled") toast(e.message); return false; }
  }

  // ---- per-session menu -----------------------------------------------------------------------------
  // `again` redraws whichever screen the menu was opened from (the project page or the room grid).
  // A menu row's shortcut, one cap per key: the same caps as the key bar and the shortcut sheet.
  const keyCaps = (k) => `<span class="mk keys" aria-hidden="true">${k.split(" ").map((x) => `<kbd>${x}</kbd>`).join("")}</span>`;
  function menu(btn, s, name, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    // A few words and an icon per choice. One that does not apply to this session is left out;
    // one that could but cannot right now is dimmed and says why when pressed.
    const ended = s.state === "ended", codex = s.agent === "codex";
    const MN = {top: ["pin", topPinned(s) ? tl("session.top.off") : tl("session.top.on")], open: ["play", tl("mn.open")], fresh: ["plus", tl("mn.fresh")], split: ["sidebar", tl("mn.split")], lighten: ["swap", tl("mn.lighten")],
      read: ["eye", s.unread ? tl("mn.read") : tl("mn.unread")], pick: ["check", tl("mn.pick")],
      pin: ["pin", s.pinned ? tl("mn.unpin") : tl("mn.pin")], stop: ["stop", codex ? tl("room.codexStop") : tl("mn.stop")], tidy: ["archive", s.tidied ? tl("mn.untidy") : tl("mn.tidy")]};
    const item = (a) => { const o = what(a, s), m = a === "float" ? ["ext", floating.has(s.id) ? tl("fl.unpin") : tl("fl.pin")] : MN[a];
      return `<button data-a="${a}"${a === "stop" ? ` class="dz"` : ""}${o.off ? ` aria-disabled="true"` : ""}${MK[a] ? ` data-k="${MK[a]}" aria-keyshortcuts="${MK[a]}"` : ""}>${ic(m[0])}<span>${esc(m[1])}</span>${MK[a] ? keyCaps(MK[a]) : ""}</button>`; };
    const ordRow = btn.closest(".pj-srow");
    // A phone folds a running session's state row into the name's row, which hides 변경 and 화면
    // there: the chat's own menu carries them instead, so nothing the PC offers is lost.
    const chN = s.changes ? (s.changes.files || 0) + (s.changes.untracked || 0) : 0;
    const folded = !ended && phoneList() && btn.matches("[data-cmenu]")
      ? (chN ? `<button data-x="chg">${ic("list")}<span>${tl("pj.chg", {n: chN})}</span></button>` : "") + (s.bg ? `<button data-x="bg">${ic("full")}<span>${tl("pj.bglog")}</span></button>` : "") : "";
    // Find in this conversation: also Ctrl+F, but a phone has no keys and the app's window no find of its own.
    // These four answer to a chord, not to a letter while the menu is up: the hint says so the way the letters do.
    const hint = keyCaps;
    const findIt = btn.matches("[data-cmenu]") && btn.closest(".pj-conv") ? `<button data-x="find"${appWin() ? ` aria-keyshortcuts="Control+F"` : ""}>${ic("search")}<span>${tl("pj.find.menu")}</span>${appWin() ? hint("Ctrl F") : ""}</button>` : "";
    // In a chat with lines of mine: to my newest (where the newest answer begins; Alt+Up from anywhere),
    // and under 더 보기 the newest answer whole and the conversation as loaded, both as Markdown.
    const cv = findIt && convs[s.id], said = cv && cv.entries.some((e) => e.kind === "user"), ans = cv ? lastAnswer(cv.entries) : "";
    const recN = convs[s.id] && convs[s.id].work ? convs[s.id].work.files.length : 0;   // files the record says this session edited
    const mineIt = said ? `<button data-x="mine" aria-keyshortcuts="Alt+ArrowUp">${ic("up")}<span>${tl("pj.mine.menu")}</span>${hint("Alt ↑")}</button>` : "";
    // 차례 목록 (a long conversation as a list) and 자주 쓰는 문구 (lines saved to send again).
    const turnsIt = cv && cv.loaded ? `<button data-x="turns" aria-keyshortcuts="Alt+T">${ic("list")}<span>${tl("pj.turns.menu")}</span>${hint("Alt T")}</button>` : "";
    const snipIt = findIt ? `<button data-x="snip" aria-keyshortcuts="Control+/">${ic("book")}<span>${tl("pj.snip.menu")}</span>${hint("Ctrl /")}</button>` : "";
    const maskIt = findIt ? `<button data-x="mask">${ic("lock")}<span>${Redact.on() ? tl("pj.mask.off") : tl("pj.mask.on")}</span></button>` : "";
    const copyIt = (ans ? `<button data-x="cpa">${ic("copy")}<span>${tl("pj.copy.last")}</span></button>` : "") + (said || ans ? `<button data-x="cpc">${ic("doc")}<span>${tl("pj.copy.conv")}</span></button>` : "");
    // An ended Claude session can be handed to the Claude desktop app (`claude --desktop --resume`):
    // only on this PC, and shown once the server says the app and a new enough Claude Code are here.
    const deskIt = ended && !codex && onThisPc() ? `<button data-x="desk"${deskCan ? "" : ` style="display:none"`}>${ic("ext")}<span>${tl("mn.desktop")}</span></button>` : "";
    if (deskIt && !deskCan) get("/api/session/desktop").then((r) => { deskCan = !!r.can; const b = pop.querySelector('[data-x="desk"]'); if (b && deskCan) b.style.display = ""; }).catch(() => {});
    // A taskbar button of its own (taskbar.py): where there is a taskbar and pinning is switched on.
    const B = window.GenokBar, barOn = !!B && B.pins.includes(s.id);
    const barIt = !phoneList() && B && B.native && B.opts && B.opts.pin ? `<button data-x="bar">${ic("pin")}<span>${barOn ? tl("bar.unpin") : tl("bar.pin")}</span></button>` : "";
    pop.innerHTML = item("top") + (ended ? item("open") : "") + item("fresh") + (splitCan(s.id) ? item("split") : "") + (phoneList() ? "" : item("float")) + barIt + (codex ? "" : item("read")) + (ordRow && !pickOn ? item("pick") : "")
      + findIt + mineIt + turnsIt + snipIt + maskIt + folded + (!folded.includes(`"chg"`) && btn.matches("[data-cmenu]") && recN ? `<button data-x="chg">${ic("list")}<span>${tl("pj.chg", {n: recN})}</span></button>` : "")
      + moreRow(item("lighten") + item("pin") + ordItems(ordRow) + (s.fixed ? "" : `<button data-x="name">${ic("pen")}<span>${tl("pj.name.menu")}</span></button>`) + copyIt + deskIt + `<button data-x="access">${ic("shieldCheck")}<span>${tl("session.access.title")}</span></button>` + (phoneList() && name ? `<button data-x="dept">${ic("folder")}<span>${tl("room.deptMenu")}</span></button>` : ""))
      + `<hr>` + item("tidy") + (ended ? "" : item("stop"));
    popAt(pop, btn);
    ordWire(pop, ordRow); moreWire(pop);
    // Whether it is on the floating stack is asked when the menu opens (the stack is changed from
    // its own window too); the row is corrected in place if the answer differs.
    const F = window.GenokFloat;
    (F && F.pins ? Promise.resolve(F.pins()).then((v) => ({cards: [...(v || [])].map((c) => ({sid: c && c.sid ? c.sid : c}))})) : get("/api/float")).then((v) => { const was = floating.has(s.id); floating = new Set((v.cards || []).map((c) => c.sid));
      const b = pop.querySelector('[data-a="float"]'); if (b && pop.isConnected && was !== floating.has(s.id)) { const role = b.getAttribute("role"), had = b === document.activeElement; b.outerHTML = item("float");
        const nb = pop.querySelector('[data-a="float"]'); if (role) { nb.setAttribute("role", role); nb.tabIndex = -1; } if (had) nb.focus({preventScroll: true}); }
      const n = pop.querySelector('[data-a="float"]'); if (n && !n.onclick) n.onclick = (e) => { e.stopPropagation(); pop.remove(); control("float", s, name, again); }; }).catch(() => {});
    pop.querySelectorAll("[data-x]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); pop.remove(); if (b.dataset.x === "bar") return B.pin(s.id, !barOn, {name, title: title(s), agent: s.agent || "claude"}).then(() => toast(barOn ? tl("bar.unpinned") : tl("bar.pinned")), (er) => toast(er.message));
      if (b.dataset.x === "access") return showSessionAccess(s); if (b.dataset.x === "name") return sessRename(s, again); if (b.dataset.x === "desk") return openDesktop(s, again); if (b.dataset.x === "mask") return Redact.set(!Redact.on()); if (b.dataset.x === "chg") return showChanges(s.id); if (b.dataset.x === "find") return findOpen(btn.closest(".pj-conv")); if (b.dataset.x === "turns") return turnsOpen(btn.closest(".pj-conv"), cv); if (b.dataset.x === "snip") return snipOpen(btn.closest(".pj-conv")); if (b.dataset.x === "bg") return showAgentLog(s.bg);
      if (b.dataset.x === "mine") { const bx = btn.closest(".pj-conv").querySelector("#pj-msgs"); return hop(bx, cv, -1, true); }
      if (b.dataset.x === "cpa" || b.dataset.x === "cpc") return copyText(Redact.show(b.dataset.x === "cpa" ? ans : convMarkdown(cv.entries, {title: title(s), me: tl("pj.md.me"), agent: codex ? "Codex" : "Claude Code",
        words: (t) => parts(unnote(t)).words, when: (at) => new Date(at).toLocaleString(tmLoc(), {dateStyle: "medium", timeStyle: "short"})}))).then((ok) => toast(ok ? tl("pj.copied") : tl("pj.copyFail")));
      // A phone's list has no project lines, so the project's own menu is reached from any of its sessions.
      const r = (roomsCache || roomsSeen || []).find((x) => x.name === name); if (btn.isConnected) headMenu(btn, name, !!(r && r.registered), again); });
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const off = what(b.dataset.a, s).off;
      if (off) return toast(off);
      pop.remove(); control(b.dataset.a, s, name, again);
    });
  }
  let deskCan = false;                 // GET /api/session/desktop said `claude --desktop` can run here
  async function openDesktop(s, again) {
    try { await act("/api/session/open", {sid: s.id, via: "desktop"}); toast(tl("pjx.done.app")); roomsCache = null; again(); }
    catch (e) { if (e.message !== "cancelled") toast(e.message); }
  }
  // Genok grants do not describe the agent's current sandbox or approval policy.
  function showSessionAccess(s) {
    const agent = s.agent === "codex" ? "codex" : "claude";
    sheet(`<div class="pj-dlg pj-access"><h3>${tl("session.access.title")}</h3><p class="hint">${esc(title(s))} · ${agent === "codex" ? "Codex" : "Claude"}</p>
      <div class="pj-access-state" role="status">${tl("session.access.loading")}</div>
      <div class="pj-access-run" hidden></div>
      <p class="hint" data-access-note>${tl("session.access.agent")}</p>
      <button class="btn press" data-access-settings>${tl("session.access.settings")}</button></div>`, (box) => {
      box.querySelector("[data-access-settings]").onclick = () => { closeSheet(); setPage = "connect"; setShowPage = true; location.hash = "#settings"; };
      const state = box.querySelector(".pj-access-state");
      // What the agent itself may do is the agent's to say: Codex's newest turn (approval, sandbox) or Claude Code's last permission mode, from its record.
      // Not known (no turn yet, or the ask failed): the sheet keeps saying it cannot be checked here.
      get("/api/session/model?sid=" + enc(s.id)).then((r) => {
        const a = r && r.access; if (!a || !box.isConnected) return;
        const run = box.querySelector(".pj-access-run");
        if (agent === "claude") {
          if (!a.mode) return;
          const MODE = {default: () => tl("session.mode.default"), acceptEdits: () => tl("session.mode.edits"), plan: () => tl("session.mode.plan"),
            auto: () => tl("session.mode.auto"), bypassPermissions: () => tl("session.mode.bypass"), dontAsk: () => tl("session.mode.dontAsk")};
          run.innerHTML = `<dl><dt>${tl("session.mode")}</dt><dd>${MODE[a.mode] ? MODE[a.mode]() : esc(a.mode)}</dd></dl>`;
          run.hidden = false; box.querySelector("[data-access-note]").textContent = tl("session.mode.note");
          return;
        }
        const ASK = {never: () => tl("session.run.ask.never"), "on-request": () => tl("session.run.ask.request"), untrusted: () => tl("session.run.ask.untrusted"), "on-failure": () => tl("session.run.ask.failure")};
        const BOX = {"danger-full-access": () => tl("session.run.box.full"), "workspace-write": () => tl("session.run.box.folder"), "read-only": () => tl("session.run.box.read")};
        const word = (map, v) => v == null ? tl("session.access.unknown") : map[v] ? map[v]() : esc(v);
        run.innerHTML = `<dl><dt>${tl("session.run.ask")}</dt><dd>${word(ASK, a.approval)}</dd>
          <dt>${tl("session.run.box")}</dt><dd>${word(BOX, a.sandbox)}</dd>
          <dt>${tl("session.run.net")}</dt><dd>${a.network == null ? tl("session.access.unknown") : a.network ? tl("session.access.allowed") : tl("session.access.notAllowed")}</dd></dl>`;
        run.hidden = false; box.querySelector("[data-access-note]").textContent = tl("session.run.note");
      }, () => {});
      get("/api/connect/perms").then((r) => {
        if (!box.isConnected) return;
        const items = r && r[agent] && r[agent].items;
        if (!Array.isArray(items)) throw new Error("Missing permission state");
        const value = (scope) => {
          const item = items.find((x) => x.scope === scope);
          return !item || typeof item.on !== "boolean" ? tl("session.access.unknown") : item.on ? tl("session.access.allowed") : tl("session.access.notAllowed");
        };
        state.innerHTML = `<dl><dt>${tl("session.access.read")}</dt><dd>${value("read:" + agent + "-sessions")}</dd>
          <dt>${tl("session.access.send")}</dt><dd>${value("session:wake")}</dd>
          <dt>${tl("session.access.manage")}</dt><dd>${value("session:hide")}</dd></dl>`;
      }).catch(() => { if (box.isConnected) state.textContent = tl("session.access.failed"); });
    });
  }
  // One place for an action's name, its one line, and why it is not available right now. The
  // names keep three things apart: 끝내기 turns the session off, 목록에서 숨기기 only hides it from
  // this list, and folding a panel touches no session at all.
  let floating = new Set();
  const MK = {open: "O", fresh: "N", split: "B", float: "F", read: "U", pick: "S", lighten: "M", pin: "P", stop: "E", tidy: "A"};   // the letter beside each choice
  function what(a, s) {
    const ended = s.state === "ended", codex = s.agent === "codex";
    if (a === "pick") return {label: tl("mn.pick")};
    if (a === "read") return {label: s.unread ? tl("mn.read") : tl("mn.unread"),
      off: !s.unread && (where().sid === s.id || (convs[s.id] && convs[s.id].body && convs[s.id].body.isConnected)) ? tl("rd.open") : ""};
    if (a === "split") return {label: tl("split.open"), sub: tl("split.openSub"), off: splitWhy(s.id)};
    if (a === "float") return floating.has(s.id) ? {label: tl("fl.unpin"), sub: tl("fl.unpinSub")} : {label: tl("fl.pin"), sub: tl("fl.pinSub")};
    if (a === "open") return {label: tl("pjx.open"), sub: tl("pjx.open.sub"), short: tl("pjx.open.short"),
      off: ended ? "" : tl("pjx.open.off")};
    if (a === "fresh") return {label: tl("pjx.fresh"), sub: tl("pjx.fresh.sub"), short: tl("pjx.fresh.short")};
    if (a === "lighten") return {label: tl("pjx.move"), sub: tl("pjx.move.sub"), short: tl("pjx.move.short"),
      off: codex ? tl("pjx.move.offCodex") : ended ? tl("pjx.move.offEnded")
        : s.moved ? tl("pjx.move.offMoved")
        : s.lighten && s.lighten.state === "writing" ? tl("pjx.move.offWriting") : ""};
    if (a === "top") return {label: topPinned(s) ? tl("session.top.off") : tl("session.top.on"), sub: tl("session.top.sub")};
    if (a === "pin") return {label: s.pinned ? tl("room.unpin") : tl("room.pin"), sub: s.pinned ? tl("pjx.unpin.sub") : tl("pjx.pin.sub")};
    if (a === "stop") return codex ? {label: tl("room.codexStop"), sub: tl("pjx.cstop.sub"), short: tl("pjx.cstop.short")}
      : {label: tl("mn.stop"), sub: tl("pjx.stop.sub"), short: tl("pjx.stop.short"), off: ended ? tl("pjx.stop.off") : ""};
    return s.tidied ? {label: tl("pjx.untidy"), sub: tl("pjx.untidy.sub"), short: tl("pjx.untidy.short")}
      : {label: tl("pick.tidy"), sub: codex ? tl("pjx.tidy.subCodex") : tl("pjx.tidy.sub"), short: tl("pjx.tidy.short"),
        off: ""};
  }
  // Only a step that cannot simply be taken back asks first. 이어서 하기 wakes the same
  // conversation and 숨기기 only hides a row (its toast offers 되돌리기): both go at one press.
  const ASK = {
    get fresh() { return [tl("pjx.fresh.ask"), tl("pjx.fresh"), "fresh"]; },   // harmless, so it may be switched off
    lighten: null,                       // the server asks (it knows if the session is up)
    stop: null,                          // the server asks twice
  };
  const DONE = LT(() => ({tidy: tl("pjx.done.tidy"), fresh: tl("pjx.done.fresh"), open: tl("pjx.done.open")}));
  const BUSY = LT(() => ({top: tl("session.top.busy"), open: tl("pjx.busy.open"), fresh: tl("pjx.busy.fresh"), lighten: tl("pjx.busy.move"), stop: tl("pjx.busy.stop"), tidy: tl("pjx.busy.tidy"), pin: tl("pjx.busy.pin")}));
  // What is being done to a session right now: shown on its row and above its chat, and its
  // buttons wait, so a slow answer never looks like a press that did nothing.
  const busy = {};
  function setBusy(sid, txt) {
    if (txt) busy[sid] = txt; else delete busy[sid];
    document.querySelectorAll(".pj-row[data-sid]").forEach((n) => { if (n.dataset.sid !== sid) return;
      n.classList.toggle("busy", !!txt); txt ? n.setAttribute("aria-busy", "true") : n.removeAttribute("aria-busy");
      const l = n.querySelector(".pj-stl"); if (l) { if (txt) { l.dataset.was = l.dataset.was || l.textContent; l.textContent = txt; } else if (l.dataset.was) { l.textContent = l.dataset.was; delete l.dataset.was; } } });
    const c = convs[sid];
    if (c && c.body && c.body.isConnected) paint(c.body, c, false, c.entries.length);
  }
  async function control(action, s, name, again) {
    const off = what(action, s).off;
    if (off) return toast(off);
    if (action === "split") return splitAdd({id: s.id, p: name}, "", "");
    if (action === "read") return readFlip(s, again);
    if (action === "pick") { picked.add(s.id); pickFrom = s.id; return pickShow(); }
    if (busy[s.id]) return toast(tl("pjx.busy.wait"));
    const tick = (on) => setBusy(s.id, on ? BUSY[action] : "");
    try {
      if (action === "top") {
        const on = !topPinned(s), r = await act("/api/session/top-pin", {sid: s.id, on}, 0, tick);
        topPins = new Set(r.top_pins || []);
        toast(on ? tl("session.top.done") : tl("session.top.undone")); roomsCache = null; return again();
      }
      if (action === "pin") {
        await act("/api/session/pin", s.pinned ? {name, off: 1} : {name, sid: s.id}, 0, tick);
        toast(s.pinned ? tl("room.unpinned") : tl("room.pinnedNow")); roomsCache = null; return again();
      }
      if (action === "float") {
        // The floating stack (floatwin.py): a card of this conversation on top of other apps.
        const on = !floating.has(s.id), F = window.GenokFloat;
        if (F && F.set) {
          const r = await (on ? F.set(s.id, true, {name, title: title(s), agent: s.agent || "claude"}) : F.off ? F.off(s.id) : F.set(s.id, false));
          on ? floating.add(s.id) : floating.delete(s.id);
          // Only what happened is said: it is up, it is kept for the PC app, or the window did not come up.
          return toast(!on ? tl("fl.unpinned") : !r || r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
        }
        const r = await post("/api/float/pin", {sid: s.id, on, name, title: title(s), agent: s.agent || "claude", open: true});
        floating = new Set(r.pins || []);
        return toast(!on ? tl("fl.unpinned") : r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
      }
      if (action === "tidy" && s.tidied) {
        tick(true); await post("/api/session/untidy", {sid: s.id}); toast(tl("pjx.done.untidy")); return again();
      }
      const q = ASK[action];
      if (q && (await confirmDlg(q[0], q[1], q[2])) !== "ok") return;
      let r;
      if (action === "open") {
        r = await act("/api/session/revive", {sid: s.id}, 0, tick);
        if (r.fallback === "open") {
          // A Claude session reopens in the Claude app's Code list; Codex keeps its terminal.
          r = await act("/api/session/open", s.agent === "codex" ? {sid: s.id} : {sid: s.id, via: "app"}, 0, tick);
          if (r.via === "app") r.message = r.message || tl("pjx.done.app");
        }
      } else if (action === "tidy" && dupUnder.has(s.id)) r = await act("/api/session/tidy-many", {sids: withTwins([s.id])}, 0, tick);   // with the ones folded behind it
      else r = await act("/api/session/" + action, {sid: s.id}, 0, tick);
      if (r.terminal) { tick(false); await infoDlg(r.message); return; }
      if (action === "tidy") showTidied = "";   // a hide puts the row away, even with the hidden ones open
      if (action === "tidy" && typeof toastAct === "function") toastAct(r.message || (r.app === "codex" ? tl("pjx.done.tidyCodex") : DONE.tidy), tl("toggleFav.3"), async () => {
        try { await post("/api/session/untidy", {sids: r.sids || [s.id]}); roomsCache = null; again(); } catch (e) { toast(e.message); } });
      else toast(r.message || DONE[action] || tl("pjx.done"));
      if (action === "tidy" && where().sid === s.id) return nav("project/" + enc(name));
      roomsCache = null;
      // 새로 켜기 opens in the background and answers with the new session: go straight to it.
      if (action === "fresh" && r.sid && where().name !== MULTI) return nav("project/" + enc(name) + "/" + enc(r.sid));
      again();
    } catch (e) { if (e.message !== "cancelled") toast(e.message); }
    finally { setBusy(s.id, ""); }
  }

  // 읽지 않음으로 표시 puts the read marker back before the newest reply (the row gets its dot and
  // 내 차례 again); 읽음으로 표시 moves it to the end, as opening the chat does.
  async function readFlip(s, again) {
    const sid = s.id, n = s.unread ? 0 : 1;
    try {
      if (!n) await post("/api/room-read-all", {keys: [sid]});
      else if (!(await post("/api/room-unread", {sid})).ok) return toast(tl("rd.none"));
      readLocal(sid, n);
      if (typeof drawChrome === "function") drawChrome();
      toast(n ? tl("rd.unreadDone") : tl("rd.readDone")); again();
    } catch (e) { toast(e.message); }
  }
  // What the list remembers follows at once (as markRead does for a chat that was opened).
  function readLocal(sid, n) {
    Object.keys(projSeen).forEach((p) => { const v = projSeen[p], x = ((v.v && v.v.sessions) || []).find((y) => y.id === sid); if (x && (x.unread || 0) !== n) { x.unread = n; v.k = JSON.stringify(v.v); } });
    (roomsCache || []).forEach((r) => { if (r.sid === sid) r.unread = n; (r.more || []).forEach((m) => { if (m.sid === sid) m.unread = n; }); });
    if (typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.unread = n; });
    if (convs[sid]) convs[sid].readSent = null;        // opening it later reads it again
  }

  // The new-session row's menu: the one choice, 숨기기, like a session's. `again` redraws the list.
  function draftMenu(btn, name, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    pop.innerHTML = `<button data-a="tidy">${ic("archive")}<span>${esc(tl("mn.tidy"))}</span></button>`;
    popAt(pop, btn);
    pop.querySelector("[data-a]").onclick = (e) => { e.stopPropagation(); pop.remove(); hideDraft(name, again); };
  }
  function hideDraft(name, again) {
    const was = dropDraft(name), at = where();
    toastAct(tl("pick.tidyDone", {n: 1}), tl("pick.undo"), () => { backDraft(name, was); if (where().name === name && where().sid === NEW) again(); else nav("project/" + enc(name) + "/" + NEW); });
    if (at.name === name && at.sid === NEW) nav("project/" + enc(name)); else again();
  }

  // ---- several sessions at once ----------------------------------------------------------------
  // Ctrl (or Cmd) click picks a row, Shift click picks the run up to it, 선택 in a row's menu
  // starts it too. While picking, a click picks instead of opening and a bar stands in the list's
  // head: 읽음으로 표시, 목록에서 숨기기, and more behind the dots. Each does what the row's own
  // menu does, once for all of them. 끝내기 shows only while a picked session is on, and asks
  // once before it ends them. Esc or the cross leaves.
  const picked = new Set();
  let pickOn = false, pickFrom = "", pickNew = false;
  const pickRows = () => [...document.querySelectorAll(".pj-rail .pj-srows .pj-srow[data-sid],.pj-rail .pj-srows .pj-srow[data-dr]")];
  const pkey = (r) => r.dataset.sid || (r.dataset.dr ? NEW : "");     // the new-session row is picked as NEW
  const pickUp = () => [...picked].filter((id) => railRows.has(id) && railRows.get(id).s.state !== "ended");
  const pickBar = () => { const none = picked.size ? "" : ` aria-disabled="true"`, b = (k, i, t, short) => `<button class="pj-pb press${k === "end" ? " dz" : ""}${short ? " lb" : ""}${k === "tidy" || k === "end" ? " tx" : ""}" data-pk="${k}"${k === "off" || k === "more" ? "" : none} aria-label="${esc(t)}" title="${esc(t)}"${k === "more" ? ` aria-haspopup="menu"` : ""}>${ic(i)}${short ? `<span class="pj-pl">${esc(short)}</span>` : ""}</button>`;
    return `<div class="pj-lhd pj-pick${pickNew ? " new" : ""}" role="toolbar" aria-label="${esc(tl("pick.bar"))}">${b("off", "x", tl("pick.off"))}<b aria-live="polite">${esc(tl("pick.n", {n: picked.size}))}</b>${b("read", "check", tl("mn.read"), tl("pick.read.s"))}${b("tidy", "archive", tl("pick.tidy"), tl("pick.tidy.s"))}${pickUp().length ? b("end", "power", tl("mn.stop"), tl("mn.stop")) : ""}${b("more", "more", tl("mn.more"))}</div>`; };
  function pickMarks(box) {
    box.classList.toggle("picking", pickOn); pickNew = false;
    // Where the sticky bar stops: the top of the list when it scrolls itself, else under the page's top bar.
    const own = /auto|scroll/.test(getComputedStyle(box).overflowY), tb = document.getElementById("top");
    box.style.setProperty("--pk-top", !pickOn || own || !tb ? "0px" : Math.max(0, Math.round(tb.getBoundingClientRect().bottom)) + "px");
    box.querySelectorAll(".pj-srows .pj-srow[data-sid],.pj-srows .pj-srow[data-dr]").forEach((r) => { const on = pickOn && picked.has(pkey(r)); r.classList.toggle("pk", on); on ? r.setAttribute("aria-selected", "true") : r.removeAttribute("aria-selected"); });
  }
  let pickStay = false;
  function pickShow() { pickNew = !pickOn; pickOn = true; if (railNow) railNow(); }
  function pickEnd() { if (!pickOn) return; pickOn = false; pickStay = false; picked.clear(); pickFrom = ""; if (railNow) railNow(); }
  // A click on a session row: true when it picked (and so must not open the chat).
  function pickClick(e, c) {
    const sid = pkey(c), mod = e.ctrlKey || e.metaKey;
    if (!c.matches(".pj-srows .pj-srow") || (!pickOn && !mod && !e.shiftKey)) return false;
    // With a mouse a plain click leaves the picking and opens the session, as in a file manager;
    // a finger has no Ctrl, so a tap keeps picking.
    // Unless picking was asked for by its button: then every click picks, until the bar is shut.
    if (pickOn && !mod && !e.shiftKey && !phoneList() && !pickStay) { pickEnd(); return false; }
    const ids = pickRows().map(pkey), on = document.querySelector(".pj-rail .pj-srow.on[data-sid]");
    const a = ids.indexOf(pickFrom || (on ? on.dataset.sid : sid)), b = ids.indexOf(sid);
    if (e.shiftKey && a >= 0 && b >= 0) { ids.slice(Math.min(a, b), Math.max(a, b) + 1).forEach((x) => picked.add(x)); const sel = getSelection(); if (sel) sel.removeAllRanges(); }
    else { picked.has(sid) ? picked.delete(sid) : picked.add(sid); pickFrom = sid; }
    pickShow();
    return true;
  }
  function pickDo(a, btn, again) {
    if (a === "off") return pickEnd();
    if (a === "more") return pickMenu(btn, again);
    if (a === "all" || a === "stale") { pickRows().forEach((r) => { if (a === "all" || r.classList.contains("s-stale")) picked.add(pkey(r)); });
      if (a === "stale" && !document.querySelector(".pj-rail .pj-srows .pj-srow.s-stale[data-sid]")) toast(tl("pick.staleNone"));
      return pickShow(); }
    pickRun(a, again);
  }
  // The bar's dots, and a right click on a row while picking: the same choices, with their letters.
  function pickMenu(btn, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    const none = picked.size ? "" : ` aria-disabled="true"`, K = {read: "U", tidy: "A", end: "E"};
    const it = (a, i, t) => `<button data-a="${a}"${a === "end" ? ` class="dz"` : ""}${K[a] ? none + ` data-k="${K[a]}" aria-keyshortcuts="${K[a]}"` : ""}>${ic(i)}<span>${esc(t)}</span>${K[a] ? keyCaps(K[a]) : ""}</button>`;
    pop.innerHTML = it("all", "check", tl("pick.all")) + it("stale", "moon", tl("pick.stale")) + `<hr>` + it("read", "eye", tl("mn.read")) + it("tidy", "archive", tl("pick.tidy")) + (pickUp().length ? `<hr>` + it("end", "stop", tl("mn.stop")) : "");
    popAt(pop, btn);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); if (b.getAttribute("aria-disabled")) return toast(tl("pick.none")); pop.remove(); pickDo(b.dataset.a, b, again); });
  }
  async function pickRun(a, again) {
    const sids = [...picked].filter((id) => railRows.has(id)), up = sids.filter((id) => railRows.get(id).s.state !== "ended"), ended = sids.filter((id) => !up.includes(id));
    const dr = a === "tidy" && picked.has(NEW);        // the new-session row: hiding it forgets the draft
    if (!sids.length && !dr) return toast(tl("pick.none"));
    try {
      if (a === "read") {
        await post("/api/room-read-all", {keys: sids}); sids.forEach((id) => readLocal(id, 0));
        if (typeof drawChrome === "function") drawChrome();
        toast(tl("pick.readDone", {n: sids.length}));
      } else if (a === "end") {
        // 끝내기 for the ones that are on, asked once for all of them (취소 has the focus). Each is
        // ended the way its own row's 끝내기 does, one after another; what has ended is left alone.
        if (!up.length) return toast(tl("pick.endNone"));
        const nm = (id) => title(railRows.get(id).s), names = up.slice(0, 5).map(nm).join(", ") + (up.length > 5 ? " " + tl("pick.endMore", {n: up.length - 5}) : "");
        if ((await ask(`<h3>${esc(tl("pick.endAsk", {n: up.length}))}</h3><p class="pj-dsub">${esc(names)}</p>
          <div class="acts"><button class="pj-btn light full press" data-v="ok">${esc(tl("mn.stop"))}</button><button class="pj-btn full press" data-v="cancel">${tl("libDraw.22")}</button></div>`,
          (box) => setTimeout(() => { const c = box.querySelector("[data-v='cancel']"); if (c && c.isConnected) c.focus({preventScroll: true}); }, 0))) !== "ok") return;
        let done = 0; const bad = [];
        for (const id of up) {
          setBusy(id, BUSY.stop);
          try { const r = await act("/api/session/stop", {sid: id, confirm: 2}); if (r.terminal || r.ok === false) bad.push(nm(id)); else done++; }
          catch (e) { if (e.message === "cancelled") { setBusy(id, ""); break; } bad.push(nm(id)); }
          setBusy(id, "");
        }
        toast(bad.length ? tl("pick.endFail", {n: done, bad: bad.join(", ")}) : tl("pick.endDone", {n: done}));
      } else {
        // Hiding is reversible and never stops selected sessions. A picked row takes the same-titled
        // sessions folded behind it along; the toast counts the rows that were picked.
        const done = sids.length ? (await act("/api/session/tidy-many", {sids: withTwins(sids)})).sids || [] : [], at = where(), was = dr ? dropDraft(at.name) : null; showTidied = "";
        toastAct(tl("pick.tidyDone", {n: sids.filter((id) => done.includes(id)).length + (dr ? 1 : 0)}), tl("pick.undo"), () => (done.length ? post("/api/session/untidy", {sids: done}) : Promise.resolve()).then(() => { if (dr) backDraft(at.name, was); roomsCache = null; again(); }).catch((e) => toast(e.message)));
        if (done.includes(at.sid) || (dr && at.sid === NEW)) { pickEnd(); return nav("project/" + enc(at.name)); }
      }
      pickEnd(); roomsCache = null; again();
    } catch (e) { if (e.message !== "cancelled") toast(e.message); }
  }
  // A click anywhere else (the chat, the page around the list, the list's blank space) leaves the
  // picking. The bar, its menus, dialogs and toasts do not; neither do the list's own controls
  // and rows (a row has its own rule above). The click that ends a drag never gets here (split.js).
  document.addEventListener("click", (e) => {
    if (!pickOn || !e.isTrusted && !e.detail && e.target === document) return;
    const t = e.target; if (!t || !t.closest || !t.isConnected) return;
    if (t.closest(".pj-pick,.pj-pop,#sheet,#ov,#toast,.toast,.pj-dlg,dialog,[role=dialog],[role=menu],.pj-srow,.pj-sgl,.pj-sgrp")) return;
    const rail = t.closest(".pj-rail");
    if (rail && t !== rail && !t.matches(".pj-srows")) return;
    pickEnd();
  });
  document.addEventListener("keydown", (e) => {
    if (!pickOn || e.isComposing || document.querySelector(".pj-pop,#sheet.on,#ov.on")) return;
    if (e.key === "Escape") { e.preventDefault(); return pickEnd(); }
    // Ctrl A picks every row shown, unless a field is being typed in.
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.code === "KeyA" && !(e.target.closest && e.target.closest("input,textarea,[contenteditable]"))) { e.preventDefault(); pickDo("all"); }
  });

  // ---- right click on a row --------------------------------------------------------------------
  // A session row, a session card and a project's name open the menu their ⋯ button opens, at the
  // pointer: right click, Shift F10 or the menu key on a focused row, a long press on a touch
  // screen. Nothing else is touched: text, fields and links keep whatever a right click did there.
  const CTX_ROWS = ".pj-srow[data-sid],.pj-srow[data-dr],.pj-card.pj-row[data-sid],.pj-sgl,.pj-srow[data-p],.pj-head";
  let ctxDown = 0, ctxHold = 0, ctxXY = null, ctxHeld = 0, ctxDownHeld = false, ctxLift = 0;
  function rowCtx(row, x, y, kb) {
    // The page's own wrapper: drawn on #view itself, a second copy of the page was added under the first.
    const el = document.querySelector("#view>.pj") || document.querySelector("#view"), again = () => { if (el && el.isConnected && location.hash.startsWith("#project")) draw(el); };
    const h = row.matches(".pj-srow[data-sid]") ? railRows.get(row.dataset.sid) : null;
    const btn = h ? null : row.querySelector("[data-more],[data-gm],[data-hm],[data-dm]");
    if (!h && !btn) return false;
    if (kb) { const b = row.getBoundingClientRect(); x = b.left + Math.min(40, b.width / 2); y = b.bottom - 6; }
    const to = row.matches(".pj-sgl") ? row.querySelector(".pj-sgh") || row : row.matches(".pj-head") ? btn : row;
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    ctxAt = {x, y, row: to, kb, label: h || row.matches(".pj-card") ? tl("pj.menu") : tl("room.deptMenu")};
    // While picking: the row joins the pick and the menu is the one for all of them.
    if (h && pickOn) { picked.add(row.dataset.sid); pickShow(); pickMenu(row, again); }
    else if (h) menu(row, h.s, h.name, again); else btn.click();
    ctxAt = null;                                      // not taken (the button was waiting on something): no stray point
    return true;
  }
  let ctxPress = null;
  function clearPress() {
    if (!ctxPress) return;
    const p = ctxPress; ctxPress = null;
    if (p.spring) p.spring.jump(1);
    p.row.style.removeProperty("scale"); p.row.classList.remove("pj-holding");
  }
  function pressRow(row) {
    row.classList.add("pj-holding");
    const p = ctxPress = {row, spring: null};
    if (!RM() && window.Motion && Motion.phys) {
      p.spring = Motion.phys(1, 420, 40, (x) => { row.style.scale = String(x); });
      p.spring.set(.985);
    }
  }
  document.addEventListener("pointerdown", (e) => {
    ctxDown = performance.now(); clearTimeout(ctxHold); clearPress(); ctxXY = null; ctxDownHeld = false;
    if (e.pointerType === "mouse" || !e.target.closest) return;
    const row = e.target.closest(CTX_ROWS); if (!row || e.target.closest(".pj-more,a,input,textarea")) return;
    const x = e.clientX, y = e.clientY; ctxXY = [x, y]; pressRow(row);
    // Held without moving: the row is in the hand (it can be carried to another place), and let
    // go where it is it opens the menu. A row that cannot change places opens the menu at once
    // (a phone browser without a contextmenu event gets it here).
    const say = () => { if (row.isConnected && rowCtx(row, x, y, false)) { ctxHeld = performance.now(); return true; } return false; };
    ctxHold = setTimeout(() => { ctxXY = null; clearPress(); if (!row.isConnected) return;
      const got = SP && SP.grab && SP.grab(e, row, say);
      if (got) ctxHeld = performance.now();           // the browser's own long-press menu is not wanted over it
      if (got || say()) { ctxDownHeld = true; if (navigator.vibrate) navigator.vibrate(12); } }, 520);
  }, true);
  document.addEventListener("pointermove", (e) => { if (ctxXY && Math.hypot(e.clientX - ctxXY[0], e.clientY - ctxXY[1]) > 8) { clearTimeout(ctxHold); clearPress(); ctxXY = null; } }, true);
  ["pointerup", "pointercancel"].forEach((k) => document.addEventListener(k, () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; if (ctxDownHeld) { ctxDownHeld = false; ctxLift = performance.now(); } }, true));
  addEventListener("blur", () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; });
  addEventListener("hashchange", () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; });
  // A row in the hand keeps the page from scrolling under the finger.
  document.addEventListener("touchmove", (e) => { if (SP && SP.dragging() && e.cancelable) e.preventDefault(); }, {passive: false});
  // The lift that ends a hold must not also open the conversation under the finger.
  // Nor press whatever the menu put under it: the click of that same lift is dropped wherever it lands.
  document.addEventListener("click", (e) => { const now = performance.now(); if (!e.isTrusted) return;
    if ((ctxLift && now - ctxLift < 500) || (ctxHeld && now - ctxHeld < 1200 && !e.target.closest(".pj-pop"))) { ctxHeld = ctxLift = 0; e.preventDefault(); e.stopPropagation(); } }, true);
  document.addEventListener("contextmenu", (e) => {
    const t = e.target;
    if (!t.closest || t.closest("input,textarea,[contenteditable],a[href],.pj-pop")) return;
    const row = t.closest(CTX_ROWS); if (!row) return;
    const sel = getSelection(); if (sel && !sel.isCollapsed && row.contains(sel.anchorNode)) return;   // marked text: copy stays
    if ((SP && SP.dragging()) || (ctxHeld && performance.now() - ctxHeld < 1200)) return e.preventDefault();   // the hold already answered
    clearTimeout(ctxHold); ctxXY = null;
    // No press came before it: the keyboard asked (Shift F10, the menu key).
    const kb = performance.now() - ctxDown > 700 && row.contains(document.activeElement);
    if (rowCtx(row, e.clientX, e.clientY, kb)) { e.preventDefault(); if (e.pointerType === "touch") ctxHeld = performance.now(); }
  });

  // ==== side by side (web/split.js) ================================================================
  // Up to three columns of conversations on a wide screen, two stacked in each (3 x 2). split.js
  // keeps the layout ({panes, rows, w, h, focus}, on this device) and its limits, the drag out of
  // the list and the dividers; here the panes
  // are drawn (each one is the ordinary chat: drawSession) and the room for them is found.
  // The address always names the focused pane, so a reload, a link and the list all agree.
  const SP = window.PjSplit || null;
  let shownCur = null, splitFresh = null;             // the chat that is drawn ({id, p}); the pane just dropped in
  const splitEl = () => document.querySelector("#view .pj");
  // Width left for the chats with the list `railW` wide and the results `sideW` (36 = the two gaps).
  function splitRoom(el, railW, sideW) {
    const c = el.querySelector(".pj-cols"), cs = c ? null : getComputedStyle(el);
    const w = c ? c.clientWidth : el.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
    return w - railW - sideW - 36;
  }
  // As the two sides are now: the list gives way down to its narrowest by itself (colGrips).
  const splitCap = (el) => SP.cap(splitRoom(el, folded("rail") ? 40 : PJW.l[1][0], folded("side") ? 40 : PJW.r[1][0]));
  const splitBest = (el) => SP.cap(splitRoom(el, 40, 40));               // with both sides folded to their strips
  // Rows that fit in the chat column's height (a short window stacks nothing).
  const splitRows = (el) => { const b = el.querySelector("#pj-body"); return b && b.clientHeight ? SP.capRows(b.clientHeight) : SP.MAXR; };
  // Columns drawn / columns that should be; splitStale: the panes drawn are not the ones that fit now.
  const splitDrawn = (el) => { const s = el.querySelector(".pj-split"); return s ? +s.dataset.n : 1; };
  const splitWant = (el) => { const L = SP && shownCur && SP.load(); return L ? SP.shown(L, splitCap(el)).n : 1; };
  function splitStale(el) {
    const s = el.querySelector(".pj-split"), L = s && SP.load(); if (!L) return false;
    return SP.view(L, splitCap(el), splitRows(el)).panes.map((p) => p.id).join() !== [...s.querySelectorAll(".pj-pane")].map((b) => b.dataset.pane).join();
  }
  // The layout a drop is added to: the saved one, or the single chat on screen.
  // A change always starts from what is on screen: panes the window has no room for right now
  // (kept in the saved layout while it is only looked at) are let go once the person rearranges.
  function splitBase() {
    if (!SP || !shownCur) return null;
    const L = SP.load(), el = splitEl(), ids = el ? [...el.querySelectorAll(".pj-pane")].map((n) => n.dataset.pane) : [];
    if (!L || ids.length < 2) return {panes: [shownCur], w: [1], focus: 0};
    let B = L;
    L.panes.forEach((p) => { if (B && !ids.includes(p.id)) B = SP.remove(B, p.id); });
    return B || {panes: [shownCur], w: [1], focus: 0};
  }
  const splitAt = (p) => "#project/" + enc(p.p) + "/" + enc(p.id);
  // A list row names its session (data-sid) or a project that opens on its current one (data-p).
  function splitRow(row) {
    const box = row.closest(".pj-rail");
    if (row.dataset.sid) return {id: row.dataset.sid, p: row.dataset.pn || (box && box.dataset.pn) || where().name};
    const r = (roomsCache || roomsSeen || []).find((x) => x.name === row.dataset.p);
    return r && r.sid ? {id: r.sid, p: r.name} : null;
  }
  const splitCan = (id) => !!SP && wide() && threeCols() && !!shownCur && SP.indexOf(splitBase(), id) < 0;
  // The most this window can hold: columns with both sides folded, rows by its height.
  const splitFit = (el) => ({c: Math.min(SP.MAXC, splitBest(el)), r: splitRows(el)});
  // Why one more would not fit anywhere, in a line ("" when it does).
  function splitWhy(id) {
    const el = splitEl(), L = splitBase(); if (!el || !L) return "";
    const f = splitFit(el);
    if (SP.indexOf(L, id) >= 0 || SP.add(L, {id}, f.c, f.r) !== L) return "";
    return f.c >= SP.MAXC && f.r >= SP.MAXR ? tl("split.full", {n: SP.MAXC * SP.MAXR}) : f.c * f.r < 2 ? tl("split.none") : tl("split.fit", {n: f.c * f.r});
  }
  // One side of a pane: "" it may land there, "same" it would change nothing, else why not.
  function splitSide(pane, target, side) {
    const el = splitEl(), L = splitBase(); if (!el || !L) return "same";
    const no = SP.can(L, pane.id, target, side), f = splitFit(el), tb = side === "t" || side === "b";
    if (no === "same") return no;
    if (no) return splitWhy(pane.id) || (no === "rows" ? tl("split.maxRows", {n: SP.MAXR}) : tl("split.max", {n: SP.MAXC}));   // no place at all, else this side
    if (tb) return f.r < 2 ? tl("split.short") : "";
    return SP.drop(L, pane, target, side).rows.length <= f.c ? "" : f.c < 2 ? tl("split.none") : tl("split.fit", {n: f.c});
  }
  function splitPlan(el, cur, name) {
    let L = SP && SP.load(); if (!L) return null;
    // A stored layout past 3 x 2 was brought inside it: the panes that found no place are named once.
    if (SP.spilled) { toast(tl("split.spilled", {n: SP.spilled.length})); SP.spilled = null; }
    const N = SP.open(L, {id: cur.id, p: name});
    if (N !== L) SP.save(L = N);
    const v = SP.view(L, splitCap(el), splitRows(el)); if (v.panes.length < 2) return null;
    return {L, from: v.from, cols: v.cols, panes: v.panes};
  }
  function splitDraw(el, sp, name, all, my) {
    SP.ensureCss();
    const body = el.querySelector("#pj-body"), fid = sp.L.panes[sp.L.focus].id, n = sp.cols.length;
    const share = sp.cols.reduce((a, c, j) => a + sp.L.w[sp.from + j], 0) || 1;
    el.querySelector(".pj-cols").classList.add("pj-sp");
    // A pane is its session: the box that already shows it stays (its lines, scroll, caret and
    // loop carry on), wherever the layout puts it. Only a pane that was not there is built, and
    // only that one comes in with motion. The order is the layout's, never the list's.
    let wrap = body.querySelector(":scope>.pj-split");
    if (!wrap) { endRun(body); body.innerHTML = `<div class="pj-split"></div><div data-col="side" id="pj-side"></div>`; wrap = body.firstElementChild; }
    wrap.dataset.n = n;
    const had = {}, seq = sp.cols.map((c) => c.map((p) => p.id).join(",")).join("\n");
    wrap.querySelectorAll(".pj-pane").forEach((b) => { had[b.dataset.pane] = b; });
    const fresh = new Set(), gripping = document.body.classList.contains("gripping");
    const slots = [...wrap.querySelectorAll(".pj-pane")], now = new Set(sp.panes.map((p) => p.id));
    const boxes = sp.panes.map((p, i) => {
      let box = had[p.id]; delete had[p.id];
      // Another session took this pane's place: the frame stays, what is in it is drawn again.
      const prev = !box && !(splitFresh && splitFresh.id === p.id) && slots[i];
      if (prev && !now.has(prev.dataset.pane) && had[prev.dataset.pane] === prev) {
        box = prev; delete had[prev.dataset.pane];
        endRun(box); delete box.dataset.up; box.dataset.pane = p.id; box._swap = true;
        box.classList.remove("in", "l", "r", "t", "b");
      } else if (!box) {
        box = document.createElement("section"); fresh.add(box);
        box.className = "pj-pane" + (splitFresh && splitFresh.id === p.id ? " in " + splitFresh.side : "");
        box.dataset.pane = p.id; box.dataset.multi = "1";
      } else box.classList.remove("in", "l", "r", "t", "b");
      box.classList.toggle("focus", p.id === fid);
      if (box.dataset.up && !box._pjRun) delete box.dataset.up;      // its loop ended: it is drawn again
      const k = box.querySelector(":scope>.pj-conv>.pj-nth .k");
      if (k && k.textContent !== String(i + 1)) { k.textContent = i + 1; k.title = "Ctrl " + (i + 1); }
      return box;
    });
    Object.keys(had).forEach((id) => { endRun(had[id]); had[id].remove(); });
    if (wrap._seq !== seq) {
      wrap._seq = seq;
      wrap.querySelectorAll(".pj-dv,.pj-dh").forEach((d) => d.remove());
      // A column is a plain box around its one or two panes: the panes move between them whole.
      const cols = [...wrap.querySelectorAll(":scope>.pj-col")];
      while (cols.length < n) { const c = document.createElement("div"); c.className = "pj-col"; wrap.appendChild(c); cols.push(c); }
      let k = 0;
      sp.cols.forEach((c, j) => c.forEach((p, r) => { const box = boxes[k++]; if (cols[j].children[r] !== box) mMove(cols[j], box, cols[j].children[r] || null); }));
      cols.splice(n).forEach((c) => c.remove());
      cols.slice(1).forEach((c) => c.insertAdjacentHTML("beforebegin", `<div class="pj-dv" role="separator" aria-orientation="vertical" tabindex="0" aria-label="${esc(tl("split.dv"))}" title="${esc(tl("split.dvTip"))}"></div>`));
      // What the dividers leave is written to the columns (and the stacked pair) they stand between.
      const keep = (set) => { const L = SP.load(); if (L && set(L) !== false) SP.save(L); };
      SP.dividers(wrap, (f) => keep((L) => {
        const at = [...wrap.querySelectorAll(":scope>.pj-col")].map((c) => SP.where(L, c.firstElementChild.dataset.pane)); if (at.some((t) => !t)) return false;
        const sum = at.reduce((a, t) => a + L.w[t.c], 0);
        at.forEach((t, j) => { L.w[t.c] = f[j] * sum; });
      }));
      cols.forEach((c) => {
        if (c.children.length < 2) return;
        c.firstElementChild.insertAdjacentHTML("afterend", `<div class="pj-dh" role="separator" aria-orientation="horizontal" tabindex="0" aria-label="${esc(tl("split.dh"))}" title="${esc(tl("split.dhTip"))}"></div>`);
        SP.dividers(c, (f) => keep((L) => { const t = SP.where(L, c.firstElementChild.dataset.pane); if (!t || SP.rowsOf(L)[t.c] < 2) return false; L.h[t.c] = f[0]; }), true);
      });
    }
    // Each column's share of the width, and the top pane's share of a stacked column.
    if (!gripping || fresh.size) {
      let k = 0;
      sp.cols.forEach((c, j) => {
        const col = boxes[k].parentNode, h = sp.L.h && sp.L.h[sp.from + j] > 0 && sp.L.h[sp.from + j] < 1 ? sp.L.h[sp.from + j] : 0.5;
        col.style.flexGrow = (sp.L.w[sp.from + j] / share * n).toFixed(5);
        c.forEach((p, r) => { boxes[k++].style.flexGrow = c.length < 2 ? "1" : ((r ? 1 - h : h) * 2).toFixed(5); });
      });
    }
    splitFresh = null;
    colGrips(el);                                      // the two sides give the panes their room
    const mount = (box, p, s, k) => {
      if (!live(my) || !box.isConnected || box.dataset.up || box.dataset.pane !== p.id) return;
      box.dataset.up = "1"; box.setAttribute("aria-label", title(s));
      drawSession(box, el, s.project || p.p || name, s, my);
      box.querySelector(".pj-conv").insertAdjacentHTML("afterbegin", `<div class="pj-nth${sessName(s, s.project || p.p || name).includes(pname(s.project || p.p || name)) ? " pn" : ""}"><span class="k" title="Ctrl ${k}" aria-hidden="true">${k}</span><div class="tx"><div class="t" title="${esc(title(s))}">${faceMk(emoOf(s.project || p.p || name), colOf(s.project || p.p || name), icoOf(s.project || p.p || name))}${s.fixed ? pinMk() : ""}${esc(unEm(sessName(s, s.project || p.p || name), emoOf(s.project || p.p || name) || icoHtml(icoOf(s.project || p.p || name))))}</div></div>
        <button class="pj-more pj-px press" data-px aria-label="${esc(tl("room.closePane"))}" title="${esc(tl("split.closeTip"))}">${ic("x")}</button></div>`);
      box.querySelector("[data-px]").onclick = (e) => { e.stopPropagation(); splitLeave(el, p.id); };
      if (box._swap) { box._swap = false; const m = box.querySelector("#pj-msgs"); if (m) m.classList.add("pj-swap"); }
    };
    sp.panes.forEach((p, i) => {
      const box = boxes[i], known = p.p === name && all.find((s) => s.id === p.id), c = convs[p.id];
      if (fresh.has(box)) {
        const on = () => { if (!box.classList.contains("focus")) splitFocus(el, box.dataset.pane); };
        box.addEventListener("pointerdown", on, true); box.addEventListener("focusin", on);
      }
      if (box.dataset.up) return;                      // already showing it
      if (known) return mount(box, p, known, i + 1);
      // A session of another project (or one this list no longer shows): what is remembered of it
      // is drawn at once, and the server is asked whether it still exists. Gone: it leaves the layout.
      if (c && c.state && c.state.id === p.id) mount(box, p, c.state, i + 1);
      else if (!box.firstElementChild) box.innerHTML = `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`;
      get("/api/project/session?id=" + enc(p.id)).then((s) => {
        if (!live(my) || !box.isConnected || box.dataset.pane !== p.id) return;
        if (!s || s.found === false) return splitLeave(el, p.id);
        mount(box, p, Object.assign({}, s, {id: p.id}), i + 1);
      }).catch(() => { /* offline: the pane keeps what it shows */ });
    });
    // Panes there is no room to draw are asked about too, so one that is gone does not come back later.
    sp.L.panes.filter((p) => !sp.panes.includes(p) && !(p.p === name && all.some((s) => s.id === p.id))).forEach((p) =>
      get("/api/project/session?id=" + enc(p.id)).then((s) => { if (s && s.found === false) SP.save(SP.remove(SP.load(), p.id)); }).catch(() => {}));
    splitMarks(el);
  }
  // A pane was pressed or typed in: it is the one the address, the results and the list follow.
  // Nothing is drawn again, so the caret and the scroll of every pane stay where they are.
  function splitFocus(el, id) {
    const L = SP.load(), i = SP.indexOf(L, id); if (i < 0) return;
    const p = L.panes[i];
    el.querySelectorAll(".pj-pane").forEach((n) => n.classList.toggle("focus", n.dataset.pane === id));
    if (L.focus !== i) { L.focus = i; SP.save(L); }
    if (location.hash !== splitAt(p)) history.replaceState(null, "", splitAt(p));
    shownCur = {id, p: p.p}; lastSid = id; seenAt = p.p + "/" + id;
    const c = convs[id], box = el.querySelector("#pj-body>#pj-side");
    if (c && box) { delete box.dataset.strip; side(box, c.room || p.p, c); }
    splitMarks(el);
  }
  // Close a pane (its ✕, Alt W, or a session that no longer exists) and show what is left.
  function splitLeave(el, id) {
    const L = SP.load(); if (!L) return draw(el);
    const N = SP.remove(L, id), keep = N ? N.panes[N.focus] : L.panes.find((p) => p.id !== id);
    SP.save(N);
    if (keep) history.replaceState(null, "", splitAt(keep));
    draw(el);
  }
  // Open `pane` on one side of the pane `target` ("l" | "r" | "t" | "b"), or with no target where
  // there is room (a column right of the focused one, else stacked under it). A place the limits
  // or the window have no room for changes nothing and says why. The list narrows by itself; when
  // that is not enough the results fold to their strip, then the list.
  function splitAdd(pane, target, side) {
    const el = splitEl(), base = splitBase(); if (!el || !base) return;
    const why = target ? splitSide(pane, target, side) : splitWhy(pane.id); if (why) return why === "same" ? null : toast(why);
    const f = splitFit(el), N = target ? SP.drop(base, pane, target, side) : SP.add(base, pane, f.c, f.r);
    if (!N || N === base) return;
    const n = N.rows.length;
    if (splitCap(el) < n) setFold("side", true);
    if (splitCap(el) < n) setFold("rail", true);
    SP.save(N);
    splitFresh = {id: pane.id, side: target ? side : SP.where(N, pane.id).r ? "b" : "r"};
    history.replaceState(null, "", splitAt(pane));
    draw(el);
  }
  // The list shows which rows are open in a pane, and which one is the focused pane.
  function splitMarks(el) {
    const rail = el.querySelector(".pj-rail"); if (!rail || !SP) return;
    // On screen: the panes that are drawn (one the window has no room for is not).
    const L = el.querySelector(".pj-split") ? SP.load() : null, ids = L ? [...el.querySelectorAll(".pj-split .pj-pane")].map((n) => n.dataset.pane) : [], fid = L ? L.panes[L.focus].id : "";
    const seen = new Set();
    rail.querySelectorAll(SP.host.rows).forEach((r) => {
      const p = splitRow(r), inp = !!p && ids.includes(p.id);
      r.classList.toggle("vis", inp);
      if (inp) { r.dataset.vis = "1"; seen.add(p.id); } else delete r.dataset.vis;
      if (!L || !p) return;
      r.classList.toggle("on", p.id === fid);
      if (p.id === fid) r.setAttribute("aria-current", "true"); else r.removeAttribute("aria-current");
    });
    // A pane whose row is not in the list (its project is folded, or shows only its newest few).
    rail.querySelectorAll(".pj-sgrp>.pj-sgl").forEach((h) => {
      const g = h.parentNode.dataset.g;
      h.classList.toggle("vis", !!L && L.panes.some((p) => p.p === g && ids.includes(p.id) && !seen.has(p.id)));
    });
  }
  const sideOf = (body) => body.querySelector("#pj-side") || (body.matches(".pj-pane.focus") ? document.querySelector("#pj-body>#pj-side") : null);
  if (SP) {
    SP.host = {
      rows: ".pj-rail .pj-srow[data-sid],.pj-rail .pj-srow[data-p]",
      ok: () => wide() && threeCols() && !!shownCur && !!splitEl(),
      pick: splitRow,
      find: (pane) => [...document.querySelectorAll(SP.host.rows)].find((r) => { const p = splitRow(r); return p && p.id === pane.id; }) || null,
      targets: () => {
        const el = splitEl(), panes = [...el.querySelectorAll(".pj-pane")];
        if (panes.length) return panes.map((n) => ({el: n, id: n.dataset.pane}));
        const c = el.querySelector("#pj-body>.pj-conv");
        return c && shownCur ? [{el: c, id: shownCur.id}] : [];
      },
      // One side of a pane: {ok} it can land there, {hint} it cannot and why, null it would change nothing.
      check: (pane, target, side) => { const why = splitSide(pane, target, side); return why === "same" ? null : why ? {hint: why} : {ok: true}; },
      drop: splitAdd,
      // Let go outside the app's window: the conversation floats where it was let go (floatwin.py
      // reads the pointer's place itself, in the screen's own pixels).
      out: {
        can: (row) => { const B = window.GenokBar; return !!row.dataset.sid && !phoneList() && !!(B && B.native && B.opts && B.opts.dragout); },
        drop: (row) => {
          const sid = row.dataset.sid, p = splitRow(row);
          post("/api/float/pin", {sid, on: true, open: true, at: "cursor", name: p.p, agent: row.classList.contains("cx") ? "codex" : "claude"})
            .then((r) => { floating = new Set(r.pins || []); toast(r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp")); }, (e) => toast(e.message));
        },
      },
      // The same drag changes a row's place in the list; a project's name carries the project.
      sort: !ORD ? null : {
        rows: ".pj-rail .pj-srows .pj-sgl,.pj-rail .pj-srows .pj-srow[data-sid]",
        can: (row) => { const u = ordUnits(row); return !!u && u.units.length > 1; },
        multi: (row) => ordMany(ordUnits(row)).length,
        start: (row) => {
          let u = ordUnits(row); if (!u) return null;
          const grp = ordMany(u);
          // Picked rows leave the list while they are in the hand; the rest trade places around the grabbed one.
          if (grp.length) u = Object.assign({}, u, {every: u.units.map(u.key), many: grp.map(u.key), fold: grp.filter((x) => x !== u.unit), units: u.units.filter((x) => x === u.unit || !grp.includes(x))});
          // A phone's list scrolls with the page: the page is what moves at the edges, under the bars.
          const st = ORD.start(phoneList() ? Object.assign({}, u, {scroller: document.scrollingElement, over: () => {
            const t = document.getElementById("top"), b = document.getElementById("tabbar");
            return {top: t ? t.getBoundingClientRect().bottom : 0, bottom: b ? b.getBoundingClientRect().top : innerHeight};
          }}) : u);
          if (st) st.u = u; return st;
        },
        move: ORD.move, drop: ORD.drop,
        done: (st) => { const r = ORD.done(st); if (r) ordCommit(st.u, r.from, r.to); },
      },
    };
    // Right click (or the menu key) on a list row: the same way in without a drag.
    document.addEventListener("contextmenu", (e) => {
      if (e.defaultPrevented) return;                  // the row's own menu (rowCtx) opened: 나란히 열기 is in it
      const row = e.target.closest && e.target.closest(SP.host.rows); if (!row || !SP.host.ok()) return;
      const p = splitRow(row); if (!p || !splitCan(p.id)) return;
      e.preventDefault();
      document.querySelectorAll(".pj-pop").forEach((x) => x.remove());
      const pop = document.createElement("div"), why = splitWhy(p.id);
      pop.className = "pj-pop wide";
      pop.innerHTML = `<button class="two" ${why ? `aria-disabled="true"` : ""}><span>${esc(tl("split.open"))}</span><small>${esc(why || tl("split.openSub"))}</small></button>`;
      popAt(pop, row);
      pop.firstChild.onclick = (ev) => { ev.stopPropagation(); if (why) return toast(why); pop.remove(); splitAdd(p, "", ""); };
    });
    // Ctrl 1-6 (Alt 1-6 where the browser keeps Ctrl): that pane, ready to type in. Alt W closes
    // the focused pane. Esc does too, but only when nothing else would take it: not while typing
    // or composing, and not with a menu, a sheet or the search open.
    addEventListener("keydown", (e) => {
      if (!location.hash.startsWith("#project/")) return;
      const el = splitEl(), panes = el ? [...el.querySelectorAll(".pj-pane")] : []; if (panes.length < 2) return;
      const k = e.ctrlKey !== e.altKey && !e.shiftKey && !e.metaKey && /^Digit[1-6]$/.test(e.code || "") ? +e.code.slice(5) : 0;
      if (k) {
        const p = panes[k - 1]; if (!p) return;
        e.preventDefault(); splitFocus(el, p.dataset.pane);
        const ta = p.querySelector("#pj-ta"); if (ta) ta.focus({preventScroll: true});
        return;
      }
      const typing = e.target.matches && e.target.matches("input,textarea,gk-select,[contenteditable]");
      const shut = (e.altKey && !e.ctrlKey && !e.metaKey && e.code === "KeyW") || (e.key === "Escape" && !typing && !e.isComposing && e.keyCode !== 229);
      if (!shut || SP.dragging() || (window.LOOP_LAYER_UP && window.LOOP_LAYER_UP()) || document.querySelector(".pj-pop,#ov.on")) return;
      if (pickOn && e.key === "Escape") return;        // Esc leaves the picking first
      const f = el.querySelector(".pj-pane.focus"); if (!f) return;
      e.preventDefault();
      const L = SP.remove(SP.load(), f.dataset.pane), next = L ? L.panes[L.focus] : panes.map((n) => n.dataset.pane).find((id) => id !== f.dataset.pane);
      const c = convs[L ? next.id : next]; if (c) c.focusDraft = true;      // the keyboard stays in a chat
      splitLeave(el, f.dataset.pane);
    }, true);
  }

  // ---- one session: conversation | results + open comments --------------------------------------
  let holds = 0; const HOLD = 3;                      // answers being waited for (tail), and how many may be at once
  // chat-draft:begin
  const CHAT_DRAFT = "genok.chat-draft:", CHAT_DRAFT_AGE = 30 * 86400e3;
  function readDraft(sid) {
    try {
      const value = JSON.parse(localStorage.getItem(CHAT_DRAFT + sid));
      if (value && typeof value.text === "string" && Number.isFinite(value.at)
          && Date.now() - value.at <= CHAT_DRAFT_AGE) return value.text;
      localStorage.removeItem(CHAT_DRAFT + sid);
    } catch (e) { /* unavailable or damaged storage: keep typing */ }
    return "";
  }
  function writeDraft(sid, text) {
    try {
      if (text) localStorage.setItem(CHAT_DRAFT + sid, JSON.stringify({text, at: Date.now()}));
      else localStorage.removeItem(CHAT_DRAFT + sid);
    } catch (e) { /* quota or private mode: the in-memory draft still works */ }
  }
  // chat-draft:end
  // chat-outbox:begin
  // Lines that were still going or had failed outlive a reload, so what happened to them can be
  // checked. One that was mid-send comes back as "not confirmed": it is never sent again by itself.
  const CHAT_OUT = "genok.chat-out:", CHAT_OUT_AGE = 86400e3;
  function readOut(sid, unknown) {
    try {
      const rows = JSON.parse(localStorage.getItem(CHAT_OUT + sid));
      if (Array.isArray(rows)) return rows.filter((r) => r && typeof r.text === "string" && Number.isFinite(r.at) && Date.now() - r.at <= CHAT_OUT_AGE)
        .map((r) => ({text: r.text, said: r.text, imgs: [], at: r.at, busy: false, kept: true, uncertain: !r.failed || !!r.uncertain, failed: r.failed && !r.uncertain ? r.failed : unknown}));
    } catch (e) { /* unavailable or damaged storage: nothing to bring back */ }
    return [];
  }
  function writeOut(sid, pend) {
    try {
      const rows = pend.filter((p) => p.text && (p.busy || p.failed)).map((p) => ({text: p.text, at: p.at, failed: p.busy ? "" : p.failed, uncertain: !!p.uncertain}));
      if (rows.length) localStorage.setItem(CHAT_OUT + sid, JSON.stringify(rows));
      else localStorage.removeItem(CHAT_OUT + sid);
    } catch (e) { /* quota or private mode: the line is still in this page */ }
  }
  // chat-outbox:end
  function C(sid) {
    return convs[sid] || (convs[sid] = {out: sid, entries: [], offset: null, results: [], queued: [], draft: readDraft(sid), pend: readOut(sid, tl("pj.delivery.unknown")), state: null, loaded: false,
      imgs: [], divTs: undefined, divSeen: false, readSent: null, stick: true, pos: null, unseen: 0, offline: false, waiting: false, stateHtml: "", noteHtml: null, kick: null});
  }
  // Where the person stopped reading, kept across a reload (sessionStorage) so the chat comes back
  // to the same place instead of the top; a chat left at the bottom just lands on the newest.
  const POS = "rl-chat-pos:", TIP = "rl-chat-tip";
  const readPos = (sid) => { try { return JSON.parse(sessionStorage.getItem(POS + sid)); } catch (e) { return null; } };
  const writePos = (sid, p) => { try { sessionStorage.setItem(POS + sid, JSON.stringify(p)); } catch (e) { /* private window: fine */ } };
  const tipOn = () => { try { return localStorage.getItem(TIP) !== "1"; } catch (e) { return true; } };
  const tipOff = () => { try { localStorage.setItem(TIP, "1"); } catch (e) { /* shown again next time */ } };
  const nearEnd = (box) => box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  // Where the reading stands, in a form that survives the log being built again: at the end, or on
  // a line (which one, and how far its top is from the box's top edge). `top` is the old fallback.
  const lines = (box) => box.querySelectorAll(":scope>.pj-msg:not([data-pend])");
  function spot(box, stick) {
    const p = {top: box.scrollTop, stick};
    if (stick) return p;
    const t = box.getBoundingClientRect().top, ls = lines(box);
    for (let i = 0; i < ls.length; i++) {
      const r = ls[i].getBoundingClientRect();
      if (r.height && r.bottom > t + 1) { p.k = i; p.at = ls[i].dataset.at || ""; p.off = Math.round(r.top - t); break; }
    }
    return p;
  }
  function seat(box, p) {
    if (!p || p.stick) { box.scrollTop = box.scrollHeight; return; }
    const ls = lines(box);
    let n = p.k != null && ls[p.k];
    if (p.at && !(n && n.dataset.at === p.at)) n = [...ls].find((x) => x.dataset.at === p.at) || n;
    if (n) box.scrollTop += n.getBoundingClientRect().top - box.getBoundingClientRect().top - p.off;
    else box.scrollTop = p.top || 0;
  }
  // After the log is built again the page around it is still finding its size (the columns are
  // fitted, pictures and fonts come in). Until the person touches the chat, or a moment passes,
  // the spot is held: every change of size seats the log on it again.
  function letGo(box, c) {
    if (!c.hold) return;
    clearTimeout(c.holdT); c.hold = null;
    if (box.isConnected && box.clientHeight) { c.stick = nearEnd(box); endBtn(box, c); }
  }
  function hold(box, c, p) {
    clearTimeout(c.holdT); c.hold = p; c.stick = !!p.stick;
    c.holdT = setTimeout(() => letGo(box, c), 1500);
  }
  // One control for the way down. It shows once the end is more than a third of the box away, or
  // when lines arrived out of sight - then it carries their count.
  function endBtn(box, c) {
    const pill = box.parentNode && box.parentNode.querySelector(".pj-newpill"); if (!pill) return;
    const far = box.scrollHeight - box.scrollTop - box.clientHeight;
    const on = !box._end && !c.stick && (c.unseen > 0 || far > box.clientHeight / 3);
    const n = on ? c.unseen : 0, t = n ? tl("pj.newMsg", {n}) : tl("pj.toEnd"), b = pill.querySelector("b"), nt = n ? (n > 99 ? "99+" : String(n)) : "";
    pill.classList.toggle("on", on);
    if (b && b.textContent !== nt) b.textContent = nt;
    if (pill.title !== t) { pill.title = t; pill.setAttribute("aria-label", t); }
  }
  // Never a long ride: from far away the log lands a box and a half short of the end first and
  // only that last stretch is eased (200ms). Touching the log takes it back at once.
  function endStop(box, c) {
    if (!box._end) return;
    cancelAnimationFrame(box._end); box._end = 0;
    c.stick = nearEnd(box); endBtn(box, c);
  }
  function toEnd(box, c) {
    const max = () => box.scrollHeight - box.clientHeight;
    cancelAnimationFrame(box._end); box._end = 0;
    clearTimeout(c.holdT); c.hold = null; c.stick = true; c.unseen = 0;
    if (RM() || max() - box.scrollTop < 2) { box.scrollTop = max(); endBtn(box, c); return; }
    const from = Math.max(box.scrollTop, max() - box.clientHeight * 1.5), t0 = performance.now();
    const step = (now) => {
      const k = Math.max(0, Math.min(1, (now - t0) / 200));
      box.scrollTop = Math.max(box.scrollTop, k < 1 ? from + (max() - from) * (1 - Math.pow(1 - k, 3)) : max());
      box._end = k < 1 && box.isConnected ? requestAnimationFrame(step) : 0;
    };
    box.scrollTop = from; box._end = requestAnimationFrame(step); endBtn(box, c);
  }
  // ---- from one line of mine to the next ----------------------------------------------------------
  // A long answer leaves the log at its end, and where it begins is right under my line. Alt+Up and
  // Alt+Down seat the log on the line of mine above or below its top edge (past the newest: the
  // end); `last` goes to my newest wherever the log stands. The line found shows itself once.
  function hop(box, c, d, last) {
    const mine = [...box.querySelectorAll(":scope>.pj-msg.user")], t = box.getBoundingClientRect().top + 12;
    const tops = mine.map((n) => n.getBoundingClientRect().top);
    const i = last ? mine.length - 1 : d < 0 ? tops.findLastIndex((y) => y < t - 2) : tops.findIndex((y) => y > t + 2);
    if (i < 0 || (d > 0 && !last && box.scrollHeight - box.scrollTop - box.clientHeight < 2)) { if (d > 0) toEnd(box, c); return; }
    cancelAnimationFrame(box._end); box._end = 0; letGo(box, c);
    box.scrollTop += tops[i] - t;
    c.stick = nearEnd(box); if (c.stick) c.unseen = 0; endBtn(box, c);
    mine[i].animate([{opacity: .35}, {opacity: 1}], {duration: 320, easing: "ease-out"});
  }
  // ---- what was said before the first look ----------------------------------------------------------
  // The first look reads the end of the record (c.start: the byte its oldest line begins at, 0 =
  // nothing before it). While there is more, the log's first child is the row that brings it; the
  // lines go in above and what is being read stays where it is.
  function olderRow(box, c) {
    const b = box.querySelector(":scope>.pj-older"), on = c.start > 0 && c.entries.length > 0;
    if (b && !on) { if (b === document.activeElement) box.focus({preventScroll: true}); b.remove(); }
    else if (!b && on) box.insertAdjacentHTML("afterbegin", `<button type="button" class="pj-older press"><span class="pj-spin" aria-hidden="true"></span>${tl("pj.older")}</button>`);
  }
  async function older(c, s, btn) {
    if (c.olderBusy) return;
    const from = c.start;
    c.olderBusy = true; btn.setAttribute("aria-busy", "true");
    try {
      const tx = await loopFetch("/api/sessions/transcript?id=" + enc(s.id) + "&agent=" + enc(s.agent) + "&before=" + from);
      if (c.start !== from || !tx.entries) return;         // the record was read again from its end meanwhile
      c.entries = tx.entries.concat(c.entries); c.start = tx.start || 0;
      const box = c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"); if (!box) return;
      const row = box.querySelector(":scope>.pj-older"), h = box.scrollHeight, top = box.scrollTop, held = box._selectionPaint;
      if (held && held.from != null) held.from += tx.entries.length;
      box.querySelectorAll(":scope>.pj-day").forEach((n) => n.remove());   // stamp() puts the day lines back where they belong now
      const html = tx.entries.map((e) => bubble(e)).join("");
      if (row) row.insertAdjacentHTML("afterend", html); else box.insertAdjacentHTML("afterbegin", html);
      letGo(box, c); paint(c.body, c, false, c.entries.length);
      box.scrollTop = top + box.scrollHeight - h;
      c.stick = nearEnd(box); c.pos = spot(box, c.stick); writePos(s.id, c.pos); endBtn(box, c);
      if (box._find) box._find();
    } catch (e) { toast(tl("pj.older.fail")); }
    finally { c.olderBusy = false; if (btn.isConnected) btn.removeAttribute("aria-busy"); }
  }
  // ---- find in this conversation ------------------------------------------------------------------
  // The app's window has no find of its own, and a browser's would miss folded lines' state. Matches
  // are marked with the CSS highlight API (the lines are not touched, so nothing is drawn again);
  // Enter / Shift+Enter step through them from the newest, Esc closes. Only what this chat has
  // loaded is searched, and only lines on screen (a folded tool run is opened first).
  const HL = window.CSS && window.CSS.highlights && typeof Highlight === "function" ? window.CSS.highlights : null;   // `CSS` here is this file's style text
  function findOpen(conv, seed) {
    const bar = conv && conv.querySelector("#pj-find"), box = conv && conv.querySelector("#pj-msgs");
    if (!bar || !box) return;
    if (!bar._f) {
      const inp = bar.querySelector("input"), n = bar.querySelector(".n"), bs = bar.querySelectorAll("[data-fd]");
      let hits = [], at = -1, back = null;
      const mark = () => { if (!HL) return; HL.set("pj-find", new Highlight(...hits)); HL.set("pj-find-on", new Highlight(...(at >= 0 ? [hits[at]] : []))); };
      const look = (keep) => {
        const q = inp.value.trim().toLowerCase(), was = at; hits = [];
        if (q) { const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {acceptNode: (t) => { const p = t.parentElement;
            return p && p.closest(".pj-msg") && !p.closest(".pj-tm,.tg,button") && p.getClientRects().length ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }});
          for (let t; (t = w.nextNode());) { const s = t.data.toLowerCase();
            for (let i = s.indexOf(q); i >= 0; i = s.indexOf(q, i + q.length)) { const r = new Range(); r.setStart(t, i); r.setEnd(t, i + q.length); hits.push(r); } } }
        at = keep && was >= 0 && was < hits.length ? was : hits.length - 1; show(!keep);
      };
      const show = (go) => {
        n.textContent = inp.value.trim() ? (hits.length ? `${at + 1}/${hits.length}` : tl("pj.find.none")) : "";
        bs.forEach((b) => { b.disabled = hits.length < 2; }); mark();
        if (!go || at < 0) return;
        const r = hits[at].getBoundingClientRect(), b = box.getBoundingClientRect(), c = box._c;
        if (r.top < b.top + 52 || r.bottom > b.bottom - 12) { box.scrollTop += r.top - b.top - box.clientHeight / 3; if (c) { letGo(box, c); c.stick = nearEnd(box); endBtn(box, c); } }
      };
      const step = (d) => { if (!hits.length) return; at = (at + d + hits.length) % hits.length; show(true); };
      const shut = () => { bar.classList.remove("on"); hits = []; at = -1; if (HL) { HL.delete("pj-find"); HL.delete("pj-find-on"); }
        box._find = null; const to = back && back.isConnected ? back : conv.querySelector("#pj-ta"); if (to && bar.contains(document.activeElement)) to.focus({preventScroll: true}); };
      let tm = 0;
      inp.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(() => { tm = 0; look(false); }, 120); });
      inp.addEventListener("keydown", (e) => { if (e.isComposing || e.keyCode === 229) return;
        if (e.key === "Enter") { e.preventDefault(); if (tm) { clearTimeout(tm); tm = 0; look(false); } else step(e.shiftKey ? 1 : -1); }
        else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); shut(); } });
      bar.addEventListener("mousedown", (e) => { if (e.target.closest("button")) e.preventDefault(); });   // the box keeps the caret
      bar.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; if (b.hasAttribute("data-fdx")) shut(); else step(+b.dataset.fd); });
      // With words given (a line found from the list's search) they are looked for as they are; a
      // finger's keyboard stays down, the line found is already on screen.
      bar._f = {open: (q) => { back = document.activeElement !== inp ? document.activeElement : back; bar.classList.add("on"); box._find = () => look(true);
        if (q != null) inp.value = q;
        if (q == null || !matchMedia("(pointer:coarse)").matches) { inp.focus({preventScroll: true}); inp.select(); }
        if (inp.value.trim()) look(q != null); }};
    }
    bar._f.open(seed);
  }
  // ---- a line of the log, by who said it and when --------------------------------------------------
  const lineAt = (box, side, at) => [...box.querySelectorAll(`:scope>.pj-msg.${side === "user" ? "user" : "claude"}[data-at]:not([data-pend])`)].find((n) => n.dataset.at === at);
  function goLine(box, c, n) {
    cancelAnimationFrame(box._end); box._end = 0; letGo(box, c);
    box.scrollTop += n.getBoundingClientRect().top - box.getBoundingClientRect().top - 12;
    c.stick = nearEnd(box); if (c.stick) c.unseen = 0; endBtn(box, c);
    n.animate([{opacity: .35}, {opacity: 1}], {duration: 320, easing: "ease-out"});
  }
  // A line said before what is loaded: the record is read further back, a few times at most, until
  // it is here. True when the log now stands on it.
  async function seekLine(box, c, s, side, at) {
    for (let k = 0; k < 8; k++) {
      const n = lineAt(box, side, at); if (n) { goLine(box, c, n); return true; }
      const b = box.querySelector(":scope>.pj-older"), was = c.start; if (!b || !(was > 0)) break;
      await older(c, s, b);
      if (c.start === was || !box.isConnected) break;
    }
    return false;
  }
  // The entry a drawn line shows (see nthOf).
  function entryOf(c, n) {
    const side = n.classList.contains("user") ? "user" : "claude", at = n.dataset.at;
    const same = [...n.parentNode.querySelectorAll(`:scope>.pj-msg.${side}[data-at]:not([data-pend])`)].filter((x) => x.dataset.at === at);
    // Only when the log shows as many lines for that moment as the record holds: else none is sure.
    return same.length === c.entries.filter((e) => e.at === at && LINE_SIDE(e) === side).length ? nthOf(c.entries, side, at, same.indexOf(n)) : null;
  }
  // ---- lines kept (고정) ---------------------------------------------------------------------------
  // A line the person wants to find again is kept on the server by who said it and when
  // (rooms.api_marks), so the phone and the PC show the same ones. It is marked where it stands
  // and listed first in 차례 목록.
  function markRows(box, c) {
    const on = new Set((c.marks || []).map((m) => m.kind + "|" + m.at));
    box.querySelectorAll(":scope>.pj-msg[data-at]>.pj-bk").forEach((b) => {
      const n = b.parentNode, is = on.has((n.classList.contains("user") ? "user" : "claude") + "|" + n.dataset.at);
      if (is === n.hasAttribute("data-mk") && b.title) return;
      const t = is ? tl("pj.mark.off") : tl("pj.mark.on");
      n.toggleAttribute("data-mk", is); b.title = t; b.setAttribute("aria-label", t); b.setAttribute("aria-pressed", is ? "true" : "false");
    });
  }
  async function markSet(c, side, at, text) {
    const sid = c.sid || (c.state && c.state.id), on = (c.marks || []).some((m) => m.kind === side && m.at === at);
    try {
      const r = await loopFetch("/api/session/marks", {method: "POST", json: on ? {sid, at, kind: side, off: 1} : {sid, at, kind: side, text}});
      c.marks = r.marks || []; toast(on ? tl("pj.mark.offDone") : tl("pj.mark.onDone"));
      const box = c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"); if (box) markRows(box, c);
    } catch (e) { toast(e.message); }
  }
  function markLine(c, n, words) {
    const e = entryOf(c, n), side = n.classList.contains("user") ? "user" : "claude";
    return markSet(c, side, n.dataset.at, words || (e ? (side === "user" ? parts(unnote(e.text)).words : e.text) : ""));
  }
  // ---- 차례 목록 -----------------------------------------------------------------------------------
  // A long conversation as a list: the lines kept, then every line of mine (newest first) with what
  // the session did after it. A row seats the log on that line. Alt+T, or the chat's menu.
  function turnsOpen(conv, c) {
    const box = conv.querySelector("#pj-msgs"), s = c.state || {}, now = Date.now();
    const ts = turnList(c.entries).filter((t) => t.at).reverse(), mk = (c.marks || []).slice().reverse();
    const when = (at) => { const ms = tmMs(at); return ms == null ? "" : tmDay(ms) === tmDay(now) ? tmText(ms, now).text : new Date(ms).toLocaleDateString(tmLoc(), {month: "short", day: "numeric"}); };
    const took = (t) => { const a = tmMs(t.at), b = tmMs(t.end); return a != null && b != null && b - a >= 1000 ? subDur(b - a) : ""; };
    const head = (t) => { const u = parts(unnote(t)); return (u.words.split("\n").find((l) => l.trim()) || (u.pics.length ? tl("pj.img.look") : "")).trim(); };
    const row = (t) => `<div class="tl-row"><button type="button" class="tl-go press" data-k="user" data-at="${esc(t.at)}"><span class="t">${esc(Redact.show(head(t.text) || ((c.entries[t.i].imgs || []).length ? tl("pj.img.look") : "")))}</span><span class="s">${esc([when(t.at), took(t),
      t.tools ? tl("pj.act.tool", {n: t.tools}) : "", t.files ? tl("pj.turns.files", {n: t.files}) : "", t.out ? tl("pj.sub.tok", {n: ctxTok(t.out)}) : ""].filter(Boolean).join(" · "))}</span></button></div>`;
    const kept = (m) => `<div class="tl-row"><button type="button" class="tl-go press" data-k="${esc(m.kind)}" data-at="${esc(m.at)}"><span class="t">${esc(Redact.show(m.text))}</span><span class="s">${esc([m.kind === "user" ? tl("pj.md.me") : s.agent === "codex" ? "Codex" : "Claude", when(m.at)].filter(Boolean).join(" · "))}</span></button>
      <button type="button" class="tl-x press" data-unmk="${esc(m.kind)}" data-at="${esc(m.at)}" aria-label="${esc(tl("pj.mark.off"))}" title="${esc(tl("pj.mark.off"))}">${ic("x")}</button></div>`;
    sheet(`<div class="pj-dlg pj-tl"><h3>${tl("pj.turns.h")}</h3>
      ${mk.length ? `<div class="pj-lab">${tl("pj.turns.kept")} <span class="n">${mk.length}</span></div><div class="tl-rows">${mk.map(kept).join("")}</div><div class="pj-lab">${tl("pj.turns.mine")} <span class="n">${ts.length}</span></div>` : ""}
      ${ts.length ? `<div class="tl-rows">${ts.map(row).join("")}</div>` : ""}
      ${!ts.length || c.start > 0 ? `<p class="tl-none">${ts.length ? tl("pj.turns.more") : tl("pj.turns.none")}</p>` : ""}</div>`, (bx) => {
      bx.querySelector(".pj-tl").onclick = async (e) => {
        const x = e.target.closest("[data-unmk]"), g = e.target.closest(".tl-go");
        if (x) { await markSet(c, x.dataset.unmk, x.dataset.at); if (document.getElementById("sheet").classList.contains("on")) turnsOpen(conv, c); return; }
        if (!g) return;
        closeSheet();
        if (box.isConnected && !(await seekLine(box, c, s, g.dataset.k, g.dataset.at))) toast(tl("pj.turns.gone"));
      };
    });
  }
  document.addEventListener("keydown", (e) => {
    if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.isComposing || e.code !== "KeyT") return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs"), sh = document.getElementById("sheet");
    if (!box || !box._c || !box.clientHeight || (sh && sh.classList.contains("on"))) return;
    e.preventDefault(); turnsOpen(box.closest(".pj-conv"), box._c);
  });
  // ---- 자주 쓰는 문구 ---------------------------------------------------------------------------------
  // Lines saved to send again (rooms.api_snippets; the same on the phone and the PC). One picked
  // goes into the box at the caret, to change or send; what is in the box now can be saved here.
  // Ctrl+/ in the box, or the chat's menu.
  async function snipOpen(conv) {
    const ta = conv.querySelector("#pj-ta"); let rows;
    try { rows = (await get("/api/snippets")).snippets || []; } catch (e) { return toast(e.message); }
    const draw = () => sheet(`<div class="pj-dlg pj-tl sn"><h3>${tl("pj.snip.h")}</h3>
      ${rows.length ? `<div class="tl-rows">${rows.map((r) => `<div class="tl-row"><button type="button" class="tl-go press" data-sn="${esc(r.id)}"><span class="t">${esc(r.text)}</span></button>
        <button type="button" class="tl-x press" data-snx="${esc(r.id)}" aria-label="${esc(tl("pj.snip.drop"))}" title="${esc(tl("pj.snip.drop"))}">${ic("x")}</button></div>`).join("")}</div>` : ""}
      ${ta.value.trim() ? `<button type="button" class="pj-btn light full press" data-snsave>${tl("pj.snip.save")}</button>` : `<p class="tl-none">${tl("pj.snip.how")}</p>`}</div>`, (bx) => {
      bx.querySelector(".pj-tl").onclick = async (e) => {
        const g = e.target.closest("[data-sn]"), x = e.target.closest("[data-snx]"), sv = e.target.closest("[data-snsave]");
        if (g) {
          const r = rows.find((q) => q.id === g.dataset.sn); closeSheet(); if (!r || !ta.isConnected) return;
          ta.setRangeText(r.text, ta.selectionStart, ta.selectionEnd, "end"); ta.dispatchEvent(new Event("input", {bubbles: true}));
          setTimeout(() => { if (ta.isConnected) ta.focus({preventScroll: true}); }, 60); return;
        }
        if (!x && !sv) return;
        try { rows = (await loopFetch("/api/snippets", {method: "POST", json: x ? {id: x.dataset.snx, off: 1} : {text: ta.value}})).snippets || []; if (sv) toast(tl("pj.snip.saved")); draw(); }
        catch (er) { toast(er.message); }
      };
    });
    draw();
  }
  // ---- said in a conversation: the list's search also looks inside the records ----------------------
  // Under the sessions found by name, the newest lines that hold every word typed (sessions_ctl.
  // search_talk: the end of the newest records). A row opens that conversation on the line, with
  // the words marked by its find bar. The rows are this file's own node, put back after the list
  // is drawn again.
  let talkQ = "", talkT = 0, talkEl = null, talkAsk = 0;
  function talkPut(box) {
    const q = sessQ.trim();
    if (q.length < 2) { talkQ = ""; talkAsk++; clearTimeout(talkT); if (talkEl) talkEl.remove(); talkEl = null; return; }
    if (talkEl && talkEl.parentNode !== box) box.appendChild(talkEl);
    if (q === talkQ) return;
    talkQ = q; clearTimeout(talkT); const ask = ++talkAsk;
    talkT = setTimeout(async () => {
      let r; try { r = await get("/api/project/search?q=" + enc(q)); } catch (e) { return; }
      if (ask !== talkAsk || !r.hits) return;
      const rail = document.querySelector(".pj-rail"), words = q.toLowerCase().split(/\s+/).filter(Boolean);
      if (talkEl) talkEl.remove(); talkEl = null;
      const rows = r.hits.map((h) => { const row = railRows.get(h.id), pn = row ? row.name : h.project || "", x = h.hits[0]; if (!pn || !x) return "";
        return `<button type="button" class="pj-tk press" data-tk="${esc(h.id)}" data-pn="${esc(pn)}" data-k="${esc(x.kind === "user" ? "user" : "claude")}" data-at="${esc(x.at || "")}"><span class="t"><span>${esc(Redact.show(row ? title(row.s) : h.title || pname(pn)))}</span>${h.n > 1 ? `<i>${tl("pj.talk.n", {n: h.n})}</i>` : ""}</span><span class="x">${markWords(Redact.show(x.text), words, esc)}</span></button>`; }).filter(Boolean);
      if (!rows.length || !rail) return;
      talkEl = document.createElement("div"); talkEl.className = "pj-talk";
      talkEl.innerHTML = `<div class="h">${tl("pj.talk.h")}</div>` + rows.slice(0, 20).join("");
      rail.appendChild(talkEl);
    }, 300);
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-tk"); if (!b) return;
    const c = C(b.dataset.tk), bx = c.loaded && c.body && c.body.isConnected && c.body.querySelector("#pj-msgs");
    // The find bar looks for one run of letters: of the words typed, the longest.
    const q = talkQ.split(/\s+/).sort((x, y) => y.length - x.length)[0];
    // The conversation is already on screen: it goes to the line as it is.
    if (bx) { findOpen(bx.closest(".pj-conv"), q); return void seekLine(bx, c, c.state || {}, b.dataset.k, b.dataset.at); }
    c.seek = {side: b.dataset.k, at: b.dataset.at, q};
    nav("project/" + enc(b.dataset.pn) + "/" + enc(b.dataset.tk));
  });
  // ---- a result the session pushed, where it was pushed -------------------------------------------
  // The newest version of each result this session pushed stands in the log before the first line
  // said after it, and opens the result. A push made before what is loaded has no place yet.
  function resRows(box, c) {
    const res = (c.results || []).filter((r) => tmMs(r.at) != null), have = new Map();
    box.querySelectorAll(":scope>.pj-rc").forEach((n) => { if (res.some((r) => rkey(r) + "@" + r.v === n.dataset.rk)) have.set(n.dataset.rk, n); else n.remove(); });
    if (!res.length) return;
    const ls = [...box.querySelectorAll(":scope>.pj-msg.claude[data-at]:not([data-pend]),:scope>.pj-msg.user[data-at]:not([data-pend])")];
    const head = ls.length ? tmMs(ls[0].dataset.at) : null; if (head == null) return;
    res.forEach((r) => {
      const k = rkey(r) + "@" + r.v, t = tmMs(r.at); if (have.has(k) || (c.start > 0 && t < head)) return;
      const html = `<button type="button" class="pj-rc press" data-rk="${esc(k)}" data-go="${esc("item/" + r.project + "/" + r.item)}">${resThumb(r)}<span class="tx"><div class="t">${esc(r.title)}</div><div class="s">${esc(tl("pj.rc.sub", {v: vShort(r.v)}))}</div></span></button>`;
      let a = ls.find((n) => tmMs(n.dataset.at) > t);
      while (a && a.previousElementSibling && a.previousElementSibling.matches(".pj-unread,.pj-pics,.pj-day")) a = a.previousElementSibling;
      const end = a || box.querySelector(":scope>.pj-now");
      if (end) end.insertAdjacentHTML("beforebegin", html); else box.insertAdjacentHTML("beforeend", html);
    });
  }
  // The "새 글" line also says what came in from there on: answers, tool calls, files, results.
  function recap(box, c) {
    const n = box.querySelector(":scope>.pj-unread"), r = n && recapOf(c.entries, c.divTs); if (!n) return;
    const from = tmMs(c.divTs), res = r ? (c.results || []).filter((x) => tmMs(x.at) >= from).length : 0;
    const t = [tl("pj.unread"), r && r.said > 1 ? tl("pj.recap.said", {n: r.said}) : "", r && r.tools ? tl("pj.act.tool", {n: r.tools}) : "", r && r.files ? tl("pj.turns.files", {n: r.files}) : "", res ? tl("pj.recap.res", {n: res}) : ""].filter(Boolean).join(" · ");
    if (n.textContent !== t) n.textContent = t;
  }
  // A line of mine as it is drawn: a comment line's result is the way to that result, when the
  // app knows a result of that name in that project.
  function mineHtml(words) {
    const shown = Redact.show(words), r = shown === words ? commentRef(words) : null;
    let it = null;
    try { it = r && (D.items || []).find((x) => x.project === r.project && (x.title === r.title || x.id === r.title)); } catch (e) { /* items not loaded yet */ }
    return it ? esc(words.slice(0, r.a)) + `<button type="button" class="pj-lk" data-go="${esc("item/" + it.project + "/" + it.id)}">${esc(words.slice(r.a, r.b))}</button>` + plainLinks(words.slice(r.b)) : plainLinks(shown);
  }
  // Ctrl+F (Cmd+F) with a chat on screen opens its find bar (the focused pane's, side by side), but
  // only in the desktop app's own windows: a browser tab keeps Ctrl+F for the browser's find.
  const appWin = () => IN_APP || (FLOAT && !!window.pywebview);
  document.addEventListener("keydown", (e) => {
    if (!appWin()) return;
    if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.isComposing || (e.key !== "f" && e.key !== "F" && e.code !== "KeyF")) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box.clientHeight) return;
    e.preventDefault(); findOpen(box.closest(".pj-conv"));
  });
  // End (or Ctrl+End) with nothing focused goes down in the chat that is open (the focused pane).
  document.addEventListener("keydown", (e) => {
    if (e.key !== "End" || e.target !== document.body || e.altKey || e.shiftKey || e.metaKey) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box._c || !box.clientHeight) return;
    e.preventDefault(); toEnd(box, box._c);
  });
  // Alt+Up / Alt+Down with nothing focused: from one line of mine to the next (hop), in that chat.
  document.addEventListener("keydown", (e) => {
    if (!e.altKey || (e.key !== "ArrowUp" && e.key !== "ArrowDown") || e.target !== document.body || e.ctrlKey || e.shiftKey || e.metaKey) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box._c || !box.clientHeight) return;
    e.preventDefault(); hop(box, box._c, e.key === "ArrowUp" ? -1 : 1);
  });

  function drawSession(body, root, name, s, my) {
    const c = C(s.id); c.state = s; c.body = body; c.room = name;
    endRun(body);                                     // the box showed another conversation: its loops end here
    if (!c.pos) c.pos = readPos(s.id);
    c.unseen = 0; c.stateHtml = ""; c.noteHtml = null;
    body.innerHTML = `
      <div class="pj-seg seg"><button class="${tab === "conv" ? "on" : ""} press" data-t="conv">${tl("pj.tab.conv")}</button>
        <button class="${tab === "side" ? "on" : ""} press" data-t="side">${tl("pj.tab.side")}</button></div>
      <div class="pj-conv" data-col="conv">
        <div id="pj-state"></div>
        <div class="pj-note" id="pj-note"></div>
        <details id="pj-feedback" class="pj-feedback" hidden><summary></summary><div></div></details>
        <div class="pj-tip" id="pj-tip" ${tipOn() ? "" : "hidden"}><span>${tl("pj.tip")}</span>
          <button class="press" data-tipx aria-label="${tl("pj.tipClose")}">${ic("x")}</button></div>
        <div class="pj-wrap"><div class="pj-msgs" id="pj-msgs" aria-live="polite" tabindex="-1"></div>
          <div class="pj-find" id="pj-find" role="search">${ic("search")}<input type="search" enterkeyhint="search" aria-label="${tl("pj.find")}" placeholder="${tl("pj.find")}"><span class="n" aria-live="polite"></span>
            <button class="press" data-fd="-1" aria-label="${tl("pj.find.prev")}" title="${tl("pj.find.prev")}">${ic("up")}</button><button class="press" data-fd="1" aria-label="${tl("pj.find.next")}" title="${tl("pj.find.next")}">${ic("up")}</button><button class="press" data-fdx aria-label="${tl("pj.find.close")}" title="${tl("pj.find.close")}">${ic("x")}</button></div>
          <button class="pj-newpill press" id="pj-pill" aria-label="${tl("pj.toEnd")}" title="${tl("pj.toEnd")}">${ic("up")}<b aria-hidden="true"></b></button></div>
        <div class="pj-att" id="pj-att" hidden></div>
        <div class="pj-todo" id="pj-todo" hidden></div>
        <div class="pj-rd" id="pj-rd"${Redact.on() ? "" : " hidden"}>${ic("eye")}<span>${tl("pj.mask.is")}</span><button type="button" data-unmask>${tl("pj.mask.show")}</button></div>
        <div class="pj-to" id="pj-to">${toLine({name, emoji: emoOf(name), conv: title(s), agent: s.agent || "claude"})}</div>
        <div class="pj-in"><div class="pj-box"><button class="pj-clip press" id="pj-clip" aria-label="${tl("pj.clip")}" title="${tl("pj.clip")}">${ic("image")}</button>
          <input type="file" id="pj-file" accept="image/png,image/jpeg,image/webp,image/gif,application/pdf,text/*,.md,.log,.json,.jsonl,.yaml,.yml,.toml,.ini,.py,.js,.ts,.tsx,.jsx,.css,.c,.h,.cpp,.cs,.java,.kt,.go,.rs,.rb,.php,.swift,.sh,.ps1,.sql,.diff,.patch" multiple hidden>
          <span class="pj-mwrap" id="pj-ml"></span>
          <textarea id="pj-ta" rows="1" placeholder="${tl("pj.ph")}" aria-label="${tl("pj.taLabel")}"></textarea>
          <span class="pj-pjn">${em(emoOf(name))}<span>${esc(unEm(pname(name), emoOf(name)))}</span></span><span class="pj-enter">${tl("room.enterSend")}</span>
          ${micHtml()}
          <button class="pj-go press" id="pj-send" aria-label="${tl("pj.send")}" title="${tl("pj.send")}" disabled>${ic("up")}<span class="pj-spin" aria-hidden="true"></span></button></div></div>
      </div>
      <div data-col="side" id="pj-side"></div>`;
    const again = () => draw(root);
    const ml = body.querySelector("#pj-ml");
    if (ml) modelChip(ml, {sid: s.id});
    // The lines kept in this conversation, asked once per visit; the log marks them when they land.
    get("/api/session/marks?id=" + enc(s.id)).then((r) => { c.marks = r.marks || []; const bx = body.isConnected && body.querySelector("#pj-msgs"); if (bx) markRows(bx, c); }).catch(() => {});
    body.addEventListener("click", body._pjClick = async (e) => { const b = e.target.closest("[data-cmenu]"); if (b) { e.stopPropagation(); menu(b, Object.assign({}, s, c.state), name, again); }
      const g = e.target.closest("[data-chg]"); if (g) showChanges(s.id);
      const l = e.target.closest("[data-bglog]"); if (l) showAgentLog(c.state.bg);
      const ab = e.target.closest("[data-act]"); if (ab) control(ab.dataset.act, Object.assign({}, s, c.state), name, again);
      const qp = e.target.closest("[data-qpick]"); if (qp) qPick(qp);
      const ap = e.target.closest("[data-approve]"), qb = ap && ap.closest(".pj-q");
      if (ap && !ap.disabled) { ap.parentNode.querySelectorAll("button").forEach((n) => { n.disabled = true; });
        // Answered (or already answered elsewhere): the bar goes at once, in place, and the state
        // loop asks every second for a while; the chat is not drawn again. Any other failure puts
        // the buttons back so the press can be tried again.
        const aid = ap.dataset.aid, done = () => { if (c.state && c.state.ask && String(c.state.ask.id) === aid) { c.state = Object.assign({}, c.state); delete c.state.ask; } };
        loopFetch("/api/session/approve", {method: "POST", json: {sid: s.id, id: aid, allow: ap.dataset.approve === "1", answers: qb ? qAnswers(qb) : undefined}})
          .then((j) => { done(); ansMark(s.id, true); toast(srvMsg(j.message || j.error || "")); })
          .catch((er) => { if ((er.raw || er.message) === SRV_ASK_GONE) done(); toast(srvMsg(er.message)); })
          .then(() => { c.noteHtml = ""; c.fastUntil = Date.now() + NOW_FAST; if (body.isConnected) paint(body, c, false, c.entries.length); if (c.kick) c.kick(); }); }
      const gn = e.target.closest("[data-gonew]"); if (gn) nav("project/" + enc(name) + "/" + enc(gn.dataset.gonew));
      const tx = e.target.closest("[data-tipx]"); if (tx) { tipOff(); body.querySelector("#pj-tip").hidden = true; }
      const x = e.target.closest("[data-imgrm]"); if (x) { c.imgs.splice(+x.dataset.imgrm, 1); chips(body, c); }
      // A line that did not get through: send it again from where it stands, or take it away.
      const rs = e.target.closest("[data-resend]"), un = e.target.closest("[data-unsend]");
      const pr = rs ? c.pend[+rs.dataset.resend] : un ? c.pend[+un.dataset.unsend] : null;
      if (rs && pr && pr.failed) {
        if (pr.uncertain && (await confirmDlg(tl("pj.delivery.confirm"), tl("pj.delivery.retry"))) !== "ok") return;
        pr.failed = ""; pr.busy = true; pr.at = Date.now(); paint(body, c, false, c.entries.length); queue(s, c, pr); }
      if (un && pr) { c.pend.splice(c.pend.indexOf(pr), 1); (pr.imgs || []).forEach((im) => URL.revokeObjectURL(im.url)); paint(body, c, false, c.entries.length); } });
    body.querySelectorAll("[data-t]").forEach((b) => b.onclick = () => { tab = b.dataset.t; if (!body.dataset.multi) setFold("tab", tab === "side"); body.querySelectorAll(".pj-seg [data-t]").forEach((x) => x.classList.toggle("on", x === b)); cols(body); side(body.querySelector("#pj-side"), name, c); });
    cols(body);
    const ta = body.querySelector("#pj-ta"); ta.value = c.draft;
    // A follow-up asked from a result (pjDraft): the box is ready to type in, caret at the end.
    if (c.focusDraft) { c.focusDraft = false; setTimeout(() => { if (ta.isConnected) { ta.focus({preventScroll: true}); ta.setSelectionRange(ta.value.length, ta.value.length); } }, 60); }
    // The box grows with what is typed up to six lines (four over a phone's keyboard), then scrolls. Send is live only when there
    // is something to send; while a line is on its way and the box is empty it shows the ring.
    const go = body.querySelector("#pj-send");
    const grow = () => {
      const cs = getComputedStyle(ta), lines = document.body.classList.contains("pj-kb") ? 4 : 6, cap = Math.round((parseFloat(cs.lineHeight) || 22) * lines + parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom));
      if (!ta.value || !ta.scrollHeight) { ta.style.height = ""; return; }   // empty or not laid out: the CSS height (see the room box above)
      ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, cap) + "px";
    };
    c.sync = () => { go.disabled = !(ta.value.trim() || c.imgs.length); go.classList.toggle("busy", !!c.sending); grow(); };
    ta.addEventListener("input", () => { c.recall = null; c.draft = ta.value; writeDraft(s.id, c.draft); c.sync(); });
    // A line of mine put back in the box (mineAll's i-th, -1 = the empty box), caret at its end.
    const recall = (i, all) => { const t = i < 0 ? "" : all[i]; c.recall = i < 0 ? null : {i, text: t};
      ta.value = c.draft = t; writeDraft(s.id, t); c.sync(); ta.setSelectionRange(t.length, t.length); };
    const box0 = body.querySelector(".pj-box");
    box0.addEventListener("click", (e) => { if (e.target === box0) ta.focus(); });
    // Send while it listens: what was heard so far goes at once.
    const send = () => { Dictate.cut(); sendLine(body, s, name, root); };
    micWire(body, ta);
    const conv = body.querySelector(".pj-conv"), fileIn = body.querySelector("#pj-file");
    body.querySelector("#pj-clip").onclick = () => fileIn.click();
    fileIn.onchange = () => { addFiles(body, c, fileIn.files); fileIn.value = ""; };
    ta.addEventListener("paste", (e) => {
      const fs = [...((e.clipboardData && e.clipboardData.files) || [])].filter((f) => f.type.startsWith("image/"));
      if (fs.length) { e.preventDefault(); addFiles(body, c, fs); }
    });
    ["dragenter", "dragover"].forEach((t) => conv.addEventListener(t, (e) => { if ([...(e.dataTransfer ? e.dataTransfer.types : [])].includes("Files")) { e.preventDefault(); conv.classList.add("drop"); } }));
    conv.addEventListener("dragleave", (e) => { if (!conv.contains(e.relatedTarget)) conv.classList.remove("drop"); });
    conv.addEventListener("drop", (e) => { e.preventDefault(); conv.classList.remove("drop"); addFiles(body, c, e.dataTransfer.files); });
    chips(body, c);
    go.onclick = send;
    // Pressing send or the picture button leaves the caret in the box: the keyboard stays up.
    [go, body.querySelector("#pj-clip")].forEach((b) => b.addEventListener("mousedown", (e) => e.preventDefault()));
    // Enter sends, Shift+Enter breaks the line. The Enter that commits a Korean/Japanese/Chinese
    // composition must not send: isComposing (Chrome), keyCode 229 (Safari/IME) and our own flag.
    let composing = false;
    ta.addEventListener("compositionstart", () => { composing = true; });
    ta.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && Dictate.on()) { e.preventDefault(); e.stopPropagation(); Dictate.drop(); return; }
      if (e.code === "Slash" && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) { e.preventDefault(); snipOpen(conv); return; }
      // Up in an empty box brings my last line back to change and send again (as the CLIs do).
      if (e.key === "ArrowUp" && !ta.value && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && !e.isComposing && !composing) {
        const last = lastMine(c), all = mineAll(c);
        if (last) { e.preventDefault(); recall(Math.max(0, all.indexOf(last)), all); }
        return;
      }
      // That line still as it came: Up on its first row steps to the one I sent before it, Down on
      // its last row to the one after (past the newest: the empty box). Changed, the keys are the box's.
      const rc = c.recall;
      if (rc && ta.value === rc.text && (e.key === "ArrowUp" || e.key === "ArrowDown") && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && !e.isComposing && !composing) {
        const up = e.key === "ArrowUp", all = mineAll(c), i = rc.i + (up ? 1 : -1);
        if (i < all.length && !(up ? ta.value.slice(0, ta.selectionStart) : ta.value.slice(ta.selectionEnd)).includes("\n")) { e.preventDefault(); recall(i, all); }
        return;
      }
      // PageUp / PageDown read the log from the box, while the box has nothing of its own to scroll.
      if ((e.key === "PageUp" || e.key === "PageDown") && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && ta.scrollHeight <= ta.clientHeight + 1) {
        e.preventDefault(); endStop(box, c); box.scrollTop += (e.key === "PageUp" ? -.85 : .85) * box.clientHeight; return;
      }
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); send();
    });
    // Scroll: remember where the person is; stay glued to the newest while they are at the end.
    const box = body.querySelector("#pj-msgs"), pill = body.querySelector("#pj-pill");
    let saveT = 0;
    box._c = c;
    box.addEventListener("scroll", () => {
      if (!box.isConnected || !box.clientHeight) return;        // a log that left the page says nothing about where they read
      if (!c.hold && !box._end) { c.stick = nearEnd(box); if (c.stick) c.unseen = 0; }
      endBtn(box, c);
      clearTimeout(saveT);
      saveT = setTimeout(() => { if (!box.isConnected || !box.clientHeight || c.hold) return; c.pos = spot(box, c.stick); writePos(s.id, c.pos); }, 120);
    }, {passive: true});
    box.addEventListener("load", (e) => { if (c.stick && e.target.tagName === "IMG") box.scrollTop = box.scrollHeight; }, true);
    box.addEventListener("click", (e) => { const cp = e.target.closest("[data-copy]"), ol = e.target.closest(".pj-older"), bk = e.target.closest(".pj-bk");
      if (ol) { older(c, s, ol); return; }
      if (bk) { e.preventDefault(); markLine(c, bk.parentNode); return; }
      if (cp) { e.preventDefault(); if (cp.dataset.copy === "code") { const pre = cp.parentNode.querySelector("pre"); copyText(selectedText(pre) || (pre ? pre.textContent.replace(/\n$/, "") : "")); } else copyLine(cp.closest(".pj-msg")); return; }
      const b = e.target.closest(".pj-pic,.pj-md img"), im = b && (b.tagName === "IMG" ? b : b.querySelector("img")); if (im) { e.preventDefault(); picView(box, im); } });
    ["wheel", "touchstart", "pointerdown", "keydown"].forEach((t) => conv.addEventListener(t, () => letGo(box, c), {passive: true}));
    ["wheel", "touchstart", "pointerdown"].forEach((t) => box.addEventListener(t, () => endStop(box, c), {passive: true}));
    conv.addEventListener("keydown", (e) => {
      // The floating stack has Alt+Up / Alt+Down for its own cards.
      if (!FLOAT && e.altKey && (e.key === "ArrowUp" || e.key === "ArrowDown") && !e.ctrlKey && !e.shiftKey && !e.metaKey) { e.preventDefault(); hop(box, c, e.key === "ArrowUp" ? -1 : 1); return; }
      if (e.key !== "End" || e.altKey || e.shiftKey || e.metaKey || e.target.closest("input,textarea,select,[contenteditable]")) return;
      e.preventDefault(); toEnd(box, c);
    });
    pill.onmousedown = (e) => e.preventDefault();               // the composer keeps the keyboard
    pill.onclick = () => { const mine = document.activeElement === pill; toEnd(box, c); if (mine) ta.focus({preventScroll: true}); };
    // Copy buttons preserve the browser selection; a long press uses the native text menu.
    box.addEventListener("mousedown", (e) => { if (e.target.closest("[data-copy],.pj-bk")) e.preventDefault(); });
    const copyText = (text) => {
      const no = () => toast(tl("pj.copyFail"));
      try { navigator.clipboard.writeText(text).then(() => toast(tl("pj.copied")), no); } catch (e) { no(); }
    };
    const copyLine = (m) => {
      const selected = selectedText(m); if (selected) return copyText(selected);
      // An answer is copied as the session wrote it (Markdown: its tables, lists and code fences).
      const src = m.classList.contains("claude") ? entryOf(c, m) : null;
      const tm = m.querySelector(".pj-tm"); if (tm) tm.style.display = "none";   // the words, not when they were said
      const tg = m.querySelector(".tg"), all = m.innerText;        // innerText keeps the line breaks as drawn
      if (tm) tm.style.display = "";
      const text = src ? Redact.show(src.text).trim() : (tg && all.endsWith(tg.innerText) ? all.slice(0, -tg.innerText.length) : all).trim();
      const sp = window.Motion && Motion.SPRINGS && Motion.SPRINGS.snap;
      if (!RM()) m.animate([{transform: "scale(.97)"}, {transform: "none"}], {duration: sp ? sp.ms : 320, easing: sp ? sp.ease : "ease-out"});
      copyText(text);
    };
    // The room for the log changes (the keyboard comes up, the box grows a line): what was at
    // the bottom edge stays at the bottom edge, so the line being answered is not pushed under.
    if (typeof ResizeObserver === "function") {
      // The same watch covers the lines (paint() adds them): one that grows late - a picture, a
      // font, a code block - must not push the newest out of sight while the log is at the end.
      let h0 = box.clientHeight;
      box._ro = new ResizeObserver((es) => {
        const mine = es.some((e) => e.target === box), was = h0, h = box.clientHeight, d = was - h;
        if (mine) h0 = h;
        if (!h) return;
        if (c.hold) seat(box, c.hold);
        else if (c.stick) { if (!box._end) box.scrollTop = box.scrollHeight; }
        else if (mine && d) { if (was) box.scrollTop += d; else seat(box, c.pos); }   // back from hidden: where they were
        endBtn(box, c);
      });
      box._ro.observe(box);
    }
    if (body.dataset.multi) body.querySelector("#pj-side").remove();   // a pane is only the chat
    paint(body, c, true); side(sideOf(body), name, c);
    start(body, s, name, my);
  }
  // chat-recall:begin
  // The words of the newest line I sent in this chat ("" when there is none): one still on its
  // way first, else the newest of mine in the record. Pictures stay where they were.
  function lastMine(c) {
    const p = c.pend[c.pend.length - 1];
    if (p) return parts(p.text).words;
    for (let i = c.entries.length - 1; i >= 0; i--) if (c.entries[i].kind === "user") return parts(unnote(c.entries[i].text)).words;
    return "";
  }
  // Every line I sent in this chat, newest first, for stepping further back with Up; one said
  // twice in a row is one step.
  function mineAll(c) {
    const all = c.pend.map((p) => p.text).reverse().concat(c.entries.filter((e) => e.kind === "user").map((e) => unnote(e.text)).reverse());
    return all.map((t) => parts(t).words).filter((t, i, a) => t && t !== a[i - 1]);
  }
  // chat-recall:end
  // chat-export:begin (pure; tests/chatexport.test.js runs this block on its own)
  // The newest answer whole: everything the session said after my last line that it answered (one
  // answer is several lines here when tools ran in between), as it wrote it - Markdown and all.
  function lastAnswer(entries) {
    const out = [];
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i];
      if (e.kind === "user" && out.length) break;
      if ((e.kind === "claude" || e.kind === "files") && e.text) out.unshift(e.text.trim());
    }
    return out.join("\n\n");
  }
  // The conversation as loaded, as a Markdown document: who speaks and when
  // over each turn (not a heading: answers bring their own), tool lines left out.
  function convMarkdown(entries, o) {
    const out = ["# " + o.title];
    let who = "";
    entries.forEach((e) => {
      const mine = e.kind === "user", text = mine ? o.words(e.text) : e.kind === "claude" || e.kind === "files" ? (e.text || "").trim() : "";
      if (!text) return;
      const w = mine ? o.me : o.agent;
      if (w !== who) { out.push("**" + w + "**" + (e.at ? " · " + o.when(e.at) : "")); who = w; }
      out.push(text);
    });
    return out.join("\n\n") + "\n";
  }
  // chat-export:end
  // chat-turns:begin (pure; tests/chatturns.test.js runs this block on its own)
  // One row per line of mine, in the order said: where it is, when, and what the session did before
  // my next one - when it last wrote, how many lines it said, how many tool calls, how many files it
  // changed, and what the record says its answers cost to write (an answer is several lines here,
  // each with the same count, so a count is taken once per answer id).
  function turnList(entries) {
    const out = []; let t = null, ids = null, files = null;
    entries.forEach((e, i) => {
      if (e.kind === "user") { ids = new Set(); files = new Set(); out.push(t = {i, at: e.at || "", text: e.text || "", end: "", said: 0, tools: 0, files: 0, out: 0}); return; }
      if (!t) return;
      if (e.at && e.kind !== "res") t.end = e.at;
      if (e.kind === "claude") t.said++;
      if (e.kind === "tool") { t.tools++; if (e.cat === "edit" && e.what) { files.add(e.what); t.files = files.size; } }
      if (e.mid && !ids.has(e.mid)) { ids.add(e.mid); t.out += e.out || 0; }
    });
    return out;
  }
  // What came in from one line of the session's on (the line the "새 글" mark stands over).
  function recapOf(entries, at) {
    const i = at ? entries.findIndex((e) => e.kind === "claude" && e.at === at) : -1; if (i < 0) return null;
    const files = new Set(), r = {said: 0, tools: 0, files: 0};
    entries.slice(i).forEach((e) => { if (e.kind === "claude") r.said++; else if (e.kind === "tool") { r.tools++; if (e.cat === "edit" && e.what) files.add(e.what); } });
    r.files = files.size; return r;
  }
  // The n-th line said at `at` on one side, as the log draws them: a line of mine, or one the
  // session wrote (whatever is not mine, a tool call, thinking, or a part of another line).
  const LINE_SIDE = (e) => e.kind === "user" ? "user" : e.kind === "tool" || e.kind === "think" || e.kind === "sub" || e.kind === "res" || e.kind === "files" || e.sub ? "" : "claude";
  const nthOf = (entries, side, at, n) => entries.filter((e) => e.at === at && LINE_SIDE(e) === side)[n] || null;
  // "[Genok 코멘트] 프로젝트 / 결과물 · v002 · 1건": which result a comment line is about, and
  // where its name stands in the line (`a`..`b`).
  function commentRef(text) {
    const m = /^\[Genok 코멘트\] (.+?) \/ (.+?) · v\d+ · /.exec(String(text || "")); if (!m) return null;
    const a = m[0].indexOf("] ") + 2;
    return {project: m[1], title: m[2], a, b: a + m[1].length + 3 + m[2].length};
  }
  // Words found in a line, marked. `words` are lower case; the line keeps its own letters.
  function markWords(text, words, esc) {
    const low = text.toLowerCase(), cuts = [];
    words.forEach((w) => { for (let i = low.indexOf(w); w && i >= 0; i = low.indexOf(w, i + w.length)) cuts.push([i, i + w.length]); });
    cuts.sort((x, y) => x[0] - y[0]);
    let out = "", at = 0;
    cuts.forEach(([x, y]) => { if (x < at) return; out += esc(text.slice(at, x)) + "<mark>" + esc(text.slice(x, y)) + "</mark>"; at = y; });
    return out + esc(text.slice(at));
  }
  // chat-turns:end
  function cols(body) {
    body.querySelectorAll("[data-col]").forEach((c) => c.style.display = (threeCols() || c.dataset.col === tab) ? "" : "none");
    phoneChat();
  }

  // The row above the chat: what the session is doing (the orb moves while it works or when we
  // wait for its answer), then its actions.
  function state(c) {
    const st = (c.state && c.state.state) || "ended", s = c.state || {}, ch = s.changes;
    const n = ch ? (ch.files || 0) + (ch.untracked || 0) : 0;
    const k = kindOf(st, s.last), doing = busy[s.id];
    let mk, label;
    // A plain mark, the same family as the list's dots: a ring that turns while something is on its way.
    if (doing) { mk = `<span class="pj-spin" aria-hidden="true"></span>`; label = doing; }
    else if (st === "live") { mk = dot("live"); label = LABEL.live; }
    else if (c.waiting && st !== "ended") { mk = `<span class="pj-spin" aria-hidden="true"></span>`; label = tl("pj.st.waiting"); }
    else { mk = dot(k); label = LABEL[k] || k; }
    // The session's own actions sit in the open under its state, each with what it does to the
    // conversation; the menu keeps the full list with a line of explanation per row.
    const d = doing ? "disabled" : "";
    const btn = (a, pri) => { const o = what(a, s); return o.off ? "" : `<button class="pj-act press${pri ? " pri" : ""}" data-act="${a}" ${d} title="${esc(o.sub || "")}">${esc(o.label)}</button>`; };
    // One that ended keeps a single small 이어서 하기 beside its state (typing below wakes it too);
    // 새로 켜기 and 목록에서 숨기기 are in the menu at the end of the row.
    const acts = st === "ended" ? "" : btn("fresh") + btn("lighten") + btn("stop"), wake = st === "ended" ? btn("open", true) : "";
    return `<div class="pj-state">${mk}<span class="pj-stl ${doing ? "" : k}">${esc(label)}</span><span class="pj-stx">${c.room ? `<span class="pj-stp">${esc(" · " + pname(c.room))}</span>` : ""} · <span class="pj-agw ${s.agent === "codex" ? "cx" : "cl"}">${s.agent === "codex" ? "Codex" : "Claude Code"}</span></span>${c.offline ? `<span class="off">${tl("pj.offline")}</span>` : ""}${s.bg ? `<span class="pj-bg">${tl("pj.bg")}</span>` : ""}${s.moved ? `<span class="pj-bg">${tl("pj.moved")}</span>` : ""}<span class="sp"></span>
      ${n ? `<button class="pj-chg press" data-chg title="${tl("pj.chg.t")}">${tl("pj.chg", {n})}${ch.ins ? ` <span class="a">+${ch.ins}</span>` : ""}${ch.del ? ` <span class="d">-${ch.del}</span>` : ""}</button>` : ""}
      ${s.bg ? `<button class="pj-text press" data-bglog>${tl("pj.bglog")}</button>` : ""}
      ${wake}<button class="pj-more press" data-cmenu aria-label="${tl("pj.menu")}" title="${tl("pj.menu")}" style="margin:-4px -6px -4px 0">${ic("more")}</button></div>
      ${acts ? `<div class="pj-acts">${acts}</div>` : ""}`;
  }
  const LIGHT = LT(() => ({writing: tl("pjx.lg.writing"), opened: tl("pjx.lg.opened"),
    timeout: tl("pjx.lg.timeout"), failed: tl("pjx.lg.failed")}));
  const span = (sec) => sec < 60 ? tl("pjx.sec", {n: Math.max(0, Math.round(sec))}) : tl("pjx.min", {n: Math.floor(sec / 60)});
  // codex-question:begin
  // A question Codex asks mid-turn (request_user_input): each one with its options, one of which
  // may be pressed, and a line for the person's own words where the question takes them.
  const qHtml = (a) => `<div class="pj-q"><b>${tl("room.codexAskQ")}</b>${a.questions.map((q) => `<div class="pj-qq" data-qid="${esc(q.id)}"><div>${q.header ? `<b>${esc(q.header)}</b> · ` : ""}${esc(q.question)}</div>${
    q.options.map((o) => `<div><button class="press" data-qpick="${esc(o.label)}" aria-pressed="false">${esc(o.label)}</button>${esc(o.description)}</div>`).join("")}${
    q.other ? `<input type="${q.secret ? "password" : "text"}" autocomplete="off" placeholder="${tl("room.codexQNote")}" aria-label="${tl("room.codexQNote")}">` : ""}</div>`).join("")
    }<div class="pj-qa"><button class="press" data-approve="1" data-aid="${esc(a.id)}">${tl("room.codexQSend")}</button><button class="press" data-approve="0" data-aid="${esc(a.id)}">${tl("room.codexQSkip")}</button></div></div>`;
  const qPick = (b) => { const on = b.getAttribute("aria-pressed") === "true";
    b.closest("[data-qid]").querySelectorAll("[data-qpick]").forEach((n) => n.setAttribute("aria-pressed", "false"));
    b.setAttribute("aria-pressed", on ? "false" : "true"); };
  const qAnswers = (box) => { const out = {};
    box.querySelectorAll("[data-qid]").forEach((q) => { const p = q.querySelector('[data-qpick][aria-pressed="true"]'), n = q.querySelector("input");
      out[q.dataset.qid] = {pick: p ? p.dataset.qpick : "", note: n ? n.value : ""}; });
    return out; };
  // codex-question:end
  // The plain sentence under it: how a line will travel, or what is wrong.
  function note(c) {
    const st = (c.state && c.state.state) || "ended", s = c.state || {};
    let line, bad = false, tail = "";
    if (st === "stuck") { line = s.stuck_hint || tl("pj.note.stuck"); bad = true; }
    else if (s.agent === "codex") { line = s.cut ? tl("room.codexCut") : tl("room.codexNote"); bad = !!s.cut;
      tail = (s.cut ? "" : tl("room.codexNoteMore") + " ") + (s.in_app === false ? tl("room.codexOnlyHere") : ""); }
    else if (st === "ended") line = "";      // the box's own placeholder already says a line continues it
    else if (s.reachable) line = tl("pj.note.live");
    else line = tl("pj.note.later");
    // 새로 옮기기 always ends in words: how long it has been writing and when it gives up, the
    // way to the new session once it is open, or why it stopped.
    const L = s.lighten, lg = L && LIGHT[L.state];
    let more = "";
    if (lg) {
      const txt = L.state === "writing" && L.at ? (L.limit ? tl("pjx.lg.forLim", {lg, t: span(Date.now() / 1000 - L.at), lim: span(L.limit)}) : tl("pjx.lg.for", {lg, t: span(Date.now() / 1000 - L.at)})) : (L.why || lg);
      more = `<div class="${L.state === "timeout" || L.state === "failed" ? "bad" : ""}"><b>${tl("pjx.move")}</b> · ${esc(txt)}${L.state === "opened" && L.new ? `<button class="press" data-gonew="${esc(L.new)}">${tl("pjx.lg.go")}</button>` : ""}</div>`;
    } else if (s.ask && s.ask.kind === "question") more = qHtml(s.ask);
    else if (s.ask) {
      // Codex is waiting to be allowed something: said in full, answered here, never on its own.
      const a = s.ask, what = (a.command || a.reason || "") + (a.cwd ? " (" + a.cwd + ")" : "");
      more = `<div style="overflow-wrap:anywhere"><b>${a.kind === "patch" ? tl("room.codexAskFile") : tl("room.codexAskCmd")}</b> · ${esc(what)}<button class="press" data-approve="1" data-aid="${esc(a.id)}">${tl("room.codexAllow")}</button><button class="press" data-approve="0" data-aid="${esc(a.id)}">${tl("room.codexDeny")}</button></div>`;
    } else if (s.moved) more = `<div><b>${tl("pjx.moved")}</b> · ${tl("pjx.moved.d")}</div>`;
    // The Codex app shows a conversation only under a folder it has as a project, so this opens it there by its link.
    const cx = s.agent === "codex" && s.in_app === false ? ` · ${tl("room.codexNotInApp")}` : "";
    return `${line ? `<div class="${bad ? "bad" : line === tl("pj.note.live") ? "nl" : ""}">${more1(esc(line), esc(tail.trim()), "pjnote")}${cx}</div>` : ""}${more}`;
  }

  // ---- pictures in the chat -----------------------------------------------------------------------
  // A file that is not a picture goes by its name (the server keeps the same list: text, code, PDF);
  // the session gets the saved path and reads it itself. Text is 1 MB at most, a PDF 20 MB.
  const IMG_MAX = 4, IMG_BYTES = 20 * 1024 * 1024, DOC_MAX = 4, TEXT_BYTES = 1024 * 1024;
  const DOC_EXT = /\.(pdf|txt|md|markdown|log|csv|tsv|json|jsonl|ya?ml|toml|ini|cfg|conf|env|pyi?|[mc]?js|tsx?|jsx|s?css|[ch]|cc|[ch]pp|cs|java|kt|go|rs|rb|php|swift|sh|bash|zsh|ps1|bat|cmd|sql|diff|patch|tex|rst|lua|r|dart|vue)$/i;
  function addFiles(body, c, files) {
    for (const f of files) {
      const pic = f.type.startsWith("image/");
      if (!pic && !DOC_EXT.test(f.name)) { toast(tl("pj.file.kind")); continue; }
      if (f.size > (pic || /\.pdf$/i.test(f.name) ? IMG_BYTES : TEXT_BYTES)) { toast(pic ? tl("pj.img.size") : tl("pj.file.size")); continue; }
      if (pic && c.imgs.filter((im) => im.url).length >= IMG_MAX) { toast(tl("pj.img.max", {n: IMG_MAX})); continue; }
      if (!pic && c.imgs.filter((im) => !im.url).length >= DOC_MAX) { toast(tl("pj.file.max", {n: DOC_MAX})); continue; }
      c.imgs.push(pic ? {blob: f, url: URL.createObjectURL(f)} : {blob: f, name: f.name});
    }
    chips(body, c);
  }
  function chips(body, c) {
    const box = body.querySelector("#pj-att"); if (!box) return;
    box.hidden = !c.imgs.length;
    box.innerHTML = c.imgs.map((im, i) => `<div class="th${im.url ? "" : " doc"}">${im.url ? `<img src="${im.url}" alt="">` : ic("doc") + `<span>${esc(im.name)}</span>`}<button data-imgrm="${i}" aria-label="${tl("pj.img.rm")}">${ic("x")}</button></div>`).join("");
    if (c.sync && c.body === body) c.sync();
  }
  async function uploadImgs(imgs, sid) {
    if (!imgs.length) return [];
    const t = await act("/api/session/attach-target", {sid}), out = [];
    for (const im of imgs) {
      const r = await fetch(`/api/attach?p=${enc(t.p)}&i=${enc(t.i)}` + (im.name ? "&n=" + enc(im.name) : ""), {method: "POST", headers: {"Content-Type": im.blob.type || (im.name ? "application/octet-stream" : "image/png")}, body: im.blob});
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || tl("pj.img.fail"));
      out.push(j.path);
    }
    return out;
  }
  // A picture travels as a "clip <path>" line (like a comment); the chat shows it as a picture.
  const CLIP = "📎 ";
  function picUrl(path) {
    const seg = String(path).split(/[\\/]/), k = seg.lastIndexOf("_attach");
    return k >= 2 && seg[k + 1] ? "/f/" + enc(seg[k - 2]) + "/" + enc(seg[k - 1]) + "/_attach/" + enc(seg[k + 1]) : "";
  }
  function parts(t) {
    const pics = [], words = [];
    // A clipped file that is no picture stays in the words, by its name alone.
    String(t || "").split("\n").forEach((ln) => { const l = ln.trim(); if (!l.startsWith(CLIP)) words.push(ln); else if (PIC_EXT.test(l)) pics.push(picUrl(l.slice(CLIP.length))); else words.push(CLIP + l.split(/[\\/]/).pop()); });
    return {words: words.join("\n").trim(), pics: pics.filter(Boolean)};
  }
  const rich = (t) => esc(parts(t).words);
  // The pictures of one line: their own block above its words, each opening in the viewer.
  const picRow = (urls, cls) => !urls.length ? "" : `<div class="pj-pics${urls.length === 1 ? " one" : ""}${cls || ""}">${urls.map((u) =>
    `<button type="button" class="pj-pic press" aria-label="${esc(tl("pj.pic.open"))}"><img src="${esc(u)}" alt="" loading="lazy" draggable="false"></button>`).join("")}</div>`;
  // The app's own viewer (v2.js) over the chat: every picture of this conversation, this one first.
  function picView(box, img) {
    if (typeof viewer !== "function") return;
    const all = [...box.querySelectorAll(".pj-pic img, .pj-md img")], back = img.closest("button") || document.activeElement;
    viewer(all.map((n) => ({url: n.currentSrc || n.src, name: n.alt || "", kind: "image"})), Math.max(0, all.indexOf(img)), null);
    const vw = [...document.querySelectorAll(".vw")].pop(); if (!vw) return;
    const ext = vw.querySelector(".vtop a"); if (ext) ext.style.display = "none";   // nothing here opens another window
    new MutationObserver((_, mo) => { if (vw.isConnected) return; mo.disconnect(); if (back && back.isConnected) back.focus({preventScroll: true}); }).observe(document.body, {childList: true});
  }

  // ---- sheets: changes list, background screen ----------------------------------------------------------
  async function showChanges(sid) {
    // What the session itself wrote, from its record (no git needed): each file's lines in and out,
    // opening on the edits as the record has them. Only Edit and Write calls leave such a record.
    const rec = (convs[sid] && convs[sid].work && convs[sid].work.files) || [];
    const r = await readOrAsk("/api/project/changes?id=" + enc(sid)).catch((e) => { if (!rec.length) toast(tl("pjx.chg.fail") + " " + (e.message || "")); return rec.length ? {} : null; });
    if (!r || r.declined) return;
    const files = (r.files || []).map((f) => `<div><span class="p">${esc(f.path)}</span><span class="n">${f.ins ? "+" + f.ins : ""} ${f.del ? "-" + f.del : ""}</span></div>`);
    const un = (r.untracked || []).map((f) => `<div><span class="p">${esc(f)}</span><span class="n">${tl("pjx.chg.new")}</span></div>`);
    const mine = rec.map((f, i) => `<div class="rw"><button type="button" data-df="${i}" aria-expanded="false"><span class="p">${esc(Redact.show(f.path))}</span><span class="n"><i class="da">+${f.add}</i> <i class="dd">−${f.del}</i></span></button></div>`);
    sheet(`<div class="pj-dlg"><h3>${tl("pjx.chg.rec")}</h3><div class="pj-dnone">${tl("pjx.chg.rec.d")}</div>
      <div class="pj-files pj-chgs">${mine.join("") || `<div><span class="p">${tl("pjx.chg.rec.none")}</span></div>`}</div>
      <div class="pj-lab">${tl("pjx.chg.h")}</div><div class="pj-files">${files.concat(un).join("") || `<div><span class="p">${tl("pjx.chg.none")}</span></div>`}</div></div>`, (box) => {
      box.querySelectorAll("[data-df]").forEach((b) => b.onclick = async () => {
        const row = b.parentNode, was = row.querySelector(".dv"); b.setAttribute("aria-expanded", was ? "false" : "true");
        if (was) return was.remove();
        row.insertAdjacentHTML("beforeend", `<div class="dv"><div class="pj-dnone">${tl("pj.diff.wait")}</div></div>`);
        const ds = await loopFetch("/api/sessions/diff?id=" + enc(sid) + "&path=" + enc(rec[+b.dataset.df].path)).then((d) => d.diffs || [], () => []);
        const dv = row.querySelector(".dv"); if (dv) dv.innerHTML = diffHtml(ds);
      });
    });
  }
  async function showAgentLog(bg) {
    if (!bg || !bg.id) return;
    const r = await readOrAsk("/api/project/agent-log?id=" + enc(bg.id)).catch((e) => ({error: e.message}));
    if (r.declined) return;
    sheet(`<div class="pj-dlg"><h3>${tl("pjx.bg.h")}</h3><pre class="pj-log">${esc(r.text || r.error || tl("pjx.bg.none"))}</pre></div>`, () => {});
  }

  // `held`: a line still waiting (drawn again on every paint), with the class it carries.
  const PIC_EXT = /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/i;
  function sentHtml(e) {
    const fs = (e.files || []).filter((f) => f && f.url), pics = fs.filter((f) => PIC_EXT.test(f.name)), rest = fs.filter((f) => !PIC_EXT.test(f.name));
    return picRow(pics.map((f) => f.url), " sent")
      + (rest.length ? `<div class="pj-sent">${rest.map((f) => `<a class="pj-file press" href="${esc(f.url)}" target="_blank" rel="noopener noreferrer">${ic("doc")}<span>${esc(f.name)}</span></a>`).join("")}</div>` : "")
      + (e.text ? `<div class="pj-msg claude"${e.at ? ` data-at="${esc(e.at)}"` : ""}>${marked(e.text)}</div>` : "");
  }
  function bubble(e, pending, held) {
    if (e.kind === "files") return sentHtml(e);
    if (e.kind === "sub" || e.kind === "res") return "";  // a part of another line: subs() and acts() fold it into that line
    if (e.kind === "think" || (e.kind === "tool" && e.id && !e.sub)) return actRow(e);
    if (e.sub) return `<div class="pj-sub" data-sub="${esc(e.sub.id)}"${e.at ? ` data-at="${esc(e.at)}"` : ""}><button type="button" class="pj-subh" aria-expanded="false"><span class="smk" aria-hidden="true"></span><span class="stx"></span>${ic("chev")}</button></div>`;
    const k = e.kind === "user" ? "user" : e.kind === "tool" ? "tool" : "claude";
    const tag = pending ? `<span class="tg">${esc(pending)}</span>` : e._recv ? `<span class="tg ok">${tl("pj.recv")}</span>` : "";
    const u = k === "user" ? parts(unnote(e.text)) : null, pd = held == null ? "" : "data-pend ";
    // Pictures put in from an official app with no words: the line this app writes for its own.
    if (u && !u.words && (e.imgs || []).length) u.words = tl("pj.img.look");
    // A long line of mine shows its first lines; the button under it opens the rest in place.
    const lk = u && !pending && (u.words.length > UL_CHARS || u.words.split("\n").length > UL_LINES) ? (e.at || "") + ":" + u.words.length : "";
    // e.imgs: pictures put in from an official app, read out of the record (the server's addresses).
    return (u ? picRow((e.imgs || []).concat(u.pics), pending ? " pending" : "").replace("<div ", "<div " + pd) : "")
      + `<div ${pd}class="pj-msg ${k}${pending ? " pending" : ""}${held || ""}${lk && !ulOpen.has(lk) ? " clip" : ""}"${e.at ? ` data-at="${esc(e.at)}"` : ""}>${u ? (lk ? `<span class="ut">${mineHtml(u.words)}</span><button type="button" class="um" data-ul="${esc(lk)}">${ulOpen.has(lk) ? tl("pj.act.less") : tl("pj.act.more")}</button>` : mineHtml(u.words)) : k === "claude" ? marked(e.text) : esc(Redact.show(e.text))}${k === "tool" || pending ? "" : tmHtml(e.at) + cpBtn() + (e.at ? bkBtn() : "")}${tag}</div>`;
  }
  const ulOpen = new Set(), UL_CHARS = 1200, UL_LINES = 12;
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-msg.user>.um"); if (!b) return;
    const k = b.dataset.ul, open = !ulOpen.has(k), box = b.closest(".pj-msgs"), y = b.getBoundingClientRect().top;
    if (open) ulOpen.add(k); else ulOpen.delete(k);
    b.parentNode.classList.toggle("clip", !open); b.textContent = open ? tl("pj.act.less") : tl("pj.act.more");
    if (box && !open) box.scrollTop += b.getBoundingClientRect().top - y;
  });
  // ---- quote what is selected into the reply ---------------------------------------------------------
  // Words selected in the log get one small button under them; it puts them in the box as a quote
  // ("> " lines) with the caret after, ready for the reply.
  let qBtn = null, pBtn = null;
  document.addEventListener("selectionchange", () => {
    const sel = document.getSelection(), a = sel && !sel.isCollapsed && sel.toString().trim() ? sel.anchorNode : null;
    const box = a && (a.nodeType === 1 ? a : a.parentElement).closest(".pj-msgs"), wrap = box && box.contains(sel.focusNode) && box.closest(".pj-conv .pj-wrap");
    if (!wrap) { if (qBtn) { qBtn.remove(); qBtn = null; } if (pBtn) { pBtn.remove(); pBtn = null; } return; }
    if (!qBtn || qBtn.parentNode !== wrap) {
      if (qBtn) qBtn.remove();
      wrap.insertAdjacentHTML("beforeend", `<button type="button" class="pj-quote press">${tl("pj.quote")}</button>`); qBtn = wrap.lastChild;
      if (!RM()) qBtn.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
      qBtn.onmousedown = (e) => e.preventDefault();          // the selection and the caret stay as they are
      qBtn.onclick = () => {
        const ta = wrap.closest(".pj-conv").querySelector("#pj-ta"), q = document.getSelection().toString().trim().split("\n").map((l) => "> " + l).join("\n");
        ta.value = (ta.value.trim() ? ta.value.replace(/\s*$/, "\n\n") : "") + q + "\n\n";
        document.getSelection().removeAllRanges(); ta.dispatchEvent(new Event("input", {bubbles: true})); ta.focus();
      };
    }
    const r = sel.getRangeAt(0).getBoundingClientRect(), w = wrap.getBoundingClientRect();
    // 고정 stands beside 인용 while the words are inside one line that can be kept: it keeps that
    // line, named by the words selected (a finger has no button beside the line).
    const an = a.nodeType === 1 ? a : a.parentElement, fo = sel.focusNode.nodeType === 1 ? sel.focusNode : sel.focusNode.parentElement;
    const ln = an.closest(".pj-msg"), can = ln && ln === fo.closest(".pj-msg") && ln.querySelector(":scope>.pj-bk") && box._c;
    if (!can && pBtn) { pBtn.remove(); pBtn = null; }
    if (can && (!pBtn || pBtn.parentNode !== wrap)) {
      if (pBtn) pBtn.remove();
      wrap.insertAdjacentHTML("beforeend", `<button type="button" class="pj-quote press"></button>`); pBtn = wrap.lastChild;
      if (!RM()) pBtn.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
      pBtn.onmousedown = (e) => e.preventDefault();
    }
    if (pBtn) {
      pBtn.textContent = ln.hasAttribute("data-mk") ? tl("pj.mark.off") : tl("pj.mark.on");
      pBtn.onclick = () => { const words = document.getSelection().toString().trim(); document.getSelection().removeAllRanges(); markLine(box._c, ln, words); };
    }
    const both = qBtn.offsetWidth + (pBtn ? pBtn.offsetWidth + 6 : 0), top = Math.max(4, Math.min(r.bottom - w.top + 6, w.height - qBtn.offsetHeight - 4)) + "px";
    const left = Math.max(8, Math.min(r.left - w.left, w.width - both - 8));
    qBtn.style.top = top; qBtn.style.left = left + "px";
    if (pBtn) { pBtn.style.top = top; pBtn.style.left = left + qBtn.offsetWidth + 6 + "px"; }
  });
  // ---- when each line was said ---------------------------------------------------------------------
  // The time is the transcript's own (a record without one shows nothing). Today, within the hour:
  // "방금", "3분 전"; after that the clock; another day: the clock under a line naming the day.
  const tmMs = (at) => { const t = at ? Date.parse(at) : NaN; return isFinite(t) ? t : null; };
  const tmDay = (ms) => { const d = new Date(ms); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
  const tmLoc = () => LANG() === "ko" ? "ko-KR" : "en-US";
  // Speaking into the box (web/dictate.js): the mic is drawn only where the browser can listen.
  const SPEECH = window.Dictate && Dictate.SPEECH;
  // Discard, level, mic: the three that go before send in a message box (this chat's and a new one's).
  const micHtml = () => SPEECH ? `<button class="pj-clip pj-vx press" id="pj-vx" aria-label="${tl("pj.mic.drop")}" title="${tl("pj.mic.drop")}">${ic("x")}</button><span class="pj-wave" aria-hidden="true"></span>
          <button class="pj-clip pj-mic press" id="pj-mic" aria-pressed="false" aria-label="${tl("pj.mic")}" title="${tl("pj.mic")}">${ic("mic")}${ic("stopfill")}</button>` : "";
  const micWire = (body, ta) => { const mic = body.querySelector("#pj-mic");
    if (mic) { mic.onclick = () => Dictate.listen(ta, mic, mic.closest(".pj-box"), "pj-rec"); body.querySelector("#pj-vx").onclick = Dictate.drop; } };
  function tmText(ms, now) {
    const m = Math.floor((now - ms) / 6e4);
    if (m > -2 && m < 60 && tmDay(ms) === tmDay(now)) return {rel: true, text: m < 1 ? tl("ago.2") : tl("ago.3", {p0: m})};
    return {rel: false, text: new Date(ms).toLocaleTimeString(tmLoc(), {hour: "numeric", minute: "2-digit"})};
  }
  function tmHtml(at) {
    const ms = tmMs(at); if (ms == null) return "";
    const d = new Date(ms), t = tmText(ms, Date.now());
    // aria-live off: the log announces new lines, not a time that counts up.
    return `<time class="pj-tm" datetime="${d.toISOString()}" title="${esc(d.toLocaleString(tmLoc(), {dateStyle: "full", timeStyle: "short"}))}" aria-live="off"${t.rel ? " data-rel" : ""}>${esc(t.text)}</time>`;
  }
  // ---- what a turn did, folded -------------------------------------------------------------------------
  // A run of tool lines (and thinking the record kept in words) is one quiet row that says what kinds
  // of work it was: "명령 3 · 파일 5 · 검색 2". The row opens and closes the lines where they stand;
  // which runs are open is remembered by the run's first line for as long as the page lives. With
  // "대화에 작업 과정 보기" on they start open. Painting again only corrects the row's words and which
  // lines hide, so a line arriving in a live run moves nothing else.
  const tfOpen = new Set();
  function foldText(r) {
    const n = {}; r.forEach((x) => { const c = x.dataset.cat || "tool", k = c === "read" || c === "edit" ? "file" : c; n[k] = (n[k] || 0) + 1; });
    return [n.think ? tl("pj.act.think") : "", n.run ? tl("pj.act.run", {n: n.run}) : "", n.file ? tl("pj.act.file", {n: n.file}) : "",
      n.search ? tl("pj.act.search", {n: n.search}) : "", n.web ? tl("pj.act.web", {n: n.web}) : "", n.tool ? tl("pj.act.tool", {n: n.tool}) : ""].filter(Boolean).join(" · ");
  }
  function fold(box) {
    const runs = []; let cur = null;
    for (const n of box.children) {
      if (n.classList.contains("pj-tfold")) continue;
      if (n.classList.contains("tool")) { if (!cur) runs.push(cur = []); cur.push(n); } else cur = null;
    }
    const keep = new Set();
    runs.forEach((r) => {
      let b = r[0].previousElementSibling;
      if (!(b && b.classList.contains("pj-tfold"))) { r[0].insertAdjacentHTML("beforebegin", `<button type="button" class="pj-tfold"><span></span>${ic("chev")}</button>`); b = r[0].previousElementSibling; }
      keep.add(b);
      const k = r[0].dataset.tid || r[0].dataset.at || "", open = tfOpen.has(k) !== document.body.classList.contains("steps"), txt = foldText(r);
      b.dataset.k = k; b.setAttribute("aria-expanded", open ? "true" : "false");
      if (b.firstChild.textContent !== txt) b.firstChild.textContent = txt;
      r.forEach((x) => x.classList.toggle("fd", !open));
    });
    box.querySelectorAll(":scope>.pj-tfold").forEach((b) => { if (!keep.has(b)) b.remove(); });
  }
  // The row stays where it is under the pointer: whatever the log does with its height, it does below.
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-tfold"), box = b && b.parentNode; if (!box) return;
    const y = b.getBoundingClientRect().top, k = b.dataset.k;
    if (tfOpen.has(k)) tfOpen.delete(k); else tfOpen.add(k);
    fold(box); if (box._actC) acts(box, box._actC); box.scrollTop += b.getBoundingClientRect().top - y;
  });
  // ---- one line of a run: a tool call or a thought ----------------------------------------------------
  // The line names the tool and what it was given; acts() adds what the record says came back (an
  // error, an edit's +/-). It opens in place on the whole command and the output, cut to a few
  // lines until asked for more; the server sends only the head of a long output and says how much
  // it left out. An edit opens on its diff, read once from the record by the call's id.
  const actOpen = new Set(), actFull = new Set(), actDiff = new Map(), ACT_LINES = 12;
  const thinkId = (e) => "think:" + (e.at || "") + ":" + (e.text || "").length;
  function actRow(e) {
    const think = e.kind === "think", file = e.cat === "read" || e.cat === "edit";
    const what = Redact.show(think ? e.text : file ? (e.what || "").split(/[\\/]/).slice(-2).join("/") : e.what || "").replace(/\s+/g, " ").slice(0, 200);
    return `<div class="pj-msg tool act" data-tid="${esc(think ? thinkId(e) : e.id)}" data-cat="${think ? "think" : esc(e.cat || "tool")}"${e.at ? ` data-at="${esc(e.at)}"` : ""}><button type="button" class="ah" aria-expanded="false"><b>${think ? tl("pj.act.think") : esc(e.name || "")}</b><span class="aw">${esc(what)}</span><span class="am"></span></button></div>`;
  }
  function diffHtml(ds) {
    if (!ds || !ds.length) return `<div class="pj-dnone">${tl("pj.diff.none")}</div>`;
    return ds.map((d) => `<div class="pj-diff">` + d.hunks.map((h) => `<div class="dh">@@ -${h.a} +${h.b} @@</div>`
      + h.lines.map((l) => `<div class="${l[0] === "+" ? "da" : l[0] === "-" ? "dd" : "dn"}">${esc(Redact.show(l)) || " "}</div>`).join("")).join("")
      + (d.cut ? `<div class="dh">${tl("pj.diff.cut")}</div>` : "") + `</div>`).join("");
  }
  function actBody(e, r, full, diff) {
    if (e.kind === "think") return `<div class="at">${plainLinks(Redact.show(e.text))}</div>`;
    const lines = r ? Redact.show(r.text).split("\n") : [], long = lines.length > ACT_LINES;
    return (e.what ? `<pre class="ac">${esc(Redact.show(e.what))}</pre>` : "")
      + (!r ? `<div class="an">${tl("pj.act.wait")}</div>`
        : r.add != null ? (diff ? diffHtml(diff) : `<div class="an">${tl("pj.diff.wait")}</div>`)
        : !r.text ? `<div class="an">${tl("pj.act.empty")}</div>`
        : `<pre class="ar${r.err ? " bad" : ""}">${esc((full ? lines : lines.slice(0, ACT_LINES)).join("\n"))}</pre>`
          + (long || r.more ? `<div class="an">${full && r.more ? `<span>${tl("pj.act.cut", {n: r.more.toLocaleString()})}</span>` : ""}`
            + `<button type="button" data-actmore>${full ? tl("pj.act.less") : tl("pj.act.more")}</button></div>` : ""));
  }
  function acts(box, c) {
    box._actC = c;
    const rows = box.querySelectorAll(":scope>.pj-msg.act"); if (!rows.length) return;
    const res = new Map(), src = new Map();
    c.entries.forEach((e) => { if (e.kind === "res") res.set(e.id, e); else if (e.kind === "think") src.set(thinkId(e), e); else if (e.kind === "tool" && e.id) src.set(e.id, e); });
    rows.forEach((n) => {
      const id = n.dataset.tid, r = res.get(id), head = n.firstChild, mk = head.lastChild, open = actOpen.has(id) && !n.classList.contains("fd");
      const m = !r ? "" : (r.err ? `<i class="bad">${tl("pj.act.err")}</i>` : "") + (r.add != null ? `<i class="da">+${r.add}</i><i class="dd">−${r.del}</i>` : "");
      if (mk._h !== m) { mk._h = m; mk.innerHTML = m; }
      head.setAttribute("aria-expanded", open ? "true" : "false");
      let b = n.querySelector(":scope>.ab");
      if (!open) { if (b) b.remove(); return; }
      const full = actFull.has(id), diff = actDiff.get(id), key = [r && r.text, full, !!diff, Redact.on()].join("\n");
      if (!b) { n.insertAdjacentHTML("beforeend", `<div class="ab"></div>`); b = n.lastChild; if (!RM()) b.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
      if (b._k !== key) { b._k = key; b.innerHTML = actBody(src.get(id) || {}, r, full, diff); }
      if (r && r.add != null && !actDiff.has(id) && c.sid) {
        actDiff.set(id, null);
        loopFetch("/api/sessions/diff?id=" + enc(c.sid) + "&call=" + enc(id)).then((d) => d.diffs || [], () => []).then((ds) => { actDiff.set(id, ds); if (box.isConnected) acts(box, box._actC); });
      }
    });
  }
  document.addEventListener("click", (e) => {
    const t = e.target.closest && e.target.closest(".pj-msg.act>.ah,[data-actmore]"), box = t && t.closest(".pj-msgs"); if (!box || !box._actC) return;
    const set = t.matches(".ah") ? actOpen : actFull, k = t.closest(".pj-msg.act").dataset.tid, y = t.getBoundingClientRect().top;
    if (set.has(k)) set.delete(k); else set.add(k);
    acts(box, box._actC); if (t.isConnected) box.scrollTop += t.getBoundingClientRect().top - y;
  });
  // ---- the session's task list ---------------------------------------------------------------------
  // The record's own list (TodoWrite, or the task tools), shown while something on it is still to
  // do: "2/5" and the item in hand, opening on every item with its state. Whether it is open is
  // the page's to remember, per session.
  const todoOpen = new Set();
  function todoStrip(body, c) {
    const el = body.querySelector("#pj-todo"); if (!el) return;
    const ts = (c.work && c.work.todos) || [], done = ts.filter((t) => t.state === "completed").length;
    el.hidden = !ts.length || done === ts.length; if (el.hidden) return;
    const now = ts.find((t) => t.state === "in_progress") || ts.find((t) => t.state !== "completed"), open = todoOpen.has(c.sid);
    const h = `<button type="button" aria-expanded="${open}"><b>${tl("pj.todo.n", {done, all: ts.length})}</b><span>${esc(Redact.show(now.text))}</span>${ic("chev")}</button>`
      + (open ? `<ul>${ts.map((t) => `<li class="${esc(t.state)}">${esc(Redact.show(t.text))}</li>`).join("")}</ul>` : "");
    if (el._h !== h) { el._h = h; el.innerHTML = h; }
    el.onclick = (e) => { if (!e.target.closest("button")) return; if (open) todoOpen.delete(c.sid); else todoOpen.add(c.sid); todoStrip(body, c); };
  }
  // ---- a subagent's run, one line -----------------------------------------------------------------
  // The call is the row (a tool line that carries `sub`, see session_view). What the record says
  // about the run later (the "sub" entries: started, ended, its report) is folded into that row
  // by the call's id, or by the agent's id where a line names only that. The row opens in place
  // on the brief and the report. Several runs in one turn get a line that adds them up and can
  // put the finished ones away. What is open or put away is remembered while the page lives.
  const subOpen = new Set(), subHid = new Set();
  const SUB_END = {completed: () => tl("pj.sub.done"), failed: () => tl("pj.sub.failed"), killed: () => tl("pj.sub.stopped"), stopped: () => tl("pj.sub.stopped")};
  // "claude-haiku-4-5-20251001" -> "Haiku 4.5": the family and its version as the id has them.
  const subModel = (id) => { const m = /^(?:claude-)?([a-z]+)((?:-\d{1,2}(?!\d))*)/.exec(id || "");
    return m ? m[1][0].toUpperCase() + m[1].slice(1) + (m[2] ? " " + m[2].slice(1).replace(/-/g, ".") : "") : id || ""; };
  const subDur = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? tl("pj.now.sec", {n: s}) : tl("pj.now.min", {m: Math.floor(s / 60), n: s % 60}); };
  function subRuns(c) {
    const by = new Map(), call = new Map();
    c.entries.forEach((e) => { if (e.sub) by.set(e.sub.id, Object.assign({at: e.at}, e.sub)); else if (e.kind === "sub" && e.id && e.aid) call.set(e.aid, e.id); });
    c.entries.forEach((e) => {
      const r = e.kind === "sub" && by.get(e.id || call.get(e.aid)); if (!r) return;
      ["model", "state", "end", "tokens", "uses", "ms", "report"].forEach((k) => { if (e[k] != null && e[k] !== "") r[k] = e[k]; });
    });
    return by;
  }
  function subs(box, c) {
    box._subC = c;
    const groups = []; let g = null;
    for (const n of box.children) {
      if (n.classList.contains("pj-sub")) { if (!g) groups.push(g = []); g.push(n); }
      else if (n.matches(".pj-msg.user:not([data-pend])")) g = null;
    }
    const keep = new Set();
    if (groups.length) {
      const runs = subRuns(c), off = ((c.state && c.state.state) || "ended") === "ended", now = Date.now();
      groups.forEach((rows) => {
        const vs = rows.map((n) => {
          // Ended: the record said how, or its report is here; a run of a session that is off is not running either.
          const r = runs.get(n.dataset.sub) || {}, st = r.state || (r.report ? "completed" : off ? "stopped" : ""), t0 = tmMs(r.at), t1 = tmMs(r.end);
          const ms = r.ms != null ? r.ms : t0 == null ? null : !st ? now - t0 : t1 != null ? t1 - t0 : null;
          const head = n.firstChild, mk = head.firstChild, tx = mk.nextSibling, id = n.dataset.sub, open = subOpen.has(id);
          const bits = st ? [r.uses != null ? tl("pj.sub.uses", {n: r.uses}) : "", r.tokens != null ? tl("pj.sub.tok", {n: ctxTok(r.tokens)}) : "", subModel(r.model), ms != null ? subDur(ms) : ""]
            : [ms != null ? subDur(ms) : "", subModel(r.model)];
          const html = `<b>${esc(r.name || tl("pj.sub.agent"))}</b>${r.desc ? ` <span class="sds">${esc(Redact.show(r.desc))}</span>` : ""} <span class="sdt">· <span class="sst">${esc(st ? (SUB_END[st] || SUB_END.completed)() : tl("pj.sub.run"))}</span>${esc(bits.filter(Boolean).map((b) => " · " + b).join(""))}</span>`;
          if (tx._h !== html) { tx._h = html; tx.innerHTML = html; }
          const k = st === "failed" ? "bad" : st === "completed" ? "ok" : st ? "off" : "run";
          if (n.dataset.st !== k) { n.dataset.st = k; mk.innerHTML = k === "run" ? `<span class="pj-spin"></span>` : ic(k === "bad" ? "warn" : k === "ok" ? "check" : "x"); }
          head.setAttribute("aria-expanded", open ? "true" : "false");
          let b = n.querySelector(":scope>.pj-subb");
          if (!open) { if (b) b.remove(); }
          else {
            const key = [r.brief, r.report, Redact.on()].join("\n");
            if (!b) { n.insertAdjacentHTML("beforeend", `<div class="pj-subb"></div>`); b = n.lastChild; if (!RM()) b.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
            if (b._k !== key) { b._k = key; b.innerHTML = `<h5>${tl("pj.sub.brief")}</h5><div class="bf">${plainLinks(Redact.show(r.brief))}</div><h5>${tl("pj.sub.report")}</h5><div class="rp">${r.report ? marked(r.report) : `<span class="no">${st ? tl("pj.sub.none") : tl("pj.sub.wait")}</span>`}</div>`; }
          }
          return {n, r, st, t0, t1, open};
        });
        const done = vs.filter((v) => v.st), k = rows[0].dataset.sub, hid = subHid.has(k);
        vs.forEach((v) => v.n.classList.toggle("fd", rows.length > 1 && hid && !!v.st && !v.open));
        if (rows.length < 2) return;
        let b = rows[0].previousElementSibling;
        if (!(b && b.classList.contains("pj-subsum"))) { rows[0].insertAdjacentHTML("beforebegin", `<div class="pj-subsum"><span></span><button type="button"></button></div>`); b = rows[0].previousElementSibling; }
        keep.add(b); b.dataset.k = k;
        // The time on the wall is from the first start to the last end, said once all have ended;
        // against the sum of what each took it says how much ran side by side.
        const all = done.length === rows.length && vs.every((v) => v.t0 != null && v.t1 != null);
        const wall = all ? Math.max(...vs.map((v) => v.t1)) - Math.min(...vs.map((v) => v.t0)) : 0;
        const sum = (f) => done.reduce((a, v) => a + (v.r[f] || 0), 0), work = sum("ms"), uses = sum("uses"), toks = sum("tokens");
        const txt = [tl("pj.sub.sum.n", {n: rows.length}), wall ? subDur(wall) : done.length < rows.length ? tl("pj.sub.sum.left", {n: rows.length - done.length}) : "",
          work ? tl("pj.sub.sum.time", {t: subDur(work)}) + (wall && work / wall >= 1.15 ? " (" + tl("pj.sub.sum.par", {x: (work / wall).toFixed(1)}) + ")" : "") : "",
          uses ? tl("pj.sub.uses", {n: uses}) : "", toks ? tl("pj.sub.tok", {n: ctxTok(toks)}) : ""].filter(Boolean).join(" · ");
        if (b.firstChild.textContent !== txt) b.firstChild.textContent = txt;
        const say = done.length ? (hid ? tl("pj.sub.show", {n: done.length}) : tl("pj.sub.hide", {n: done.length})) : "";
        b.lastChild.hidden = !say; b.lastChild.setAttribute("aria-pressed", hid ? "true" : "false");
        if (b.lastChild.textContent !== say) b.lastChild.textContent = say;
      });
    }
    box.querySelectorAll(":scope>.pj-subsum").forEach((b) => { if (!keep.has(b)) b.remove(); });
  }
  document.addEventListener("click", (e) => {
    const t = e.target.closest && e.target.closest(".pj-subh,.pj-subsum>button"), box = t && t.closest(".pj-msgs"); if (!box || !box._subC) return;
    const row = t.matches(".pj-subh"), set = row ? subOpen : subHid, k = row ? t.parentNode.dataset.sub : t.parentNode.dataset.k, y = t.getBoundingClientRect().top;
    if (set.has(k)) set.delete(k); else set.add(k);
    subs(box, box._subC); box.scrollTop += t.getBoundingClientRect().top - y;
  });
  // After a paint: one time per run (same side, same minute - on its last line) and a line where
  // the day changes. Only what is missing is added, so painting again changes nothing.
  function stamp(box) {
    const today = tmDay(Date.now());
    let day = "", prev = null;
    box.querySelectorAll(":scope>.pj-msg[data-at]").forEach((n) => {
      const ms = tmMs(n.dataset.at); if (ms == null) return;
      const k = tmDay(ms);
      if (k !== day && (day || k !== today)) {
        let a = n; while (a.previousElementSibling && a.previousElementSibling.matches(".pj-unread,.pj-tfold,.pj-pics,[data-pend]")) a = a.previousElementSibling;
        if (!(a.previousElementSibling && a.previousElementSibling.classList.contains("pj-day"))) {
          const d = new Date(ms), o = {month: "long", day: "numeric", weekday: "long"};
          if (d.getFullYear() !== new Date().getFullYear()) o.year = "numeric";
          a.insertAdjacentHTML("beforebegin", `<div class="pj-day" role="separator">${esc(d.toLocaleDateString(tmLoc(), o))}</div>`);
        }
      }
      day = k;
      const t = n.querySelector(":scope>.pj-tm"); if (!t) return;
      const side = n.classList.contains("user"), min = Math.floor(ms / 6e4);
      if (prev && prev.side === side && prev.min === min && prev.day === k) prev.t.hidden = true;
      t.hidden = false; prev = {t, side, min, day: k};
    });
    tmStart();
  }
  // One timer for every chat on the page: it rewrites the words of the times still counting
  // ("3분 전" -> "4분 전"), nothing else, and rests while the page is hidden.
  let tmTimer = 0;
  function tmTick() {
    const now = Date.now(), rel = document.querySelectorAll("time.pj-tm[data-rel]");
    rel.forEach((n) => { const t = tmText(Date.parse(n.dateTime), now);
      if (!t.rel) n.removeAttribute("data-rel");
      if (n.textContent !== t.text) n.textContent = t.text; });
    if (!rel.length) tmStop();
  }
  const tmStop = () => { clearInterval(tmTimer); tmTimer = 0; };
  const tmStart = () => { if (!tmTimer && !document.hidden && document.querySelector("time.pj-tm[data-rel]")) tmTimer = setInterval(tmTick, 30000); };
  document.addEventListener("visibilitychange", () => { if (document.hidden) tmStop(); else { tmTick(); tmStart(); } });
  // What the session wrote, with its bold, inline code and lists read as such. markdown.js builds
  // nodes (never innerHTML), so the text stays escaped; a plain line stays a plain line.
  // The copy button of a line (and of a code block: data-copy="code").
  const cpBtn = (what) => `<button type="button" class="pj-cp press" data-copy="${what || "line"}" aria-label="${esc(tl("pj.copy"))}" title="${esc(tl("pj.copy"))}">${ic("copy")}</button>`;
  // The mark of a line kept; markRows() says which way it goes.
  const bkBtn = () => `<button type="button" class="pj-bk press" aria-pressed="false">${ic("tack")}</button>`;
  // A code block sits in a frame of its own: a head (its language, else "코드") with the copy button.
  const marked = (t) => {
    t = Redact.show(t);
    if (!(typeof looksMarkdown === "function" && looksMarkdown(t))) return plainLinks(t);
    const n = renderMarkdown(String(t).trim(), "md pj-md");
    n.querySelectorAll("pre").forEach((pre) => { const w = document.createElement("div"); w.className = "pj-prew"; w.dataset.l = ((pre.querySelector("code") || pre).className.match(/language-([\w+#.-]+)/) || [])[1] || tl("pj.code"); pre.replaceWith(w); w.appendChild(pre); w.insertAdjacentHTML("beforeend", cpBtn("code")); });
    return n.outerHTML;
  };
  // chat-selection:begin
  function selectedText(root) {
    const sel = window.getSelection();
    return root && sel && !sel.isCollapsed && root.contains(sel.anchorNode) && root.contains(sel.focusNode) ? sel.toString() : "";
  }
  // chat-selection:end
  // Plain messages retain their whitespace and markup characters, with only web addresses linked.
  const plainLinks = (t) => {
    const text = String(t || ""), re = /https?:\/\/[^\s<>"'`]*[^\s<>"'`.,;:!?)\]]/g;
    let out = "", at = 0, m;
    while ((m = re.exec(text))) {
      out += esc(text.slice(at, m.index)) + `<a href="${esc(m[0])}" target="_blank" rel="noopener noreferrer">${esc(m[0])}</a>`;
      at = re.lastIndex;
    }
    return out + esc(text.slice(at));
  };
  // Why a line did not go, on the line itself: the reason when one is known, else the plain words.
  const failWhy = (why) => why && why !== "cancelled" ? String(why) : tl("room.failed");
  // A line of mine that is not in the transcript yet: on its way, sent, or not delivered.
  function pendRow(p, i) {
    const u = parts(p.text), mine = (p.imgs || []).filter((im) => im.url).map((im) => im.url);
    const tag = p.failed
      ? `<span class="tg bad" role="alert">${ic("warn")}<span>${esc(failWhy(p.failed))}</span><button class="press" data-resend="${i}">${esc(p.uncertain ? tl("pj.delivery.retry") : tl("room.retry"))}</button><button class="press" data-unsend="${i}">${esc(tl("room.drop"))}</button></span>`
      : `<span class="tg">${p.busy ? `<span class="pj-spin" aria-hidden="true"></span>` : ""}${esc(p.tag || "")}</span>`;
    return picRow(mine.concat(u.pics), p.busy ? " pending" : "").replace("<div ", "<div data-pend ")
      + `<div data-pend class="pj-msg user${p.busy ? " pending" : ""}${p.failed ? " failed" : ""}">${plainLinks(Redact.show(u.words) || (mine.length ? tl("pj.img.look") : ""))}${tag}</div>`;
  }
  // ---- what is happening to the line just sent ---------------------------------------------------
  // One line under the newest: on its way, held, or what the session is on right now (the step
  // its own record names, see sessions_ctl.step_of) with how long the turn has taken. Only what
  // is known is said. The answer arrives above it, in its place.
  const NOW_FAST = 30000, STEPS = {think: () => tl("pj.now.think"), run: () => tl("pj.now.run"), read: () => tl("pj.now.read"), edit: () => tl("pj.now.edit"),
    search: () => tl("pj.now.search"), web: () => tl("pj.now.web"), agent: () => tl("pj.now.agent"), write: () => tl("pj.now.write"),
    tool: (s) => s.name ? tl("pj.now.tool", {name: s.name}) : tl("pj.now.tool0")};
  function nowOf(c) {
    const st = c.state || {}, live = st.state === "live", p = [...c.pend].reverse().find((x) => !x.failed);
    if (p && p.busy && !live) return {text: tl("pj.now.sending"), at: p.at};
    if (c.fail && !live) return {text: c.fail, still: true, bad: true};      // the last line failed after it was taken
    if (live) {
      const s = st.step, say = s && Object.prototype.hasOwnProperty.call(STEPS, s.kind) ? STEPS[s.kind] : null;
      return {text: say ? say(s) : tl("pj.st.live"), what: (s && s.what) || "", at: c.turnAt};
    }
    // The session is holding the line for review: one press lets it take such lines at once.
    if ((p && p.route === "held") || c.queued.some((q) => q.held)) return st.peer_accept ? {text: tl("pj.now.heldOn"), still: true} : {text: tl("pj.now.heldBy"), still: true, accept: true};
    if (p && p.route === "hook") return {text: tl("pj.now.held"), still: true};
    if (p && p.route === "wake") return {text: tl("pj.now.wake"), at: p.at};
    // Once the session was seen working on it and rests again, the answer is on its way to the page.
    if ((p && (p.route === "live" || p.route === "native")) || (c.waiting && st.state !== "ended" && !c.sawLive)) return {text: tl("pj.now.sent"), at: c.turnAt || (p && p.at)};
    return null;
  }
  function nowSec(el) {
    const s = el._at ? Math.floor((Date.now() - el._at) / 1000) : 0;
    const t = s < 1 ? "" : " · " + (s < 60 ? tl("pj.now.sec", {n: s}) : tl("pj.now.min", {m: Math.floor(s / 60), n: s % 60}));
    // A room's first answer waits for the session to start; say so once the wait is noticeable.
    const hint = el._first && s >= 5 ? " · " + tl("pj.now.first") : "";
    if (el.lastChild.textContent !== t + hint) el.lastChild.textContent = t + hint;
  }
  function nowLine(box, c) {
    const n = nowOf(c);
    let el = box.querySelector(":scope>.pj-now");
    if (!n) { if (!c.pend.length && !c.waiting) c.turnAt = 0; if (el) el.classList.remove("on"); return; }
    if (!el) { box.insertAdjacentHTML("beforeend", `<div class="pj-now" role="status" aria-live="off"><span class="mk keys" aria-hidden="true"></span><span class="tx"></span><span class="nsec" aria-hidden="true"></span></div>`); el = box.lastElementChild; }
    const mk = el.firstChild, tx = mk.nextSibling, k = n.bad ? "b" : n.still ? "s" : "m";
    el.classList.toggle("bad", !!n.bad);
    // The app's own activity mark (orb.js): it moves only while something is really on its way.
    if (mk.dataset.k !== k) { mk.dataset.k = k; mk.innerHTML = n.bad ? ic("warn") : n.still ? `<rl-orb state="breathing" size="20" px="14" paused aria-label=""></rl-orb>`
      : `<i class="st-dot"></i>`; }
    const html = esc(n.text) + (n.what ? `<span> · ${esc(Redact.show(n.what))}</span>` : "") + (n.accept ? ` <button type="button" class="btn sm press" data-peeraccept>${tl("pj.now.accept")}</button>` : "");
    if (tx._h !== html) {
      const was = tx._h; tx._h = html; tx.innerHTML = html;
      if (was && el.classList.contains("on") && tx.animate) tx.animate([{opacity: .3}, {opacity: 1}], {duration: 180, easing: "ease-out"});
    }
    const acc = tx.querySelector("[data-peeraccept]");
    if (acc && !acc.onclick) acc.onclick = async () => {
      acc.disabled = true;
      try {
        const r = await loopFetch("/api/peer/accept", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({place: (c.state || {}).project || ""})});
        const j = await r.json().catch(() => ({}));
        if (j.need_consent) return;               // the person said "not now"
        toast(j.result === "written" ? tl("pj.now.acceptDone") : tl("pj.now.acceptFail"));
        if (j.result === "written") c.pend.forEach((p) => { if (p.route === "held") p.route = "live"; });
        if (c.kick) c.kick();
      } catch (e) { toast(e.message); }
      finally { if (acc.isConnected) acc.disabled = false; }
    };
    el._at = n.at || 0; el._first = !n.bad && (n.text === tl("pj.now.wake") || !c.entries.some((e) => e.kind !== "user"));
    el.classList.add("on"); nowSec(el);
  }
  // Paint the conversation from cache. `all` repaints; otherwise only the tail after `from` is added.
  // Scroll rules: a repaint lands where the person left off (or on the newest); new lines follow
  // the end only while they are at the end, otherwise the way-down button carries their count.
  // Tail/state updates wait while text is selected, then catch up from the earliest queued offset.
  document.addEventListener("selectionchange", () => {
    document.querySelectorAll("#pj-msgs").forEach((box) => {
      const p = box._selectionPaint;
      if (!p || selectedText(box)) return;
      delete box._selectionPaint;
      if (p.body.isConnected) paint(p.body, p.c, p.all, p.from);
    });
  });
  // 가림 모드 changed (here, in settings or in another window): every chat on the page is drawn
  // again from what it holds, and the line over its box says the mode is on.
  document.addEventListener("redact", () => Object.values(convs).forEach((c) => {
    if (!c.body || !c.body.isConnected) return;
    const rd = c.body.querySelector("#pj-rd"); if (rd) rd.hidden = !Redact.on();
    paint(c.body, c, true);
  }));
  document.addEventListener("redact", () => { if (location.hash.startsWith("#project")) render(); });   // the lists beside the chats
  document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("[data-unmask]")) Redact.set(false); });
  function paint(body, c, all, from) {
    const box = body.querySelector("#pj-msgs"), st = body.querySelector("#pj-state"), nt = body.querySelector("#pj-note");
    if (st) { const h = state(c); if (h !== c.stateHtml) { c.stateHtml = h; st.innerHTML = h; } }
    // Written only when it changed: a press on a button in it (허용 / 거부, 새 세션 열기) must not
    // find the button swapped for a new one between the finger going down and coming up.
    if (nt) { const h = note(c); if (h !== c.noteHtml) { c.noteHtml = h; nt.innerHTML = h; } }
    const fb = body.querySelector("#pj-feedback"), records = c.state?.feedback || [];
    if (fb) { fb.hidden = !records.length; fb.querySelector("summary").textContent = tl("pj.feedback.history", {n: records.length});
      const html = records.map((r) => `<div class="pj-feedback-row"><button class="press" data-go="item/${enc(r.project)}/${enc(r.item)}">${esc(r.item)} · ${esc(r.v || "")}</button><p>${esc(r.text)}</p><small>${r.fixed_in ? tl("itemView.7", {esc: esc(r.fixed_in)}) : r.ack ? tl("itemView.122") : r.delivered ? tl("itemView.123") : tl("itemView.125")} · <time data-note-at="${esc(r.at || "")}">${ago(r.at)}</time></small></div>`).join("");
      if (fb.dataset.records !== JSON.stringify(records)) { fb.dataset.records = JSON.stringify(records); fb.querySelector("div").innerHTML = html; }
    }
    const ta = body.querySelector("#pj-ta");
    if (ta) ta.placeholder = body.dataset.ph || (((c.state && c.state.state) === "ended") ? tl("pj.phEnded") : tl("pj.ph"));
    if (!box) return;
    if (selectedText(box)) {
      const p = box._selectionPaint;
      box._selectionPaint = {body, c, all: all || !!(p && p.all), from: p ? Math.min(p.from ?? c.entries.length, from ?? c.entries.length) : from};
      return;
    }
    const deferred = box._selectionPaint;
    if (deferred) {
      all = all || deferred.all;
      from = Math.min(deferred.from ?? c.entries.length, from ?? c.entries.length);
      delete box._selectionPaint;
    }
    const stick = !all && c.stick;
    if (all) {
      box.innerHTML = "";
      if (!c.loaded) box.innerHTML = `<div class="pj-empty pj-wait">${loadingHtml(tl("pj.loading"))}</div>`;
      else if (!c.entries.length && !c.pend.length && !c.queued.length) box.innerHTML = `<div class="pj-empty">${tl("pj.empty")}</div>`;
    }
    const empty = box.querySelector(".pj-empty");
    let added = 0;
    const now = box.querySelector(":scope>.pj-now"), put = (html) => now ? now.insertAdjacentHTML("beforebegin", html) : box.insertAdjacentHTML("beforeend", html);
    const add = (html) => { if (empty && empty.parentNode) empty.remove(); put(html); added++; };
    const fresh = all ? c.entries : c.entries.slice(from);
    let placed = !!box.querySelector(".pj-unread");
    fresh.forEach((e) => {
      if (e.kind === "sub" || e.kind === "res") return;    // no line of its own (see subs, acts)
      if (!placed && c.divTs && e.kind === "claude" && e.at === c.divTs) { add(`<div class="pj-unread">${tl("pj.unread")}</div>`); placed = true; }
      add(bubble(e));
      if (e._recv) { const t = setTimeout(() => { e._recv = false; box.querySelectorAll(".tg.ok").forEach((n) => n.remove()); }, 3500); timers.add(t); }
    });
    // pending: lines we sent that are not in the transcript yet, then lines held for the hook.
    // Each stands where it was said: above whatever the session wrote after it, not under it.
    // Drawn again only when something about them changed: the state loop paints every second or
    // three, and a line put back each time restarted its spinner and counted as new to a reader.
    const wrote = [...box.querySelectorAll(".pj-msg.claude[data-at], .pj-msg.tool[data-at]")], ats = wrote.map((n) => n.dataset.at);
    const rows = c.pend.map((p, i) => [pendSlot(ats, p.at), pendRow(p, i), p.at || 0]);
    const held = c.queued.filter((q) => !c.pend.some((p) => sameLine(p.text, q.text))).map((q) =>
      [pendSlot(ats, Date.parse(q.at)), bubble({kind: "user", text: q.text, at: q.at},
        q.fail ? tl("room.failed") + " · " + srvMsg(q.fail) : tl("pj.queued"), q.fail ? " failed" : ""), Date.parse(q.at) || 0]);
    const pkey = JSON.stringify([rows, held]), had = box.querySelectorAll("[data-pend]");
    if (added || pkey !== box._pendKey || had.length !== box._pendN) {
      had.forEach((n) => n.remove());
      // Server-held lines keep their send time too; they must not cover every newer answer.
      rows.concat(held).sort((a, b) => a[2] - b[2]).forEach(([k, html]) => { const before = k < 0 ? null : wrote[k];
        const at = before && before.previousElementSibling && before.previousElementSibling.classList.contains("pj-unread") ? before.previousElementSibling : before;
        if (at) at.insertAdjacentHTML("beforebegin", html); else put(html); });
      box._pendKey = pkey; box._pendN = box.querySelectorAll("[data-pend]").length;
      writeOut(c.out, c.pend);
    }
    nowLine(box, c);
    olderRow(box, c); fold(box); acts(box, c); subs(box, c); resRows(box, c); stamp(box); recap(box, c); markRows(box, c); todoStrip(body, c);
    if (added && box._find) box._find();                 // the find bar counts lines that came in while it is open
    if (box._ro) for (const n of box.children) if (!n._ro) { n._ro = 1; box._ro.observe(n, {box: "border-box"}); }
    if (all) {
      const p = c.pos, back = p && !p.stick && c.loaded;
      if (back) seat(box, p);                                          // back where they were reading
      else box.scrollTop = box.scrollHeight;                           // the newest; the "새 글" line stays in the log above it
      c.stick = nearEnd(box);
      if (c.loaded) hold(box, c, back ? p : spot(box, c.stick));
    } else if (stick) {
      box.scrollTop = box.scrollHeight;
      if (c.hold) c.hold = {stick: true};
    } else if (added && fresh.length) {
      c.unseen += fresh.length;
    }
    endBtn(box, c);
  }

  // Sending never waits on the server: the line is in the chat and the box is empty the moment it
  // is sent, and the box takes the next line straight away. The server is asked after that, one
  // line at a time per conversation so they arrive in the order they were typed.
  function sendLine(body, s, name, root) {
    const ta = body.querySelector("#pj-ta"), c = C(s.id);
    const said = ta.value.trim(); if (!said && !c.imgs.length) return;
    const p = {text: said, said, imgs: c.imgs.slice(), tag: tl("room.sending"), busy: true, at: Date.now()};
    c.pend.push(p); ta.value = ""; c.draft = ""; writeDraft(s.id, ""); c.imgs = []; chips(body, c);
    if (!c.turnAt) c.turnAt = p.at;
    c.fastUntil = p.at + NOW_FAST; c.sawLive = false; if (c.kick) c.kick();
    c.stick = true; tipOff(); const tp = body.querySelector("#pj-tip"); if (tp) tp.hidden = true;
    paint(body, c, false, c.entries.length); ta.focus({preventScroll: true});
    if (c.sync) c.sync();                                   // the box is one line again at once
    queue(s, c, p);
  }
  // State facts the server only sends while they hold (sessions_ctl): dropped when an answer leaves them out.
  const GONE = ["ask", "cut", "stuck", "stuck_hint", "fail"];
  // The server says these Codex lines in Korean only; known ones are shown in the page's language.
  const SRV_ASK_GONE = "이미 처리된 요청이에요.";
  const SRV = {"Codex 앱이나 터미널에서 이 대화가 열려 있어요. 거기서 닫고 1분쯤 뒤 다시 보내 주세요.": () => tl("room.srv.elsewhere"),
    "Codex가 허락을 기다리고 있어요. 먼저 [허용]이나 [거절]을 눌러 주세요.": () => tl("room.srv.askFirst"),
    [SRV_ASK_GONE]: () => tl("room.srv.askGone"), "허용했어요. Codex가 이어서 해요.": () => tl("room.srv.allowed"),
    "거절했어요. Codex가 그 일은 하지 않고 이어서 답해요.": () => tl("room.srv.denied")};
  const srvMsg = (t) => t && SRV[t] ? SRV[t]() : srvT(t);
  // A line on its way is an answer: the row is not my-turn from here on (ansMark).
  const queue = (s, c, p) => { ansMark(s.id, true); c.chain =(c.chain || Promise.resolve()).then(() => deliver(s, c, p)); };
  async function deliver(s, c, p) {
    // The page may have been drawn again while this waited: paint whichever chat is up now.
    const show = () => { if (c.body && c.body.isConnected) { paint(c.body, c, false, c.entries.length); if (c.sync) c.sync(); } };
    if (!c.pend.includes(p)) return;                       // taken away while it waited its turn
    p.busy = true; p.failed = ""; p.uncertain = false; p.route = ""; p.tag = tl("room.sending"); c.sending = (c.sending || 0) + 1; show();
    try {
      if (p.imgs.length) {
        const paths = await uploadImgs(p.imgs, s.id);
        p.imgs.forEach((im) => URL.revokeObjectURL(im.url)); p.imgs = [];
        p.text = (p.said || (paths.some((x) => PIC_EXT.test(x)) ? tl("pj.img.look") : tl("pj.file.look"))) + paths.map((x) => "\n" + CLIP + x).join("");
      }
      const r = await act("/api/session/tell", {sid: s.id, text: p.text});
      // "보냄" = it reached the session's inbox; the line turns into a normal bubble marked 받음 the
      // moment the session writes it into its transcript.
      p.tag = r.routed === "native" ? tl("pj.native.accepted") : r.routed === "live" ? tl("room.sent") : (r.message || tl("pj.relayed"));
      p.route = r.routed;
      if (r.routed === "live" || r.routed === "native") p.sentAt = Date.now();
      if (s.agent !== "codex" && r.routed !== "hook") c.waiting = true;   // held for the hook = not on its way, no spinner
      if (r.routed !== "live" && r.routed !== "native") toast(r.message || tl("pj.relayed"));
      if (c.kick) c.kick();
    } catch (e) {
      // Nothing typed is lost: the line stays in the chat, marked, with 다시 보내기 on it.
      // Said once: on the line itself while its chat is on screen, as a toast only when it is not.
      p.uncertain = e.code === "delivery_unconfirmed";
      if (!p.uncertain) ansMark(s.id, false);              // it never left: still the person's turn
      p.failed = srvMsg(e.message) || tl("room.failed");
      if (e.message !== "cancelled" && !(c.body && c.body.isConnected)) toast(srvMsg(e.message));
      if (p.uncertain) p.failed = tl("pj.delivery.unknown");
    } finally { p.busy = false; c.sending = Math.max(0, (c.sending || 1) - 1); show(); }
  }

  // ---- live tail -------------------------------------------------------------------------------
  // Two loops per open chat. The transcript loop holds a request open on the server (up to 20s)
  // that answers the moment the file gains a complete line, so a reply lands in well under a
  // second and an idle chat costs one request per 20s. The state loop refreshes the session's
  // facts (working / waiting / queued lines) every 3s, and right after the transcript moves.
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function start(body, s, name, my) {
    const c = C(s.id), ac = new AbortController(), run = {body, ac};
    endLoop(body); body._pjRun = run; runs.add(run);
    const alive = () => body._pjRun === run && body.isConnected && !ac.signal.aborted && (my && my.embed ? true : location.hash.startsWith("#project"));
    // The server leaves a fact out once it no longer holds (a Codex request answered, a cut answer
    // taken up again, a login fixed): it must leave this chat too, not linger from an older answer.
    const merge = (st) => { c.state = Object.assign({}, c.state, st); GONE.forEach((k) => { if (!(k in st)) delete c.state[k]; }); c.queued = st.queued || [];
      // A line the app was carrying in that did not make it: the row says so, with 다시 보내기.
      c.queued.forEach((q) => { if (!q.fail) return; const p = c.pend.find((x) => x.text === q.text && !x.failed && !c.sending); if (p) { p.failed = srvMsg(q.fail); p.busy = false; c.waiting = false; } });
      // A line written to the session's inbox that never turned up in its record: it waits for the
      // session's next turn, so the line under the chat says that instead of "sent".
      c.queued.forEach((q) => { if (!q.stuck) return; const p = c.pend.find((x) => x.text === q.text && !x.failed && x.route === "live"); if (p) p.route = q.held ? "held" : "hook"; });
      // Codex is not working and its record never took the line: it did not arrive.
      if (s.agent === "codex") c.pend.forEach((p) => { if (lostLine(p, st, Date.now())) {
        p.uncertain = p.route === "native";
        p.failed = p.uncertain ? tl("pj.delivery.unknown") : tl("room.codexLost");
      } });
      // Codex took the line and the turn failed at once: said on the line (다시 보내기) and under the chat.
      c.fail = srvMsg(st.fail && st.fail.text || "");
      if (c.fail && st.state !== "live") { const p = c.pend.find((x) => !x.failed && !x.busy && x.route === "live"); if (p) p.failed = c.fail; }
      // How long the turn has been going is the server's to say (a turn that began before this page did).
      if (st.state === "live") c.sawLive = true;
      if (st.state === "live" && st.step && st.step.sec != null) { const t = Date.now() - st.step.sec * 1000; if (!c.turnAt || Math.abs(c.turnAt - t) > 3000) c.turnAt = t; }
      // The list's row says what this header says (one state per conversation).
      if (rowSync && st.found !== false) rowSync(s.id, st);
      if (c.agKey !== undefined && JSON.stringify(st.agents || []) !== c.agKey) side(sideOf(body), name, c); };
    let lastState = 0;
    async function states() {
      while (alive()) {
        // Side by side, a pane that is not the focused one asks a third as often (new lines still kick it at once).
        await Promise.race([sleep(Date.now() < (c.fastUntil || 0) ? 1000 : body.matches(".pj-pane:not(.focus)") ? 9000 : 3000), new Promise((r) => { c.kick = r; })]);
        if (!alive()) return;
        if (document.hidden || Date.now() - lastState < 700) continue;
        lastState = Date.now();
        try { merge(await get("/api/project/session?id=" + enc(s.id))); paint(body, c, false, c.entries.length); }
        catch (e) { /* the transcript loop shows the offline note */ }
      }
    }
    async function tail() {
      let first = true, slow = false;
      while (alive()) {
        if (document.hidden && !first) { await sleep(1000); continue; }
        if (slow) { slow = false; await sleep(body.matches(".pj-pane:not(.focus)") ? 3000 : 1000); if (!alive()) return; }
        // A waiting answer keeps a connection, and the browser has six for the whole app: side by
        // side, HOLD panes wait for their next line; the rest ask instead (the focused one every
        // second, the others every 3s).
        const hold = !first && c.offset != null && holds < HOLD;
        if (hold) holds++;
        try {
          const q = "/api/sessions/transcript?id=" + enc(s.id) + "&agent=" + enc(s.agent)
            + (c.offset != null ? "&offset=" + c.offset + (hold ? "&wait=20" : "") : "");
          let tx, st = null;
          try {
            if (first) [tx, st] = await Promise.all([loopFetch(q, {signal: ac.signal}), get("/api/project/session?id=" + enc(s.id))]);
            else tx = await loopFetch(q, {signal: ac.signal});
          } finally { if (hold) holds--; }
          slow = !first && !hold;
          if (!alive()) return;
          if (c.offline) { c.offline = false; paint(body, c, false, c.entries.length); }
          if (st) { merge(st); lastState = Date.now(); }
          if (tx.declined || tx.need_consent) {
            c.loaded = true; paint(body, c, true);
            const b = body.querySelector("#pj-msgs");
            if (b && !c.entries.length) {
              b.innerHTML = `<div class="pj-empty">${tl("pj.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("room.askAgain")}</button></div>`;
              b.querySelector("[data-retry]").onclick = () => draw(body.closest(".pj") || body);
            }
            return;
          }
          if (tx.found === false) {
            if (!c.loaded) { c.loaded = true; paint(body, c, true); const b = body.querySelector("#pj-msgs"); if (b && !c.entries.length) b.innerHTML = `<div class="pj-empty">${tl("pj.noLog")}</div>`; }
            first = false; await sleep(5000); continue;
          }
          const from = c.entries.length, got = tx.entries || [];
          const firstLoad = c.divTs === undefined;
          if (tx.reset || c.offset == null) { c.entries = got; c.start = tx.start || 0; } else if (got.length) c.entries = c.entries.concat(got);
          if (tx.offset != null) c.offset = tx.offset;
          if (tx.results && tx.results.length) c.results = tx.results;
          if (tx.work) c.work = tx.work;
          c.sid = s.id;
          got.forEach((e) => { if (e.kind === "user") { const i = c.pend.findIndex((p) => sameLine(p.text, e.text) && !(p.kept && Date.parse(e.at) < p.at - 60000)); if (i >= 0) { c.pend.splice(i, 1); e._recv = true; } } });
          if (got.some((e) => e.kind === "claude")) c.waiting = false;
          c.loaded = true;
          if (firstLoad) {                       // where the person stopped reading, fixed for this visit
            c.divTs = null;
            if (st && st.read_at) { const f = c.entries.find((e) => e.kind === "claude" && e.at && Date.parse(e.at) > Date.parse(st.read_at)); if (f) c.divTs = f.at; }
          }
          if (first || tx.reset || got.length || c.entries.length < from) {
            paint(body, c, first || tx.reset || c.entries.length < from, from);
            if (first && c.seek) { const k = c.seek, bx = body.querySelector("#pj-msgs"); c.seek = null;
              findOpen(bx.closest(".pj-conv"), k.q); if (k.at) seekLine(bx, c, s, k.side, k.at); }
            markRead(c, s.id);
            side(sideOf(body), name, c);
            if (!first && c.kick) c.kick();
          }
          first = false;
        } catch (e) {
          if (!alive()) return;
          c.offline = true; paint(body, c, false, c.entries.length);
          first = false; await sleep(2000);
        }
      }
    }
    // The seconds on the status line count on their own, between the server's answers.
    (async () => { while (alive()) { await sleep(1000); const n = body.querySelector("#pj-msgs>.pj-now.on"); if (n) nowSec(n); } })();
    tail(); states();
  }
  // Move the read marker to the newest thing the session said, while the room is open and visible.
  function markRead(c, sid) {
    if (document.hidden) return;
    const last = [...c.entries].reverse().find((e) => e.kind === "claude" && e.at);
    if (!last || last.at === c.readSent) return;
    c.readSent = last.at;
    post("/api/room-read", {key: "c:" + sid, at: last.at}).then(() => {
      // What the list remembers follows too: the row left behind must not turn to 내 차례 again
      // from an answer that was read before the server heard about this.
      Object.keys(projSeen).forEach((n) => { const p = projSeen[n], x = ((p.v && p.v.sessions) || []).find((y) => y.id === sid); if (x && x.unread) { x.unread = 0; p.k = JSON.stringify(p.v); } });
      (roomsCache || []).forEach((r) => { if (r.sid === sid) r.unread = 0; (r.more || []).forEach((m) => { if (m.sid === sid) m.unread = 0; }); });
      // The next-unread jump and the counts read attention's rooms: this one is read now.
      if (typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.unread = 0; });
      if (typeof drawChrome === "function") drawChrome();   // the sidebar's unread pill follows at once
    }).catch(() => { c.readSent = null; });
  }

  // Results this session pushed (with their picture, linked to the result) + the project's open comments.
  function resThumb(r) {
    let it = null;
    try { it = (D.items || []).find((x) => iid(x) === r.project + "/" + r.item); } catch (e) { /* items not loaded yet */ }
    const kind = (it && it.kind) || "doc", k = (typeof KIND !== "undefined" && KIND[kind]) || ["doc"];
    return `<span class="th">${ic(k[0])}${it && it.thumb ? `<img src="${esc(it.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : ""}${kind === "video" && it && it.thumb ? `<span class="play">${ic("play")}</span>` : ""}</span>`;
  }
  function side(box, name, c) {
    if (!box) return;
    let items = [];
    try { items = (D.items || []).filter((x) => x.project === name || (typeof gname === "function" && gname(x) === name)); } catch (e) {}
    const open = items.filter((x) => (x.open || 0) > 0);
    const res = c.results || [];
    const row = (t, sub, go, badge) => `<button class="pj-item press" data-go="${esc(go)}">
      <span class="tx"><div class="t">${esc(t)}</div><div class="s">${esc(sub)}</div></span>${badge ? `<span class="cm">${esc(badge)}</span>` : ""}</button>`;
    const resRow = (r) => `<button class="pj-res press" data-go="${esc("item/" + r.project + "/" + r.item)}" title="${esc(r.title)}">${resThumb(r)}
      <span class="tx"><div class="t">${esc(r.title)}</div><div class="s">${esc(vShort ? vShort(r.v) : r.v)}${r.at ? " · " + esc(ago(r.at)) : ""}</div></span></button>`;
    // X7 agent mode: the role agents working for this head, their state, and 멈추기 where it can stop.
    const ags = (c.state && c.state.agents) || [];
    const canFold = threeCols() && !box.closest("[data-multi]");
    // The panel is shut (its strip, or the other tab): the way in carries how many results were
    // not looked at yet. It moves once, when that number goes up, and then only keeps its colour
    // and the number. Open, the results are in view: they count as looked at.
    const sid = (c.state && c.state.id) || "", shut = canFold ? folded("side") : tab !== "side";
    const nf = shut ? unseenRes(sid, res) : 0, pop = nf > (c.popN || 0);
    c.popN = nf;
    if (!shut && res.length) seeRes(sid, res);
    (!canFold && c.body ? c.body.querySelectorAll(`[data-t="side"]`) : []).forEach((tb) => {
      if (tb.dataset.nf === String(nf)) return;
      tb.dataset.nf = nf;
      tb.innerHTML = (tb.hasAttribute("data-res") ? ic("tray") : tl("pj.tab.side")) + (nf ? `<b class="pj-nb${pop ? " pop" : ""}" aria-label="${esc(tl("pj.res.unseen", {n: nf}))}">${nf}</b>` : "");
    });
    if (canFold && shut) {
      const key = [nf, res.length, open.length].join("/"), tip = (nf ? tl("pj.res.unseen", {n: nf}) + " · " : "") + tl("pj.res.tip", {n: res.length, o: open.length});
      c.agKey = JSON.stringify(ags);
      if (box.dataset.strip === key && box.querySelector(".pj-strip")) return;      // nothing new: a mark in motion is left alone
      box.dataset.strip = key; box.classList.remove("pj-dn1");
      const was = box.firstElementChild && !box.querySelector(":scope>.pj-strip");      // the open panel was there: it was folded just now
      box.innerHTML = `<button class="pj-strip r${was ? " pj-anim" : ""} press${nf ? " new" : ""}${pop ? " pop" : ""}" data-fold="side" aria-expanded="false" aria-label="${esc(tip)}" title="${esc(tip)}">${ICO.panel}<span class="c${nf ? " new" : ""}" aria-hidden="true">${ic("stack")}<b>${nf || res.length}</b></span><span class="c${open.length ? " hot" : ""}" aria-hidden="true">${ic("chat")}<b>${open.length}</b></span></button>`;
      return;
    }
    delete box.dataset.strip;
    const rd = folded("rdense");
    box.classList.toggle("pj-dn1", rd);
    const foldBtn = `<span class="sp"></span><button class="pj-fbtn pj-rdn press" data-rdense aria-pressed="${rd}" aria-label="${esc(tl("pj.res.dense"))}" title="${esc(tl("pj.res.dense"))}">${ic("list")}</button>`
      + (canFold ? `<button class="pj-fbtn r press" data-fold="side" aria-expanded="true" aria-label="${esc(tl("pj.side.fold"))}" title="${esc(tl("pj.side.fold"))}">${ICO.panel}</button>` : "");
    const WHY = {inside: [tl("pj.ag.no.inside"), tl("pj.ag.why.inside")], terminal: [tl("pj.ag.no.terminal"), tl("pj.ag.why.terminal")],
      codex: [tl("pj.ag.no.codex"), tl("pj.ag.why.codex")]};
    const agRow = (a) => `<div class="pj-agt"><button class="go press" data-go="${esc(a.inside ? "item/" + a.project + "/" + a.item : "project/" + enc(name) + "/" + enc(a.sid))}">${dot(a.state)}
      <span class="tx"><div class="t">${esc(a.role)}</div><div class="s">${esc(LABEL[a.state] || a.state)} · ${esc(a.inside ? tl("pj.ag.inside") : (a.title || a.sid.slice(0, 8)))}${a.at ? " · " + esc(ago(a.at)) : ""}</div></span></button>
      ${a.stoppable ? `<button class="stp press" data-agstop="${esc(a.sid)}">${esc(tl("pj.ag.stop"))}</button>`
        : WHY[a.why] ? `<span class="s" style="flex:none;font-size:11.5px;color:var(--t4)" title="${esc(WHY[a.why][1])}">${esc(WHY[a.why][0])}</span>` : ""}</div>`;
    box.innerHTML =
      (ags.length ? `<div class="pj-lab" style="margin-top:4px">${esc(tl("pj.ag.head"))} <span class="n">${ags.length}</span>${foldBtn}</div>` + ags.slice(0, 12).map(agRow).join("") : "") +
      `<div class="pj-lab"${ags.length ? "" : ` style="margin-top:4px"`}>${tl("pj.res.head")} <span class="n">${res.length}</span>${ags.length ? "" : foldBtn}</div>` +
      (res.length ? res.slice(0, 12).map(resRow).join("")
        : `<div class="pj-empty" style="text-align:left;padding:8px 2px">${tl("pj.res.none")}</div>`) +
      `<div class="pj-lab">${tl("pj.open.head")} <span class="n">${open.length}</span></div>` +
      (open.length ? open.slice(0, 12).map((x) => row(x.title, `${vShort(x.v)} · ${ago(x.at)}`, "item/" + iid(x), tl("pj.open.n", {n: x.open}))).join("")
        : `<div class="pj-empty" style="text-align:left;padding:8px 2px">${tl("pj.open.none")}</div>`);
    c.agKey = JSON.stringify(ags);
    const db = box.querySelector("[data-rdense]");
    if (db) db.onclick = () => { setFold("rdense", !folded("rdense")); side(box, name, c); const b = box.querySelector("[data-rdense]"); if (b) b.focus({preventScroll: true}); };
    box.querySelectorAll("[data-agstop]").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const a = ags.find((x) => x.sid === b.dataset.agstop);
      if (a) control("stop", {id: a.sid, agent: a.agent, state: a.state}, name, () => { if (c.kick) c.kick(); });
    });
  }

  // Desktop: size the columns to the room left under the toolbar. The bottom status bar (#status, fixed
  // from 1024px) and every ancestor's bottom padding are taken off, so the composer is never under it.
  function fit() {
    const g = document.querySelector(".pj-cols"); if (!g) return;
    if (!wide()) { g.style.removeProperty("--pjh"); return; }
    const st = document.getElementById("status");
    let r = st && getComputedStyle(st).position === "fixed" ? st.offsetHeight : 0;
    for (let n = g.parentElement; n && n !== document.body; n = n.parentElement) {
      const cs = getComputedStyle(n); r += (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.marginBottom) || 0);
    }
    let top = 0;                          // offsetTop ignores the entrance animation's translate
    for (let n = g; n; n = n.offsetParent) top += n.offsetTop;
    g.style.setProperty("--pjh", Math.max(320, Math.floor(innerHeight - r - top)) + "px");
  }
  window.pjFit = fit;
  window.pjCtx = ctxRow;                                       // the floating window's cards say how full a conversation is the same way
  window.pjCss = ensureCss;                                    // the floating window's blocks wear the session row's tokens
  // The same menu, for surfaces that are not the chat list (web/railmenu.js: the side menu's rows,
  // result cards): one place for the position, the keys and the look. `at` is {x, y, row, kb, label}.
  window.pjPopAt = (pop, anchor, at) => { ensureCss(); ctxAt = at || null; const off = popAt(pop, anchor); ctxAt = null; return off; };
  window.pjIconOf = (anchor, name) => iconOf(anchor, name, () => {});
  // Phone: an open chat takes the whole visible screen (see body.pjchat in the CSS). Decided from
  // what is drawn: a chat pane that is showing, on the chat screen, under 1024px.
  function phoneChat() {
    const {name} = where();
    const conv = !wide() && name && name !== ALL && name !== MULTI && document.querySelector("#view .pj>.pj-cols:not(.pj-listonly) .pj-conv");
    const on = !!conv && conv.style.display !== "none" && !!conv.querySelector(".pj-nth");
    document.body.classList.toggle("pjchat", on);
    if (swLeft && !(SW && SW.live())) { SW.clear(swLeft); swLeft = null; swRail = null; swPeek(false); }
    if (!on && typeof typingSync === "function") typingSync();   // a box hidden with the chat no longer hides the tab bar (v2.js)
    if (on) vvFit(); else document.body.classList.remove("pj-kb");
    // The chat appears where it is, once per opening (a redraw, another session picked while it is
    // up, or coming back from the results tab is not an opening). Only the hand slides it (below).
    if (!on) { if (!conv) chatAt = ""; return; }
    const was = chatAt; chatAt = location.hash;
    if (was) return;
    conv.animate([{opacity: 0}, {opacity: 1}], {duration: RM() ? 180 : 140, easing: "ease-out"});
  }
  let chatAt = "";
  // By hand (web/swipe.js): a row of the list is pulled sideways for its buttons, the chat is
  // pulled from the left edge to show the list under it, and from the right edge the list gives
  // the chat back. Here is only what those act on; every button is one the row's menu has.
  const swRoot = () => document.querySelector("#view .pj");
  const swPeek = (on) => document.body.classList.toggle("pj-peek", on);
  let swRail = null;
  if (SW) SW.host = {
    ok: () => phoneList() && location.hash.startsWith("#project") && !document.querySelector(".pj-pop,#sheet.on,#ov.on,.vw,.stk"),
    row: (sid) => {
      const h = railRows.get(sid); if (!h) return null;
      // Each: its outline icon, one short word under it, and its tone (go = the accent, dz = caution).
      const s = h.s, b = (a, icon, text, tone) => ({a, icon: icl(icon), text: esc(text), label: esc(what(a, s).label), dz: tone === "dz", go: tone === "go", off: what(a, s).off || ""});
      const hide = b("tidy", "hide", tl("mn.tidy"));
      // The menu's own order: 이어서 하기 (an ended one), 읽음, then 숨기기 or 끝내기.
      return {left: (s.state === "ended" ? [b("open", "resume", tl("sw.open"), "go")] : []).concat(s.agent === "codex" ? [] : [s.unread ? b("read", "read", tl("sw.read")) : b("read", "unread", tl("sw.unread"))],
        s.state === "ended" ? hide : b("stop", "end", s.agent === "codex" ? tl("room.codexStop") : tl("mn.stop"), "dz")), right: hide};
    },
    act: (a, sid) => { const h = railRows.get(sid), el = swRoot(); if (h && el) return control(a, h.s, h.name, () => draw(el)); },
    edge: {
      can: (side) => {
        const el = swRoot(), cols = el && el.querySelector(":scope>.pj-cols"), conv = cols && cols.querySelector("#pj-body .pj-conv");
        if (!conv || !conv.querySelector(".pj-nth [data-list]")) return false;
        return side === "l" ? document.body.classList.contains("pjchat") && !document.body.classList.contains("pj-kb") : listAt && cols.classList.contains("pj-listonly") && !!lastChat.name;
      },
      // The list is put under the chat (left edge), or the chat over the list's right edge.
      begin: (side) => {
        const cols = swRoot().querySelector(":scope>.pj-cols"), conv = cols.querySelector("#pj-body .pj-conv");
        if (side === "l") {
          if (!cols.querySelector(":scope>.pj-rail")) { swRail = document.createElement("div"); swRail.className = "pj-rail"; cols.insertBefore(swRail, cols.firstChild); if (railNow) railNow(); }
          swPeek(true); document.documentElement.scrollTop = listY;
        } else { listY = scrollY; cols.classList.remove("pj-listonly"); document.body.classList.add("pjchat"); swPeek(true); vvFit(); }
        return conv;
      },
      end: (to, conv) => {
        const el = swRoot(), cols = el && el.querySelector(":scope>.pj-cols"), now = cols && cols.classList.contains("pj-listonly") ? "list" : "chat";
        const done = () => { swPeek(false); swRail = null; SW.clear(conv); };
        if (!cols || !conv.isConnected) return done();
        if (to === "chat" && listAt) {                 // the chat was pulled back over the list: it is opened
          done(); const y = listY; fromList("project/" + enc(lastChat.name) + "/" + enc(lastChat.sid)); listY = y; return;
        }
        if (to === "chat") { if (swRail) swRail.remove(); document.documentElement.scrollTop = 0; return done(); }
        if (listAt) { cols.classList.add("pj-listonly"); document.body.classList.remove("pjchat"); return done(); }
        swLeft = conv; toList();                      // the page that follows clears it (phoneChat)
        setTimeout(() => { if (swLeft === conv) { swLeft = null; done(); } }, 1500);
      },
    },
  };
  let swLeft = null;
  // The pane is as tall as what can be seen: on an iPhone the keyboard covers the page instead of
  // resizing it, and the page may be pushed up under it (offsetTop). A pinch zoom is left alone.
  // Whether the keyboard is up is read against the tallest the screen has been at this width with
  // no box in use: an iPhone can report innerHeight already shrunk by the keyboard, and a phone
  // that resizes the page always does, so "innerHeight - height" alone can miss it.
  let vvBase = 0, vvW = 0;
  function vvFit() {
    const b = document.body, v = window.visualViewport;
    if (!b.classList.contains("pjchat") || (v && v.scale > 1.01)) return;
    const h = v ? v.height : innerHeight, t = v ? v.offsetTop : 0;
    const bar = b.classList.contains("inapp") ? (document.getElementById("top") || {}).offsetHeight || 0 : 0;
    b.style.setProperty("--pj-vh", Math.round(h - bar) + "px");
    b.style.setProperty("--pj-vt", Math.round(t + bar) + "px");
    const a = document.activeElement, typing = !!(a && a.matches && a.matches("textarea, input, [contenteditable]"));
    if (innerWidth !== vvW) { vvW = innerWidth; vvBase = 0; }
    vvBase = typing ? Math.max(vvBase, h, innerHeight, document.documentElement.clientHeight) : h;
    const kb = typing && vvBase - h > 80;
    if (kb === b.classList.contains("pj-kb")) return;
    b.classList.toggle("pj-kb", kb);
    // The box's height was set for the other padding: one line again, or what is typed (four lines at most over the keyboard).
    const ta = document.getElementById("pj-ta");
    if (ta) { const cs = getComputedStyle(ta), cap = Math.round((parseFloat(cs.lineHeight) || 22) * (kb ? 4 : 6) + parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom));
      if (!ta.value || !ta.scrollHeight) ta.style.height = "";
      else { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, cap) + "px"; } }
  }
  if (window.visualViewport) {
    let raf = 0;
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(vvFit); };
    visualViewport.addEventListener("resize", on); visualViewport.addEventListener("scroll", on);
    addEventListener("focusout", () => setTimeout(on, 80));   // the keyboard put away with no resize told: the rows come back
  }
  // Put a line in a conversation's message box before it opens (the item screen's 후속 요청).
  // Text typed and not sent, anywhere (a new conversation's first line or an open one): the app
  // update asks before a restart would drop it.
  window.pjUnsent = () => Object.values(drafts).some((v) => v && v.trim()) || Object.values(convs).some((c) => c.draft && c.draft.trim());
  window.pjDraft = (sid, text) => { const c = C(sid); c.draft = text; writeDraft(sid, text); c.focusDraft = true; };
  // The same chat, mounted somewhere else (the item screen's chat tab, custom.js): one pane, no
  // side column. `o.sid` is the session to open; without it (or when it is unknown here) the
  // department `o.name` gives its own session (the pin), else one that is up, else the newest.
  window.pjEmbed = async function (body, o) {
    ensureCss();
    body._pjEmbed = () => window.pjEmbed(body, o);
    let cur = null, name = o.name || "";
    if (o.sid) {
      const s = await get("/api/project/session?id=" + enc(o.sid)).catch(() => null);
      if (s && s.found) { cur = Object.assign({}, s, {id: o.sid}); name = s.project || name; }
    }
    if (!cur && name) {
      const v = await readOrAsk("/api/project?name=" + enc(name)).catch(() => null);
      if (v && (v.need_consent || v.declined)) return {name, consent: true};
      const all = (v && v.sessions) || [];
      cur = all.find((s) => v.pin && s.id === v.pin) || pickCurrent(all.filter((s) => !s.tidied));
    }
    if (!body.isConnected) return null;
    if (!cur) return {name, session: null};
    body.dataset.multi = "1"; tab = "conv";
    drawSession(body, body, name, cur, {embed: body});
    return {name, session: cur, state: () => (C(cur.id).state || cur).state};
  };
  addEventListener("resize", () => { fit(); const b = document.getElementById("pj-body"); if (b && b.querySelector("[data-col]")) cols(b); else phoneChat(); });
  // The page width also changes without the window (the app menu folding): when that crosses the
  // three-column line the room is drawn again in its other shape; otherwise the two side widths
  // are fitted again so the chat keeps its 380px.
  if (typeof ResizeObserver === "function") {
    let t = 0, was = null;
    const settle = () => {
      const pj = document.querySelector("#view .pj"), now = threeNow();
      if (!pj || !pj.querySelector(".pj-cols") || !location.hash.startsWith("#project/")) return;
      if (threeCols() !== now || (!now && document.documentElement.classList.contains("pj2") !== twoNow()) || splitWant(pj) !== splitDrawn(pj) || splitStale(pj)) draw(pj); else if (now) { colGrips(pj); fit(); }
    };
    const ro = new ResizeObserver((es) => { const w = Math.round(es[0].contentRect.width); if (w === was) return; was = w; clearTimeout(t); t = setTimeout(settle, 180); });
    const v = document.getElementById("view"); if (v) ro.observe(v);
  }
  addEventListener("hashchange", () => { if (!location.hash.startsWith("#project")) stop(true); phoneChat(); });

  // ---- join the app ------------------------------------------------------------------------------------
  window.LOOP_TABS = window.LOOP_TABS || [];
  // The room page stays up while the person moves inside it (another conversation, another
  // project, back and forward) and across the app's refresh rounds: draw() brings it up to date.
  // The list of rooms stays up the same way, so a refresh round only touches the rows that changed.
  const keeps = (v) => { const p = v.firstElementChild, w = where(); if (!p || v.children.length !== 1 || !p.classList.contains("pj")) return false;
    // The first loader stays up when the list hands over to a chat (a PC opens the last one): one loader, not two.
    if (p.querySelector(":scope>rl-load")) return true;
    if (!w.name || w.name === ALL) return !!p.querySelector(":scope>#pj-rg");
    return !!p.querySelector(":scope>.pj-cols") && w.name !== MULTI; };
  window.LOOP_TABS.push({id: "project", get label() { return tl("menu.chat"); }, icon: "chat", draw, keeps});
  // v2.js drew once before this file loaded: register the screen now and redraw if we are on it.
  try { syncExtTabs(); if (location.hash.startsWith("#project")) render(); else drawChrome(); } catch (e) { /* the next render picks the tab up */ }
})();
