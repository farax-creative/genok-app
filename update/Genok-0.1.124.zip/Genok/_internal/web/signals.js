// 답을 기다리는 세션: a card on 받은함 > 할 것. Part of the app core.
//
// GET /api/signals lists the background sessions that wait for an answer. Waits older than 12
// hours fold away as "오래된 질문" so they stop crowding what is fresh. Nothing on this card
// stops, wakes or answers a session; it only shows them.
//
// Reading the session list asks first. Until it is allowed the card is one quiet state line with
// one neutral button (state first, then the action); the dialog opens only on that button.
//
// Look follows the refern inspector: grey panel, small letter-spaced label with a chevron to
// fold, thin dividers, full-width neutral button, no loud colour. The fold is a spring on state
// (a tap mid-way just reverses it); under prefers-reduced-motion it is a soft fade instead.
//
// Each waiting row can be answered from here (Q05, the hub's reply chips): one-tap answers drawn
// from what the session is asking plus "ㅇㅋ 진행해", a line to type, and a link to open the whole
// conversation. The answer goes through /api/session/tell, which never wakes a session that is up.
//
// Attaches by wrapping SCREENS.inbox (v2.js is not edited). App globals: SCREENS, V, esc, loopFetch.

// One-tap answers for what a session waits on: the options it offered ("A | B", "(A/B)", a
// numbered or dashed list, y/n), at most four, then the plain go-ahead. Pure, for node tests.
const SG_GO = "ㅇㅋ 진행해";
function sgChoices(needs) {
  const s = String(needs == null ? "" : needs).trim();
  let opts = [];
  const lines = s.split(/\n/).map((l) => /^\s*(?:\d{1,2}[.)]|[-*•])\s+(.+)$/.exec(l)).filter(Boolean).map((m) => m[1]);
  if (lines.length >= 2) opts = lines;
  else if (/\|/.test(s)) opts = s.replace(/^[^|:：]*[:：]\s*/, "").split("|");
  else {
    const par = /\(([^()]*\/[^()]*)\)/.exec(s) || /\[([^\[\]]*\/[^\[\]]*)\]/.exec(s);
    if (par && !/^y\/n$/i.test(par[1].trim())) opts = par[1].split("/");
    else if (/\by\/n\b/i.test(s)) opts = ["yes", "no"];
  }
  const out = [];
  for (const o of opts.map((x) => x.replace(/\*+$/, "").trim())) {
    if (o && o.length <= 40 && !out.includes(o) && out.length < 4) out.push(o);
  }
  if (!out.includes(SG_GO)) out.push(SG_GO);
  return out;
}
if (typeof module !== "undefined") module.exports = { sgChoices, SG_GO };

(function () {
  "use strict";
  if (typeof window === "undefined" || window.__signalsCore || typeof SCREENS === "undefined" || !SCREENS.inbox) return;
  window.__signalsCore = true;

  const _esc = typeof esc === "function" ? esc : (s) => String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  // What a project (or a group) is called on screen: the display name a person gave it (v2.js).
  const _pn = (n) => typeof pname === "function" ? pname(n) : n;
  const chev = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>`;
  const REFRESH_MS = 20000;

  let last = null;          // {asks, old_hours} | {need: dialog} | null
  let at = 0;
  let inflight = null;
  const shut = { fresh: false, old: true };
  const drafts = {};        // sid -> a reply being typed, kept across the card's repaints
  const sent = {};          // sid -> {t, held}: what went out and whether it is still waiting to be handed over

  // .sg is also the stage grid thumbnail in v2.css (aspect-ratio 16/10), which cut this card short.
  const CSS = `
.sg{aspect-ratio:auto;cursor:auto;position:static;background:var(--card);border-radius:var(--r-card,12px);margin:0 0 12px;overflow:hidden;color:var(--t1);--sg-spring:cubic-bezier(.34,1.4,.64,1)}
.sg-sec{border-top:1px solid var(--line)}
.sg>.sg-sec:first-child{border-top:0}
.sg-sh{display:flex;align-items:center;gap:8px;width:100%;min-height:44px;padding:0 16px;text-align:left;color:var(--t3);cursor:pointer}
.sg-sh:hover{color:var(--t2)}
.sg-sh .l{flex:1;min-width:0;font-size:12px;font-weight:700;letter-spacing:.07em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sg-sh .n{font-size:12px;font-weight:500;letter-spacing:0}
.sg-sh .cv{flex:none;display:grid;place-items:center;width:20px;height:20px;transition:transform .5s var(--sg-spring)}
.sg-sec.shut .sg-sh .cv{transform:rotate(-90deg)}
.sg-sb{display:grid;grid-template-rows:1fr;transition:grid-template-rows .5s var(--sg-spring),opacity .25s ease}
.sg-sb>div{overflow:hidden;min-height:0}
.sg-sec.shut .sg-sb{grid-template-rows:0fr;opacity:0}
.sg-row{display:flex;align-items:baseline;gap:8px;padding:8px 16px;border-top:1px solid var(--line)}
.sg-row:first-child{border-top:0}
.sg-row .t{flex:1;min-width:0;font-size:14px;line-height:1.4;overflow-wrap:anywhere}
.sg-row .t small{display:block;margin-top:2px;font-size:12px;color:var(--t3)}
.sg-row .a{flex:none;font-size:12px;color:var(--t3)}
.sg-bd{padding:2px 16px 16px}
.sg-line{margin:0;font-size:13px;line-height:1.5;color:var(--t2)}
.sg-acts{display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:0 16px 12px}
.sg-chip{height:30px;padding:0 12px;border-radius:16px;background:var(--btn,#2a2a2a);color:var(--t1);font-size:13px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;transition:transform .35s var(--sg-spring),filter .15s}
.sg-chip:hover{filter:brightness(1.2)}
.sg-chip:active{transform:scale(.96)}
.sg-chip:disabled{opacity:.5}
.sg-reply{display:flex;gap:6px;flex:1 1 100%;min-width:0}
.sg-reply input{flex:1;min-width:0;height:34px;padding:0 12px;border-radius:8px;border:1px solid var(--line);background:transparent;color:var(--t1);font:inherit;font-size:14px}
.sg-reply button{flex:none;height:34px;padding:0 12px;border-radius:8px;background:var(--btn-hi,#323232);color:var(--t1);font-size:13px;font-weight:600}
.sg-open{flex:none;margin-left:auto;font-size:12px;color:var(--blue-t,var(--t2));text-decoration:none}
.sg-open:hover{text-decoration:underline}
.sg-sent{flex:1 1 auto;min-width:0;font-size:12px;color:var(--t3);overflow-wrap:anywhere}
.sg-btn{display:block;width:100%;height:38px;margin-top:12px;border-radius:8px;background:var(--btn-hi,#323232);color:var(--t1);font-size:14px;font-weight:600}
.sg-need{display:flex;align-items:center;gap:12px;padding:8px 8px 8px 16px}
.sg-need .sg-line{flex:1;min-width:0}
.sg-need .sg-line b{display:block;color:var(--t1);font-weight:600}
.sg-need .sg-btn{flex:none;width:auto;height:44px;margin:0;padding:0 14px}
.sg-btn:hover{filter:brightness(1.25)}
.sg-btn:active{transform:scale(.985)}
@media (prefers-reduced-motion:reduce){
  .sg-sh .cv,.sg-btn,.sg-chip{transition:none}
  .sg-sb{transition:opacity .2s ease}
  .sg-sec.shut .sg-sb{grid-template-rows:1fr;visibility:hidden}
}`;

  function css() {
    if (document.getElementById("sg-css")) return;
    const s = document.createElement("style");
    s.id = "sg-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  const age = (s) => s < 90 ? tl("sg.now") : s < 3600 ? tl("sg.min", {n: Math.round(s / 60)}) : s < 86400 ? tl("sg.hr", {n: Math.floor(s / 3600)}) : tl("sg.day", {n: Math.floor(s / 86400)});

  function sec(key, label, n, body) {
    return `<div class="sg-sec ${shut[key] ? "shut" : ""}" data-sg="${key}">
      <button class="sg-sh" type="button" aria-expanded="${!shut[key]}"><span class="l">${label}</span>${n != null ? `<span class="n">${n}</span>` : ""}<span class="cv">${chev}</span></button>
      <div class="sg-sb"><div>${body}</div></div></div>`;
  }

  // The answer tools under a waiting row: only when the row carries the session id to answer.
  function acts(a) {
    if (!a.session) return "";
    const open = `<a class="sg-open" href="#project/${encodeURIComponent(a.dept)}/${encodeURIComponent(a.session)}">${tl("sig.3")}</a>`;
    if (sent[a.session]) return `<div class="sg-acts"><span class="sg-sent">${sent[a.session].held ? tl("sig.held") : tl("sig.4")} · ${_esc(sent[a.session].t)}</span>${open}</div>`;
    const chips = sgChoices(a.needs).map((c) => `<button class="sg-chip press" type="button" data-sg-say="${_esc(c)}">${_esc(c)}</button>`).join("");
    return `<div class="sg-acts" data-sg-sid="${_esc(a.session)}">${chips}${open}<form class="sg-reply"><input type="text" enterkeyhint="send" maxlength="4000" placeholder="${tl("sig.1")}" aria-label="${tl("sig.1")}" value="${_esc(drafts[a.session] || "")}"><button type="submit" class="press">${tl("sig.2")}</button></form></div>`;
  }

  // The same wording as the 할 것 rows (v2.js needsText): the CLI names the wait in English.
  const needs = (n) => typeof needsText === "function" ? needsText(n) : n;
  const row = (a) => `<div class="sg-row"><span class="t">${_esc(_pn(a.dept))}${a.needs ? `<small>${_esc(needs(a.needs))}</small>` : ""}</span><span class="a">${age(a.age)}</span></div>${acts(a)}`;

  async function say(box, text) {
    const sid = box.dataset.sgSid, t = String(text || "").trim();
    if (!sid || !t) return;
    const ctl = box.querySelectorAll("button,input");
    ctl.forEach((b) => { b.disabled = true; });
    try {
      const r = await loopFetch("/api/session/tell", { method: "POST", json: { sid, text: t } });
      if (r.declined) { ctl.forEach((b) => { b.disabled = false; }); return; }
      sent[sid] = {t, held: r.routed !== "live" && r.routed !== "native"}; delete drafts[sid];
      if (r.routed !== "live" && r.message && typeof toast === "function") toast(r.message);
      paint();
    } catch (e) {
      ctl.forEach((b) => { b.disabled = false; });
      if (typeof toast === "function") toast(e.message || tl("sig.5"));
    }
  }

  function html() {
    if (!last) return "";
    if (last.need) {
      return `<div class="sg-need"><p class="sg-line"><b>${tl("sg.wait")}</b> ${tl("sg.need")}</p><button class="sg-btn" type="button" data-sg-ask>${tl("consent.askbtn")}</button></div>`;
    }
    // While the watcher reads the list, fresh waits are rows of 할 것 itself (v2.js, counted in
    // the red number); this card then keeps only the old ones.
    const inTodo = typeof att !== "undefined" && att && att.watching;
    const asks = last.asks || [], fresh = inTodo ? [] : asks.filter((a) => !a.old), old = asks.filter((a) => a.old);
    if (!fresh.length && !old.length) return "";
    return (fresh.length ? sec("fresh", tl("sg.wait"), fresh.length, fresh.map(row).join("")) : "")
      + (old.length ? sec("old", tl("sg.old", {n: last.old_hours || 12}), old.length, old.map(row).join("")) : "");
  }

  function paint() {
    const v = typeof V === "function" ? V() : null;
    if (!v) return;
    const old = v.querySelector(".sg");
    if (old) old.remove();
    const h = html();
    if (!h) return;
    css();
    const card = document.createElement("div");
    card.className = "sg";
    card.innerHTML = h;
    const first = v.querySelector(".card");
    if (first) v.insertBefore(card, first); else v.appendChild(card);
    card.querySelectorAll(".sg-sh").forEach((b) => b.addEventListener("click", () => {
      const s = b.parentElement, k = s.dataset.sg;
      shut[k] = !shut[k];
      s.classList.toggle("shut", shut[k]);
      b.setAttribute("aria-expanded", String(!shut[k]));
    }));
    card.querySelectorAll("[data-sg-sid]").forEach((box) => {
      const sid = box.dataset.sgSid, inp = box.querySelector("input");
      box.querySelectorAll("[data-sg-say]").forEach((b) => b.addEventListener("click", () => say(box, b.dataset.sgSay)));
      inp.addEventListener("input", () => { drafts[sid] = inp.value; });
      box.querySelector("form").addEventListener("submit", (e) => { e.preventDefault(); say(box, inp.value); });
    });
    const ask = card.querySelector("[data-sg-ask]");
    if (ask) ask.addEventListener("click", async () => {
      ask.disabled = true;
      try {
        const r = await loopFetch("/api/signals");
        if (!r.declined) { last = r; at = Date.now(); }
      } catch (e) { /* stays on the state line */ }
      paint();
    });
  }

  function refresh() {
    if (inflight) return inflight;
    // A plain fetch: the dialog must not pop up by itself on every visit to 할 것.
    inflight = fetch("/api/signals", { cache: "no-store" })
      .then(async (r) => {
        const j = await r.json().catch(() => ({}));
        last = j && j.need_consent ? { need: j.need_consent } : r.ok && j.asks ? j : last;
        at = Date.now();
        // A wait that ended takes its "sent" line with it; a new wait of that session asks afresh.
        const live = new Set(((last && last.asks) || []).map((a) => a.session));
        Object.keys(sent).forEach((k) => { if (!live.has(k)) delete sent[k]; });
      })
      .catch(() => {})
      .then(() => {
        inflight = null;
        // Typing a reply is not interrupted by the card redrawing itself around the caret.
        const a = document.activeElement, typing = a && a.closest && a.closest(".sg-reply");
        if (!typing && typeof cur !== "undefined" && cur === "inbox") paint();
      });
    return inflight;
  }

  const orig = SCREENS.inbox;
  SCREENS.inbox = function (tab) {
    const out = orig.apply(this, arguments);
    if (tab === undefined || tab === "do" || (typeof inTab !== "undefined" && inTab === "do")) {
      paint();                                   // from what is known, at once
      if (Date.now() - at > REFRESH_MS) refresh();
    }
    return out;
  };
})();
