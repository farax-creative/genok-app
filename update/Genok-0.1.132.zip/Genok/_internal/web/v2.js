// Genok: see what an agent made, compare versions, and say what to change.
// Four tabs - 내 차례, 프로젝트, 결과물, 설정. Plain script, no build; it reads /api.

let D = {sessions: [], board: [], usage: {}, items: [], ins: {ready: false}, codex: [], places: [], agents: [], pins: [], hidden: [], favs: null, keys: {}, room_read: {}, at: null};

// UI text lives in web/i18n/ko.json (served as /i18n.js). tl(key, {name}) fills in each {name};
// a missing key shows the key itself, so a gap is visible rather than blank.
// The unit of work is one word everywhere, "폴더". Text never spells the word: ko.json and the
// code say {unit}, and a particle that depends on how the word ends is a token too - {unit}{을}
// reads 폴더를.
//   {unit}                the word            {units} {Unit} {Units}: English plural / capital
//   {을} {이} {은} {와} {로} {예요} {라} {나} {랑} {든}   (either form of a pair: {을} = {를})
// unitname.py holds the same rules for server text; tests/unit.test.js keeps the two in step and
// fails when a new string spells the default word instead of {unit}.
// unit:begin
const UNIT_DEF = {ko: "폴더", en: "folder"};
const JOSA_PAIRS = [["을", "를"], ["이", "가"], ["은", "는"], ["과", "와"], ["으로", "로"], ["이에요", "예요"],
  ["이라", "라"], ["이나", "나"], ["이랑", "랑"], ["이든", "든"]];
const JOSA = JOSA_PAIRS.reduce((o, p) => (o[p[0]] = o[p[1]] = p, o), {});
const JOSA_RE = /\{(이에요|예요|으로|이라|이나|이랑|이든|을|를|이|가|은|는|과|와|로|라|나|랑|든)\}/g;
const DIGIT_END = {0: 1, 1: 2, 2: 0, 3: 1, 4: 0, 5: 0, 6: 1, 7: 2, 8: 2, 9: 0};   // 영 일 이 삼 사 오 육 칠 팔 구
// How a text ends, by its last letter or digit: 0 a vowel, 1 a final consonant, 2 the consonant ㄹ
// (로, not 으로). Hangul is read off the syllable, a digit by its Korean reading, a Latin letter by
// a guess: l is ㄹ, m / n / ng a consonant, anything else a vowel (Team 팀, Folder 폴더).
const endSound = (text) => {
  const s = String(text || "");
  let i = s.length - 1;
  while (i >= 0 && !/[\p{L}\p{N}]/u.test(s[i])) i--;
  if (i < 0) return 0;
  const ch = s[i], c = ch.charCodeAt(0);
  if (c >= 0xAC00 && c <= 0xD7A3) { const j = (c - 0xAC00) % 28; return j === 0 ? 0 : j === 8 ? 2 : 1; }
  if (ch in DIGIT_END) return DIGIT_END[ch];
  const low = ch.toLowerCase();
  if (low === "l") return 2;
  if (low === "m" || low === "n") return 1;
  if (low === "g" && i > 0 && s[i - 1].toLowerCase() === "n") return 1;
  return 0;
};
const josa = (text, token) => {
  const p = JOSA[token]; if (!p) return token;
  const f = endSound(text);
  return p[0] === "으로" ? (f === 1 ? "으로" : "로") : (f ? p[0] : p[1]);
};
// The word the person picked ("" while it is the default). names.unit is where it lived before.
const unitCustom = () => "";
const unitPlural = (w) => !/[a-z]$/i.test(w) ? w : /(s|x|z|ch|sh)$/i.test(w) ? w + "es" : /[^aeiou]y$/i.test(w) ? w.slice(0, -1) + "ies" : w + "s";
const unitCap = (w) => w.charAt(0).toUpperCase() + w.slice(1);
// `as` fills with a given word instead of the saved one (the preview in 설정 › 화면).
const unitFill = (t, lang, as) => {
  if (t.indexOf("{") < 0 && t.indexOf("부서") < 0) return t;
  const w = as || unitCustom() || UNIT_DEF[lang] || UNIT_DEF.ko;
  // A stray "부서" (an extension's text, an old server message) is still the unit, particle and all.
  let s = t.replace(/부서(를|가|는|와|로)?/g, (m, j) => w + (j ? "{" + j + "}" : ""))
    .replace(/\{(unit|units|Unit|Units)\}/g, (m, k) => k === "unit" ? w : k === "units" ? unitPlural(w) : k === "Unit" ? unitCap(w) : unitCap(unitPlural(w)));
  if (s.indexOf("{") < 0) return s;
  let out = "", last = 0, m;
  JOSA_RE.lastIndex = 0;
  while ((m = JOSA_RE.exec(s))) { out += s.slice(last, m.index); out += josa(out, m[1]); last = m.index + m[0].length; }
  return out + s.slice(last);
};
const tl = (key, vars, as) => {
  const own = window.I18N?.[key];
  const t = String(own ?? window.I18N_ALL?.ko?.[key] ?? key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? vars[k] : m);
  return unitFill(t, own != null ? (window.I18N_LANG || "ko") : "ko", typeof as === "string" ? as : "");
};
// Text written in the code itself (no ko.json key) says {unit} too and goes through this.
const ut = (t) => unitFill(String(t), "ko");
// The server speaks Korean. A line it sends (an error, a toast, a confirm) is looked up by its
// Korean words among the srv.* keys and shown in the page's language; an unknown line stays as sent.
// {a}, {name} in a srv.* text stand for what the server filled in.
let srvIx = null;
const srvT = (t) => {
  if (typeof t !== "string" || LANG() === "ko" || !/[가-힣]/.test(t)) return t;
  const ko = (window.I18N_ALL && window.I18N_ALL.ko) || {};
  if (!srvIx) {
    srvIx = {exact: {}, pat: []};
    for (const k in ko) {
      if (k.slice(0, 4) !== "srv.") continue;
      const v = ko[k];
      if (v.indexOf("{") < 0) { srvIx.exact[v] = k; srvIx.exact[v.replace(/\.$/, "")] = k; continue; }
      const names = [];
      const re = v.replace(/[.*+?^$()|[\]\\]/g, "\\$&").replace(/\\?\{(\w+)\\?\}|\{(\w+)\}/g, (m, a, b) => { names.push(a || b); return "(.+?)"; });
      srvIx.pat.push([new RegExp("^" + re + "\\.?$"), k, names]);
    }
  }
  const s = t.trim(), k = srvIx.exact[s];
  if (k) return tl(k);
  for (const [re, key, names] of srvIx.pat) {
    const m = re.exec(s); if (!m) continue;
    const vars = {}; names.forEach((n, i) => { if (!/^units?$/i.test(n)) vars[n] = m[i + 1]; });   // the unit word is each language's own
    return tl(key, vars);
  }
  return t;
};
// unit:end
// The UI language. /i18n.js ships both dictionaries and picks one (the saved setting, else the
// OS/browser locale: ko -> Korean, anything else -> English). setLang swaps it in place. en.json
// may hold only some keys: tl falls back to the Korean text, never to the bare key.
const LANG = () => window.I18N_LANG || "ko";
// A constant label table that follows the language: rebuilt from `make` on every read (they are
// tiny), so a language switch needs no reload. Methods are bound to the fresh copy.
const LT = (make) => new Proxy(Array.isArray(make()) ? [] : {}, {
  get: (_, k) => { const o = make(), v = o[k]; return typeof v === "function" ? v.bind(o) : v; },
  has: (_, k) => k in make(),
  ownKeys: () => Reflect.ownKeys(make()),
  getOwnPropertyDescriptor: (_, k) => Object.getOwnPropertyDescriptor(make(), k),
});
async function setLang(lang) {
  const all = window.I18N_ALL || {}, eff = lang || (/^ko/i.test((navigator.languages && navigator.languages[0]) || navigator.language || "") ? "ko" : "en");
  if (!all[eff]) return;
  window.I18N_PICK = lang; window.I18N_LANG = eff; window.I18N = all[eff];
  document.documentElement.lang = eff;
  try { await post("/api/custom/prefs", {lang}); } catch (e) { toast(e.message); }
  try { window.dispatchEvent(new CustomEvent("loop-lang", {detail: eff})); } catch (e) {}
  // Settings redraws in place (render() would send a phone back to the settings menu).
  if (cur === "settings" && !detail) SCREENS.settings(); else render();
  drawChrome();
}
// The compact 한국어 / English switch, shared by the first-run header and 설정 > 일반.
const LANG_NAMES = [["ko", "한국어"], ["en", "English"]];
const langSeg = (cls = "") => `<div class="seg langseg ${cls}" role="group" aria-label="${tl("lang.label")}">`
  + LANG_NAMES.map(([k, n]) => `<button class="press ${LANG() === k ? "on" : ""}" data-lang="${k}" aria-pressed="${LANG() === k}" lang="${k}">${n}</button>`).join("")
  + `</div>`;
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-lang]"); if (b && b.dataset.lang !== LANG()) setLang(b.dataset.lang); });
// Scrollbar auto-hide (desktop only, mouse+hover devices — v2.css .scrolling rules): the thumb is
// transparent at rest and only fades in on hover OR while actively scrolling. Capture-phase listener
// on document catches "scroll" on any descendant even though the event itself doesn't bubble.
{
  const scrollHideT = new WeakMap();
  document.addEventListener("scroll", (e) => {
    const el = e.target === document ? document.documentElement : e.target;
    if (!el || !el.classList) return;
    el.classList.add("scrolling");
    clearTimeout(scrollHideT.get(el));
    scrollHideT.set(el, setTimeout(() => el.classList.remove("scrolling"), 700));
  }, true);
}
// Inside the app's own window (Genok.exe opens /?app=1): offer the same page in the browser.
// The address loses its query further down (and a reload keeps the stripped one), so the window
// remembers it for its own lifetime: without this a reload dropped the window controls and the drag.
// The floating window (/?float=1, web/float.js) is this same page showing only pinned conversations:
// the screens, their shortcuts, the heartbeat and the update check stay with the main window.
// v2.html marks it on <html> before the first paint and keeps that note for the window's lifetime,
// so an address that lost ?float=1 still is the floating window, never the app's screens.
const FLOAT = document.documentElement.classList.contains("float") || new URLSearchParams(location.search).has("float");
// The glass design (kit-d2 + kit-app + the lab layers) is the app; 설정 → 테마 can still pick the
// earlier one, kept as "0" under genok-lab. Read once at start.
const LAB3 = (() => { try { return localStorage.getItem("genok-lab") !== "0"; } catch (e) { return true; } })();
if (LAB3) { document.documentElement.classList.add("lab", "lab2", "lab3"); for (const f of ["/lab.css", "/lab2.css", "/kit-d2.css", "/kit-app.css", "/lab3.css"]) { const k = document.createElement("link"); k.rel = "stylesheet"; k.href = f; document.head.appendChild(k); } }
const IN_APP = (() => {
  if (FLOAT) return false;
  let v = new URLSearchParams(location.search).has("app");
  try { if (v) sessionStorage.setItem("v2-inapp", "1"); else v = sessionStorage.getItem("v2-inapp") === "1"; } catch (e) { /* private window */ }
  return v;
})();
// Which OS the app window runs on, read from the user agent for the first paint (js_api.env() is the
// authoritative copy). Only Windows is frameless and draws its own min/max/close chrome; macOS keeps
// its native title bar (with the traffic lights), so it never draws those buttons. .os-win / .os-mac
// on <html> let the CSS switch, and WINCHROME gates the window controls and the top-row drag.
const OS_MAC = /Mac/i.test(navigator.userAgent);
const OS_WIN = !OS_MAC && /Windows/i.test(navigator.userAgent);
// Last resort: the app's bridge is here but the page does not know it is the app window (the
// address and the note were both lost). Load once more as the app window, so there is always a
// way to move and close it.
if (!IN_APP && !FLOAT) {
  const asApp = () => {
    // The floating window's bridge (floatwin.Api: layout, no set_zoom) is not the app window's:
    // that window goes back to its own page, never to the app's screens.
    const a = window.pywebview && window.pywebview.api;
    if (a && a.layout && !a.set_zoom) return location.replace("/?float=1");
    try { sessionStorage.setItem("v2-inapp", "1"); } catch (e) { return; } location.replace("/?app=1" + location.hash); };
  if (window.pywebview) asApp(); else addEventListener("pywebviewready", asApp, {once: true});
}
if (IN_APP) {
  document.documentElement.classList.add(OS_MAC ? "os-mac" : OS_WIN ? "os-win" : "os-other");
  document.body.classList.add("inapp");
}

// ---------- icons: Phosphor Icons (MIT, regular weight, 256 grid, filled outlines; licenses/phosphor.md) ----------
// Only the glyphs the UI uses are inlined. Keys are ours; the star carries a filled twin (.pg) for the on state.
const P = {
  sync:'<path d="M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z"/>',
  home:'<path d="M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z"/>',
  lib:'<path d="M216,40H72A16,16,0,0,0,56,56V72H40A16,16,0,0,0,24,88V200a16,16,0,0,0,16,16H184a16,16,0,0,0,16-16V184h16a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM72,56H216v62.75l-10.07-10.06a16,16,0,0,0-22.63,0l-20,20-44-44a16,16,0,0,0-22.62,0L72,109.37ZM184,200H40V88H56v80a16,16,0,0,0,16,16H184Zm32-32H72V132l36-36,49.66,49.66a8,8,0,0,0,11.31,0L194.63,120,216,141.38V168ZM160,84a12,12,0,1,1,12,12A12,12,0,0,1,160,84Z"/>',
  people:'<path d="M117.25,157.92a60,60,0,1,0-66.5,0A95.83,95.83,0,0,0,3.53,195.63a8,8,0,1,0,13.4,8.74,80,80,0,0,1,134.14,0,8,8,0,0,0,13.4-8.74A95.83,95.83,0,0,0,117.25,157.92ZM40,108a44,44,0,1,1,44,44A44.05,44.05,0,0,1,40,108Zm210.14,98.7a8,8,0,0,1-11.07-2.33A79.83,79.83,0,0,0,172,168a8,8,0,0,1,0-16,44,44,0,1,0-16.34-84.87,8,8,0,1,1-5.94-14.85,60,60,0,0,1,55.53,105.64,95.83,95.83,0,0,1,47.22,37.71A8,8,0,0,1,250.14,206.7Z"/>',
  chart:'<path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160ZM104,96h40V200H104ZM56,144H88v56H56Z"/>',
  menu:'<path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"/>',
  grid:'<path d="M104,40H56A16,16,0,0,0,40,56v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V56A16,16,0,0,0,104,40Zm0,64H56V56h48v48Zm96-64H152a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V56A16,16,0,0,0,200,40Zm0,64H152V56h48v48Zm-96,32H56a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V152A16,16,0,0,0,104,136Zm0,64H56V152h48v48Zm96-64H152a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V152A16,16,0,0,0,200,136Zm0,64H152V152h48v48Z"/>',
  grip:'<path d="M104,60A12,12,0,1,1,92,48,12,12,0,0,1,104,60Zm60,12a12,12,0,1,0-12-12A12,12,0,0,0,164,72ZM92,116a12,12,0,1,0,12,12A12,12,0,0,0,92,116Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,116ZM92,184a12,12,0,1,0,12,12A12,12,0,0,0,92,184Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,184Z"/>',
  zoomin:'<path d="M152,112a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z"/>',
  zoomout:'<path d="M152,112a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z"/>',
  search:'<path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"/>',
  bell:'<path d="M221.8,175.94C216.25,166.38,208,139.33,208,104a80,80,0,1,0-160,0c0,35.34-8.26,62.38-13.81,71.94A16,16,0,0,0,48,200H88.81a40,40,0,0,0,78.38,0H208a16,16,0,0,0,13.8-24.06ZM128,216a24,24,0,0,1-22.62-16h45.24A24,24,0,0,1,128,216ZM48,184c7.7-13.24,16-43.92,16-80a64,64,0,1,1,128,0c0,36.05,8.28,66.73,16,80Z"/>',
  chev:'<path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z"/>',
  back:'<path d="M165.66,202.34a8,8,0,0,1-11.32,11.32l-80-80a8,8,0,0,1,0-11.32l80-80a8,8,0,0,1,11.32,11.32L91.31,128Z"/>',
  x:'<path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"/>',
  play:'<path d="M232.4,114.49,88.32,26.35a16,16,0,0,0-16.2-.3A15.86,15.86,0,0,0,64,39.87V216.13A15.94,15.94,0,0,0,80,232a16.07,16.07,0,0,0,8.36-2.35L232.4,141.51a15.81,15.81,0,0,0,0-27ZM80,215.94V40l143.83,88Z"/>',
  pause:'<path d="M200,32H160a16,16,0,0,0-16,16V208a16,16,0,0,0,16,16h40a16,16,0,0,0,16-16V48A16,16,0,0,0,200,32Zm0,176H160V48h40ZM96,32H56A16,16,0,0,0,40,48V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V48A16,16,0,0,0,96,32Zm0,176H56V48H96Z"/>',
  pin:'<path d="M128,64a40,40,0,1,0,40,40A40,40,0,0,0,128,64Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,128,128Zm0-112a88.1,88.1,0,0,0-88,88c0,31.4,14.51,64.68,42,96.25a254.19,254.19,0,0,0,41.45,38.3,8,8,0,0,0,9.18,0A254.19,254.19,0,0,0,174,200.25c27.45-31.57,42-64.85,42-96.25A88.1,88.1,0,0,0,128,16Zm0,206c-16.53-13-72-60.75-72-118a72,72,0,0,1,144,0C200,161.23,144.53,209,128,222Z"/>',
  video:'<path d="M251.77,73a8,8,0,0,0-8.21.39L208,97.05V72a16,16,0,0,0-16-16H32A16,16,0,0,0,16,72V184a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V159l35.56,23.71A8,8,0,0,0,248,184a8,8,0,0,0,8-8V80A8,8,0,0,0,251.77,73ZM192,184H32V72H192V184Zm48-22.95-32-21.33V116.28L240,95Z"/>',
  image:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V158.75l-26.07-26.06a16,16,0,0,0-22.63,0l-20,20-44-44a16,16,0,0,0-22.62,0L40,149.37V56ZM40,172l52-52,80,80H40Zm176,28H194.63l-36-36,20-20L216,181.38V200ZM144,100a12,12,0,1,1,12,12A12,12,0,0,1,144,100Z"/>',
  code:'<path d="M69.12,94.15,28.5,128l40.62,33.85a8,8,0,1,1-10.24,12.29l-48-40a8,8,0,0,1,0-12.29l48-40a8,8,0,0,1,10.24,12.3Zm176,27.7-48-40a8,8,0,1,0-10.24,12.3L227.5,128l-40.62,33.85a8,8,0,1,0,10.24,12.29l48-40a8,8,0,0,0,0-12.29ZM162.73,32.48a8,8,0,0,0-10.25,4.79l-64,176a8,8,0,0,0,4.79,10.26A8.14,8.14,0,0,0,96,224a8,8,0,0,0,7.52-5.27l64-176A8,8,0,0,0,162.73,32.48Z"/>',
  doc:'<path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Zm-32-80a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,136Zm0,32a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,168Z"/>',
  link:'<path d="M240,88.23a54.43,54.43,0,0,1-16,37L189.25,160a54.27,54.27,0,0,1-38.63,16h-.05A54.63,54.63,0,0,1,96,119.84a8,8,0,0,1,16,.45A38.62,38.62,0,0,0,150.58,160h0a38.39,38.39,0,0,0,27.31-11.31l34.75-34.75a38.63,38.63,0,0,0-54.63-54.63l-11,11A8,8,0,0,1,135.7,59l11-11A54.65,54.65,0,0,1,224,48,54.86,54.86,0,0,1,240,88.23ZM109,185.66l-11,11A38.41,38.41,0,0,1,70.6,208h0a38.63,38.63,0,0,1-27.29-65.94L78,107.31A38.63,38.63,0,0,1,144,135.71a8,8,0,0,0,16,.45A54.86,54.86,0,0,0,144,96a54.65,54.65,0,0,0-77.27,0L32,130.75A54.62,54.62,0,0,0,70.56,224h0a54.28,54.28,0,0,0,38.64-16l11-11A8,8,0,0,0,109,185.66Z"/>',
  megaphone:'<path d="M248,120a48.05,48.05,0,0,0-48-48H160.2c-2.91-.17-53.62-3.74-101.91-44.24A16,16,0,0,0,32,40V200a16,16,0,0,0,26.29,12.25c37.77-31.68,77-40.76,93.71-43.3v31.72A16,16,0,0,0,159.12,214l11,7.33A16,16,0,0,0,194.5,212l11.77-44.36A48.07,48.07,0,0,0,248,120ZM48,199.93V40h0c42.81,35.91,86.63,45,104,47.24v65.48C134.65,155,90.84,164.07,48,199.93Zm131,8,0,.11-11-7.33V168h21.6ZM200,152H168V88h32a32,32,0,1,1,0,64Z"/>',
  chat:'<path d="M116,128a12,12,0,1,1,12,12A12,12,0,0,1,116,128ZM84,140a12,12,0,1,0-12-12A12,12,0,0,0,84,140Zm88,0a12,12,0,1,0-12-12A12,12,0,0,0,172,140Zm60-76V192a16,16,0,0,1-16,16H83l-32.6,28.16-.09.07A15.89,15.89,0,0,1,40,240a16.13,16.13,0,0,1-6.8-1.52A15.85,15.85,0,0,1,24,224V64A16,16,0,0,1,40,48H216A16,16,0,0,1,232,64ZM40,224h0ZM216,64H40V224l34.77-30A8,8,0,0,1,80,192H216Z"/>',
  rooms:'<path d="M216,80H184V48a16,16,0,0,0-16-16H40A16,16,0,0,0,24,48V176a8,8,0,0,0,13,6.22L72,154V184a16,16,0,0,0,16,16h93.59L219,230.22a8,8,0,0,0,5,1.78,8,8,0,0,0,8-8V96A16,16,0,0,0,216,80ZM66.55,137.78,40,159.25V48H168v88H71.58A8,8,0,0,0,66.55,137.78ZM216,207.25l-26.55-21.47a8,8,0,0,0-5-1.78H88V152h80a16,16,0,0,0,16-16V96h32Z"/>',
  check:'<path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"/>',
  list:'<path d="M80,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H88A8,8,0,0,1,80,64Zm136,56H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Zm0,64H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16ZM44,52A12,12,0,1,0,56,64,12,12,0,0,0,44,52Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,116Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,180Z"/>',
  folder:'<path d="M216,72H131.31L104,44.69A15.86,15.86,0,0,0,92.69,40H40A16,16,0,0,0,24,56V200.62A15.4,15.4,0,0,0,39.38,216H216.89A15.13,15.13,0,0,0,232,200.89V88A16,16,0,0,0,216,72ZM40,56H92.69l16,16H40ZM216,200H40V88H216Z"/>',
  flag:'<path d="M42.76,50A8,8,0,0,0,40,56V224a8,8,0,0,0,16,0V179.77c26.79-21.16,49.87-9.75,76.45,3.41,16.4,8.11,34.06,16.85,53,16.85,13.93,0,28.54-4.75,43.82-18a8,8,0,0,0,2.76-6V56A8,8,0,0,0,218.76,50c-28,24.23-51.72,12.49-79.21-1.12C111.07,34.76,78.78,18.79,42.76,50ZM216,172.25c-26.79,21.16-49.87,9.74-76.45-3.41-25-12.35-52.81-26.13-83.55-8.4V59.79c26.79-21.16,49.87-9.75,76.45,3.4,25,12.35,52.82,26.13,83.55,8.4Z"/>',
  loop:'<path d="M24,128A72.08,72.08,0,0,1,96,56H204.69L194.34,45.66a8,8,0,0,1,11.32-11.32l24,24a8,8,0,0,1,0,11.32l-24,24a8,8,0,0,1-11.32-11.32L204.69,72H96a56.06,56.06,0,0,0-56,56,8,8,0,0,1-16,0Zm200-8a8,8,0,0,0-8,8,56.06,56.06,0,0,1-56,56H51.31l10.35-10.34a8,8,0,0,0-11.32-11.32l-24,24a8,8,0,0,0,0,11.32l24,24a8,8,0,0,0,11.32-11.32L51.31,200H160a72.08,72.08,0,0,0,72-72A8,8,0,0,0,224,120Z"/>',
  gauge:'<path d="M207.06,72.67A111.24,111.24,0,0,0,128,40h-.4C66.07,40.21,16,91,16,153.13V176a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V152A111.25,111.25,0,0,0,207.06,72.67ZM224,176H119.71l54.76-75.3a8,8,0,0,0-12.94-9.42L99.92,176H32V153.13c0-3.08.15-6.12.43-9.13H56a8,8,0,0,0,0-16H35.27c10.32-38.86,44-68.24,84.73-71.66V80a8,8,0,0,0,16,0V56.33A96.14,96.14,0,0,1,221,128H200a8,8,0,0,0,0,16h23.67c.21,2.65.33,5.31.33,8Z"/>',
  server:'<path d="M208,136H48a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,64H48V152H208v48Zm0-160H48A16,16,0,0,0,32,56v48a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V56A16,16,0,0,0,208,40Zm0,64H48V56H208v48ZM192,80a12,12,0,1,1-12-12A12,12,0,0,1,192,80Zm0,96a12,12,0,1,1-12-12A12,12,0,0,1,192,176Z"/>',
  clock:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"/>',
  brain:'<path d="M248,124a56.11,56.11,0,0,0-32-50.61V72a48,48,0,0,0-88-26.49A48,48,0,0,0,40,72v1.39a56,56,0,0,0,0,101.2V176a48,48,0,0,0,88,26.49A48,48,0,0,0,216,176v-1.41A56.09,56.09,0,0,0,248,124ZM88,208a32,32,0,0,1-31.81-28.56A55.87,55.87,0,0,0,64,180h8a8,8,0,0,0,0-16H64A40,40,0,0,1,50.67,86.27,8,8,0,0,0,56,78.73V72a32,32,0,0,1,64,0v68.26A47.8,47.8,0,0,0,88,128a8,8,0,0,0,0,16,32,32,0,0,1,0,64Zm104-44h-8a8,8,0,0,0,0,16h8a55.87,55.87,0,0,0,7.81-.56A32,32,0,1,1,168,144a8,8,0,0,0,0-16,47.8,47.8,0,0,0-32,12.26V72a32,32,0,0,1,64,0v6.73a8,8,0,0,0,5.33,7.54A40,40,0,0,1,192,164Zm16-52a8,8,0,0,1-8,8h-4a36,36,0,0,1-36-36V80a8,8,0,0,1,16,0v4a20,20,0,0,0,20,20h4A8,8,0,0,1,208,112ZM60,120H56a8,8,0,0,1,0-16h4A20,20,0,0,0,80,84V80a8,8,0,0,1,16,0v4A36,36,0,0,1,60,120Z"/>',
  spark:'<path d="M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"/>',
  plug:'<path d="M200,48H136V16a8,8,0,0,0-16,0V48H56A32,32,0,0,0,24,80V192a32,32,0,0,0,32,32H200a32,32,0,0,0,32-32V80A32,32,0,0,0,200,48Zm16,144a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V80A16,16,0,0,1,56,64H200a16,16,0,0,1,16,16Zm-52-56H92a28,28,0,0,0,0,56h72a28,28,0,0,0,0-56Zm-24,16v24H116V152ZM80,164a12,12,0,0,1,12-12h8v24H92A12,12,0,0,1,80,164Zm84,12h-8V152h8a12,12,0,0,1,0,24ZM72,108a12,12,0,1,1,12,12A12,12,0,0,1,72,108Zm88,0a12,12,0,1,1,12,12A12,12,0,0,1,160,108Z"/>',
  book:'<path d="M232,48H160a40,40,0,0,0-32,16A40,40,0,0,0,96,48H24a8,8,0,0,0-8,8V200a8,8,0,0,0,8,8H96a24,24,0,0,1,24,24,8,8,0,0,0,16,0,24,24,0,0,1,24-24h72a8,8,0,0,0,8-8V56A8,8,0,0,0,232,48ZM96,192H32V64H96a24,24,0,0,1,24,24V200A39.81,39.81,0,0,0,96,192Zm128,0H160a39.81,39.81,0,0,0-24,8V88a24,24,0,0,1,24-24h64Z"/>',
  dice:'<path d="M192,32H64A32,32,0,0,0,32,64V192a32,32,0,0,0,32,32H192a32,32,0,0,0,32-32V64A32,32,0,0,0,192,32Zm16,160a16,16,0,0,1-16,16H64a16,16,0,0,1-16-16V64A16,16,0,0,1,64,48H192a16,16,0,0,1,16,16ZM104,92A12,12,0,1,1,92,80,12,12,0,0,1,104,92Zm72,0a12,12,0,1,1-12-12A12,12,0,0,1,176,92Zm-72,72a12,12,0,1,1-12-12A12,12,0,0,1,104,164Zm36-36a12,12,0,1,1-12-12A12,12,0,0,1,140,128Zm36,36a12,12,0,1,1-12-12A12,12,0,0,1,176,164Z"/>',
  swap:'<path d="M213.66,181.66l-32,32a8,8,0,0,1-11.32-11.32L188.69,184H48a8,8,0,0,1,0-16H188.69l-18.35-18.34a8,8,0,0,1,11.32-11.32l32,32A8,8,0,0,1,213.66,181.66Zm-139.32-64a8,8,0,0,0,11.32-11.32L67.31,88H208a8,8,0,0,0,0-16H67.31L85.66,53.66A8,8,0,0,0,74.34,42.34l-32,32a8,8,0,0,0,0,11.32Z"/>',
  pen:'<path d="M227.31,73.37,182.63,28.68a16,16,0,0,0-22.63,0L36.69,152A15.86,15.86,0,0,0,32,163.31V208a16,16,0,0,0,16,16H92.69A15.86,15.86,0,0,0,104,219.31L227.31,96a16,16,0,0,0,0-22.63ZM92.69,208H48V163.31l88-88L180.69,120ZM192,108.68,147.31,64l24-24L216,84.68Z"/>',
  arrow:'<path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/>',
  rect:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,160H40V56H216V200Z"/>',
  ellipse:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Z"/>',
  eraser:'<path d="M225,80.4,183.6,39a24,24,0,0,0-33.94,0L31,157.66a24,24,0,0,0,0,33.94l30.06,30.06A8,8,0,0,0,66.74,224H216a8,8,0,0,0,0-16h-84.7L225,114.34A24,24,0,0,0,225,80.4ZM108.68,208H70.05L42.33,180.28a8,8,0,0,1,0-11.31L96,115.31,148.69,168Zm105-105L160,156.69,107.31,104,161,50.34a8,8,0,0,1,11.32,0l41.38,41.38a8,8,0,0,1,0,11.31Z"/>',
  gear:'<path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm88-29.84q.06-2.16,0-4.32l14.92-18.64a8,8,0,0,0,1.48-7.06,107.21,107.21,0,0,0-10.88-26.25,8,8,0,0,0-6-3.93l-23.72-2.64q-1.48-1.56-3-3L186,40.54a8,8,0,0,0-3.94-6,107.71,107.71,0,0,0-26.25-10.87,8,8,0,0,0-7.06,1.49L130.16,40Q128,40,125.84,40L107.2,25.11a8,8,0,0,0-7.06-1.48A107.6,107.6,0,0,0,73.89,34.51a8,8,0,0,0-3.93,6L67.32,64.27q-1.56,1.49-3,3L40.54,70a8,8,0,0,0-6,3.94,107.71,107.71,0,0,0-10.87,26.25,8,8,0,0,0,1.49,7.06L40,125.84Q40,128,40,130.16L25.11,148.8a8,8,0,0,0-1.48,7.06,107.21,107.21,0,0,0,10.88,26.25,8,8,0,0,0,6,3.93l23.72,2.64q1.49,1.56,3,3L70,215.46a8,8,0,0,0,3.94,6,107.71,107.71,0,0,0,26.25,10.87,8,8,0,0,0,7.06-1.49L125.84,216q2.16.06,4.32,0l18.64,14.92a8,8,0,0,0,7.06,1.48,107.21,107.21,0,0,0,26.25-10.88,8,8,0,0,0,3.93-6l2.64-23.72q1.56-1.48,3-3L215.46,186a8,8,0,0,0,6-3.94,107.71,107.71,0,0,0,10.87-26.25,8,8,0,0,0-1.49-7.06Zm-16.1-6.5a73.93,73.93,0,0,1,0,8.68,8,8,0,0,0,1.74,5.48l14.19,17.73a91.57,91.57,0,0,1-6.23,15L187,173.11a8,8,0,0,0-5.1,2.64,74.11,74.11,0,0,1-6.14,6.14,8,8,0,0,0-2.64,5.1l-2.51,22.58a91.32,91.32,0,0,1-15,6.23l-17.74-14.19a8,8,0,0,0-5-1.75h-.48a73.93,73.93,0,0,1-8.68,0,8,8,0,0,0-5.48,1.74L100.45,215.8a91.57,91.57,0,0,1-15-6.23L82.89,187a8,8,0,0,0-2.64-5.1,74.11,74.11,0,0,1-6.14-6.14,8,8,0,0,0-5.1-2.64L46.43,170.6a91.32,91.32,0,0,1-6.23-15l14.19-17.74a8,8,0,0,0,1.74-5.48,73.93,73.93,0,0,1,0-8.68,8,8,0,0,0-1.74-5.48L40.2,100.45a91.57,91.57,0,0,1,6.23-15L69,82.89a8,8,0,0,0,5.1-2.64,74.11,74.11,0,0,1,6.14-6.14A8,8,0,0,0,82.89,69L85.4,46.43a91.32,91.32,0,0,1,15-6.23l17.74,14.19a8,8,0,0,0,5.48,1.74,73.93,73.93,0,0,1,8.68,0,8,8,0,0,0,5.48-1.74L155.55,40.2a91.57,91.57,0,0,1,15,6.23L173.11,69a8,8,0,0,0,2.64,5.1,74.11,74.11,0,0,1,6.14,6.14,8,8,0,0,0,5.1,2.64l22.58,2.51a91.32,91.32,0,0,1,6.23,15l-14.19,17.74A8,8,0,0,0,199.87,123.66Z"/>',
  warn:'<path d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"/>',
  hub:'<path d="M223.68,66.15,135.68,18h0a15.88,15.88,0,0,0-15.36,0l-88,48.17a16,16,0,0,0-8.32,14v95.64a16,16,0,0,0,8.32,14l88,48.17a15.88,15.88,0,0,0,15.36,0l88-48.17a16,16,0,0,0,8.32-14V80.18A16,16,0,0,0,223.68,66.15ZM128,32h0l80.34,44L128,120,47.66,76ZM40,90l80,43.78v85.79L40,175.82Zm96,129.57V133.82L216,90v85.78Z"/>',
  archive:'<path d="M224,48H32A16,16,0,0,0,16,64V88a16,16,0,0,0,16,16v88a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V104a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM208,192H48V104H208ZM224,88H32V64H224V88ZM96,136a8,8,0,0,1,8-8h48a8,8,0,0,1,0,16H104A8,8,0,0,1,96,136Z"/>',
  minus:'<path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128Z"/>',
  fit:'<path d="M200,80v32a8,8,0,0,1-16,0V88H160a8,8,0,0,1,0-16h32A8,8,0,0,1,200,80ZM96,168H72V144a8,8,0,0,0-16,0v32a8,8,0,0,0,8,8H96a8,8,0,0,0,0-16ZM232,56V200a16,16,0,0,1-16,16H40a16,16,0,0,1-16-16V56A16,16,0,0,1,40,40H216A16,16,0,0,1,232,56ZM216,200V56H40V200H216Z"/>',
  plus:'<path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>',
  stop:'<path d="M200,40H56A16,16,0,0,0,40,56V200a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V56A16,16,0,0,0,200,40Zm0,160H56V56H200V200Z"/>',
  up:'<path d="M205.66,117.66a8,8,0,0,1-11.32,0L136,59.31V216a8,8,0,0,1-16,0V59.31L61.66,117.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,205.66,117.66Z"/>',
  dl:'<path d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"/>',
  ext:'<path d="M224,104a8,8,0,0,1-16,0V59.32l-66.33,66.34a8,8,0,0,1-11.32-11.32L196.68,48H152a8,8,0,0,1,0-16h64a8,8,0,0,1,8,8Zm-40,24a8,8,0,0,0-8,8v72H48V80h72a8,8,0,0,0,0-16H48A16,16,0,0,0,32,80V208a16,16,0,0,0,16,16H176a16,16,0,0,0,16-16V136A8,8,0,0,0,184,128Z"/>',
  more:'<path d="M140,128a12,12,0,1,1-12-12A12,12,0,0,1,140,128Zm56-12a12,12,0,1,0,12,12A12,12,0,0,0,196,116ZM60,116a12,12,0,1,0,12,12A12,12,0,0,0,60,116Z"/>',
  full:'<path d="M216,48V88a8,8,0,0,1-16,0V56H168a8,8,0,0,1,0-16h40A8,8,0,0,1,216,48ZM88,200H56V168a8,8,0,0,0-16,0v40a8,8,0,0,0,8,8H88a8,8,0,0,0,0-16Zm120-40a8,8,0,0,0-8,8v32H168a8,8,0,0,0,0,16h40a8,8,0,0,0,8-8V168A8,8,0,0,0,208,160ZM88,40H48a8,8,0,0,0-8,8V88a8,8,0,0,0,16,0V56H88a8,8,0,0,0,0-16Z"/>',
  star:'<path class="pr" d="M239.18,97.26A16.38,16.38,0,0,0,224.92,86l-59-4.76L143.14,26.15a16.36,16.36,0,0,0-30.27,0L90.11,81.23,31.08,86a16.46,16.46,0,0,0-9.37,28.86l45,38.83L53,211.75a16.38,16.38,0,0,0,24.5,17.82L128,198.49l50.53,31.08A16.4,16.4,0,0,0,203,211.75l-13.76-58.07,45-38.83A16.43,16.43,0,0,0,239.18,97.26Zm-15.34,5.47-48.7,42a8,8,0,0,0-2.56,7.91l14.88,62.8a.37.37,0,0,1-.17.48c-.18.14-.23.11-.38,0l-54.72-33.65a8,8,0,0,0-8.38,0L69.09,215.94c-.15.09-.19.12-.38,0a.37.37,0,0,1-.17-.48l14.88-62.8a8,8,0,0,0-2.56-7.91l-48.7-42c-.12-.1-.23-.19-.13-.5s.18-.27.33-.29l63.92-5.16A8,8,0,0,0,103,91.86l24.62-59.61c.08-.17.11-.25.35-.25s.27.08.35.25L153,91.86a8,8,0,0,0,6.75,4.92l63.92,5.16c.15,0,.24,0,.33.29S224,102.63,223.84,102.73Z"/><path class="pg" d="M234.29,114.85l-45,38.83L203,211.75a16.4,16.4,0,0,1-24.5,17.82L128,198.49,77.47,229.57A16.4,16.4,0,0,1,53,211.75l13.76-58.07-45-38.83A16.46,16.46,0,0,1,31.08,86l59-4.76,22.76-55.08a16.36,16.36,0,0,1,30.27,0l22.75,55.08,59,4.76a16.46,16.46,0,0,1,9.37,28.86Z"/>',
  tool:'<path d="M226.76,69a8,8,0,0,0-12.84-2.88l-40.3,37.19-17.23-3.7-3.7-17.23,37.19-40.3A8,8,0,0,0,187,29.24,72,72,0,0,0,88,96,72.34,72.34,0,0,0,94,124.94L33.79,177c-.15.12-.29.26-.43.39a32,32,0,0,0,45.26,45.26c.13-.13.27-.28.39-.42L131.06,162A72,72,0,0,0,232,96,71.56,71.56,0,0,0,226.76,69ZM160,152a56.14,56.14,0,0,1-27.07-7,8,8,0,0,0-9.92,1.77L67.11,211.51a16,16,0,0,1-22.62-22.62L109.18,133a8,8,0,0,0,1.77-9.93,56,56,0,0,1,58.36-82.31l-31.2,33.81a8,8,0,0,0-1.94,7.1L141.83,108a8,8,0,0,0,6.14,6.14l26.35,5.66a8,8,0,0,0,7.1-1.94l33.81-31.2A56.06,56.06,0,0,1,160,152Z"/>',
  cube:'<path d="M223.68,66.15,135.68,18h0a15.88,15.88,0,0,0-15.36,0l-88,48.17a16,16,0,0,0-8.32,14v95.64a16,16,0,0,0,8.32,14l88,48.17a15.88,15.88,0,0,0,15.36,0l88-48.17a16,16,0,0,0,8.32-14V80.18A16,16,0,0,0,223.68,66.15ZM128,32h0l80.34,44L128,120,47.66,76ZM40,90l80,43.78v85.79L40,175.82Zm96,129.57V133.82L216,90v85.78Z"/>',
  tray:'<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,16V152h-28.7A15.86,15.86,0,0,0,168,156.69L148.69,176H107.31L88,156.69A15.86,15.86,0,0,0,76.69,152H48V48Zm0,160H48V168H76.69L96,187.31A15.86,15.86,0,0,0,107.31,192h41.38A15.86,15.86,0,0,0,160,187.31L179.31,168H208v40Z"/>',
  track:'<path d="M224,128a8,8,0,0,1-8,8H128a8,8,0,0,1,0-16h88A8,8,0,0,1,224,128ZM128,72h88a8,8,0,0,0,0-16H128a8,8,0,0,0,0,16Zm88,112H128a8,8,0,0,0,0,16h88a8,8,0,0,0,0-16ZM82.34,42.34,56,68.69,45.66,58.34A8,8,0,0,0,34.34,69.66l16,16a8,8,0,0,0,11.32,0l32-32A8,8,0,0,0,82.34,42.34Zm0,64L56,132.69,45.66,122.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32,0l32-32a8,8,0,0,0-11.32-11.32Zm0,64L56,196.69,45.66,186.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32,0l32-32a8,8,0,0,0-11.32-11.32Z"/>',
  sidebar:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM40,56H80V200H40ZM216,200H96V56H216V200Z"/>',
  moon:'<path d="M233.54,142.23a8,8,0,0,0-8-2,88.08,88.08,0,0,1-109.8-109.8,8,8,0,0,0-10-10,104.84,104.84,0,0,0-52.91,37A104,104,0,0,0,136,224a103.09,103.09,0,0,0,62.52-20.88,104.84,104.84,0,0,0,37-52.91A8,8,0,0,0,233.54,142.23ZM188.9,190.34A88,88,0,0,1,65.66,67.11a89,89,0,0,1,31.4-26A106,106,0,0,0,96,56,104.11,104.11,0,0,0,200,160a106,106,0,0,0,14.92-1.06A89,89,0,0,1,188.9,190.34Z"/>',
  lock:'<path d="M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"/>',
  shieldCheck:'<path d="M208,40H48A16,16,0,0,0,32,56v56c0,52.72,25.52,84.67,46.93,102.19,23.06,18.86,46,25.26,47,25.53a8,8,0,0,0,4.2,0c1-.27,23.91-6.67,47-25.53C198.48,196.67,224,164.72,224,112V56A16,16,0,0,0,208,40Zm0,72c0,37.07-13.66,67.16-40.6,89.42A129.3,129.3,0,0,1,128,223.62a128.25,128.25,0,0,1-38.92-21.81C61.82,179.51,48,149.3,48,112l0-56,160,0ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"/>',
  bulb:'<path d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Zm-16,0a72,72,0,0,0-73.74-72c-39,.92-70.47,33.39-70.26,72.39a71.65,71.65,0,0,0,27.64,56.3A32,32,0,0,1,96,186v6h64v-6a32.15,32.15,0,0,1,12.47-25.35A71.65,71.65,0,0,0,200,104Zm-16.11-9.34a57.6,57.6,0,0,0-46.56-46.55,8,8,0,0,0-2.66,15.78c16.57,2.79,30.63,16.85,33.44,33.45A8,8,0,0,0,176,104a9,9,0,0,0,1.35-.11A8,8,0,0,0,183.89,94.66Z"/>',
};
const ic = (k, c = "i") => `<svg class="${c}" data-ic="${k}" viewBox="0 0 256 256" aria-hidden="true">${P[k] || P.cube}</svg>`;
// A few Lucide glyphs (ISC, licenses/lucide.md), path data unmodified, drawn as 24-unit strokes.
// Used where an outline reads better than Phosphor's filled shapes: the phone row swipe actions
// and the menu beside [새 세션] (play, folder-plus, pin).
const LU = {
  resume:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/>',
  read:'<path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/>',
  unread:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="1"/>',
  hide:'<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
  end:'<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.77.04"/>',
  play:'<polygon points="6 3 20 12 6 21 6 3"/>',
};
const icl = (k, w = 1.75) => `<svg class="lu" data-ic="${k}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LU[k] || ""}</svg>`;
// Empty-state art from web/motion.js (Fluent Emoji); nothing if that script is missing.
const mEmpty = (m) => window.Motion ? Motion.empty(m) : "";
// The lower part of a video is its own controls (timeline, volume). A drag that starts there
// scrubs the video; paging from there moved the whole stage under the finger instead.
const onControls = (e) => { const v = e.target.closest?.("video"); if (!v) return false;
  const r = v.getBoundingClientRect(); return e.clientY > r.bottom - Math.max(110, r.height * 0.35); };
// Korean particle after a name: jo("여행", "와", "과") -> "여행과". Names end in Hangul, digits
// (v001 reads 일) or Latin; a closing syllable, a digit read with one, or l/m/n takes the second form.
const jo = (w, open, closed) => {
  const c = String(w ?? "").trim().slice(-1), k = c.charCodeAt(0) - 0xAC00;
  const shut = k >= 0 && k < 11172 ? k % 28 !== 0 && !(closed === "으로" && k % 28 === 8)
    : /[013678]/.test(c) ? !(closed === "으로" && /[178]/.test(c)) : /[lmn]/i.test(c) && !(closed === "으로" && /l/i.test(c));
  return LANG() !== "ko" ? w : w + (shut ? closed : open);
};
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
// One line now, the rest on a press: the rest fades in where it stands (no slide). A key keeps it
// open across repaints of the same spot.
const more1Open = new Set();
const more1 = (first, rest, key) => !rest ? first : key && more1Open.has(key) ? `${first} ${rest}`
  : `${first} <button type="button" class="more1 press" aria-expanded="false"${key ? ` data-more1="${esc(key)}"` : ""}>${tl("ui.more1")}</button><span class="more1x" hidden> ${rest}</span>`;
document.addEventListener("click", (e) => {
  const b = e.target.closest && e.target.closest(".more1");
  if (!b) return;
  e.preventDefault(); e.stopPropagation();
  if (b.dataset.more1) more1Open.add(b.dataset.more1);
  const x = b.nextElementSibling, had = document.activeElement === b;
  if (x) x.hidden = false;
  b.hidden = true;
  // Pressed by keyboard, the button took the focus away with it: it goes to the words it opened.
  if (had && x) { x.tabIndex = -1; x.focus({preventScroll: true}); }
}, true);
// The agent's key-colour dot that goes before its name in a label (.agdot in v2.css).
const agDot = (agent) => `<i class="agdot${agent === "codex" ? " cx" : ""}" aria-hidden="true"></i>`;
window.agDot = agDot;
// Legacy wall-clock timestamps belong to the host PC, not the phone's timezone.
const hostDate = (iso) => { const value = String(iso || "");
  if (/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d(?:\.\d+)?)?$/.test(value) && Number.isFinite(window.LOOP_SERVER_OFFSET))
    return new Date(Date.parse(value + "Z") - window.LOOP_SERVER_OFFSET * 6e4);
  return new Date(iso); };
window.hostDate = hostDate;
const ago = (iso) => { if (!iso) return tl("ago.1"); const d = hostDate(iso), m = (Date.now() - d) / 6e4;
  if (!Number.isFinite(m)) return tl("ago.1");
  return m < 1 ? tl("ago.2") : m < 60 ? tl("ago.3", {p0: Math.round(m)}) : m < 1440 ? tl("ago.4", {p0: Math.round(m/60)}) : m < 1440*30 ? tl("ago.5", {p0: Math.round(m/1440)}) : d.toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR",{month:"long",day:"numeric"}); };
// Refresh timestamps without repainting the comment text or disrupting text selection.
setInterval(() => document.querySelectorAll("[data-note-at]").forEach((el) => {
  const text = ago(el.dataset.noteAt); if (el.textContent !== text) el.textContent = text;
}), 20000);
const day = (iso) => { const d = hostDate(iso), t = new Date(); const diff = Math.floor((new Date(t.toDateString()) - new Date(d.toDateString())) / 864e5);
  return diff <= 0 ? tl("day.1") : diff === 1 ? tl("day.2") : d.toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR",{month:"long",day:"numeric"}); };
const hm = (iso) => iso ? hostDate(iso).toLocaleTimeString(LANG() === "en" ? "en-US" : "ko-KR", {hour:"numeric", minute:"2-digit"}) : "";
// Item-level due date (Frame.io식 마감일 필드, §4.15): "YYYY-MM-DD" -> {days, label, over}.
const dueInfo = (due) => { if (!due) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(due + "T00:00:00"); if (isNaN(d)) return null;
  const days = Math.round((d - today) / 864e5);
  const label = days === 0 ? tl("itemView.170") : days === 1 ? tl("itemView.171")
    : days > 1 ? tl("itemView.172", {n: days}) : tl("itemView.173", {n: -days});
  return {days, label, over: days < 0}; };
const base = (p) => String(p || "").split(/[\\/]/).filter(Boolean).pop() || p || "";

// markdown.js builds DOM with h(); this is the same small helper the classic page has.
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) el.append(k.nodeType ? k : String(k));
  return el;
}

const STATUS_T = LT(() => ({pending:tl("STATUS_T.1"), changes:tl("STATUS_T.2"), hold:tl("STATUS_T.3"), approved:tl("STATUS_T.4")}));
// A background job says what it is doing; only a terminal session is judged by how fresh
// its file is. "Linked to the desktop app" used to count as working, so every connected
// session read 작업 중 for ever.
const JOB_S = {working: "work", blocked: "ask", done: "idle", idle: "idle", stopped: "idle"};
const state = (r) => r.stuck ? "stuck" : !r.active ? "off" : r.job && JOB_S[r.job] ? JOB_S[r.job]
  : (Date.now() - new Date(r.active)) < 3*60e3 ? "work" : "idle";
const KIND = {video:["video","purple"], image:["image","blue"], html:["code","teal"], text:["doc","grey"], link:["link","green"], code:["code","teal"], diff:["code","green"], doc:["doc","grey"], sheet:["list","green"]};
// An <img> with a loading state: pulses until it loads, fades in, and falls back quietly on error.
// A picture this page has already shown is drawn again without the pulse and the fade: a list
// that redraws itself (the 30s round, the live watch) would otherwise blink every thumbnail.
const imgSeen = new Set();
function imgIn(im) { const k = im.getAttribute("src"), was = imgSeen.has(k); imgSeen.add(k); im.classList.remove("loading"); if (!was) im.classList.add("imgin"); }
const imgTag = (url, {alt = "", lazy = true, drag = true, keep = false} = {}) =>
  `<img class="${imgSeen.has(url) ? "" : "loading"}" src="${esc(url)}" alt="${esc(alt)}"${lazy ? ` loading="lazy"` : ""}${drag ? "" : ` draggable="false"`} onload="imgIn(this)" onerror="${keep ? "this.classList.remove('loading');this.classList.add('bad')" : "this.remove()"}">`;
const thumb = (it, cls = "ico") => {
  const [k, c] = KIND[it.kind] || ["doc","grey"];
  return `<span class="${cls} c-${c}">${ic(k)}${it.thumb ? imgTag(it.thumb) : ""}${it.thumb && it.kind === "video" ? `<span class="play">${ic("play","i f")}</span>` : ""}</span>`;
};
const deptIco = (r, cls = "ico") => `<span class="${cls}">${r.icon ? esc(r.icon) : ic("folder")}</span>`;
const justIn = (x) => x.at && Date.now() - new Date(x.at) < 15 * 6e4;
const byAt = (a, b) => (b.at || "").localeCompare(a.at || "");
// Answered questions hand the item back to its department, so it leaves 확인 필요.
// Sent comments do the same: the person has said their piece, whether or not the session took it yet.
// Which of 전달 대기 / 작업 중 / 멈춤 the session's turn is on is told in status.js.
const turnOf = (x) => stTurn(x);
// Where each result stands is decided in one place (status.js stKind); this only keeps the answer
// per loaded list, per minute (a kind can turn on the clock alone), and feeds it which sessions
// are waiting on the reader (attention rooms).
let flowMemo = {of: null, m: new Map()};
const stAsking = () => stWaits(attL("rooms"));
function stJ(x) {
  const of = D.items, at = Math.floor(Date.now() / 6e4), sig = JSON.stringify(stAsking()?.said || {});
  if (flowMemo.of !== of || flowMemo.at !== at || flowMemo.sig !== sig) flowMemo = {of, at, sig, m: new Map(), lead: stLeads(of, Date.now())};
  if (!flowMemo.m.has(x)) flowMemo.m.set(x, stJudge(x, Date.now(), stAsking(), flowMemo.lead));
  return flowMemo.m.get(x);
}
const stK = (x) => stJ(x).kind;
// The saved views' smart filters (views.js) still read the older names.
const flowOf = (x) => ({work: "work", ask: "ask", undelivered: "unread", queued: "unread", stalled: "quiet", old: "old", done: "done"})[stK(x)] || "";
const ST_NAME = LT(() => ({check: tl("st.reply"), ask: tl("st.ask"), undelivered: tl("st.undelivered"), queued: tl("st.undelivered"), work: tl("st.work"), stalled: tl("SESS_T.2"),
  done: tl("st.done"), old: tl("st.old"), hold: tl("STATUS_T.3"), approved: tl("STATUS_T.4"), finished: tl("st.finished")}));
const ST_TABN = LT(() => ({all: tl("libDraw.1"), fresh: tl("st.fresh"), pending: tl("st.reply"), undelivered: tl("st.undelivered"), changes: tl("st.work"), stalled: tl("SESS_T.2"),
  finished: tl("st.finished")}));
const ST_NONE = LT(() => ({all: tl("libDraw.19"), fresh: tl("st.none.fresh"), pending: tl("st.none.pending"), undelivered: tl("st.none.undelivered"), changes: tl("st.none.work"), stalled: tl("st.none.stalled"),
  finished: tl("st.none.finished")}));
// What each list holds, in one line: shown under the strip, so it never hides behind a hover.
const ST_HINT = LT(() => ({fresh: tl("st.hint.fresh"), pending: tl("st.hint.pending"), undelivered: tl("st.hint.undelivered"), changes: tl("st.hint.work"), stalled: tl("st.hint.stalled"),
  finished: tl("st.hint.finished")}));
const stNone = (k) => `<p>${ST_NONE[k]}</p>`;
// An empty list still offers the next step: the sample while there are no results at all, the
// whole list when only this tab is empty.
const stNext = (k) => { const n = k === "fresh" ? D.items.filter((x) => stOf(x) === "pending" && !libHide.has(iid(x))).length : 0;
  return !D.items.length ? `<p class="act"><button class="btn press" data-ob-sample="add">${tl("onboard.sampleadd")}</button></p>`
  : n ? `<p class="act"><button class="btn press" data-lib="pending">${tl("st.next.reply", {n})}</button></p>`
  : k !== "all" ? `<p class="act"><button class="btn press" data-lib="all">${tl("keybar.all")}</button></p>` : ""; };
// Why a result is where it is, in one line, from the fact the classifier decided on: the chip's
// tooltip on a PC, and the line a tap on the item's chip opens on a phone.
const ST_Y = LT(() => ({new: tl("st.y.new"), seen: tl("st.y.seen"), asked: tl("st.y.asked"), blocked: tl("st.y.blocked"), nosess: tl("st.y.nosess"), unread: tl("st.y.unread"),
  unread_gone: tl("st.y.unread_gone"), unread_old: tl("st.y.unread_old"), has: tl("st.y.has"), later: tl("st.y.later"), read: tl("st.y.read"), fresh: tl("st.y.fresh"), resting: tl("st.y.resting"),
  rested: tl("st.y.rested"), gone: tl("st.y.gone"), quiet: tl("st.y.quiet"), mine: tl("st.y.mine"), noclock: tl("st.y.noclock"), answer: tl("st.y.answer"), go: tl("st.y.go"),
  settled: tl("st.y.settled"), old: tl("st.y.old"), hold: tl("st.y.hold"), finished: tl("st.y.finished")}));
const stSpan = (ms) => { const m = Math.max(1, Math.round(ms / 6e4)); return m < 60 ? tl("st.span.m", {n: m}) : m < 1440 ? tl("st.span.h", {n: Math.round(m / 60)}) : tl("st.span.d", {n: Math.round(m / 1440)}); };
const stWhy = (x) => { const j = stJ(x), s = (j.again ? tl("st.y.again") + " · " : "") + (ST_Y[j.why] || ""); return s.split(" · ").filter((part) => j.since || !part.includes("{t}")).join(" · ").replace("{t}", j.since ? stSpan(Date.now() - j.since) : "").replace("{n}", x.asked || ""); };
const stTip = (x) => { const w = stWhy(x); return w ? ` title="${esc(w)}"` : ""; };
// The list a result is filed under (the tab key), its chip words, and the chip's colour: blue when
// the move is mine, orange for 멈춤 alone (the one that needs a nudge), plain for everything else.
const stOf = (x) => stTab(stK(x), x);
// Mine to answer: the two lists 내 차례 is made of (새로 온 것 + 답할 것).
const stMine = (x) => ST_MINE.includes(stOf(x));
const stName = (x) => stOf(x) === "fresh" && stK(x) === "check" ? tl("st.fresh") : ST_NAME[stK(x)] || "";
const stCls = (x) => { const k = stK(x); return k === "check" || k === "ask" ? "pending" : k === "stalled" ? "changes" : k === "approved" ? "approved" : "quiet"; };
// The status strip of the lists: every list always there, in one order, with its count (an empty
// one only dims), so "is there anything for me" is answered by a 0 and not by a missing tab.
// A thin rule sets apart whose move it is: mine | a session's | over. 전체 is the sum of them and
// sits at the end as a quiet control, not as a list among the lists. An empty list drops its hint line:
// its empty card says it in one line (신규가 없어요), not two. The counts come from the
// same memoised judge the cards use (stOf), so a count and its list can never disagree.
function stTabs(xs, sel, attr) {
  const n = {all: xs.length}; ST_MAIN.forEach((k) => { n[k] = 0; }); xs.forEach((x) => { n[stOf(x)]++; });
  const one = (k, c = "") => `<button class="press${c}${sel === k ? " on" : ""}${n[k] ? "" : " zero"}" role="tab" aria-selected="${sel === k}" data-${attr}="${k}">${ST_TABN[k]} <em class="num">${n[k]}</em></button>`;
  return `<div class="lstatw"><div class="lstat" data-sk="${attr}f" role="tablist">${ST_MAIN.map((k) => one(k, k === "undelivered" || k === ST_DONE ? " fin" : "")).join("")}${one("all", " all")}</div></div>${ST_HINT[sel] && n[sel] ? `<p class="lsub">${ST_HINT[sel]}</p>` : ""}`;
}
// The strip scrolls sideways on a narrow screen: a fade on the side that has more, the open tab in
// view, and the scroll kept where it was across a redraw.
const stScroll = {};
function stStrip(root) {
  const el = root && root.querySelector(".lstat"); if (!el) return;
  const k = el.dataset.sk, w = el.parentNode;
  const fade = () => { w.classList.toggle("fl", el.scrollLeft > 2); w.classList.toggle("fr", el.scrollLeft + el.clientWidth < el.scrollWidth - 2); stScroll[k] = el.scrollLeft; };
  el.scrollLeft = stScroll[k] || 0;
  const on = el.querySelector(".on");
  if (on && (on.offsetLeft < el.scrollLeft || on.offsetLeft + on.offsetWidth > el.scrollLeft + el.clientWidth)) el.scrollLeft = Math.max(0, on.offsetLeft - 24);
  el.addEventListener("scroll", fade, {passive: true}); fade();
}
const handed = (e) => !!(e.sent || e.delivered || e.ack);
const NOTE_T = LT(() => ({ack: [tl("NOTE_T.1"), "var(--green)"], sent: [tl("NOTE_T.2"), ""], unsent: [tl("NOTE_T.3"), "var(--orange)"]}));
const noteTag = (x) => { const n = NOTE_T[x.note]; return n ? ` · <span style="white-space:nowrap${n[1] ? `;color:${n[1]}` : ""}">${n[0]}</span>` : ""; };
// 나중에 (Linear's snooze): a result put aside leaves 내 차례 until its time, or sooner when a
// version other than the one it was put aside at arrives.
const snoozeOf = (x) => { const e = (D.snooze || {})[iid(x)]; return e && e.until * 1000 > Date.now() && (!e.v || e.v === x.v) ? e : null; };
// 내 차례 is exactly 새로 온 것 + 답할 것 (one rule, stMine): a version handed on unopened is not mine again.
// 나중에 보기 has no time: the row is put aside until something new happens on it. A result
// comes back with its next version (e.v); any other row of 할 일 with the mark it stood on (e.mark:
// the tool call a session waits on, a routine's last run). Same store as the timed snooze.
const SNZ_OPEN = 4102444800;              // 2100-01-01: "no time" in the store's epoch seconds
const asideOf = (key, mark) => { const e = (D.snooze || {})[key]; return e && e.until * 1000 > Date.now() && (e.mark == null || e.mark === mark) ? e : null; };
const myTurn = () => D.items.filter((x) => stMine(x) && !snoozeOf(x) && !libHide.has(iid(x))).sort(byAt);
const iid = (x) => x.project + "/" + x.id;
// The one name an item is filed and shown under (views.js groupName). "부서" is a team-mode idea
// only (user rule), so a folder's items never scatter across dept names outside 팀 모드. Used by
// the rail, the project/부서 page, the chips, the lib grouping and the compare column alike.
const teamMode = () => document.documentElement.dataset.unit === "dept";
const gname = (x) => groupName(x, teamMode());
// What a project is called on screen: the display name a person gave it, else its real name.
// The real name stays the key everywhere (routes, data-dept, pins), so a rename breaks no link.
// Results pushed from a group's rooms are filed under the group's name, so that name follows the
// group's display name too.
// A project's mark: the styled icon it was given (web/icons.js), else its emoji.
const identFace = (n, emoji) => (window.LOOP_ICONS ? LOOP_ICONS.face(D.ident?.[n]?.icon, emoji) : esc(emoji || ""));
// The sample's folder is named 샘플 on disk (onboard.py SAMPLE_PROJECT); it reads in the page's language.
const pname = (n) => { const i = D.ident?.[n]?.name, r = (i && i !== n ? i : D.gident?.[n]?.name) || i; return r && r !== n ? r : n === "샘플" ? tl("onboard.sampleProj") : n; };
// The same for a group (묶음): the register keeps its own name, the screens show this one.
const gpname = (g) => D.gident?.[g]?.name || g;
// The 사용 방식 knobs (web/custom.js LOOP_PREF; undefined until the options load): the sidebar
// titles the person renamed, and the word for what results are filed under (프로젝트 / 부서).
const knob = (k) => window.LOOP_PREF?.(k);
const prefName = (k) => (knob("names") || {})[k] || "";
const unitWord = () => unitCustom() || tl("ui.projects");
// ---------- menus: every one of the 21 stays reachable from 전체 ----------
// Tabs are what gets done most: see what's new, check results, talk, look at departments.
// 대화 took 알림's place on the phone (2026-10): what waits on me is the bell's, as on a PC.
const TABS = LT(() => ([["home",tl("ui.nav.home"),"home"],["project",tl("menu.chat"),"chat"],["lib",tl("TABS.3"),"lib"],["all",tl("all.tab"),"menu"]]));
// 알림 (#inbox: 할 일 · 소식 · 기록) has no menu row and no phone tab: the bell in the top bar is its
// one way in on every width. Its address, G I and old favourites/links still open it.
const MENUS = LT(() => ([
  {g:tl("MENUS.1"), k:"home", n:tl("ui.nav.home"), i:"home", c:"blue", d:tl("ui.nav.home.d")},
  {g:tl("MENUS.1"), k:"lib", n:tl("TABS.3"), i:"lib", c:"purple", d:tl("MENUS.4")},
  {g:tl("MENUS.1"), k:"project", n:tl("menu.chat"), i:"chat", c:"green", d:tl("menu.chat.d")},
  {g:tl("MENUS.1"), k:"depts", n:unitWord(), i:"folders", c:"teal", d:tl("menu.depts.d")},
  {g:tl("MENUS.1"), k:"routines", n:tl("routines.nav"), i:"clock", c:"orange", d:tl("routines.d")},
  {g:tl("MENUS.1"), k:"retro", n:tl("retro.nav"), i:"flag", c:"purple", d:tl("retro.d")},
  {g:tl("MENUS.1"), k:"search", n:tl("MENUS.5"), i:"search", c:"grey", d:tl("MENUS.6")},
  {g:tl("MENUS.1"), k:"settings", n:tl("TABS.4"), i:"gear", c:"grey", d:tl("MENUS.7")},
]));
// What to look at on each page, in one line; shown under 설정 as the manual.
const MANUAL = LT(() => ({
  home: tl("ui.nav.home.d"),
  inbox: tl("MANUAL.1"),
  dept: tl("MANUAL.2", {u: unitWord()}),
  lib: tl("MANUAL.3"),
  project: tl("menu.chat.d"),
  routines: tl("routines.d"),
  retro: tl("retro.d"),
  depts: tl("MANUAL.depts"),
  search: tl("MANUAL.4"),
  settings: tl("MANUAL.5"),
}));
// Pages folded into 받은함 keep working: old links, G keys, favourites and number keys that
// still name them land on the matching section.
const ALIAS = {mission: "inbox", alerts: "inbox/news", tasks: "inbox/log"};
// Four menus became two (2026-10): 모든 대화 is a tab of 대화, and the project list page gave its
// row to 프로젝트. The addresses #sessions and #dept still open their own screens; only the menu
// key moved, so a saved favourite, a number key or the sidebar highlight lands on the new row.
// 용량 (#storage) is a tab of 결과물 the same way: its own address, no row of its own.
const MOVED = {sessions: "project", dept: "depts", storage: "lib", board: "lib"};
const menuKey = (k) => { const a = (ALIAS[k] || k).split("/")[0]; return MOVED[a] || a; };
// The two tabs of 대화: 프로젝트별 (#project) and 최근 순 (#sessions). Drawn by both screens.
const chatTabs = (at) => `<div class="seg chtabs" role="tablist" aria-label="${esc(tl("menu.chat"))}">${[["project", tl("menu.chat.rooms")], ["sessions", tl("menu.sessions")]].map(([k, n]) =>
  `<button class="press ${k === at ? "on" : ""}" role="tab" aria-selected="${k === at}" data-go="${k}">${esc(n)}</button>`).join("")}</div>`;
const M = (k) => MENUS.find((m) => m.k === menuKey(k));
const menuIco = (m, cls = "ico") => `<span class="${cls} c-${m.c}">${ic(m.i)}</span>`;

// ---------- data ----------
// A dropped link (Tailscale asleep, Wi-Fi gone) read as the browser's English "Failed to fetch".
const netErr = () => Object.assign(new Error(tl("netErr.1")), {net: true});
// A server error in the page's language; `raw` keeps the server's own words for code that compares them.
// The server's own sentences are Korean. Anything else in its error (an exception's name, a
// proxy's words) says nothing to a person: the plain line is shown, the raw text is kept on .raw.
const srvSaid = (t) => typeof t === "string" && /[가-힣]/.test(t);
const srvErr = (t) => Object.assign(new Error((srvSaid(t) && srvT(t)) || tl("get.1")), {raw: t || ""});
const get = (p) => fetch(p, {cache:"no-store"}).catch(() => { throw netErr(); }).then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) throw srvErr(j.error); return j; });
const post = (p, body) => fetch(p, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)})
  .catch(() => { throw netErr(); }).then(async (r) => { const j = await r.json().catch(() => ({}));
    // The status and body ride on the error so a 409 {conflict} can be shown, not just toasted.
    if (!r.ok) throw Object.assign(srvErr(j.error), {status: r.status, body: j}); return j; });
// A 409 from an approval or a 맞아/아직: the review moved on while the reader was looking.
// What changed is listed in a calm sheet (or inline, inside the compare workspace) and the
// reader decides again - nothing is retried behind their back.
const isConflict = (e) => e && e.status === 409;
// changed: [{id, kind, v}] - the log entries written after the rev the screen read. With the
// item's log at hand each one shows its own words; without it, a short kind label.
function conflictHtml(body, v, log) {
  const b = body || {}, ch = Array.isArray(b.changed) ? b.changed : [];
  const said = (id) => { const e = id && (log || []).find((x) => x.id === id);
    return e?.text ? e.text.replace(/^\[[^\]]*\]\s*/, "") : ""; };
  const line = (c) => typeof c === "string" ? esc(c)
    : esc([c.v, c.text || c.summary || c.label || said(c.id) || (c.kind === "comment" ? tl("conflict.k_comment") : tl("conflict.k_other"))]
      .filter(Boolean).join(" · ").split(/\s+/).join(" ").slice(0, 120));
  const newer = b.latest && v && b.latest !== v;
  const rows = [newer && `<li class="cfnew">${tl("conflict.newer", {v: esc(b.latest)})}</li>`].concat(ch.slice(0, 6).map((c) => `<li>${line(c)}</li>`)).filter(Boolean);
  if (ch.length > 6) rows.push(`<li class="cfmore">${tl("conflict.more", {n: ch.length - 6})}</li>`);
  return `<div class="cfx" role="alert"><b class="cft">${tl("conflict.title")}</b><p class="cfs">${b.conflict ? esc(b.error || "") || tl("conflict.sub") : tl("conflict.norev")}</p>${rows.length ? `<ul class="cfl">${rows.join("")}</ul>` : ""}</div>`;
}
// opts: {v, log?, again: label of the re-decide button or null, retry(body) => Promise, reload(),
// can?(body): whether deciding again on the same screen still makes sense (default: no newer version)}
function conflictSheet(body, opts) {
  const b = body || {}, can = !!(b.conflict && opts.retry && (opts.can ? opts.can(b) : !b.stale && (!b.latest || b.latest === opts.v)));
  sheet(`<h3>${tl("conflict.h")}</h3>${conflictHtml(b, opts.v, opts.log)}
    <button class="btn xl fill press" id="cfre">${tl("conflict.reload")}</button>${can ? `<button class="btn xl press" id="cfgo" style="margin-top:8px">${esc(opts.again)}</button>` : ""}`, (el) => {
    el.querySelector("#cfre").onclick = () => { closeSheet(); opts.reload(); };
    const g = el.querySelector("#cfgo");
    if (g) g.onclick = async () => { g.disabled = true;
      try { await opts.retry(b); closeSheet(); }
      catch (e) { if (isConflict(e)) conflictSheet(e.body, opts); else { toast(e.message); g.disabled = false; } } };
  });
}
// A press by keyboard that redraws the screen (a chip, a tab, a fold, "more") removed the very button that was pressed,
// and focus fell to <body>: the next Tab started from the top of the page. For two seconds after Enter or Space the
// button's twin in the new drawing takes the focus back, unless focus has gone somewhere of its own accord.
let kfStop = null;
addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const a = document.activeElement, view = document.getElementById("view");
  if (!a || !view || !view.contains(a) || !a.matches("button,[role=button],[role=tab],[role=radio],[role=switch]")) return;
  if (kfStop) kfStop();
  const tag = a.tagName, id = a.id, ds = JSON.stringify(a.dataset), tx = (a.textContent || "").trim();
  const same = (x) => (id ? x.id === id : ds !== "{}" ? JSON.stringify(x.dataset) === ds : (x.textContent || "").trim() === tx);
  const nth = [...view.querySelectorAll(tag)].filter(same).indexOf(a);
  const back = () => {
    if (a.isConnected || document.activeElement !== document.body) return;
    const twins = [...view.querySelectorAll(tag)].filter(same), t = twins[nth] || twins[0];
    if (t) t.focus({preventScroll: true});
  };
  const mo = new MutationObserver(back); mo.observe(view, {childList: true, subtree: true});
  const tm = setTimeout(() => kfStop && kfStop(), 2000);
  const stop = () => { mo.disconnect(); clearTimeout(tm); removeEventListener("pointerdown", stop, true); kfStop = null; };
  kfStop = stop; addEventListener("pointerdown", stop, true);
}, true);

// Offline, the screen kept showing the last lists as if they were live. Say so, with a way back.
let lostMsg = "";
function netBar(on, srv) {
  let b = document.getElementById("netbar");
  if (!on) { b?.remove(); return; }
  lostMsg = srv ? tl("netBar.4") : tl("netBar.1");
  if (b) { b.firstElementChild.textContent = lostMsg; return; }
  b = document.createElement("div"); b.id = "netbar"; b.className = "netbar"; b.setAttribute("role", "status");
  b.innerHTML = `<span>${esc(lostMsg)}</span><button class="press">${tl("netBar.2")}</button>`;
  document.body.appendChild(b);
  const btn = b.querySelector("button");
  btn.onclick = async () => { btn.disabled = true; await load();
    if (!document.getElementById("netbar")) { toast(tl("netBar.3")); render(); } else btn.disabled = false; };
}
let loadLost = false;                       // the last load brought nothing: the top bar says so
async function load() {
  let lost = false, down = false;
  // A 500 on the two lists is as stale as no network: an old copy must not pass for a fresh sync.
  // A 200 that is not a list (a proxy's page, a half-written answer) is no answer either.
  const core = (p, d) => get(p).then((j) => { if (!Array.isArray(j)) throw srvErr(); return j; }).catch((e) => { lost = true; if (!e.net) down = true; return d; });
  const soft = (p, d) => get(p).catch((e) => { if (e.net) lost = true; return d; });
  // The identity map (a person's own display name for a project) rides along; it is optional, so
  // a miss keeps the last copy and never marks the load as lost.
  const [board, items, pf, cu] = await Promise.all([
    core("/api/board", D.board), core("/api/items", D.items), soft("/api/prefs", {}),
    get("/api/custom").catch(() => null)]);
  netBar(lost, down);
  // Nothing came: keep the old time, so "n분 전 동기화" does not claim a fresh copy.
  loadLost = lost;
  // One list of the two came: it is kept (the other stays as it was), the time is not moved.
  if (lost) { D = {...D, board, items}; return false; }
  D = {...D, board, items, ident: cu?.identity || D.ident || {}, gident: cu?.group_names || D.gident || {}, pins: pf.pins || D.pins || [], hidden: pf.hidden_projects || D.hidden || [], shelved: pf.shelved || D.shelved || [], placeNums: pf.place_nums || D.placeNums || {}, favs: pf.favs !== undefined ? pf.favs : D.favs, keys: pf.keys || D.keys || {}, snooze: pf.snooze || D.snooze || {}, room_read: pf.room_read || D.room_read || {}, seen_at: pf.seen_at || D.seen_at || "", profile_name: pf.profile_name !== undefined ? pf.profile_name : D.profile_name, fb: pf.feedback_url !== undefined ? pf.feedback_url : D.fb, fbEn: pf.feedback_url_en !== undefined ? pf.feedback_url_en : D.fbEn, fbImg: pf.feedback_images !== undefined ? !!pf.feedback_images : !!D.fbImg, at: new Date().toISOString()};
  if ((pf.alerts_seen || "") > alertsSeen) seeAlerts(pf.alerts_seen, false);   // read on the other device
  if (pf.news_read?.some((k) => !newsRead.has(k))) readNews(pf.news_read, false);
  try { localStorage.setItem("v2-cache", JSON.stringify({board, items, pins: D.pins, favs: D.favs, keys: D.keys, fb: D.fb, fbEn: D.fbEn, at: D.at})); } catch {}
  return true;
}

// ---------- routing: the hash is the page, so reload and the phone's back button both work ----------
// #inbox · #lib · #item/<p/i> · #dept/<key> · #settings
let cur = "inbox", detail = null, libF = "", libFAuto = true, libD = "", libQ = "", libK = "", libSel = null, ovT = "sum", ovR = "all", dayP = 0, acctSel = "a", dismissed = false, retroWk = 0;
const V = () => document.getElementById("view");
// One result to the next (다음, after 승인, N, a link inside a result) takes the place of the one on
// screen instead of stacking on it, so back leaves to the list it was opened from - not to the
// result before.
const nav = (hash) => { if (location.hash.slice(1) === hash) return render();
  if (hash.startsWith("item/") && location.hash.startsWith("#item/")) { history.replaceState(null, "", "#" + hash); return void dispatchEvent(new HashChangeEvent("hashchange")); }
  location.hash = hash; };
// Which layout: by device, not by width alone (as Slack, Linear and VS Code do - a narrow window on a
// PC keeps its menu and title bar, it does not become a phone). Phone layout: 720px and under, or a
// touch screen under 1024px. A mouse from 721px gets the desktop layout; under 1024px that is the
// compact one (menu folded to its icons, panels folded). The CSS reads the same condition.
const WIDE_Q = "(min-width:1024px),(min-width:721px) and (pointer:fine)";
const layoutOf = (w, fine) => w >= 1024 ? "wide" : w >= 721 && fine ? "compact" : "phone";
const wide = () => { try { return matchMedia(WIDE_Q).matches; } catch (e) { return layoutOf(innerWidth, false) !== "phone"; } };
const compact = () => wide() && layoutOf(innerWidth, true) === "compact";
// Many files under the stage pushed the comment box off a phone screen: the thumbs fold into
// one scrolling strip, open by default only on a PC, and the last choice is kept.
function sgOpen(set) {
  try { if (set !== undefined) localStorage.setItem("sgOpen", set ? "1" : "0"); const v = localStorage.getItem("sgOpen"); if (v) return v === "1"; } catch (e) {}
  return wide();
}
// Keep the thumb on the stage in sight inside the folded strip, without moving the page.
function sgShow() {
  const g = document.querySelector("#sgrid .sg.on"), r = g?.parentElement;
  if (!g || document.getElementById("sgw")?.classList.contains("open")) return;
  r.scrollTo({left: g.offsetLeft - (r.clientWidth - g.offsetWidth) / 2, behavior: RM() ? "auto" : "smooth"});
}

// ---------- refresh without a blank (stale-while-revalidate) ----------
// A redraw of the screen that is already open (the 30s round, the live watch, the refresh
// button) used to rebuild #view from nothing: the entry fade started every child at opacity 0,
// extension screens cleared themselves and drew "loading" before their fetch answered, and the
// page jumped to the top. Now the shown content stays until the new one is ready, it is swapped
// in one step, and scroll, open folds and focus are put back. First loads are untouched.
let softN = 0, viewGen = 0;                  // softN>0 while a refresh redraw runs; viewGen counts real navigations
const innerDesc = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML");
const innerSet = innerDesc.set;
const FOCUSABLE = "button,a,input,textarea,gk-select,summary,[tabindex]";
function viewState(root = V()) {
  const a = document.activeElement, all = [...root.querySelectorAll(FOCUSABLE)], fi = a && root.contains(a) ? all.indexOf(a) : -1;
  return {y: scrollY, fi, tag: fi >= 0 ? a.tagName : "", sel: fi >= 0 && typeof a.selectionStart === "number" ? [a.selectionStart, a.selectionEnd] : null,
    open: [...root.querySelectorAll("details")].map((d) => d.open),
    inner: [...root.querySelectorAll("*")].map((e, i) => (e.scrollTop || e.scrollLeft) ? [i, e.tagName, e.scrollTop, e.scrollLeft] : null).filter(Boolean)};
}
function restoreView(st, root = V()) {
  const ds = [...root.querySelectorAll("details")];
  if (ds.length === st.open.length) ds.forEach((d, i) => { if (d.open !== st.open[i]) d.open = st.open[i]; });
  if (st.inner.length) { const all = root.querySelectorAll("*"); st.inner.forEach(([i, tag, top, left]) => { const e = all[i]; if (e && e.tagName === tag) { e.scrollTop = top; e.scrollLeft = left; } }); }
  if (scrollY !== st.y) scrollTo(0, st.y);
  if (st.fi >= 0 && !root.contains(document.activeElement)) {
    const e = [...root.querySelectorAll(FOCUSABLE)][st.fi];
    if (e && e.tagName === st.tag && !e.disabled) { try { e.focus({preventScroll: true}); if (st.sel) e.setSelectionRange(st.sel[0], st.sel[1]); } catch {} }
  }
}
// What a refresh must not move: a redraw builds every <img> again, and the new one would load and
// come in where the old one stood; a new result card starts as its 300px content-visibility
// placeholder, which pushed everything below the cards scrolled past. Call before the draw; the
// function it hands back puts the pictures that were on screen into the new page (same src, in
// order) and gives each card the height it had.
function keepLook(root = V()) {
  const pics = new Map(), tall = new Map();
  root.querySelectorAll("img[src]").forEach((im) => { if (!im.complete || !im.naturalWidth) return;
    const k = im.getAttribute("src"); if (!pics.has(k)) pics.set(k, []); pics.get(k).push(im); });
  root.querySelectorAll(".gw").forEach((el) => { const k = el.querySelector(".gi")?.dataset.item; if (k) tall.set(k, el.offsetHeight); });
  return () => {
    const news = [...root.querySelectorAll("img[src]")];
    news.forEach((b) => { const q = pics.get(b.getAttribute("src")), i = q ? q.indexOf(b) : -1; if (i >= 0) q.splice(i, 1); });   // it never left
    news.forEach((b) => { const q = pics.get(b.getAttribute("src")); if (!q || !q.length) return;
      const a = q.shift(); if (a.isConnected) return;
      a.className = b.className; a.classList.remove("loading", "imgin"); b.replaceWith(a); });
    if (tall.size) root.querySelectorAll(".gw").forEach((el) => { const h = tall.get(el.querySelector(".gi")?.dataset.item); if (h) el.style.containIntrinsicHeight = `auto ${h}px`; });
  };
}
// Run a screen's draw for a refresh: same page, so no entry animation, and the state kept.
function softDraw(fn) {
  const st = viewState(), keep = keepLook(); V().classList.add("still"); softN++;
  try { return fn(); } finally { softN--; try { keep(); } catch (e) { console.error(e); } restoreView(st); }
}
// The open screen, redrawn from fresh data. Never while a detail page is up (it has its own state).
let gaBusy = 0;                           // X15: until when result cards are mid-spring (gactFlip)
function redraw() {
  if (detail || !SCREENS[cur] || cur === "settings") return;
  // X15: the server's "something changed" lands a few ms after 정리; rebuilding now would cut the cards' spring.
  if (performance.now() < gaBusy) return void setTimeout(redraw, gaBusy - performance.now() + 20);
  softDraw(() => gaPics(() => SCREENS[cur](cur === "inbox" ? inTab : undefined)));   // X15: result cards keep their pictures
}
// openmoji.js wraps each department emoji in <span class="emo"> once it is on the page, so what
// stands there never equalled the html it was written from and the rail was rebuilt every round
// (the emoji blinked as text first). The copy handed back has the plain characters again.
function plainEmoji(el) {
  if (!el.querySelector(".emo")) return el;
  const c = el.cloneNode(true);
  c.querySelectorAll(".emo").forEach((n) => n.replaceWith(n.textContent)); c.normalize();
  return c;
}
// Write html into a chrome element only when it differs, and keep its scroll and focus: the
// rail and the bars were rebuilt every round, which dropped hover and focus for nothing.
function setHTML(el, html) {
  if (!el) return;
  const t = el.cloneNode(false); innerSet.call(t, html);
  if (t.isEqualNode(el) || t.isEqualNode(plainEmoji(el))) return;
  const a = document.activeElement, kf = (x) => x.dataset.go || x.dataset.key || x.dataset.dept || "";
  const key = a && el.contains(a) && a.dataset ? kf(a) : "", top = el.scrollTop;
  innerSet.call(el, html); el.scrollTop = top;
  if (key) { const n = [...el.querySelectorAll(FOCUSABLE)].find((x) => kf(x) === key); if (n) n.focus({preventScroll: true}); }
}
// Hold back the innerHTML writes of a draw that will repaint later (a placeholder line, then the
// data): the old content stays on screen, and the LAST write lands once the draw is done. A draw
// that hands back a promise is waited for; otherwise the last write lands after 1.5s. A draw that
// adds nodes instead of setting innerHTML is swapped at once (new nodes are in, old ones go out).
// A hold belongs to one draw of one screen. A move to another screen (or the next refresh) lets go
// of it first: the new screen's own writes would otherwise be held back and then thrown away.
let holdOff = null;
function holdWrites(el, run, apply) {
  if (holdOff) holdOff();
  const gen = viewGen, before = [...el.childNodes];
  let held = null, done = false, timer = 0;
  const off = holdOff = () => { if (holdOff === off) holdOff = null; if (done) return; done = true; clearTimeout(timer); delete el.innerHTML; };
  Object.defineProperty(el, "innerHTML", {configurable: true, get() { return innerDesc.get.call(el); },
    set(v) { if (done) innerSet.call(el, v); else held = {v}; }});
  const fin = () => {
    if (done) return; done = true; clearTimeout(timer); delete el.innerHTML;
    if (!held || !el.isConnected || gen !== viewGen) return;
    apply ? apply(() => innerSet.call(el, held.v)) : innerSet.call(el, held.v);
  };
  let r; try { r = run(); } catch (e) { console.error(e); return fin(); }
  if (el.childNodes.length > before.length || before.some((n) => n.parentNode !== el)) {     // it built with DOM calls
    before.forEach((n) => { if (n.parentNode === el) n.remove(); });
    done = true; delete el.innerHTML; return;
  }
  const then = r && typeof r.then === "function";
  timer = setTimeout(fin, then ? 10000 : 1500);
  if (then) r.then(fin, fin);
}

// Where each list was scrolled when a result opened from it, so coming back lands on the same card
// (phone list apps keep the place; it used to jump to the top). Keyed by the full list address.
// Noted on scroll, not at render: a filter tab rewrites the address in place without a render.
const listY = {}; let renderHash = location.hash;
addEventListener("scroll", () => { if (!detail) listY[location.hash] = scrollY; }, {passive: true});
function render(opts) {
  // Capture the built-in screen keys once (before any extension registers), so an extension
  // tab can never take a core id; then fold in whatever tabs extensions have pushed by now.
  window.LOOP_CORE_SCREENS = window.LOOP_CORE_SCREENS || Object.keys(SCREENS);
  syncExtTabs();
  // opts.soft: the same page again with fresh data (the refresh button): keep the place, no entry animation.
  const soft = !!(opts && opts.soft), y0 = scrollY;
  if (!soft) { viewGen++; if (holdOff) holdOff(); V().classList.remove("still"); }
  if (!(soft && !detail)) { endCompose(); closeResult(); }
  document.body.classList.remove("ctahide"); stageMount = null;
  // A name with a bare % ("진행률 50%") is not valid percent-encoding: read it as typed.
  let raw = location.hash.slice(1) || "home";
  // The results list keeps its filter in the address (#lib?f=pending&d=부서&q=글자), so a
  // refresh or a sent link opens the same list.
  if (/^lib\?/.test(raw)) { const u = new URLSearchParams(raw.slice(4)); libFAuto = !u.get("f"); libF = libFAuto ? "" : stTabKey(u.get("f")); libD = u.get("d") || ""; libQ = u.get("q") || ""; libK = u.get("k") || ""; raw = "lib"; }
  // A compare view keeps its pair, mode, and moment in the address (#item/<id>?cmp=v3,v5&m=wipe&t=12.4)
  // so a reload, Back, or a link opened elsewhere restores the exact comparison. A project/item
  // name can never hold "?", so the query safely starts at the first one.
  pendingCmp = null;
  if (/^item\//.test(raw) && raw.includes("?")) {
    const qi = raw.indexOf("?"), u = new URLSearchParams(raw.slice(qi + 1)), cmp = (u.get("cmp") || "").split(",");
    if (cmp[0]) pendingCmp = {id: null, a: cmp[0], b: cmp[1] || "", m: u.get("m") || "", t: parseFloat(u.get("t")), thr: parseInt(u.get("thr"), 10)};
    raw = raw.slice(0, qi);
  }
  let h = raw; try { h = decodeURIComponent(raw); } catch {}
  // #mission · #alerts · #tasks became sections of 받은함: the address is rewritten in place,
  // so Back does not bounce through the old name.
  if (ALIAS[h]) { h = ALIAS[h]; history.replaceState(null, "", "#" + h); }
  // 전체 is the phone's menu page; the desktop layout has no way to it and no styles for it. An
  // address that names it there (a link sent from the phone) opens home instead.
  if (h === "all" && wide()) { h = "home"; history.replaceState(null, "", "#home"); }
  const [k, ...rest] = h.split("/");
  const id = rest.join("/");
  if (pendingCmp) pendingCmp.id = id;
  if (k !== "lib") { libSel = null; document.getElementById("selbar")?.remove(); }
  if (k === "search") { search(true); return; }
  search(false);
  if ((k === "item" || k === "dept") && id) {
    detail = [k, id];
    document.body.classList.add("push"); document.body.classList.remove("allpg");
    document.body.classList.toggle("detail", !wide() && k === "item");
    ({item: itemView, dept: deptView})[k](id);
    infoPanel(null);
  } else {
    detail = null;
    cur = SCREENS[k] ? k : "home";
    document.body.classList.remove("push", "detail");
    if (cur !== "settings") setDeep = false;
    if (cur === "settings") { setShowPage = setDeep; setUpdSeen = false; setNav.run?.stop(); setNav.run = null; setNav.drag = false; }   // a fresh open of settings starts on the menu (phone)
    const r = soft ? softDraw(() => SCREENS[cur](k === "inbox" ? id : undefined)) : SCREENS[cur](k === "inbox" ? id : undefined);
    document.body.classList.toggle("allpg", cur === "all");   // phone: 전체 draws its own top row
    head(M(cur)?.n || (cur === "inbox" ? tl("TABS.1") : "") || (cur === "all" ? tl("all.tab") : "") || extTabs().find((t) => t.id === cur)?.label || "", r?.right);
    infoPanel(cur);
  }
  const was = renderHash; renderHash = location.hash;
  // Back from a chat opened in the sessions list: the list is where it was left, not at its top.
  const fromItem = /^#(item|dept)\//.test(was) || (cur === "sessions" && /^#project\//.test(was));
  scrollTo(0, soft ? y0 : !detail && fromItem && listY[location.hash] || 0); drawChrome();
  // Customisation (web/custom.js): re-apply per-project accent and any view options that
  // depend on the screen just drawn. A no-op when custom.js has not loaded.
  try { window.LOOP_AFTER_RENDER && window.LOOP_AFTER_RENDER(); } catch (e) {}
}
function back() {
  // An embedded report has its own history; the app's back button leaves the result directly.
  if (detail?.[0] === "item") return nav("lib");
  if (history.length > 1 && sessionStorage.getItem("v2-inner")) history.back();
  else nav(detail?.[0] === "item" ? "lib" : "dept");
}
// A result opened from a conversation remembers it, so the back spot can say where it leads
// ("대화로" + the conversation's name). Noted when the address moves from a room to a result, kept
// from one result to the next (those replace each other in history, so back still lands in the
// room) and across the search/settings overlays. Memory only: a result opened by its address or
// after a reload has no known origin and shows the plain back arrow.
let navLast = location.hash.slice(1), itemFrom = null;
window.LOOP_ITEM_FROM = () => itemFrom?.sid || null;
function noteFrom() {
  const h = location.hash.slice(1), room = /^project\/[^/?]+\/([^/?]+)/.exec(navLast), over = /^(search|settings)/;
  if (h.startsWith("item/")) {
    if (room) {
      const f = itemFrom = {hash: navLast, sid: decodeURIComponent(room[1]), title: ""};
      get("/api/project/session?id=" + encodeURIComponent(f.sid)).then((x) => { if (itemFrom !== f || !x?.title) return;
        f.title = x.title; document.querySelectorAll(".tochat .bn").forEach((n) => { n.textContent = x.title; n.closest("button").title = x.title; }); }).catch(() => {});
    } else if (!navLast.startsWith("item/") && !(over.test(navLast) && itemFrom?.at === h)) itemFrom = null;
    if (itemFrom) itemFrom.at = h;
  } else if (!over.test(h)) itemFrom = null;
  navLast = h;
}
// A link to a result inside a conversation opens it here, in the app, so back returns to the
// conversation (it used to open a second window). A link that names a version still opens as before.
document.addEventListener("click", (e) => {
  const a = e.target.closest?.(".pj-msgs a[href]"); if (!a || e.defaultPrevented || e.button || e.ctrlKey || e.metaKey || e.shiftKey) return;
  let u; try { u = new URL(a.href); } catch { return; }
  const m = /^\/i\/([^/]+)\/([^/]+)\/?$/.exec(u.pathname);
  if (!m || u.search || u.port !== location.port || !["localhost", "127.0.0.1", location.hostname].includes(u.hostname)) return;
  let id; try { id = decodeURIComponent(m[1]) + "/" + decodeURIComponent(m[2]); } catch { return; }
  if (!D.items?.some((x) => iid(x) === id)) return;
  e.preventDefault(); nav("item/" + encodeURIComponent(decodeURIComponent(m[1])) + "/" + encodeURIComponent(decodeURIComponent(m[2])));
});
// Back on a phone while the viewer or a sheet is up: the page under it changes, so they go too.
addEventListener("hashchange", () => { try { sessionStorage.setItem("v2-inner", "1"); } catch {}
  noteFrom();
  vwClose?.(); stkClose?.(); if (document.getElementById("sheet")?.classList.contains("on")) closeSheet(); closeResult(); render(); });

// The sidebar toggle: one control in one place - the first slot of the top bar on every desktop
// screen, list or detail, so it never moves or goes missing when the rest of the bar changes.
// Whether history has a page ahead (Navigation API; where it is missing the button stays on).
const fwdOk = () => { try { return window.navigation ? navigation.canGoForward : true; } catch { return true; } };
// The one panel icon (a window with a side panel on the right). The left menu's controls draw it mirrored (CSS).
const PANEL_ICO = '<svg class="i" viewBox="0 0 256 256" aria-hidden="true"><path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM40,56H160V200H40ZM216,200H176V56h40V200Z"/></svg>';
const railBtn = () => `<button class="ib press railtgl" data-railmin aria-label="${railTip()}" aria-expanded="${railState() === "full"}" title="${railTip()} ( [ )">${PANEL_ICO}</button>`;
function head(title, right = "") {
  const t = document.getElementById("top"); head.last = [title, right];
  if (detail) {
    // Result back always returns to the library; do not label it as a chat return.
    const fc = null;
    setHTML(t, `${LAB3 && wide() ? `<div class="tbtools">` : ""}${wide() ? railBtn() : ""}<button class="ib back press${fc ? " tochat" : ""}" data-back aria-label="${fc ? tl("head.tochat") : tl("head.1")}"${fc ? ` title="${esc(fc.title)}"` : ""}>${ic("back")}${fc ? `<span class="bl">${tl("head.tochat")}</span><span class="bn">${esc(fc.title)}</span>` : ""}</button>${LAB3 && wide() ? "</div>" : ""}<h1 class="dt">${title}</h1><span class="sp"></span>${syncBtn()}${right}${fbBtn()}${connPill()}${updPill()}${wcSpacer()}`);
    return;
  }
  if (!wide()) { setHTML(t, `<h1>${title}</h1><span class="sp"></span>${zoomBtn()}${right || bellSearch()}${fbBtn()}${connPill()}${updPill()}${wcSpacer()}`); return; }
  // Desktop: refern's single toolbar — a cluster of chrome icons on the left, an address-like path
  // pill centred between two flexible gaps, the screen's right-side actions, then (on a frameless
  // Windows window) room for the min/max/close corner bar. Refresh is the quiet data-sync icon in the
  // left cluster; its last-sync time lives in the tooltip, so "방금 동기화" is no longer a text pill.
  setHTML(t, `<div class="tbtools">`
    + railBtn()
    + `<button class="ib press" data-back aria-label="${tl("ui.tb.back")}" title="${tl("ui.tb.back")}">${ic("back")}</button>`
    + `<button class="ib press fwd" data-fwd aria-label="${tl("ui.tb.fwd")}" title="${fwdOk() ? tl("ui.tb.fwd") : tl("ui.tb.fwd.none")}"${fwdOk() ? "" : " disabled"}>${ic("back")}</button>`
    + `<button class="ib press" data-sync aria-label="${tl("ui.tb.refresh")}" title="${tl("syncBtn.2", {p0: D.at ? hm(D.at) : "-"})}">${ic("sync")}</button>`
    + `<button class="ib press tbset ${cur === "settings" ? "on" : ""}" data-go="settings" aria-label="${tl("TABS.4")}" title="${tl("TABS.4")}">${ic("gear")}</button>`
    // Search is one icon here (Ctrl K). The wide centre pill repeated the sidebar highlight and
    // crowded the title bar, so the middle is left empty to drag the window by.
    + (LAB3 ? "" : `<button class="ib press" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")} (${tl("ui.ctrlk")})">${ic("search")}</button>`)
    + `</div>`
    // Lab layout: the screen's name leads the bar (home greets below instead). Lab 3 has the one
    // bar only, with the search field in the middle of it and no greeting.
    + (LAB3 && cur !== "home" ? `<h1 class="ttl">${title}</h1>` : "")
    + (LAB3 ? `<span class="sp"></span><button class="k3q press" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")} (${tl("ui.ctrlk")})">${ic("search")}<span>${tl("MENUS.5")}</span></button>` : "")
    + `<span class="sp"></span><div class="tbright">${zoomBtn()}${right || bellOnly()}${fbBtn()}</div>${connPill()}${updPill()}${wcSpacer()}`);
}
// Frameless Windows window chrome, drawn by the page (refern style): no separate title strip. The
// page runs to the top edge; min/max/close sit transparent in the top-right corner of every screen
// (one fixed bar above every overlay, onboarding and tour included) and headers reserve that corner
// with wcSpacer. A press on any empty spot in the top row drags the window: the bridge (start_move)
// hands it to the system move loop, so Snap and FancyZones work; double-click maximizes. The resize
// border is native (winframe.py).
const WINCHROME = IN_APP && OS_WIN;
// The title-bar update pill's state (see updPill); declared up here because head() draws it.
// phase: "" | "dl" | "ready" (downloaded, waiting to be applied) | "install". auto: install as soon as
// the download is in. err: why the last try failed. sure: the busy-session warning was confirmed.
const UPD = {u: null, phase: "", pct: 0, enterUntil: 0, auto: true, err: "", run: 0};
const WG = {
  min: `<line x1="1.5" y1="5" x2="8.5" y2="5"/>`,
  max: `<rect x="1.5" y="1.5" width="7" height="7" rx="0.5"/>`,
  restore: `<rect x="1.4" y="3.1" width="5.5" height="5.5" rx="0.5"/><path d="M3.6 3.1V1.4h5.5v5.5H7.3"/>`,
  close: `<path d="M1.5 1.5l7 7M8.5 1.5l-7 7"/>`,
};
const winGlyph = (k) => `<svg class="wg" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">${WG[k]}</svg>`;
const winMaxed = () => document.body.classList.contains("winmax");
const wcSpacer = () => WINCHROME ? `<span class="wcsp" aria-hidden="true"></span>` : "";
const winCtl = () => `<div class="wctl">`
  + `<button class="wb" data-wmin aria-label="${tl("ui.win.min")}" title="${tl("ui.win.min")}">${winGlyph("min")}</button>`
  + `<button class="wb" data-wmax aria-label="${tl("ui.win.max")}" title="${winMaxed() ? tl("ui.win.restore") : tl("ui.win.max")}">${winGlyph(winMaxed() ? "restore" : "max")}</button>`
  + `<button class="wb wclose" data-wclose aria-label="${tl("ui.win.close")}" title="${tl("ui.win.close")}">${winGlyph("close")}</button>`
  + `</div>`;
// Python (tray._sync_maxed) calls this on maximize/restore (Snap and double-click included).
window.__rlWinMax = (maxed) => {
  document.body.classList.toggle("winmax", !!maxed);
  const b = document.querySelector("[data-wmax]");
  if (b) { b.innerHTML = winGlyph(maxed ? "restore" : "max"); b.title = tl(maxed ? "ui.win.restore" : "ui.win.max"); }
};
document.addEventListener("click", (e) => {
  const w = e.target.closest?.("[data-wmin],[data-wmax],[data-wclose]");
  if (!w || !window.pywebview?.api) return;
  if (w.dataset.wmin !== undefined) window.pywebview.api.minimize?.();
  else if (w.dataset.wmax !== undefined) window.pywebview.api.toggle_maximize?.();
  else if (w.dataset.wclose !== undefined) window.pywebview.api.close?.();
});
const DRAGH = 36;
// Real controls only. [data-go]/[data-back] are not listed: every one is a button or link already, and
// the Settings/Search backdrop (a full-screen div with data-back) would make the whole top row undraggable.
const dragSpot = (e) => e.clientY >= 0 && e.clientY < DRAGH && !e.target.closest?.(
  "button,a,input,gk-select,textarea,label,summary,[role=button],[role=checkbox],.ib,.btn,.field,.wctl,.updpill,.connpill,.updpop,[contenteditable]");
document.addEventListener("mousedown", (e) => {
  if (!WINCHROME || e.button !== 0 || e.detail > 1 || !window.pywebview?.api?.start_move || !dragSpot(e)) return;
  e.preventDefault();
  window.pywebview.api.start_move();
}, true);
document.addEventListener("dblclick", (e) => {
  if (WINCHROME && window.pywebview?.api && dragSpot(e)) window.pywebview.api.toggle_maximize?.();
});
function initWinChrome() {
  if (!WINCHROME) return;
  const bar = document.createElement("div");
  bar.className = "wtbar";
  bar.innerHTML = winCtl();
  document.body.appendChild(bar);
}
initWinChrome();
// A refresh that really refreshes: everything reloads and the open screen redraws, even the
// ones the 30-second round leaves alone. How old the data is sits beside it.
const syncBtn = () => `<button class="sync press" data-sync aria-label="${tl("syncBtn.1")}" title="${tl("syncBtn.2", {p0: D.at ? hm(D.at) : "-"})}">${ic("sync")}<span>${syncAgo()}</span></button>`;
const syncAgo = () => { if (!D.at) return (loadLost ? tl("syncAgo.4") : tl("syncAgo.1")); const m = Math.floor((Date.now() - hostDate(D.at)) / 6e4); return (m < 1 ? tl("ago.2") : m < 60 ? tl("syncAgo.2", {m}) : tl("ago.4", {p0: Math.floor(m / 60)})) + tl("syncAgo.3"); };
async function syncNow(b) {
  if (b.classList.contains("on")) return;
  document.querySelectorAll("[data-sync]").forEach((x) => x.classList.add("on"));
  // A bar that just came up already says why; the toast repeats it only when the bar was there before.
  const barred = !!document.getElementById("netbar");
  try { const ok = await load(); render({soft: true}); if (ok || barred) toast(ok ? tl("syncNow.1") : lostMsg, 2200, ok ? "synced" : "failed"); }
  catch (e) { toast(e.message); }
  document.querySelectorAll("[data-sync]").forEach((x) => { x.classList.remove("on"); const sp = x.querySelector("span"); if (sp) sp.innerHTML = syncAgo(); });
}
setInterval(() => document.querySelectorAll("[data-sync] span").forEach((x) => { const h = syncAgo(); if (x.innerHTML !== h) x.innerHTML = h; }), 20000);
// Search + bell, the always-there right cluster. On desktop the sync sits quietly in the left chrome
// cluster, so the toolbar uses searchBell(); the phone header keeps the sync pill via bellSearch().
// The bell is the one way into 알림: it carries the number 할 일 has (a dot for unread 소식 alone) and
// opens on the tab that has something. drawChrome redraws it in place when the number moves.
const bellOnly = () => { const todo = todoCount(), news = newsUnread(), t = tl("TABS.1") + (todo ? " " + todo : "");
  return `<button class="ib press bellb ${!detail && cur === "inbox" ? "on" : ""}" data-bell data-go="${!todo && news ? "inbox/news" : "inbox"}" aria-label="${t}" title="${tl("TABS.1")}">${ic("bell")}${todo ? `<b class="bcnt num">${todo > 99 ? "99+" : todo}</b>` : news ? `<span class="dot"></span>` : ""}</button>`; };
const searchOnly = () => `<button class="ib press sbsearch" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")}">${ic("search")}</button>`;
// The zoom magnifier (web/custom.js zoomChip) leads the right cluster; it is hidden at 100%.
const zoomBtn = () => (window.zoomChip ? zoomChip() : "");
const searchBell = () => `${searchOnly()}${bellOnly()}`;
const bellSearch = () => `${syncBtn()}${searchBell()}`;
// "의견 남기기" (G-024): the beta feedback form. The address comes from the server (version.py
// FEEDBACK_URL, the one place it lives) with only the app version filled in; while it is
// empty or not http(s) nothing is drawn. A plain new-tab link in a browser; in the app window the
// click asks the server to open the PC's default browser instead.
// Since the popup (fbSheet): the button opens a short form here, and Send posts what was typed plus
// the app's version through the server (/api/feedback-send). The page stays as the way out when
// that fails.
const fbUrl = () => { const u = (LANG() === "en" && D.fbEn) || D.fb || ""; return /^https?:\/\//i.test(u) ? u : ""; };
const fbLink = (cls, inner, label) => `<a class="${cls}" data-feedback href="${esc(fbUrl())}" target="_blank" rel="noopener noreferrer"${label ? ` aria-label="${label}" title="${label}"` : ""}>${inner}</a>`;
// A megaphone, not the speech bubble: the bubble already means "conversation" in the side menu.
// The words stand beside it on a PC-wide bar (v2.css .fbb); narrower, the icon alone, down to 600px.
const fbBtn = () => fbUrl() ? fbLink("ib press fbb", ic("megaphone") + `<span>${tl("fb.send")}</span>`, tl("fb.send")) : "";
const fbPage = () => IN_APP ? post("/api/feedback-open", {lang: LANG()}).catch((x) => toast(x.message)) : window.open(fbUrl(), "_blank", "noopener");
const FB_DRAFT = "genok-fb-draft";
const FB_IMG_MAX = 4, FB_IMG_BYTES = 5 * 1024 * 1024;
function fbSheet() {
  let d = {}; try { d = JSON.parse(localStorage.getItem(FB_DRAFT) || "{}") || {}; } catch (e) { /* no draft */ }
  const st = {text: typeof d.text === "string" ? d.text : "", mail: typeof d.mail === "string" ? d.mail : ""};
  const imgs = [], canImg = !!D.fbImg;   // pictures live for this popup only, never in the draft
  sheet(`<h2 style="margin:0 0 4px">${tl("fb.send")}</h2><p class="hint" style="margin:0 0 12px">${canImg ? tl("fb.pop.di", {v: esc(D.ver || "")}) : tl("fb.pop.d", {v: esc(D.ver || "")})}</p>
    <form class="fbf" novalidate>
    <textarea class="fbta" id="fb-t" rows="5" maxlength="5000" placeholder="${tl("fb.pop.ph")}" aria-label="${tl("fb.pop.ph")}">${esc(st.text)}</textarea>
    ${canImg ? `<div class="fbimgs" id="fb-i"></div><input type="file" id="fb-f" accept="image/png,image/jpeg,image/gif,image/webp" multiple hidden>` : ""}
    <div class="fbl"><label for="fb-m">${tl("fb.pop.mail")}</label></div>
    <input class="fbin" id="fb-m" type="email" inputmode="email" autocomplete="email" spellcheck="false" maxlength="200" placeholder="name@example.com" value="${esc(st.mail)}">
    <div class="cf-acts"><button type="submit" class="btn xl fill press" id="fb-go">${tl("fb.pop.go")}</button><button type="button" class="btn xl press" data-sclose>${tl("fb.pop.cancel")}</button></div>
    <button type="button" class="lnk press fbalt" id="fb-page">${tl("fb.pop.page")}</button></form>`, (el) => {
    const ta = el.querySelector("#fb-t"), mail = el.querySelector("#fb-m"), go = el.querySelector("#fb-go"), form = el.querySelector(".fbf");
    const keep = () => { try { localStorage.setItem(FB_DRAFT, JSON.stringify(st)); } catch (e) { /* storage off */ } };
    const paint = () => { go.disabled = !st.text.trim(); };
    paint();
    ta.oninput = () => { st.text = ta.value; keep(); paint(); };
    mail.oninput = () => { st.mail = mail.value; keep(); };
    el.querySelector("#fb-page").onclick = () => fbPage();
    if (canImg) {
      const box = el.querySelector("#fb-i"), pick = el.querySelector("#fb-f");
      const draw = () => { box.innerHTML = imgs.map((m, i) => `<span class="fbim"><img src="${m.url}" alt=""><button type="button" class="press" data-del="${i}" title="${tl("fb.pop.imgdel")}" aria-label="${tl("fb.pop.imgdel")}">${ic("x")}</button></span>`).join("")
        + (imgs.length < FB_IMG_MAX ? `<button type="button" class="fbadd press" id="fb-add" title="${esc(tl("fb.pop.img"))}">${ic("image")}<span>${tl("fb.pop.img")}</span></button>${imgs.length || !wide() ? "" : `<span class="fbhint">${tl("fb.pop.imgd")}</span>`}` : ""); };
      const add = (files) => { for (const f of files) {
        if (!/^image\/(png|jpeg|gif|webp)$/.test(f.type)) continue;
        if (imgs.length >= FB_IMG_MAX) { toast(tl("fb.pop.imgmax")); break; }
        if (f.size > FB_IMG_BYTES) { toast(tl("fb.pop.imgbig")); continue; }
        const m = {url: URL.createObjectURL(f), data: ""}; imgs.push(m);
        const fr = new FileReader(); fr.onload = () => { m.data = String(fr.result).split(",")[1] || ""; }; fr.readAsDataURL(f);
      } draw(); };
      draw();
      box.onclick = (e) => { const x = e.target.closest("[data-del]");
        if (x) { URL.revokeObjectURL(imgs.splice(+x.dataset.del, 1)[0].url); draw(); } else if (e.target.closest("#fb-add")) pick.click(); };
      pick.onchange = () => { add(pick.files); pick.value = ""; };
      // Ctrl+V anywhere in the popup, or a drop on it: pictures only, text pastes as usual.
      el.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith("image/")); if (fs.length) { e.preventDefault(); add(fs); } });
      const over = (on) => form.classList.toggle("drop", on);
      el.addEventListener("dragover", (e) => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); e.stopPropagation(); over(true); } });
      el.addEventListener("dragleave", (e) => { if (!el.contains(e.relatedTarget)) over(false); });
      el.addEventListener("drop", (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); e.stopPropagation(); over(false); add(e.dataTransfer.files); });
    }
    form.onsubmit = (e) => { e.preventDefault(); if (go.disabled) return;
      if (imgs.some((m) => !m.data)) return;   // a picture still being read: the next press sends it
      go.disabled = true; go.textContent = tl("fb.pop.going");
      post("/api/feedback-send", {text: st.text, mail: st.mail.trim(), ...(imgs.length ? {images: imgs.map((m) => ({data: m.data}))} : {})})
        .then(() => { try { localStorage.removeItem(FB_DRAFT); } catch (x) { /* storage off */ } imgs.forEach((m) => URL.revokeObjectURL(m.url)); closeSheet(); toast(tl("fb.pop.done")); })
        .catch((x) => { go.textContent = tl("fb.pop.go"); go.disabled = false; toast(x.message); }); };
    if (wide()) ta.focus();
  });
}
document.addEventListener("click", (e) => {
  if (!e.target.closest?.("[data-feedback]")) return;
  e.preventDefault(); fbSheet();
});
// Ctrl/Cmd K opens search from anywhere, like refern's Ctrl K hint on the home search box.
addEventListener("keydown", (e) => {
  if (FLOAT) return;
  if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
    if (e.target.closest?.("input,textarea,[contenteditable]")) return;
    e.preventDefault(); search(true);
  }
});

// The menu on the left folds to its icons (as Linear and Slack do), so the conversation or
// the result being looked at gets the width. "[" does the same from the keyboard.
// Three states, one key: v2-railmin is "0" (full), "2" (icons only) or "1" (hidden: the value a
// fold wrote before there were three, so a menu that was folded stays folded). The toolbar button
// and "[" switch full <-> icons; the border handle, the 보기 menu and "{" hide it altogether, and
// showing it again brings back the shape it had (v2-railwas).
// A window that never chose starts on the icons: each one names itself on hover (railTip).
const railState = (v) => { try {
  const c = compact();
  if (v === undefined) { const s = localStorage.getItem(railKey()) || "2"; return s === "1" ? "off" : c ? railPeek ? "full" : "icons" : s === "2" ? "icons" : "full"; }
  if (c) railPeek = v === "full";
  if (v === "off") localStorage.setItem(railKey("was"), !c && railState() === "icons" ? "2" : "0");
  localStorage.setItem(railKey(), v === "off" ? "1" : v === "icons" ? "2" : "0"); } catch { return compact() ? "icons" : "full"; } };
// A compact window (a PC under 1024px) keeps its own choice apart from the wide window's, so
// narrowing the window folds the menu and widening it brings back what the wide window had.
// There the menu is its icons; opened in full it lies over the page for as long as it is used
// (railPeek, never saved) and folds again on a pick, a press outside it or Escape - as Slack and
// Notion do in a narrow window.
let railPeek = false;
const railKey = (k) => "v2-rail" + (k || "min") + (compact() ? "-c" : "");
const railMin = () => railState() === "off";
const railRoom = () => railState() === "full" && !compact() ? 216 : 72;   // what the menu takes from the page, about
const railTip = () => { const s = railState(); return s === "full" ? tl("ui.tb.railIcons") : s === "off" ? tl("ui.tb.railShow") : tl("ui.tb.railFull"); };
const railMark = () => { const s = railState(); document.body.classList.toggle("railmin", s === "off"); document.body.classList.toggle("railico", s === "icons"); };
railMark();
function setRail(s) { railState(s); railMark();
  // Keep the toolbar toggle honest (the toolbar is not re-rendered on toggle).
  document.querySelectorAll("[data-railmin]").forEach((b) => { b.setAttribute("aria-expanded", String(s === "full")); b.setAttribute("aria-label", railTip()); b.title = railTip() + " ( [ )"; });
  railTipOff(); drawChrome(); setClw(clw()); window.LOOP_FOLDS?.(); }
function toggleRail() { const s = railState(); setRail(s === "off" ? railWas() : s === "full" ? "icons" : "full"); }
const railWas = () => { try { return compact() || localStorage.getItem(railKey("was")) === "2" ? "icons" : "full"; } catch { return "full"; } };
const railUnpeek = () => { if (railPeek) setRail("icons"); };
document.addEventListener("pointerdown", (e) => { if (railPeek && !e.target.closest?.("#rail,[data-railmin],[data-edge]")) railUnpeek(); }, true);
addEventListener("hashchange", railUnpeek);
// Escape folds the menu and nothing else: on a result it would also go back.
addEventListener("keydown", (e) => { if (e.key === "Escape" && railPeek) { e.stopImmediatePropagation(); e.preventDefault(); railUnpeek(); } }, true);
function railHide(on) { if (on === undefined) on = !railMin(); if (on !== railMin()) setRail(on ? "off" : railWas()); }
// Icons only: a row's name is its tooltip, on hover and on keyboard focus (the native title waits
// a second and never shows for the keyboard). One tip, placed beside the row.
const railTipOff = () => document.querySelectorAll(".railtip").forEach((t) => t.remove());
function railTipOn(b) {
  railTipOff(); if (!b || !document.body.classList.contains("railico") || !wide() || !b.dataset.tip) return;
  const t = document.createElement("div"), r = b.getBoundingClientRect(); t.className = "gatip railtip"; t.setAttribute("role", "tooltip"); t.textContent = b.dataset.tip;
  document.body.appendChild(t);
  t.style.left = r.right + 10 + "px"; t.style.top = Math.max(8, Math.min(innerHeight - t.offsetHeight - 8, r.top + r.height / 2 - t.offsetHeight / 2)) + "px";
}
const railRow = (e) => e.target.closest?.("#rail .it");
document.addEventListener("mouseover", (e) => { const b = railRow(e); if (b) railTipOn(b); else railTipOff(); });
document.addEventListener("focusin", (e) => { const b = railRow(e); if (b && b.matches(":focus-visible")) railTipOn(b); else railTipOff(); });
document.addEventListener("pointerdown", railTipOff, true);
// Icons only: the names are not on screen, so a row carries its name (and its count) for a screen
// reader and for the tip above instead of a native title, which would come up on top of the tip.
const railIco = () => railState() === "icons" && wide();
const rn = (t, n) => railIco() ? ` data-tip="${t}" aria-label="${t}${n ? " " + n : ""}"` : ` title="${t}"`;
// Not named chrome(): a global function by that name replaces window.chrome, and with it
// window.chrome.webview, which is the pywebview bridge (every window.pywebview.api call fails).
// Lab 3: the kit's own shell, its left capsule menu and right capsule column, stands around Genok's pages.
// Lab 3: every inner screen wears the kit's own classes (glass card, pill, list row) on top of its
// markup, so the kit stylesheet paints it while the screen keeps its handlers.
let k3obs = null;
// Lab 3, PC: the bell opens the kit's notification drawer over the page instead of leaving it -
// what waits on me by kind, then the latest news. Rows are ordinary [data-go]/[data-item] controls.
function kitBell(from) {
  const old = document.getElementById("k3bell"); if (old) { old.k3shut(); return; }
  const T = todoSecs().filter((s) => secN(s)), N = newsList().slice(0, 6);
  const d = document.createElement("aside"); d.id = "k3bell"; d.className = "glass-drawer k3bell"; d.setAttribute("aria-label", tl("TABS.1"));
  d.innerHTML = `<div class="drawer-header"><span class="drawer-title">${tl("TABS.1")}</span><button class="drawer-close-btn press" data-k3bx aria-label="${tl("ui.close")}">${ic("x")}</button></div>
    <div class="drawer-list">${T.length ? `<div class="k3bh">${tl("bell.todo")}</div>` : ""}${T.map((s) => `<button class="drawer-item unread press" data-go="inbox" data-k="${s.k}"><span class="k3bi">${ic(s.i)}</span><span class="tx"><div class="drawer-item-title">${esc(s.n)}</div><div class="drawer-item-desc">${esc(String(s.peek(s.L[0]) || ""))}</div></span><b class="num">${secN(s)}</b></button>`).join("")
    }${N.length ? `<div class="k3bh">${tl("bell.news")}</div>` : ""}${N.map((a) => `<button class="drawer-item news${newsNew(a) ? " unread" : ""} press" ${a.item ? `data-item="${esc(a.item)}"` : `data-go="inbox/news"`}><span class="k3bi">${ic(a.i)}</span><span class="tx"><div class="drawer-item-title">${esc(a.t)}</div><div class="drawer-item-desc">${esc(a.s || "")}</div></span><span class="drawer-item-time">${ago(a.at)}</span></button>`).join("")
    }${T.length || N.length ? "" : `<div class="drawer-item-desc">${tl("bell.none")}</div>`}</div>
    <button class="btn k3bellall press" data-go="inbox">${tl("itemView.31")}</button>`;
  // Opens under the bell that was pressed: 홈's own header sits lower than the toolbar.
  if (from) d.style.top = Math.round(from.getBoundingClientRect().bottom + 14) + "px";
  document.body.append(d);
  const shut = () => { d.remove(); document.removeEventListener("keydown", key, true); document.removeEventListener("mousedown", out, true); };
  d.k3shut = shut;
  const key = (e) => { if (e.key === "Escape") { e.stopPropagation(); shut(); } };
  // A press outside only closes: the click that follows is swallowed, so it cannot open what lay under it.
  const out = (e) => { if (d.contains(e.target) || e.target.closest("[data-bell]")) return; shut();
    const eat = (c) => { c.preventDefault(); c.stopPropagation(); }; document.addEventListener("click", eat, {capture: true, once: true});
    setTimeout(() => document.removeEventListener("click", eat, true), 400); };
  document.addEventListener("keydown", key, true); document.addEventListener("mousedown", out, true);
  d.addEventListener("click", (e) => { if (e.target.closest("[data-k3bx],[data-go],[data-item]")) setTimeout(shut, 0); });
}
if (LAB3) document.addEventListener("click", (e) => { const b = e.target.closest("#top [data-bell],.d2-header [data-bell]"); if (!b || !wide()) return;
  e.preventDefault(); e.stopPropagation(); kitBell(b); }, true);
function kitDress() {
  const v = V(); if (!v) return;
  v.querySelectorAll(":is(.card,.set,.uz-panel,.hsv):not(.glass-card)").forEach((e) => e.classList.add("glass-card"));
  v.querySelectorAll(".row:not(.video-row-item)").forEach((e) => e.classList.add("video-row-item"));
  v.querySelectorAll(".cnrow:not(.drawer-item)").forEach((e) => e.classList.add("drawer-item"));
  v.querySelectorAll(".chip").forEach((e) => { if (!e.classList.contains("category-pill")) e.classList.add("category-pill");
    const on = e.classList.contains("on"); if (on !== e.classList.contains("active")) e.classList.toggle("active", on); });
}
function drawKit() {
  if (!k3obs && V()) { k3obs = new MutationObserver(kitDress); k3obs.observe(V(), {childList: true, subtree: true, attributes: true, attributeFilter: ["class"]}); kitDress(); }
  const app = document.querySelector(".app"); if (!app) return;
  let L = document.getElementById("k3l"), R = document.getElementById("k3r");
  if (!L) { L = document.createElement("aside"); L.id = "k3l"; L.className = "d2-sidebar-left"; app.prepend(L);
    R = document.createElement("aside"); R.id = "k3r"; R.className = "d2-sidebar-right"; app.append(R);
    R.addEventListener("click", (e) => { if (k3skip) return;
      const b = e.target.closest("[data-k3n]"); if (b) return srShow(b.dataset.k3k, b.dataset.k3n);
      if (e.target.closest("[data-k3set]")) return kitPins();
      if (e.target.closest("[data-k3next]")) { const r = unreadRooms()[0]; if (!r) return toast(tl("nextUnread.none")); if (srOpen !== r.key) srShow(r.key, r.dept); } });
    kitSort(R);
    kitTip(L); kitTip(R);
    const logo = (on) => (e) => { const b = e.target.closest?.(".d2-logo-wrap"); if (b && !b.contains(e.relatedTarget)) kitLogo(b, on); };
    L.addEventListener("mouseover", logo(true)); L.addEventListener("mouseout", logo(false));
    L.addEventListener("focusin", logo(true)); L.addEventListener("focusout", logo(false)); }
  if (k3d && k3d.on) return;                       // a drag in progress keeps its buttons
  const at = detail ? "lib" : cur, name = (k) => (MENUS.find((m) => m.k === k) || {}).n || "";
  const nb = (k, i, t) => `<button type="button" class="d2-nav-btn${at === k ? " active" : ""}" data-go="${k}" data-tip="${esc(t)}" aria-label="${esc(t)}"${at === k ? ' aria-current="page"' : ""}>${ic(i, "d2-nav-icon")}</button>`;
  L.setAttribute("aria-label", tl("MENUS.1"));
  setHTML(L, `<button type="button" class="d2-logo-wrap" data-go="home" title="Genok" aria-label="Genok">${brandMark(24)}</button>`
    + `<nav class="d2-left-nav">${nb("home", "home", name("home"))}${nb("project", "chat", name("project"))}${nb("lib", "lib", name("lib"))}${typeof SCREENS.usage === "function" ? nb("usage", "chart", ((window.LOOP_TABS || []).find((t) => t.id === "usage") || {}).label || "") : ""}${nb("settings", "gear", name("settings"))}</nav>`
    + `<div class="d2-left-bottom">${fbUrl() ? fbLink("d2-nav-btn k3fb", ic("megaphone", "d2-nav-icon"), tl("fb.send")) : ""}${D.ver ? `<button type="button" class="d2-nav-btn k3ver press" data-stupd title="${esc(tl("upd.check"))} · v${esc(D.ver)}" aria-label="${esc(tl("upd.check"))}">${ic("dl", "d2-nav-icon")}${updOn() ? `<i class="k3vdot"></i>` : ""}</button>` : ""}<button type="button" class="d2-plus-btn" data-go="depts" title="${esc(name("depts"))}" aria-label="${esc(name("depts"))}">${ic("plus", "d2-nav-icon")}</button></div>`);
  // pinned projects first, each with its chat's state; then the other live chats, then the rest of the projects
  const rm = new Map(srRooms().map((q) => [q.r.dept, q])), PJ = projects(), who = [], seen = new Set();
  const sel = k3Sel(), add = (n, icon, q) => { if (seen.has(n) || who.length >= (sel ? K3MAX : 9)) return; seen.add(n);
    who.push({n, icon, s: k3S(q), key: q ? q.r.key : ""}); };
  const named = (n) => { const q = rm.get(n), g = PJ.find((x) => x.name === n); if (q || g) add(n, (q && q.r.icon) || (g && g.icon) || "", q); };
  if (sel) sel.forEach(named);
  else rm.forEach((q, n) => { if (K3LIVE(q.s)) add(n, q.r.icon, q); });
  const unread = unreadRooms().length;
  R.setAttribute("aria-label", tl("srail.label"));
  setHTML(R, `<button type="button" class="d2-social-top-avatar" data-k3next data-tip="${esc(tl("k3.next"))}" aria-label="${esc(tl("k3.next") + (unread ? " " + unread : ""))}">${ic("chat", "d2-social-icon")}${unread ? `<b class="k3cnt num">${unread > 9 ? "9+" : unread}</b>` : ""}</button>`
    + `<div class="d2-friends-list">${who.map((w) => { const t = pname(w.n) + (w.s ? " · " + SR_T[w.s] : "");
      return `<button type="button" class="d2-friend-avatar-wrap${srOpen === (w.key || "d:" + w.n) ? " on" : ""}" data-k3n="${esc(w.n)}" data-k3k="${esc(w.key)}" data-s="${w.s}" data-tip="${esc(pname(w.n))}" aria-label="${esc(t)}"><span class="d2-friend-img"${k3Col(w.n)}>${k3Face(w.n, w.icon)}</span></button>`; }).join("")}</div>`
    + `<div class="d2-social-bottom"><button type="button" class="d2-social-icon-btn" data-go="project" data-tip="${esc(name("project"))}" aria-label="${esc(name("project"))}">${ic("rooms", "d2-social-icon")}</button><button type="button" class="d2-social-icon-btn" data-k3set data-tip="${esc(tl("k3.pins.set"))}" aria-label="${esc(tl("k3.pins.set"))}">${ic("sliders", "d2-social-icon")}</button></div>`);
}
// Lab 3: the logo's ring turns while the pointer rests on it (or it has the keyboard) and stills
// when it leaves. The still mark is the ring's own logo frame, so the two cross-fade in place.
function kitLogo(b, on) { b.classList.toggle("spin", !!on && !RM()); }
// Lab 3: which conversations stand in the right column, and in what order. Nothing stored = the
// automatic list (pinned projects, then live chats, then the rest). Once the person picks or
// drags, the list is theirs: project names in their order, kept in this window ("genok-k3r").
const K3MAX = 12, K3LIVE = (s) => s === "work" || s === "ask" || s === "stuck";
// The state a column icon wears: none for a session that has ended (it was shown as 대기, the
// same as one that is up and waiting).
const k3S = (q) => (q && !(q.s === "idle" && (q.r.state === "ended" || q.r.job === "stopped")) ? q.s : "");
// A face in the right column: the icon chosen for the project (a drawn one takes its colour).
// Name label beside a column icon, in place of the browser's own tooltip. It fades in where it stands.
function kitTip(col) {
  let tip = null, at = null;
  const off = () => { at = null; if (tip) tip.classList.remove("on"); };
  col.addEventListener("pointerover", (e) => { const b = e.pointerType === "touch" ? null : e.target.closest("[data-tip]");
    if (!b || col.classList.contains("sorting")) return off(); if (b === at) return;
    if (!tip) { tip = document.createElement("div"); tip.className = "k3tip"; tip.setAttribute("aria-hidden", "true"); document.body.append(tip); }
    at = b; const s = b.dataset.s, r = b.getBoundingClientRect(), c = col.getBoundingClientRect(), left = col.id === "k3l";
    tip.innerHTML = `${s ? `<i data-s="${esc(s)}"></i>` : ""}<span>${esc(b.dataset.tip)}</span>${s && SR_T[s] ? `<em>${esc(SR_T[s])}</em>` : ""}`;
    tip.style.top = Math.round(r.top + r.height / 2) + "px";
    tip.style.left = left ? Math.round(c.right + 8) + "px" : ""; tip.style.right = left ? "" : Math.round(innerWidth - c.left + 8) + "px";
    tip.classList.add("on"); });
  col.addEventListener("pointerleave", off); col.addEventListener("pointerdown", off);
}
const k3Face = (n, emoji) => identFace(n, emoji) || ic("folder", "d2-social-icon");
const k3Col = (n) => { const c = D.ident?.[n]?.color; return c && /^#[0-9a-f]{3,8}$/i.test(c) ? ` style="color:${c}"` : ""; };
window.k3FaceSet = (n) => { const b = [...document.querySelectorAll("#k3r [data-k3n]")].find((x) => x.dataset.k3n === n), f = b && b.querySelector(".d2-friend-img"); if (!f) return;
  const i = D.ident?.[n] || {}; f.innerHTML = k3Face(n, i.emoji || ""); f.style.color = i.color && /^#[0-9a-f]{3,8}$/i.test(i.color) ? i.color : ""; };
function k3Sel(v) { try {
  if (v === undefined) { const a = JSON.parse(localStorage.getItem("genok-k3r") || "null"); return Array.isArray(a) ? a.filter((x) => typeof x === "string") : null; }
  if (v) localStorage.setItem("genok-k3r", JSON.stringify(v)); else localStorage.removeItem("genok-k3r"); } catch (e) { /* stays automatic */ } return v || null; }
// Dragging a face up or down the column moves it there. The face follows the pointer 1:1 from
// where it was grabbed, the others step aside, and letting go settles it into its slot.
let k3d = null, k3skip = false;
function kitSort(R) {
  const STEP = 44;                                   // a face and the gap under it
  R.addEventListener("pointerdown", (e) => { const b = e.target.closest("[data-k3n]"); if (b && !e.button) k3d = {b, id: e.pointerId, x0: e.clientX, y0: e.clientY, on: false}; });
  // On the window, not the column: a quick pull sideways leaves the column before the face is held.
  addEventListener("pointermove", (e) => { const d = k3d; if (!d || e.pointerId !== d.id) return;
    const dy = e.clientY - d.y0, dx = e.clientX - d.x0;
    if (!d.on) { if (Math.hypot(dx, dy) < 6) return;
      d.on = true; d.L = [...R.querySelectorAll("[data-k3n]")]; d.i = d.j = d.L.indexOf(d.b);
      d.b.setPointerCapture(e.pointerId); srClose(); R.classList.add("sorting"); d.b.classList.add("drag"); }
    // Pulled sideways it leaves the column, and let go outside the window it becomes a floating card.
    const far = Math.abs(dx) > 28;
    d.out = e.clientX < 0 || e.clientY < 0 || e.clientX > innerWidth || e.clientY > innerHeight;
    d.b.style.transform = `translate(${far ? dx : 0}px,${dy}px)`; d.b.classList.toggle("away", far);
    if (far) { d.j = d.i; d.L.forEach((x) => { if (x !== d.b) x.style.transform = ""; }); return; }
    d.j = Math.max(0, Math.min(d.L.length - 1, d.i + Math.round(dy / STEP)));
    d.L.forEach((x, n) => { if (x === d.b) return;
      const sh = d.i < d.j && n > d.i && n <= d.j ? -STEP : d.i > d.j && n >= d.j && n < d.i ? STEP : 0;
      x.style.transform = sh ? `translateY(${sh}px)` : ""; }); });
  const drop = (e) => { const d = k3d; if (!d || e.pointerId !== d.id) return; k3d = null; if (!d.on) return;
    k3skip = true; setTimeout(() => { k3skip = false; }, 80);          // the click that ends a drag opens nothing
    const names = d.L.map((x) => x.dataset.k3n);
    if (e.type === "pointerup" && d.out) k3Float(d.b);
    if (e.type === "pointerup" && d.j !== d.i) { names.splice(d.j, 0, names.splice(d.i, 1)[0]); k3Sel(names); }
    else d.j = d.i;
    const end = () => { R.classList.remove("sorting"); drawKit(); };
    if (RM()) return end();
    d.b.classList.remove("drag"); d.b.style.transform = `translateY(${(d.j - d.i) * STEP}px)`; setTimeout(end, 200); };
  addEventListener("pointerup", drop); addEventListener("pointercancel", drop);
}
// A face let go outside the window: its conversation goes up as a floating card (floatwin.py).
async function k3Float(b) {
  const key = b.dataset.k3k || "", sid = key.replace(/^[a-z]:/, ""), F = window.GenokFloat;
  if (!sid) return toast(tl("k3.float.none"));
  const q = srRooms().find((x) => x.r.key === key), meta = {name: b.dataset.k3n, title: (q && q.r.title) || b.dataset.k3n, agent: (q && q.r.agent) || "claude"};
  try {
    const r = F && F.set ? await F.set(sid, true, meta) : await post("/api/float/pin", Object.assign({sid, on: true, open: true}, meta));
    toast(!r || r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
  } catch (e) { toast(e.message); }
}
// The sliders at the foot of the column: choose which conversations stand there.
function kitPins() {
  const rm = new Map(srRooms().map((q) => [q.r.dept, q])), PJ = projects(), all = [], seen = new Set();
  const put = (n, icon) => { if (!seen.has(n)) { seen.add(n); all.push({n, icon}); } };
  (k3Sel() || []).forEach((n) => { const q = rm.get(n), g = PJ.find((x) => x.name === n); if (q || g) put(n, (q && q.r.icon) || (g && g.icon) || ""); });
  rm.forEach((q, n) => put(n, q.r.icon)); PJ.forEach((g) => put(g.name, g.icon));
  const live = () => all.filter((x) => rm.get(x.n) && K3LIVE(rm.get(x.n).s)).map((x) => x.n).slice(0, K3MAX);
  let auto = !k3Sel(), pick = auto ? live() : k3Sel().filter((n) => seen.has(n));
  sheet(`<h2 style="margin:0 0 4px">${tl("k3.pins.t")}</h2><p class="hint" style="margin:0 0 10px">${tl("k3.pins.d")}</p>
    <div class="k3ptop"><span class="k3pn num" data-k3cnt></span><span class="sp"></span><button type="button" class="btn sm press" data-k3none>${tl("k3.pins.none")}</button></div>
    <div class="k3pins">${all.map((a) => { const q = rm.get(a.n);
      return `<button type="button" class="k3prow press" role="checkbox" data-k3p="${esc(a.n)}"><span class="ico sm"${k3Col(a.n)}>${k3Face(a.n, a.icon)}</span><span class="t">${esc(pname(a.n))}</span>${k3S(q) ? `<span class="s" data-s="${q.s}">${esc(SR_T[q.s])}</span>` : ""}<i class="k3chk">${ic("check")}</i></button>`; }).join("")}</div>
    <div class="cf-acts"><button class="btn xl fill press" data-k3done>${tl("lib.fil.done")}</button><button class="btn xl press" data-k3auto aria-pressed="false">${tl("k3.pins.auto")}</button></div>`, (el) => {
    const mark = () => { el.querySelectorAll("[data-k3p]").forEach((b) => b.setAttribute("aria-checked", String(pick.includes(b.dataset.k3p))));
      el.querySelector("[data-k3cnt]").textContent = auto ? tl("k3.pins.autoOn") : pick.length + " / " + K3MAX;
      el.querySelector("[data-k3auto]").setAttribute("aria-pressed", String(auto));
      el.querySelector("[data-k3none]").disabled = !pick.length; };
    mark();
    // Press and sweep down the list: every row passed takes the first row's new state.
    let sw = null;
    const set = (n, on) => { if (on === pick.includes(n)) return true;
      if (!on) pick = pick.filter((x) => x !== n);
      else if (pick.length >= K3MAX) return false;
      else pick.push(n);
      auto = false; return true; };
    const list = el.querySelector(".k3pins");
    list.addEventListener("pointerdown", (e) => { const b = e.target.closest("[data-k3p]"); if (!b || e.button) return;
      sw = {on: !pick.includes(b.dataset.k3p), y: e.clientY, moved: false}; });
    list.addEventListener("pointermove", (e) => { if (!sw || e.pointerType === "touch") return;
      if (!sw.moved && Math.abs(e.clientY - sw.y) < 8) return;
      sw.moved = true; const b = document.elementFromPoint(e.clientX, e.clientY)?.closest?.("[data-k3p]");
      if (b && list.contains(b) && set(b.dataset.k3p, sw.on)) mark(); });
    el.addEventListener("pointerup", () => setTimeout(() => { sw = null; })); el.addEventListener("pointercancel", () => { sw = null; });
    list.onclick = (e) => { const b = e.target.closest("[data-k3p]"); if (!b) return;
      if (sw && sw.moved) return;   // the sweep already set it
      const n = b.dataset.k3p;
      if (!set(n, !pick.includes(n))) return toast(tl("k3.pins.max", {n: K3MAX}));
      mark(); };
    el.querySelector("[data-k3none]").onclick = () => { pick = []; auto = false; mark(); };
    el.querySelector("[data-k3auto]").onclick = () => { auto = true; pick = live(); mark(); };
    el.querySelector("[data-k3done]").onclick = () => { k3Sel(auto || !pick.length ? null : pick); closeSheet(); drawKit(); };
  });
}
function drawChrome() {
  drawSrail(); if (LAB3) drawKit();
  // Keyboard: the first Tab offers a jump past the side menu to the page itself.
  const sk = document.getElementById("skip");
  if (sk) sk.textContent = tl("a11y.skip");   // every draw: follows a language switch
  if (sk && !sk.onclick) { sk.onclick = () => { const v = document.getElementById("view"); v.tabIndex = -1; v.focus({preventScroll: true}); }; }
  if (document.querySelector("#rail .sorting")) return;   // a drag in progress keeps its rows
  const todo = todoCount(), news = newsUnread();
  // The tab says it too: the number for 할 것, a dot for unread 소식 only (as on the 받은함 tab).
  const title = todo ? `(${todo}) Genok` : news ? "• Genok" : "Genok";
  if (document.title !== title) document.title = title;
  markIcon(todo, news, badgeCount());
  barBadge(todo);
  document.querySelectorAll("#top [data-bell]").forEach((b) => { const h = bellOnly();      // serialised html never equals its source (attribute order, icons): compare as nodes
    const t = document.createElement("template"); innerSet.call(t, h); if (!t.content.firstElementChild?.isEqualNode(b)) b.outerHTML = h; });
  const on = (k) => !detail && menuKey(cur) === k || detail?.[0] === "item" && k === "lib" || detail?.[0] === "dept" && k === "depts";
  // The 대화 tab carries what its menu row does: how many rooms have a reply not read yet (quiet,
  // the red number is the bell's). A screen that has a tab of its own is not listed again after it.
  const xt = extTabs(), rooms = unreadRooms().length;
  // The 결과물 tab does the same for results: how many sit in 새로 온 것 (the list it opens on).
  const fresh = D.items.filter((x) => stOf(x) === "fresh" && !libHide.has(iid(x))).length;
  const cnt = (k) => k === "project" ? rooms : k === "lib" ? fresh : 0;
  // 전체 (the right end) holds what has no tab of its own: the other screens, extensions, usage, settings.
  const inAll = !detail && (["all", "settings", "depts", "routines", "retro"].includes(menuKey(cur)) || tabExt(xt).some((t) => t.id === cur));
  setHTML(document.getElementById("tabbar"), TABS.map(([k, n, i]) => {
    const lit = k === "all" ? inAll : on(k);
    const c = cnt(k);
    return `<button class="${lit ? "on" : ""}" data-go="${k}"${c ? ` aria-label="${esc(n)} ${c}"` : ""}>${ic(i)}${n}${c ? `<b class="tcnt soft num">${c > 99 ? "99+" : c}</b>` : ""}</button>`; }).join(""));
  const rail = document.getElementById("rail");
  const pj = projects();
  // Extension screens turned off in the menu editor (web/custom.js) are out of the rail too.
  const MH = window.LOOP_MENUHIDE, xr = xt.filter((t) => !MENUS.some((m) => m.k === t.id) && !(MH && MH.ext(t.id)));
  // The projects are one plain row that opens their list (no block of rows in the menu): it carries
  // how many results in them wait to be checked.
  const need = pj.reduce((s, g) => s + g.todo, 0);
  // No wordmark at the top of the menu (the name lives in the window title and 정보): the toggles in the top bar come first.
  setHTML(rail, ""
    // Groups carry no titles: a gap tells them apart. Hiding and restoring entries is in 설정 (사용 방식 > 메뉴).
    + menuGroups().map(([g, L]) => [g, L.filter((m) => !(m.k === "settings" && settingsAtFoot()) && !(m.k === "search" && wide()))]).filter(([, L]) => L.length).map(([g, L]) => `<div class="rgrp" ${g === favTitle() ? `data-sort="favs"` : ""}>` + L.map((m) => {
      const mine = m.k === "project" ? rooms : m.k === "lib" ? fresh : m.k === "depts" ? need : 0;
      return `<button class="it press ${on(m.k) ? "on" : ""} ${m.plan ? "soon" : ""}" data-key="${m.k}" data-go="${m.k}"${m.k === FAV_LOCK ? " data-fixed" : ""}${rn(esc(m.n), mine)}>${menuIco(m, "ri")}<span class="mn">${m.n}</span>${mine ? `<small class="cnt num" title="${esc(m.k === "depts" ? tl("home.g.n", {n: mine}) : m.k === "lib" ? `${tl("st.fresh")} ${mine}` : tl("chrome.unreadRooms", {n: mine}))}">${mine}</small>` : m.plan ? `<small>${tl("chrome.2")}</small>` : ""}${favBtn(m.k, "inrow")}</button>`; }).join("") + "</div>").join("")
    // Extension screens (window.LOOP_TABS) get their own group in the sidebar, routed like the rest.
    + (xr.length ? `<div class="rgrp">` + xr.map((t) => `<button class="it press ${on(t.id) ? "on" : ""}" data-key="${esc(t.id)}" data-go="${esc(t.id)}"${rn(esc(t.label))}><span class="ri">${ic(t.icon)}</span><span class="mn">${esc(t.label)}</span></button>`).join("") + "</div>" : "")
    // The sidebar is folded from the refern-style toolbar toggle (data-railmin) and "[", so the
    // old in-rail "메뉴 접기" text item is gone — one control, no duplicate.
    + `<div class="foot2 railend">${tl("ui.end")}</div>`
    // 설정 is pinned to the foot, away from the rows that get clicked all day; it stays in view
    // while the list above scrolls.
    + (settingsAtFoot() ? `<div class="railfoot"><button class="it press ${on("settings") ? "on" : ""}" data-key="settings" data-go="settings"${rn(tl("TABS.4"))}><span class="ri">${ic("gear")}</span><span class="mn">${tl("TABS.4")}</span></button>${railIco() ? "" : `<button class="railver press num" data-stupd title="${tl("upd.check")}" aria-label="${tl("upd.check")}">${esc(D.ver ? planVer() : "")}</button>`}</div>` : ""));
  rail.querySelectorAll("[data-sort]").forEach((b) => sortable(b, (keys) => reorder(b.dataset.sort, keys), true));
  drawStatus();
}
// The favicon and the installed app's icon carry the same signal: a red dot (and the app badge's
// number) while 할 것 has something, a quieter dot for unread 소식 alone. Drawn only on change.
let iconSvg = null, iconMark = "";
// The app's taskbar button carries 할 것's number too (taskbar.py): told only when it changes.
let barN = -1;
function barBadge(n) { if (!IN_APP || n === barN) return; barN = n; post("/api/taskbar/badge", {n}).catch(() => { barN = -1; }); }
function markIcon(todo, news, badge = todo) {
  const want = todo ? "todo" : news ? "news" : "";
  try { if (navigator.setAppBadge) badge ? navigator.setAppBadge(badge).catch(() => {}) : navigator.clearAppBadge().catch(() => {}); } catch {}
  if (want === iconMark) return; iconMark = want;
  const link = document.querySelector('link[rel="icon"]'); if (!link) return;
  if (!want) { link.href = "/icon.svg"; return; }
  const put = () => { if (iconMark !== want || !iconSvg) return;
    const dot = `<circle cx="206" cy="50" r="${want === "todo" ? 50 : 36}" fill="${want === "todo" ? "#ff3b30" : "#0a84ff"}" stroke="#0b0b0c" stroke-width="12"/>`;
    link.href = "data:image/svg+xml," + encodeURIComponent(iconSvg.replace(/<\/svg>\s*$/, dot + "</svg>")); };
  if (iconSvg) return put();
  fetch("/icon.svg").then((r) => r.ok ? r.text() : null).then((t) => { if (t) { iconSvg = t; put(); } }).catch(() => {});
}
// ---------- 받은함 · 소식: what happened that asks nothing of me ----------
// When 소식 was last opened (the old 알림 marker, same server field): lines after it are unread.
let alertsSeen = ""; try { alertsSeen = localStorage.getItem("v2-alerts-seen") || ""; } catch {}
function seeAlerts(at, tell = true) {
  alertsSeen = at; try { localStorage.setItem("v2-alerts-seen", at); } catch {}
  // The marker lives on the server too (prefs.alerts_seen): read on the phone, read on the PC.
  if (tell && at) post("/api/alerts-seen", {at}).catch(() => {});
}
const after = (at, t) => !t || (at && new Date(at) > new Date(t));
const NEWS_H = 72;                         // hours of 소식 kept in view
const recent = (at, h = NEWS_H) => at && Date.now() - new Date(at) < h * 36e5;
// Read-only: pushes that are not waiting on me (already handled, or put aside), departments
// that took or read a request, sessions that finished or stopped with their last line.
// Whatever needs me is on 할 것 instead, so the two lists never hold the same thing.
function newsList() {
  const todo = new Set(myTurn().map(iid));
  return [
    ...D.items.filter((x) => recent(x.at) && !todo.has(iid(x))).map((x) => ({c:"blue", i:"lib", t:tl("newsList.1", {p0: gname(x), jo: jo(x.v, "를", "을")}), s:`${x.title} · ${stName(x)}`, at:x.at, item:iid(x)})),
    ...D.board.filter((b) => b.state === "delivered" && recent(b.asked)).map((b) => ({c:"grey", i:"check", t:tl("newsList.2", {jo: jo(pname(b.dept), "가", "이")}), s:b.title, at:b.asked, item:iid(b)})),
    // Past "delivered": the session said it read every line, so the fix is under way.
    ...D.board.filter((b) => b.state === "ack" && recent(b.asked)).map((b) => ({c:"green", i:"check", t:tl("newsList.3", {jo: jo(pname(b.dept), "가", "이")}), s:b.title, at:b.asked, item:iid(b)})),
  ].sort((a, b) => (b.at || "").localeCompare(a.at || ""));
}
// A row read on its own (prefs.news_read on the server, so the phone and the PC agree); the
// marker still reads everything before it.
let newsRead = new Set(); try { newsRead = new Set(JSON.parse(localStorage.getItem("v2-news-read") || "[]")); } catch {}
const newsKey = (a) => `${a.item || a.talk || a.t}|${a.at}`;
const newsNew = (a) => after(a.at, alertsSeen) && !newsRead.has(newsKey(a));
function readNews(keys, tell = true) {
  keys.forEach((k) => newsRead.add(k)); try { localStorage.setItem("v2-news-read", JSON.stringify([...newsRead].slice(-400))); } catch {}
  if (tell) post("/api/alerts-seen", {read: keys}).catch(() => {});
}
const newsUnread = () => newsList().filter(newsNew).length;

// ---------- 자리 비운 사이: what happened while I was away, by rules from stored data ----------
// The last moment the app was on screen is kept in this browser and on the server (prefs.seen_at),
// so a look on the phone counts for the PC too. Back after two hours: one line per department.
// Until 다 봤어요 the "since" stays pending, and a bar on home and 받은함 leads back to it.
const AWAY_MS = 2 * 36e5;
const lsGet = (k) => { try { return localStorage.getItem(k) || ""; } catch { return ""; } };
const lsSet = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch {} };
const later = (a, b) => !a ? b : !b ? a : new Date(a) > new Date(b) ? a : b;
let catchSince = lsGet("v2-catch"), awayFrom = "", catchData = null, herePost = 0;
// Heartbeat: this browser every call, the server at most every five minutes (or when forced).
function hereNow(force) {
  if (FLOAT) return;
  const at = new Date().toISOString(); lsSet("v2-seen-at", at);
  if (!force && Date.now() - herePost < 3e5) return; herePost = Date.now();
  fetch("/api/seen-at", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"}, body: JSON.stringify({at})}).catch(() => {});
}
const catchGet = (since) => get("/api/catchup?since=" + encodeURIComponent(since)).then((d) => (catchData = {...d, since}), () => null);
async function awayCheck(last) {
  if (!last || Date.now() - new Date(last) < AWAY_MS) return;
  awayFrom = last;
  // An older unseen stretch still counts: the sheet covers both.
  if (!catchSince || new Date(last) < new Date(catchSince)) { catchSince = last; lsSet("v2-catch", last); }
  const d = await catchGet(catchSince); if (!d) return;
  if (!d.depts.length) return catchDone(true);
  catchRedraw();
  const busy = document.getElementById("sheet").classList.contains("on") || document.activeElement?.matches?.("input,textarea,gk-select") || document.querySelector(".vw,.stk");
  if (!busy) catchOpen();
}
function catchDone(quiet) {
  catchSince = ""; catchData = null; lsSet("v2-catch", ""); hereNow(true);
  if (!quiet) catchRedraw();
}
const catchRedraw = () => { if (!detail && cur === "inbox") SCREENS.inbox(inTab); };
const awayTxt = (t) => { const h = (Date.now() - new Date(t)) / 36e5; return h < 1 ? tl("awayTxt.1") : h < 24 ? tl("awayTxt.2", {p0: Math.round(h)}) : tl("awayTxt.3", {p0: Math.round(h / 24)}); };
const vShort = (v) => { const n = parseInt(String(v).replace(/\D/g, ""), 10); return isNaN(n) ? v : "v" + n; };
const SESS_T = LT(() => ({finished: tl("SESS_T.1"), stopped: tl("SESS_T.2"), blocked: tl("SESS_T.3"), stuck: tl("SESS_T.4")}));
function catchLine(r) {
  const vs = r.versions || [], hot = r.session === "blocked" || r.session === "stuck" || r.asked;
  const bits = [vs.length ? tl("catchLine.2", {p0: vs.slice(-3).map((x) => vShort(x.v)).join("·"), p1: vs.length > 3 ? tl("catchLine.1", {p0: vs.length - 3}) : ""}) : "",
    r.session ? SESS_T[r.session] : "", r.asked ? tl("catchLine.3", {asked: r.asked}) : "", r.claimed ? tl("catchLine.4", {claimed: r.claimed}) : "", r.lint ? tl("catchLine.5", {lint: r.lint}) : ""].filter(Boolean);
  // A session line opens that department's conversation on the project page.
  const go = (hot || !r.item) && r.talk ? roomGo(r.dept, r.talk) : r.item ? "item/" + r.item : "inbox";
  const sub = r.said || [...new Set(vs.map((x) => x.title))].slice(0, 2).join(" · ");
  return `<button class="row press" data-cgo="${esc(go)}"><span class="ico sm c-${hot ? "red" : r.session ? "teal" : "blue"}">${ic(r.talk && !vs.length ? "chat" : "lib")}</span>
    <span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}<span class="cbits">${bits.map((b) => `<i>${esc(b)}</i>`).join("")}</span></div>${sub ? `<div class="s">${esc(sub)}</div>` : ""}</span><span class="chev">${ic("chev")}</span></button>`;
}
async function catchOpen() {
  const since = catchSince || awayFrom || new Date(Date.now() - 8 * 36e5).toISOString();
  const d = catchData?.since === since ? catchData : await catchGet(since);
  if (!d) return toast(tl("catchOpen.1"));
  const L = d.depts;
  sheet(`<h2 style="margin:0 0 4px">${tl("catchOpen.5")}</h2><p class="hint" style="margin:0 0 12px">${awayTxt(since)} · ${L.length ? tl("catchOpen.3", {n: L.length, p1: d.more ? tl("catchOpen.2", {more: d.more}) : ""}) : tl("catchOpen.4")}</p>
    <div class="catchl">${L.map(catchLine).join("")}</div>
    <div class="catchf"><button class="btn press" data-cok>${tl("catchOpen.6")}</button></div>`, (box) => {
    box.querySelectorAll("[data-cgo]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); closeSheet(); nav(b.dataset.cgo); });
    box.querySelector("[data-cok]").onclick = (e) => { e.stopPropagation(); closeSheet(); catchDone(); toast(tl("catchOpen.7"), 2200, "confirm"); };
  });
}
// While a stretch is unseen: a slim bar that reopens it, or closes it for good.
function catchBar() {
  if (!catchSince) return "";
  const n = catchData?.since === catchSince ? catchData.depts.length : 0;
  return `<div class="card catchbar"><span class="ico sm c-blue">${ic("clock")}</span><span class="tx"><div class="t">${tl("catchOpen.5")}</div><div class="s">${awayTxt(catchSince)}${n ? tl("catchBar.1", {n}) : ""}</div></span>
    <button class="btn sm press" data-catch>${tl("catchBar.2")}</button><button class="btn sm weak press" data-catchok>${tl("catchOpen.6")}</button></div>`;
}
const dueDi = (x) => { const di = dueInfo(x.due); return di ? ` · <b class="opn${di.over ? " over" : ""}">${di.label}</b>` : ""; };
// A meta line as pieces: where it wraps (a phone), no line starts or ends with the dot between them.
const mline = (parts) => `<span class="mlw">${parts.filter(Boolean).map((t) => `<span class="mlp">${t}</span>`).join("")}</span>`;
// lean: a list that already says the project and the unsent comments elsewhere leaves both out.
// Every result is in one project: rows need not name it.
const oneProj = () => new Set(D.items.map(gname)).size === 1;
const itemRow = (x, btn = true, lean = {}) => `<button class="row press" data-item="${esc(iid(x))}">${thumb(x)}<span class="tx"><div class="t">${justIn(x) ? `<em class="jin">${tl("ago.2")}</em>` : ""}${esc(x.title)}</div>
  <div class="s ml">${mline([lean.proj ? "" : deptMark(gname(x)) + esc(pname(gname(x))), esc(x.v), ago(x.at), x.open ? `<b class="opn">${tl("open.1", {n: x.open})}</b>` : "", dueDi(x).slice(3), x.comments && !lean.note?.has(iid(x)) ? noteTag(x).slice(3) : ""])}</div></span>${btn ? (x.new ? `<span class="btn weak">${tl("itemRow.1")}</span>` : `<span class="btn">${tl("itemRow.2")}</span>`) : ""}</button>`;
// Hub rules a push broke (push_review "lint"): an orange tag on the card and the item header;
// tapping it lists them. A span, since it sits inside the card's own button.
const LINTS = {};
const lintTag = (key, lint) => { if (!lint?.length) return ""; LINTS[key] = lint;
  return `<span class="tag lint press" role="button" tabindex="0" data-lint="${esc(key)}" title="${tl("lintTag.1")}">${tl("lintTag.2", {n: lint.length})}</span>`; };
const lintOpen = (e) => { const b = e.target.closest?.("[data-lint]"); if (!b || (e.type === "keydown" && e.key !== "Enter" && e.key !== " ")) return;
  e.preventDefault(); e.stopPropagation();
  sheet(`<h2 style="margin:0 0 4px">${tl("lintTag.1")}</h2><p class="hint" style="margin:0 0 12px">${tl("lintOpen.1")}</p>
    ${(LINTS[b.dataset.lint] || []).map((x) => `<div class="row"><span class="ico sm c-orange">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(x.msg)}</div></span></div>`).join("")}`, () => {}); };
document.addEventListener("click", lintOpen, true);
// The item's status chip opens its one-line reason (a phone has no tooltip).
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-stwhy]"); if (!b) return;
  const l = b.closest(".htitle")?.querySelector(".stwhy"); if (!l) return; l.hidden = !l.hidden; b.setAttribute("aria-expanded", !l.hidden); });
document.addEventListener("keydown", lintOpen, true);
const rs = (t) => { const hr =(t*1000 - Date.now()) / 36e5; return hr < 1 ? tl("rs.1") : hr < 24 ? tl("rs.2", {p0: Math.round(hr)}) : tl("rs.3", {p0: Math.round(hr/24)}); };

const SCREENS = {};
// Extension screens (window.LOOP_TABS, see web/tabs.js). They route by hash exactly like a
// built-in screen: each is registered into SCREENS so the router, the 30s background redraw
// and the rail/tabbar treat it the same. A built-in id is never overwritten.
const extTabs = () => (typeof window.loopTabs === "function" ? window.loopTabs() : []);
// The phone tab bar's share of them: all but the ones that already stand there as a tab (대화)
// and the ones turned off in the menu editor (web/custom.js); search still opens those.
const tabExt = (xt) => xt.filter((t) => !TABS.some(([k]) => k === t.id) && !window.LOOP_MENUHIDE?.ext(t.id));
function syncExtTabs() {
  extTabs().forEach((t) => {
    if (SCREENS[t.id]) return;                 // never shadow a built-in screen
    SCREENS[t.id] = () => {
      const el = V();
      // A screen that keeps its own page up (t.keeps): it brings what is there up to date, on a
      // refresh and on a move inside it alike. Nothing is cleared, so nothing enters a second time.
      if (t.keeps && t.keeps(el)) { el.classList.add("still"); try { return t.draw(el.firstElementChild); } catch (e) { console.error(e); } return; }
      // A refresh keeps what is shown until the extension has its new data (see holdWrites).
      if (softN > 0 && el.firstElementChild) return holdWrites(el, () => t.draw(el), (w) => { const st = viewState(); w(); restoreView(st); });
      el.innerHTML = ""; try { t.draw(el); } catch (e) { console.error(e); }
    };
  });
}
// A project is the name its results were pushed under; its newest push dates it.
const projects = () => { const G = new Map();
  D.items.forEach((x) => { const n = gname(x); if (!G.has(n)) G.set(n, {name: n, icon: x.icon || "", items: []}); G.get(n).items.push(x); });
  return [...G.values()].map((g) => ({...g, at: g.items.map((x) => x.at || "").sort().pop() || "",
    todo: g.items.filter(stMine).length})).sort((a, b) => b.at.localeCompare(a.at)).sort(byPjOrder); };
// The person's own project order (dragged on the project list), kept on this device. Projects not in
// it yet follow, newest first.
const pjOrder = (v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem("v2-pjorder") || "[]"); localStorage.setItem("v2-pjorder", JSON.stringify(v)); } catch { return []; } };
const byPjOrder = (a, b) => { const po = pjOrder(), at = (g) => { const i = po.indexOf(g.name); return i < 0 ? 1e6 : i; }; return at(a) - at(b); };
// Project rows inside box are put in order by dragging (mouse; touch keeps scrolling) or Alt+Up/Down.
// The moved names take the slots they already held in the whole order, so a searched or pinned
// subset moves only among itself and the archived ones stay where they were. The rows ride springs
// (motion.js, C9); custom.js's dragSort stands in when that is missing. redraw repaints the list.
function pjSort(box, sel, redraw) {
  const done = (names) => { const it = names[Symbol.iterator](), at = document.activeElement?.dataset?.dept;
    pjOrder(projects().map((g) => names.includes(g.name) ? it.next().value : g.name)); redraw();
    if (at) [...document.querySelectorAll(sel)].find((r) => r.dataset.dept === at)?.focus(); };
  if (window.Motion?.sort) Motion.sort(box, sel, done, (el) => el.dataset.dept);
  else if (window.LOOP_DRAGSORT) window.LOOP_DRAGSORT(box, sel, "y", done);
}
// ---------- 홈: one line of greeting, what waits to be checked, who is working ----------
// Calm on purpose (picked 2026-10-03). Recent results live on 결과물, activity on 사용량, plan and
// version in the status line and 설정, search in the top bar; home repeats none of them.
const greetKind = () => { const h = new Date().getHours(); return h < 5 ? "night" : h < 12 ? "morning" : h < 18 ? "afternoon" : "evening"; };
// ---------- 홈 > 활동: per-day counts (GET /api/activity), read once a minute at most ----------
const ACT = {val: null, at: 0, req: null};
function getAct() {
  if (ACT.val && Date.now() - ACT.at < 60000) return Promise.resolve(ACT.val);
  return ACT.req = ACT.req || get("/api/activity").then((v) => { ACT.val = v; ACT.at = Date.now(); return v; })
    .catch(() => ACT.val).finally(() => { ACT.req = null; });
}
const actRange = () => ["7", "30"].includes(lsGet("v2-homeact")) ? lsGet("v2-homeact") : "182";
const actNum = (n) => n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + "M" : n >= 1e4 ? Math.round(n / 1e3) + "K" : Number(n || 0).toLocaleString();
const actDate = (ds) => new Date(ds + "T00:00:00").toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {year: "numeric", month: "short", day: "numeric", weekday: "short"});
function drawAct(host, page) {
  const el = host || document.getElementById("homeact"), a = ACT.val; if (!el) return;
  // Nothing recorded yet: no block at all rather than a grid of empty squares.
  if (!a || !a.days || (!a.days.some((d) => d.m + d.r + d.c) && a.claude !== "scanning")) { el.hidden = true; el.innerHTML = ""; return; }
  const on = a.claude === "ok", rg = page ? "182" : actRange(), R = a.ranges[rg] || {};
  // "Active days" out of the days there is any record for (R.span), not out of the whole range.
  const act = R.span ? tl("home.act.of", {a: R.active, n: R.span}) : R.active;
  const stats = on && page
    ? [[tl("home.act.results"), actNum(R.results)], [tl("home.act.checks"), actNum(R.checks)], [tl("home.act.sessions"), actNum(R.sessions)],
       [tl("home.act.msgs"), actNum(R.messages)], [tl("home.act.active"), act], [tl("home.act.peak"), R.peak == null ? "—" : tl("home.act.hour", {h: R.peak})]]
    : on
    ? [[tl("home.act.sessions"), actNum(R.sessions)], [tl("home.act.msgs"), actNum(R.messages)],
       [tl("home.act.tokens"), actNum(R.tokens), tl("home.act.tokens.tip")], [tl("home.act.active"), act],
       [tl("home.act.peak"), R.peak == null ? "—" : tl("home.act.hour", {h: R.peak})], [tl("home.act.results"), actNum(R.results)]]
    : [[tl("home.act.results"), actNum(R.results)], [tl("home.act.checks"), actNum(R.checks)], [tl("home.act.active"), act]];
  // Up to 26 columns of weeks (Monday on top), the last one holding today. The map starts at the
  // week of the first day on record (a.since): the weeks before it are not drawn, since nothing
  // is known about them, and a day before it inside that week is left blank. A day's weight is
  // what was done on it: messages sent + results pushed + results checked (a day known only by
  // its session count still counts as active).
  const by = new Map(a.days.map((d) => [d.d, d])), val = (d) => d ? d.m + d.r + d.c || (d.s ? 1 : 0) : 0;
  const iso = (t) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
  const today = new Date(a.today + "T00:00:00"), start = new Date(today);
  start.setDate(start.getDate() - ((today.getDay() + 6) % 7) - 25 * 7);
  const first = a.since ? new Date(a.since + "T00:00:00") : null, short = !!first && first > start;
  let W = 26;
  if (short) { const mon = new Date(first); mon.setDate(mon.getDate() - ((first.getDay() + 6) % 7));
    W = Math.max(1, Math.round((today - mon) / 6048e5 - ((today.getDay() + 6) % 7) / 7) + 1); start.setTime(mon.getTime()); }
  const old = (i) => i < (W - 16) * 7 ? " old" : "";        // a phone shows the last 16 weeks
  const whole = short ? tl("home.act.since", {d: `${first.getMonth() + 1}/${first.getDate()}`}) : tl("home.act.rall");
  const since = new Date(today); since.setDate(since.getDate() - (+rg - 1));
  const vals = a.days.map(val).filter(Boolean).sort((x, y) => x - y), q = (f) => vals[Math.min(vals.length - 1, Math.floor(vals.length * f))] || 0;
  const cut = [q(.25), q(.5), q(.75)], lvl = (v) => !v ? 0 : v <= cut[0] ? 1 : v <= cut[1] ? 2 : v <= cut[2] ? 3 : 4;
  let cells = "";
  for (let i = 0; i < W * 7; i++) {
    const t = new Date(start); t.setDate(t.getDate() + i);
    const ds = iso(t), d = by.get(ds);
    cells += t > today || (first && t < first) ? `<i class="hc no${old(i)}"></i>`
      : `<i class="hc l${lvl(val(d))}${t < since ? " dim" : ""}${old(i)}" data-d="${ds}"></i>`;
  }
  const src = a.claude === "scanning" ? tl("home.act.src.scan") : !on ? tl("home.act.src.off") : short ? tl("home.act.src.since") : "";   // the usual case needs no line: it is the label's hint
  el.hidden = false;
  el.innerHTML = `<div class="rechead"><div class="hlab" title="${tl("home.act.src.ok")}">${tl("home.act")}</div><span class="sp"></span>
      ${page ? `<span class="hspan">${whole}</span>` : `<div class="seg hseg" role="group" aria-label="${tl("home.act")}">${[["7", tl("home.act.r7")], ["30", tl("home.act.r30")], ["182", whole]].map(([k, n]) => `<button class="press${k === rg ? " on" : ""}" data-actr="${k}" aria-pressed="${k === rg}">${n}</button>`).join("")}</div>`}</div>
    <div class="hact">
      <div class="hstats n${stats.length}">${stats.map(([k, v, tip]) => `<div class="hsv"${tip ? ` title="${esc(tip)}"` : ""}><div class="k">${k}</div><div class="v num">${v}</div></div>`).join("")}</div>
      <div class="hmapw"><div class="hmap" tabindex="0" role="group" aria-label="${tl("home.act.map")}"${W < 26 ? ` style="max-width:${W * 17}px"` : ""}>${cells}</div>
        <div class="hleg"><span class="htip" aria-live="polite"></span><span class="sp"></span>${tl("home.act.less")}<i class="hc l0"></i><i class="hc l1"></i><i class="hc l2"></i><i class="hc l3"></i><i class="hc l4"></i>${tl("home.act.more")}</div></div>
    </div>
    ${src ? `<div class="hsrc">${src}${a.claude === "off" && typeof SCREENS.usage === "function" ? ` <button class="lnk press" data-go="usage">${tl("home.act.enable")}</button>` : ""}</div>` : ""}`;
  el.querySelectorAll("[data-actr]").forEach((b) => b.onclick = () => { lsSet("v2-homeact", b.dataset.actr); drawAct(host, page); el.querySelector(`[data-actr="${b.dataset.actr}"]`)?.focus(); });
  // One day at a time under the pointer or the arrow keys; its date and counts show in the line
  // under the map (no floating box to chase).
  const map = el.querySelector(".hmap"), tip = el.querySelector(".htip"), all = [...map.querySelectorAll(".hc[data-d]")];
  let at = -1;
  const show = (i) => { all[at]?.classList.remove("at"); at = i; const c = all[i]; if (!c) { tip.textContent = ""; return; }
    c.classList.add("at"); const d = by.get(c.dataset.d);
    const parts = d ? [on && (d.m || !d.s ? tl("home.act.tip.m", {n: d.m}) : tl("home.act.tip.s", {n: d.s})), tl("home.act.tip.r", {n: d.r}), tl("home.act.tip.c", {n: d.c})].filter(Boolean).join(" · ") : tl("home.act.tip.none");
    tip.textContent = `${actDate(c.dataset.d)} · ${parts}`; };
  map.onpointermove = (e) => { const i = all.indexOf(e.target); if (i >= 0 && i !== at) show(i); };
  map.onpointerleave = () => { if (document.activeElement !== map) show(-1); };
  map.onfocus = () => { if (at < 0) show(all.length - 1); };
  map.onblur = () => show(-1);
  map.onkeydown = (e) => { const step = {ArrowLeft: -7, ArrowRight: 7, ArrowUp: -1, ArrowDown: 1}[e.key]; if (!step) return;
    e.preventDefault(); const lo = all.findIndex((c) => c.offsetParent !== null); show(Math.max(lo, Math.min(all.length - 1, (at < 0 ? all.length - 1 : at) + step))); };
  if (a.claude === "scanning") setTimeout(() => { if (el.isConnected && (host || (cur === "home" && !detail))) { ACT.at = 0; getAct().then(() => drawAct(host, page)); } }, 4000);
}
// Sessions working right now (attention rooms; empty until reading sessions is allowed), newest first.
const workingRooms = () => attL("rooms").filter((r) => r.job === "working").sort((a, b) => (Date.parse(b.active) || 0) - (Date.parse(a.active) || 0));
const workRows = (W, cap) => W.slice(0, cap).map((r) => `<button class="row press" data-go="${esc(roomGo(r.dept, r.key))}">${deptIco(r, "ico sm")}<span class="tx"><div class="t">${esc(pname(r.dept))}</div><div class="s">${esc(r.said || (r.agent === "codex" ? "Codex" : "Claude"))}</div></span><span class="hwt num">${ago(r.active)}</span></button>`).join("")
  + (W.length > cap ? `<button class="row press todomore" data-go="sessions"><span class="tx"><div class="s">${tl("home.v.more", {n: W.length - cap})}</div></span>${ic("chev", "i go")}</button>` : "");
// 진행 on home: who is at work, as small tiles (a name and how long ago). What each one last said
// is in its chat: a column of those sentences made the page a wall of text.
const workTiles = (W, cap) => W.slice(0, W.length > cap ? cap - 1 : cap).map((r) => `<button class="hwtile press" data-go="${esc(roomGo(r.dept, r.key))}">${deptIco(r, "ico sm")}<span class="tx"><span class="t">${esc(pname(r.dept))}</span><span class="s num">${ago(r.active)}</span></span></button>`).join("")
  + (W.length > cap ? `<button class="hwtile more press" data-go="sessions"><span class="tx"><span class="t">${tl("home.v.more", {n: W.length - cap + 1})}</span></span>${ic("chev", "i go")}</button>` : "");
// What waits to be checked, as results: questions first, then results not looked at yet (the same
// two lists 내 차례 shows).
const homeChecks = () => { const T = todoSecs(), of = (k) => T.find((s) => s.k === k).L;
  return [...of("ask").flatMap((g) => g.items).sort(byAt).map((x) => ({x, ask: 1})), ...of("look").map((x) => ({x}))]; };
// One result on home: a small picture, its title, one quiet line. The first stands alone and a
// little larger (homeLead); the next three are rows in one card. A status is said only where it
// asks for something.
const homeThumb = (x) => `<span class="hth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.kind === "video" ? `<span class="htp">${ic("play")}</span>` : ""}</span>`;
const homeWhere = (x) => `${esc(pname(gname(x)))} · ${ago(x.at)}`;
// What waits, as tiles of one size (the same shape as the work tiles below): a name and one short
// word under it, nothing else. At most `cap`, the last giving way to "N more" in 알림. The agent
// mark line (badges.js) is left off a result's tile: data-bdg.
const waitTile = (go, lead, t, s) => `<button class="hwtile press" data-tk ${go}>${lead}<span class="tx"><span class="t">${esc(t)}</span><span class="s">${s}</span></span></button>`;
// `one`: every tile is from the same project, so its name under each says nothing - the age does.
const checkTile = (c, one) => waitTile(`data-item="${esc(iid(c.x))}" data-bdg="1"`, homeThumb(c.x), c.x.title, c.ask ? `<b class="pending">${tl("home.v.answer")}</b>` : one ? ago(c.x.at) : esc(pname(gname(c.x))));
// The first result that waits, large: its picture, its name, and the three things one does with it
// (decide, look, put off) without opening it first. A question is answered inside, so it only opens.
const homeHero = (c) => `<div class="hhero"><button class="hhero-pv press" data-item="${esc(iid(c.x))}" aria-label="${esc(c.x.title)}">${homeThumb(c.x)}</button>
  <div class="hhero-tx"><span class="k">${tl("nextCard.3")}</span><span class="t">${esc(c.x.title)}</span><span class="s">${homeWhere(c.x)}</span>
  <div class="hhero-acts">${c.ask ? `<button class="btn fill press" data-item="${esc(iid(c.x))}">${tl("askCard.4")}</button>` : `<button class="btn fill press" data-happ="${esc(iid(c.x))}">${tl("STATUS_T.4")}</button><button class="btn press" data-item="${esc(iid(c.x))}">${tl("search.3")}</button>`}<button class="btn weak press hhero-later" data-later="${esc(iid(c.x))}">${tl("palActs.2")}</button></div></div></div>`;
const waitTiles = (L, cap) => L.slice(0, L.length > cap ? cap - 1 : cap).join("")
  + (L.length > cap ? `<button class="hwtile more press" data-go="inbox"><span class="tx"><span class="t">${tl("home.rest", {n: L.length - cap + 1})}</span></span>${ic("chev", "i go")}</button>` : "");
const homeRow = (c, tk = true) => `<button class="hrow press"${tk ? " data-tk" : ""} data-item="${esc(iid(c.x))}">${homeThumb(c.x)}<span class="tx"><span class="t">${esc(c.x.title)}</span><span class="s">${homeWhere(c.x)}</span></span>${c.ask ? `<span class="hst pending">${tl("home.v.answer")}</span>` : ""}</button>`;
// A session that cannot go on without the person (a permission, a question) comes first: it is
// the shortest thing to clear and an agent sits idle until it is.
const homeNeed = (a) => waitTile(`data-go="${esc(roomGo(a.dept, a.session))}"`, deptIco(attL("rooms").find((r) => r.key === a.session) || a, "ico sm"), pname(a.dept), `<b class="pending">${a.needs === "permission prompt" ? tl("home.v.allow") : tl("home.v.answer")}</b>`);
// 사용량 screen: the 26-week block home used to carry (web/usage.js calls this after it paints).
window.LOOP_ACT_SEC = (root) => {
  if (!root || root.querySelector(".hactsec")) return;
  const el = document.createElement("section"); el.className = "hactsec"; el.hidden = true; root.appendChild(el);
  if (ACT.val) drawAct(el, true);
  getAct().then(() => { if (el.isConnected) drawAct(el, true); });
};
// A row on home that opens a page of 설정 (the empty home's 연결 확인하기).
document.addEventListener("click", (e) => {
  const s = e.target.closest?.("[data-homeset]");
  if (s) { setPage = s.dataset.homeset; setShowPage = true; location.hash = "#settings"; }
});
SCREENS.home = function () {
  const name = D.profile_name || "", items = D.items || [];
  const C = homeChecks(), W = workingRooms(), B = todoSecs().find((s) => s.k === "blocked").L, n = C.length + B.length, num = `<b class="num">${n}</b>`;
  // literal keys (not built by concatenation) so the i18n test sees every key used
  const g = {night: tl("ui.greet.night"), morning: tl("ui.greet.morning"), afternoon: tl("ui.greet.afternoon"), evening: tl("ui.greet.evening")}[greetKind()];
  // The greeting is the count. With nothing pushed yet there is nothing to count: a plain hello.
  const greet = !items.length ? (name ? tl("ui.greet.name", {name: esc(name), g: g}) : g)
    : n ? (name ? tl("home.g.n.name", {name: esc(name), n: num}) : tl("home.g.n", {n: num}))
    : name ? tl("home.g.none.name", {name: esc(name)}) : tl("home.g.none");
  // What waits: up to four tiles, the rest one tap away in 알림.
  // Nothing waits: the three newest results take the place, so the page is never a bare line.
  const rest = B.map(homeNeed).concat(C.slice(1).map((c) => checkTile(c, oneProj())));
  // The board (lab): what to check next beside what else waits, then the newest results beside the counts.
  const lead = C.length ? iid(C[0].x) : "", R = items.slice().sort(byAt).filter((x) => iid(x) !== lead);
  const dCard = (x, cls = "") => `<button class="dcard${cls} press" data-item="${esc(iid(x))}">${homeThumb(x)}<span class="cap"><b>${esc(x.title)}</b><span>${homeWhere(x)}</span></span></button>`;
  const side = rest.length ? waitTiles(rest, 3) : R.slice(C.length ? 0 : 1, C.length ? 3 : 4).map((x) => checkTile({x}, oneProj())).join("");
  const cards = R.slice(side && !rest.length ? (C.length ? 3 : 4) : C.length ? 0 : 1).slice(0, 4);
  const sum = (num, name, go) => `<button class="dsc press" data-go="${go}"><span class="k">${name}</span><b class="num">${num}</b></button>`;
  const stat = `<div class="dsum">${sum(n, tl("home.now.wait"), "inbox")}${sum(C.length, tl("home.now.check"), "inbox")}${sum(B.length, tl("SESS_T.3"), "inbox")}${sum(W.length, tl("st.work"), "project")}</div>`;
  // Lab 3: the kit's dashboard markup itself (kit-d2.css), filled with what waits and the newest results.
  const d2img = (x, cls) => x && x.thumb ? `<img class="${cls}" src="${esc(x.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : "";
  const d2st = (attr, lead, t, s) => `<button class="d2-stacked-item press" ${attr}><span class="d2-stacked-left"><span class="d2-stacked-thumb">${lead}</span><span class="d2-stacked-info"><span class="d2-stacked-title">${esc(t)}</span><span class="d2-stacked-sub">${s}</span></span></span>${ic("chev", "i d2-stacked-arrow")}</button>`;
  const d2res = (x) => d2st(`data-item="${esc(iid(x))}"`, homeThumb(x), x.title, homeWhere(x));
  const H3 = C.length ? C[0] : items.length ? {x: items.slice().sort(byAt)[0]} : null;
  const used3 = new Set(C.map((c) => iid(c.x)).concat(H3 ? [iid(H3.x)] : []));
  const R3 = items.slice().sort(byAt).filter((x) => !used3.has(iid(x)));
  const st3 = B.map((a) => d2st(`data-go="${esc(roomGo(a.dept, a.session))}"`, deptIco(a, "ico sm"), pname(a.dept), a.needs === "permission prompt" ? tl("home.v.allow") : tl("home.v.answer"))).concat(C.slice(1).map((c) => d2res(c.x)));
  // Fewer than three wait: the sessions at work stand there, each one press from its chat. An old
  // result as filler read like a second "recent" list.
  const held = new Set(B.map((a) => a.dept)), W3 = W.filter((w) => !held.has(w.dept)), nW = Math.max(0, Math.min(3 - st3.length, W3.length));
  W3.slice(0, nW).forEach((w) => st3.push(d2st(`data-go="${esc(roomGo(w.dept, w.key))}"`, deptIco(w, "ico sm"), pname(w.dept), `${tl("st.work")} · ${ago(w.active)}`)));
  const Wb = W3.slice(nW);
  // Still short of three: the newest results, newest first.
  while (st3.length < 3 && R3.length) st3.push(d2res(R3.shift()));
  const board3 = !H3 ? "" : `<div class="d2-row-upper"><section class="d2-hero-card"><div class="d2-hero-glow"></div>
      <div class="d2-hero-top-bar"><div class="d2-hero-badges"><span class="d2-popular-pill">${C.length ? tl("nextCard.3") : tl("ui.recent")}</span></div>${C.length > 1 ? `<div class="d2-carousel-dashes">${C.slice(0, 3).map((c, i) => `<span class="d2-dash${i ? "" : " active"}"></span>`).join("")}</div>` : ""}</div>
      <div class="d2-hero-content"><h2 class="d2-hero-title">${esc(H3.x.title)}</h2><p class="d2-hero-desc">${homeWhere(H3.x)}</p>
        <div class="d2-social-proof">${C.length && !H3.ask ? `<button class="d2-reviews-pill press" data-happ="${esc(iid(H3.x))}">${tl("STATUS_T.4")}</button>` : ""}<button class="d2-reviews-pill d2-ghost press" data-item="${esc(iid(H3.x))}">${H3.ask ? tl("askCard.4") : tl("search.3")}</button></div></div>
      <div class="d2-hero-character-wrap">${d2img(H3.x, "d2-hero-character-img")}</div></section>
      <div class="d2-stacked-list">${st3.slice(0, 3).join("")}</div></div>
    ${(() => { const L = Wb.slice(0, 3), x = L.length ? null : R3[0] || null; if (!L.length && !x) return "";
      const bar = (attr, lead, t, sub, at, more) => `<button class="d2-downloads-bar press" ${attr}><span class="d2-download-glow-wave"></span><span class="d2-download-left"><span class="d2-fifa-icon-box">${lead}</span><span class="d2-fifa-meta"><span class="d2-fifa-title">${esc(t)}</span><span class="d2-fifa-tag">${sub}</span></span></span>
        <span class="d2-download-right"><span class="d2-download-progress-text"><span class="d2-download-time num">${at}</span>${more ? `<span class="d2-download-size">+${more}</span>` : ""}</span><span class="d2-download-actions"><span class="d2-dl-close-btn">${ic("chev")}</span></span></span></button>`;
      return `<div class="d2-row-bottom"><div class="d2-section-head"><h3 class="d2-section-title">${L.length ? tl("st.work") : tl("TABS.3")}</h3><button type="button" class="d2-see-more" data-go="${L.length ? "project" : "lib"}">${tl("ui.viewall")}</button></div>
      <div class="k3bars">${L.length ? L.map((w, i) => bar(`data-go="${esc(roomGo(w.dept, w.key))}"`, deptIco(w, "d2-fifa-ico"), pname(w.dept), tl("st.work"), ago(w.active), i === L.length - 1 ? Wb.length - L.length : 0)).join("")
        : bar(`data-item="${esc(iid(x))}"`, homeThumb(x), x.title, homeWhere(x), ago(x.at), 0)}</div></div>`; })()}`;
  const board = items.length ? `<div class="drow">${C.length ? homeHero(C[0]) : dCard(R[0], " big")}${side ? `<div class="dstack">${side}</div>` : ""}</div>
      ${stat}
      <section class="dnew"><div class="rechead"><h2 class="hsub">${tl("ui.recent")}</h2><span class="sp"></span><button class="lnk press" data-go="lib">${tl("ui.viewall")}</button></div>
        <div class="dcards">${cards.map((x) => dCard(x)).join("")}</div></section>`
    : `<div class="homeempty"><p>${tl("ui.home.empty")}</p><button class="btn sm press" data-homeset="connect">${tl("home.empty.go")}</button></div>`;
  const top = LAB3 ? (items.length ? board3 : board) : n ? `${C.length ? homeHero(C[0]) : ""}${rest.length ? `<div class="hwtiles${rest.length < 3 ? " few" : ""}">${waitTiles(rest, 4)}</div>` : ""}`
    : items.length ? `<div class="rechead"><h2 class="hsub">${tl("ui.recent")}</h2><span class="sp"></span><button class="lnk press" data-go="lib">${tl("ui.viewall")}</button></div>
      <div class="card hlist">${items.slice().sort(byAt).slice(0, 3).map((x) => homeRow({x}, false)).join("")}</div>`
    : `<div class="homeempty"><p>${tl("ui.home.empty")}</p><button class="btn sm press" data-homeset="connect">${tl("home.empty.go")}</button></div>`;
  // A narrow window has no sidebar: the way to the projects is one row here (hidden where the sidebar shows).
  const pj = projects();
  V().innerHTML = `<div class="home${LAB3 && items.length ? " d2-main-area d2home" : ""}">
    ${LAB3 && items.length ? `<header class="d2-header"><h1 class="d2-header-greeting">${greet}</h1><div class="d2-header-center"><button class="d2-search-bar press" data-go="search">${ic("search")}<span class="d2-search-input">${tl("MENUS.5")}</span><kbd>${tl("ui.ctrlk")}</kbd></button></div><div class="d2-header-right"><button type="button" class="d2-head-icon-btn" data-sync title="${esc(tl("ui.tb.refresh"))}" aria-label="${esc(tl("ui.tb.refresh"))}">${ic("sync")}</button><button type="button" class="d2-head-icon-btn" data-bell data-go="inbox" title="${esc(tl("TABS.1"))}" aria-label="${esc(tl("TABS.1"))}">${ic("bell")}${todoCount() ? `<span class="d2-head-dot"></span>` : ""}</button></div></header>` : LAB3 && items.length ? `<div class="dhead"><h1 class="greet">${greet}</h1><button class="dsearch press" data-go="search">${ic("search")}<span>${tl("MENUS.5")}</span><kbd>${tl("ui.ctrlk")}</kbd></button></div>` : `<h1 class="greet">${greet}</h1>`}
    <div id="homerec">${top}</div>
    ${LAB3 && items.length ? "" : W.length ? `<div class="rechead"><h2 class="hsub">${tl("st.work")}<b class="num">${W.length}</b></h2></div><div class="hwtiles${LAB3 ? " dwork" : ""}">${workTiles(W, 4)}</div>` : ""}
    ${LAB3 && items.length ? "" : pj.length ? `<button class="card hrow hpjr press" data-go="depts"><span class="ico sm c-grey">${ic("folders")}</span><span class="tx"><span class="t">${esc(unitWord())}<b class="num">${pj.length}</b></span></span>${ic("chev", "i go")}</button>` : ""}
  </div>`;
  V().querySelector("[data-happ]")?.addEventListener("click", () => approveMany([C[0].x]));
  const pc = permCard() + (window.LOOP_HOME_FIRST ? window.LOOP_HOME_FIRST() : "") + fixCard(), hm = pc && V().querySelector(".home"), hd = hm && hm.querySelector(".d2-header");
  if (hd) hd.insertAdjacentHTML("afterend", pc); else if (hm) hm.insertAdjacentHTML("afterbegin", pc);
  triMark();
  // First-run / empty-state track fills the empty home via this hook.
  if (!items.length && typeof window.LOOP_HOME_EMPTY === "function") {
    // The first-use card (3 steps + the line to paste into a session) comes back as HTML. The
    // hook's "nothing to do" card is not for here.
    try {
      const html = window.LOOP_HOME_EMPTY(document.getElementById("homerec"));
      if (typeof html === "string" && html.includes('class="card oh"')) {
        const rec = document.getElementById("homerec");
        rec.innerHTML = html; V().querySelector(".home").classList.add("first");
      }
    } catch (e) { console.error(e); }
  }
};
// ---------- right info panel (refern's OVERVIEW column), per screen ----------
// ---------- 회고: one week at a glance, paged back a week at a time ----------
const retroLabel = (n) => n === 0 ? tl("day.week") : n === 1 ? tl("retro.last") : tl("retro.ago", {n});
const mdShort = (t) => new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "long", day: "numeric"});
SCREENS.retro = function () {
  const end = Date.now() - retroWk * 7 * 864e5, start = end - 7 * 864e5;
  const inWk = (x) => x.at && new Date(x.at) > start && new Date(x.at) <= end;
  const done = D.items.filter((x) => x.status === "approved" && inWk(x)).sort(byAt);
  const asked = D.items.filter((x) => x.status === "changes" && inWk(x)).sort(byAt);
  const made = D.items.filter(inWk);
  const by = {}; made.forEach((x) => { const k = gname(x); by[k] = (by[k] || 0) + 1; });
  const depts = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 8), top = depts[0]?.[1] || 1;
  const none = `<div class="fun">${tl("retro.none", {wk: retroLabel(retroWk)})}</div>`;
  V().innerHTML = `<div class="wknav"><button class="ib press" data-wk="1" aria-label="${tl("retro.prev")}">${ic("back")}</button>
      <div class="wkl"><b>${retroLabel(retroWk)}</b><span>${mdShort(start + 864e5)} – ${mdShort(end)}</span></div>
      <button class="ib press" data-wk="-1" aria-label="${tl("retro.next")}" ${retroWk === 0 ? `disabled title="${tl("retro.next.none")}"` : ""}>${ic("chev")}</button></div>
    <div class="grid2">
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.ok", {wk: retroLabel(retroWk)})}</div><div class="v num" style="font-size:28px">${done.length}</div><div class="s">${tl("retro.of", {n: made.length})}</div></span></div></div>
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.changes")}</div><div class="v num" style="font-size:28px">${asked.length}</div><div class="s">${asked.length ? tl("retro.fixing") : tl("retro.clear")}</div></span></div></div></div>
    <div class="card"><div class="ch"><h2>${tl("retro.bydept")}</h2></div><div class="bars">${depts.map(([n, c]) => `<div class="bar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(pname(n))}</span><span class="tr"><i style="width:${c / top * 100}%"></i></span><span class="num">${c}</span></div>`).join("") || none}</div></div>
    <div class="card"><div class="ch"><h2>${tl("retro.done")}</h2><span class="n num">${done.length}</span></div>${done.slice(0, 12).map((x) => itemRow(x, false)).join("") || none}<div style="height:8px"></div></div>
    ${asked.length ? `<div class="card"><div class="ch"><h2>${tl("retro.asked")}</h2><span class="n num">${asked.length}</span></div>${asked.slice(0, 8).map((x) => itemRow(x, false)).join("")}<div style="height:8px"></div></div>` : ""}`;
  V().querySelectorAll("[data-wk]").forEach((b) => b.onclick = () => { retroWk = Math.max(0, retroWk + (+b.dataset.wk)); SCREENS.retro(); scrollTo(0, 0); });
};
const infoPair = (k, v) => `<div class="ipk">${esc(k)}</div><div class="ipv">${v == null || v === "" ? "—" : esc(String(v))}</div>`;
// A clickable overview row: the number is a filter, not a repeat of the home tiles beside it.
const infoLink = (go, k, v) => `<button class="ipl press" data-go="${esc(go)}"><span class="ipk">${esc(k)}</span><span class="ipv num">${esc(String(v))}</span></button>`;
const infoSec = (label, pairs) => `<div class="iplab">${esc(label).toUpperCase()}</div>${pairs}`;
function infoPanel(screen) {
  const el = document.getElementById("info"); if (!el) return;
  const it = D.items || [];
  const open = it.reduce((s, x) => s + (x.open || 0), 0);
  let title = "", sub = "", body = "";
  if (screen === "inbox") {
    title = tl("TABS.1");
    body = infoSec(tl("ui.info.overview"), infoPair(tl("ui.stat.pending"), myTurn().length) + infoPair(tl("ui.stat.open"), open));
    // Lab 3: the column under the overview carries who is working now and the latest news, in the kit's drawer rows.
    if (LAB3) { const W = workingRooms(), N = newsList().slice(0, 5);
      body += (W.length ? infoSec(tl("room.bgBusy"), `<div class="k3side">${workRows(W, 4)}</div>`) : "")
        + (N.length ? infoSec(tl("bellSearch.1"), `<div class="k3side">${N.map((a) => `<button class="drawer-item${newsNew(a) ? " unread" : ""} press" ${a.item ? `data-item="${esc(a.item)}"` : `data-go="inbox/news"`}><span class="drawer-item-dot"></span><span class="tx"><div class="drawer-item-title">${esc(a.t)}</div><div class="drawer-item-desc">${esc(a.s || "")}</div><div class="drawer-item-time">${ago(a.at)}</div></span></button>`).join("")}</div>`) : ""); }
  } else { el.hidden = true; el.innerHTML = ""; return; }
  el.hidden = false;
  setHTML(el, `<div class="iptitle">${esc(title)}</div>${sub ? `<div class="ipsub">${esc(sub)}</div>` : ""}${body}`);
}
// One /api/update read serves drawStatus, drawChrome callers and the first drawUpdate: a request made
// within 10s of the last one shares its answer (the server caches the check anyway). force skips it.
let updReq = null, updReqAt = 0;
function getUpd(force) {
  const go = () => fetch("/api/update" + (force ? "?force=1" : "")).then((r) => r.ok ? r.json() : null).catch(() => null);
  if (force) return go();
  if (updReq && Date.now() - updReqAt < 10000) return updReq;
  updReqAt = Date.now(); return updReq = go();
}
async function drawStatus() {
  const s = document.getElementById("status"); if (!s) return;
  if (D.ver === undefined) { const u = await getUpd(); D.ver = u?.current || ""; }
  // The corner names the plan the way the store does - Lite (free), Pro, Trial - then the version.
  // /api/plan decides (license.js keeps window.LOOP_PLAN and calls this again when it changes).
  // The version is also the everyday way to ask "is there a newer one?": a button beside it runs the
  // same check as 설정 > 지금 버전 and says the answer in a toast (the title-bar pill takes over when
  // a newer build can be installed).
  const h = `<span>${esc(D.ver ? planVer() : "Genok")}</span>${D.ver ? `<button class="stupd press" data-stupd aria-label="${tl("upd.check")}" title="${tl("upd.check")}">${ic("dl")}<span>${tl("upd.check")}</span></button>` : ""}`;
  // On a PC there is no status row: the same line is the button beside 설정 at the foot of the rail.
  document.querySelectorAll(".railver").forEach((x) => { const t = D.ver ? planVer() : ""; if (x.textContent !== t) x.textContent = t; });
  if (s._was === h && s.firstChild) return;            // every refresh round calls this: same line, same nodes
  s.innerHTML = h; s._was = h;
  s.removeAttribute("aria-hidden");
}
addEventListener("click", async (e) => {
  const b = e.target.closest?.("[data-stupd]"); if (!b || b.disabled) return;
  const say = b.querySelector("span");               // the rail's button has no words of its own: it only dims
  b.disabled = true; b.classList.add("busy"); if (say) say.textContent = tl("upd.checking");
  const u = await getUpd(true);
  b.disabled = false; b.classList.remove("busy"); if (say) say.textContent = tl("upd.check");
  if (!u || (!u.found && u.error)) return toast(tl("upd.nocheck"), 4000);
  takeUpd(u);
  if (u.packaged) return toast(tl("upd.store", {cur: u.current}), 4000);
  if (!u.found) return toast(tl("update.5", {cur: u.current}), 3000);
  // A newer build opens the popover under the pill: what's new, then the person presses 업데이트
  // there. Checking never downloads or installs by itself (it used to, when the pill was not drawn yet).
  if (u.can_apply) return requestAnimationFrame(() => updPop(true) || toast(tl("update.4", {cur: u.current, v: u.latest}), 4000));
  toast(u.blocked ? tl("upd.blocked", {cur: u.current, v: u.latest}) : tl("update.4", {cur: u.current, v: u.latest}), 4000);
});
addEventListener("loop:plan", () => drawStatus());
const deptRow = (g) => `<button class="row press" data-dept="${esc(g.name)}">${deptIco(g)}<span class="tx"><div class="t">${esc(pname(g.name))}</div>
  <div class="s">${tl("deptRow.2", {n: g.items.length, p4: g.at ? " · " + ago(g.at) : ""})}</div></span>
  ${g.todo ? `<span class="btn weak">${tl("deptRow.1", {todo: g.todo})}</span>` : ""}${pinBtn(g.name, "inrow")}${archBtn(g.name, "inrow")}</button>`;

// ---------- 즐겨찾기: the menus kept under "자주 쓰는", chosen by the user ----------
// Never set means the defaults; the list lives in the server prefs so phone and PC agree.
// 대화 sits right under 홈 by default. A saved list that is just the old default (saved by a
// star toggled on and off again) counts as never set, so it follows the new default; any other
// saved list is the person's own and is left alone.
// 홈 is always the first one and cannot be taken out (FAV_LOCK). 내 차례 left the menu for the bell,
// and 결과물 came up in its place: a list saved before that (no FAV_V marker in it) gets 결과물 once,
// where 내 차례 stood or at the end. The marker rides in the saved list itself, so a list saved
// since then - with 결과물 taken out on purpose - is left as the person made it.
const FAV_DEF = ["home", "project", "lib", "search"];
const FAV_OLD = [["home", "inbox", "search"], ["home", "project", "inbox", "search"]];
const FAV_LOCK = "home", FAV_V = "~v2";
const favClean = (L) => [...new Set(L.map(menuKey))].filter((k) => MENUS.some((m) => m.k === k));
const favNorm = (saved) => {
  if (!Array.isArray(saved)) return FAV_DEF;
  let L = [...new Set(saved.filter((k) => typeof k === "string").map(menuKey))];
  if (!saved.includes(FAV_V)) {
    if (FAV_OLD.some((o) => o.join() === L.join())) return FAV_DEF;
    if (!L.includes("lib")) L = L.includes("inbox") ? L.map((k) => k === "inbox" ? "lib" : k) : [...L, "lib"];
  }
  return [FAV_LOCK, ...favClean(L).filter((k) => k !== FAV_LOCK)];
};
const favs = () => favNorm(D.favs);
// A list the person just made is one made since the move: it carries the marker from the start.
const favSet = (L) => { D.favs = [...L.filter((k) => k !== FAV_V), FAV_V]; };

// 설정 lives at the foot of the sidebar unless the person put it somewhere themselves.
const settingsAtFoot = () => !isFav("settings") && !(knob("menu_order") || []).includes("settings");
const isFav = (k) => favs().includes(k);
// "자주 쓰는" first, then every group without what is already up there. The 사용 방식 knobs rename
// both titles, hide menus (still reachable from 전체, G keys and 자주 쓰는) and move some up.
const favTitle = () => prefName("favs") || tl("chrome.1");
const menuGroups = () => { const F = favs(), gs = [...new Set(MENUS.map((m) => m.g))], hid = knob("menu_hide") || [];
  const ord = knob("menu_order") || [], at = (k) => (ord.includes(k) ? ord.indexOf(k) - ord.length : MENUS.findIndex((m) => m.k === k));
  return [[favTitle(), F.map((k) => M(k))], ...gs.map((g) => [prefName("menus") || g,
    MENUS.filter((m) => m.g === g && !F.includes(m.k) && !hid.includes(m.k)).sort((a, b) => at(a.k) - at(b.k))])].filter(([, L]) => L.length); };
const favBtn = (k, cls = "") => { if (k === FAV_LOCK) return "";
  const on = isFav(k), t = on ? tl("favBtn.1") : tl("favBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb favb press ${cls} ${on ? "on" : ""}" data-fav="${k}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("star")}</${tag}>`; };
async function toggleFav(k, undo = true) {
  if (menuKey(k) === FAV_LOCK) return;
  const was = favs(), on = !was.includes(k), n = M(k)?.n || k;
  favSet(on ? [...was, k] : was.filter((x) => x !== k));
  redrawFavs();
  if (undo) toastAct(on ? tl("toggleFav.1", {n}) : tl("toggleFav.2", {n}), tl("toggleFav.3"), () => { favSet(was); saveFavs(); }, 5000, on ? "fav" : "unfav");
  saveFavs();
}
async function saveFavs() {
  redrawFavs();
  try { D.favs = (await post("/api/favs", {favs: [...favs(), FAV_V]})).favs; } catch (e) { toast(e.message); }
}
function redrawFavs() { drawChrome(); }

// ---------- 순서 바꾸기: pinned departments and favourite menus, dragged into place ----------
// The row follows the pointer 1:1, the others make room as it passes their middle, and on
// release it settles into the gap. With a mouse the whole row drags (rail); by touch only the
// handle does, so the list still scrolls under a finger.
function sortable(box, done, mouseOnly = false) {
  box.onpointerdown = (e) => {
    const items = [...box.children].filter((c) => !("fixed" in c.dataset)), it = items.find((c) => c.contains(e.target));
    if (!it || e.button || items.length < 2 || (mouseOnly && e.pointerType !== "mouse")) return;
    if (e.target.closest("[data-fav],[data-pin]") || (e.pointerType !== "mouse" && !e.target.closest(".grab"))) return;
    if (e.pointerType !== "mouse") e.preventDefault();
    const y0 = e.clientY, i0 = items.indexOf(it), R = items.map((c) => c.getBoundingClientRect());
    const step = R[1].top - R[0].top, lo = R[0].top - R[i0].top, hi = R.at(-1).top - R[i0].top;
    let on = false, to = i0;
    const move = (ev) => { const dy = Math.max(lo, Math.min(hi, ev.clientY - y0));
      if (!on) { if (Math.abs(ev.clientY - y0) < 5) return; on = true; box.classList.add("sorting"); it.classList.add("lift"); }
      ev.preventDefault();
      it.style.transform = `translateY(${dy}px)`;
      const cy = R[i0].top + R[i0].height / 2 + dy;
      to = items.filter((c, j) => j !== i0 && R[j].top + R[j].height / 2 < cy).length;
      items.forEach((c, j) => { if (j === i0) return; const sh = j > i0 && j <= to ? -step : j < i0 && j >= to ? step : 0; c.style.transform = sh ? `translateY(${sh}px)` : ""; });
    };
    const up = () => { removeEventListener("pointermove", move); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
      if (!on) return;
      // The click that ends a drag is not a press on the row.
      const eat = (ev) => { ev.stopPropagation(); ev.preventDefault(); }; addEventListener("click", eat, true); setTimeout(() => removeEventListener("click", eat, true), 60);
      it.classList.add("settle"); it.style.transform = `translateY(${(to - i0) * step}px)`;
      setTimeout(() => { items.forEach((c) => { c.style.transform = ""; c.classList.remove("lift", "settle"); }); box.classList.remove("sorting");
        if (to === i0) return; const o = items.slice(); o.splice(to, 0, o.splice(i0, 1)[0]); o.forEach((c) => box.appendChild(c)); done([...box.children].map((c) => c.dataset.key)); }, RM() ? 0 : 220);
    };
    addEventListener("pointermove", move, {passive: false}); addEventListener("pointerup", up); addEventListener("pointercancel", up);
  };
}
async function reorder(kind, keys) {
  if (kind === "favs") { favSet(keys); return saveFavs(); }
  const was = D.pins; D.pins = keys;
  try { D.pins = (await post("/api/pins", {pins: keys})).pins; } catch (e) { D.pins = was; toast(e.message); }
  drawChrome();
}
// On a phone there is no rail: the same lists in a sheet, each row with a handle.
const SNZ = () => { const d = new Date(), at = (days, h) => { const t = new Date(d); t.setDate(t.getDate() + days); t.setHours(h, 0, 0, 0); return t / 1000; };
  const mon = (8 - d.getDay()) % 7 || 7;
  return [[tl("SNZ.1"), d / 1000 + 3 * 3600], ...(d.getHours() < 17 ? [[tl("SNZ.2"), at(0, 18)]] : []), [tl("SNZ.3"), at(1, 9)], [tl("SNZ.4"), at(mon, 9)], [tl("SNZ.5"), d / 1000 + 30 * 86400]]; };
const snzWhen = (e) => e.until - Date.now() / 1000 > 20 * 86400 ? tl("snzWhen.1") : new Date(e.until * 1000).toLocaleString(LANG() === "en" ? "en-US" : "ko-KR", {month: "numeric", day: "numeric", weekday: "short", hour: "numeric"});
function snoozeSheet(key) {
  const x = D.items.find((y) => iid(y) === key); if (!x) return;
  sheet(`<h2 style="margin:0 0 4px">${tl("snoozeSheet.1")}</h2><p class="hint" style="margin:0 0 12px">${tl("snoozeSheet.2", {esc: esc(x.title)})}</p>
    <div class="snzl">${SNZ().map(([t, u], i) => `<button class="row press" data-snzat="${u}"><span class="ico sm">${ic("clock")}</span><span class="tx"><div class="t">${t}</div></span><kbd class="num">${i + 1}</kbd></button>`).join("")}</div>`,
    (box) => { box.querySelectorAll("[data-snzat]").forEach((b) => b.onclick = () => { closeSheet(); snooze(key, +b.dataset.snzat); });
      box.addEventListener("keydown", (e) => { const b = box.querySelectorAll("[data-snzat]")[+e.key - 1]; if (b) { e.preventDefault(); b.click(); } }); });
}
async function snooze(key, until, mark) {
  const x = D.items.find((y) => iid(y) === key), was = {...(D.snooze || {})};
  D.snooze = {...was}; if (until) D.snooze[key] = {until, v: x?.v || null, ...(mark == null ? {} : {mark})}; else delete D.snooze[key];
  redrawTurn();
  if (until) toastAct(until === SNZ_OPEN ? tl("later.done") : tl("snooze.1", {snzWhen: snzWhen(D.snooze[key])}), tl("toggleFav.3"), () => snooze(key, null));
  else toast(tl("snooze.2"));
  try { D.snooze = (await post("/api/snooze", {key, until: until || null, v: x?.v || null, mark})).snooze || {}; } catch (e) { D.snooze = was; toast(e.message); redrawTurn(); }
}
// Several rows at once, as [key, entry | null] (null = back to 할 일). One redraw; the store takes
// them one after another, and a failure leaves the screen on what the server last said it holds.
async function snoozeMany(rows) {
  const was = {...(D.snooze || {})}; let got = was;
  D.snooze = {...was}; rows.forEach(([key, e]) => { if (e) D.snooze[key] = e; else delete D.snooze[key]; });
  redrawTurn();
  try { for (const [key, e] of rows) got = (await post("/api/snooze", {key, until: e ? e.until : null, v: e ? e.v : null, mark: e ? e.mark : undefined})).snooze || {}; D.snooze = got; }
  catch (err) { D.snooze = got; toast(err.message); redrawTurn(); }
}
// The rows of the given sections of 할 일 put aside at once, each the way its own clock does it -
// a result until its next version, any other row until what it stood on changes. 되돌리기 puts
// back exactly these rows, each to the entry it had before.
const laterRows = (T) => T.flatMap((s) => (s.k === "ask" ? s.L.flatMap((g) => g.items) : s.L).map((r) => SEC_ROW[s.k] ? SEC_ROW[s.k](r) : [iid(r), null, r.v]));
function laterAll(T, said) {
  const rows = laterRows(T), was = D.snooze || {};
  if (!rows.length) return;
  const back = rows.map(([key]) => [key, was[key] || null]);
  const put = snoozeMany(rows.map(([key, mark, v]) => [key, {until: SNZ_OPEN, v: v || null, ...(mark == null ? {} : {mark})}]));
  // The way back waits for the last of the writes above: one still on its way would hide the row again.
  toastAct(said, tl("toggleFav.3"), () => put.then(() => { snoozeMany(back); toast(tl("snooze.2")); }));
}
// 할 일 in the two kinds the result lists have: 신규 (a version not opened yet) and 답변 (everything
// that waits for the person's move). One split, so the two numbers always add up to the bell's.
const turnKinds = (T) => { const isNew = (s, x) => s.k === "look" && stOf(x) === "fresh";
  return {fresh: T.map((s) => ({...s, L: s.L.filter((x) => isNew(s, x))})), reply: T.map((s) => ({...s, L: s.L.filter((x) => !isNew(s, x))}))}; };
// 모두 읽음 on 신규: each is marked opened (as opening it does) and leaves 할 일 until its next version.
function readFresh(T) {
  T.find((s) => s.k === "look").L.forEach((x) => { x.new = false; post("/api/seen", {p: x.project, i: x.id, v: x.v}).catch(() => {}); });
  laterAll(T, tl("sx.allread.done"));
}
const redrawTurn = () => { if (!detail && cur === "inbox") SCREENS.inbox(inTab); else if (!detail && cur === "home") SCREENS.home(); drawChrome(); };
// The quiet action on every row of 할 일 (and the way back on 나중에). A result's keeps the class
// the skins already dress (.snzb); `mark` is given for the rows that are not results.
const laterBtn = (key, mark) => `<span class="${mark == null ? "snzb" : "ltrb"} press" role="button" tabindex="0" data-later="${esc(key)}"${mark == null ? "" : ` data-mark="${esc(mark)}"`} aria-label="${tl("snoozeSheet.1")}" title="${tl("snoozeSheet.1")}">${ic("clock")}</span>`;
const backBtn = (key) => `<span class="ltrb press" role="button" tabindex="0" data-unsnz="${esc(key)}" aria-label="${tl("inboxDo.6")}" title="${tl("inboxDo.6")}">${ic("undo")}</span>`;
function sortSheet(kind) {
  const L = kind === "favs" ? favs().map((k) => ({k, n: M(k).n, i: menuIco(M(k), "ico sm")}))
    : (D.pins || []).map((d) => ({k: d, n: d, i: `<span class="ico sm">${ic("star")}</span>`}));
  sheet(`<h2 style="margin:0 0 4px">${tl("sortSheet.3", {p0: kind === "favs" ? tl("sortSheet.1") : tl("sortSheet.2")})}</h2><p class="hint" style="margin:0 0 12px">${tl("sortSheet.4")}</p>
    <div class="slist" data-sort="${kind}">${L.map((x) => `<div class="srow" data-key="${esc(x.k)}"${kind === "favs" && x.k === FAV_LOCK ? " data-fixed" : ""}>${x.i}<span class="tx">${esc(x.n)}</span><span class="grab" aria-hidden="true">${ic(kind === "favs" && x.k === FAV_LOCK ? "lock" : "grip")}</span></div>`).join("")}</div>`,
    (box) => sortable(box.querySelector(".slist"), (keys) => reorder(kind, keys)));
}

// ---------- 고정: departments kept at the top of every list, like a browser's bookmarks bar ----------
// Kept on the server (prefs) so the phone and the PC show the same ones, in the order pinned.
const isPinned = (dept) => (D.pins || []).includes(dept);
// Inside a row that is itself a button it has to be a span: a button in a button is torn apart.
const pinBtn = (dept, cls = "") => { const on = isPinned(dept), t = on ? tl("pinBtn.1") : tl("pinBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb press ${cls} ${on ? "on" : ""}" data-pin="${esc(dept)}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("star")}</${tag}>`; };
async function togglePin(dept, undo = true) {
  const on = !isPinned(dept), was = D.pins || [];
  D.pins = on ? [...was.filter((d) => d !== dept), dept] : was.filter((d) => d !== dept);
  pinsRedraw();
  if (undo) toastAct(on ? tl("togglePin.1", {dept}) : tl("togglePin.2", {dept}), tl("toggleFav.3"), () => togglePin(dept, false), 5000, on ? "fav" : "unfav");
  try { D.pins = (await post("/api/pin", {dept, on})).pins; } catch (e) { D.pins = was; toast(e.message); }
  pinsRedraw();
}
const pinsRedraw = () => { drawChrome(); if (!detail && cur === "dept") SCREENS.dept(); };

// ---------- 보관: projects folded away, like the hub's collapsible "…도 보기" line ----------
// A hidden project drops out of the sidebar, the chips and the pickers into one "보관 N" line
// that expands in place. Kept on the server (prefs.hidden_projects) so phone and PC agree.
const isArch = (dept) => (D.hidden || []).includes(dept);
let showArch = false;   // the 보관 N line is folded until clicked
// A department the register put away (an archived 부서, or one imported from the hub as finished)
// folds into the same 보관 line; only the person's own hide is undone from here (archBtn).
const inShelf = (dept) => isArch(dept) || (D.shelved || []).includes(dept);
// The folded line says what is inside by register number, on one line: "12 · 31 · 45".
const shelfNums = (gs) => gs.map((g) => (D.placeNums || {})[g.name]).filter(Boolean).sort((a, b) => a - b).join(" · ");
// The fold opens in place (no redraw), so the spring can be caught and reversed mid-way.
const shelfFold = (rows) => `<div class="shfold${showArch ? " on" : ""}"${showArch ? "" : " inert"}><div class="shfin">${rows}</div></div>`;
const toggleShelf = () => { showArch = !showArch;
  document.querySelectorAll("[data-archx]").forEach((b) => { b.setAttribute("aria-expanded", showArch); b.classList.toggle("on", showArch); });
  document.querySelectorAll(".shfold").forEach((f) => { f.classList.toggle("on", showArch); f.inert = !showArch; }); };
const archBtn = (dept, cls = "") => { const on = isArch(dept), t = on ? tl("archBtn.1") : tl("archBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb archb press ${cls} ${on ? "on" : ""}" data-arch="${esc(dept)}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("archive")}</${tag}>`; };
async function toggleArchive(dept, undo = true) {
  const on = !isArch(dept), was = D.hidden || [];
  D.hidden = on ? [...was.filter((d) => d !== dept), dept] : was.filter((d) => d !== dept);
  archRedraw();
  if (undo) toastAct(on ? tl("toggleArch.1", {dept}) : tl("toggleArch.2", {dept}), tl("toggleFav.3"), () => toggleArchive(dept, false), 5000, on ? "archive" : "restore");
  try { D.hidden = (await post("/api/project-hide", {project: dept, on})).hidden_projects; } catch (e) { D.hidden = was; toast(e.message); }
  archRedraw();
}
const archRedraw = () => { drawChrome(); if (!detail && cur === "dept") SCREENS.dept(); else if (detail?.[0] === "dept") deptView(detail[1]); };
// A row held down on a phone opens its menu, pin included (web/railmenu.js).
// ---------- 결과물 ----------
// 결과물 › 보드: every project's results on one board (web/boardview.js), each opened in place.
SCREENS.board = function () {
  const its = D.items.filter((x) => !libHide.has(iid(x)));
  V().innerHTML = `${window.resTabs ? resTabs("board") : ""}${its.length ? `<div class="bdhost" id="bdhost"></div>` : `<div class="card plan none">${stNone("all")}</div>`}`;
  if (its.length && window.BoardView) BoardView.draw(document.getElementById("bdhost"), "*", its);
  return {};
};
// Lab 3: the results on the kit's content page, as blocks (the default) or as a list; the choice
// is kept in this window ("genok-k3v").
// The list it opens on is the one last chosen ("genok-k3f"); before any choice, 신규 - opening
// on 전체 every time meant picking 신규 again on each visit.
let k3f = ((s) => s === "all" ? "" : ST_MAIN.includes(s) ? s : "fresh")(lsGet("genok-k3f"));
const K3V = {grid: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="1.5" width="5.5" height="5.5" rx="1.5"/><rect x="9" y="1.5" width="5.5" height="5.5" rx="1.5"/><rect x="1.5" y="9" width="5.5" height="5.5" rx="1.5"/><rect x="9" y="9" width="5.5" height="5.5" rx="1.5"/></svg>',
  list: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="2.5" width="13" height="2.5" rx="1.25"/><rect x="1.5" y="6.75" width="13" height="2.5" rx="1.25"/><rect x="1.5" y="11" width="13" height="2.5" rx="1.25"/></svg>'};
function k3View(v) { try { if (v) localStorage.setItem("genok-k3v", v); else return localStorage.getItem("genok-k3v") === "list" ? "list" : "grid"; } catch (e) { /* blocks */ } return v || "grid"; }
function libKit() {
  const base = D.items.filter((x) => (!libD || gname(x) === libD) && (!libQ || (x.title || "").toLowerCase().includes(libQ.toLowerCase()))).sort(byAt);
  // The same lists as the results screen has always had (신규, 답변, ... 완료), with their counts.
  const n = (k) => base.filter((x) => stOf(x) === k).length, rows = k3f ? base.filter((x) => stOf(x) === k3f) : base;
  const F = [["", tl("all.tab"), base.length], ...ST_MAIN.map((k) => [k, ST_TABN[k], n(k)])];
  const view = k3View(), VW = [["grid", tl("k3.view.grid")], ["list", tl("k3.view.list")]];
  const badge = (x) => `<span class="stat-summary-badge ${stCls(x)}">${esc(stName(x))}</span>`;
  const ok = (x) => !x.finished && gtri(x) ? `<button type="button" class="k3ok press" data-ga="ok" data-gk="${esc(iid(x))}" title="${esc(tl("gact.5"))}">${ic("check")}<span>${tl("gact.9")}</span></button>` : "";
  // An empty list says so in one line (a zero chip used to leave a bare card).
  const body = !rows.length ? `<div class="k3none">${stNone(ST_NONE[k3f] ? k3f : "all")}</div>` : view === "grid"
    ? `<div class="content-table-body k3grid">${rows.map((x) => `<div class="k3w"><button type="button" class="k3blk press" data-item="${esc(iid(x))}"${stTip(x)}>
        <span class="k3bth">${homeThumb(x)}${badge(x)}</span>
        <span class="item-title-text">${esc(x.title)}</span><span class="item-pub-text">${homeWhere(x)}</span></button>${ok(x)}</div>`).join("")}</div>`
    : `<div class="content-table-body">${rows.map((x) => `<div class="k3w"><button type="button" class="content-table-row item-row press" data-item="${esc(iid(x))}"${stTip(x)}>
        <span class="col-title"><span class="video-thumb-mini">${homeThumb(x)}</span><span class="k3tt"><span class="item-title-text">${esc(x.title)}</span><span class="item-pub-text num">${ago(x.at)}</span></span></span>
        <span class="col-cat"><span class="cat-badge">${esc(pname(gname(x)))}</span></span>
        <span class="col-views-c">${ic((KIND[x.kind] || ["doc"])[0])}</span>
        <span class="col-dur">${badge(x)}</span>
        <span class="col-act"><span class="action-circle-btn">${ic("chev")}</span></span></button>${ok(x)}</div>`).join("")}</div>`;
  V().innerHTML = `<div class="tab-view-container k3lib">
    <div class="glass-card content-table-card"><div class="content-table-header"><div class="content-header-left"><h3 class="section-title">${esc(libD ? pname(libD) : tl("TABS.3"))}</h3><div class="category-pill-group">${F.map(([k, t, c]) => `<button type="button" class="category-pill${k3f === k ? " active" : ""}${c ? "" : " zero"}" data-k3f="${k}" aria-pressed="${k3f === k}">${esc(t)} <span class="num">${c}</span></button>`).join("")}</div></div>
      <div class="k3tools"><div class="k3vw" role="group" aria-label="${esc(tl("k3.view"))}">${VW.map(([k, t]) => `<button type="button" class="press${view === k ? " on" : ""}" data-k3v="${k}" aria-pressed="${view === k}" title="${esc(t)}" aria-label="${esc(t)}">${K3V[k]}</button>`).join("")}</div></div></div>
      ${body}</div></div>`;
  V().querySelectorAll("[data-k3v]").forEach((b) => { b.onclick = () => { k3View(b.dataset.k3v); libKit(); }; });
  V().querySelectorAll("[data-k3f]").forEach((b) => { b.onclick = () => { k3f = b.dataset.k3f; lsSet("genok-k3f", k3f || "all"); libKit(); }; });
}
SCREENS.lib = function () {
  if (LAB3) return libKit();
  const depts = [...new Set(D.items.map((x) => gname(x)))].sort((a, b) => a.localeCompare(b, "ko"));
  const sel = (id, label, opts, cur) => `<gk-select id="${id}" class="lsel" aria-label="${label}">${opts.map(([k, n]) => `<option value="${esc(k)}" ${k === cur ? "selected" : ""}>${esc(n)}</option>`).join("")}</gk-select>`;
  // One toolbar row: search takes the slack, the rest are equal 36px controls on one edge.
  V().innerHTML = `${window.resTabs ? resTabs("lib") : ""}<div class="ltool"><div class="field lq">${ic("search")}<input id="libq" type="search" enterkeyhint="search" placeholder="${tl("lib.2")}" autocomplete="off" value="${esc(libQ)}"></div>
    <button class="lfbtn press" data-libfil aria-haspopup="dialog">${ic("sliders")}<span>${tl("lib.fil")}</span><em class="num" hidden></em></button>
    ${sel("libd", unitWord(), [["", tl("lib.1", {u: unitWord()})], ...depts.map((d) => [d, pname(d)])].concat(libD && !depts.includes(libD) ? [[libD, libD]] : []), libD)}
    <gk-select id="libk" class="lsel" aria-label="${tl("libDraw.24")}"></gk-select>
    <div class="seg lord" role="group" aria-label="${tl("libDraw.6")}">${[["new", tl("LIB_ORD.1")], ["dept", tl("LIB_ORD.3", {u: unitWord()})]].map(([k, n]) => `<button class="press" data-libo="${k}">${esc(n)}</button>`).join("")}</div>
    <div class="seg zoom" role="group" aria-label="${tl("libDraw.9")}">${[["s",tl("libDraw.3")],["m",tl("libDraw.4")],["l",tl("libDraw.5")]].map(([k, n]) => `<button class="press" data-libz="${k}">${n}</button>`).join("")}</div>
    <button class="zcyc press" data-libz="" aria-label="${tl("libDraw.7")}">${ic("grid")}</button></div>
    <div id="libg"></div><div id="libs"></div>${listKeyBar()}`;
  const q = document.getElementById("libq"), dd = document.getElementById("libd");
  let t0;
  q.oninput = () => { libQ = q.value; libSel = null; clearTimeout(t0); t0 = setTimeout(libDraw, 120); };
  dd.onchange = () => { libD = dd.value; libSel = null; libDraw(); };
  document.getElementById("libk").onchange = (e) => { libK = e.target.value; libSel = null; libDraw(); };
  libDraw();
};
// Phone: project, kind, order, card size and the saved views sit behind one 필터 button, so the
// first card starts right under the search. The sheet sets the same state the toolbar does.
const libFilN = () => (libD ? 1 : 0) + (libK ? 1 : 0) || (document.querySelector("#vwbar .vwc-w.on") ? 1 : 0);
function libFilSheet() {
  const chip = (attr, k, n, on) => `<button class="chip press${on ? " on" : ""}" ${attr}="${esc(k)}" aria-pressed="${on}">${n}</button>`;
  const seg = (attr, label, opts, cur) => `<div class="seg lfs" role="group" aria-label="${label}">${opts.map(([k, n]) => `<button class="press${k === cur ? " on" : ""}" ${attr}="${k}" aria-pressed="${k === cur}">${esc(n)}</button>`).join("")}</div>`;
  const body = () => {
    const depts = [...new Set(D.items.map((x) => gname(x)))].sort((a, b) => a.localeCompare(b, "ko"));
    if (libD && !depts.includes(libD)) depts.push(libD);
    const kinds = LIB_KINDS.filter(([k]) => !k || D.items.some((x) => (!libD || gname(x) === libD) && kindOf(x) === k));
    const views = [...document.querySelectorAll("#vwbar .vwc-w")], save = document.querySelector("#vwbar [data-vsave]"), manage = document.querySelector("#vwbar [data-viewmanage]");
    return (views.length ? `<div class="lbl">${tl("views.title")}</div><div class="lfc">${views.map((w) => chip("data-lfv", w.dataset.vw, w.querySelector(".vwc").innerHTML, w.classList.contains("on"))).join("")}</div>` : "")
      + `<div class="lbl">${esc(unitWord())}</div><div class="lfc">${[["", tl("lib.1", {u: unitWord()})], ...depts.map((d) => [d, pname(d)])].map(([k, n]) => chip("data-lfd", k, deptMark(k) + esc(n), k === libD)).join("")}</div>
      <div class="lbl">${tl("libDraw.24")}</div><div class="lfc">${kinds.map(([k, n, i]) => chip("data-lfk", k, (i ? ic(i) : "") + esc(n), k === libK)).join("")}</div>
      <div class="lbl">${tl("lib.fil.sort")}</div>${seg("data-lfo", tl("libDraw.6"), [["new", tl("LIB_ORD.1")], ["dept", tl("LIB_ORD.3", {u: unitWord()})]], libOrd())}
      <div class="lbl">${tl("libDraw.9")}</div>${seg("data-lfz", tl("libDraw.9"), [["s", tl("libDraw.3")], ["m", tl("libDraw.4")], ["l", tl("libDraw.5")]], libZ())}
      ${save || manage ? `<div class="lfm">${save ? `<button class="lnk press" data-lfsave>${ic("plus")}${tl("views.savethis")}</button>` : ""}${manage ? `<button class="lnk press" data-lfmanage>${tl("views.manage")}</button>` : ""}</div>` : ""}
      <div class="lfa"><button class="btn xl press" data-lfreset ${libD || libK ? "" : "disabled"}>${tl("lib.fil.reset")}</button><button class="btn xl fill press" data-sclose>${tl("lib.fil.done")}</button></div>`;
  };
  sheet(`<h3>${tl("lib.fil")}</h3><div class="lfb">${body()}</div>`, (box) => {
    const inner = box.querySelector(".lfb");
    const redo = () => { const dd = document.getElementById("libd"); if (dd) dd.value = libD; libSel = null; libDraw(); inner.innerHTML = body(); };
    inner.onclick = (e) => {
      const a = e.target.closest("[data-lfv],[data-lfd],[data-lfk],[data-lfo],[data-lfz],[data-lfreset],[data-lfsave],[data-lfmanage]"); if (!a) return;
      const d = a.dataset;
      // Saved views and their name form belong to the bar on the page: press its own buttons.
      if (d.lfv !== undefined) { document.querySelector(`#vwbar [data-view="${CSS.escape(d.lfv)}"]`)?.click(); return setTimeout(() => { if (inner.isConnected) inner.innerHTML = body(); }); }
      if (d.lfsave !== undefined) { closeSheet(); return setTimeout(() => document.querySelector("#vwbar [data-vsave]")?.click(), 320); }
      if (d.lfmanage !== undefined) return document.querySelector("#vwbar [data-viewmanage]")?.click();
      if (d.lfd !== undefined) { libD = d.lfd; if (libK && !D.items.some((x) => (!libD || gname(x) === libD) && kindOf(x) === libK)) libK = ""; }
      else if (d.lfk !== undefined) libK = d.lfk;
      else if (d.lfo) libO(d.lfo);
      else if (d.lfz) libZ(d.lfz);
      else if (d.lfreset !== undefined) { libD = ""; libK = ""; }
      redo();
    };
  });
}
// Kinds as ThreeUI sorts its catalogue: chips over the grid, only the ones there are.
const LIB_KINDS = LT(() => ([["", tl("LIB_KINDS.1"), ""], ["video", tl("LIB_KINDS.2"), "video"], ["image", tl("LIB_KINDS.3"), "image"], ["html", tl("LIB_KINDS.4"), "code"], ["doc", tl("LIB_KINDS.5"), "doc"]]));
const kindOf = (x) => x.kind === "text" || x.kind === "link" ? "doc" : x.kind;
const libZ = (v) => { try { if (v === undefined) return localStorage.getItem("v2-libz") || "m"; localStorage.setItem("v2-libz", v); } catch { return "m"; } };
// Order of the list: newest first, oldest first, or one department after another. Left
// unset, 확인 필요 goes by department and the rest newest first, as before.
// Piles can also go by session (병렬 작업: one per worktree) or by role (메인 + 서브에이전트: the
// main session's own pushes, then one pile per subagent/teammate role).
const LIB_ORD = LT(() => ([["new", tl("LIB_ORD.1")], ["old", tl("LIB_ORD.2")], ["dept", tl("LIB_ORD.3", {u: unitWord()})],
  ["session", tl("LIB_ORD.4")], ["role", tl("LIB_ORD.5")], ["due", tl("LIB_ORD.6")]]));
// Where 결과물 opens: the reader's own pick, else the 사용 방식 결과물 묶기 knob.
const LIB_KNOB = {unit: "dept", session: "session", role: "role", date: "new"};
const libOrd = () => { const o = libO(); return LIB_ORD.some(([k]) => k === o) ? o : LIB_KNOB[knob("lib_group")] || "dept"; };
const PILED = ["dept", "session", "role"];
const libGroupOf = (x, ord) => ord === "role" ? (x.role || tl("mode.main")) : ord === "session" ? (x.session || gname(x)) : gname(x);
// Library groups the reader folded away, by project name (kept across visits).
const libFold = (() => { try { return new Set(JSON.parse(localStorage.getItem("v2-libfold") || "[]")); } catch { return new Set(); } })();
const saveFold = () => { try { localStorage.setItem("v2-libfold", JSON.stringify([...libFold])); } catch {} };
// A project's emoji on library rows, so piles tell apart at a glance.
const deptMark = (name) => { const r = D.items.find((x) => gname(x) === name && x.icon); return r ? `<span class="dmk" aria-hidden="true">${identFace(name, r.icon)}</span>` : ""; };
const libO = (v) => { try { if (v === undefined) return localStorage.getItem("v2-libo") || ""; localStorage.setItem("v2-libo", v); } catch { return ""; } };
const libHide = new Set();                 // approved from the list, still inside the 5 seconds to take it back
function libHash() {
  if (cur !== "lib" || detail) return;
  const u = new URLSearchParams(); if (libF && !libFAuto) u.set("f", libF); if (libD) u.set("d", libD); if (libQ.trim()) u.set("q", libQ.trim()); if (libK) u.set("k", libK);
  const s = u.toString(); if (location.hash.slice(1) !== "lib" + (s ? "?" + s : "")) history.replaceState(null, "", "#lib" + (s ? "?" + s : ""));
}
// 끝난 작업, one project at a time: a line that sums the project up, then its results as a
// plain list, newest first. Each row opens the result; its 기록 button unfolds that result's
// own run in place (every version and what was said on it, oldest first), read once on demand.
const finOpen = new Set(), finHist = new Map();
const finDay = (t) => t ? new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "short", day: "numeric"}) : "";
function finLines(d) {
  const L = [];
  (d.versions || []).forEach((v) => L.push({at: v.at || "", ic: "up", t: tl("fin.h.ver", {v: vShort(v.v)})}));
  (d.log || []).forEach((e) => {
    if ((e.kind === "comment" || e.kind === "message") && e.text) L.push({at: e.at || "", ic: "chat", t: String(e.text).replace(/\s+/g, " ").slice(0, 120)});
    else if (e.kind === "status" && STATUS_T[e.status]) L.push({at: e.at || "", ic: e.status === "approved" ? "check" : "bendBack", t: STATUS_T[e.status]});
  });
  if (d.finished) L.push({at: d.finished, ic: "flag", t: tl("fin.h.end")});
  return L.sort((a, b) => a.at.localeCompare(b.at));
}
const finHistHtml = (k) => { const L = finHist.get(k);
  return !L ? `<div class="finh">${loadingHtml("", {size: 20})}</div>` : `<ol class="finh">${L.length ? L.map((l) => `<li>${ic(l.ic, "i")}<span class="ft">${esc(l.t)}</span><time>${finDay(l.at)}</time></li>`).join("") : `<li><span class="ft">${tl("fin.h.none")}</span></li>`}</ol>`; };
function finGroup(d, xs) {
  const vs = xs.reduce((a, x) => a + (x.count || 0), 0), cs = xs.reduce((a, x) => a + (x.comments || 0), 0);
  return `<div class="finl"${libFold.has(d) ? " hidden" : ""}><p class="fins">${tl("fin.sum", {v: vs, c: cs})}</p>${xs.map((x) => { const k = iid(x), on = finOpen.has(k);
    return `<div class="finr"><button class="finb press" data-item="${esc(k)}"><span class="fth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}</span><span class="ftx"><span class="t">${esc(x.title)}</span><span class="s">${stK(x) === "approved" ? `<i class="fok">${tl("STATUS_T.4")}</i>` : ""}${vShort(x.v)} · ${finDay(x.finished || x.at)}</span></span></button><button class="finx press" data-finx="${esc(k)}" aria-expanded="${on}">${on ? tl("fin.hist.off") : tl("fin.hist")}${ic("chev", "i")}</button>${on ? finHistHtml(k) : ""}</div>`; }).join("")}</div>`;
}
function finWire(g) {
  g.querySelectorAll("[data-finx]").forEach((b) => b.onclick = async () => { const k = b.dataset.finx;
    if (finOpen.has(k)) { finOpen.delete(k); return libDraw(); }
    finOpen.add(k); libDraw();
    if (finHist.has(k)) return;
    const [p0, ...r] = k.split("/"), d = await itemDetail(p0, r.join("/"));
    finHist.set(k, d ? finLines(d) : []); if (finOpen.has(k)) libDraw(); });
}
let libAsk = 0;
function libDraw() {
  const g = document.getElementById("libg"); if (!g) return;
  // A fresh open always lands on 새로 온 것, empty or not: skipping to the next tab read as "something is waiting".
  if (libFAuto || !libF) libF = "fresh";
  libHash();
  const qq = libQ.trim().toLowerCase();
  const base0 = D.items.filter((x) => !libHide.has(iid(x)) && (!libD || gname(x) === libD)
    && Triage.match(`${x.title} ${x.dept || ""} ${pname(x.dept || "")} ${x.project} ${pname(x.project)}`, qq));
  const base = base0.filter((x) => !libK || kindOf(x) === libK);
  // By department unless the reader picked another order: one pile by date was hard to tell apart.
  const ord = libOrd();
  const L = base.filter((x) => libF === "all" || stOf(x) === libF).sort(byAt);
  if (ord === "old") L.reverse();
  // Due soonest first (overdue on top); items without a due date go last, newest first.
  if (ord === "due") L.sort((a, b) => (a.due ? 0 : 1) - (b.due ? 0 : 1) || (a.due || "").localeCompare(b.due || "") || byAt(a, b));
  // What came in the last 15 minutes is its own group on top, so a fresh push is not lost in 오늘.
  // 확인 필요 goes by department, so one department's pile is looked through in one go.
  // Departments come in order of their newest push, so whoever just sent something is on top.
  // 멈춤 goes by who stopped it (the reader, or nobody), so the ones that just ended can be
  // finished in one go. 끝난 작업 always goes by project: one project's whole run in one place.
  const byWho = libF === "stalled", fin = libF === ST_DONE;
  const byDept = fin || (PILED.includes(ord) && !byWho), gord = fin ? "dept" : ord, groups = {};
  if (byDept) L.forEach((x) => (groups[libGroupOf(x, gord)] ||= []).push(x));
  else if (byWho) [[true, tl("st.g.mine")], [false, tl("st.g.ended")]].forEach(([m, t]) => { const xs = L.filter((x) => !!stJ(x).mine === m); if (xs.length) groups[t] = xs; });
  else if (ord === "due") L.forEach((x) => (groups[x.due ? tl("libDraw.27") : tl("libDraw.28")] ||= []).push(x));
  else L.forEach((x) => (groups[justIn(x) && ord === "new" ? tl("libDraw.2") : day(x.at)] ||= []).push(x));
  // 확인 필요: several can be approved in one go - a department's pile it has already been
  // looked through elsewhere, or a row of small fixes.
  const pick = ST_MINE.includes(libF) && L.length > 1;
  if (!pick) libSel = null;
  const G = Object.entries(groups);
  // Project piles follow the order set in the sidebar; the rest keep newest-first.
  if (byDept && gord === "dept") { const po = pjOrder(), at = (d) => { const i = po.indexOf(d); return i < 0 ? 1e6 : i; }; G.sort((a, b) => at(a[0]) - at(b[0])); }
  const K = LIB_KINDS.filter(([k]) => !k || base0.some((x) => kindOf(x) === k));
  // The toolbar above is static (so the search keeps its focus); only its state is synced here.
  const kSel = document.getElementById("libk");
  if (kSel) { const ko = K.map(([k, n]) => `<option value="${k}">${n}</option>`).join(""); if (kSel.dataset.o !== ko) { kSel.innerHTML = ko; kSel.dataset.o = ko; } kSel.value = libK; }
  document.querySelectorAll(".ltool .lord [data-libo]").forEach((b) => { const on = ord === b.dataset.libo; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  document.querySelectorAll(".ltool .seg.zoom [data-libz]").forEach((b) => { const on = libZ() === b.dataset.libz; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  const zc = document.querySelector(".ltool .zcyc"); if (zc) zc.dataset.libz = {s: "m", m: "l", l: "s"}[libZ()];
  const fb = document.querySelector(".ltool .lfbtn em"); if (fb) { const n = libFilN(); fb.hidden = !n; fb.textContent = n || ""; fb.parentElement.classList.toggle("on", !!n); }
  g.innerHTML = stTabs(base, libF, "lib")
    + (pick ? `<div class="selrow"><span>${libSel ? `<b class="num">${libSel.size}</b>${tl("libDraw.10")}` : tl("libDraw.11", {n: L.length})}</span><button class="btn sm weak press" id="selon">${libSel ? tl("libDraw.12") : tl("libDraw.13")}</button></div>` : "")
    + (L.length ? G.map(([d, xs], gi) => `<div class="sec${byDept ? " secd" : ""}${byDept && !fin && !libSel && G.length === 1 && gord === "dept" && !libFold.has(d) ? " solo" : ""}">${byDept ? `<button class="fold press" data-fold="${esc(d)}" aria-expanded="${!libFold.has(d)}">${gord === "role" ? `<span class="dmk">${ic("people")}</span>` : gord === "session" ? `<span class="dmk">${ic("chat")}</span>` : deptMark(d) || `<span class="dmk">${ic("folder")}</span>`}<b>${esc(gord === "role" || gord === "session" ? d : pname(d))}</b><em class="num">${xs.length}</em>${xs.some(stMine) && !ST_MINE.includes(libF) ? `<span class="warn">${tl("fold.1", {n: xs.filter(stMine).length})}</span>` : ""}${ic("chev", "i fc")}</button>` : byWho ? `<b class="gwho">${esc(d)}</b><em class="num">${xs.length}</em>` : esc(d)}${libSel ? ` <button class="lnk press" data-selg="${gi}">${xs.every((x) => libSel.has(iid(x))) ? tl("libDraw.15") : tl("libDraw.16")}</button>` : byWho ? ` <button class="lnk press" data-finall="${gi}">${ic("flag")}${tl("fin.all", {n: xs.length})}</button>` : fin || !(ST_MINE.includes(libF) || libF === "all") ? "" : xs.filter(gtri).length > 1 ? ` <button class="lnk press" data-triall="${gi}">${tl("libDraw.17", {p1: xs.filter(gtri).length})}</button>` : ""}</div>${fin ? finGroup(d, xs) : `<div class="gal z-${libZ()}"${byDept && libFold.has(d) ? " hidden" : ""}>${xs.map((x) => `<div class="gw"${libSel ? "" : " data-tk"}><button class="gi press${libSel?.has(iid(x)) ? " picked" : ""}" ${libSel ? `data-sel="${esc(iid(x))}" aria-pressed="${libSel.has(iid(x))}"` : `data-item="${esc(iid(x))}"`}>
      <div class="th">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${libF === "fresh" && stName(x) === tl("st.fresh") ? "" : `<span class="tag ${stCls(x)}"${stTip(x)}>${stName(x)}</span>`}${libSel ? `<span class="pk">${ic("check")}</span>` : lintTag(iid(x) + "@" + x.v, x.lint)}</div>
      <div class="tx"><div class="t">${esc(x.title)}</div><div class="s gm"><span class="gmn">${byDept && gord === "dept" ? "" : `<span class="gpn">${deptMark(gname(x))}${esc(pname(gname(x)))}</span>`}<span class="grest">${byDept && gord === "dept" ? "" : " · "}${esc(x.v)} · ${ago(x.at)}${window.resMeta ? resMeta(x) : ""}</span></span>${x.open ? `<span class="gop"> · <b class="opn">${tl("open.1", {n: x.open})}</b></span>` : ""}</div>${x.comments && x.note ? `<div class="s">${noteTag(x).slice(3)}</div>` : ""}</div></button>${libSel ? "" : gmore(x)}</div>`).join("")}</div>`}`).join("")
      // A search that finds nothing in this list but something in another says so, one press away.
      : `<div class="card plan none">${mEmpty(qq || libD ? "emptySearch" : "emptyInbox")}${qq || libD ? `<p>${tl("libDraw.18")}</p>${libF !== "all" && base.length ? `<p class="act"><button class="btn press" data-lib="all">${tl("lib.q.else", {n: base.length})}</button></p>` : ""}` : stNone(libF) + stNext(libF)}</div>`)
    + (libSel ? `<div class="ctapad"></div>` : "");
  // The bar hangs off the body: inside the moving page a fixed bar is fixed to the page, not the screen.
  let sb = document.getElementById("selbar");
  if (libSel && !sb) { sb = document.createElement("div"); sb.id = "selbar"; sb.className = "selbar"; document.body.appendChild(sb); }
  if (sb && !libSel) sb.remove();
  if (libSel) sb.innerHTML = `<div class="in"><button class="btn xl press" id="seloff">${tl("libDraw.22")}</button><button class="btn xl fill press" id="selok" ${libSel.size ? "" : "disabled"}>${libSel.size ? tl("libDraw.20", {size: libSel.size}) : tl("libDraw.21")}</button></div>`;
  stStrip(g);
  // 멈춤: a whole group ended in one press (작업 끝내기 on each), with the toast's 되돌리기.
  g.querySelectorAll("[data-finall]").forEach((b) => b.onclick = () => libFin(G[+b.dataset.finall][1].slice(), true));
  finWire(g);
  document.getElementById("selon")?.addEventListener("click", () => { libSel = libSel ? null : new Set(); libDraw(); });
  document.getElementById("seloff")?.addEventListener("click", () => { libSel = null; libDraw(); });
  g.querySelectorAll("[data-sel]").forEach((b) => b.onclick = () => { const k = b.dataset.sel; libSel.has(k) ? libSel.delete(k) : libSel.add(k); libDraw(); });
  g.querySelectorAll("[data-selg]").forEach((b) => b.onclick = () => { const xs = G[+b.dataset.selg][1], all = xs.every((x) => libSel.has(iid(x)));
    xs.forEach((x) => all ? libSel.delete(iid(x)) : libSel.add(iid(x))); libDraw(); });
  document.getElementById("selok")?.addEventListener("click", () => approveMany(L.filter((x) => libSel.has(iid(x)))));
  g.querySelectorAll("[data-fold]").forEach((b) => b.onclick = () => { const k = b.dataset.fold; libFold.has(k) ? libFold.delete(k) : libFold.add(k); saveFold(); libDraw(); });
  g.querySelectorAll("[data-triall]").forEach((b) => b.onclick = () => triage(G[+b.dataset.triall][1].filter(gtri)));
  triMark();
  // Words that are in comments or summaries, not in titles: the server looks through those.
  const s = document.getElementById("libs"), ask = ++libAsk;
  if (qq.length < 2) { s.innerHTML = ""; return; }
  get(`/api/search?q=${encodeURIComponent(qq)}`).then((r) => {
    if (ask !== libAsk) return;
    const hs = (r.hits || []).filter((h) => h.where !== "제목" && (!libD || gname(h) === libD));
    s.innerHTML = hs.length ? `<div class="sec">${tl("libDraw.23", {n: hs.length})}</div><div class="card">${hs.map((h) => hitRow(h, qq)).join("")}</div>` : "";
  }).catch(() => {});
}
// Hovering a video's card plays it in place, as ThreeUI's catalogue does, so a pile of renders can
// be told apart without opening each one. PC only, after a short rest, never with reduced motion.
const hoverFiles = new Map();
let hoverT = 0, hoverVd = null;
// Only one preview streams at a time; the old one lets go of its connection at once.
const dropHover = (vd) => { if (!vd) return; if (hoverVd === vd) hoverVd = null;
  vd.classList.remove("in"); setTimeout(() => { vd.pause(); vd.removeAttribute("src"); vd.load(); vd.remove(); }, 200); };
async function hoverClip(key) {
  if (!hoverFiles.has(key)) { const [p, ...r] = key.split("/");
    hoverFiles.set(key, get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(r.join("/"))}`).then((d) => {
      const v = (d.versions || []).at(-1), f = (v?.files || []).find((f) => f.kind === "video" && f.play);
      return f?.play || null; }).catch(() => null)); }
  return hoverFiles.get(key);
}
document.addEventListener("pointerover", (e) => {
  if (e.pointerType !== "mouse" || RM()) return;
  const card = e.target.closest?.(".gi[data-item]"); if (!card || card.contains(e.relatedTarget)) return;
  const x = D.items.find((y) => iid(y) === card.dataset.item); if (x?.kind !== "video") return;
  clearTimeout(hoverT);
  hoverT = setTimeout(async () => {
    const url = await hoverClip(card.dataset.item); if (!url || !card.matches(":hover") || card.querySelector("video")) return;
    const th = card.querySelector(".th"), vd = document.createElement("video");
    Object.assign(vd, {src: url, muted: true, loop: true, playsInline: true, preload: "metadata"}); vd.className = "hov";
    dropHover(hoverVd); hoverVd = vd;
    vd.addEventListener("playing", () => vd.classList.add("in"), {once: true});
    th.appendChild(vd); vd.play().catch(() => vd.remove());
  }, 350);
});
document.addEventListener("pointerout", (e) => {
  const card = e.target.closest?.(".gi[data-item]"); if (!card || card.contains(e.relatedTarget)) return;
  clearTimeout(hoverT); dropHover(card.querySelector("video.hov"));
});
// A found line with the words marked, for the list's and the search screen's 코멘트 · 요약 results.
const hitRow = (h, q) => { const at = h.hit.toLowerCase().indexOf(q.toLowerCase());
  const hit = at < 0 ? esc(h.hit) : esc(h.hit.slice(0, at)) + `<b>${esc(h.hit.slice(at, at + q.length))}</b>` + esc(h.hit.slice(at + q.length));
  return `<button class="row press hit" data-item="${esc(h.project + "/" + h.id)}"><span class="ico sm c-grey">${ic(h.where === "코멘트" ? "chat" : "doc")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(h.title)}${h.archived ? ` <span class="tag">${tl("hitRow.1")}</span>` : ""}</div><div class="s">${esc(h.where === "코멘트" ? tl("hit.w.comment") : h.where === "요약" ? tl("hit.w.sum") : h.where)} · ${hit}</div></span></button>`; };
// ---------- X15: result card actions (승인 · 맡기기 · 정리), right on the card ----------
// One click per result for a pile that grew too tall to open one by one: 승인, 맡기기 (off the
// list, and its project decides whether a newer cut, a finished one or nothing should come back),
// 정리 (off the list, nobody told). They used to sit behind a ⋯ and a centred sheet; now the row is
// on the card itself (PC: in place of the meta line on hover or focus; touch: always there), and
// 되돌리기 in the toast stands in for the confirm step.
// A settled (approved, no turn) card can still be cleared off the grid - it just needs 정리, not
// the 승인/맡기기 pair. gtri stays the "still needs a decision" predicate for the bulk actions.
const gtri = (x) => !x.finished && !(x.status === "approved" && !turnOf(x));
// Phosphor regular, same source as the P table (licenses/phosphor.md).
Object.assign(P, {
  "sort-descending": '<path d="M40,128a8,8,0,0,1,8-8h72a8,8,0,0,1,0,16H48A8,8,0,0,1,40,128Zm8-56h56a8,8,0,0,0,0-16H48a8,8,0,0,0,0,16ZM184,184H48a8,8,0,0,0,0,16H184a8,8,0,0,0,0-16ZM229.66,82.34l-40-40a8,8,0,0,0-11.32,0l-40,40a8,8,0,0,0,11.32,11.32L176,67.31V144a8,8,0,0,0,16,0V67.31l26.34,26.35a8,8,0,0,0,11.32-11.32Z"/>',
  kbd:'<path fill-rule="evenodd" d="M32 48h192a16 16 0 0 1 16 16v128a16 16 0 0 1-16 16H32a16 16 0 0 1-16-16V64a16 16 0 0 1 16-16Zm0 16v128h192V64ZM60 88h16v16H60Zm40 0h16v16h-16Zm40 0h16v16h-16Zm40 0h16v16h-16ZM60 124h16v16H60Zm40 0h16v16h-16Zm40 0h16v16h-16Zm40 0h16v16h-16ZM84 160h88v16H84Z"/>',
  power:'<path d="M120,128V48a8,8,0,0,1,16,0v80a8,8,0,0,1-16,0Zm60.37-78.7a8,8,0,0,0-8.74,13.4C194.74,77.77,208,101.57,208,128a80,80,0,0,1-160,0c0-26.43,13.26-50.23,36.37-65.3a8,8,0,0,0-8.74-13.4C47.9,67.38,32,96.06,32,128a96,96,0,0,0,192,0C224,96.06,208.1,67.38,180.37,49.3Z"/>',
  wait:'<path d="M200,75.64V40a16,16,0,0,0-16-16H72A16,16,0,0,0,56,40V76a16.07,16.07,0,0,0,6.4,12.8L114.67,128,62.4,167.2A16.07,16.07,0,0,0,56,180v36a16,16,0,0,0,16,16H184a16,16,0,0,0,16-16V180.36a16.09,16.09,0,0,0-6.35-12.77L141.27,128l52.38-39.6A16.05,16.05,0,0,0,200,75.64ZM72,40H184V75.64L178.23,80H77.33L72,76Zm56,78L98.67,96h58.4Zm56,98H72V180l48-36v24a8,8,0,0,0,16,0V144.08l48,36.28Z"/>',
  undo:'<path d="M224,128a96,96,0,0,1-94.71,96H128A95.38,95.38,0,0,1,62.1,197.8a8,8,0,0,1,11-11.63A80,80,0,1,0,71.43,71.39a3.07,3.07,0,0,1-.26.25L44.59,96H72a8,8,0,0,1,0,16H24a8,8,0,0,1-8-8V56a8,8,0,0,1,16,0V85.8L60.25,60A96,96,0,0,1,224,128Z"/>',
  tack:'<path d="M235.32,81.37,174.63,20.69a16,16,0,0,0-22.63,0L98.37,74.49c-10.66-3.34-35-7.37-60.4,13.14a16,16,0,0,0-1.29,23.78L85,159.71,42.34,202.34a8,8,0,0,0,11.32,11.32L96.29,171l48.29,48.29A16,16,0,0,0,155.9,224c.38,0,.75,0,1.13,0a15.93,15.93,0,0,0,11.64-6.33c19.64-26.1,17.75-47.32,13.19-60L235.33,104A16,16,0,0,0,235.32,81.37ZM224,92.69h0l-57.27,57.46a8,8,0,0,0-1.49,9.22c9.46,18.93-1.8,38.59-9.34,48.62L48,100.08c12.08-9.74,23.64-12.31,32.48-12.31A40.13,40.13,0,0,1,96.81,91a8,8,0,0,0,9.25-1.51L163.32,32,224,92.68Z"/>',
  folders:'<path d="M224,64H154.67L126.93,43.2a16.12,16.12,0,0,0-9.6-3.2H72A16,16,0,0,0,56,56V72H40A16,16,0,0,0,24,88V200a16,16,0,0,0,16,16H192.89A15.13,15.13,0,0,0,208,200.89V184h16.89A15.13,15.13,0,0,0,240,168.89V80A16,16,0,0,0,224,64ZM192,200H40V88H85.33l29.87,22.4A8,8,0,0,0,120,112h72Zm32-32H208V112a16,16,0,0,0-16-16H122.67L94.93,75.2a16.12,16.12,0,0,0-9.6-3.2H72V56h45.33L147.2,78.4A8,8,0,0,0,152,80h72Z"/>',
  user:'<path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"/>',
  cal:'<path d="M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z"/>',
  stack:'<path d="M230.91,172A8,8,0,0,1,228,182.91l-96,56a8,8,0,0,1-8.06,0l-96-56A8,8,0,0,1,36,169.09l92,53.65,92-53.65A8,8,0,0,1,230.91,172ZM220,121.09l-92,53.65L36,121.09A8,8,0,0,0,28,134.91l96,56a8,8,0,0,0,8.06,0l96-56A8,8,0,1,0,220,121.09ZM24,80a8,8,0,0,1,4-6.91l96-56a8,8,0,0,1,8.06,0l96,56a8,8,0,0,1,0,13.82l-96,56a8,8,0,0,1-8.06,0l-96-56A8,8,0,0,1,24,80Zm23.88,0L128,126.74,208.12,80,128,33.26Z"/>',
  note:'<path d="M229.66,58.34l-32-32a8,8,0,0,0-11.32,0l-96,96A8,8,0,0,0,88,128v32a8,8,0,0,0,8,8h32a8,8,0,0,0,5.66-2.34l96-96A8,8,0,0,0,229.66,58.34ZM124.69,152H104V131.31l64-64L188.69,88ZM200,76.69,179.31,56,192,43.31,212.69,64ZM224,128v80a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V48A16,16,0,0,1,48,32h80a8,8,0,0,1,0,16H48V208H208V128a8,8,0,0,1,16,0Z"/>',
  sun:'<path d="M120,40V16a8,8,0,0,1,16,0V40a8,8,0,0,1-16,0Zm72,88a64,64,0,1,1-64-64A64.07,64.07,0,0,1,192,128Zm-16,0a48,48,0,1,0-48,48A48.05,48.05,0,0,0,176,128ZM58.34,69.66A8,8,0,0,0,69.66,58.34l-16-16A8,8,0,0,0,42.34,53.66Zm0,116.68-16,16a8,8,0,0,0,11.32,11.32l16-16a8,8,0,0,0-11.32-11.32ZM192,72a8,8,0,0,0,5.66-2.34l16-16a8,8,0,0,0-11.32-11.32l-16,16A8,8,0,0,0,192,72Zm5.66,114.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32-11.32ZM48,128a8,8,0,0,0-8-8H16a8,8,0,0,0,0,16H40A8,8,0,0,0,48,128Zm80,80a8,8,0,0,0-8,8v24a8,8,0,0,0,16,0V216A8,8,0,0,0,128,208Zm112-88H216a8,8,0,0,0,0,16h24a8,8,0,0,0,0-16Z"/>',
  ask:'<path d="M140,180a12,12,0,1,1-12-12A12,12,0,0,1,140,180ZM128,72c-22.06,0-40,16.15-40,36v4a8,8,0,0,0,16,0v-4c0-11,10.77-20,24-20s24,9,24,20-10.77,20-24,20a8,8,0,0,0-8,8v8a8,8,0,0,0,16,0v-.72c18.24-3.35,32-17.9,32-35.28C168,88.15,150.06,72,128,72Zm104,56A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/>',
  shield:'<path d="M208,40H48A16,16,0,0,0,32,56v56c0,52.72,25.52,84.67,46.93,102.19,23.06,18.86,46,25.26,47,25.53a8,8,0,0,0,4.2,0c1-.27,23.91-6.67,47-25.53C198.48,196.67,224,164.72,224,112V56A16,16,0,0,0,208,40Zm0,72c0,37.07-13.66,67.16-40.6,89.42A129.3,129.3,0,0,1,128,223.62a128.25,128.25,0,0,1-38.92-21.81C61.82,179.51,48,149.3,48,112l0-56,160,0ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"/>',
  copy:'<path d="M216,32H88a8,8,0,0,0-8,8V80H40a8,8,0,0,0-8,8V216a8,8,0,0,0,8,8H168a8,8,0,0,0,8-8V176h40a8,8,0,0,0,8-8V40A8,8,0,0,0,216,32ZM160,208H48V96H160Zm48-48H176V88a8,8,0,0,0-8-8H96V48H208Z"/>',
  sliders:'<path d="M40,88H73a32,32,0,0,0,62,0h81a8,8,0,0,0,0-16H135a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16Zm64-24A16,16,0,1,1,88,80,16,16,0,0,1,104,64ZM216,168H199a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16h97a32,32,0,0,0,62,0h17a8,8,0,0,0,0-16Zm-48,24a16,16,0,1,1,16-16A16,16,0,0,1,168,192Z"/>',
  monitor:'<path d="M208,40H48A24,24,0,0,0,24,64V176a24,24,0,0,0,24,24H208a24,24,0,0,0,24-24V64A24,24,0,0,0,208,40Zm8,136a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V64a8,8,0,0,1,8-8H208a8,8,0,0,1,8,8Zm-48,48a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,224Z"/>',
  phone:'<path d="M176,16H80A24,24,0,0,0,56,40V216a24,24,0,0,0,24,24h96a24,24,0,0,0,24-24V40A24,24,0,0,0,176,16ZM72,64H184V192H72Zm8-32h96a8,8,0,0,1,8,8v8H72V40A8,8,0,0,1,80,32Zm96,192H80a8,8,0,0,1-8-8v-8H184v8A8,8,0,0,1,176,224Z"/>',
  bolt:'<path d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"/>',
  scroll:'<path d="M96,104a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H104A8,8,0,0,1,96,104Zm8,40h64a8,8,0,0,0,0-16H104a8,8,0,0,0,0,16Zm128,48a32,32,0,0,1-32,32H88a32,32,0,0,1-32-32V64a16,16,0,0,0-32,0c0,5.74,4.83,9.62,4.88,9.66h0A8,8,0,0,1,24,88a7.89,7.89,0,0,1-4.79-1.61h0C18.05,85.54,8,77.61,8,64A32,32,0,0,1,40,32H176a32,32,0,0,1,32,32V168h8a8,8,0,0,1,4.8,1.6C222,170.46,232,178.39,232,192ZM96.26,173.48A8.07,8.07,0,0,1,104,168h88V64a16,16,0,0,0-16-16H67.69A31.71,31.71,0,0,1,72,64V192a16,16,0,0,0,32,0c0-5.74-4.83-9.62-4.88-9.66A7.82,7.82,0,0,1,96.26,173.48ZM216,192a12.58,12.58,0,0,0-3.23-8h-94a26.92,26.92,0,0,1,1.21,8,31.82,31.82,0,0,1-4.29,16H200A16,16,0,0,0,216,192Z"/>',
  stopfill:'<rect x="56" y="56" width="144" height="144" rx="28"/>',
  mic:'<path d="M128,176a48.05,48.05,0,0,0,48-48V64a48,48,0,0,0-96,0v64A48.05,48.05,0,0,0,128,176ZM96,64a32,32,0,0,1,64,0v64a32,32,0,0,1-64,0Zm40,143.6V240a8,8,0,0,1-16,0V207.6A80.11,80.11,0,0,1,48,128a8,8,0,0,1,16,0,64,64,0,0,0,128,0,8,8,0,0,1,16,0A80.11,80.11,0,0,1,136,207.6Z"/>',
  globe:'<path d="M128,24h0A104,104,0,1,0,232,128,104.12,104.12,0,0,0,128,24Zm87.62,96H175.79C174,83.49,159.94,57.67,148.41,42.4A88.19,88.19,0,0,1,215.63,120ZM96.23,136h63.54c-2.31,41.61-22.23,67.11-31.77,77C118.45,203.1,98.54,177.6,96.23,136Zm0-16C98.54,78.39,118.46,52.89,128,43c9.55,9.93,29.46,35.43,31.77,77Zm11.36-77.6C96.06,57.67,82,83.49,80.21,120H40.37A88.19,88.19,0,0,1,107.59,42.4ZM40.37,136H80.21c1.82,36.51,15.85,62.33,27.38,77.6A88.19,88.19,0,0,1,40.37,136Zm108,77.6c11.53-15.27,25.56-41.09,27.38-77.6h39.84A88.19,88.19,0,0,1,148.41,213.6Z"/>',
  toggle:'<path d="M176,56H80a72,72,0,0,0,0,144h96a72,72,0,0,0,0-144Zm0,128H80A56,56,0,0,1,80,72h96a56,56,0,0,1,0,112ZM80,88a40,40,0,1,0,40,40A40,40,0,0,0,80,88Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,80,152Z"/>',
  info:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"/>',
  steth:'<path d="M220,160a12,12,0,1,1-12-12A12,12,0,0,1,220,160Zm-4.55,39.29A48.08,48.08,0,0,1,168,240H144a48.05,48.05,0,0,1-48-48V151.49A64,64,0,0,1,40,88V40a8,8,0,0,1,8-8H72a8,8,0,0,1,0,16H56V88a48,48,0,0,0,48.64,48c26.11-.34,47.36-22.25,47.36-48.83V48H136a8,8,0,0,1,0-16h24a8,8,0,0,1,8,8V87.17c0,32.84-24.53,60.29-56,64.31V192a32,32,0,0,0,32,32h24a32.06,32.06,0,0,0,31.22-25,40,40,0,1,1,16.23.27ZM232,160a24,24,0,1,0-24,24A24,24,0,0,0,232,160Z"/>',
  import:'<path d="M223.16,68.42l-16-32A8,8,0,0,0,200,32H56a8,8,0,0,0-7.16,4.42l-16,32A8.08,8.08,0,0,0,32,72V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V72A8.08,8.08,0,0,0,223.16,68.42ZM60.94,48H195.06l8,16H52.94ZM208,208H48V80H208V208Zm-42.34-61.66a8,8,0,0,1,0,11.32l-32,32a8,8,0,0,1-11.32,0l-32-32a8,8,0,0,1,11.32-11.32L120,164.69V104a8,8,0,0,1,16,0v60.69l18.34-18.35A8,8,0,0,1,165.66,146.34Z"/>',
  key:'<path d="M216.57,39.43A80,80,0,0,0,83.91,120.78L28.69,176A15.86,15.86,0,0,0,24,187.31V216a16,16,0,0,0,16,16H72a8,8,0,0,0,8-8V208H96a8,8,0,0,0,8-8V184h16a8,8,0,0,0,5.66-2.34l9.56-9.57A79.73,79.73,0,0,0,160,176h.1A80,80,0,0,0,216.57,39.43ZM224,98.1c-1.09,34.09-29.75,61.86-63.89,61.9H160a63.7,63.7,0,0,1-23.65-4.51,8,8,0,0,0-8.84,1.68L116.69,168H96a8,8,0,0,0-8,8v16H72a8,8,0,0,0-8,8v16H40V187.31l58.83-58.82a8,8,0,0,0,1.68-8.84A63.72,63.72,0,0,1,96,95.92c0-34.14,27.81-62.8,61.9-63.89A64,64,0,0,1,224,98.1ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z"/>',
  hist:'<path d="M136,80v43.47l36.12,21.67a8,8,0,0,1-8.24,13.72l-40-24A8,8,0,0,1,120,128V80a8,8,0,0,1,16,0Zm-8-48A95.44,95.44,0,0,0,60.08,60.15C52.81,67.51,46.35,74.59,40,82V64a8,8,0,0,0-16,0v40a8,8,0,0,0,8,8H72a8,8,0,0,0,0-16H49c7.15-8.42,14.27-16.35,22.39-24.57a80,80,0,1,1,1.66,114.75,8,8,0,1,0-11,11.64A96,96,0,1,0,128,32Z"/>',
  eye:'<path d="M247.31,124.76c-.35-.79-8.82-19.58-27.65-38.41C194.57,61.26,162.88,48,128,48S61.43,61.26,36.34,86.35C17.51,105.18,9,124,8.69,124.76a8,8,0,0,0,0,6.5c.35.79,8.82,19.57,27.65,38.4C61.43,194.74,93.12,208,128,208s66.57-13.26,91.66-38.34c18.83-18.83,27.3-37.61,27.65-38.4A8,8,0,0,0,247.31,124.76ZM128,192c-30.78,0-57.67-11.19-79.93-33.25A133.47,133.47,0,0,1,25,128,133.33,133.33,0,0,1,48.07,97.25C70.33,75.19,97.22,64,128,64s57.67,11.19,79.93,33.25A133.46,133.46,0,0,1,231.05,128C223.84,141.46,192.43,192,128,192Zm0-112a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Z"/>',
  checkCircle:'<path d="M173.66,98.34a8,8,0,0,1,0,11.32l-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35A8,8,0,0,1,173.66,98.34ZM232,128A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/>',
  bendBack:'<path d="M232,200a8,8,0,0,1-16,0,88.1,88.1,0,0,0-88-88H51.31l34.35,34.34a8,8,0,0,1-11.32,11.32l-48-48a8,8,0,0,1,0-11.32l48-48A8,8,0,0,1,85.66,61.66L51.31,96H128A104.11,104.11,0,0,1,232,200Z"/>',
});
// Which glyph each action wears. Swapping one after the user's pick is this one line.
const GACT_IC = {ok: "checkCircle", tri: "bendBack", off: "archive", fin: "flag", re: "undo"};
// The app's own spring (motion.js puts it on :root as --m-snap), so the cards move as everything else does.
const gaSpring = () => { const c = getComputedStyle(document.documentElement);
  return {easing: c.getPropertyValue("--m-snap").trim() || "cubic-bezier(.2,.9,.25,1)", duration: parseFloat(c.getPropertyValue("--m-snap-d")) || 420}; };
// One 되돌리기 at a time. A new action inside the six seconds sends the waiting one at once (it was
// going to be sent anyway, only without a way back), and the toast is about the latest.
const gaSettle = () => { sendMany(); triSend(); };
let gactOpen = "";                         // narrowest cards: whose 맡기기/정리 are unfolded
// Named gmore for its two call sites (libDraw, deptView); it is the whole row now. The long
// explanations the sheet had are the tooltips.
const gmore = (x) => {
  const k = esc(iid(x)), one = (a, t, h, c, w = t) => `<button class="ga press ${c}" data-ga="${a}" data-gk="${k}" aria-label="${esc(t)}" title="${esc(h)}">${ic(GACT_IC[a])}<span>${w}</span></button>`;
  // 끝난 작업: 다시 열기 takes it back to its list, 정리 puts it away for good (the archive).
  if (x.finished) return `<div class="gact two" role="group" aria-label="${tl("gact.6")}">${one("re", tl("fin.re"), tl("fin.re.h"), "mid")}${one("off", tl("gact.4"), tl("gact.3"), "quiet")}</div>`;
  return `<div class="gact${gactOpen === iid(x) ? " open" : ""}" role="group" aria-label="${tl("gact.6")}">${gtri(x)
    ? one("ok", tl("gact.9"), tl("gact.5") + (tkPage() === "lib" ? " (A)" : ""), "pri") + `<button class="gax press" data-gax="${k}" aria-label="${tl("gact.7")}" aria-expanded="${gactOpen === iid(x)}">${ic("more")}</button>` + one("tri", tl("gact.2"), tl("gact.1"), "mid") : ""}${one("fin", tl("fin.do"), tl("fin.do.h"), "quiet", tl("fin.short"))}</div>`;
};
// The card that left shrinks away where it stood and the rest spring into the gap (FLIP), instead
// of the grid snapping. fn redraws; a redraw in the middle (되돌리기) just starts from where things
// are. Reduced motion: a plain fade, nothing slides.
const gaCalm = async () => { while (performance.now() < gaBusy) await new Promise((r) => setTimeout(r, gaBusy - performance.now() + 20)); };
// A card that stays through a redraw keeps the picture it had: the new <img> would load and fade in again.
const gaGone = new Map();                  // the picture a card left with: 되돌리기 brings it back whole, not as a placeholder
function gaPics(fn) {
  const had = new Map([...V().querySelectorAll(".gw")].map((el) => [el.querySelector(".gi")?.dataset.item, el.querySelector(".th img:not(.loading)")]));
  fn();
  V().querySelectorAll(".gw").forEach((el) => { const a = had.get(el.querySelector(".gi")?.dataset.item), b = el.querySelector(".th img");
    if (a && b && a !== b && a.getAttribute("src") === b.getAttribute("src")) { a.classList.remove("imgin"); b.replaceWith(a); } });
  had.forEach((img, k) => { if (k && img && !img.isConnected) { if (gaGone.size > 40) gaGone.clear(); gaGone.set(k, img); } });
}
// While the cards are moving nothing on them answers: the neighbour slides in under the pointer
// with 정리 exactly where the last 정리 was, and the second half of a double click cleared it too.
let gaMoveT = 0;
const gaMove = (ms) => { document.body.classList.add("gamove"); clearTimeout(gaMoveT); gaMoveT = setTimeout(() => document.body.classList.remove("gamove"), ms); };
function gactFlip(fn) {
  const cards = () => [...V().querySelectorAll(".gw")].map((el) => [el.querySelector(".gi")?.dataset.item, el]);
  // Fresh cards are content-visibility:auto and measure as 300px placeholders until their first
  // paint: read in that state, every card "moved" by hundreds of px and sprang back. The cards
  // within a screen of the viewport are measured whole (.gafl); the rest keep the height they had
  // (measuring all 259 of a long list whole took 160ms of the click). `at` is where each card
  // really is on the screen right now, for the ghost.
  const H = innerHeight, at = new Map(cards().map(([k, el]) => [k, el.getBoundingClientRect()]));
  const near = (r) => r.bottom > -H && r.top < 2 * H, nr = new Set([...at].filter(([, r]) => near(r)).map(([k]) => k));
  cards().forEach(([k, el]) => { if (nr.has(k)) el.classList.add("gafl"); });
  const was = new Map(cards().map(([k, el]) => [k, [el, el.getBoundingClientRect()]])), rm = RM(), sp = gaSpring();
  // The pressed button is seen (hold), the card goes, and only then do the others set off: a
  // neighbour sliding over a card that is still solid read as two cards printed on each other.
  // (Nothing leaving - a card coming back - and they all move at once.)
  gaPics(fn);
  cards().forEach(([k, el]) => { const o = was.get(k);
    if (!o || nr.has(k)) el.classList.add("gafl"); else el.style.containIntrinsicHeight = `auto ${o[1].height}px`; });
  const now = new Set(cards().map(([k]) => k)), hold = [...was.values()].some(([el]) => el.querySelector(".ga.done")) ? 60 : 0,
    lag = rm || ![...was.keys()].some((k) => k && !now.has(k)) ? 0 : hold + 50;
  gaBusy = performance.now() + (rm ? 160 : sp.duration) + lag; gaMove((rm ? 160 : sp.duration) + lag);
  // A card coming back while its ghost is still leaving (되돌리기 mid-way) starts from where the ghost is.
  const gh = new Map();
  document.querySelectorAll(".gaghost").forEach((g) => { const c = getComputedStyle(g); gh.set(g.querySelector(".gi")?.dataset.item, [c.opacity, c.transform]); g.remove(); });
  cards().forEach(([k, el]) => { const o = was.get(k), r = el.getBoundingClientRect();
    if (r.bottom < 0 || r.top > H) return;
    if (!o) { const h = gh.get(k), a = gaGone.get(k), b = el.querySelector(".th img");
      if (a && b && a.getAttribute("src") === b.getAttribute("src")) { a.classList.remove("imgin"); b.replaceWith(a); }
      gaGone.delete(k);
      return el.animate([{opacity: h ? h[0] : 0, transform: rm ? "none" : h ? h[1] : "scale(.94)"}, {opacity: 1, transform: "none"}], rm ? {duration: 160, easing: "ease-out"} : sp); }
    const dx = o[1].left - r.left, dy = o[1].top - r.top;
    if (!o[1].width || !(dx || dy)) return;
    // Reduced motion: nothing slides - a card that changed places fades in where it now is.
    if (rm) el.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
    else el.animate([{transform: `translate(${dx}px,${dy}px)`}, {transform: "none"}], {...sp, delay: lag, fill: "backwards"}); });
  was.forEach(([el], k) => { const r = at.get(k); if (!k || now.has(k) || !r.width || r.bottom < 0 || r.top > H) return;
    const g = el.cloneNode(true); g.className = "gw gaghost"; g.setAttribute("aria-hidden", "true");
    g.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
    document.body.appendChild(g);
    g.animate(rm ? [{opacity: 1}, {opacity: 0}] : [{opacity: 1, transform: "none"}, {opacity: 0, transform: "scale(.95)"}],
      {duration: rm ? 160 : 150, delay: rm ? 0 : hold, easing: "ease-out", fill: "forwards"}).onfinish = () => g.remove(); });
  V().querySelectorAll(".gw.gafl").forEach((el) => { el.style.containIntrinsicHeight = `auto ${el.offsetHeight}px`; el.classList.remove("gafl"); });
}
// A redraw replaces every card: the one that had the keyboard focus gets it back.
const gactDraw = () => { const f = document.activeElement?.closest?.(".gw > .gi")?.dataset.item;
  gaPics(() => { if (cur === "lib" && !detail) libDraw(); redrawDept(); });
  if (f) [...V().querySelectorAll(".gw > .gi")].find((b) => b.dataset.item === f)?.focus({preventScroll: true}); };
// 정리 is sent at once; 되돌리기 takes it back out of the archive, as it was (undo: no "kept" mark).
async function libOff(xs, how) {
  gaSettle();
  if (how === "tri") return triage(xs);
  if (how === "fin" || how === "re") return libFin(xs, how === "fin");
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const bad = [];
  for (const x of xs) {
    try { await post("/api/archive", {p: x.project, i: x.id, on: true}); }
    catch (e) { bad.push(x); libHide.delete(iid(x)); } }
  const ok = xs.filter((x) => !bad.includes(x));
  if (ok.length) toastAct(tl("libOff.2", {n: ok.length}), tl("toggleFav.3"), async () => {
    for (const x of ok) await post("/api/archive", {p: x.project, i: x.id, on: false, undo: true}).catch(() => {});
    await load(); gactFlip(() => { ok.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); toast(tl("libOff.3"), 2200, "restore"); }, 6000, "archive");
  if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
  // The answer comes within the spring: the redraw waits for the cards to settle, or it would cut it short.
  await load(); await gaCalm(); ok.forEach((x) => libHide.delete(iid(x))); gactDraw();
}
// 작업 끝내기 is a mark on the result, sent at once: the card leaves for 끝난 작업 and nothing
// derived (a comment read, a waiting session) brings it back. 되돌리기 - or 다시 열기 there -
// takes the mark off and the result is back where its status puts it.
async function libFin(xs, on, undo = true) {
  gaSettle();
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const bad = [];
  for (const x of xs) {
    try { await post("/api/finish", {p: x.project, i: x.id, on}); }
    catch (e) { bad.push(x); } }
  const ok = xs.filter((x) => !bad.includes(x)), said = on ? tl("fin.done", {n: ok.length}) : tl("fin.back");
  if (ok.length && undo) toastAct(said, tl("toggleFav.3"), () => libFin(ok, !on, false), 6000, on ? "finish" : "restore");
  else if (ok.length) toast(said, 2200, on ? "finish" : "restore");
  if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
  await load(); await gaCalm();
  const draw = () => { xs.forEach((x) => libHide.delete(iid(x))); gactDraw(); };
  // 되돌리기 brings the card back into the list on screen: it springs in like any card that returns.
  undo ? draw() : gactFlip(draw);
}
// The same on the item's own screen (the chip under the title): the screen stays, its status turns.
async function itemFin(p, i, on, undo = true) {
  try { await post("/api/finish", {p, i, on}); } catch (e) { return toast(tl("libOff.4", {n: 1}), 4000); }
  await load(); again();
  const t = on ? tl("fin.done", {n: 1}) : tl("fin.back");
  if (undo) toastAct(t, tl("toggleFav.3"), () => itemFin(p, i, !on, false), 6000, on ? "finish" : "restore");
  else toast(t, 2200, on ? "finish" : "restore");
}
// 맡기기 tells the project, and that cannot be unsaid: like 승인 it is off the list at once but only
// sent once the six seconds of 되돌리기 are over (or the page is left), so taking it back is real.
let triLater = null;
function triage(xs) {
  if (!xs.length) return;
  triSend();
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const o = triLater = {xs};                // sent when the toast's time is up (it waits while the toast is held)
  toastAct(tl("libOff.1", {n: xs.length}), tl("toggleFav.3"), () => {
    if (!triLater) return toast(tl("gact.8"));
    clearTimeout(triLater.timer); const back = triLater.xs; triLater = null;
    gactFlip(() => { back.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); toast(tl("libOff.3"), 2200, "restore"); }, 6000, "archive", () => { if (triLater === o) triSend(); });
}
function triSend() {
  const o = triLater; if (!o) return; triLater = null; clearTimeout(o.timer);
  Promise.all(o.xs.map((x) => fetch("/api/triage", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: x.project, i: x.id, on: true})}).then((r) => r.ok ? null : x, () => x)))
    .then(async (bad) => { bad = bad.filter(Boolean); await load(); o.xs.forEach((x) => libHide.delete(iid(x)));
      if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
      if (!document.activeElement?.matches?.("input,textarea,gk-select")) gactDraw(); });
}
addEventListener("pagehide", () => { triSend(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) triSend(); });
document.addEventListener("click", (e) => { const m = e.target.closest("[data-gax]");
  if (m) { e.stopPropagation(); gactOpen = gactOpen === m.dataset.gax ? "" : m.dataset.gax;
    document.querySelectorAll(".gact").forEach((r) => { const on = !!gactOpen && r.querySelector("[data-gax]")?.dataset.gax === gactOpen; r.classList.toggle("open", on); r.querySelector("[data-gax]")?.setAttribute("aria-expanded", on); }); return; }
  const b = e.target.closest("[data-ga]"); if (!b) return;
  if (gaTipped) { gaTipped = false; e.stopPropagation(); e.preventDefault(); return; }   // that press was a hold to read, not a tap
  e.stopPropagation(); const x = D.items.find((y) => iid(y) === b.dataset.gk); if (!x) return;
  gactOpen = "";
  // From the keyboard the focus would fall off with the card: it moves on to the card that takes its place.
  const at = e.detail || !e.isTrusted ? -1 : [...V().querySelectorAll(".gw")].indexOf(b.closest(".gw"));
  b.classList.add("done");                // the pressed state leaves with the card (the ghost is a copy of it)
  gactFlip(() => { b.dataset.ga === "ok" ? approveMany([x], 6000) : libOff([x], b.dataset.ga); });
  if (at >= 0) { const L = V().querySelectorAll(".gw > .gi"); L[Math.min(at, L.length - 1)]?.focus({preventScroll: true}); } }, true);
// Held on a touch screen, a button says what it does (its tooltip, which a finger cannot hover for),
// and the press that showed it does nothing.
let gaTipT = 0, gaTipped = false;
const gaTipOff = () => document.querySelectorAll(".gatip").forEach((t) => t.remove());
document.addEventListener("pointerdown", (e) => { clearTimeout(gaTipT); gaTipOff(); gaTipped = false;
  const b = e.pointerType !== "mouse" && e.target.closest?.(".ga[title]"); if (!b) return;
  gaTipT = setTimeout(() => { gaTipped = true;
    const t = document.createElement("div"), r = b.getBoundingClientRect(); t.className = "gatip"; t.setAttribute("role", "tooltip"); t.textContent = b.title;
    document.body.appendChild(t);
    t.style.left = Math.max(12, Math.min(innerWidth - t.offsetWidth - 12, r.left + r.width / 2 - t.offsetWidth / 2)) + "px";
    t.style.top = Math.max(12, r.top - t.offsetHeight - 8) + "px"; }, 450); }, true);
["pointerup", "pointercancel"].forEach((n) => document.addEventListener(n, () => { clearTimeout(gaTipT); if (gaTipped) gaTipT = setTimeout(gaTipOff, 2600); }, true));
document.addEventListener("contextmenu", (e) => { if (gaTipped && e.target.closest?.(".ga")) e.preventDefault(); }, true);
// Held on a touch screen, a results card starts 여러 개 승인 with that card picked (as a phone's photo
// or mail list does), where the list offers it; the lift that ended the hold opens nothing.
let gpT = 0, gpXY = null, gpHeld = 0;
document.addEventListener("pointerdown", (e) => { clearTimeout(gpT); gpXY = null;
  const c = e.pointerType !== "mouse" && !libSel && !detail && e.target.closest?.("#view .gi[data-item]"); if (!c || !document.getElementById("selon")) return;
  gpXY = [e.clientX, e.clientY];
  gpT = setTimeout(() => { gpXY = null; if (!c.isConnected || libSel || !document.getElementById("selon")) return;
    gpHeld = performance.now(); libSel = new Set([c.dataset.item]); libDraw(); if (navigator.vibrate) navigator.vibrate(12); }, 520); }, true);
document.addEventListener("pointermove", (e) => { if (gpXY && Math.hypot(e.clientX - gpXY[0], e.clientY - gpXY[1]) > 8) { clearTimeout(gpT); gpXY = null; } }, true);
["pointerup", "pointercancel"].forEach((n) => document.addEventListener(n, () => { clearTimeout(gpT); gpXY = null; }, true));
document.addEventListener("click", (e) => { if (gpHeld && performance.now() - gpHeld < 1200) { gpHeld = 0; e.preventDefault(); e.stopPropagation(); } }, true);
document.addEventListener("contextmenu", (e) => { if (gpHeld && performance.now() - gpHeld < 1200 && e.target.closest?.("#view .gi")) e.preventDefault(); }, true);
// ---------- /X15 ----------
// Several approved at once: gone from the list at once, sent after five seconds unless taken back.
let manyLater = null;
// The item's review detail (rev, directives) for a decision made from a list row.
const itemDetail = (p, i) => get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`).catch(() => null);
const itemRev = (p, i) => itemDetail(p, i).then((d) => d?.rev ?? d?.review?.rev);
function approveMany(xs, ms = 5000) {
  if (!xs.length) return;
  sendMany(); triSend();
  libSel = null; xs.forEach((x) => libHide.add(iid(x))); libDraw(); redrawTurn(); redrawDept();
  // Board rows carry no review rev, and an approval without one is refused: read it during the
  // five seconds, so the approval names the revision that was there when the reader said yes.
  xs.forEach((x) => { if (x.rev == null) x.revP = itemRev(x.project, x.id).then((r) => { x.rev = r; }); });
  const o = manyLater = {xs};               // sent when the toast's time is up (it waits while the toast is held)
  toastAct(tl("approveMany.1", {n: xs.length}), tl("toggleFav.3"), () => {
    if (!manyLater) return toast(tl("approveMany.2"));
    clearTimeout(manyLater.timer); const back = manyLater.xs; manyLater = null;
    toast(tl("approveMany.3"), 2200, "undo"); gactFlip(() => { back.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); redrawTurn(); }, ms, "approve", () => { if (manyLater === o) sendMany(); });
}
function sendMany() {
  const o = manyLater; if (!o) return; manyLater = null; clearTimeout(o.timer);
  Promise.all(o.xs.map((x) => (x.rev == null && x.revP || Promise.resolve()).then(() => fetch("/api/status", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: x.project, i: x.id, v: x.v, status: "approved", rev: x.rev})})).then((r) => r.ok ? null : x, () => x)))
    .then(async (bad) => { bad = bad.filter(Boolean); await load(); o.xs.forEach((x) => libHide.delete(iid(x)));
      if (bad.length) toast(tl("sendMany.1", {n: bad.length}), 4000);
      if (!document.activeElement?.matches?.("input,textarea,gk-select")) { if (cur === "lib" && !detail) libDraw(); redrawTurn(); } });
}
addEventListener("pagehide", () => { sendMany(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) sendMany(); });

// One version's picture: its first file that has one.
const shotOf = (v) => { const f = (v.files || []).find((f) => f.thumb || f.kind === "image") || (v.files || [])[0];
  return f ? {img: f.kind === "image" ? f.url : f.thumb, video: f.kind === "video" ? (f.play || f.url) : null, kind: f.kind, url: f.url} : {}; };
// What the viewer can show full screen: pictures and videos. The rest open as links.
const viewable = (f) => f.kind === "image" || f.kind === "video";
// The item on screen, for the decide buttons. Kept off the DOM: a data-item on #view would
// make every click inside it read as "open this item".
let openItem = null;
// The result page. The file being looked at stays on screen (swipe or arrows between
// files, videos play in place); below it one card with tabs, because usually only one of
// 질문 / 코멘트 is used. The version is a small chip, since the latest is what is checked.
let stageAt = 0, stageOf = null, stageGo = null, stageFit = null, stageZoom = null;
const verPick = {}, tabPick = {}, cmpPick = {};
// Version timeline: the 비교 toggle and which versions are picked while it is on (transient,
// reset when the open item changes). pendingCmp/cmpSeek carry a compare state read from the
// address (#item/<id>?cmp=..&m=..&t=..) into the first draw of that item.
let cmpToggle = false, tlSel = [], tlItem = null, pendingCmp = null, cmpSeek = null;
// A request of the last version ticked off as fixed: this browser's own note, kept by comment.
const fxMem = {};
const isFixed = (id) => { if (id in fxMem) return fxMem[id]; try { return localStorage.getItem("fx:" + id) === "1"; } catch { return false; } };
const setFixed = (id, on) => { fxMem[id] = on; try { on ? localStorage.setItem("fx:" + id, "1") : localStorage.removeItem("fx:" + id); } catch {} };
// A pushed link (/i/<p>/<i>/<v>) arrives as /?v=<v>#item/<p>/<i>: open that version.
{ const q = new URLSearchParams(location.search).get("v"), m = location.hash.match(/^#item\/(.+)$/);
  if (q && m) verPick[decodeURIComponent(m[1])] = q;
  if (location.search) history.replaceState(null, "", "/" + (IN_APP ? "?app=1" : FLOAT ? "?float=1" : "") + location.hash); }
let dockOpenOf = "";              // the item whose comment tools are out (a report's stay folded until the box is used)
let dirsOpenOf = "";              // the item whose 요청 fold is open; closed unless asked for
let xtraOpenOf = "";              // the item whose 기록과 정리 fold is open
let imMoreOf = "";                // the item whose 더 보기 (meta chips) is open
let pageW = "pc"; try { pageW = localStorage.getItem("pageW") || "pc"; } catch {}
// The zoom of a shown HTML result (PC): the report inside the frame, apart from the app's screen size.
const PAGE_Z = [0.5, 0.67, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2];
let pageZ = 1; try { const z = +localStorage.getItem("pageZ"); if (PAGE_Z.includes(z)) pageZ = z; } catch {}
// The same four buttons on a picture and on a page: out, the size now (press: 100%), in, fit.
const zoomCtl = (cls, label) => `<div class="zctl ${cls}" role="group" aria-label="${label}"><button class="press" data-z="-1" aria-label="${tl("zoom.out")}" title="${tl("zoom.out")}">${ic("minus")}</button><button class="press zpct num" data-z="100" aria-label="${tl("zoom.actual")}" title="${tl("zoom.actual")}"></button><button class="press" data-z="1" aria-label="${tl("zoom.in")}" title="${tl("zoom.in")}">${ic("plus")}</button><button class="press" data-z="0" aria-label="${tl("zoom.fit")}" title="${tl("zoom.fit")}">${ic("fit")}</button></div>`;
// The next thing waiting for a look, after the one open: so a run through the list
// is one tap each, and a line for it can go without leaving this one.
// Only 확인 필요 counts: a new version already answered in words is the department's move.
const toCheck = () => myTurn();
// The same department's pile comes first: its results are usually looked at together.
// The one before it in the same walk (Shift+N / ↑): the mirror of nextOf, wrapping the same way.
const prevOf = (id) => {
  const l = toCheck().reverse(), me = D.items.find((x) => iid(x) === id), who = (x) => gname(x);
  const same = me ? l.filter((x) => who(x) === who(me)) : [], at = same.findIndex((x) => iid(x) === id);
  return same[at + 1] || same.find((x) => iid(x) !== id) || l.find((x) => iid(x) !== id && (!me || who(x) !== who(me))) || l.find((x) => iid(x) !== id);
};
const nextOf = (id) => {
  const l = toCheck(), me = D.items.find((x) => iid(x) === id), who = (x) => gname(x);
  const same = me ? l.filter((x) => who(x) === who(me)) : [], at = same.findIndex((x) => iid(x) === id);
  return same[at + 1] || same.find((x) => iid(x) !== id) || l.find((x) => iid(x) !== id && (!me || who(x) !== who(me))) || l.find((x) => iid(x) !== id);
};
function nextCard(id) {
  const x = nextOf(id); if (!x) return "";
  const me = D.items.find((y) => iid(y) === id);
  const who = (y) => gname(y), rest = toCheck().filter((y) => iid(y) !== id), mine = rest.filter((y) => who(y) === who(x)).length;
  return `<div class="card nextrev" id="nextrev" data-nx="${esc(iid(x))}">
    <button class="nxgo press" data-item="${esc(iid(x))}" aria-label="${tl("nextCard.4", {esc: esc(x.title)})}">
      <span class="nxth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.thumb && x.kind === "video" ? `<span class="play">${ic("play", "i f")}</span>` : ""}</span>
      <span class="tx"><div class="s"><b>${tl("nextCard.3")}</b> · <span class="num">${tl("nextCard.2", {n: rest.length})}</span></div><div class="t">${me && gname(me) === gname(x) ? "" : esc(pname(gname(x))) + " · "}${esc(x.title)}</div></span>${ic("chev", "i go")}</button>
  </div>`;
}
// `mount`: an element to draw into instead of the page (the workroom's stage, the phone's
// result sheet). The header and the page-only bars are left out; everything else is the same code.
// A line typed here: its words, then the pictures its 📎 paths point at (kept under the hub's
// item/_attach, so the last three parts of the path are its /f/ address).
function attOf(text) {
  const urls = [], words = String(text).split("\n").filter((l) => {
    const m = l.match(/^📎 .*[\\/]([^\\/]+)[\\/]([^\\/]+)[\\/]_attach[\\/]([^\\/]+)$/);
    if (m) urls.push(`/f/${encodeURIComponent(m[1])}/${encodeURIComponent(m[2])}/_attach/${encodeURIComponent(m[3])}`);
    return !m;
  }).join("\n");
  return {words, urls};
}
// pgquote:begin
// A comment on a passage of a shown HTML report carries the passage as its first line, a markdown
// quote ("> words"): the session reads where it is meant, and the reader's log can go back to it.
const PGQ_MAX = 160;
function quoteLine(sel) {
  const q = String(sel || "").replace(/\s+/g, " ").trim();
  return q.length > PGQ_MAX ? q.slice(0, PGQ_MAX).trimEnd() + "…" : q;
}
function quoteOf(words) {
  const m = /^> ([^\n]+)(?:\n|$)/.exec(String(words || ""));
  if (!m || !m[1].trim()) return null;
  // A second line "→ words" is what the reader wants there instead.
  const rest = words.slice(m[0].length), to = /^→ ([^\n]+)(?:\n|$)/.exec(rest);
  return to && to[1].trim() ? {q: m[1].trim(), to: to[1].trim(), rest: rest.slice(to[0].length)} : {q: m[1].trim(), rest};
}
// Which of several equal passages a line's words are: how often they come up in the lines before
// it, spacing left out the way the page finds them (server.KEY_BRIDGE).
function nthBefore(lines, at, words) {
  const bare = (s) => String(s).replace(/[\s·]/g, ""), t = bare(words), hay = bare(lines.slice(0, at).join(""));
  let n = 0;
  if (t) for (let p = hay.indexOf(t); p >= 0; p = hay.indexOf(t, p + 1)) n++;
  return n;
}
// What changed in a report's words from one version to the next, in reading order: lineDiff rows
// (vdiff.js) folded into {was, now} pairs. A line only taken out has no `now`, one only put in no `was`.
// `at` is the new line's place in the report (0 = its first line), for going to it.
function pageChanges(rows) {
  const out = []; let del = [], add = [];
  const flush = () => { for (let k = 0; k < Math.max(del.length, add.length); k++) out.push({was: del[k] ?? null, now: add[k]?.text ?? null, at: add[k] ? add[k].b - 1 : null}); del = []; add = []; };
  for (const r of rows) { if (r.type === "same") flush(); else if (r.type === "del") del.push(r.text); else add.push(r); }
  flush();
  return out;
}
// pgquote:end
// The words of a pushed page, one line per block (a table row is one line), scripts and styles left
// out. The page is only parsed, never run, so a report that builds itself in script reads as empty.
const PG_BLOCK = "p,li,h1,h2,h3,h4,h5,h6,td,th,pre,blockquote,dt,dd,figcaption,summary,caption,div,section,article,header,footer,main,aside,nav,label,button";
function pageLines(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("script,style,noscript,template,svg").forEach((n) => n.remove());
  const out = [], w = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT); let row = null, blk = null, el = null;
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const t = n.nodeValue.replace(/\s+/g, " "); if (!t.trim()) continue;
    const b = n.parentElement.closest(PG_BLOCK) || doc.body, r = b.closest("tr") || b;
    // Two elements of one block (a figure and its label) are usually laid out apart: a space, not one word.
    if (r === row) out[out.length - 1] += (b !== blk ? " · " : n.parentElement !== el ? " " : "") + t; else out.push(t);
    row = r; blk = b; el = n.parentElement;
  }
  return out.map((s) => s.replace(/\s+/g, " ").trim());
}
// The report on screen against the version before: both pages' words, diffed once per pair.
const pgDiffMemo = new Map();
function pgDiff(aUrl, bUrl) {
  const key = aUrl + "\n" + bUrl;
  if (!pgDiffMemo.has(key)) pgDiffMemo.set(key, Promise.all([aUrl, bUrl].map((u) => fetch(u).then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.text(); })))
    .then(([a, b]) => { const la = pageLines(a), lb = pageLines(b);
      if (la.length > 4000 || lb.length > 4000) return null;
      const changes = pageChanges(lineDiff(la.join("\n"), lb.join("\n")));
      // Where a press on a changed line goes: its first cell, and which of the equal ones it is.
      for (const c of changes) if (c.now) { c.go = c.now.split(" · ")[0]; c.n = nthBefore(lb, c.at, c.go); }
      return {same: a === b, changes}; })
    .catch(() => null));
  return pgDiffMemo.get(key);
}
// A push that put requests off (--later <id,...>) stored their ids; the reader sees the requests'
// own words, or how many there were when a request is no longer on file. Never the raw id.
function laterText(s, dirs) {
  const ids = String(s || "").match(/#[0-9a-f]{6,16}(?![0-9a-z])/gi);
  if (!ids) return s || "";
  const words = ids.map((h) => (dirs || []).find((x) => String(x.id || "").startsWith(h.slice(1)))?.text).filter(Boolean)
    .map((t) => { t = attOf(t).words.split(/\s+/).join(" ").trim(); return t.length > 40 ? t.slice(0, 40) + "…" : t; }).filter(Boolean);
  return words.length ? words.join(" · ") + (ids.length > words.length ? " · " + tl("itemView.later_n", {n: ids.length - words.length}) : "") : tl("itemView.later_n", {n: ids.length});
}
// The frame a video is on, as a picture: a redraw makes a new <video>, and this stands in it until its own frame is back.
function stillOf(v) {
  if (v.readyState < 2 || !v.videoWidth) return "";
  const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  return c.toDataURL("image/jpeg", 0.9);
}
// What the open result showed last: the 5s check below (at `again`) redraws when this no longer holds.
let itemSig = "";
const itemSigOf = (id, d) => id + "|" + d.versions.length + "|" + d.log.length;
async function itemView(id, mount = null) {
  const box = mount || V();
  if (mount) mount.dataset.iid = id;
  // The 비교 toggle and its picks belong to the item on screen; a move to another item drops them.
  if (tlItem !== id) { tlItem = id; cmpToggle = false; tlSel = []; }
  // A compare state carried in from the address applies to the primary view only (not a stage/sheet
  // mount), and once: verPick/cmpPick become the pair, the mode and moment come along, 비교 opens.
  let restoredCmp = false;
  if (pendingCmp && pendingCmp.id === id && !mount) {
    const pc = pendingCmp; pendingCmp = null;
    verPick[id] = pc.a; if (pc.b) cmpPick[id] = pc.b;
    if (pc.m) cmpMode(pc.m);
    if (!isNaN(pc.thr)) cmpThr = pc.thr;
    cvAuto = id; cvScroll = scrollY; cmpSeek = isNaN(pc.t) ? null : pc.t;
  }
  // Redrawing the same item (a comment sent, the list refreshed) rebuilt the video at 0:00:
  // the moment just commented on was lost. Carry it over.
  const kv = openItem?.id === id ? stageVideo() : null, keep = kv && {v: openItem.v, t: kv.currentTime, play: !kv.paused, pic: stillOf(kv)};
  const x = D.items.find((i) => iid(i) === id);
  const [p, ...rest] = id.split("/"), i = rest.join("/");
  // A report's width and zoom tools sit in the top bar (PC); a redraw of the same item keeps them there.
  const hdT = esc(x?.title || i), hdMore = `<button class="ib press" id="imore" aria-label="${tl("itemView.1")}">${ic("more")}</button>`;
  if (!mount) head(hdT, openItem?.id === id && head.last?.[1]?.includes("pgtop") ? head.last[1] : hdMore);
  if (!openItem || openItem.id !== id) box.innerHTML = loadingHtml(tl("syncAgo.1"), {fill: true});
  let d;
  try { d = await get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`); }
  catch (e) {
    if (mount ? !mount.isConnected || mount.dataset.iid !== id : detail?.[1] !== id) return;   // moved on: the failure is not this screen's
    box.innerHTML = `<div class="card plan none"><p>${esc(e.message)}</p><p><button class="btn weak press" data-go="lib">${tl("item.gone.go")}</button></p></div>`; return;
  }
  if (mount ? !mount.isConnected || mount.dataset.iid !== id : detail?.[1] !== id) return;   // moved on while it loaded
  if (!mount) itemSig = itemSigOf(id, d);
  if (x?.new && d.versions.length) {                         // opened = seen: its 새 버전 alert goes away
    x.new = false; post("/api/seen", {p, i, v: d.versions[d.versions.length - 1].v}).catch(() => {}); drawChrome();
  }
  const vs = d.versions.slice().reverse(), v = vs.find((w) => w.v === verPick[id]) || vs[0], latest = v === vs[0];
  if (drawing) endDraw(false);
  const prev = vs[vs.indexOf(v) + 1], s = shotOf(v);
  const files = v.files || [], pics = files.filter(viewable), other = files.filter((f) => !viewable(f))
    // Pushed with --url: a site or page to open, not a file. v2 used to drop these.
    .concat((v.links || []).map((u) => ({url: u, name: u.replace(/^https?:\/\//, ""), kind: tl("itemView.2")})));
  if (stageOf !== id + v.v) { stageOf = id + v.v; stageAt = 0; pin = null; pinning = false; }
  stageAt = Math.min(stageAt, Math.max(pics.length - 1, 0));
  const allNotes = d.log.filter((e) => e.kind === "comment" || e.kind === "astra" || (e.kind === "message" && !/^\[(리뷰 허브|컨트롤룸) 코멘트\]/.test(e.text)));
  // 기록 filters: only the kinds this item has get a chip; a chosen one lists every match, not the last 12.
  const openIds = new Set((d.directives || []).filter((x) => x.state === "open").map((x) => x.id));
  const LF = [["all", tl("libDraw.1"), () => true], ["pic", tl("itemView.3"), (e) => attOf(e.text).urls.length > 0],
    ["when", tl("itemView.4"), (e) => !!whenTag(attOf(e.text).words)], ["reply", tl("itemView.5"), (e) => !!e.fixed_in],
    ["open", tl("itemView.6"), (e) => openIds.has(e.id)], ["ver", tl("lf.ver"), (e) => e.v === v.v]].map(([k, n, f]) => [k, n, allNotes.filter(f).length, f])
    .filter((c) => c[2] && (c[0] !== "ver" || c[2] < allNotes.length));     // 이 버전: only when older versions have notes too
  // No notes yet: every chip, "전체" too, was filtered out and LF[0] was undefined.
  const lf = LF.find((c) => c[0] === logF[id]) || LF[0] || ["all", tl("libDraw.1"), () => true, 0], lfOn = lf[0] !== "all";
  const notes = lfOn ? allNotes.filter(lf[3]) : allNotes.slice(logAll[id] ? 0 : -12), hidden = lfOn ? 0 : allNotes.length - notes.length;
  const unsent = d.log.filter((e) => e.kind === "comment" && !handed(e));
  const done = latest && v.status === "approved" && d.archived;
  // The shown version, read the way the lists read it: sent comments or answers make it the department's turn.
  const mine = d.log.filter((e) => e.kind === "comment" && e.v === v.v);
  const gave = d.log.filter((e) => (e.kind === "comment" || e.kind === "message") && e.v === v.v && handed(e));
  // The questions stay on the page after they are answered: each one folds to the answer on record
  // ([답] comments of this version), so "did I answer?" is read off the screen.
  const ask = v.ask || [], askAns = askAnswers(ask, d.log, v.v), askOpen = ask.filter((q, qi) => !askAns[qi]).length;
  const vx = {id: d.id, title: d.title, status: v.status, handed: gave.length > 0, answered: ask.length > 0 && !askOpen, spoke: gave.filter((e) => !(e.text || "").startsWith("[답]")).length,
    dept: x?.dept || v.dept, at: v.at, note: x?.note, asked: askOpen, comments: x?.comments, open: x?.open, led: x?.led,
    finished: d.finished, reach: x?.reach, said: x?.said, reopened: x?.reopened, moved_at: x?.moved_at, to_session: x?.to_session, sess: x?.sess, sess_since: x?.sess_since, handed_at: gave.map((e) => e.at || "").sort().pop() || null};
  // Two videos compare as videos, played in step: the file of the same name when the
  // other version has one, else each version's lead file. Any version can be the other side
  // (cmpPick); the one before is the default.
  const cmpWith = (w) => { const ws = shotOf(w);
    const cf = files.find((f) => f.kind === "video" && (w.files || []).some((x) => x.name === f.name && x.kind === "video"));
    const cv = cf ? [(w.files || []).find((x) => x.name === cf.name && x.kind === "video"), cf]
      : s.video && ws.video ? [w.files.find((f) => f.kind === "video"), v.files.find((f) => f.kind === "video")] : null;
    return {w, cv, ps: ws, ok: !!(cv || (s.img && ws.img))}; };
  const cmps = vs.filter((w) => w !== v).map(cmpWith).filter((c) => c.ok);
  const cmp = cmps.find((c) => c.w.v === cmpPick[id]) || cmps.find((c) => c.w === prev) || cmps[0];
  const pv = cmp?.w, cv = cmp?.cv, ps = cmp?.ps || {}, cmpOk = !!cmp, flipV = pv || prev;
  // What was asked of the version before, to tick off while looking at this one.
  const asked = latest && prev && !done ? d.log.filter((e) => e.kind === "comment" && e.v === prev.v && !/^\[(답|확정)\]/.test(e.text)) : [];
  // 지시 tracker: the reader's asks and how far each got. Newest first; claimed ones (a
  // version says it fixed them) need a 통과/다시 verdict, ok ones fold away.
  const dirs = (d.directives || []).slice().reverse();
  const dClaim = dirs.filter((x) => x.state === "claimed"), dOpen = dirs.filter((x) => x.state === "open" && !x.snoozed), dOk = dirs.filter((x) => x.state === "ok" || x.state === "passed");
  const dZz = dirs.filter((x) => x.state === "open" && x.snoozed);        // 다음에: put off to the next version
  // The asks already tracked as directives (below) are not repeated as a second checklist: only
  // asks that never became a directive stay in the 이전 요청 fold, so 지시 lives in one place.
  const askedO = asked.filter((e) => !dirs.some((x) => x.id === e.id));
  // A one-line summary: markdown marks (**bold**, `code`, list bullets) are dropped, not shown raw.
  // The spot/box tag reads as the chip below, not as raw percent; a time in the same tag stays.
  const dtxt = (x) => esc((quoteOf(attOf(x.text || "").words)?.rest ?? attOf(x.text || "").words).replace(/위치\([^)]*\)\s*/, "").replace(/^\[\s*\]\s*/, "").replace(/\*\*([^*\n]+)\*\*/g, "$1").replace(/`([^`\n]+)`/g, "$1").replace(/^\s*(?:[-*+]|\d+[.)])\s+/gm, "").split(/\s+/).join(" ").slice(0, 90));
  const dRgn = (x) => x.v === v.v && regionOf({rect: x.rect, text: x.text}) ? `<button class="lchip press" data-loc="${esc(x.id)}" title="${tl("loc.region_t")}">${ic("pin")}<span>${tl("loc.region")}</span></button> ` : "";
  const dQt = (x) => { const q = !pics.length && quoteOf(attOf(x.text || "").words); return q ? `<button class="qj press" data-qj="${esc(q.q)}" data-qn="${x.quote_n | 0}" title="${tl("pgq.jump_t")}"><span>${tl("pgq.part")}</span></button> ` : ""; };
  const dRow = (x) => `<div class="row note dir ${x.state}" data-did="${esc(x.id)}"><span class="tx"><div class="nt">${dRgn(x)}${dQt(x)}${dtxt(x)}</div><div class="s">${x.cycle > 1 ? `<em class="dcy num">${tl("fixv.cycle", {n: x.cycle})}</em> ` : ""}${x.state === "claimed" ? `<b class="dc">${tl("itemView.7", {esc: esc(x.fixed_in)})}</b>` : x.state === "ok" ? tl("itemView.8") : x.state === "passed" ? tl("itemView.9") : `${esc(x.v || "")} · ${ago(x.at)}`}</div>${x.fixed_note && x.state !== "open" ? `<div class="dsaid">${esc(x.fixed_note)}</div>` : ""}</span>${x.state === "open" && latest && !done ? `<span class="dbtns"><button class="btn sm weak press dzz" data-dz="${esc(x.id)}">${x.snoozed ? tl("dz.back") : tl("dz.later")}</button></span>` : ""}${x.state === "claimed" ? `<span class="dbtns"><button class="btn sm press dfv" data-fv="${esc(x.id)}" title="${tl("fixv.open_t")}">${ic("swap")}<span>${tl("fixv.open")}</span></button><button class="btn sm fill press dyes" data-dv="${esc(x.id)}">${tl("itemView.10")}</button><button class="btn sm weak press dno" data-dv="${esc(x.id)}">${tl("itemView.11")}</button></span>` : ""}</div>`;
  const dirCard = (dClaim.length || dOpen.length || dZz.length) ? `<details class="card dirs" id="dirsfold" data-panel="directives"${dirsOpenOf === id ? " open" : ""}><summary class="ch"><h2>${tl("itemView.17")}</h2><span class="dcnts">${[dOpen.length && `<button class="dcnt press num" data-dj="open">${tl("itemView.12", {n: dOpen.length})}</button>`, dClaim.length && `<button class="dcnt press num wait" data-dj="claimed">${tl("itemView.13", {n: dClaim.length})}</button>`].filter(Boolean).join("<i>·</i>")}</span><span class="sp"></span>${ic("chev", "i dn")}</summary>
    ${dClaim.map(dRow).join("")}${dClaim.length > 1 ? `<div class="clall"><button class="btn sm press dall">${tl("itemView.14", {n: dClaim.length})}</button></div>` : ""}${dOpen.slice(0, 3).map(dRow).join("")}
    ${dOpen.length > 3 ? `<p class="hint2" style="padding:2px 16px 12px;margin:0">${tl("itemView.15", {p0: dOpen.length - 3})}</p>` : ""}
    ${dZz.length ? `<details class="dok"><summary>${tl("dz.n", {n: dZz.length})}</summary>${dZz.map(dRow).join("")}<div style="height:6px"></div></details>` : ""}
    ${dOk.length ? `<details class="dok"><summary>${tl("itemView.16", {n: dOk.length})}</summary>${dOk.map(dRow).join("")}<div style="height:6px"></div></details>` : "<div style='height:8px'></div>"}</details>` : "";
  const tabs = [ask.length && ["ask", tl("itemView.18") + (askOpen ? "" : `<em class="tdone" role="img" aria-label="${tl("ask.done")}" title="${tl("ask.done")}">${ic("check")}</em>`), askOpen], ["cm", tl("itemView.19"), allNotes.length], !mount && window.LOOP_ITEM_CHAT && window.pjEmbed && ["chat", tl("itemView.chat"), 0]].filter(Boolean);   // comparing has one entry: 비교 on the version strip
  const tab = tabs.some((t) => t[0] === tabPick[id]) ? tabPick[id] : ask.length && !askOpen ? "cm" : tabs[0][0];
  const slide = (f, n) => `<div class="sl">${goneOf(f) ? goneHtml(f) : f.kind === "video"
    ? `<video src="${esc(f.play || f.url)}" loop playsinline preload="metadata" ${sound() ? "" : "muted"} ${f.thumb ? `poster="${esc(f.thumb)}"` : ""}></video><div class="sspin" hidden>${loadingHtml("", {tight: true})}</div>`
    : imgTag(f.url, {alt: f.name, lazy: !!n, drag: false, keep: true})}</div>`;
  // A file whose name and size match the version before is "그대로": looked at already, most likely.
  d.viewed = d.viewed || {};
  const before = (w) => vs[vs.indexOf(w) + 1];
  const sameF = (w, f) => { const b = before(w), o = b && (b.files || []).find((q) => q.name === f.name);
    return !!o && f.size != null && o.size === f.size; };
  const seenF = (w, f) => { const x = (d.viewed[w.v] || {})[f.name];
    return x !== undefined ? x : sameF(w, f) && seenF(before(w), f); };
  // 바뀐 것만: offered when some files of this version are as they were and some are not.
  const sgChg = ((n) => n < pics.length ? n : 0)(pics.filter((f) => !sameF(v, f)).length);
  // A lone still image needs none of the video/multi-file chrome (frame stepper, scrub track,
  // resize grip): those left an empty band and a stray handle under the picture. Flag it so the
  // stage shows just the image cleanly.
  const oneStill = pics.length === 1 && !pics.some((f) => f.kind === "video");
  // An HTML report has nothing to put on the stage, so it used to show a bare icon and
  // the reader had to find the small open-link row. Show the page itself instead.
  const page = !pics.length && files.find((f) => f.kind === "html");
  // The same report in the version before (by name, else its lead page): what the words are compared with.
  // Every passage a comment quotes: kept quietly marked in the report (the pen above it turns that off).
  const pgMarks = page ? d.log.filter((e) => e.kind === "comment").map((e) => ({text: quoteOf(attOf(e.text || "").words)?.q, n: e.quote_n | 0}))
    .filter((m, k, all) => m.text && all.findIndex((o) => o.text === m.text && o.n === m.n) === k) : [];
  const pageWas = page && prev ? (prev.files || []).find((f) => f.kind === "html" && f.name === page.name) || (prev.files || []).find((f) => f.kind === "html") : null;
  const otherF = page ? other.filter((f) => f !== page) : other;   // the framed page opens from 더 보기, not from a second row
  const pgTools = page ? `<div class="pgtop"><div class="seg pgsz pc-only" role="group" aria-label="${tl("itemView.22")}"><button data-pw="pc" class="${pageW === "phone" ? "" : "on"}">${tl("itemView.23")}</button><button data-pw="phone" class="${pageW === "phone" ? "on" : ""}">${tl("itemView.24")}</button></div>${zoomCtl("pgzoom", tl("zoom.page"))}</div>` : "";
  if (page && !mount) head(hdT, pgTools + hdMore);
  const media = page
    ? `<div class="pgw${pageW === "phone" ? " phone" : ""}" id="pgw" style="--pgz:${pageZ}">${mount ? pgTools : ""}${pageWas || pgMarks.length ? `<div class="pgchg">${pageWas ? `<div class="pgc" id="pgchg"></div>` : ""}${pgMarks.length ? `<button class="pgmk press${pgMarksOn ? " on" : ""}" id="pgmk" aria-pressed="${pgMarksOn}" title="${tl("pgq.marks_t")}">${ic("pen")}<span class="num">${pgMarks.length}</span></button><button class="pgmk press" id="pgnx" aria-label="${tl("pgq.next_t")}" title="${tl("pgq.next_t")}">${ic("chev")}</button>` : ""}</div>` : ""}
        <div class="pgframe"><iframe src="${esc(keyUrl(page.url))}&bar=1" title="${esc(page.name)}" sandbox="allow-scripts allow-popups"></iframe>
        <button class="pgfull press" id="pgfull" aria-pressed="false" aria-label="${tl("itemView.25")}">${ic("full")}<span>${tl("itemView.26")}</span></button></div></div>`
    : pics.length
    ? `<div class="stage" id="stage" data-bg="${stageBg}"><div class="strk">${pics.map(slide).join("")}</div>
        ${pics.length > 1 ? `<button class="snav l press" aria-label="${tl("itemView.27")}">${ic("chev")}</button><button class="snav r press" aria-label="${tl("itemView.28")}">${ic("chev")}</button>` : ""}
        <button class="sfull press" aria-label="${tl("itemView.38")}">${ic("full")}</button>${zoomCtl("szoom", tl("zoom.result"))}
        ${flipV ? `<button class="sflip press" aria-pressed="false" title="${tl("itemView.29", {v: flipV.v})}" aria-label="${tl("itemView.29", {v: flipV.v})}">${ic("swap")}<span>${tl("flipBadge.0", {v: flipV.v})}</span></button>` : ""}</div>
       <div class="sbar"><span class="sname"></span><span class="fstep" hidden><button class="press fplay" aria-label="${tl("itemView.39")}" title="${tl("itemView.40")}">${ic("play")}</button><button class="press" data-fs="-1" aria-label="${tl("itemView.41")}" title="${tl("itemView.42")}">${ic("chev")}</button><button class="press fnow num" aria-label="${tl("itemView.43")}" title="${tl("itemView.44")}"></button><button class="press" data-fs="1" aria-label="${tl("itemView.45")}" title="${tl("itemView.46")}">${ic("chev")}</button><button class="press frate num" aria-label="${tl("itemView.47")}" title="${tl("itemView.48")}">1×</button><button class="press fscn" aria-label="${tl("itemView.49")}" aria-pressed="false" title="${tl("itemView.49")}">${ic("image")}</button></span><span class="smute" hidden title="${tl("stageBg.7")}">${tl("stageBg.6")}</span><button class="press sbgb" title="${tl("stageBg.5")}" aria-label="${tl("stageBg.5")}"><i class="bgsw"></i><span></span></button><button class="press sguide num" aria-pressed="false" title="${tl("itemView.50")}">${tl("itemView.51")}</button><span class="scount num"></span></div>
       <div class="cmk" id="cmk" hidden aria-label="${tl("itemView.52")}"></div>
       <div class="fstrip" id="fstrip" hidden></div>
       <div class="sgrip" id="sgrip" role="separator" aria-label="${tl("itemView.53")}" title="${tl("itemView.54")}"><i></i></div>
       ${pics.length > 2 ? `<div class="sgw${sgOpen() ? " open" : ""}" id="sgw"><button class="sgt press" id="sgt" aria-expanded="${sgOpen()}" aria-label="${tl("itemView.35", {n: pics.length})}"><span>${tl("itemView.36")} <b class="num">${pics.length}</b>${tl("itemView.37")} <b class="num" id="vwn">${pics.filter((f) => seenF(v, f)).length}</b></span><em>${sgOpen() ? tl("itemView.30") : tl("itemView.31")}</em>${ic("chev")}</button><div class="sgrid${sgOnly && sgChg ? " only" : ""}" id="sgrid">${sgChg ? `<button class="sgf press${sgOnly ? " on" : ""}" id="sgf" aria-pressed="${sgOnly}">${tl("fgrid.chg", {n: sgChg})}</button>` : ""}${pics.map((f, n) => {
         // Every file of the version at a glance: tap one to put it on the stage above.
         const said = d.log.filter((e) => e.kind === "comment" && e.v === v.v && e.text.startsWith("[" + f.name)).length;
         const on = seenF(v, f), same = sameF(v, f);
         return `<button class="sg press${on ? " seen" : ""}${same ? " same" : ""}" data-sg="${n}" aria-label="${esc(f.name)}${same ? tl("itemView.32") : ""}">${f.kind === "video" && !f.thumb
           ? `<span class="sgv">${ic("play")}</span>` : `<img src="${esc(f.kind === "video" ? f.thumb : f.url)}" alt="" loading="lazy" draggable="false">`}
           <span class="sgn">${same ? tl("itemView.33") : ""}${esc(f.name.replace(/\.[^.]+$/, ""))}</span>${lostTag(f)}${said ? `<em class="num">${said}</em>` : ""}<span class="vwd" role="checkbox" tabindex="0" data-vw="${esc(f.name)}" aria-checked="${on}" aria-label="${tl("itemView.34")}" title="${tl("itemView.34")}">${ic("check")}</span></button>`; }).join("")}</div></div>` : ""}`
    : `<div class="hero">${ic((KIND[s.kind] || ["doc"])[0])}</div>`;
  // The decision sits in the composer dock, right above the box: approving and asking for a fix
  // are the two answers to a result, so they live in one place at every width.
  const talkB = v.dept ? `<button class="btn weak press" data-talk-dept="${esc(v.dept)}">${tl("dnote.1")}</button>` : "";
  const decideBtns = !latest
    ? `<button class="btn fill press tolatest">${tl("itemView.55")}</button>`
    : done
    ? `<button class="btn press" data-decide="reopen">${tl("itemView.56")}</button>${talkB}`
    : v.status === "approved" && !turnOf(vx)
    ? `${talkB}<button class="btn fill press" data-decide="done">${tl("itemView.57")}</button>`
    : `${askOpen ? `<button class="btn fill press askgo" data-askgo>${tl("itemView.askgo")}<b class="num">${askOpen}</b></button>` : ""}<button class="btn fill press" data-decide="approved">${ic("check")}${tl("STATUS_T.4")}</button>`;
  // One line beside the buttons saying what they do here - the hub's decideNote (R15).
  const decideNote = !latest ? tl("dnote.2") : done ? tl("dnote.3") : v.status === "approved" && !turnOf(vx) ? tl("dnote.4") : "";
  const talkLink = v.dept && latest && !done && v.status !== "approved" ? `<button class="lnk press talkgo" data-talk-dept="${esc(v.dept)}">${ic("chat")}<span>${tl("dnote.1")}</span>${ic("chev")}</button>` : "";
  // The version is a plain label now: the timeline strip below is the picker (no second one).
  const vchip = `${v.v}${vs.length > 1 && !latest ? tl("itemView.63") : ""}`;
  // 버전 타임라인: every version left(oldest)→right(newest), the current kept in view, each with
  // its number, time, and 고침/지시 badges. Tap to view; the 비교 toggle then picks two.
  const verTL = vs.length > 1 ? (() => {
    let ovs = vs.slice().reverse(), bg = timelineBadges(ovs, d.directives);
    // Free keeps every version's DATA (nothing is ever deleted); the strip shows the recent
    // ones and folds the older ones behind a calm "Pro에서 보기" row. version_limit is null
    // on Pro/trial. The version currently in view is never folded away.
    let folded = 0;
    const lim = window.LOOP_PLAN && window.LOOP_PLAN.version_limit;
    if (lim && ovs.length > lim && window.planCan && !planCan("version_history")) {
      let cut = ovs.length - lim;
      const curIdx = ovs.findIndex((w) => w === v);
      if (curIdx >= 0 && curIdx < cut) cut = curIdx;
      if (cut > 0) { folded = cut; ovs = ovs.slice(cut); bg = bg.slice(cut); }
    }
    const proRow = folded ? `<button class="vtli vtlpro press" data-vpro title="${tl("license.pro_version_history")}"><span class="vth">${ic("star")}</span><span class="vtm"><b>${tl("license.older_pro", {n: folded})}</b></span></button>` : "";
    return `<div class="card vtl${cmpToggle ? " picking" : ""}" id="vtl" data-panel="versions"><div class="vtlbar">
      <div class="vtlstrip" id="vtlstrip" role="tablist" aria-label="${tl("itemView.70")}">${proRow}${ovs.map((w, n) => {
        const th = shotOf(w).img, b = bg[n], sel = tlSel.includes(w.v), isNow = w === v, oth = cmp && w === cmp.w;
        return `<button class="vtli press${isNow ? " on" : ""}${oth && !isNow ? " oth" : ""}${sel ? " sel" : ""}" data-vt="${w.v}" role="tab" aria-selected="${isNow}" aria-label="${w.v}${n === ovs.length - 1 ? tl("itemView.64") : ""}">
          <span class="vth${isNow ? " on" : ""}">${th ? imgTag(th, {drag: false}) : `<em class="num">${w.v.replace(/^v0*/, "v")}</em>`}</span>
          <span class="vtm"><b class="num">${w.v}${n === ovs.length - 1 ? tl("itemView.64") : ""}</b><i>${w.final ? `<em class="rs-tag fin">${tl("res.final")}</em>` : w.removed ? `<em class="rs-tag">${tl("res.noFile")}</em>` : ago(w.at)}</i></span>
          ${(b.fixed || b.raised) ? `<span class="vtbg">${b.fixed ? `<em class="vf num" title="${tl("itemView.65")}">${ic("check")}${b.fixed}</em>` : ""}${b.raised ? `<em class="vo num" title="${tl("itemView.66")}">${tl("itemView.67", {raised: b.raised})}</em>` : ""}</span>` : ""}</button>`; }).join("")}</div>
      <button class="vtlcmp press${cmpToggle ? " on" : ""}" id="vtlcmp" aria-pressed="${cmpToggle}" title="${ovs.length === 2 ? tl("itemView.71two") : tl("itemView.71")}">${ic("swap")}<span>${tl("itemView.72")}</span></button></div>
      ${cmpToggle ? `<p class="vtlhint fun">${tlSel.length ? `<b>${tlSel[0]}</b> ${tl("itemView.68")}` : tl("itemView.69")}</p>` : ""}</div>`;
  })() : "";
  const dueI = dueInfo(d.meta?.due);
  // The panel opens on what is needed at first sight (state, the questions, the decision). The
  // item's upkeep - who has it, a due date, finishing, the conversation that pushed it, the page
  // in its own tab - waits behind one 더 보기. A name or a date already set stays in sight.
  const imChip = {
    assignee: `<button class="ichip press" data-imeta="assignee">${ic("user", "i")}<span>${d.meta?.assignee ? esc(d.meta.assignee) : tl("itemView.166")}</span></button>`,
    due: `<button class="ichip press${dueI?.over ? " over" : ""}" data-imeta="due">${ic("cal", "i")}<span>${d.meta?.due ? dueI.label : tl("itemView.167")}</span></button>`,
    fin: latest ? `<button class="ichip ifin press" data-ifin="${d.finished ? 0 : 1}" title="${d.finished ? tl("fin.re.h") : tl("fin.do.h")}">${ic(d.finished ? "undo" : "flag", "i")}<span>${d.finished ? tl("fin.re") : tl("fin.do")}</span></button>` : "",
    made: v.session_id && itemFrom?.sid !== v.session_id ? `<button class="ichip press" data-made="${esc(v.session_id)}" title="${tl("itemView.made_h")}">${ic("chat", "i")}<span>${tl("itemView.made")}</span></button>` : "",
    tab: page ? `<a class="ichip press" href="${esc(page.url)}" target="_blank" rel="noopener" title="${esc(page.name)}">${ic("ext", "i")}<span>${tl("itemView.newtab")}</span></a>` : ""};
  const imTop = [d.meta?.assignee && imChip.assignee, d.meta?.due && imChip.due].filter(Boolean);
  // No name or date set: 더 보기 ends the status line instead of standing alone on a row of its own.
  const imRest = [!d.meta?.assignee && imChip.assignee, !d.meta?.due && imChip.due, imChip.fin, imChip.made, imChip.tab].filter(Boolean);
  const imMore = imRest.length ? `<button class="ichip imore press" data-imore aria-expanded="${imMoreOf === id}">${ic("more", "i")}<span>${imMoreOf === id ? tl("itemView.30") : tl("ui.more")}</span></button>` : "";
  // A redraw of the item on screen (a comment sent, a tick, a meta edit) rebuilt the framed page: the
  // report reloaded and jumped back to its first page. Same item, version and page: the live frame
  // stays in the document (a re-inserted iframe reloads, so it is never detached) and only what is
  // around it is replaced. The caret of a comment being typed comes back as well.
  // The conversation that pushed this version: a link to it, and a follow-up that opens its message
  // box with this item and version already named. Older pushes carry no session id: nothing shows.
  const madeBy = v.session_id ? ` · <button class="lnk press" data-made="${esc(v.session_id)}">${tl("itemView.made")}</button> · <button class="lnk press" data-made="${esc(v.session_id)}" data-follow>${tl("itemView.follow")}</button>` : "";
  const pgKey = page ? `${id}@${v.v}@${page.url}` : "";
  const oldCols = box.firstElementChild?.matches?.(".detailcols.item") ? box.firstElementChild : null;
  const oldMedia = pgKey && oldCols?.firstElementChild?.dataset.pg === pgKey && oldCols.querySelector(".media iframe") ? oldCols.firstElementChild : null;
  const oldPanel = openItem?.id === id ? oldCols?.lastElementChild : null, panelTop = oldPanel ? oldPanel.scrollTop : 0;
  const panelEnd = !!oldPanel && Math.abs(cmGap() ?? 99) <= 32;
  const fa = document.activeElement, typed = fa && fa.id === "cm" && box.contains(fa) ? [fa.selectionStart, fa.selectionEnd] : null;
  /* Lab layout: the version strip sits under the picture, as a filmstrip. */
  const vtlUnder = LAB3 && !mount && !isPhoneW();
  const itemHtml = `<div class="detailcols item${vtlUnder ? " vtlu" : ""}${mount ? " mounted" : ""}" style="--ipw:${ipw()}px"><div class="media${oneStill ? " still" : ""}">${media}${vtlUnder ? verTL : ""}</div><div class="cgrip igrip" id="igrip" role="separator" aria-orientation="vertical" aria-label="${tl("itemView.91")}" tabindex="0" title="${tl("itemView.92")}"></div><div>
    <div class="htitle"><h2>${esc(d.title)}</h2><p>${done || !stWhy(vx) ? `<span class="tag ${done ? v.status : stCls(vx)}">${done ? tl("hitRow.1") : stName(vx)}</span>` : `<button class="tag why press ${stCls(vx)}" data-stwhy="1" aria-expanded="false"${stTip(vx)}>${stName(vx)}</button>`}${[esc(pname(v.dept || "")), vs.length > 1 ? "" : vchip, ago(v.at)].filter(Boolean).join(" · ")}${lintTag(p + "/" + d.id + "@" + v.v, v.lint)}${imTop.length ? "" : imMore}</p>${done || !stWhy(vx) ? "" : `<p class="stwhy" hidden>${esc(stWhy(vx))}</p>`}
      <div class="imeta${imTop.length ? "" : " rest"}" id="imeta" title="${tl("itemView.175")}">${imTop.join("")}${imTop.length ? imMore : ""}${imRest.length ? `<span class="imrest"${imMoreOf === id ? "" : " hidden"}>${imRest.join("")}</span>` : ""}</div></div>
    ${vtlUnder ? "" : verTL}
    ${d.archived && d.superseded_by ? `<a class="card row press" href="#item/${esc(p)}/${encodeURIComponent(d.superseded_by)}"><span class="tx"><div class="t" style="font-size:16px">${tl("itemView.73")}</div><div class="s">${tl("itemView.74", {esc: esc(D.items.find((x) => iid(x) === p + "/" + d.superseded_by)?.title || d.superseded_by)})}</div></span>${ic("chev","i go")}</a>` : ""}
    ${v.summary ? `<div class="card isumwrap"><div class="quote isum" title="${tl("itemView.75")}">${esc(v.summary)}</div><button class="lnk press isummore" aria-expanded="false">${tl("ui.more")}</button></div>` : ""}
    ${v.later ? `<div class="card"><div class="quote" style="margin-top:18px"><span class="warn">${tl("itemView.76")}</span> · ${esc(laterText(v.later, d.directives))}</div></div>` : ""}
    ${dirCard}
    ${askedO.length ? `<details class="card prevask" data-panel="history" ${askedO.every((e) => isFixed(e.id)) ? "" : "open"}><summary class="ch"><h2>${tl("itemView.78", {v: prev.v})}</h2><span class="n num" id="pacount">${askedO.filter((e) => isFixed(e.id)).length} / ${askedO.length}</span><span class="sp"></span>${ic("chev", "i dn")}</summary>
      ${askedO.map((e) => `<div class="row note pa${isFixed(e.id) ? " ok" : ""}"><button class="ck press" data-fx="${esc(e.id)}" role="checkbox" aria-checked="${isFixed(e.id)}" aria-label="${tl("itemView.77")}">${CKM}</button><span class="tx"><div class="nt">${noteText(e, e.v, pics)}</div></span></div>`).join("")}
      <p class="hint2 pahint">${tl("itemView.79")}</p></details>` : ""}
    ${otherF.length ? `<div class="card">${otherF.map((f) => `<a class="row press" href="${esc(f.url)}" target="_blank" rel="noopener"><span class="ico sm c-grey">${ic((KIND[f.kind] || ["doc"])[0])}</span><span class="tx"><div class="t" style="font-size:16px">${esc(f.name)}${lostTag(f)}</div><div class="s">${esc(f.kind || tl("itemView.36"))}</div></span>${ic("ext","i go")}</a>`).join("")}</div>` : ""}
    <div class="card itab" data-panel="comments"><div class="seg wide" id="itabs" role="tablist">${tabs.map(([k, n, c]) => `<button role="tab" aria-selected="${k === tab}" class="${k === tab ? "on" : ""}" data-v="${k}">${n}${c ? ` <span class="num">${c}</span>` : ""}</button>`).join("")}</div><div id="tbody"></div></div>
    ${nextCard(id)}
    <div class="cdk${latest && askOpen && !done ? " asking" : ""}" id="cdk"><div class="card cdkc">
      <div class="decide cdkd"><p class="dnote">${decideNote}${talkLink}</p><div class="in">${decideBtns}${mount && nextOf(id) ? `<button class="btn press nextb" id="nextb" aria-label="${tl("nextCard.3")}" title="${tl("itemView.90")}">${ic("chev")}</button>` : ""}</div></div>
      ${pics.length > 1 ? `<div class="tgt"><button class="tg press" data-tgt="file"></button><button class="tg press" data-tgt="all">${tl("itemView.105")}</button></div>` : ""}
      <div class="cdock${pics.length ? "" : " quiet"}${dockOpenOf === id ? " open" : ""}" id="cdock"><div class="pinrow"><button class="opt press" id="cmimg" aria-label="${tl("cmImg.1")}" title="${tl("cmImg.2")}">${ic("image")}<span>${tl("cmImg.1")}</span></button><input type="file" id="cmfile" accept="image/*" multiple hidden>${pics.length ? `<button class="opt press" id="drawbtn" aria-label="${tl("itemView.107")}" title="${tl("itemView.107")} (D)">${ic("pen")}<span>${tl("itemView.107")}</span></button><button class="opt press" id="pinbtn" aria-label="${tl("itemView.106")}" title="${tl("itemView.106")} (P)">${ic("pin")}<span>${tl("itemView.106")}</span></button>` : ""}<button class="opt press" id="cmsplit" hidden aria-pressed="false" title="${tl("cmSplit.1")}">${ic("list")}<span></span></button><button class="opt press" id="cmpx">${ic("x")}<span>${tl("itemView.114")}</span></button></div>
        <div class="drawchip" id="drawchip" hidden></div>
        <div class="qchip" id="qchip" hidden></div>
        <div class="cmatt" id="cmatt" hidden></div>
        <div class="cbox"><textarea id="cm" rows="1" enterkeyhint="send" placeholder="${pics.length > 1 ? tl("itemView.109") : page ? tl("pgq.ph") : tl("itemView.110")}"></textarea><button class="btn fill press" id="cmadd" disabled title="${tl("itemView.112")}">${tl("nextCard.6")}</button></div>
        <div class="splitpv" id="splitpv" hidden aria-live="polite"></div></div>
      ${pics.some((f) => f.kind === "video") ? `<p class="fun" id="cmwhen">${tl("itemView.111") + tl("cmWhen.5")}</p>` : ""}</div></div>
    <details class="card ixtra" id="ixtra"${xtraOpenOf === id ? " open" : ""}><summary class="ch"><span class="xl">${tl("itemView.xtra")}</span><span class="sp"></span>${ic("chev", "i dn")}</summary></details>
  </div></div>
  ${keyBarHtml({video: pics.some((f) => f.kind === "video"), pics: pics.length, page: !!page, decide: latest && !done && v.status !== "approved", next: !!nextOf(id), vers: vs.length > 1, cmp: cmpOk, mount})}
  <div class="ctapad"></div>`;
  if (oldMedia) {
    const t = document.createElement("div"); innerSet.call(t, itemHtml);
    const nc = t.firstElementChild;
    oldCols.className = nc.className; oldCols.style.cssText = nc.style.cssText;
    while (oldMedia.nextSibling) oldMedia.nextSibling.remove();
    nc.firstElementChild.remove(); oldCols.append(...nc.childNodes);
    while (oldCols.nextSibling) oldCols.nextSibling.remove();
    nc.remove(); box.append(...t.childNodes);
  } else box.innerHTML = itemHtml;
  if (pgKey) { const m = box.querySelector(".detailcols.item > .media"); if (m) m.dataset.pg = pgKey; }
  wireItemGrip();
  if (pageWas) pgChgFill(box.querySelector("#pgchg"), pageWas.url, page.url, prev.v, v.v);
  box.querySelector("#sgf")?.addEventListener("click", (e) => { sgOnly = !sgOnly;
    e.currentTarget.classList.toggle("on", sgOnly); e.currentTarget.setAttribute("aria-pressed", sgOnly); box.querySelector("#sgrid").classList.toggle("only", sgOnly); });
  box.querySelector("#pgmk")?.addEventListener("click", (e) => { pgMarksOn = !pgMarksOn; lsSet("pg-marks-off", pgMarksOn ? "" : "1");
    e.currentTarget.classList.toggle("on", pgMarksOn); e.currentTarget.setAttribute("aria-pressed", pgMarksOn); pgMarksSend(); });
  // One press walks the quoted passages in turn, so a phone needs no trip to the comment list.
  box.querySelector("#pgnx")?.addEventListener("click", () => { const l = openItem.quotes, m = l[pgMarkAt++ % l.length]; if (m) pgFind(m.text, m.n); });
  box.querySelectorAll("[data-talk-dept]").forEach((b) => b.onclick = () => nav("project/" + encodeURIComponent(b.dataset.talkDept)));
  box.querySelectorAll("[data-made]").forEach((b) => b.onclick = async () => {
    const sid = b.dataset.made, s = await get("/api/project/session?id=" + encodeURIComponent(sid)).catch(() => null);
    if (!s || !s.found || !s.project) return toast(tl("itemView.madeGone"));
    if (b.hasAttribute("data-follow")) window.pjDraft?.(sid, tl("itemView.followDraft", {t: d.title, v: v.v, id: p + "/" + d.id}));
    nav("project/" + encodeURIComponent(s.project) + "/" + encodeURIComponent(sid));
  });
  box.querySelectorAll("[data-imeta]").forEach((b) => b.onclick = () => wireImetaEdit(box, b.dataset.imeta, p, i, d));
  box.querySelector("[data-imore]")?.addEventListener("click", (e) => { const b = e.currentTarget, r = box.querySelector(".imrest"), on = r.hidden;
    imMoreOf = on ? id : ""; r.hidden = !on; r.classList.toggle("in", on);     // in place, a short fade (v2.css .imrest.in)
    b.setAttribute("aria-expanded", String(on)); b.querySelector("span").textContent = on ? tl("itemView.30") : tl("ui.more"); });
  box.querySelectorAll("[data-ifin]").forEach((b) => b.onclick = () => itemFin(p, i, b.dataset.ifin === "1"));
  // 버전 타임라인: view a version, or (with 비교 on) pick two and open the comparison. The current
  // one is scrolled into sight within the strip, never moving the page.
  const latestV = vs[0].v;
  const tlStrip = box.querySelector("#vtlstrip");
  if (tlStrip) {
    const now = tlStrip.querySelector(".vtli.on");
    if (now) tlStrip.scrollTo({left: now.offsetLeft - (tlStrip.clientWidth - now.offsetWidth) / 2, behavior: RM() ? "auto" : "smooth"});
    tlStrip.querySelectorAll("[data-vt]").forEach((b) => b.onclick = () => {
      const vv = b.dataset.vt;
      if (!cmpToggle) { if (vv === latestV) delete verPick[id]; else verPick[id] = vv; again(); return; }
      if (tlSel.includes(vv)) { tlSel = tlSel.filter((x) => x !== vv); b.classList.remove("sel"); }
      else tlSel.push(vv);
      if (tlSel.length >= 2) {
        const [a, c2] = tlSel.slice(0, 2).sort();     // a = older, c2 = newer (zero-padded names sort right)
        verPick[id] = c2; cmpPick[id] = a; cmpToggle = false; tlSel = [];
        cvAuto = id; cvScroll = scrollY;      // picking the pair opens the compare workspace once the item has redrawn
        again();
      } else {
        b.classList.toggle("sel", tlSel.includes(vv));
        const h = box.querySelector(".vtlhint"); if (h) h.innerHTML = tlSel.length ? `<b>${esc(tlSel[0])}</b> ${tl("itemView.68")}` : tl("itemView.69");
      }
    });
    box.querySelector("#vtlcmp").onclick = () => {
      // Only two versions: there is no pair to pick, so 비교 opens them side by side straight away.
      const vs = [...tlStrip.querySelectorAll("[data-vt]")].map((b) => b.dataset.vt);
      if (!cmpToggle && vs.length === 2) { const [a, c2] = vs.sort(); verPick[id] = c2; cmpPick[id] = a; tlSel = []; cvAuto = id; cvScroll = scrollY; return again(); }
      cmpToggle = !cmpToggle; tlSel = []; again(); };
    tlStrip.querySelector("[data-vpro]")?.addEventListener("click", () => window.proSheet && proSheet("version_history"));
  }
  // 봤음 per file: a tap on the check (not the thumb) ticks it; kept on the item so the phone and
  // the PC agree. A file carried over unchanged shows its old tick until it is set here.
  const tickVw = async (el) => { const f = pics.find((q) => q.name === el.dataset.vw); if (!f) return;
    const on = !seenF(v, f), was = (d.viewed[v.v] || {})[f.name], put = (x) => { const m = d.viewed[v.v] ||= {};
      if (x === undefined) delete m[f.name]; else m[f.name] = x;
      el.setAttribute("aria-checked", seenF(v, f)); el.closest(".sg").classList.toggle("seen", seenF(v, f));
      document.getElementById("vwn").textContent = pics.filter((q) => seenF(v, q)).length; };
    put(on);
    try { await post("/api/viewed", {p, i, v: v.v, name: f.name, on}); } catch (e) { put(was); toast(e.message); } };
  box.querySelectorAll("[data-vw]").forEach((el) => { el.onclick = (e) => { e.stopPropagation(); tickVw(el); };
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); tickVw(el); } }; });
  // The phone's bottom bar: on to the next result without deciding, no scrolling down to the card.
  document.getElementById("ixtra")?.addEventListener("toggle", (e) => { xtraOpenOf = e.target.open ? id : ""; });
  document.getElementById("dirsfold")?.addEventListener("toggle", (e) => { dirsOpenOf = e.target.open ? id : ""; });
  document.getElementById("nextb")?.addEventListener("click", () => { const n = nextOf(id); if (n) { autoPlay = true; nav("item/" + iid(n)); } });
  // Comments on this version that name a moment: dots along the video, tap to go there. The
  // last version's requests not ticked off yet show too, hollow, to look at the same spot.
  const onV = d.log.filter((e) => e.kind === "comment" && e.v === v.v);
  const spots = () => { const open = asked.filter((e) => !isFixed(e.id));
    return {marks: onV.map((e) => ({...whenTag(e.text), text: e.text})).concat(open.map((e) => ({...whenTag(e.text), text: e.text, prev: true}))).filter((m) => m.tag),
      pins: onV.map(pinOfE).filter(Boolean).concat(open.map(pinOfE).filter(Boolean).map((q) => ({...q, prev: true})))}; };
  openItem = {id, p, i, v: v.v, rev: d.rev ?? d.review?.rev, log: d.log, latest, dept: v.dept, reject: v.reject || x?.reject || [], pics, status: v.status, archived: d.archived,
    page: !!page, owed: latest && !done ? dOpen.map(dtxt) : [], quotes: pgMarks,
    vers: vs.map((w) => w.v), alt: flipV && {v: flipV.v, files: flipV.files || []},
    olds: vs.filter((w) => w.v < v.v && w.v !== flipV?.v).reverse().map((w) => ({v: w.v, files: w.files || []})), ...spots()};
  const it = openItem;
  // Feature modules attach per-item UI here (see window.LOOP_SETTINGS for the settings slot).
  // tabs.js normalises the list (functions only, first wins); a block that throws is skipped and
  // never breaks the core item view.
  ((typeof loopItemView === "function" ? loopItemView() : (window.LOOP_ITEM_VIEW || []))).forEach((f) => { try { f(box, it, d); } catch (e) { console.error(e); } });
  document.querySelectorAll("[data-fx]").forEach((b) => b.onclick = () => { const on = b.getAttribute("aria-checked") !== "true";
    setFixed(b.dataset.fx, on); b.setAttribute("aria-checked", on); b.closest(".row").classList.toggle("ok", on);
    const n = asked.filter((e) => isFixed(e.id)).length; document.getElementById("pacount").textContent = `${n} / ${asked.length}`;
    if (on && n === asked.length) toast(tl("itemView.98"), 2200, "confirm");
    Object.assign(it, spots()); drawPins(); stageVideo()?.dispatchEvent(new Event("seeked")); });
  // The counts in the 지시 header go to the first row of their kind, lit up for a moment.
  box.querySelectorAll("[data-dj]").forEach((b) => b.onclick = () => {
    const r = box.querySelector(`.dirs .dir.${b.dataset.dj}`); if (!r) return;
    r.closest("details.dirs").open = true;
    r.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"});
    r.classList.remove("hl"); void r.offsetWidth; r.classList.add("hl"); setTimeout(() => r.classList.remove("hl"), 1200); });
  // 지시 verdicts: 통과 marks a claimed fix verified, 다시 reopens it and re-sends the ask.
  // The verdict is bound to the version in view (latestV): if a newer one arrived meanwhile,
  // the server answers 409 and the page reloads so the fix is judged against the new cut.
  // Each verdict carries the directive's revision as this screen read it (when the server gives
  // one): a fix re-claimed or re-worded in between answers 409 and the change is shown first.
  const dirOf = (id) => dirs.find((x) => x.id === id) || {};
  // v is the version that claimed the fix (fixed_in; the latest one for an unclaimed ask).
  // reason: the optional "what is still off" from the fix check, kept with the 아직.
  const sayDir = (id, ok, rev, reason) => post("/api/directive", {p, i, id, v: dirOf(id).fixed_in || latestV, ok, verdict: ok ? "ok" : "again", rev: rev ?? dirOf(id).rev,
    ...(!ok && reason ? {reason} : {})});
  // Deciding again on this screen only makes sense while the claim is the one shown here.
  const sameClaim = (id) => (b) => !b.stale && (b.fixed_in ?? null) === (dirOf(id).fixed_in ?? null);
  const dirConflict = (e, id, ok, b) => { if (!isConflict(e)) { toast(e.message); if (b) b.disabled = false; return; }
    conflictSheet(e.body, {v: latestV, log: d.log, can: sameClaim(id), again: ok ? tl("conflict.ok") : tl("conflict.again"),
      retry: async (cb) => { await sayDir(id, ok, cb.directive_rev); toast(ok ? tl("verdict.1") : tl("itemView.100")); await load(); again(); },
      reload: async () => { await load(); again(); }}); };
  box.querySelectorAll(".dir .dzz").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await post("/api/directive", {p, i, id: b.dataset.dz, snooze: !dirOf(b.dataset.dz).snoozed}); await load(); again(); }
    catch (e) { toast(e.message); b.disabled = false; } });
  box.querySelectorAll(".dir .dyes").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await sayDir(b.dataset.dv, true); again(); }
    catch (e) { dirConflict(e, b.dataset.dv, true, b); } });
  box.querySelector(".dall")?.addEventListener("click", async (e) => { e.currentTarget.disabled = true;
    try { for (const x of dClaim) await sayDir(x.id, true); toast(tl("itemView.99", {n: dClaim.length}), 2200, "confirm"); again(); }
    catch (err) { if (isConflict(err)) conflictSheet(err.body, {v: latestV, log: d.log, reload: async () => { await load(); again(); }}); else toast(err.message); } });
  box.querySelectorAll(".dir .dno").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await sayDir(b.dataset.dv, false); toast(tl("itemView.100"), 2200, "resent"); again(); }
    catch (e) { dirConflict(e, b.dataset.dv, false, b); } });
  // 고쳤다고 함 → the fix-check workspace: the version the ask was written on, left; the version
  // that says it fixed it, right; the ask, what changed, and 맞아/아직 underneath.
  box.querySelectorAll(".dir [data-fv]").forEach((b) => b.onclick = (e) => { e.stopPropagation();
    const x = dirOf(b.dataset.fv); if (x.id) openFixVerify(x, d, vs, {p, i, latestV, sayDir}); });
  // Feature scripts (wake.js) decorate each directive row with a delivery-state chip and actions.
  (window.LOOP_DIRECTIVE_DECOR || []).forEach((f) => { try { f(box, p, i, again); } catch (e) { console.error(e); } });
  document.querySelector(".sflip")?.addEventListener("click", flipStage);
  const body = document.getElementById("tbody");
  const draw = (k) => {
    tabPick[id] = k;
    // On a phone the comparison replaces the sticky picture (it would sit on top of the compare box).
    box.querySelector(".detailcols.item")?.classList.toggle("tab-cmp", k === "cmp");
    // 대화 has its own message box: the comment dock steps aside so one box, one 보내기 shows.
    box.querySelector(".detailcols.item")?.classList.toggle("tab-chat", k === "chat");
    if (!mount && k !== "cmp") setItemHash(id);   // leaving 비교 drops the ?cmp=… from the address
    document.querySelectorAll("#itabs button").forEach((b) => { b.classList.toggle("on", b.dataset.v === k); b.setAttribute("aria-selected", b.dataset.v === k); });
    if (k === "ask") {
      const ed = askEdit[id] || (askEdit[id] = new Set());
      body.innerHTML = `<div class="ask" id="ask">${ask.map((q, qi) => { const a = askAns[qi];
        // Answered: folded to the answer on record. 고치기 opens it again with the answer filled in.
        if (a && !ed.has(qi)) return `<div class="aq done" data-q="${qi}"><div class="qt">${esc(q.q)}</div><div class="adone"><span class="aa">${ic("check")}<b>${esc(a.text)}</b></span><span class="s">${tl("ask.done_at", {t: ago(a.at)})}</span><button class="lnk press" data-aedit="${qi}">${tl("ask.edit")}</button></div></div>`;
        // Not answered yet: the recommended choice is already picked, so taking the advice is one
        // press on 답 보내기 (data-new: nothing on record, so the pick itself is what gets sent).
        const oi0 = a ? (q.options || []).findIndex((o) => a.text === o || a.text.startsWith(o + " · ")) : Number.isInteger(q.rec) && (q.options || [])[q.rec] ? q.rec : -1, note0 = a ? (oi0 >= 0 ? a.text.slice(q.options[oi0].length).replace(/^ · /, "") : a.text) : "";
        return `<div class="aq" data-q="${qi}" data-pick="${oi0}"${a ? "" : " data-new"}><div class="qt">${esc(q.q)}</div>${(q.options || []).length ? `<div class="aopts">${q.options.map((o, oi) => `<button class="opt press${oi === oi0 ? " on" : ""}" data-a="${oi}">${esc(o)}${q.rec === oi ? `<em>${tl("itemView.101")}</em>` : ""}</button>`).join("")}</div>` : ""}
        <textarea class="anote" rows="1" placeholder="${(q.options || []).length ? tl("itemView.102") : tl("itemView.103")}">${esc(note0)}</textarea></div>`; }).join("")}
        ${askOpen || ed.size ? `<div style="padding:6px 16px 20px"><button class="btn xl fill press" id="asend" disabled style="width:100%">${tl("itemView.104")}</button></div>` : `<div style="height:10px"></div>`}</div>`;
      body.querySelectorAll("[data-aedit]").forEach((b) => b.onclick = () => { ed.add(+b.dataset.aedit); draw("ask"); });
      wireAsk(it, ask);
    } else if (k === "chat") {
      window.LOOP_ITEM_CHAT(body, it);      // the live chat with the session behind this result (custom.js)
    } else if (k === "cm") {
      const noteRow = (e) => e.kind === "astra"
        ? `<div class="row note astra"><span class="tx"><div class="nt"><span class="albl">${tl("itemView.115", {ic: ic("spark", "i")})}</span> ${noteText(e, v.v, pics)}</div><div class="s">${tl("itemView.116", {v: e.v, ago: ago(e.at)})}</div></span><span class="nbtns"><button class="ib press afwd" data-fwd="${esc(e.id)}" aria-label="${tl("itemView.117")}" title="${tl("itemView.118")}">${ic("up")}</button><button class="ib press ndel" data-del="${esc(e.id)}" aria-label="${tl("itemView.119")}" title="${tl("itemView.120")}">${ic("x")}</button></span></div>`
        : `<div class="row note" data-eid="${esc(e.id)}"><span class="tx"><div class="nt">${noteText(e, v.v, pics)}</div><div class="s">${e.kind === "message" ? tl("itemView.121") : e.ack ? tl("itemView.122") : e.delivered ? tl("itemView.123") : e.sent ? tl("itemView.124") : tl("itemView.125")} · ${esc(e.v)} · <time data-note-at="${esc(e.at)}">${ago(e.at)}</time>${e.fixed_in ? ` · <b class="dc">${tl("itemView.7", {esc: esc(e.fixed_in)})}</b>` : ""}${e.edited ? ` · <span class="ned" title="${esc(e.prev_text ? tl("cmEdit.9", {t: e.prev_text.slice(0, 200)}) : "")}">${e.reedited ? tl("cmEdit.4") : tl("cmEdit.3")}</span>` : ""}</div></span>${e.kind === "comment" ? `<span class="nbtns"><button class="ib press nedit" data-edit="${esc(e.id)}" aria-label="${tl("cmEdit.1")}" title="${e.delivered || e.ack ? tl("cmEdit.2") : tl("cmEdit.1")}">${ic("pen")}</button>${!e.delivered && !e.ack ? `<button class="ib press ndel" data-del="${esc(e.id)}" aria-label="${tl("itemView.126")}" title="${tl("itemView.127")}">${ic("x")}</button>` : ""}</span>` : ""}</div>`;
      // Oldest first, as a talk reads: a comment just sent lands at the end, right above the box.
      const fo = cmFold(allNotes, cmOpen() || lfOn, cmSeenOf(id, allNotes)), canFold = allNotes.length > 1 && !lfOn;
      const pk = fo.peek && attOf(fo.peek.text), pv = pk ? esc(pk.words.replace(/[*_`#>]+/g, "").replace(/\s+/g, " ").trim() || tl("itemView.3")) : fo.folded ? tl("cmFold.prev", {n: allNotes.length - fo.keep.length}) : "";
      const foldBtn = fo.folded ? `<button class="cmfold press${cmFade ? " in" : ""}" id="cmfold" aria-expanded="false" aria-label="${tl("cmFold.open", {n: allNotes.length})}">${fo.fresh ? `<em class="cmnew num">${tl("cmFold.new", {n: fo.fresh})}</em>` : ""}<span class="fpv">${pv}</span>${fo.peek ? `<span class="s">${ago(fo.peek.at)}</span>` : ""}${ic("chev", "i dn")}</button>`
        : canFold ? `<button class="cmfold open press" id="cmfold" aria-expanded="true"><span class="fpv">${tl("itemView.30")}</span>${ic("chev", "i dn")}</button>` : "";
      if (fo.folded) body.innerHTML = `${foldBtn}${fo.keep.map(noteRow).join("")}
        ${unsent.length ? `<div class="sendbar"><span>${tl("itemView.128")} <b class="num">${unsent.length}</b></span><button class="btn press" id="cmsend">${tl("itemView.129", {ic: ic("up")})}</button></div>` : `<div style="height:8px"></div>`}`;
      else body.innerHTML = `${foldBtn}<div class="cmlist${cmFade ? " in" : ""}">${LF.length > 1 ? `<div class="chips lfil" data-sk="cf" role="group" aria-label="${tl("itemView.130")}">${LF.map(([k, n, c]) => `<button class="chip press${k === lf[0] ? " on" : ""}" data-lf="${k}" aria-pressed="${k === lf[0]}">${n}${k === "all" ? "" : ` <em class="num">${c}</em>`}</button>`).join("")}</div>` : ""}
        ${notes.length ? (hidden ? `<button class="btn press lmore" id="lmore">${tl("itemView.131", {hidden})}</button>` : "") + notes.map(noteRow).join("") + `<div style="height:8px"></div>`
          : `<div class="fun cmnone">${ic("chat")}<span>${tl("itemView.132")}</span></div>`}
        </div>${unsent.length ? `<div class="sendbar"><span>${tl("itemView.128")} <b class="num">${unsent.length}</b></span><button class="btn press" id="cmsend">${tl("itemView.129", {ic: ic("up")})}</button></div>` : ""}`;
      cmFade = false;
      // Folding is the reader's own setting (this browser), not the item's: it holds from one result to the next.
      document.getElementById("cmfold")?.addEventListener("click", () => { lsSet("v2-cmopen", fo.folded ? "1" : ""); cmSeen.at = allNotes[allNotes.length - 1]?.at || cmSeen.at; cmFade = !RM(); draw("cm");
        document.getElementById("cmfold")?.focus({preventScroll: true}); });
      // A long comment shows three lines and a 더 보기; a picture or an edit box is never cut.
      body.querySelectorAll(".row.note .nt").forEach((nt) => { const row = nt.closest(".row"), eid = row.dataset.eid || row.querySelector("[data-fwd]")?.dataset.fwd;
        if (!eid || nt.querySelector(".npics")) return;
        const full = cmFull.has(eid); nt.classList.toggle("clamp", !full);
        if (!full && nt.scrollHeight <= nt.clientHeight + 4) return nt.classList.remove("clamp");
        const b = document.createElement("button"); b.className = "lnk press ntmore"; b.textContent = full ? tl("itemView.30") : tl("ui.more"); b.setAttribute("aria-expanded", String(full));
        b.onclick = () => { const on = !cmFull.has(eid); on ? cmFull.add(eid) : cmFull.delete(eid); nt.classList.toggle("clamp", !on); b.textContent = on ? tl("itemView.30") : tl("ui.more"); b.setAttribute("aria-expanded", String(on)); };
        nt.after(b); });
      document.getElementById("lmore")?.addEventListener("click", () => { logAll[id] = true; again(); });
      body.querySelectorAll("[data-lf]").forEach((b) => b.onclick = () => { logF[id] = b.dataset.lf; again(); });
      // 부서에 전달: the reader chooses to send Astra's opinion on as a comment (a directive).
      body.querySelectorAll("[data-fwd]").forEach((b) => b.onclick = async () => {
        const e = allNotes.find((x) => x.id === b.dataset.fwd); if (!e) return; b.disabled = true;
        try { await post("/api/comment", {p, i, v: v.v, text: tl("itemView.133") + e.text}); await sendNow(it); again(); toast(tl("itemView.134"), 2200, "delivered"); }
        catch (err) { toast(err.message); b.disabled = false; } });
      gitCard(body, p, i, v.v);
      // A comment no session has read yet can still be taken back (a typo, the wrong item).
      body.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => { b.disabled = true;
        try { const gone = (await post("/api/delete", {p: it.p, i: it.i, id: b.dataset.del})).entry; again();
          toastAct(tl("itemView.135"), tl("toggleFav.3"), async () => {
            try { await post("/api/restore", {p: it.p, i: it.i, entry: gone}); again(); } catch (e) { toast(e.message); } });
        } catch (e) { toast(e.message); b.disabled = false; } });
      // 고치기: the comment's words open in place. Before a session took it this is a quiet fix;
      // after, the corrected ask goes to the session again, labelled as a correction (C06).
      body.querySelectorAll("[data-edit]").forEach((b) => b.onclick = () => {
        const e = allNotes.find((x) => x.id === b.dataset.edit), row = b.closest(".row"); if (!e || !row || row.querySelector(".nedbox")) return;
        const nt = row.querySelector(".nt"), was = nt.innerHTML, taken = !!(e.delivered || e.ack);
        nt.classList.remove("clamp"); row.querySelector(".ntmore")?.remove();
        nt.innerHTML = `<div class="nedbox"><textarea class="nedta" rows="3" aria-label="${tl("cmEdit.1")}"></textarea><div class="nedrow"><span class="fun">${taken ? tl("cmEdit.5") : tl("cmEdit.6")}</span><button class="btn press" data-ecx>${tl("cmEdit.7")}</button><button class="btn fill press" data-eok>${tl("cmEdit.8")}</button></div></div>`;
        const ta = nt.querySelector("textarea"), ok = nt.querySelector("[data-eok]");
        ta.value = e.text; ta.style.height = Math.min(ta.scrollHeight + 2, 260) + "px"; ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
        const close = () => { nt.innerHTML = was; };
        const save = async () => { const text = ta.value.trim(); if (!text || text === e.text.trim()) return close(); ok.disabled = true;
          try { const r = await post("/api/edit", {p: it.p, i: it.i, id: e.id, text});
            if (r.entry?.reedited && !r.entry.delivered) { toast(tl("cmEdit.10"), 2200, "confirm"); await sendNow(it); } else toast(tl("cmEdit.11"), 2200, "confirm");
            again(); }
          catch (err) { toast(err.message); ok.disabled = false; } };
        nt.querySelector("[data-ecx]").onclick = close; ok.onclick = save;
        ta.addEventListener("keydown", (k) => { if (k.key === "Escape") { k.preventDefault(); close(); } else if (k.key === "Enter" && (k.ctrlKey || k.metaKey)) { k.preventDefault(); save(); } });
      });
      const send = document.getElementById("cmsend");
      if (send) send.onclick = async () => { send.disabled = true;
        try { await sendNow(it); again(); } catch (e) { toast(e.message); send.disabled = false; } };
    } else {
      const side = (f, img, k) => cv ? `<video class="${k}" src="${esc(f.play || f.url)}" muted loop playsinline preload="auto"></video>` : `<div class="${k}" style="background-image:url('${esc(img)}')"></div>`;
      // 차이(pixel diff) now covers two videos too: their current frames are diffed live, so it
      // joins the modes for both stills and videos.
      const isVid = !!cv, MODES = CMPM.concat([["diff", tl("itemView.136")]]);
      let eff = cmpMode(); if (!MODES.some((m) => m[0] === eff)) eff = "wipe";
      // 지시 위치 겹쳐 보기: the pins/moments the previous version's comments carried, to lay over
      // the newer frame with a toggle; each says whether a later version claimed it fixed.
      const ov = overlayFromPrev(d.log.filter((e) => e.kind === "comment" && e.v === pv.v && !/^\[(답|확정)\]/.test(e.text)), v.v);
      // What the newer version reports it changed, read beside the picture so a look explains itself.
      const chg = versionChanges(v, pv, d.directives);
      const chgHtml = (chg.summary || chg.fixed.length || chg.later) ? `<div class="vchg"><b>${tl("itemView.139", {esc: esc(chg.to)})}</b>${chg.summary ? `<p>${esc(chg.summary)}</p>` : ""}${chg.fixed.length ? `<ul>${chg.fixed.slice(0, 4).map((t) => `<li>${esc(t.slice(0, 80))}</li>`).join("")}${chg.fixed.length > 4 ? `<li class="more">${tl("itemView.137", {p0: chg.fixed.length - 4})}</li>` : ""}</ul>` : ""}${chg.later ? `<p class="lt">${tl("itemView.138", {esc: esc(laterText(chg.later, d.directives))})}</p>` : ""}</div>` : "";
      // The pair steps in place, one version at a time per side: on a phone the timeline that
      // also picks it sits a screen above this tab (user, 2026-09-29).
      const ordA = cmps.map((c) => c.w).reverse(), ordB = vs.slice().reverse().filter((w) => w !== pv);
      const stepOf = (ord, cur, dir) => ord[ord.indexOf(cur) + dir] || null;
      const sw = (k, ord, cur) => `<button class="ib press" data-cst="${k}" data-d="-1" aria-label="${k === "a" ? tl("cmpsw.1") : tl("cmpsw.2")}"${stepOf(ord, cur, -1) ? "" : " disabled"}>${ic("chev", "i lf")}</button><b class="num">${esc(cur.v)}</b><button class="ib press" data-cst="${k}" data-d="1" aria-label="${k === "a" ? tl("cmpsw.3") : tl("cmpsw.4")}"${stepOf(ord, cur, 1) ? "" : " disabled"}>${ic("chev")}</button>`;
      body.innerHTML = `<div class="cmptop"><span class="cmpsw" role="group" aria-label="${tl("cmpsw.5")}">${sw("a", ordA, pv)}<span class="ar">→</span>${sw("b", ordB, v)}</span><span class="grow"></span><span class="cmpres" id="cmpres" hidden></span><button class="btn sm fill press" id="cvopen" title="${tl("cv.open.t")}">${ic("full")}${tl("cv.open")}</button><button class="lnk press" id="cmpcopy" title="${tl("itemView.145")}">${tl("itemView.146", {ic: ic("link")})}</button></div>
        ${cmps.length > 1 ? `<button class="cmphint fun press" id="cmphint">${tl("itemView.140")} <b>${tl("itemView.72")}</b>${tl("itemView.141")}</button>` : ""}
        ${chgHtml}
        <div class="cmpm"><div class="seg" role="group" aria-label="${tl("itemView.147")}">${MODES.map(([k, n]) => `<button class="press${k === eff ? " on" : ""}" data-cm="${k}" aria-pressed="${k === eff}">${n}</button>`).join("")}</div>
          <label class="cmpo"${eff === "over" ? "" : " hidden"}><span class="num">${pv.v}</span><input type="range" id="cmpo" min="0" max="100" value="${cmpOp}" aria-label="${tl("itemView.148", {v: v.v})}"><span class="num">${v.v}</span></label>
          <label class="cmpthr"${eff === "diff" ? "" : " hidden"}><span>${tl("itemView.149")}</span><input type="range" id="cmpthr" min="4" max="80" value="${cmpThr}" aria-label="${tl("itemView.150")}"><span class="cmpdr num" id="cmpdr"></span></label>
          ${ov.length ? `<button class="opt press cmpovt" id="cmpovt" aria-pressed="false" title="${tl("itemView.142")}">${ic("pin")}<span>${tl("itemView.143")}</span></button>` : ""}</div>
        <div class="cmp m-${eff}${cv ? " vid" : ""}" id="cmp" style="--o:${cmpOp / 100}">${side(cv?.[0], ps.img, "a")}${side(cv?.[1], s.img, "b")}<canvas class="cdiff" aria-label="${tl("itemView.151")}"></canvas><div class="cmpov" aria-hidden="true"></div><div class="h"></div><span class="lb l">${pv.v}</span><span class="lb r">${v.v}</span></div>
        ${cv ? `<div class="cmpbar"><button class="press" id="cmpplay" aria-label="${tl("itemView.39")}">${ic("play")}</button><button class="press" data-cs="-1" aria-label="${tl("itemView.41")}">${ic("chev")}</button><button class="press" data-cs="1" aria-label="${tl("itemView.45")}">${ic("chev")}</button><span class="num" id="cmpnow"></span><span class="grow"></span><span class="sub">${esc(cv[1].name)}</span></div>
        <div class="cmprail" id="cmprail" tabindex="0" role="slider" aria-label="${tl("itemView.144")}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="cmptk"><i class="fill"></i><div class="ticks" aria-hidden="true"></div><span class="ph"></span></div><div class="cmpdur"><span class="da num"></span><span class="db num"></span></div></div>` : ""}
        <div style="height:14px"></div>`;
      // The chip row is gone; this points to the one picker and turns 비교 on so a pair can be chosen.
      document.getElementById("cmphint")?.addEventListener("click", () => {
        const vtl = document.getElementById("vtl"); if (!vtl) return;
        vtl.scrollIntoView({block: wide() ? "nearest" : "center", behavior: RM() ? "auto" : "smooth"});
        if (!cmpToggle) document.getElementById("vtlcmp")?.click();
      });
      body.querySelectorAll("[data-cst]").forEach((b) => b.onclick = () => { const d = +b.dataset.d;
        if (b.dataset.cst === "a") { const w = stepOf(ordA, pv, d); if (w) cmpPick[id] = w.v; }
        else { const w = stepOf(ordB, v, d); if (!w) return; cmpPick[id] = pv.v; if (w.v === vs[0].v) delete verPick[id]; else verPick[id] = w.v; }
        tabPick[id] = "cmp"; again(); });
      const c = document.getElementById("cmp");
      // Different resolutions between the two versions: say so and keep 밀기 from scaling the
      // smaller up to cover the box (nearby CSS switches .mism to contain). Videos read their size
      // once metadata is in; images are loaded once for their natural size.
      const resEl = document.getElementById("cmpres");
      const showRes = (a, b) => { const lab = resMismatch(a, b); if (!resEl) return;
        c.classList.toggle("mism", !!lab);
        if (lab) { resEl.textContent = tl("itemView.162", {r: lab}); resEl.hidden = false; } else resEl.hidden = true; };
      if (cv) { const [va, vb] = c.querySelectorAll("video");
        const chk = () => { if (va?.videoWidth && vb?.videoWidth) showRes({w: va.videoWidth, h: va.videoHeight}, {w: vb.videoWidth, h: vb.videoHeight}); };
        [va, vb].forEach((m) => m && (m.readyState >= 1 ? chk() : m.addEventListener("loadedmetadata", chk, {once: true}))); }
      else if (ps.img && s.img) Promise.all([loadImg(ps.img), loadImg(s.img)])
        .then(([ia, ib]) => c.isConnected && showRes({w: ia.naturalWidth, h: ia.naturalHeight}, {w: ib.naturalWidth, h: ib.naturalHeight})).catch(() => {});
      // The compare state rides in the address so a reload, Back, or a shared link restores this
      // exact pair, mode, threshold, and moment. `curMode` tracks the mode as it switches in place.
      const cvid = cv ? c.querySelectorAll("video")[1] : null;
      let curMode = eff;
      const syncUrl = () => { if (!mount) setCmpHash(id, v.v, pv.v, curMode, cvid ? cvid.currentTime : 0, cmpThr); };
      // The pixel diff is drawn once per (pair, 기준); the readout under 기준 says how much moved.
      const dr = document.getElementById("cmpdr");
      const setRatio = (r) => { if (dr) dr.textContent = r == null ? tl("itemView.152") : tl("itemView.153", {p0: Math.round(r * 100)}); };
      // 지시 겹쳐 보기: redrawn on demand, on every frame while a video plays, and on resize.
      const drawOv = () => renderCmpOverlay(c, ov, cv ? cv[1].fps || 0 : 0);
      // 차이: two stills diff by URL once per (pair, 기준); two videos diff their current frames live.
      const vdiff = cv ? wireCmpVideoDiff(c, () => cmpThr, () => c.classList.contains("m-diff"), setRatio) : null;
      const showDiff = () => cv ? vdiff() : renderCmpDiff(c, ps.img, s.img, cmpThr, setRatio);
      if (cv) { wireCmpVideo(c, cv[1].fps, drawOv);
        wireCmpRail(c, cv, cmpRailMarks(d, cv, pv), cv[1].fps, {a: pv.v, b: v.v}); }
      if (eff === "diff") showDiff();
      // 밀기 · 나란히 · 겹치기 · 차이 switch in place: the videos keep playing where they are.
      body.querySelectorAll("[data-cm]").forEach((b) => b.onclick = () => { cmpMode(b.dataset.cm); curMode = b.dataset.cm;
        body.querySelectorAll("[data-cm]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        MODES.forEach(([k]) => c.classList.toggle("m-" + k, k === b.dataset.cm));
        body.querySelector(".cmpo").hidden = b.dataset.cm !== "over"; body.querySelector(".cmpthr").hidden = b.dataset.cm !== "diff";
        drawOv();
        if (b.dataset.cm === "diff") showDiff(); syncUrl(); });
      document.getElementById("cmpo").oninput = (e) => { cmpOp = +e.target.value; c.style.setProperty("--o", cmpOp / 100); drawOv(); };
      document.getElementById("cmpthr").oninput = (e) => { cmpThr = +e.target.value; clearTimeout(cmpThrT); cmpThrT = setTimeout(() => { showDiff(); syncUrl(); }, 90); };
      const ovt = document.getElementById("cmpovt");
      if (ovt) ovt.onclick = () => { const on = c.classList.toggle("ov-on"); ovt.classList.toggle("on", on); ovt.setAttribute("aria-pressed", String(on)); drawOv(); };
      // An image compare needs the newer picture's natural size to place a pin; load it once.
      if (ov.length && !cv && s.img) loadImg(s.img).then((im) => { const lay = c.querySelector(".cmpov"); if (lay && c.isConnected) { lay._nw = im.naturalWidth; lay._nh = im.naturalHeight; drawOv(); } }).catch(() => {});
      new ResizeObserver(() => drawOv()).observe(c);
      // Restore a moment from the address, then keep the address in step as the video moves.
      if (cvid && cmpSeek != null) { const t = cmpSeek; cmpSeek = null;
        const go = () => { try { cvid.currentTime = t; } catch (e) {} }; cvid.readyState >= 1 ? go() : cvid.addEventListener("loadedmetadata", go, {once: true}); }
      if (cvid && !mount) { cvid.addEventListener("seeked", syncUrl); cvid.addEventListener("pause", syncUrl); }
      syncUrl();
      document.getElementById("cmpcopy").onclick = async () => {
        const ok = await copyText(location.href.split("#")[0] + cmpHashStr(id, v.v, pv.v, curMode, cvid ? cvid.currentTime : 0, cmpThr));
        toast(ok ? tl("itemView.154") : tl("itemView.155"), 2200, ok ? "copied" : "failed"); };
      document.getElementById("cvopen").onclick = () => openCmpWorkspace(x, vs, pv.v, v.v);
      c.addEventListener("pointerdown", (e) => { if (!c.classList.contains("m-wipe")) return; c.setPointerCapture(e.pointerId);
        const mv = (ev) => { const r = c.getBoundingClientRect(); c.style.setProperty("--x", Math.min(100, Math.max(0, (ev.clientX - r.left) / r.width * 100)) + "%"); };
        mv(e); c.onpointermove = mv; c.onpointerup = c.onpointercancel = () => { c.onpointermove = null; }; });
    }
    tgtLabel();
  };
  document.querySelectorAll("#itabs button").forEach((b) => b.onclick = () => {
    draw(b.dataset.v);
    // On a phone the tab body can sit under the decision bar: bring the whole card up to the header.
    const card = b.closest(".itab");
    if (!wide() && card.getBoundingClientRect().bottom > innerHeight - 90) card.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"});
  });
  // An HTML report is checked at both widths: PC fills the column, 폰 shows it at 390px.
  document.querySelectorAll(".pgtop [data-pw]").forEach((b) => b.onclick = () => { pageW = b.dataset.pw; try { localStorage.setItem("pageW", pageW); } catch {}
    document.getElementById("pgw").classList.toggle("phone", pageW === "phone");
    document.querySelectorAll(".pgtop [data-pw]").forEach((x) => x.classList.toggle("on", x === b)); });
  pageZoom(null);
  document.querySelectorAll(".pgtop .pgzoom [data-z]").forEach((b) => b.onclick = () => { const d = +b.dataset.z; pageZoom(Math.abs(d) === 1 ? d : 0); });
  // An HTML report used to fill the phone screen; scrolling inside the iframe trapped the page
  // so the questions/comments below were out of reach. The frame is capped and this opens it full.
  const pgfull = document.getElementById("pgfull");
  if (pgfull && !oldMedia) { const onEsc = (e) => { if (e.key === "Escape") pgfull.click(); };
    pgfull.onclick = () => { const pgw = document.getElementById("pgw"), on = pgw.classList.toggle("full");
      pgfull.setAttribute("aria-pressed", String(on)); pgfull.querySelector("span").textContent = on ? tl("itemView.114") : tl("itemView.26");
      document.body.classList.toggle("pgfullon", on);
      if (on) addEventListener("keydown", onEsc); else removeEventListener("keydown", onEsc); }; }
  stageGo = wireStage(pics, pics.filter((f) => f.kind === "video").length === 1 ? v.shots : null); wireGrip();
  const summary = box.querySelector(".isumwrap"), summaryMore = summary?.querySelector(".isummore");
  if (summaryMore) { const text = summary.querySelector(".isum"); summaryMore.hidden = text.scrollHeight <= text.clientHeight + 2;
    summaryMore.onclick = () => { const on = summary.classList.toggle("open"); summaryMore.setAttribute("aria-expanded", String(on)); summaryMore.textContent = on ? tl("itemView.30") : tl("ui.more"); }; }
  const kd = keep?.v === v.v && keep.t > 0 && stageVideo();
  if (kd && keep.pic) kd.poster = keep.pic;
  if (kd) { const seek = () => { kd.currentTime = keep.t; if (keep.play) playNow(kd); }; kd.readyState >= 1 ? seek() : kd.addEventListener("loadedmetadata", seek, {once: true}); }
  if (autoPlay) { autoPlay = false; playNow(stageVideo()); }
  wireComments(it);
  draw(tab);
  // A report has no picture to mark, so its comment tools (사진, 선택지 보기) wait on a PC until
  // the box is used; with an image they are the review tools and stay out (v2.css .cdock.quiet).
  document.getElementById("cm")?.addEventListener("focus", () => { dockOpenOf = id; document.getElementById("cdock")?.classList.add("open"); });
  // 답하기 n in the dock (phone): the questions sit under the report, so the one press that is
  // always on screen opens their tab and brings the card up.
  box.querySelector("[data-askgo]")?.addEventListener("click", () => { draw("ask");
    box.querySelector(".itab")?.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); });
  // A redraw rebuilt the side panel: put its scroll back, and keep the end of the list in sight
  // when it was (or when a comment was just sent, so it shows right above the box).
  const newPanel = box.querySelector(".detailcols.item > div:last-child");
  if (newPanel && panelTop) newPanel.scrollTop = panelTop;
  // A phone measures against the page, and the picture above the list is still settling its height.
  if (Date.now() < cmJump || panelEnd) { cmEnd(); if (!wide()) setTimeout(() => { if (openItem?.id === id) cmEnd(); }, 350); }
  if (typed) { const t = document.getElementById("cm");
    if (t && document.activeElement !== t) { try { t.focus({preventScroll: true}); t.setSelectionRange(typed[0], typed[1]); } catch {} } }
  if (cvAuto === id && !mount) { cvAuto = null; if (pv) openCmpWorkspace(x, vs, pv.v, v.v, cvScroll); }
  // A compare link opened on a phone lands above the sticky media; bring the comparison into view.
  if (restoredCmp && !wide()) { const el = box.querySelector("#cmp") || box.querySelector(".itab");
    el?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}); }
  document.querySelectorAll(".tolatest").forEach((b) => b.addEventListener("click", () => { delete verPick[id]; again(); }));
  const more = mount ? null : document.getElementById("imore");
  if (more) more.onclick = () => {
    const f = pics[stageAt] || files[0];
    const row = (k, icon, t, sub = "") => `<button class="row press" data-m="${k}"><span class="ico sm c-grey">${ic(icon)}</span><span class="tx"><div class="t" style="font-size:16px">${t}</div>${sub ? `<div class="s">${sub}</div>` : ""}</span></button>`;
    sheet(`<h3>${esc(d.title)}</h3>
      ${f ? `<a class="row press" href="${esc(f.url)}" target="_blank" rel="noopener"><span class="ico sm c-grey">${ic("ext")}</span><span class="tx"><div class="t" style="font-size:16px">${tl("itemView.156")}</div><div class="s">${esc(f.name)}</div></span></a>` : ""}
      ${row("copy", "link", tl("itemView.157"), tl("itemView.158"))}
      ${latest && v.status === "approved" && !done ? row("unapprove", "back", tl("itemView.159")) : ""}
      ${latest && !done ? row("done", "check", tl("itemView.57"), tl("itemView.160")) : ""}
      ${wide() ? row("keys", "kbd", pref("keys") ? tl("keybar.menu.off") : tl("keybar.menu.on"), tl("keybar.menu.d")) : ""}`, (el) => {
      el.querySelectorAll("[data-m]").forEach((b) => b.onclick = async (e) => { e.stopPropagation(); const m = b.dataset.m;
        if (m === "copy") { const ok = await copyText(location.href.split("#")[0] + "#item/" + id); closeSheet(); return toast(ok ? tl("itemView.161") : tl("itemView.155"), 2200, ok ? "copied" : "failed"); }
        closeSheet();
        if (m === "keys") keyBarToggle();
        else if (m === "unapprove") decide("pending");
        else if (m === "done") setTimeout(() => decide("done"), 280); });
    });
  };
}
// The comment tab's "this file" chip follows the file on screen.
function tgtLabel() {
  const b = document.querySelector('.tg[data-tgt="file"]'), f = openItem?.pics[stageAt];
  if (!b || !f) return;
  b.innerHTML = `${tl("tgtLabel.1")} <b>${esc(f.name)}</b>`;
  const t = document.querySelector(".tgt")?.dataset.on || "file";
  document.querySelectorAll(".tg").forEach((x) => x.classList.toggle("on", x.dataset.tgt === t));
}
// Files on the result page: one at a time, following the finger, springing to the next.
// The grip under the stage sizes it: 1:1 with the finger, carried on by the flick and eased
// back inside the limits on release, kept for next time. A double tap goes back to the default.
// A portrait video in the default 16:10 box is small on a phone, so this is the way to see it big.
function wireGrip() {
  const g = document.getElementById("sgrip"), st = document.getElementById("stage");
  if (!g || !st) return;
  const lo = () => 140, hi = () => Math.max(lo() + 40, innerHeight - 170);
  const put = (h) => { st.style.height = h + "px"; st.style.maxHeight = "none"; st.style.aspectRatio = "auto"; };
  const fit = (h) => Math.max(lo(), Math.min(hi(), h));
  let saved = 0; try { saved = +localStorage.getItem("stageH") || 0; } catch {}
  if (saved) put(fit(saved));
  // No size of the user's own yet: a portrait file on a phone opens tall enough to read,
  // instead of a sliver in the middle of a 16:10 box.
  stageFit = saved || wide() ? null : () => {
    const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video");
    const w = m?.videoWidth || m?.naturalWidth, hh = m?.videoHeight || m?.naturalHeight;
    if (!w || !hh) return m?.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", () => stageFit?.(), {once: true});
    if (hh > w * 1.05) put(Math.round(Math.min(innerHeight * 0.56, st.clientWidth * hh / w)));
    else { st.style.height = st.style.maxHeight = st.style.aspectRatio = ""; }
  };
  stageFit?.();
  let d = null, h = 0, stop = null;
  g.addEventListener("pointerdown", (e) => {
    if (e.button) return;
    stop && stop(); h = st.getBoundingClientRect().height;
    d = {id: e.pointerId, y0: e.clientY, h0: h, hist: [[e.clientY, e.timeStamp]]};
    g.setPointerCapture(e.pointerId); g.classList.add("on"); e.preventDefault();
  });
  g.addEventListener("pointermove", (e) => {
    if (!d || e.pointerId !== d.id) return;
    h = d.h0 + e.clientY - d.y0;
    if (h < lo()) h = lo() + rubber(h - lo(), innerHeight); else if (h > hi()) h = hi() + rubber(h - hi(), innerHeight);
    put(h); d.hist.push([e.clientY, e.timeStamp]); if (d.hist.length > 5) d.hist.shift();
  });
  const end = (e) => {
    if (!d || e.pointerId !== d.id) return;
    const a = d.hist[0], b = d.hist[d.hist.length - 1], v = b[1] > a[1] ? (b[0] - a[0]) / (b[1] - a[1]) * 1000 : 0;
    d = null; g.classList.remove("on");
    const to = fit(h + project(v, 0.99));
    try { localStorage.setItem("stageH", Math.round(to)); } catch {}
    stageFit = null;
    if (RM()) return put(to);
    stop = springTo(() => h, (x) => { h = x; put(x); }, to, v, null, 0.36, 1);
  };
  g.addEventListener("pointerup", end); g.addEventListener("pointercancel", end);
  g.addEventListener("dblclick", () => { stop && stop(); st.style.height = st.style.maxHeight = st.style.aspectRatio = "";
    try { localStorage.removeItem("stageH"); } catch {} });
}
// ---- frames: seeking to the middle of a frame so the decoder settles on it
// (frameOf and clock live in stamp.js with the comment tags).
// Play what was just brought up; where the browser refuses sound without a tap, play it muted.
const playNow = (vd) => vd?.play().catch(() => { if (vd.muted) return; vd.muted = true; vd.play().catch(() => {}); });
// The bar's play button follows the video; redrawn only on a change, so a press is never cut under the finger.
const showPlay = (fs, vd) => { const b = fs.querySelector(".fplay"), on = !!vd && !vd.paused;
  if (b.dataset.on === String(on)) return; b.dataset.on = on; b.innerHTML = ic(on ? "pause" : "play"); b.setAttribute("aria-label", on ? tl("showPlay.1") : tl("itemView.39")); };
// Set by 다음 (N, or after 승인): the next result starts playing as it opens.
let autoPlay = false;
const stageVideo = () => document.querySelectorAll("#stage .sl")[stageAt]?.querySelector("video") || null;
const stepFrame = (n) => stepVideo(stageVideo(), openItem?.pics[stageAt], n);
function stepVideo(vd, f, n) {
  if (!vd || !f) return;
  vd.pause();
  const end = Number.isFinite(vd.duration) ? vd.duration : Infinity;
  if (!f.fps) { vd.currentTime = Math.max(0, Math.min(end, vd.currentTime + n * 0.1)); return; }
  const last = f.frames ? f.frames - 1 : Math.max(0, Math.round(end * f.fps) - 1);
  vd.currentTime = (Math.max(0, Math.min(last, frameOf(vd.currentTime, f.fps) + n)) + 0.5) / f.fps;
}
// Press-and-hold a step button: one step on press, then repeat with acceleration until release.
// Pointer capture keeps it running if the finger slides off; releasing lands on the frame reached.
function holdStep(b, dir) {
  b.addEventListener("pointerdown", (e) => {
    if (e.button) return;
    e.preventDefault(); b.setPointerCapture?.(e.pointerId);
    const mult = e.shiftKey ? 10 : 1;
    stepFrame(dir * mult);
    let held = 0, t = null;
    const tick = () => { held++; stepFrame(dir * mult); t = setTimeout(tick, held < 6 ? 110 : held < 14 ? 60 : 30); };
    const first = setTimeout(tick, 320);        // a tap is one frame; a hold starts repeating after this
    const stop = () => { clearTimeout(first); clearTimeout(t);
      b.removeEventListener("pointerup", stop); b.removeEventListener("pointercancel", stop); b.removeEventListener("lostpointercapture", stop); };
    b.addEventListener("pointerup", stop); b.addEventListener("pointercancel", stop); b.addEventListener("lostpointercapture", stop);
  });
  // Keyboard focus on the button: Enter/Space steps once (arrows step from anywhere on the page).
  b.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); stepFrame(dir * (e.shiftKey ? 10 : 1)); } });
}
// A frame/time typed into the readout: "120" or "f120" is a frame (seconds when the file has no fps),
// "1:23" a clock, "3.5s" seconds. Returns seconds to seek to, or null when it makes no sense.
function parseSeek(s, f) {
  s = String(s).trim(); if (!s) return null; let m;
  if ((m = /^(\d+):([0-5]?\d(?:\.\d+)?)$/.exec(s))) return +m[1] * 60 + +m[2];
  if ((m = /^(\d+(?:\.\d+)?)\s*s$/i.exec(s))) return +m[1];
  if ((m = /^f?\s*(\d+(?:\.\d+)?)$/i.exec(s))) { const n = +m[1]; return f?.fps ? (n + 0.5) / f.fps : n; }
  return null;
}
// Tap the readout to type a moment to jump to; readout() redraws it once the input closes.
function fnowJump(el, pic, redraw) {
  el.onclick = () => {
    const vd = stageVideo(), f = pic(); if (!vd || el.querySelector("input")) return;
    const cur = f.fps ? String(frameOf(vd.currentTime, f.fps)) : clock(vd.currentTime, true);
    el.innerHTML = `<input class="fjump num" value="${esc(cur)}" inputmode="decimal" aria-label="${tl("fnowJump.1")}">`;
    const inp = el.querySelector("input"); inp.focus(); inp.select();
    const close = () => { inp.onblur = null; inp.remove(); redraw(); };
    const commit = (hint) => { const t = parseSeek(inp.value, f);
      if (t != null && Number.isFinite(vd.duration)) vd.currentTime = Math.max(0, Math.min(vd.duration - 0.001, t));
      else if (t == null && hint) toast(tl("fnowJump.2"));
      close(); };
    inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); commit(true); } else if (e.key === "Escape") { e.preventDefault(); close(); } };
    inp.onblur = () => commit(false);
  };
}
// M (Shift+M back): jump to the next comment mark on the file on screen.
function jumpMark(dir) {
  const vd = stageVideo(), f = openItem?.pics[stageAt]; if (!vd || !f) return;
  const single = openItem.pics.filter((g) => g.kind === "video").length === 1;
  const ts = (openItem.marks || []).filter((m) => m.name ? m.name === f.name : single)
    .map((m) => f.fps && m.frame != null ? (m.frame + 0.5) / f.fps : m.t).sort((a, b) => a - b);
  if (!ts.length) return toast(tl("jumpMark.1"));
  const now = vd.currentTime, t = dir > 0 ? ts.find((x) => x > now + 0.05) : ts.filter((x) => x < now - 0.05).pop();
  if (t == null) return toast(dir > 0 ? tl("jumpMark.2") : tl("jumpMark.3"));
  vd.currentTime = t;                           // a playing video keeps playing from the mark
}
// Slow motion for checking a move: 1x, 0.5x, 0.25x, round again. One speed for every video on the stage.
let rate = 1;
function nextRate() { setRate(rate === 1 ? 0.5 : rate === 0.5 ? 0.25 : 1); }
// J K L as in every editor: K stops, L plays and each further L goes faster (1 1.5 2),
// J slows a playing video down, or on a stopped one goes back a second.
const RATES = [0.25, 0.5, 1, 1.5, 2];
function jkl(k, vd) {
  if (k === "k") return vd.pause();
  const i = RATES.indexOf(rate);
  if (k === "l") { if (vd.paused) { setRate(1); return playNow(vd); } return setRate(RATES[Math.min(RATES.length - 1, i + 1)]); }
  if (vd.paused) { vd.currentTime = Math.max(0, vd.currentTime - 1); return; }
  setRate(RATES[Math.max(0, i - 1)]);
}
function setRate(r) {
  rate = r;
  document.querySelectorAll("#stage video, .vw video, #cmp video").forEach((vd) => { vd.playbackRate = rate; });
  const b = document.querySelector(".fstep .frate"); if (b) { b.textContent = `${rate}×`; b.classList.toggle("on", rate !== 1); }
}
// The before/after wipe with two videos: the new one leads, the old one follows it
// (play, pause, seek, and a nudge back whenever they drift more than a frame apart).
function wireCmpVideo(c, fps, onFrame) {
  const [a, b] = c.querySelectorAll("video"), play = document.getElementById("cmpplay"), now = document.getElementById("cmpnow");
  const f = fps || 30;
  // The older cut follows the driving (newer) time by absolute time (alignTime); past its end its
  // last frame is held instead of re-seeking every tick.
  const sync = () => { const {t, past} = alignTime(b.currentTime, a.duration);
    if (past) { if (!a.paused) a.pause(); return; }
    if (a.paused && !b.paused) a.play().catch(() => {});
    if (Math.abs(a.currentTime - t) > 1 / f) a.currentTime = t; };
  const show = () => { now.textContent = fps ? `f${frameOf(b.currentTime, fps)}` : clock(b.currentTime, true); play.innerHTML = ic(b.paused ? "play" : "pause"); play.setAttribute("aria-label", b.paused ? tl("itemView.39") : tl("SESS_T.2")); onFrame && onFrame(); };
  b.addEventListener("play", () => { sync(); a.play().catch(() => {}); show(); });
  b.addEventListener("pause", () => { a.pause(); sync(); show(); });
  b.addEventListener("seeked", () => { sync(); show(); });
  b.addEventListener("timeupdate", () => { if (!b.paused) sync(); show(); });
  play.onclick = () => b.paused ? b.play().catch(() => {}) : b.pause();
  document.querySelectorAll("[data-cs]").forEach((x) => x.onclick = () => { b.pause();
    b.currentTime = stepTime(b.currentTime, fps, +x.dataset.cs, b.duration); });
  show();
}
// The pixel diff for two videos: their current frames are drawn onto one grid (the newer's aspect,
// capped at 1024 wide) and diffed. While a video plays it redraws per displayed frame, throttled to
// spare the CPU; paused or scrubbing, it redraws on every seek. Returns a function that forces a
// redraw (mode switch, threshold change). The last frame's cost is left on window.__cmpDiffMs.
function wireCmpVideoDiff(c, getThr, isDiff, onRatio) {
  const [a, b] = c.querySelectorAll("video");
  const oa = document.createElement("canvas"), ob = document.createElement("canvas");
  const ga = oa.getContext("2d", {willReadFrequently: true}), gb = ob.getContext("2d", {willReadFrequently: true});
  let raf = 0, last = 0;
  const draw = () => {
    const out = c.querySelector(".cdiff"); if (!out || !a || !b) return;
    const bw = b.videoWidth, bh = b.videoHeight; if (!bw || !bh) return onRatio(null);
    const {w, h} = diffSize(bw, bh, 1024);
    const t0 = performance.now();
    try {
      oa.width = ob.width = out.width = w; oa.height = ob.height = out.height = h;
      ga.drawImage(a, 0, 0, w, h); gb.drawImage(b, 0, 0, w, h);
      const r = diffPixels(ga.getImageData(0, 0, w, h).data, gb.getImageData(0, 0, w, h).data, w, h, {threshold: getThr()});
      out.getContext("2d").putImageData(new ImageData(r.data, w, h), 0, 0);
      onRatio(r.ratio);
      try { window.__cmpDiffMs = Math.round((performance.now() - t0) * 10) / 10; } catch {}
    } catch { onRatio(null); }
  };
  const rVFC = "requestVideoFrameCallback" in HTMLVideoElement.prototype;
  const schedule = () => { raf = rVFC ? b.requestVideoFrameCallback(loop) : requestAnimationFrame(loop); };
  function loop() { raf = 0; if (!isDiff()) return;
    const now = performance.now(); if (now - last > 80) { last = now; draw(); }   // ~12/s is plenty to read
    if (!b.paused) schedule(); }
  b.addEventListener("play", () => { if (isDiff() && !raf) schedule(); });
  b.addEventListener("seeked", () => { if (isDiff()) draw(); });
  b.addEventListener("pause", () => { if (isDiff()) draw(); });
  // Opened straight into 차이 before the frames decode: redraw once each side is ready.
  const ready = () => { if (isDiff() && a.readyState >= 2 && b.readyState >= 2) draw(); };
  a.addEventListener("loadeddata", ready); b.addEventListener("loadeddata", ready);
  return () => { draw(); if (!b.paused && isDiff() && !raf) schedule(); };
}
// The time-tagged comments that sit on the compared file, for the scrub rail's ticks. A mark's
// time is read at the newer video's rate; ones left on the previous version are dimmer.
function cmpRailMarks(d, cv, pv) {
  const names = [cv[1]?.name, cv[0]?.name].filter(Boolean);
  return (d.log || []).filter((e) => e.kind === "comment").map((e) => { const w = whenTag(e.text);
    if (!w || (w.name && !names.includes(w.name))) return null;
    return {t: w.frame != null && cv[1].fps ? (w.frame + 0.5) / cv[1].fps : w.t, prev: e.v === pv.v}; }).filter(Boolean);
}
// The dedicated scrub rail for two videos: drag it and both seek together, 1:1 with the finger
// (a direct seek, no glide, so the frame follows the pointer exactly); ← → step one frame (Shift
// ten), Space plays. It shows both cuts' lengths and a tick per time-tagged comment.
function wireCmpRail(c, cv, marks, fps, vers) {
  const rail = document.getElementById("cmprail"); if (!rail) return;
  const [a, b] = c.querySelectorAll("video");
  const track = rail.querySelector(".cmptk"), fill = rail.querySelector(".fill"), ph = rail.querySelector(".ph");
  const ticks = rail.querySelector(".ticks"), da = rail.querySelector(".da"), db = rail.querySelector(".db");
  const dur = () => Number.isFinite(b.duration) && b.duration > 0 ? b.duration : 1;
  const put = () => { const f = Math.min(1, Math.max(0, b.currentTime / dur())) * 100;
    fill.style.width = f + "%"; ph.style.left = f + "%"; rail.setAttribute("aria-valuenow", Math.round(f)); };
  const meta = () => {
    if (db) db.textContent = `${vers.b} ${clock(dur(), true)}`;
    if (da) da.textContent = `${vers.a} ${Number.isFinite(a.duration) ? clock(a.duration, true) : "…"}`;
    ticks.innerHTML = marks.map((m) => `<i class="${m.prev ? "prev" : ""}" style="left:${(Math.min(1, Math.max(0, m.t / dur())) * 100).toFixed(2)}%"></i>`).join("");
    put();
  };
  b.readyState >= 1 ? meta() : b.addEventListener("loadedmetadata", meta, {once: true});
  a.readyState >= 1 || a.addEventListener("loadedmetadata", meta, {once: true});
  b.addEventListener("timeupdate", put); b.addEventListener("seeked", put);
  let scrub = false, wasPlaying = false;
  const seek = (x) => { const r = track.getBoundingClientRect(); b.currentTime = Math.min(1, Math.max(0, (x - r.left) / r.width)) * dur(); };
  track.addEventListener("pointerdown", (e) => { e.preventDefault(); track.setPointerCapture(e.pointerId);
    scrub = true; wasPlaying = !b.paused; b.pause(); seek(e.clientX); });
  track.addEventListener("pointermove", (e) => { if (scrub) seek(e.clientX); });
  const end = (e) => { if (!scrub) return; scrub = false; try { track.releasePointerCapture(e.pointerId); } catch {} if (wasPlaying) b.play().catch(() => {}); };
  track.addEventListener("pointerup", end); track.addEventListener("pointercancel", end);
  rail.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); b.pause();
      b.currentTime = stepTime(b.currentTime, fps, (e.key === "ArrowRight" ? 1 : -1) * (e.shiftKey ? 10 : 1), b.duration); }
    else if (e.key === " " || e.key === "Enter") { e.preventDefault(); b.paused ? b.play().catch(() => {}) : b.pause(); }
  });
}
// 지시 위치 겹쳐 보기: the previous version's pins over the newer frame in compare. Positioned in
// the newer element's contain-box (video or image), so a pin lands where it was left. On a video,
// only the pins around the current moment show. Green check = a later version claims it fixed.
function renderCmpOverlay(c, ov, fps) {
  const lay = c.querySelector(".cmpov"); if (!lay) return;
  if (!c.classList.contains("ov-on") || c.classList.contains("m-diff") || !ov.length) { lay.innerHTML = ""; return; }
  const bEl = c.querySelector(".b"), cr = c.getBoundingClientRect(), r = bEl.getBoundingClientRect();
  const vd = bEl.tagName === "VIDEO" ? bEl : null;
  const nw = vd ? vd.videoWidth : lay._nw, nh = vd ? vd.videoHeight : lay._nh;
  if (!nw || !nh || !r.width) { lay.innerHTML = ""; return; }
  const s = Math.min(r.width / nw, r.height / nh), w = nw * s, h = nh * s;
  const bx = r.left - cr.left + (r.width - w) / 2, by = r.top - cr.top + (r.height - h) / 2;
  const at = (o) => o.frame != null && fps ? (o.frame + 0.5) / fps : o.t;
  const near = (o) => !vd || o.t == null || Math.abs(at(o) - vd.currentTime) < 0.6;
  const pins = ov.filter((o) => o.x != null && near(o));
  // A region comment (w/h) shows its box, with the same tappable pin on its top-left corner.
  const px = (v, n) => (v * n / 100).toFixed(1);
  lay.innerHTML = pins.map((o, i) => (o.w != null ? `<i class="cmpbox ${o.fixed ? "fx" : "op"}" aria-hidden="true" style="left:${(bx + w * o.x / 100).toFixed(1)}px;top:${(by + h * o.y / 100).toFixed(1)}px;width:${px(o.w, w)}px;height:${px(o.h, h)}px"></i>` : "") + `<button class="cmpin ${o.fixed ? "fx" : "op"}" data-ov="${i}" style="left:${(bx + w * o.x / 100).toFixed(1)}px;top:${(by + h * o.y / 100).toFixed(1)}px" aria-label="${o.fixed ? tl("renderCmpOverlay.1") : tl("renderCmpOverlay.2")}">${o.fixed ? ic("check") : ""}</button>`).join("");
  lay.querySelectorAll("[data-ov]").forEach((el) => el.onclick = (e) => { e.stopPropagation();
    const o = pins[+el.dataset.ov]; toast((o.fixed ? tl("renderCmpOverlay.3") : "") + attOf(o.text).words, 4500); });
}
// A comment on the version on screen gets its moment as a button: tap to see that frame.
function noteText(e, shown, pics) {
  const {words, urls} = attOf(e.text), w = e.v === shown && whenTag(words);
  const att = urls.length ? `<span class="npics">${urls.map((u) => `<a href="${esc(u)}" target="_blank" rel="noopener"><img src="${esc(u)}" alt="${tl("noteText.1")}" loading="lazy"></a>`).join("")}</span>` : "";
  // A comment written in markdown (bold, code, a list) reads as it was meant; plain words stay
  // plain text. renderMarkdown builds DOM nodes, never parsing HTML, so this stays safe (C06).
  const md = (s) => typeof looksMarkdown === "function" && looksMarkdown(s) ? renderMarkdown(s.trim(), "md nmd").outerHTML : esc(s);
  // A box left on the picture: a chip that lights the box on the stage (hover/focus) and goes to it (tap).
  const rg = e.v === shown && regionOf(e) ? `<button class="lchip press" data-loc="${esc(e.id)}" title="${tl("loc.region_t")}">${ic("pin")}<span>${tl("loc.region")}</span></button> ` : "";
  // A quoted passage of the report: its own block above the words, a way back to that place.
  const qo = quoteOf(words);
  if (qo) return `<button class="qjump press" data-qj="${esc(qo.q)}" data-qn="${e.quote_n | 0}" title="${tl("pgq.jump_t")}">${esc(qo.q)}</button>` + (qo.to ? `<span class="qto">${esc(qo.to)}</span>` : "") + md(qo.rest) + att;
  if (!w || !pics.some((f) => f.kind === "video")) return rg + md(words) + att;
  const span = w.t2 != null || w.frame2 != null;
  return `<button class="tjump press num${span ? " span" : ""}" data-jn="${esc(w.name)}" data-jt="${w.t}" data-jf="${w.frame ?? ""}"${span ? tl("noteText.2", {p0: w.t2 ?? "", p1: w.frame2 ?? ""}) : ""}>${span ? ic("loop") : ""}${esc(w.tag.trim())}</button> ${md(words.slice(w.tag.length))}` + att;
}
document.addEventListener("click", (e) => { const b = e.target.closest?.(".tjump"); if (!b || !openItem || !stageGo) return;
  const pics = openItem.pics, byName = pics.findIndex((f) => f.name === b.dataset.jn && f.kind === "video");
  const at = byName >= 0 ? byName : pics[stageAt]?.kind === "video" ? stageAt : pics.findIndex((f) => f.kind === "video"); if (at < 0) return;
  stageGo(at); const vd = stageVideo(), f = pics[at]; if (!vd) return;
  const a = f.fps && b.dataset.jf !== "" ? (+b.dataset.jf + 0.5) / f.fps : +b.dataset.jt;
  // A range chip goes round its stretch, as I and O would have set it; a single moment just stops there.
  const e2 = b.dataset.jf2 ?? "", t2 = b.dataset.jt2 ?? "", end = f.fps && e2 !== "" ? (+e2 + 1) / f.fps : t2 !== "" ? +t2 : null;
  vd.pause(); vd.currentTime = a;
  if (end != null && end > a) { loops[abKey()] = {a, b: end}; toast(tl("noteText.3", {abTxt: abTxt(loops[abKey()], f)})); playNow(vd); }
  const st = document.getElementById("stage"); if (st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); });
// A comment with a box: hovering or focusing its row lights the box on the stage; a tap on the
// chip keeps it lit and brings the stage (and the right file) into view.
document.addEventListener("click", (e) => { const b = e.target.closest?.(".lchip"); if (!b || !openItem) return;
  e.stopPropagation(); lightLoc(locHl === b.dataset.loc && locHlKeep ? null : b.dataset.loc, true); });
const locRow = (e) => e.target.closest?.(".row.note")?.querySelector(".lchip");
document.addEventListener("pointerover", (e) => { const c = locRow(e); if (c && !locHlKeep && locHl !== c.dataset.loc) lightLoc(c.dataset.loc); });
document.addEventListener("pointerout", (e) => { const c = locRow(e); if (c && !locHlKeep && !c.closest(".row").contains(e.relatedTarget)) lightLoc(null); });
document.addEventListener("focusin", (e) => { const c = locRow(e); if (c && !locHlKeep) lightLoc(c.dataset.loc); });
// ---- pin: a spot on the picture or frame, carried in the comment's tag as "위치(가로42%,세로60%)" (from the
// top left of the picture itself, not the black bars around it). Pins already left on the file
// on screen show as orange dots - on a video, only around the moment they were left at.
let pin = null, pinning = false, pinLabel = () => {};
function pinOf(text) {
  const m = /^\[([^\]]{1,200})\]/.exec(text || ""), w = m && m[1].split(/\s+/).find((x) => PIN_W.test(x)); if (!w) return null;
  const at = whenTag(text), r = boxOf(w);
  // A box's dot (compare overlay, old readers) sits at its middle, not its top-left corner.
  const [x, y] = r ? [Math.round((r.x + r.w / 2) * 100), Math.round((r.y + r.h / 2) * 100)] : w.match(/\d+/g).map(Number);
  return {x, y, r, name: at ? at.name : m[1].split(/\s+/).filter((q) => q && !PIN_W.test(q)).join(" "), t: at ? at.t : null, frame: at?.frame ?? null, text};
}
// A comment's box on the picture (0..1): the stored rect when the server kept one, else the
// box in its "위치(가로…,폭…,높이…)" tag. A plain spot (old pin) has none and stays a dot.
const okRect = (r) => r && [r.x, r.y, r.w, r.h].every(Number.isFinite) && r.w > 0 && r.h > 0 ? r : null;
const regionOf = (e) => e && (okRect(e.rect) || pinOf(e.text)?.r) || null;
// A box fitted inside the picture at 4 decimals, so x + w and y + h never pass 1.
function fitRect(r) {
  const q = (n) => Math.round(Math.min(1, Math.max(0, n)) * 1e4) / 1e4, x = q(r.x), y = q(r.y);
  const fit = (o, n) => { let s = Math.max(1e-4, Math.min(q(n), q(1 - o))); while (o + s > 1 && s > 1e-4) s = q(s - 1e-4); return s; };
  return {x, y, w: fit(x, r.w), h: fit(y, r.h)};
}
function pinOfE(e) {
  const q = pinOf(e.text); if (!q) return null;
  return {...q, id: e.id, r: okRect(e.rect) || q.r};
}
// The comment whose spot is lit on the stage (hover/focus on its row, or a tap on its chip).
let locHl = null, locHlKeep = false;
function lightLoc(id, keep) {
  locHl = id; locHlKeep = !!keep; drawPins();
  if (keep) { const q = (openItem?.pins || []).find((x) => x.id === id), at = q && q.name ? openItem.pics.findIndex((f) => f.name === q.name) : -1;
    if (at >= 0 && at !== stageAt && stageGo) stageGo(at);
    const st = document.getElementById("stage"); if (st && st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); }
}
function mediaBox(m) {
  const r = m.getBoundingClientRect(), nw = m.videoWidth || m.naturalWidth, nh = m.videoHeight || m.naturalHeight;
  if (!nw || !nh) return null;
  const s = Math.min(r.width / nw, r.height / nh), w = nw * s, h = nh * s;
  return {left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, w, h};
}
function drawPins() {
  const st = document.getElementById("stage"); if (!st || !openItem) return;
  let lay = st.querySelector(".pins");
  if (!lay) { lay = document.createElement("div"); lay.className = "pins"; st.appendChild(lay);
    // In pin mode a tap leaves a spot; on a still picture a drag draws a box instead (region
    // comment). The box follows the pointer 1:1 and is kept in 0..1 of the picture itself.
    let rg = null;
    const frac = (e, b) => [Math.min(1, Math.max(0, (e.clientX - b.left) / b.w)), Math.min(1, Math.max(0, (e.clientY - b.top) / b.h))];
    lay.addEventListener("pointermove", (e) => { if (!rg || e.pointerId !== rg.id) return;
      const [fx, fy] = frac(e, rg.b); rg.r = {x: Math.min(rg.x0, fx), y: Math.min(rg.y0, fy), w: Math.abs(fx - rg.x0), h: Math.abs(fy - rg.y0)};
      if (!rg.moved && Math.hypot(e.clientX - rg.cx, e.clientY - rg.cy) > 6) rg.moved = true;
      if (rg.moved) { pin = {x: Math.round((rg.r.x + rg.r.w / 2) * 100), y: Math.round((rg.r.y + rg.r.h / 2) * 100), at: stageAt, r: rg.r, live: true}; drawPins(); } });
    const rgEnd = (e) => { if (!rg || e.pointerId !== rg.id) return; const g = rg; rg = null;
      if (e.type === "pointercancel") { pin = null; drawPins(); pinLabel(); return; }
      if (g.moved && g.r && g.r.w * g.b.w >= 8 && g.r.h * g.b.h >= 8) { const r = g.r, q = (n) => Math.round(n * 10000) / 10000;
        pin = {x: Math.round((r.x + r.w / 2) * 100), y: Math.round((r.y + r.h / 2) * 100), at: stageAt, r: {x: q(r.x), y: q(r.y), w: q(r.w), h: q(r.h)}}; }
      else pin = {x: Math.round(g.x0 * 100), y: Math.round(g.y0 * 100), at: stageAt};
      pinning = false; drawPins(); pinLabel(); pinPlaced(); };
    lay.addEventListener("pointerup", rgEnd); lay.addEventListener("pointercancel", rgEnd);
    lay.addEventListener("pointerdown", (e) => {
      if (!pinning) { const p = e.target.closest?.(".pin.old,.rgn.old"); if (p) { e.stopPropagation(); toast(p.dataset.t, 4500); } return; }
      e.stopPropagation(); e.preventDefault();
      const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = m && mediaBox(m); if (!b) return;
      const x = Math.round((e.clientX - b.left) / b.w * 100), y = Math.round((e.clientY - b.top) / b.h * 100);
      if (x < 0 || x > 100 || y < 0 || y > 100) return toast(tl("drawPins.1"));
      if (m.tagName === "IMG") { rg = {id: e.pointerId, b, x0: x / 100, y0: y / 100, cx: e.clientX, cy: e.clientY, moved: false};
        try { lay.setPointerCapture(e.pointerId); } catch {} return; }
      pin = {x, y, at: stageAt}; pinning = false; drawPins(); pinLabel(); pinPlaced(); });
    new ResizeObserver(() => drawPins()).observe(st); }
  st.classList.toggle("pinning", pinning);
  const f = openItem.pics[stageAt], m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = m && mediaBox(m);
  if (!b) { lay.innerHTML = ""; m?.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", drawPins, {once: true}); return; }
  const sr = st.getBoundingClientRect(), vd = m.tagName === "VIDEO" ? m : null;
  const when = (q) => f.fps && q.frame != null ? (q.frame + 0.5) / f.fps : q.t;
  const near = (q) => !vd || when(q) == null || Math.abs(when(q) - vd.currentTime) < 0.6;
  const mine = (openItem.pins || []).filter((q) => (q.name ? q.name === f.name : openItem.pics.length === 1) && near(q));
  const L = (x) => (b.left - sr.left + b.w * x).toFixed(1), T = (y) => (b.top - sr.top + b.h * y).toFixed(1);
  const tip = (title) => title ? ` title="${esc(title)}" data-t="${esc(title.replace(/^\[[^\]]*\]\s*/, ""))}"` : "";
  const dot = (x, y, cls, title = "") => `<span class="pin ${cls}" style="left:${L(x / 100)}px;top:${T(y / 100)}px"${tip(title)}></span>`;
  const box = (r, cls, title = "") => `<span class="rgn ${cls}" style="left:${L(r.x)}px;top:${T(r.y)}px;width:${(b.w * r.w).toFixed(1)}px;height:${(b.h * r.h).toFixed(1)}px"${tip(title)}></span>`;
  drawGuide();
  lay.classList.toggle("lit", !!locHl && mine.some((q) => q.id === locHl));
  lay.innerHTML = mine.map((q) => { const c = (q.prev ? "old prev" : "old") + (q.id && q.id === locHl ? " hl" : "");
      return q.r ? box(q.r, c, q.text) : dot(q.x, q.y, c, q.text); }).join("")
    + (pin && pin.at === stageAt ? (pin.r ? box(pin.r, "new" + (pin.live ? " live" : "")) : dot(pin.x, pin.y, "new")) : "");
}
// After a spot or box is placed: open the composer so the note can be written and sent.
function pinPlaced() {
  // A pin belongs to a comment: opening it from the stage (composer still closed) opens the
  // composer so the note can be written and sent, then focuses/scrolls to it as usual.
  cmShow();
  // PC: straight into the box. Phone: bring the box back up without raising the keyboard.
  if (wide()) document.getElementById("cm")?.focus({preventScroll: true});
  else if (document.querySelector(".cbox")?.closest(".mounted")) setTimeout(() => document.querySelector(".cbox")?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}), 250);
}
// ---- F (or 비율): where a 9:16, 4:5 or 1:1 cut of the picture would fall, the rest dimmed.
// The stage's backdrop: black by default, or graphite / white / a checkerboard to judge edges and
// transparency against (the hub's viewer backgrounds, R10). Remembered on this device.
const STAGE_BGS = ["black", "graphite", "white", "checker"];
let stageBg = "black"; try { stageBg = STAGE_BGS.includes(localStorage.getItem("v2-stagebg")) ? localStorage.getItem("v2-stagebg") : "black"; } catch {}
function stageBgLabel() { const b = document.querySelector(".sbar .sbgb"); if (!b) return;
  b.querySelector("span").textContent = [tl("stageBg.1"), tl("stageBg.2"), tl("stageBg.3"), tl("stageBg.4")][STAGE_BGS.indexOf(stageBg)]; b.dataset.bg = stageBg; }
function nextStageBg() { stageBg = STAGE_BGS[(STAGE_BGS.indexOf(stageBg) + 1) % STAGE_BGS.length];
  try { localStorage.setItem("v2-stagebg", stageBg); } catch {}
  const st = document.getElementById("stage"); if (st) st.dataset.bg = stageBg; stageBgLabel(); }
// On 9:16 a dashed line also marks what the Shorts / Reels buttons and caption cover.
const GUIDES = ["", "9:16", "4:5", "1:1"];
let guide = ""; try { guide = localStorage.getItem("v2-guide") || ""; } catch {}
function nextGuide() { guide = GUIDES[(GUIDES.indexOf(guide) + 1) % GUIDES.length];
  try { localStorage.setItem("v2-guide", guide); } catch {}
  drawGuide(); toast(guide ? tl("nextGuide.1", {guide}) : tl("nextGuide.2")); }
function drawGuide() {
  const st = document.getElementById("stage"); if (!st) return;
  const btn = document.querySelector(".sbar .sguide"); if (btn) { btn.textContent = guide || tl("itemView.51"); btn.classList.toggle("on", !!guide); btn.setAttribute("aria-pressed", String(!!guide)); }
  let lay = st.querySelector(".guide"); const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = guide && m && mediaBox(m);
  if (!b) { lay?.remove(); return; }
  if (!lay) { lay = document.createElement("div"); lay.className = "guide"; lay.setAttribute("aria-hidden", "true"); st.appendChild(lay); }
  const [aw, ah] = guide.split(":").map(Number), sr = st.getBoundingClientRect();
  const h = Math.min(b.h, b.w * ah / aw), w = h * aw / ah;
  Object.assign(lay.style, {left: `${b.left - sr.left}px`, top: `${b.top - sr.top}px`, width: `${b.w}px`, height: `${b.h}px`});
  lay.innerHTML = `<i style="left:${(b.w - w) / 2}px;top:${(b.h - h) / 2}px;width:${w}px;height:${h}px">${guide === "9:16" ? "<u></u>" : ""}<b class="num">${guide}</b></i>`;
}
// The line under the comment box says which moment goes with the words, as it moves.
function cmWhen() {
  const el = document.getElementById("cmwhen"), vd = stageVideo(); if (!el || !vd) return;
  const r = abOf(vd), w = momentOf(vd, openItem?.pics[stageAt]);
  el.innerHTML = (w ? `<b class="num">${w}</b> ${tl("cmWhen.3", {p1: r ? tl("cmWhen.1") : tl("cmWhen.2")})}` : tl("cmWhen.4")) + (r ? "" : tl("cmWhen.5"));
}
// With an I-O loop set, a comment is about the whole stretch (Frame.io's range comment), not one frame.
const momentOf = (vd, f) => { const r = abOf(vd); return r ? spanWhen(r.a, r.b, f?.fps) : whenOf(vd, f); };
// "[file 0:05 f120]": where a video comment points, in words the department can read.
// Before anything is shown there is no moment; once a frame is up, 0:00 is one (a black first frame).
const whenOf = (vd, f) => !vd || (vd.currentTime <= 0 && vd.readyState < 2) ? "" : [clock(vd.currentTime), f?.fps ? `f${frameOf(vd.currentTime, f.fps)}` : ""].filter(Boolean).join(" ");
// ---- scene strip: stills pulled from the video in the browser (nothing is stored), one per
// shot when the version has a cut list, else ten across the length. Tap one to go there.
const stripCache = new Map();
let stripOn = false; try { stripOn = localStorage.getItem("strip") === "1"; } catch {}
async function stills(src, times) {
  const key = src + "|" + times.join(); if (stripCache.has(key)) return stripCache.get(key);
  const vd = Object.assign(document.createElement("video"), {muted: true, preload: "auto", src});
  const out = [];
  try {
    await new Promise((ok, no) => { vd.onloadeddata = ok; vd.onerror = no; });
    for (const t of times) {
      await new Promise((ok) => { vd.onseeked = ok; vd.currentTime = Math.min(t, vd.duration - 0.01); });
      const c = document.createElement("canvas"), w = 192; c.width = w; c.height = Math.round(w * vd.videoHeight / vd.videoWidth) || 108;
      c.getContext("2d").drawImage(vd, 0, 0, c.width, c.height); out.push(c.toDataURL("image/jpeg", 0.8));
    }
  } catch { return []; } finally { vd.removeAttribute("src"); vd.load(); }
  stripCache.set(key, out); return out;
}
// A file of a past version whose bytes were not kept when the file changed later: what shows
// may be the newer file, so it says so (short label, the why in the tooltip).
// A file whose bytes are not there - overwritten after this version (the server answers 410) or a
// referenced original that is missing (404) - shows a calm note instead of a broken picture.
const goneOf = (f) => f && (f.removed ? "removed" : f.past_lost ? "lost" : f.ref_state === "missing" ? "missing" : "");
const goneHtml = (f) => goneOf(f) === "removed"
  ? `<div class="sgone" role="note"><b>${tl("res.goneT")}</b><span>${tl("res.goneD")}</span></div>`
  : goneOf(f) === "lost"
  ? `<div class="sgone" role="note"><b>${tl("pastLost.1")}</b><span>${tl("pastLost.t")}</span></div>`
  : `<div class="sgone" role="note"><b>${tl("refMissing.1")}</b><span>${tl("refMissing.t")}</span></div>`;
const lostTag = (f) => f && f.past_lost ?`<em class="plost" title="${tl("pastLost.t")}">${tl("pastLost.1")}</em>` : "";
function wireStage(pics, shots) {
  const st = document.getElementById("stage");
  stageZoom = null;
  if (!st) return null;
  const tr = st.querySelector(".strk"), W = () => st.clientWidth, bar = st.nextElementSibling;
  let x = 0, stop = null, drag = null;
  const put = (v) => { x = v; tr.style.transform = `translate3d(${v}px,0,0)`; };
  const label = () => { bar.querySelector(".sname").innerHTML = esc(pics[stageAt].name) + lostTag(pics[stageAt]); bar.querySelector(".scount").textContent = pics.length > 1 ? `${stageAt + 1} / ${pics.length}` : "";
    // A video pushed with no sound track says so, so a silent cut is not mistaken for a muted player.
    bar.querySelector(".smute").hidden = !(pics[stageAt].kind === "video" && pics[stageAt].audio === false);
    document.querySelectorAll("#sgrid .sg").forEach((g) => g.classList.toggle("on", +g.dataset.sg === stageAt)); sgShow();
    st.querySelector(".snav.l")?.classList.toggle("off", stageAt === 0); st.querySelector(".snav.r")?.classList.toggle("off", stageAt === pics.length - 1); tgtLabel(); stageFit?.(); readout(); flipBadge(); };
  // Frame stepping, the old review page's player the user asked to keep: the readout
  // follows the video on the stage, the buttons (and ← →) move one frame.
  const fs = bar.querySelector(".fstep");
  const readout = () => { const vd = stageVideo(), f = pics[stageAt]; fs.hidden = !vd;
    drawStrip(); drawMarks(); cmWhen(); drawPins(); showPlay(fs, vd);
    // Leave the readout alone while a frame is being typed into it (an open input lives here).
    if (vd && !fs.querySelector(".fnow input")) fs.querySelector(".fnow").textContent = (f.fps ? `f${frameOf(vd.currentTime, f.fps)}${f.frames ? " / " + (f.frames - 1) : ""}` : clock(vd.currentTime, true))
      + (abOf(vd) ? tl("wireStage.1", {abTxt: abTxt(abOf(vd), f)}) : ""); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked", "loadedmetadata"].forEach((ev) => vd.addEventListener(ev, readout)));
  // Buffering spinner, same pattern as the viewer's .vspin.
  tr.querySelectorAll("video").forEach((vd) => { const sp = vd.nextElementSibling;
    ["waiting", "stalled"].forEach((ev) => vd.addEventListener(ev, () => { sp.hidden = false; }));
    ["playing", "canplay", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { sp.hidden = true; })); });
  // I and O set a stretch to go round while checking one move; X lets the whole run again.
  tr.querySelectorAll("video").forEach((vd) => vd.addEventListener("timeupdate", () => { const r = abOf(vd);
    if (r && !vd.paused && (vd.currentTime >= r.b || vd.currentTime < r.a - 0.05)) vd.currentTime = r.a; }));
  // Press and hold the step buttons to run through frames, faster the longer it is held; a tap is
  // one frame, and letting go stops on whatever frame it reached (stepFrame always lands on one).
  fs.querySelectorAll("[data-fs]").forEach((b) => holdStep(b, +b.dataset.fs));
  // The readout doubles as a jump box: tap it, type a frame (120 / f120), a clock (1:23) or 3.5s.
  fnowJump(fs.querySelector(".fnow"), () => pics[stageAt], readout);
  fs.querySelector(".frate").onclick = nextRate;
  bar.querySelector(".sguide").onclick = nextGuide;
  bar.querySelector(".sbgb").onclick = nextStageBg; stageBgLabel();
  // A big play button beside the frame steps: on a phone the video's own is two taps and small.
  const fp = fs.querySelector(".fplay"), playState = () => showPlay(fs, stageVideo());
  fp.onclick = () => { const vd = stageVideo(); if (!vd) return; vd.paused ? playNow(vd) : vd.pause(); };
  tr.querySelectorAll("video").forEach((vd) => ["play", "pause"].forEach((ev) => vd.addEventListener(ev, playState)));
  const strip = document.getElementById("fstrip"), scn = fs.querySelector(".fscn");
  let stripFor = null, marks = [];
  const drawStrip = async () => { const vd = stageVideo(), f = pics[stageAt];
    scn.classList.toggle("on", stripOn); scn.setAttribute("aria-pressed", String(stripOn));
    strip.hidden = !stripOn || !vd; if (strip.hidden || stripFor === f.url) return;
    stripFor = f.url; strip.innerHTML = loadingHtml(tl("wireStage.2"));
    if (!(vd.duration > 0)) await new Promise((ok) => vd.addEventListener("loadedmetadata", ok, {once: true}));
    marks = shots?.length ? shots.slice(0, 40).map((x) => x.start) : Array.from({length: 10}, (_, i) => vd.duration * (i + 0.05) / 10);
    const pics2 = await stills(f.play || f.url, marks);
    if (stripFor !== f.url) return;
    strip.innerHTML = pics2.length ? pics2.map((u, i) => `<button class="press" data-at="${i}" aria-label="${tl("wireStage.3", {clock: clock(marks[i])})}"><img src="${u}" alt=""><span class="num">${shots?.length ? "#" + shots[i].n : f.fps ? "f" + frameOf(marks[i], f.fps) : clock(marks[i], vd.duration < 20)}</span></button>`).join("")
      : `<span class="sub">${tl("wireStage.4")}</span>`;
    strip.querySelectorAll("[data-at]").forEach((b) => b.onclick = () => { const v2 = stageVideo(); if (!v2) return; v2.currentTime = marks[+b.dataset.at] + 0.001; });
    markStrip(); };
  // The scrub bar under the video: a hairline track with a played fill, the A-B loop range, a dot
  // per comment, and a playhead. Drag it (mouse or finger) to scrub 1:1, or grab a dot to a comment.
  const rail = document.getElementById("cmk");
  let railFor = null, tip = null;
  const seekTo = (clientX) => { const vd = stageVideo(); if (!vd || !(vd.duration > 0)) return;
    const r = rail.getBoundingClientRect(), p = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    vd.pause(); vd.currentTime = p * vd.duration; };
  const showTip = (clientX) => { const vd = stageVideo(), f = pics[stageAt]; if (!vd || !(vd.duration > 0)) return;
    if (!tip) { tip = document.createElement("div"); tip.className = "cmktip num"; document.body.appendChild(tip); }
    const r = rail.getBoundingClientRect(), p = Math.min(1, Math.max(0, (clientX - r.left) / r.width)), t = p * vd.duration;
    tip.textContent = f.fps ? `f${frameOf(t, f.fps)}` : clock(t, true);
    tip.style.left = Math.min(r.right, Math.max(r.left, clientX)) + "px"; tip.style.top = r.top + "px"; tip.hidden = false; };
  const hideTip = () => { if (tip) tip.hidden = true; };
  let scrub = null, wasPlaying = false;
  const hoverPC = matchMedia("(hover: hover)").matches;
  rail.addEventListener("pointerdown", (e) => { if (e.button || e.target.closest("button")) return;
    const vd = stageVideo(); if (!vd || !(vd.duration > 0)) return;
    e.preventDefault(); rail.setPointerCapture(e.pointerId); scrub = e.pointerId; wasPlaying = !vd.paused;
    seekTo(e.clientX); showTip(e.clientX); });
  rail.addEventListener("pointermove", (e) => { if (scrub === e.pointerId) { seekTo(e.clientX); showTip(e.clientX); }
    else if (scrub == null && hoverPC) showTip(e.clientX); });
  const endScrub = (e) => { if (scrub !== e.pointerId) return; scrub = null; hideTip();
    try { rail.releasePointerCapture(e.pointerId); } catch {}
    if (wasPlaying) { const vd = stageVideo(); if (vd) playNow(vd); } };
  rail.addEventListener("pointerup", endScrub);
  rail.addEventListener("pointercancel", endScrub);
  rail.addEventListener("pointerleave", () => { if (scrub == null) hideTip(); });
  const drawMarks = () => { const vd = stageVideo(), f = pics[stageAt];
    if (!vd) { rail.hidden = true; railFor = null; hideTip(); return; }
    const ms = (openItem?.marks || []).filter((m) => m.name ? m.name === f.name : pics.filter((g) => g.kind === "video").length === 1);
    rail.hidden = false;
    if (!(vd.duration > 0)) return vd.addEventListener("loadedmetadata", drawMarks, {once: true});
    const key = f.url + "|" + ms.length;
    if (railFor !== key) { railFor = key;
      // Marks on the same moment share one dot: two dots on one spot left the lower one unreachable.
      const spots = new Map();
      ms.forEach((m) => { const t = f.fps && m.frame != null ? (m.frame + 0.5) / f.fps : m.t, k = Math.min(100, t / vd.duration * 100).toFixed(2);
        const s = spots.get(k) || {t, k, prev: true, texts: []}; s.prev = s.prev && !!m.prev; s.texts.push(attOf(m.text).words.slice(m.tag.length, 120).trim() || tl("itemView.107")); spots.set(k, s); });
      rail.innerHTML = `<u class="cmkfill"></u><b class="cmkab" hidden></b>` + [...spots.values()].map((s) =>
        `<button class="press${s.prev ? " prev" : ""}" style="left:${s.k}%" data-mt="${s.t}" title="${esc(s.texts.join(" · "))}" aria-label="${tl("wireStage.5", {clock: clock(s.t)})}"></button>`).join("") + `<i></i>`;
      rail.querySelectorAll("[data-mt]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const v2 = stageVideo(); if (!v2) return; v2.currentTime = +b.dataset.mt; if (b.title) toast(b.title, 4500); }); }
    const pct = Math.min(100, vd.currentTime / vd.duration * 100);
    rail.querySelector("i").style.left = pct + "%"; rail.querySelector(".cmkfill").style.width = pct + "%";
    const r = abOf(vd), abEl = rail.querySelector(".cmkab");
    if (r) { abEl.hidden = false; abEl.style.left = (r.a / vd.duration * 100) + "%"; abEl.style.width = ((r.b - r.a) / vd.duration * 100) + "%"; }
    else abEl.hidden = true; };
  // The still for the moment on screen is outlined, so the strip doubles as a map.
  const markStrip = () => { const vd = stageVideo(); if (!vd || strip.hidden) return; let on = -1; marks.forEach((t, i) => { if (vd.currentTime + 0.01 >= t) on = i; });
    strip.querySelectorAll("[data-at]").forEach((b) => b.classList.toggle("on", +b.dataset.at === on)); };
  scn.onclick = () => { stripOn = !stripOn; try { localStorage.setItem("strip", stripOn ? "1" : "0"); } catch {} drawStrip(); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, markStrip)));
  // Buttons, keys and the grid cut straight to the other result - "슬라이드 빼줘, 바로바로 비교하게".
  // Only a finger that let go mid-drag springs the rest of the way, carrying its speed.
  // ---- zoom of the result on the stage (mouse): its own scale, apart from the app's screen size.
  // Same model as the full-screen viewer: scale and offset from the resting centre, the spot under
  // the pointer stays put, a drag pans 1:1 and keeps its speed on release. s = 1 is "fit"; the
  // number shown is the picture's real size (100% = one picture pixel per screen pixel).
  const zc = st.querySelector(".szoom"), zmouse = matchMedia("(hover:hover) and (pointer:fine)").matches;
  let z = {s: 1, tx: 0, ty: 0}, stopZ = null, pan = null, tapT = 0, lastUp = 0;
  const zm = () => st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video") || null;
  const zfit = () => { const m = zm(), nw = m && (m.videoWidth || m.naturalWidth), nh = m && (m.videoHeight || m.naturalHeight);
    if (!nw || !nh) return null; const f = Math.min(W() / nw, st.clientHeight / nh); return {w: nw * f, h: nh * f, f}; };
  const zmax = () => { const b = zfit(); return Math.max(8, b ? 4 / b.f : 8); };
  const zb = (s) => { const b = zfit(); return b ? {x: Math.max(0, (b.w * s - W()) / 2), y: Math.max(0, (b.h * s - st.clientHeight) / 2)} : {x: 0, y: 0}; };
  const zon = () => z.s > 1.005;
  const zpaint = () => { const m = zm(), b = zfit();
    if (m) m.style.transform = zon() || z.tx || z.ty ? `translate3d(${z.tx}px,${z.ty}px,0) scale(${z.s})` : "";
    st.classList.toggle("zoomed", zon());
    if (!b && m) m.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", zpaint, {once: true});
    zc.querySelector(".zpct").textContent = b ? `${Math.round(z.s * b.f * 100)}%` : "";
    zc.querySelector('[data-z="-1"]').disabled = zc.querySelector('[data-z="0"]').disabled = !zon();
    zc.querySelector('[data-z="1"]').disabled = z.s >= zmax() - 0.001;
    if (zon() || st.querySelector(".pins,.guide")) { drawPins(); drawGuide(); } };
  const zto = (s, tx, ty, now) => { stopZ && stopZ(); stopZ = null; s = Math.max(1, Math.min(zmax(), s));
    const b = zb(s), to = s <= 1.005 ? {s: 1, tx: 0, ty: 0} : {s, tx: Math.max(-b.x, Math.min(b.x, tx)), ty: Math.max(-b.y, Math.min(b.y, ty))}, from = {...z};
    if (now || RM()) { z = to; return zpaint(); }
    let t = 0; stopZ = springTo(() => t, (v) => { t = v; z = {s: from.s + (to.s - from.s) * v, tx: from.tx + (to.tx - from.tx) * v, ty: from.ty + (to.ty - from.ty) * v}; zpaint(); }, 1, 0, () => { z = to; zpaint(); }, 0.3, 1); };
  // Zoom about a screen point (default: the middle of the stage).
  const zat = (s, px, py, now) => { const r = st.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    s = Math.max(1, Math.min(zmax(), s)); if (px == null) { px = cx; py = cy; }
    zto(s, (px - cx) - ((px - cx) - z.tx) / z.s * s, (py - cy) - ((py - cy) - z.ty) / z.s * s, now); };
  const zreset = () => { stopZ && stopZ(); stopZ = null; const m = zm(); if (m) m.style.transform = ""; z = {s: 1, tx: 0, ty: 0}; };
  // Fit <-> the real size at that spot (a picture already shown at its real size or bigger goes to 2.5x).
  const ztoggle = (px, py) => { const b = zfit(); if (!b) return; zon() ? zto(1, 0, 0) : zat(b.f < 0.98 ? 1 / b.f : 2.5, px, py); };
  stageZoom = {step: (d) => zat(z.s * (d > 0 ? 1.25 : 0.8)), fit: (now) => zto(1, 0, 0, now)};
  zc.querySelectorAll("[data-z]").forEach((b) => b.onclick = () => { const d = +b.dataset.z, f = zfit();
    if (d === 100) { if (f) zat(Math.max(1, 1 / f.f)); } else if (d) stageZoom.step(d); else stageZoom.fit(); });
  st.addEventListener("wheel", (e) => { if (!e.altKey || e.ctrlKey || !zfit() || drawing) return; e.preventDefault();
    zat(z.s * Math.exp(-e.deltaY * 0.0015), e.clientX, e.clientY, true); }, {passive: false});
  st.addEventListener("pointerdown", (e) => {
    if (!zon() || e.button || e.target.closest("button,.pins") || drawing) return;
    stopZ && stopZ(); stopZ = null;
    pan = {id: e.pointerId, x0: e.clientX, y0: e.clientY, z0: {...z}, moved: false, h: [[e.clientX, e.clientY, e.timeStamp]]};
  });
  st.addEventListener("pointermove", (e) => {
    if (!pan || e.pointerId !== pan.id) return;
    const dx = e.clientX - pan.x0, dy = e.clientY - pan.y0;
    if (!pan.moved) { if (Math.hypot(dx, dy) < 4) return; pan.moved = true; st.setPointerCapture(e.pointerId); st.classList.add("panning"); }
    const b = zb(z.s), H = st.clientHeight; let tx = pan.z0.tx + dx, ty = pan.z0.ty + dy;
    if (tx > b.x) tx = b.x + rubber(tx - b.x, W()); else if (tx < -b.x) tx = -b.x - rubber(-b.x - tx, W());
    if (ty > b.y) ty = b.y + rubber(ty - b.y, H); else if (ty < -b.y) ty = -b.y - rubber(-b.y - ty, H);
    z = {...z, tx, ty}; zpaint();
    pan.h.push([e.clientX, e.clientY, e.timeStamp]); if (pan.h.length > 5) pan.h.shift();
  });
  const panEnd = (e) => {
    if (!pan || e.pointerId !== pan.id) return; const p = pan; pan = null; st.classList.remove("panning");
    if (!p.moved) {                                         // a click while zoomed: twice goes back to fit
      if (e.type === "pointerup" && e.timeStamp - lastUp < 350) { lastUp = 0; zto(1, 0, 0); } else lastUp = e.timeStamp;
      return; }
    const a = p.h[0], c = p.h[p.h.length - 1], dt = Math.max(1, c[2] - a[2]), t = 0.35;
    zto(z.s, z.tx + (c[0] - a[0]) / dt * 1000 * t / 2, z.ty + (c[1] - a[1]) / dt * 1000 * t / 2);
  };
  st.addEventListener("pointerup", panEnd); st.addEventListener("pointercancel", panEnd);
  const go = (n, v0 = 0, now = false, glide = false) => {
    n = Math.max(0, Math.min(pics.length - 1, n));
    const moved = n !== stageAt;
    if (moved || now) zreset();              // another file, or the stage changed size: back to fit
    if (moved) tr.querySelectorAll("video").forEach((vd) => vd.pause());
    stageAt = n; label(); zpaint(); stop && stop();
    if (moved) playNow(stageVideo());      // going through several results: each one starts on arrival
    if (now || RM() || !glide) return put(-n * W());
    stop = springTo(() => x, put, -n * W(), v0, null, 0.36, 1);
  };
  tr.querySelectorAll("video").forEach((vd) => { vd.playbackRate = rate; });
  fs.querySelector(".frate").textContent = `${rate}×`; fs.querySelector(".frate").classList.toggle("on", rate !== 1);
  put(-stageAt * W()); label(); zpaint();
  st.querySelector(".snav.l")?.addEventListener("click", () => go(stageAt - 1));
  st.querySelector(".snav.r")?.addEventListener("click", () => go(stageAt + 1));
  const sw = document.getElementById("sgw");
  if (sw) document.getElementById("sgt").onclick = () => {
    const o = !sw.classList.contains("open");
    sw.classList.toggle("open", o); sgOpen(o);
    const t = document.getElementById("sgt"); t.setAttribute("aria-expanded", o); t.querySelector("em").textContent = o ? tl("itemView.30") : tl("itemView.31");
    sgShow();
  };
  document.querySelectorAll("#sgrid .sg").forEach((g) => g.onclick = () => {
    go(+g.dataset.sg);
    if (st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"});
  });
  // Full screen picks the video up where the stage has it (moment and playing or not) and hands both back on close.
  st.querySelector(".sfull").onclick = () => { const sv = stageVideo(), at = stageAt;
    const from = sv ? {t: sv.currentTime, play: !sv.paused, back: (t, play) => { const v = stageAt === at && stageVideo(); if (!v) return; v.currentTime = t; if (play) playNow(v); }} : null;
    tr.querySelectorAll("video").forEach((vd) => vd.pause()); viewer(pics, stageAt, openItem, from); };
  // Pulling on past the first or last file steps a version: right to the older one, left to the
  // newer one, the same order as the compare bar (v010 → v011). A label says where it will land.
  const verTo = (over) => { const vs = openItem?.vers || [], i = vs.indexOf(openItem?.v); return over > 0 ? vs[i + 1] : i > 0 ? vs[i - 1] : null; };
  let hint = null;
  const pullHint = (over) => { const to = over && verTo(over), on = !!to && Math.abs(over) > W() * 0.3;
    if (!to) { hint?.remove(); hint = null; return; }
    if (!hint) { hint = document.createElement("div"); st.appendChild(hint); }
    hint.className = `vpull ${over > 0 ? "l" : "r"}${on ? " on" : ""}`; hint.textContent = on ? tl("vpull.1", {v: to}) : to; };
  st.addEventListener("pointerdown", (e) => {
    if (zon() || e.button || e.target.closest("button") || onControls(e) || (pics.length === 1 && e.target.closest("video"))) return;
    stop && stop();
    drag = {id: e.pointerId, x0: e.clientX, y0: e.clientY, s: x, dir: null, hist: [[e.clientX, e.timeStamp]], video: !!e.target.closest("video")};
  });
  st.addEventListener("pointermove", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
    if (!drag.dir) { if (Math.hypot(dx, dy) < 10) return; drag.dir = Math.abs(dx) > Math.abs(dy) ? "x" : "y"; if (drag.dir === "x") st.setPointerCapture(e.pointerId); }
    if (drag.dir !== "x") return;
    const min = -(pics.length - 1) * W();
    let nx = drag.s + dx;
    drag.over = nx > 0 ? nx : nx < min ? nx - min : 0; pullHint(drag.over);
    if (nx > 0) nx = rubber(nx, W()); else if (nx < min) nx = min + rubber(nx - min, W());
    put(nx); drag.hist.push([e.clientX, e.timeStamp]); if (drag.hist.length > 5) drag.hist.shift();
  });
  st.addEventListener("pointerup", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const d = drag; drag = null; pullHint(0);
    const to = d.dir === "x" && Math.abs(d.over || 0) > W() * 0.3 && verTo(d.over);
    if (to && openItem) { if (to === openItem.vers[0]) delete verPick[openItem.id]; else verPick[openItem.id] = to;
      stageAt = 0; toast(tl("vpull.2", {v: to})); again(); return; }
    if (d.dir === "x") { const a = d.hist[0], b = d.hist[d.hist.length - 1], v = b[1] > a[1] ? (b[0] - a[0]) / (b[1] - a[1]) * 1000 : 0;
      const n = Math.round(-(x + project(v)) / W());
      return go(Math.max(stageAt - 1, Math.min(stageAt + 1, n)), v, false, true); }
    // A tap on a picture opens it big. With a mouse a second click may follow (double-click =
    // fit <-> real size), so the first one waits a moment for it; a finger opens at once.
    if (!d.dir && !d.video) { const open = () => { tapT = 0; if (st.isConnected) viewer(pics, stageAt); };
      if (e.pointerType !== "mouse" || !zmouse) open();
      else if (tapT) { clearTimeout(tapT); tapT = 0; ztoggle(e.clientX, e.clientY); }
      else tapT = setTimeout(open, 240); }
    else if (d.dir === "y") go(stageAt, 0, false, true);
  });
  st.addEventListener("pointercancel", () => { pullHint(0); if (drag) { drag = null; go(stageAt, 0, false, true); } });
  return go;
}
// While a box is being typed in on a phone, the 승인/수정 요청 bar steps aside: with the
// keyboard up it otherwise covers most of what is left of the result.
// A box that is removed or hidden while it has the focus (the chat's back button, a list redrawn
// under the search field) sends no focusout, which left the tab bar hidden on the next screen:
// the class is read again from what has the focus (and is still drawn) on every screen change,
// when a chat closes (project.js phoneChat) and whenever the keyboard moves.
// The keyboard itself is measured too: a list redrawn under its search field drops the focus
// while the keys are still up, and the bar then sat on top of the keyboard, mid-screen.
const TYPES = "textarea, input, [contenteditable]:not([contenteditable=false])";
let kbFull = 0, kbWide = 0;
const kbUp = () => { const v = window.visualViewport; if (!v) return false;
  if (v.width !== kbWide) { kbWide = v.width; kbFull = 0; }
  kbFull = Math.max(kbFull, v.height);
  return kbFull - v.height > 150; };
const typingSync = () => { const a = document.activeElement;
  document.body.classList.toggle("typing", kbUp() || (!!a?.matches?.(TYPES) && a.getClientRects().length > 0)); };
addEventListener("focusin", (e) => { if (e.target.matches?.(TYPES)) document.body.classList.add("typing"); });
addEventListener("focusout", () => setTimeout(typingSync, 60));
addEventListener("hashchange", () => { setTimeout(typingSync, 0); setTimeout(typingSync, 400); });
addEventListener("pageshow", typingSync);
document.addEventListener("visibilitychange", typingSync);
visualViewport?.addEventListener("resize", () => setTimeout(typingSync, 60));
// A zoomed page must stay pinchable so it can be brought back (v2.css turns pinch off on app screens).
visualViewport?.addEventListener("resize", () => document.documentElement.classList.toggle("zoomed", visualViewport.scale > 1.01));
addEventListener("resize", () => { if ((detail?.[0] === "item" || wrLive()) && document.getElementById("stage")) stageGo?.(stageAt, 0, true); });
// Reading down a result on a phone, the decision bar steps out of the way; any move back up,
// the top or the end of the page brings it back.
{ let lastY = scrollY;
  addEventListener("scroll", () => {
    const y = scrollY, d = y - lastY;
    if (Math.abs(d) < 8) return; lastY = y;
    const hide = !wide() && detail?.[0] === "item" && d > 0 && y > 80 && y + innerHeight < document.documentElement.scrollHeight - 40;
    document.body.classList.toggle("ctahide", hide);
  }, {passive: true}); }
// Rows that scroll sideways (chips, tabs, strips) fade at the edge that has more, so a cut-off
// chip reads as "swipe for more" rather than as a clipped screen (user, 2026-09-29).
const EDGE_ROWS = ".chips,.settabs,.mtabs,.fstrip,.vtlstrip,.pinstrip,.tpics,.sgrid,.qpick,.uz-seg,.category-pill-group";
const edgeFade = (el) => { const max = el.scrollWidth - el.clientWidth;
  el.classList.toggle("efl", max > 2 && el.scrollLeft > 2); el.classList.toggle("efr", max > 2 && el.scrollLeft < max - 2); };
// A chip strip (filters, kinds, the received tabs) is rebuilt whole whenever its screen re-renders.
// Changing one filter should not throw the strip back to the start, so its scroll is kept per
// data-sk and restored when the new strip lands; and if the chosen chip ends up past the edge it is
// nudged just into view. Only horizontal scroll is touched, so the page never jumps.
const chipScroll = {}, chipSel = {};
const keepChip = (el) => { const k = el.dataset.sk; if (!k) return;
  const on = el.querySelector('.on,[aria-pressed="true"],[aria-selected="true"]');
  const idx = on ? [...el.children].indexOf(on) : -1, moved = chipSel[k] !== idx;
  if (chipScroll[k] != null) el.scrollLeft = chipScroll[k];   // keep where the reader left it
  // Only when a different chip was chosen do we pull it into view — an unrelated re-render
  // (zoom, a fresh push) must not drag the strip back to the selected chip.
  if (moved && on) { const er = el.getBoundingClientRect(), cr = on.getBoundingClientRect();
    if (cr.left < er.left + 8) el.scrollLeft -= er.left + 8 - cr.left;
    else if (cr.right > er.right - 8) el.scrollLeft += cr.right - er.right + 8; }
  chipSel[k] = idx; chipScroll[k] = el.scrollLeft; edgeFade(el); };
{ let raf = 0; const all = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => document.querySelectorAll(EDGE_ROWS).forEach(edgeFade)); };
  addEventListener("scroll", (e) => { const t = e.target; if (!t.matches?.(EDGE_ROWS)) return; edgeFade(t); if (t.dataset?.sk) chipScroll[t.dataset.sk] = t.scrollLeft; }, {capture: true, passive: true});
  addEventListener("resize", all);
  new MutationObserver((muts) => { all();
    for (const m of muts) for (const n of m.addedNodes) { if (n.nodeType !== 1) continue;
      if (n.dataset?.sk) keepChip(n); n.querySelectorAll?.("[data-sk]").forEach(keepChip); } }).observe(document.body, {childList: true, subtree: true}); }
// cmfold:begin
// The comment history starts folded: one line (the latest words) until the reader opens it.
// An opinion nobody has acted on yet (Astra's, last in the list) stays in sight, and `fresh`
// counts the ones that arrived since the last look. A single entry is never folded.
function cmFold(notes, open, seen) {
  const last = notes[notes.length - 1] || null, folded = !open && notes.length > 1;
  const keep = folded && last.kind === "astra" ? [last] : [];
  return {folded, keep, peek: folded && !keep.length ? last : null,
    fresh: folded && seen ? notes.filter((e) => e.kind === "astra" && e.at > seen).length : 0};
}
// cmfold:end
const cmOpen = () => lsGet("v2-cmopen") === "1";
const cmFull = new Set();                  // comments opened past three lines
let cmSeen = {id: "", at: ""}, cmFade = false;   // when this item's comments were last looked at; a fold just toggled
// Read once per visit to an item, then moved up to the newest entry, so "new" means since the last look.
function cmSeenOf(id, notes) {
  if (cmSeen.id === id) return cmSeen.at;
  let m = {}; try { m = JSON.parse(lsGet("v2-cmseen") || "{}") || {}; } catch {}
  cmSeen = {id, at: m[id] || ""};
  const last = notes[notes.length - 1];
  if (last) { delete m[id]; m[id] = last.at; const ks = Object.keys(m); ks.slice(0, Math.max(0, ks.length - 200)).forEach((k) => delete m[k]); lsSet("v2-cmseen", JSON.stringify(m)); }
  return cmSeen.at;
}
const logAll = {};                         // items whose whole comment log is open
const logF = {};                           // the 기록 filter chosen per item
// 버전 비교: the wipe, the two side by side, or the new one laid over the old (SyncSketch's
// ghosting) at a chosen strength. The way is kept per browser, the strength for the visit.
const CMPM = LT(() => ([["wipe", tl("CMPM.1")], ["side", tl("CMPM.2")], ["over", tl("CMPM.3")]]));
// "diff" is a fourth way, added only for two stills (see the cmp tab); it may sit in storage.
const cmpMode = (v) => { try { if (v === undefined) { const m = localStorage.getItem("v2-cmpm"); return (CMPM.some((c) => c[0] === m) || m === "diff") ? m : "wipe"; } localStorage.setItem("v2-cmpm", v); } catch { return "wipe"; } };
let cmpOp = 50, cmpThr = 24, cmpThrT = null;
// The compare workspace (cmpview.js): a compare-only screen over the app. `cvAuto` is the item whose
// timeline pick should open it as soon as the item has redrawn.
let cvAuto = null, cvScroll = 0;
function openCmpWorkspace(item, vs, a, b, backTo) {
  const [lo, hi] = [a, b].sort(), y = backTo == null ? scrollY : backTo;
  openCompareView({title: item?.title || "", a: lo, b: hi, onClose: () => scrollTo(0, y),
    versions: vs.map((w) => ({v: w.v, at: w.at, summary: w.summary, files: w.files || []}))});
}
// 고쳤다고 함 → check the fix: the version the ask was written on (left/top) against the version
// that claims the fix (right/bottom), opened at the ask's spot or moment, with the ask, what the
// fix says changed, and 맞아/아직 bound to this directive's revision and the fixed version.
function openFixVerify(x, d, vs, ctx) {
  const has = (v) => vs.some((w) => w.v === v);
  if (!has(x.v) || !has(x.fixed_in)) return toast(tl("fixv.nover"));
  const e0 = (d.log || []).find((q) => q.id === x.id) || {text: x.text};
  const e = {...e0, rect: x.rect || e0.rect, file: x.file || e0.file};   // the directive row carries both now
  const region = regionOf(e), w = whenTag(e.text), p = pinOf(e.text);
  const src = vs.find((q) => q.v === x.v), fixV = vs.find((q) => q.v === x.fixed_in);
  const file = e.file || (p && p.name) || (w && w.name) || "";
  const fps = ((src.files || []).find((f) => f.name === file) || {}).fps || e.fps;
  const at = w ? (fps && w.frame != null ? (w.frame + 0.5) / fps : w.t) : 0;
  const where = region ? tl("fixv.where_box") : w ? tl("fixv.where_at", {t: w.tag.replace(/^\[|\]\s*$/g, "").replace(/위치\([^)]*\)/, "").trim()}) : p ? tl("fixv.where_pin") : tl("fixv.where_none");
  // The change note is whatever the fix carried; the fixed version's summary otherwise.
  const note = x.fix_note || x.claim?.note || x.claim_note || fixV.summary || "";
  const text = attOf((e.text || x.text || "").replace(/^\[[^\]]*\]\s*/, "")).words.trim();
  let changed = false;
  const after = (ok) => { changed = true; toast(ok ? tl("verdict.1") : tl("itemView.100")); return true; };
  const conflict = (err, ok, why) => { if (!isConflict(err)) throw err;
    // Only the same claim may be decided again here; a re-claim in another version needs a reload.
    const b = err.body || {}, can = !!(b.conflict && !b.stale && (b.fixed_in ?? null) === (x.fixed_in ?? null));
    changed = true;
    return {html: conflictHtml(b, ctx.latestV, d.log), again: ok ? tl("conflict.ok") : tl("conflict.again"),
      retry: can ? () => ctx.sayDir(x.id, ok, b.directive_rev, why).then(() => after(ok), (e2) => conflict(e2, ok, why)) : null}; };
  openCompareView({title: d.title || "", a: x.v, b: x.fixed_in,
    versions: vs.map((q) => ({v: q.v, at: q.at, summary: q.summary, files: q.files || []})),
    onClose: async () => { if (changed) { await load(); again(); } },
    verify: {text, note, cycle: x.cycle, file, region, at, where,
      decide: (ok, why) => ctx.sayDir(x.id, ok, undefined, why).then(() => after(ok), (err) => conflict(err, ok, why)),
      reload: () => { changed = true; }}});
}
// The compare state as an address: cmp=<viewed>,<other>&m=<mode>[&t=<seconds>]. The id may hold
// spaces or Korean, so it is used raw (as the 링크 복사 row does) — the query rides after the first
// "?", which a name never contains. `t` is dropped near zero so a still-frame link stays clean.
function cmpHashStr(id, viewed, other, mode, t, thr) {
  let s = "#item/" + id + "?cmp=" + viewed + "," + other + "&m=" + mode;
  if (mode === "diff" && thr != null) s += "&thr=" + thr;
  if (t != null && t > 0.05) s += "&t=" + Math.round(t * 10) / 10;
  return s;
}
function setCmpHash(id, viewed, other, mode, t, thr) {
  const s = cmpHashStr(id, viewed, other, mode, t, thr);
  if (location.hash !== s) history.replaceState(null, "", s);
}
// Back to a plain item address when leaving compare: drop the ?cmp=… query the item hash carries.
function setItemHash(id) {
  if (location.hash.startsWith("#item/") && location.hash.includes("?")) history.replaceState(null, "", "#item/" + id);
}
const loadImg = (src) => new Promise((ok, no) => { const im = new Image(); im.crossOrigin = "anonymous"; im.onload = () => ok(im); im.onerror = no; im.src = src; });
// 차이 mode: draw both stills onto one grid, mark every pixel that moved. Same-origin media, so
// the canvas stays untainted; if a picture will not load (or taints), the readout says so and the
// other modes still work. onRatio gets the changed fraction, or null when it could not be computed.
async function renderCmpDiff(c, aUrl, bUrl, threshold, onRatio) {
  const cv = c?.querySelector(".cdiff"); if (!cv || !aUrl || !bUrl) return onRatio?.(null);
  try {
    const [ia, ib] = await Promise.all([loadImg(aUrl), loadImg(bUrl)]);
    if (!c.isConnected) return;
    const tw = Math.min(ib.naturalWidth || 1024, 1024) || 1024;
    const th = Math.max(1, Math.round(tw * (ib.naturalHeight || 1) / (ib.naturalWidth || 1)));
    const grab = (img) => { const o = document.createElement("canvas"); o.width = tw; o.height = th;
      const g = o.getContext("2d"); g.drawImage(img, 0, 0, tw, th); return g.getImageData(0, 0, tw, th).data; };
    const r = diffPixels(grab(ia), grab(ib), tw, th, {threshold});
    cv.width = tw; cv.height = th;
    cv.getContext("2d").putImageData(new ImageData(r.data, tw, th), 0, 0);
    onRatio?.(r.ratio);
  } catch { onRatio?.(null); }
}
// Every key on one sheet: the line under the result only fits the common few.
function keysSheet() {
  const K = [["← →", tl("keysSheet.1")], [", .", tl("keysSheet.2")], ["↑ ↓", tl("keysSheet.3")], ["PgUp PgDn", tl("itemView.84")], ["[", tl("keyHelp.2")], ["]", tl("keysSheet.23")], ["Space", tl("keysSheet.4")],
    ["Home End", tl("keysSheet.5")], ["0 – 9", tl("keysSheet.6")], ["Alt+1 ~ 5", tl("keysSheet.7")], ["M", tl("keysSheet.8")], ["I O", tl("keysSheet.9")], ["X", tl("keysSheet.10")], ["S", tl("itemView.47")], ["J K L", tl("keysSheet.11")], ["F", tl("keybar.focus")], ["T", tl("keysSheet.12")], ["H", tl("keysSheet.13")],
    ["C", tl("itemView.88")], ["P", tl("itemView.106")], ["Esc", tl("keysSheet.14")], ["D", tl("keysSheet.15")],
    ["\\", tl("keysSheet.16")], ["V", tl("keysSheet.17")], ["A", tl("keysSheet.18")], ["R", tl("cmt.1")],
    ["N", tl("nextCard.3")], ["Shift+N", tl("keybar.prev")], ["↑ ↓", tl("keysSheet.24")], ["1 2 3", tl("keysSheet.21")], ["Enter", tl("itemView.38")], ["+ − 0", tl("keysSheet.19")],
    ["W", tl("keybar.width")], ["B", tl("keybar.cmp")], ["Esc", tl("keybar.back")], ["?", tl("keybar.toggle")]];
  sheet(`<h3>${tl("keysSheet.20")}</h3><dl class="keysall">${K.map(([a, b]) => `<dt>${a.split(" ").map((x) => `<b>${x}</b>`).join(" ")}</dt><dd>${b}</dd>`).join("")}</dl>`, () => {});
}
// A result mounted somewhere other than its own page (the workroom's stage, the phone's result
// sheet): {el, id, key}. Redraws go there; leaving the room or closing the sheet drops it.
let stageMount = null;
const wrLive = () => !!(stageMount && stageMount.el.isConnected);
// A redraw of the open item is the same page: no entry animation (it would carry the docked box off with it).
// An open result asks after itself every 5s, so a new version or a session's answer shows without leaving
// the page. Not while a comment is being written, a drawing is on, a sheet is up or the video plays.
setInterval(async () => {
  if (document.hidden || FLOAT || detail?.[0] !== "item" || !itemSig.startsWith(detail[1] + "|")) return;
  const id = detail[1], [p, ...r] = id.split("/"), d = await itemDetail(p, r.join("/"));
  if (!d || detail?.[1] !== id || itemSigOf(id, d) === itemSig) return;
  const el = document.activeElement, v = stageVideo();
  if ((el?.matches?.("input,textarea") && el.value) || drawing || (v && !v.paused) || document.getElementById("sheet").classList.contains("on")) return;
  await load(); if (detail?.[1] === id) again();
}, 5000);
const again = () => { V().classList.add("still"); if (wrLive()) itemView(stageMount.id, stageMount.el); else if (detail?.[0] === "item") itemView(detail[1]); };
// 담당자/마감일 칩을 눌렀을 때 그 자리에서 입력창으로 바뀌는 편집 UI (§4.15). cmEdit의
// "클릭하면 그 자리가 입력창" 패턴을 그대로 따름 - 저장/취소는 again()으로 다시 그려서 닫음.
function wireImetaEdit(box, field, p, i, d) {
  const wrap = box.querySelector("#imeta");
  if (!wrap) return;
  const cur = field === "due" ? (d.meta?.due || "") : (d.meta?.assignee || "");
  const flabel = field === "due" ? tl("itemView.169") : tl("itemView.168");
  wrap.innerHTML = `<div class="imedbox">
    <input class="imedin" type="${field === "due" ? "date" : "text"}" value="${esc(cur)}"
      ${field === "assignee" ? `maxlength="80" placeholder="${flabel}"` : ""}
      aria-label="${flabel}">
    ${cur ? `<button class="btn sm weak press" data-imclear type="button">${tl("itemView.174")}</button>` : ""}
    <button class="btn sm press" data-imcx type="button">${tl("cmEdit.7")}</button>
    <button class="btn sm fill press" data-imok type="button">${tl("cmEdit.8")}</button></div>`;
  const inp = wrap.querySelector(".imedin");
  inp.focus();
  const save = async (clear) => {
    const body = {p, i, [field]: clear ? "" : (field === "due" ? inp.value : inp.value.trim())};
    try { const r = await post("/api/meta", body); d.meta = r.meta || {}; again(); }
    catch (e) { toast(e.message || tl("get.1")); }
  };
  wrap.querySelector("[data-imok]").onclick = () => save(false);
  wrap.querySelector("[data-imclear]")?.addEventListener("click", () => save(true));
  wrap.querySelector("[data-imcx]").onclick = () => again();
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") save(false);
    else if (e.key === "Escape") again(); });
}
// ---- \ (or the ⇄ button): the file on the stage swaps with the same file of the compared
// version, at the same moment, and back. The button says which version is showing.
function flipStage() {
  const it = openItem, sl = document.querySelectorAll("#stage .sl")[stageAt], m = sl?.querySelector("img,video"), f = it?.pics[stageAt];
  if (!m || !it.alt) return;
  const same = (w) => w.files.find((x) => x.name === f.name && x.kind === f.kind);
  // A file new in the chosen version's successor: fall back to the nearest older one that has it.
  let src0 = same(it.alt) ? it.alt : (it.olds || []).find(same), o = src0 && same(src0);
  if (!o && it.pics.length === 1) { src0 = it.alt; o = it.alt.files.find((x) => x.kind === f.kind); }
  if (!o && !sl.dataset.alt) return toast(tl("flipStage.1"));
  const on = !sl.dataset.alt, g = on ? o : f, src = f.kind === "video" ? g.play || g.url : g.url;
  if (on) sl.dataset.alt = src0.v; else delete sl.dataset.alt;
  if (m.tagName === "VIDEO") { const t = m.currentTime, play = !m.paused;
    m.addEventListener("loadedmetadata", () => { m.playbackRate = rate; m.currentTime = Math.min(t, m.duration || t); if (play) playNow(m); }, {once: true});
    m.src = src; }
  else m.src = src;
  flipBadge();
}
function flipBadge() {
  const b = document.querySelector("#stage .sflip"); if (!b) return;
  const alt = document.querySelectorAll("#stage .sl")[stageAt]?.dataset.alt;
  b.classList.toggle("on", !!alt); b.setAttribute("aria-pressed", String(!!alt));
  b.querySelector("span").textContent = alt ? tl("flipBadge.1", {alt}) : openItem?.alt?.v ? tl("flipBadge.0", {v: openItem.alt.v}) : "";
}
// ---- drawing: pen, arrow and box over the picture or the paused frame, kept in the picture's
// own 0-1 space, then burnt into the full-size picture and sent with the comment. D starts it,
// Enter (or D) finishes, Esc drops it.
let drawing = null, drawPic = null;
const INK = ["#ff3b30", "#ffd60a", "#32d7ff"];
function inkStroke(g, s, b) {
  const P2 = (p) => [b.x + p[0] * b.w, b.y + p[1] * b.h], lw = Math.max(3, b.w * 0.005);
  g.strokeStyle = g.fillStyle = s.c; g.lineWidth = lw; g.lineCap = g.lineJoin = "round"; g.beginPath();
  if (s.t === "pen") { s.p.forEach((p, n) => { const [x, y] = P2(p); n ? g.lineTo(x, y) : g.moveTo(x, y); });
    if (s.p.length === 1) { const [x, y] = P2(s.p[0]); g.lineTo(x + 0.1, y); } g.stroke(); return; }
  const [x0, y0] = P2(s.p[0]), [x1, y1] = P2(s.p[s.p.length - 1]);
  if (s.t === "rect") { g.strokeRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)); return; }
  if (s.t === "ellipse") { g.ellipse((x0 + x1) / 2, (y0 + y1) / 2, Math.abs(x1 - x0) / 2, Math.abs(y1 - y0) / 2, 0, 0, 2 * Math.PI); g.stroke(); return; }
  const a = Math.atan2(y1 - y0, x1 - x0), hl = Math.max(lw * 4, 14);
  g.moveTo(x0, y0); g.lineTo(x1 - hl * 0.6 * Math.cos(a), y1 - hl * 0.6 * Math.sin(a)); g.stroke();
  g.beginPath(); g.moveTo(x1, y1); g.lineTo(x1 - hl * Math.cos(a - 0.45), y1 - hl * Math.sin(a - 0.45)); g.lineTo(x1 - hl * Math.cos(a + 0.45), y1 - hl * Math.sin(a + 0.45)); g.closePath(); g.fill();
}
function startDraw() {
  const st = document.getElementById("stage"), m = st?.querySelectorAll(".sl")[stageAt]?.querySelector("img,video");
  if (!m || drawing) return;
  stageZoom?.fit(true);                      // the drawing layer is laid over the picture at rest
  if (m.tagName === "VIDEO") { m.pause(); if (m.readyState < 2) return toast(tl("startDraw.1")); }
  else if (!m.naturalWidth) return toast(tl("startDraw.2"));
  if (pinning) { pinning = false; drawPins(); pinLabel(); }
  const lay = document.createElement("div"); lay.className = "drawl";
  lay.innerHTML = `<canvas aria-label="${tl("startDraw.9")}"></canvas><div class="dtools" role="toolbar" aria-label="${tl("startDraw.10")}">
    ${[["pen", tl("startDraw.3")], ["arrow", tl("startDraw.4")], ["rect", tl("startDraw.5")], ["ellipse", tl("draw.tool.ellipse")]].map(([k, n]) => `<button class="press" data-dt="${k}" aria-label="${n}" title="${n}">${ic(k)}</button>`).join("")}<i></i>
    ${INK.map((c, n) => `<button class="press ink" data-dc="${c}" style="--c:${c}" aria-label="${[tl("startDraw.6"), tl("startDraw.7"), tl("startDraw.8")][n]}"></button>`).join("")}<i></i>
    <button class="press" data-dz aria-label="${tl("toggleFav.3")}" title="${tl("startDraw.11")}">${ic("undo")}</button>
    <button class="press" data-dclr aria-label="${tl("draw.clear")}" title="${tl("draw.clear")}">${ic("eraser")}</button><span class="grow"></span>
    <button class="press dq" data-dq>${tl("libDraw.22")}</button><button class="press dok" data-dk>${tl("startDraw.12")}</button></div>`;
  st.appendChild(lay); st.classList.add("drawing");
  const cv = lay.querySelector("canvas"), g = cv.getContext("2d");
  const box = () => { const r = st.getBoundingClientRect(), b = mediaBox(m); return b && {x: b.left - r.left, y: b.top - r.top, w: b.w, h: b.h}; };
  const d = drawing = {m, at: stageAt, t: "pen", c: INK[0], strokes: [], lay};
  const paint = () => { const k = devicePixelRatio || 1, w = st.clientWidth, h = st.clientHeight;
    if (cv.width !== Math.round(w * k) || cv.height !== Math.round(h * k)) { cv.width = Math.round(w * k); cv.height = Math.round(h * k); }
    g.setTransform(k, 0, 0, k, 0, 0); g.clearRect(0, 0, w, h); const b = box(); if (b) d.strokes.forEach((s) => inkStroke(g, s, b)); };
  const tools = () => { lay.querySelectorAll("[data-dt]").forEach((b) => b.classList.toggle("on", b.dataset.dt === d.t));
    lay.querySelectorAll("[data-dc]").forEach((b) => b.classList.toggle("on", b.dataset.dc === d.c));
    lay.querySelector("[data-dz]").disabled = lay.querySelector("[data-dclr]").disabled = !d.strokes.length; };
  const undo = () => { d.strokes.pop(); paint(); tools(); };
  const clearAll = () => { if (!d.strokes.length) return; d.strokes = []; paint(); tools(); };
  // The finger draws 1:1: every coalesced point goes in, not only the ones a frame gets to.
  let now = null;
  const at = (e, b) => { const r = st.getBoundingClientRect(); return [(e.clientX - r.left - b.x) / b.w, (e.clientY - r.top - b.y) / b.h]; };
  cv.addEventListener("pointerdown", (e) => { e.stopPropagation(); e.preventDefault(); const b = box(); if (!b || now) return;
    cv.setPointerCapture(e.pointerId); now = {t: d.t, c: d.c, p: [at(e, b)], id: e.pointerId, b}; d.strokes.push(now); paint(); });
  cv.addEventListener("pointermove", (e) => { if (!now || e.pointerId !== now.id) return; e.stopPropagation();
    if (now.t === "pen") (e.getCoalescedEvents?.() || [e]).forEach((q) => now.p.push(at(q, now.b))); else now.p[1] = at(e, now.b); paint(); });
  const up = (e) => { if (!now || e.pointerId !== now.id) return; e.stopPropagation();
    const s = now; now = null;
    // A tap with the arrow or the box draws nothing: drop it rather than leave a dot.
    if (s.t !== "pen" && (!s.p[1] || Math.hypot((s.p[1][0] - s.p[0][0]) * s.b.w, (s.p[1][1] - s.p[0][1]) * s.b.h) < 6)) d.strokes.pop();
    paint(); tools(); };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
  lay.querySelector(".dtools").addEventListener("pointerdown", (e) => e.stopPropagation());
  lay.querySelectorAll("[data-dt]").forEach((b) => b.onclick = () => { d.t = b.dataset.dt; tools(); });
  lay.querySelectorAll("[data-dc]").forEach((b) => b.onclick = () => { d.c = b.dataset.dc; tools(); });
  lay.querySelector("[data-dz]").onclick = undo;
  lay.querySelector("[data-dclr]").onclick = clearAll;
  lay.querySelector("[data-dq]").onclick = () => endDraw(false);
  lay.querySelector("[data-dk]").onclick = () => endDraw(true);
  d.key = (e) => { if (e.target.closest?.("input,textarea")) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); endDraw(false); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); undo(); }
    else if (e.key === "Enter" || (e.key.toLowerCase() === "d" && !e.ctrlKey && !e.metaKey)) { e.preventDefault(); e.stopPropagation(); endDraw(true); } };   // stopped: the page's own Enter (viewer) and D (draw again) must not fire on the same press
  addEventListener("keydown", d.key, true);
  d.ro = new ResizeObserver(paint); d.ro.observe(st);
  tools(); paint();
  if (!wide()) st.scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"});
}
async function endDraw(keep) {
  const d = drawing; if (!d) return; drawing = null;
  removeEventListener("keydown", d.key, true); d.ro.disconnect(); d.lay.remove(); document.getElementById("stage")?.classList.remove("drawing");
  if (!keep || !d.strokes.length) return;
  // A picture is burnt in at its own full size (PNG, capped high only to guard memory); a video
  // frame at its display resolution. The vector below replays crisply at any size regardless.
  const m = d.m, isImg = m.tagName !== "VIDEO", nw = m.videoWidth || m.naturalWidth, nh = m.videoHeight || m.naturalHeight;
  const k = Math.min(1, (isImg ? 8192 : 2560) / Math.max(nw, nh));
  const c = document.createElement("canvas"); c.width = Math.round(nw * k); c.height = Math.round(nh * k);
  const g = c.getContext("2d");
  let blob;
  try { g.drawImage(m, 0, 0, c.width, c.height); d.strokes.forEach((s) => inkStroke(g, s, {x: 0, y: 0, w: c.width, h: c.height}));
    blob = await new Promise((ok, no) => c.toBlob((b) => b ? ok(b) : no(new Error()), "image/png")); }
  catch { return toast(tl("endDraw.1")); }
  if (drawPic) URL.revokeObjectURL(drawPic.url);
  // Keep the strokes (in the picture's 0-1 space) and which file they were drawn on, so the
  // comment can store the vector and the viewer can replay it on the media (see draw.js).
  drawPic = {blob, url: URL.createObjectURL(blob), id: openItem?.id,
    strokes: d.strokes.map((s) => ({t: s.t, c: s.c, p: s.p})), file: openItem?.pics?.[d.at]?.name || null};
  cmShow();
  showDrawPic();
  if (wide()) document.getElementById("cm")?.focus({preventScroll: true});
  else if (document.querySelector(".cbox")?.closest(".mounted")) setTimeout(() => document.querySelector(".cbox")?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}), 250);
}
// The finished drawing sits over the comment box until it is sent or taken off.
function showDrawPic() {
  const el = document.getElementById("drawchip"), t = document.getElementById("cm"), add = document.getElementById("cmadd"); if (!el) return;
  const on = drawPic && drawPic.id === openItem?.id; el.hidden = !on;
  el.innerHTML = on ? `<a href="${drawPic.url}" target="_blank" rel="noopener"><img src="${drawPic.url}" alt="${tl("showDrawPic.1")}"></a><span class="tx">${tl("showDrawPic.2")}</span><button class="ib press" id="drawx" aria-label="${tl("showDrawPic.3")}">${ic("x")}</button>` : "";
  if (add && t) { add.disabled = !t.value.trim() && !on && !(cmImgs[openItem?.id] || []).length; document.getElementById("cdk")?.classList.toggle("has", !add.disabled); }
  document.getElementById("drawx")?.addEventListener("click", () => { URL.revokeObjectURL(drawPic.url); drawPic = null; showDrawPic(); });
}
// The I-O stretch of the file on the stage, kept by item and file so a redraw keeps it.
const loops = {};
const abKey = () => openItem && `${openItem.id}#${stageAt}`;
// Frames when the file knows its rate: a two-second clip read "0:00–0:01" in seconds.
const abTxt = (r, f) => f?.fps ? `f${frameOf(r.a, f.fps)}–f${frameOf(r.b, f.fps)}` : `${clock(r.a, true)}–${clock(r.b, true)}`;
const abOf = (vd) => { const r = vd && vd === stageVideo() && loops[abKey()]; return r && r.b > r.a ? r : null; };
function setAB(k, vd) {
  const key = abKey(), r = loops[key] || {a: 0, b: vd.duration || 0};
  if (k === "x") { delete loops[key]; toast(tl("setAB.1")); }
  else { r[k === "i" ? "a" : "b"] = vd.currentTime; if (!Number.isFinite(r.b) || r.b <= r.a) r.b = Number.isFinite(vd.duration) ? vd.duration : r.a;
    loops[key] = r; toast(r.b > r.a ? tl("noteText.3", {abTxt: abTxt(r, openItem.pics[stageAt])}) : tl("setAB.2")); }
  vd.dispatchEvent(new Event("seeked"));
}
// Real text fields keep the keys; everything else is fair game for the item shortcuts.
const typingIn = (el) => !!(el && el.closest && el.closest("input,textarea,gk-select,[contenteditable]"));
// A pointer press leaves focus on the control it hit - a <video> or a button would then swallow
// the next Space / arrow. After a genuine click inside the result, hand focus back to the page so
// the shortcuts keep working (a keyboard-driven click, detail 0, keeps its focus for a11y).
addEventListener("click", (e) => { if (e.detail <= 0) return; const a = document.activeElement;
  if (a && a !== document.body && !typingIn(a) && a.closest?.("#stage,.detailcols")) a.blur(); }, true);
addEventListener("keydown", (e) => {
  if (!(detail?.[0] === "item" || wrLive()) || !openItem || drawing || e.ctrlKey || e.metaKey || e.altKey || (e.repeat && !/^arrow/i.test(e.key) && e.key !== "," && e.key !== ".")) return;
  if (typingIn(e.target) || document.querySelector(".vw,.viewmenu.on") || document.getElementById("sheet")?.classList.contains("on")) return;
  const k = e.key.toLowerCase(), vd = stageVideo();
  if (k === "escape" && pinning) { pinning = false; drawPins(); pinLabel(); return; }
  // Space and Enter on a focused button or link are that button's press, not the page's.
  if ((k === " " || k === "enter") && e.target.closest?.("button,a,summary,[role=switch]")) return;
  // 1/2/3 (·4) switch the compare mode while a comparison is open. It claims the number keys
  // ahead of the video's 0–9 jump, so the two versions on screen answer 밀기·나란히·겹치기·차이.
  const cmBtns = document.querySelectorAll("#tbody [data-cm]");
  if (cmBtns.length && /^[1-4]$/.test(k)) { const b = cmBtns[+k - 1]; if (b) { e.preventDefault(); b.click(); } return; }
  // On a video the arrows step frames, as on the old review page; PgUp / PgDn still change files.
  if (vd && (k === "arrowleft" || k === "arrowright")) { e.preventDefault(); stepFrame((k === "arrowright" ? 1 : -1) * (e.shiftKey ? 10 : 1)); }
  else if (vd && (k === "home" || k === "end")) { e.preventDefault(); if (k === "home") vd.currentTime = 0; else if (Number.isFinite(vd.duration)) vd.currentTime = Math.max(0, vd.duration - 0.001); }
  else if (vd && k === "s") nextRate();
  else if (vd && (k === "j" || k === "k" || k === "l")) jkl(k, vd);
  // , and . step one frame (YouTube's keys); ↑ ↓ jump a second; 0–9 jump to 0%–90%; M walks the comments.
  else if (vd && (k === "," || k === ".")) { e.preventDefault(); stepFrame(k === "." ? 1 : -1); }
  else if (vd && (k === "arrowup" || k === "arrowdown")) { e.preventDefault();
    const end = Number.isFinite(vd.duration) ? vd.duration - 0.001 : Infinity; vd.currentTime = Math.max(0, Math.min(end, vd.currentTime + (k === "arrowup" ? 1 : -1))); }
  else if (vd && /^[0-9]$/.test(k) && Number.isFinite(vd.duration)) { e.preventDefault(); vd.currentTime = vd.duration * (+k) / 10; }
  else if (vd && k === "m") jumpMark(e.shiftKey ? -1 : 1);
  // T: the aspect guide. F belongs to focus mode alone (web/custom.js) - one key, one thing.
  else if (k === "t" && openItem.pics.length) nextGuide();
  else if (k === "h") snoozeSheet(openItem.id);
  else if (vd && (k === "i" || k === "o" || k === "x")) setAB(k, vd);
  else if (vd && k === " ") { e.preventDefault(); vd.paused ? vd.play().catch(() => {}) : vd.pause(); }
  // Files step on the arrows (a still) and PgUp / PgDn (also on a video, whose arrows are frames).
  // [ and ] are not file keys: they fold the left menu and the right panel on every page.
  else if (k === "arrowleft" || k === "arrowright" || k === "pageup" || k === "pagedown") { if (!stageGo) return; e.preventDefault(); stageGo(stageAt + (k === "arrowright" || k === "pagedown" ? 1 : -1)); }
  // ↓ moves to the next item (same as N) and ↑ to the one before (Shift+N) when the stage is not
  // a video — a video keeps ↑ ↓ for the one-second jump above.
  else if ((k === "arrowdown" || k === "arrowup") && !vd) { if (wrLive()) return; const n = (k === "arrowup" ? prevOf : nextOf)(openItem.id); if (n) { e.preventDefault(); autoPlay = true; nav("item/" + iid(n)); } }
  // A and R decide what the buttons decide: the newest version, not a finished one.
  else if ((k === "a" || k === "r") && (!openItem.latest || (openItem.archived && openItem.status === "approved"))) return;
  else if (k === "a" && openItem.status !== "approved") decide("approved");
  else if (k === "r") decide("changes");
  // N the next result waiting, Shift+N the one before (as V / Shift+V walk versions).
  else if (k === "n") { if (wrLive()) return; const n = (e.shiftKey ? prevOf : nextOf)(openItem.id); if (n) { autoPlay = true; nav("item/" + iid(n)); } }
  else if (k === "p" && openItem.pics.length) { cmShow(); document.getElementById("pinbtn")?.click(); }
  else if (k === "d" && openItem.pics.length) { e.preventDefault(); cmShow(); startDraw(); }
  else if (e.key === "\\" && openItem.alt && openItem.pics.length) flipStage();
  // V goes back a version, Shift+V forward, without the version sheet.
  else if (k === "v") { const vs = openItem.vers, n = vs.indexOf(openItem.v) + (e.shiftKey ? -1 : 1); if (n < 0 || n >= vs.length) return toast(n < 0 ? tl("setAB.3") : tl("setAB.4"));
    if (n) verPick[openItem.id] = vs[n]; else delete verPick[openItem.id]; again(); }
  else if (k === "c") { e.preventDefault(); cmShow(); document.getElementById("cm")?.focus(); }
  else if ((k === " " || k === "enter") && openItem.pics.length) { e.preventDefault(); viewer(openItem.pics, stageAt); }
  else if (e.key === "?") keyBarToggle();
  else return;
});
// ===== X17: item-page shortcuts - hint bar, extra keys, keys from inside a shown HTML result =====
// Self-contained: the handler above keeps its bindings; this adds W / B / Enter / , . / Esc, the
// bar under the result, and the bridge that lets the keys work while focus is inside the frame.
// The bar is on until the reader turns it off (same "keys" preference as the settings switch).
try { if (localStorage.getItem("v2-keys") === null) localStorage.setItem("v2-keys", "1"); } catch {}
// The item frame asks for its page with ?keys=1: the server appends a small key listener (server.KEY_BRIDGE).
// &app=1 inside the app window: there the frame also hands over Ctrl + wheel (the app's screen size).
const keyUrl = (u) => u + (u.includes("?") ? "&" : "?") + "keys=1" + (IN_APP ? "&app=1" : "") + (document.documentElement.dataset.theme === "light" ? "" : "&sch=dark");   // sch: the frame's scrollbar follows the app theme
// Zoom of the shown HTML result. The frame is laid out at its width divided by the zoom (the way a
// browser zooms a page), so the report reflows instead of growing a sideways scrollbar.
// d: 1 / -1 one step, 0 back to 100%, null only shows the size it has.
function pageZoom(d) {
  const w = document.getElementById("pgw"); if (!w) return;
  if (d != null) { pageZ = d ? PAGE_Z[Math.max(0, Math.min(PAGE_Z.length - 1, PAGE_Z.indexOf(pageZ) + d))] : 1;
    try { localStorage.setItem("pageZ", String(pageZ)); } catch {} }
  w.style.setProperty("--pgz", pageZ);
  const c = document.querySelector(".pgtop .pgzoom"); if (!c) return;
  c.querySelector(".zpct").textContent = `${Math.round(pageZ * 100)}%`;
  c.querySelector('[data-z="-1"]').disabled = pageZ === PAGE_Z[0];
  c.querySelector('[data-z="1"]').disabled = pageZ === PAGE_Z[PAGE_Z.length - 1];
  c.querySelector('[data-z="0"]').disabled = c.querySelector('[data-z="100"]').disabled = pageZ === 1;
}
// A report on a phone is as tall as its content, so the page is the only thing that scrolls: a
// frame with its own scroll swallowed the swipe and the questions under it stayed out of reach.
// The frame's page reports its height (server.KEY_BRIDGE "size"); the frame is an opaque origin
// and cannot be measured from here. Left at the CSS height (it scrolls inside, as before) when
// the page lays itself out against the viewport (it would grow for ever), pins something to the
// viewport (position:fixed), or is taller than PG_FIT[1]. A PC keeps the fixed frame beside the panel.
const PG_FIT = [160, 20000];
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "size") return;
  const h = +d.h, ih = +d.ih, st = fr._fit || (fr._fit = {});
  if (!Number.isFinite(h) || !Number.isFinite(ih) || h <= 0 || fr.closest(".pgw.full") || document.body.classList.contains("composing")) return;
  const pgw = fr.closest(".pgw"), base = () => { fr.style.height = ""; pgw.classList.remove("fit"); };
  if (wide() || st.lock) return base();
  // A page that still overflows after it was given its full height is following the viewport:
  // the same overflow three times running, or four overflows in a row (content that really grew
  // reads 0 once the frame has caught up).
  const over = Math.round(h - ih);
  st.run = over > 1 ? (st.run || 0) + 1 : 0;
  st.same = over > 1 && st.set && Math.abs(over - st.over) <= 1 ? (st.same || 0) + 1 : 0;
  if (d.fixed || h > PG_FIT[1] || st.run >= 4 || st.same >= 2) { st.lock = true; return base(); }
  // Content that hangs out of its own box measures short once it fits: the height would swing
  // between the two readings, so after one swing the taller one stays.
  const to = Math.max(PG_FIT[0], Math.ceil(h));
  if (st.h2 != null && Math.abs(to - st.h2) <= 1 && Math.abs(to - st.h1) > 1) st.keep = true;
  if (st.keep && to < st.h1) return;
  st.over = over; st.set = true;
  if (to !== st.h1) { st.h2 = st.h1; st.h1 = to; }
  fr.style.height = to + "px"; pgw.classList.add("fit");   // .fit: shown in full, so no 전체 화면 on it
});
// Alt + wheel over the report: the frame's page hands the wheel over (server.KEY_BRIDGE).
let pgWheel = 0, pgWheelAt = 0;
addEventListener("message", (e) => {
  const fr = document.querySelector(".media iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "wheel" || d.mod !== "alt" || !Number.isFinite(d.dy) || !wide()) return;
  const now = Date.now(); if (now - pgWheelAt > 300) pgWheel = 0;
  pgWheelAt = now; pgWheel += d.dy;
  if (Math.abs(pgWheel) < 50) return;
  pageZoom(pgWheel < 0 ? 1 : -1); pgWheel = 0;
});
const KB_KEY = {"space": " ", "←": "arrowleft", "→": "arrowright", "esc": "escape"};
// Only the keys that apply to what is on screen: o = {video, pics, page, decide, next, vers, cmp, mount}.
function keyBarHtml(o) {
  if (o.mount) return "";
  const K = [];
  if (o.video) K.push(["Space", tl("keybar.play")], ["← →", tl("keybar.frame")]);
  else if (o.pics) { K.push(["Space", tl("keybar.big")]); if (o.pics > 1) K.push(["← →", tl("keybar.file")]); }
  else if (o.page) K.push(["W", tl("keybar.width")], ["Enter", tl("keybar.full")]);
  if (o.decide) K.push(["A", tl("keybar.ok")]);
  K.push(["C", tl("keybar.cmt")]);
  if (o.next) K.push(["N", tl("keybar.next")]);
  if (o.cmp) K.push(["B", tl("keybar.cmp")]);
  const cap = (x) => `<kbd data-k="${esc(KB_KEY[x.toLowerCase()] || x.toLowerCase())}">${esc(x)}</kbd>`;
  return `<div class="kbar${pref("keys") ? "" : " off"}" id="kbar" role="note" aria-label="${tl("keysSheet.20")}"><div class="kbar-l">${K.map(([k, t]) => `<span class="kb">${k.split(" ").map(cap).join("")}<em>${t}</em></span>`).join("")}</div><button class="kbar-b press" id="kbarall">${tl("keybar.all")}</button><button class="kbar-b ic press" id="kbarx" aria-label="${tl("keybar.off")}" title="${tl("keybar.off")}">${ic("x")}</button></div>`;
}
// The same bar under the lists that are gone through by keyboard (home, 알림 · 할 일, 결과물), with
// the keys of the list. It follows the one 단축키 안내 setting, and ? turns it on from any of them.
function listKeyBar() {
  const K = [["J K", tl("keyHelp.7")], ["Enter", tl("search.3")], ["A", tl("STATUS_T.4")], ["R", tl("cmt.1")], ["H", tl("palActs.2")]];
  if (cur === "lib") K.push(["1-7", tl("keybar.lists")]);
  K.push(["?", tl("keybar.hide")]);
  const cap = (x) => `<kbd data-k="${esc(x.toLowerCase())}">${esc(x)}</kbd>`;
  return `<div class="kbar${pref("keys") ? "" : " off"}" id="kbar" role="note" aria-label="${tl("keysSheet.20")}"><div class="kbar-l">${K.map(([k, t]) => `<span class="kb">${k.split(" ").map(cap).join("")}<em>${t}</em></span>`).join("")}</div><button class="kbar-b press" id="kbarlist">${tl("keybar.all")}</button><button class="kbar-b ic press" id="kbarx" aria-label="${tl("keybar.off")}" title="${tl("keybar.off")}">${ic("x")}</button></div>`;
}
function keyBarToggle(v = !pref("keys")) {
  pref("keys", v); document.getElementById("kbar")?.classList.toggle("off", !v);
  // Closing says how to bring it back, and offers the way right there; turning it on says it too.
  if (!v) toastAct(tl("keybar.offd"), tl("keybar.undo"), () => keyBarToggle(true), 7000);
  else toast(tl("keybar.ond"));
}
// ? works on every screen (the item screen's own handler has it too and skips a second toggle).
addEventListener("keydown", (e) => {
  if (e.key !== "?" || e.ctrlKey || e.metaKey || e.altKey || e.defaultPrevented || typingIn(e.target)) return;
  if (detail?.[0] === "item" || wrLive() || document.getElementById("sheet")?.classList.contains("on")) return;
  keyBarToggle();
});
// A pressed key lights its cap for a moment (CSS transition, so a second press just restarts it).
function keyBarHit(k) {
  const c = [...document.querySelectorAll("#kbar kbd")].find((x) => x.dataset.k === k); if (!c) return;
  c.classList.add("hit"); clearTimeout(c._hit); c._hit = setTimeout(() => c.classList.remove("hit"), 170);
}
addEventListener("click", (e) => { const b = e.target.closest?.("#kbarx,#kbarall,#kbarlist"); if (!b) return;
  if (b.id === "kbarx") keyBarToggle(false); else if (b.id === "kbarlist") keyHelp(); else keysSheet(); });
// The shell never slides sideways, whatever asked the window to (a focus on something off the edge).
addEventListener("scroll", () => { if (scrollX) scrollTo(0, scrollY); }, {passive: true});
// Same gates as the handler above, plus the compare workspace, the search overlay and the 보기 menu.
const itemKeysFree = (e) => !!openItem && detail?.[0] === "item" && !wrLive() && !drawing && !e.ctrlKey && !e.metaKey && !e.altKey && !typingIn(e.target)
  && !document.documentElement.classList.contains("cmpv-lock") && !document.querySelector(".vw,.stk,#ov.on") && !document.getElementById("sheet")?.classList.contains("on");
addEventListener("keydown", (e) => {
  if (!itemKeysFree(e)) return;
  const k = e.key.toLowerCase(), menu = document.querySelector(".viewmenu.on");
  if (menu) { if (k === "escape") menu.classList.remove("on"); return; }
  keyBarHit(e.shiftKey && k === "n" ? "shift+n" : k);
  if (e.repeat) return;
  const onBtn = e.target.closest?.("button,a,summary,[role=switch]"), full = document.getElementById("pgfull");
  // W: an HTML result at PC width / phone width. Enter: the page full screen (a still or a video already opens big).
  // + / - / 0: the result's own zoom (a picture on the stage, or the shown page), at PC width.
  const zk = wide() && !onBtn ? (k === "+" || k === "=" ? 1 : k === "-" ? -1 : k === "0" ? 0 : null) : null;
  if (zk != null && (document.getElementById("pgw") || stageZoom)) { e.preventDefault();
    if (document.getElementById("pgw")) pageZoom(zk); else zk ? stageZoom.step(zk) : stageZoom.fit(); }
  else if (k === "w" && wide()) document.querySelector(".pgtop [data-pw]:not(.on)")?.click();
  else if (k === "enter" && full && !onBtn) { e.preventDefault(); full.click(); }
  // B: the comparison tab and back.
  else if (k === "b") { const t = document.querySelector('#itabs [data-v="cmp"]'); if (t) (t.classList.contains("on") ? document.querySelector('#itabs [data-v="cm"]') : t)?.click(); }
  // , and . walk the versions where they are not a video's frame step (V / Shift+V do the same everywhere).
  else if ((k === "," || k === ".") && !stageVideo() && openItem.vers.length > 1) document.body.dispatchEvent(new KeyboardEvent("keydown", {key: k === "," ? "v" : "V", shiftKey: k === ".", bubbles: true}));
  // Esc leaves the result when there is nothing left to close (a pin being placed and the full-screen page close first).
  else if (k === "escape" && !e.defaultPrevented && !pinning && !document.querySelector(".pgw.full")) back();
});
// Keys pressed while focus is inside the shown HTML result. The frame is an opaque origin, so its
// page (server.KEY_BRIDGE) posts the keys it did not use itself; they are replayed here as if
// pressed on the app. Only from our own frame and only while the reader is really inside it.
addEventListener("message", (e) => {
  const fr = document.querySelector(".media iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "key" || typeof d.key !== "string" || d.key.length > 12) return;
  if (document.activeElement !== fr) return;
  // A pushed page must never be able to approve itself: A from inside the frame only hands the
  // keyboard back to the app, and the next A (a real key press on the app) approves.
  if (/^a$/i.test(d.key)) { fr.blur(); if (openItem?.latest && openItem.status !== "approved") toast(tl("keybar.again")); return; }
  document.body.dispatchEvent(new KeyboardEvent("keydown", {key: d.key, shiftKey: !!d.shift, repeat: !!d.repeat, bubbles: true, cancelable: true}));
});
// ===== /X17 =====
// Enter sends, Shift+Enter breaks the line. An Enter that only finishes a Korean syllable is left alone.
// An iPhone's Korean keyboard reports Enter as composing (229), so the keydown path alone let
// the key drop a line break into the box instead of sending; the line break it inserts once
// the syllable is committed is caught here as well. Shift+Enter still makes a new line.
const enterSends = (t, b) => { let shift = false;
  const go = () => setTimeout(() => { if (!b.disabled) b.click(); });
  t.onkeydown = (e) => { shift = e.shiftKey;
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); go(); } };
  t.addEventListener("beforeinput", (e) => {
    if (!shift && (e.inputType === "insertLineBreak" || e.inputType === "insertParagraph")) { e.preventDefault(); go(); } }); };
// Reads a box only after the keyboard has committed the syllable still being typed; a phone
// otherwise sent the words without their last letter.
const settled = (t) => new Promise((r) => { if (document.activeElement === t) t.blur(); setTimeout(r, 30); });
// Ready answers above the comment box: the department's own --reject list when it gave one,
// else the usual few. A tap adds it to the box (a second tap takes it out); 보내기 still sends.
// No "좋아요" here: a yes is the 승인 button right above, and a yes-shaped comment next to it
// left two ways to say the same thing and no telling which one counted.
const QUICK = LT(() => ([tl("QUICK.1"), tl("QUICK.2"), tl("QUICK.3"), tl("QUICK.4"), tl("QUICK.5"), tl("QUICK.6")]));
// The server fills a version's reject list with its own default four (hub_store.REJECT_DEFAULT,
// stored in Korean) when the department named none: those are shown in the reader's language.
const REJECT_DEFAULT = ["방향이 달라요 · 다시 잡아주세요", "디테일만 고치면 돼요", "화질·기술 문제예요", "더 얘기하고 정하죠"];
const rejectList = (r) => (r || []).map((t) => { const n = REJECT_DEFAULT.indexOf(t); return n < 0 ? t : tl(`rejectSheet.${n + 1}`); });
const quickPicks = (it) => (it.reject?.length ? rejectList(it.reject) : QUICK).slice(0, 8);
// What was typed but not sent, per item: switching to 기록 and back, or a redraw, rebuilt the box empty.
// Drafts outlive a reload: a phone browser throws a tab away while another app is in front.
const cmDraft = (() => { try { return JSON.parse(localStorage.getItem("cmDraft") || "{}"); } catch (e) { return {}; } })();
const saveDraft = () => { try { localStorage.setItem("cmDraft", JSON.stringify(Object.fromEntries(Object.entries(cmDraft).filter(([, t]) => t)))); } catch (e) {} };
// Screenshots pasted, dropped or picked for a comment on a result, per item until sent (C04).
// They go up with the comment as "📎 <path>" lines, the way a picture in a talk room does.
const cmImgs = {}, CM_IMG_MAX = 4, CM_IMG_BYTES = 20 * 1024 * 1024;
// The composer dock (#cdk) is always on screen: pinned under the side panel on a PC, to the bottom
// edge on a phone. Only the 대화 tab, which has its own message box, puts it away.
function cmShow() {
  if (document.querySelector("#itabs .on")?.dataset.v === "chat") document.querySelector('#itabs [data-v="cm"]')?.click();
  return document.getElementById("cm");
}
// How far the end of the list is from the top of the dock (0 = resting right on it). A stage/sheet
// mount has the dock in the flow, so there is nothing to measure.
function cmGap() {
  const c = document.querySelector(".card.itab"), k = document.getElementById("cdk");
  if (!c || !k || k.closest(".mounted") || !k.offsetHeight) return null;
  return c.getBoundingClientRect().bottom - k.getBoundingClientRect().top;
}
let cmJump = 0;   // until when a redraw brings the list's end up to the box (a comment was just sent)
function cmEnd() {
  const g = cmGap(); if (g == null) return;
  const p = document.getElementById("cdk").parentElement;
  if (wide() && p.scrollHeight > p.clientHeight) p.scrollTop += g + 8; else scrollBy({top: g + 8, behavior: "instant"});
}
// The box grows with the words up to its CSS max-height, then scrolls inside.
function cmGrow(t) { t.style.height = "auto"; t.style.height = t.scrollHeight + 2 + "px"; }
let cdkRO = null;
function wireComments(it) {
  const t = document.getElementById("cm"), add = document.getElementById("cmadd"), tg = document.querySelector(".tgt");
  if (!t || !add) return;
  const cdk = document.getElementById("cdk");
  const imgs = cmImgs[it.id] || (cmImgs[it.id] = []);
  // With something to send, 보내기 is the one lit button: 승인 beside it steps back (.has).
  const hasPic = () => drawPic?.id === it.id, can = () => { add.disabled = !t.value.trim() && !hasPic() && !imgs.length; cdk?.classList.toggle("has", !add.disabled); };
  t.value = cmDraft[it.id] || ""; can(); showDrawPic(); showQuote(); cmGrow(t);
  // The phone's page leaves room for the docked bar, however tall it has grown.
  cdkRO?.disconnect();
  // On a PC the dock grows when its tools come out: the panel moves up by as much, so what sat right
  // above the dock (다음 결과물) stays in sight instead of going under it.
  if (cdk && window.ResizeObserver) { let h0 = cdk.offsetHeight;
    cdkRO = new ResizeObserver(() => { const h = cdk.offsetHeight, dh = h - h0, pn = cdk.parentElement; h0 = h;
      document.body.style.setProperty("--cdkH", h + "px");
      if (dh > 0 && wide() && pn.scrollHeight > pn.clientHeight) pn.scrollTop += dh; });
    cdkRO.observe(cdk); }
  const attBox = document.getElementById("cmatt"), fileIn = document.getElementById("cmfile");
  const drawAtt = () => { if (!attBox) return; attBox.hidden = !imgs.length;
    attBox.innerHTML = imgs.map((im, n) => `<div class="th"><img src="${im.url}" alt="${tl("cmImg.3", {n: n + 1})}"><button class="press" data-imgrm="${n}" aria-label="${tl("cmImg.4")}">${ic("x")}</button></div>`).join(""); };
  const addImgs = (files) => { for (const f of files) {
      if (!f.type.startsWith("image/")) { toast(tl("cmImg.5")); continue; }
      if (f.size > CM_IMG_BYTES) { toast(tl("cmImg.6")); continue; }
      if (imgs.length >= CM_IMG_MAX) { toast(tl("cmImg.7", {n: CM_IMG_MAX})); break; }
      imgs.push({blob: f, url: URL.createObjectURL(f)}); }
    drawAtt(); can(); updSplit(); };
  if (attBox) attBox.onclick = (e) => { const x = e.target.closest("[data-imgrm]"); if (!x) return;
    const [gone] = imgs.splice(+x.dataset.imgrm, 1); if (gone) URL.revokeObjectURL(gone.url); drawAtt(); can(); updSplit(); };
  const ib = document.getElementById("cmimg"); if (ib && fileIn) { ib.onclick = () => fileIn.click(); fileIn.onchange = () => { addImgs([...fileIn.files]); fileIn.value = ""; }; }
  t.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith("image/"));
    if (fs.length) { e.preventDefault(); addImgs(fs); } });
  const dock = document.getElementById("cdock");
  if (dock) { ["dragenter", "dragover"].forEach((k) => dock.addEventListener(k, (e) => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); dock.classList.add("drop"); } }));
    dock.addEventListener("dragleave", (e) => { if (!dock.contains(e.relatedTarget)) dock.classList.remove("drop"); });
    dock.addEventListener("drop", (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); dock.classList.remove("drop"); addImgs([...e.dataTransfer.files]); }); }
  drawAtt();
  const db = document.getElementById("drawbtn"); if (db) db.onclick = () => drawing ? endDraw(true) : startDraw();
  document.querySelectorAll("#qpick .opt").forEach((o) => o.onclick = () => {
    const q = o.dataset.q, on = !t.value.includes(q);
    t.value = (on ? (t.value.trim() ? t.value.trim() + ", " : "") + q : t.value.replace(q, ""))
      .replace(/(\s*,\s*){2,}/g, ", ").replace(/^[\s,]+|[\s,]+$/g, "");
    o.classList.toggle("on", on); can(); cmDraft[it.id] = t.value; saveDraft();
  });
  if (tg) tg.querySelectorAll(".tg").forEach((b) => b.onclick = () => { tg.dataset.on = b.dataset.tgt; tgtLabel(); t.placeholder = b.dataset.tgt === "file" ? tl("itemView.109") : tl("wireComments.1"); t.focus(); });
  const pb = document.getElementById("pinbtn");
  pinLabel = () => { if (!pb) return; pb.classList.toggle("on", pinning || !!pin);
    pb.querySelector("span").textContent = pinning ? (it.pics[stageAt]?.kind === "video" ? tl("wireComments.2") : tl("loc.pinning")) : pin?.r ? tl("loc.region_set") : pin ? tl("wireComments.3", {x: pin.x, y: pin.y}) : tl("itemView.106"); };
  if (pb) pb.onclick = () => { if (drawing) endDraw(false); if (pin) { pin = null; pinning = false; } else if ((pinning = !pinning)) { stageVideo()?.pause();
      document.getElementById("stage")?.scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"}); }
    drawPins(); pinLabel(); };
  pinLabel();
  // Several directives written one per line can go as one comment or be split, each on its own.
  // The chip shows only when there are 2+ lines and no pin/drawing is attached (those belong to a
  // single note). Splitting is off by default, so a plain paragraph is never broken up by surprise.
  // With the split on, the lines it will send are listed under the box before anything goes,
  // so what arrives as separate directives is never a surprise (C07).
  const splitBtn = document.getElementById("cmsplit"), pv = document.getElementById("splitpv");
  let splitMode = false;
  function updSplit() { if (!splitBtn) return;
    const lines = splitDirectives(t.value), n = lines.length, show = n >= 2 && !hasPic() && !pin && !imgs.length && pgQuote?.id !== it.id;
    if (!show) { splitMode = false; splitBtn.hidden = true; splitBtn.setAttribute("aria-pressed", "false"); if (pv) { pv.hidden = true; pv.innerHTML = ""; } return; }
    splitBtn.hidden = false; splitBtn.setAttribute("aria-pressed", String(splitMode));
    splitBtn.classList.toggle("on", splitMode);
    splitBtn.querySelector("span").textContent = splitMode ? tl("itemView.164") : tl("itemView.163", {n});
    if (pv) { pv.hidden = !splitMode;
      pv.innerHTML = splitMode ? `<div class="spvh">${tl("cmSplit.2", {n})}</div><ol>${lines.map((ln) => `<li>${esc(ln)}</li>`).join("")}</ol>` : ""; }
    fitCompose(); }
  if (splitBtn) splitBtn.onclick = () => { splitMode = !splitMode; updSplit(); t.focus(); };
  updSplit();
  t.oninput = () => { can(); cmGrow(t); cmDraft[it.id] = t.value; saveDraft(); updSplit(); };
  // Typing about a moment while the video runs on sent a later moment than the one meant.
  t.addEventListener("focus", () => { const vd = stageVideo(); if (vd && !vd.paused) vd.pause(); cmWhen(); startCompose(); });
  document.querySelectorAll(".qtog").forEach((b) => b.onclick = () => { const on = !qpOn(); qpOn(on);
    document.getElementById("qpick")?.classList.toggle("off", !on);
    document.querySelectorAll(".qtog").forEach((x) => { x.setAttribute("aria-pressed", on); x.textContent = tl("wireComments.4", {p0: on ? tl("itemView.108") : tl("catchBar.2")}); });
    fitCompose(); });
  const cx = document.getElementById("cmpx"); if (cx) cx.onclick = () => endCompose();
  cmWhen();
  enterSends(t, add);
  add.onclick = async () => { add.disabled = true; await settled(t);
    const text = t.value.trim() || (hasPic() ? tl("wireComments.5") : imgs.length ? tl("cmImg.9") : pgQuote?.id === it.id && quoteLine(pgQuote.to) ? tl("pgq.to_say") : ""); if (!text) { add.disabled = false; return; }
    // Which file, and for a video the moment it was paused at, go in front of the words.
    const f = it.pics[stageAt], onFile = it.pics.length > 1 && (tg?.dataset.on || "file") === "file";
    // A typed viewer (code/doc/sheet, types.js) may anchor the comment to a file line, cell, or
    // selection; it returns that anchor as plain text to sit in the leading [...] tag.
    const anch = (window.LOOP_ANCHOR && window.LOOP_ANCHOR(it)) || "";
    const tag = [onFile ? f.name : "", anch, pin && pin.at === stageAt ? (pin.r ? boxTag(pin.r) : tl("wireComments.6", {x: pin.x, y: pin.y})) : "", momentOf(stageVideo(), f)].filter(Boolean).join(" ");
    // Split on: each line goes as its own directive (the same file/moment tag in front), so a
    // list a session wrote in one box lands as separate items to work through. A pin/drawing is
    // ruled out above, so there is nothing per-line to attach.
    // 되돌리기 takes back the parts no session has read yet and puts the text back in the box; the
    // hand-over (sendNow) waits out that window so its own toast does not hide the button.
    if (splitMode && !hasPic() && !imgs.length) { const plan = splitPlan(t.value, tag), draft = t.value;
      if (plan.length >= 2) { const made = [];
        try { for (const x of plan) made.push((await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: x})).entry?.id);
          await toChanges(it); delete cmDraft[it.id]; saveDraft(); pin = null; pinning = false; endCompose();
          await load(); cmJump = Date.now() + 1500; again();
          let undone = false;
          const later = setTimeout(() => { if (!undone) sendNow(it); }, 6000);
          toastAct(tl("itemView.165", {n: plan.length}), tl("toggleFav.3"), async () => { undone = true; clearTimeout(later);
            try { const d = await get(`/api/item?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`);
              const kept = (d.log || []).filter((e) => made.includes(e.id) && (e.delivered || e.ack)).map((e) => e.id);
              for (const id of made) if (id && !kept.includes(id)) await post("/api/delete", {p: it.p, i: it.i, id});
              if (!kept.length) { cmDraft[it.id] = draft; saveDraft(); }
              toast(kept.length ? tl("cmSplit.3", {n: kept.length}) : tl("cmSplit.4"));
              if (kept.length) sendNow(it);
              await load(); again(); }
            catch (e) { toast(e.message); } }, 6000);
          return; }
        catch (e) { toast(e.message); add.disabled = false; return; } } }
    try {
      // A drawing goes up first: the comment carries its path, as a picture in a talk room does,
      // plus the vector strokes so the viewer can replay them on the media (see draw.js).
      let att = "", draw = null, drawPng = null;
      if (hasPic()) { const r = await fetch(`/api/attach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`, {method: "POST", headers: {"Content-Type": "image/png"}, body: drawPic.blob});
        const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || tl("wireComments.7"));
        att = `\n📎 ${j.path}`; drawPng = j.path;
        draw = drawPic.strokes?.length ? {strokes: drawPic.strokes, file: drawPic.file} : null; }
      for (const im of imgs) { const r = await fetch(`/api/attach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`, {method: "POST", headers: {"Content-Type": im.blob.type || "image/png"}, body: im.blob});
        const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || tl("cmImg.8"));
        att += `\n📎 ${j.path}`; }
      // The box/spot and the I-O stretch ride in the tag (the server reads them into pin/rect and
      // at_/to_ fields); which file of several is named as data too.
      // A box also goes as rect (0..1, finer than the tag's whole percent); the server refuses one
      // that pokes past the edge, so it is fitted inside first.
      const rect = pin && pin.at === stageAt && pin.r ? fitRect(pin.r) : null;
      // A quoted passage leads the comment; "→ words" under it is what should stand there instead.
      const qTo = pgQuote?.id === it.id ? quoteLine(pgQuote.to) : "";
      const quote = pgQuote?.id === it.id ? `> ${pgQuote.text}\n${qTo ? `→ ${qTo}\n` : ""}` : "";
      await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: quote + (tag ? `[${tag}] ${text}` : text) + att, draw, draw_png: drawPng,
        ...(it.pics.length > 1 && f ? {file: f.name} : {}), ...(rect ? {rect} : {}), ...(quote && pgQuote.n ? {quote_n: pgQuote.n} : {})});
      await toChanges(it);
      if (hasPic()) { URL.revokeObjectURL(drawPic.url); drawPic = null; }
      imgs.splice(0).forEach((im) => URL.revokeObjectURL(im.url));
      delete cmDraft[it.id]; saveDraft(); pin = null; pinning = false; pgQuote = null; endCompose(); await sendNow(it); await load(); cmJump = Date.now() + 1500; again(); }
    catch (e) { toast(e.message); add.disabled = false; } };
}
// Leaving a comment is asking for a fix: the newest version is sent back (changes). An approved one
// keeps its mark - but once that word is sent the lists file it by the work flow again, until it
// is approved once more (status.js, `reopened`).
const toChanges = (it) => it.latest && !["changes", "approved"].includes(it.status)
  ? post("/api/status", {p: it.p, i: it.i, v: it.v, status: "changes"}).catch(() => null) : Promise.resolve();
// What went into a version in code: the commits of the pushing folder's repository since the
// version before. Folders outside git (most render work) show nothing.
const gitMemo = new Map();
async function gitCard(body, p, i, vv) {
  const key = `${p}/${i}/${vv}`;
  if (!gitMemo.has(key)) gitMemo.set(key, get(`/api/commits?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}&v=${vv}`).then((j) => j.commits || []).catch(() => []));
  const cs = await gitMemo.get(key);
  if (!cs.length || !body.isConnected || body.querySelector(".gitc")) return;
  body.insertAdjacentHTML("afterbegin", `<details class="gitc"><summary>${ic("code")}<span>${tl("gitCard.1")} <b class="num">${cs.length}</b></span>${ic("chev", "i dn")}</summary>
    ${cs.map((c) => `<div class="row gc"><code class="num">${esc(c.id)}</code><span class="tx"><div class="t">${esc(c.text)}</div><div class="s">${ago(c.at)}</div></span></div>`).join("")}</details>`);
}
// Quick picks can be put away; the choice is kept per browser.
function qpOn(set) {
  // Hidden unless turned on: they took half of what the keyboard left (user, 2026-09-26).
  try { if (set !== undefined) localStorage.setItem("qpShow", set ? "1" : "0"); return localStorage.getItem("qpShow") === "1"; } catch (e) { return false; }
}
// Writing on a phone pushed the result off the screen: the keyboard took half, the box
// the rest. While composing, the result is pinned above and the box sits on the keys, and
// it stays that way with the keyboard down so the files can be swiped between sentences.
let composing = null;
function startCompose() {
  // The pinned element is the image/video stage, or an HTML report's frame when there is no stage.
  if (wide() || composing || !(document.getElementById("stage") || document.getElementById("pgw")) || !document.getElementById("cdock")) return;
  const bg = document.createElement("div"); bg.className = "cmpbg"; bg.onclick = () => endCompose();
  // Inside the app, not on <body>: a skin that lifts .app into its own layer put this over the result and the box.
  (document.querySelector(".app") || document.body).appendChild(bg);
  let raf = 0; const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(fitCompose); };
  composing = {bg, on};
  visualViewport?.addEventListener("resize", on); visualViewport?.addEventListener("scroll", on); addEventListener("resize", on);
  document.body.classList.add("composing"); fitCompose();
  setTimeout(fitCompose, 350);   // after the keyboard has finished coming up
}
function fitCompose() {
  if (!composing) return;
  const dock = document.getElementById("cdock"), media = document.querySelector(".media");
  const stage = document.getElementById("stage"), st = stage || document.getElementById("pgw");
  if (!dock || !media || !st) return endCompose();
  const vv = window.visualViewport, top = vv ? vv.offsetTop : 0, h = vv ? vv.height : innerHeight;
  dock.style.bottom = Math.max(0, innerHeight - h - top) + "px"; media.style.top = top + "px";
  const other = media.offsetHeight - st.offsetHeight;
  document.body.style.setProperty("--cmpH", Math.max(120, Math.round(h - dock.offsetHeight - other - 6)) + "px");
  if (stage) stageGo?.(stageAt, 0, true);
}
function endCompose() {
  if (!composing) return;
  const {bg, on} = composing; composing = null; bg.remove();
  visualViewport?.removeEventListener("resize", on); visualViewport?.removeEventListener("scroll", on); removeEventListener("resize", on);
  document.body.classList.remove("composing");
  const dock = document.getElementById("cdock"), media = document.querySelector(".media");
  if (dock) dock.style.bottom = ""; if (media) media.style.top = "";
  if (document.activeElement?.id === "cm") document.activeElement.blur();
  if (document.getElementById("stage")) { stageGo?.(stageAt, 0, true); document.querySelector(".itab")?.scrollIntoView({block: "start"}); }
  else if (document.getElementById("pgw")) document.querySelector(".itab")?.scrollIntoView({block: "start"});
}
// 코멘트 in the phone's bottom bar: the box sat in a second tab under the questions, so a
// phone never found it (user, 2026-09-29). Opens that tab and puts the keyboard up in the
// same tap (a phone only raises it from a gesture), which docks the box over the result.
function openCmt() {
  const t = cmShow(); if (!t) return;
  t.focus({preventScroll: true});
  if (!composing && t.closest(".mounted")) t.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"});
}
// A shown HTML page (picker, checklist) can hand its result to the comment box. It only
// fills the box; the reader still presses 보내기. Accepted from the item's own frame only.
window.addEventListener("message", (e) => {
  // Only our own result iframe may hand a comment over: it is sandboxed (opaque origin, no
  // fetch), so this postMessage is its one way to the app. {hub:"comment"} is the hub's
  // wording; {loop:"comment"} is ours - both mean the same and carry a `text`.
  const fr = document.querySelector(".media iframe");
  const asks = e.data?.hub === "comment" || e.data?.loop === "comment";
  if (!fr || e.source !== fr.contentWindow || !asks || typeof e.data.text !== "string") return;
  cmShow();
  const t = document.getElementById("cm"), add = document.getElementById("cmadd");
  if (!t) return;
  t.value = e.data.text.slice(0, 8000); add.disabled = !t.value.trim();
  if (t.closest(".mounted")) t.scrollIntoView({block: "center", behavior: "smooth"});
  cmGrow(t); document.getElementById("cdk")?.classList.toggle("has", !add.disabled); t.focus({preventScroll: true});
  toast(tl("openCmt.1"));
});
// Words selected in the shown report (server.KEY_BRIDGE "sel") wait over the comment box as the
// comment's quote. A selection dropped while the reader is still inside the report takes the quote
// away; one that goes because they moved on to type does not.
let pgQuote = null;                       // {id, text}
function showQuote() {
  const el = document.getElementById("qchip"), t = document.getElementById("cm"); if (!el) return;
  const on = !!pgQuote && pgQuote.id === openItem?.id; el.hidden = !on;
  // The pen opens one line for the words that should stand there instead (sent as "→ words").
  const to = on && pgQuote.to != null;
  el.innerHTML = on ? `<span class="tx">${esc(pgQuote.text)}</span><button class="ib press${to ? " on" : ""}" id="qchipr" aria-pressed="${to}" aria-label="${tl("pgq.to_t")}" title="${tl("pgq.to_t")}">${ic("pen")}</button><button class="ib press" id="qchipx" aria-label="${tl("pgq.drop")}" title="${tl("pgq.drop")}">${ic("x")}</button>${to ? `<input id="qto" maxlength="160" autocomplete="off" placeholder="${tl("pgq.to_ph")}" aria-label="${tl("pgq.to_t")}" value="${esc(pgQuote.to)}">` : ""}` : "";
  if (t && openItem?.page) t.placeholder = on ? tl("pgq.ph_on") : tl("pgq.ph");
  document.getElementById("qchipx")?.addEventListener("click", () => { pgQuote = null; showQuote(); });
  document.getElementById("qchipr")?.addEventListener("click", () => { pgQuote.to = to ? null : ""; showQuote(); document.getElementById("qto")?.focus(); });
  document.getElementById("qto")?.addEventListener("input", (e) => { pgQuote.to = e.target.value; });
}
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "sel" || typeof d.text !== "string" || !openItem) return;
  const q = quoteLine(d.text);
  if (q.length > 1) pgQuote = {id: openItem.id, text: q, n: d.n | 0};
  else if (document.activeElement === fr && pgQuote?.id === openItem.id) pgQuote = null;
  else return;
  showQuote();
});
// A quote in the log, a 지시 row's 이 부분, a changed line: the report goes to those words and
// lights them (server.KEY_BRIDGE "find"). The page answers "found"; a phone's full-length frame
// cannot scroll itself, so the app scrolls to where the page says the words are.
// The quoted passages stay marked while the pen is on (server.KEY_BRIDGE "marks"). The page says
// "size" once its listener is up, and again when it grows: the list goes out each time.
let sgOnly = false;                       // the file grid shows only the files that changed
let pgMarksOn = !lsGet("pg-marks-off"), pgMarkAt = 0;
function pgMarksSend() {
  document.querySelector(".media .pgw iframe")?.contentWindow.postMessage({loop: "marks", list: pgMarksOn ? openItem?.quotes || [] : []}, "*");
}
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe");
  if (fr && e.source === fr.contentWindow && e.data?.loop === "size" && openItem?.quotes?.length) pgMarksSend();
});
function pgFind(text, n = 0) {
  document.querySelector(".media .pgw iframe")?.contentWindow.postMessage({loop: "find", text: text.replace(/…$/, ""), n}, "*");
}
document.addEventListener("click", (e) => { const b = e.target.closest?.("button[data-qj]"); if (b) pgFind(b.dataset.qj, +b.dataset.qn); });
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "found") return;
  if (!d.ok) return toast(tl("pgq.gone"));
  const top = fr.getBoundingClientRect().top, how = RM() ? "auto" : "smooth";
  if (fr.closest(".pgw.fit") && Number.isFinite(d.y)) scrollTo({top: scrollY + top + d.y - innerHeight / 3, behavior: how});
  else if (top < 0 || top > innerHeight * 0.6) fr.scrollIntoView({block: "start", behavior: how});
});
// Above the report: how many places its words changed since the version before. A press lists
// them, was over now; a line still in the report goes to its place.
async function pgChgFill(el, aUrl, bUrl, av, bv) {
  const d = await pgDiff(aUrl, bUrl);
  if (!el.isConnected) return;
  if (!d) { const row = el.parentElement; el.remove(); if (!row.children.length) row.remove(); return; }
  const n = d.changes.length;
  el.innerHTML = n ? `<button class="press">${ic("swap")}<b>${tl("pgd.n", {n})}</b><span class="num">${esc(av)} → ${esc(bv)}</span>${ic("chev")}</button>`
    : `<span>${ic("swap")}${d.same ? tl("pgd.same", {v: av}) : tl("pgd.words", {v: av})}</span>`;
  el.querySelector("button")?.addEventListener("click", () => pgChgSheet(d.changes, av, bv));
}
function pgChgSheet(ch, av, bv) {
  const MAX = 60;
  // Two lines that mostly share their words show which words changed; unrelated ones read whole.
  const line = (c) => { const runs = c.was && c.now ? wordDiff(c.was, c.now) : null;
    const kin = !!runs && runs.filter((r) => r.type === "same").reduce((n, r) => n + r.text.length, 0) >= 0.4 * Math.max(c.was.length, c.now.length);
    const side = (txt, drop, tag) => kin ? runs.filter((r) => r.type !== drop).map((r) => r.type === "same" ? esc(r.text) : `<${tag}>${esc(r.text)}</${tag}>`).join("") : tag === "del" ? `<del>${esc(txt)}</del>` : esc(txt);
    return (c.was ? `<span class="was">${side(c.was, "add", "del")}</span>` : "") + (c.now ? `<span class="now">${side(c.now, "del", "ins")}</span>` : ""); };
  sheet(`<h3>${tl("pgd.n", {n: ch.length})}</h3><p class="hint num">${esc(av)} → ${esc(bv)}</p>
    <div class="pgdl">${ch.slice(0, MAX).map((c, n) => c.now ? `<button class="pgd press${c.was ? "" : " new"}" data-pd="${n}">${line(c)}</button>` : `<div class="pgd">${line(c)}</div>`).join("")}</div>
    ${ch.length > MAX ? `<p class="hint">${tl("conflict.more", {n: ch.length - MAX})}</p>` : ""}`, (el) => {
    el.querySelectorAll("[data-pd]").forEach((b) => b.onclick = () => { closeSheet(); pgFind(ch[+b.dataset.pd].go, ch[+b.dataset.pd].n); }); });
}
// 승인 settles every request before it, the ones still open too: those are shown first, once.
function owedSheet(it) {
  sheet(`<h3>${tl("owed.h", {n: it.owed.length})}</h3><p class="hint">${tl("owed.sub")}</p>
    <ul class="owedl">${it.owed.slice(0, 3).map((t) => `<li>${t}</li>`).join("")}</ul>
    <div class="cf-acts"><button class="btn xl fill press" id="owedgo">${tl("conflict.approve")}</button><button class="btn xl press" data-sclose>${tl("finishSheet.4")}</button></div>`, (el) => {
    el.querySelector("#owedgo").onclick = () => { it.owedOk = true; closeSheet(); decide("approved"); }; });
}
// Saved comments go straight on to the session; nothing waits for a second button.
// The session gets one short nudge, not the comments: the hook attaches those on that turn.
let sendSeq = 0;
async function sendNow(it) {
  // A send that failed says why: the comment is still unsent, not "on its way".
  let err = null;
  const r = await post("/api/comments/send", {p: it.p, i: it.i, v: it.v}).catch((e) => { err = e; return null; });
  if (err) { toast(err.message); return; }
  // Did it go straight into a live session, or wait for the hook? Ask the same reach check
  // the app uses, then watch the entries: "delivered" is promised only once one is stamped peer.
  const reach = await get(`/api/session/reach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`).catch(() => null);
  const who = pname(it.dept || "") || tl("sendNow.1"), later = () => tl("sendNow.3", {jo: jo(who, "가", "이")});
  const sent = (r?.log || []).filter((e) => (e.kind === "comment" || e.kind === "message") && handed(e) && !e.ack);
  const ids = sent.filter((e) => !e.delivered).map((e) => e.id);
  // Nothing left to watch: "delivered" only when the log itself shows every one stamped, never on reach alone.
  if (!reach?.reachable || !ids.length) { const ok = !!reach?.reachable && sent.length > 0;
    toast(ok ? tl("sendNow.2", {p0: who}) : later(), 2200, ok ? "delivered" : "later"); return; }
  const me = ++sendSeq, say = (t, ms, m) => { if (me === sendSeq) toast(t, ms, m); };
  say(tl("sendNow.4"), 24000, "sending");
  // Not awaited: callers re-render right after this returns. The courier waits up to 20s for the line.
  (async () => {
    let took = false;
    for (let n = 0; n < 16 && me === sendSeq; n++) {
      await new Promise((ok) => setTimeout(ok, 1500));
      const d = await get(`/api/item?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`).catch(() => null);
      const mine = (d?.log || []).filter((e) => ids.includes(e.id));
      // A comment is never stamped peer: its notice goes into the live session (`nudged`) and
      // the hook attaches the body on the turn that notice starts. That is delivered at once too.
      const now = (e) => e.delivered_via === "peer" || !!(e.nudged && e.delivered);
      if (mine.length && mine.every(now)) return say(tl("sendNow.2", {p0: who}), 2200, "delivered");
      if (mine.length && mine.every((e) => e.delivered)) { took = true; break; }   // the hook took it on a later turn
      if (mine.some((e) => e.delivered && !now(e))) break;
    }
    say(took ? tl("sendNow.2", {p0: who}) : later(), 2200, took ? "delivered" : "later");
  })();
}
// Same "[답]" comment the classic page writes, so departments read answers one way.
// The answers on record: every "[답]" comment of this version, read line by line ("2. 질문 → 답");
// a later answer to the same question replaces the earlier one. An answer written some other way
// (no numbered lines) counts for all the questions, as it always did.
function askAnswers(ask, log, vname) {
  const out = ask.map(() => null);
  (log || []).filter((e) => e.kind === "comment" && e.v === vname && (e.text || "").startsWith("[답]")).forEach((e) => {
    const body = attOf(e.text).words.split("\n").slice(1);
    const ls = body.map((l) => /^(\d+)\.\s.*?→\s*(.+)$/.exec(l.trim())).filter((m) => m && ask[+m[1] - 1]);
    if (ls.length) ls.forEach((m) => { out[+m[1] - 1] = {text: m[2].trim(), at: e.at}; });
    else { const t = body.join(" ").trim() || tl("ask.done"); ask.forEach((q, qi) => { out[qi] = out[qi] || {text: t, at: e.at}; }); }
  });
  return out;
}
const askEdit = {};                       // item id -> the answered questions opened again to change
function wireAsk(it, ask) {
  const box = document.getElementById("ask"), b = document.getElementById("asend"); if (!b) return;
  // Only the questions open on screen are sent: a folded one keeps the answer it has.
  const live = (qi) => box.querySelector(`.aq:not(.done)[data-q="${qi}"]`);
  const pick = ask.map((q, qi) => { const p = +(live(qi)?.dataset.pick ?? -1); return p >= 0 ? p : null; });
  const line = (q, qi) => { const el = live(qi); if (!el) return null; const note = el.querySelector(".anote").value.trim();
    const o = pick[qi] != null ? q.options[pick[qi]] : null;
    return o || note ? `${qi + 1}. ${q.q} → ${[o, note].filter(Boolean).join(" · ")}` : null; };
  // An answer opened to change is sent only once it differs; a question with no answer on
  // record has nothing to differ from, so its preselected recommendation can be sent as it is.
  const was = ask.map((q, qi) => live(qi)?.hasAttribute("data-new") ? null : line(q, qi));
  const lines = () => ask.map(line).filter((l, qi) => l && l !== was[qi]);
  const sync = () => { b.disabled = !lines().length; };
  box.querySelectorAll(".aq:not(.done)").forEach((el) => { const qi = +el.dataset.q;
    el.querySelectorAll(".opt").forEach((o) => o.onclick = () => { pick[qi] = pick[qi] === +o.dataset.a ? null : +o.dataset.a;
      el.querySelectorAll(".opt").forEach((q) => q.classList.toggle("on", +q.dataset.a === pick[qi])); sync(); });
    const t = el.querySelector(".anote"); cmGrow(t);
    t.oninput = () => { cmGrow(t); sync(); };
    t.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing) e.preventDefault(); }; });
  sync();
  b.onclick = async () => { const L = lines(); if (!L.length) return; b.disabled = true;
    try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: `[답]\n${L.join("\n")}`});
      // An answer is not a rejection: "지금 그대로" came back labelled 수정 요청.
      delete askEdit[it.id]; tabPick[it.id] = "ask";
      sendNow(it); await load(); again(); }
    catch (e) { toast(e.message); b.disabled = false; } };
}
// 승인 is the everyday yes. 확정 (done) is the last word: approved, archived, and the
// department told the work is over - a new push brings the item back either way.
// A decision on the newest version is the end of that look: go straight on to the next one
// waiting, so running through the list is decide, decide, decide - not back, find, open.
async function onward(it, said) {
  const n = it.latest && nextOf(it.id);
  await load();
  // In the workroom the result stays on its stage: the room is the place, not the next item.
  if (wrLive()) { toast(said); again(); return; }
  if (n && D.items.some((x) => iid(x) === iid(n))) { toast(tl("onward.1", {said})); autoPlay = true; nav("item/" + iid(n)); }
  else { toast(said); render(); }
}
let deciding = false;                     // a second A or double-click must not decide twice
// An approval waits five seconds before it goes, so a slipped A can be taken back before the
// department hears of it. Leaving the page sends it at once.
let okLater = null;
function sendOk() {
  const o = okLater; if (!o) return Promise.resolve(); okLater = null; clearTimeout(o.timer);
  // The approval names the review revision this screen read: if a version or an ask landed in
  // the five seconds (or before), the server says 409 and the reader sees what changed first.
  return fetch("/api/status", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: o.it.p, i: o.it.i, v: o.it.v, status: "approved", rev: o.it.rev})})
    .then(async (r) => { if (!r.ok) { const j = await r.json().catch(() => ({})); throw Object.assign(new Error(j.error || tl("get.1")), {status: r.status, body: j}); } })
    .catch((e) => isConflict(e) && !document.hidden ? approveConflict(o.it, e.body)
      // The screen has usually moved on to the next result by now, so a toast that fades would
      // leave the reader believing it was approved: it stays up with a way to send it again.
      : toastAct(tl("sendOk.2", {p0: e.message === "Failed to fetch" ? tl("sendOk.1") : e.message}), tl("room.retry"),
        // Sent directly, not through okLater: another approval may be waiting out its five seconds there.
        () => post("/api/status", {p: o.it.p, i: o.it.i, v: o.it.v, status: "approved", rev: o.it.rev})
          .then(() => { toast(tl("decide.1", {p0: pname(o.it.dept || "") || tl("lib.3")})); return load().then(render); })
          .catch((e2) => isConflict(e2) ? approveConflict(o.it, e2.body) : toast(tl("sendOk.2", {p0: e2.message}), 8000)), 30000));
}
function approveConflict(it, body) {
  conflictSheet(body, {v: it.v, log: it.log, again: tl("conflict.approve"),
    retry: async (b) => { await post("/api/status", {p: it.p, i: it.i, v: it.v, status: "approved", rev: b.rev}); toast(tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")})); await load(); render(); },
    reload: async () => { await load(); if (detail?.[0] === "item" && openItem?.id === it.id) again(); else nav("item/" + it.id); }});
}
addEventListener("pagehide", () => { sendOk(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) sendOk(); });
async function decide(status) {
  const it = openItem || {};
  if (deciding) return;
  if (status === "changes") return openCmt();
  if (status === "done") return finishSheet(it);
  if (status === "approved" && it.owed?.length && !it.owedOk) return owedSheet(it);
  if (status === "approved") {
    await sendOk();                          // one held at a time
    const n = it.latest && nextOf(it.id);
    const o = okLater = {it};                // sent when the toast's time is up (it waits while the toast is held)
    toastAct(tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")}), tl("toggleFav.3"), () => {
      if (!okLater) return toast(tl("decide.2"));
      clearTimeout(okLater.timer); const back = okLater.it; okLater = null;
      toast(tl("approveMany.3"), 2200, "undo"); wrLive() ? again() : nav("item/" + back.id); }, 5000, "approve",
      () => { if (okLater === o) sendOk().then(load).then(() => {
        if (wrLive()) again(); else if (!document.activeElement?.matches?.("input,textarea,gk-select")) render(); }); });
    // On a stage the result stays put; its buttons wait out the five seconds the approval can be taken back.
    if (wrLive()) { const c = stageMount.el.querySelector(".decide"); if (c) { c.querySelectorAll("button").forEach((b) => { b.disabled = true; }); c.querySelector("p").textContent = tl("decide.3"); } return; }
    if (n && D.items.some((x) => iid(x) === iid(n))) { autoPlay = true; nav("item/" + iid(n)); }
    else back();
    return;
  }
  deciding = true;
  try {
    if (status === "reopen") {
      await post("/api/archive", {p: it.p, i: it.i, on: false});
      toast(tl("decide.4"), 2200, "undo");
    } else {
      await post("/api/status", {p: it.p, i: it.i, v: it.v, status});
      if (status === "approved") return await onward(it, tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")}));
      toast(tl("decide.5"), 2200, "undo");
    }
    await load(); wrLive() ? again() : render();
  } catch (e) { toast(e.message); }
  finally { deciding = false; }
}
function finishSheet(it) {
  sheet(`<h3>${tl("finishSheet.1")}</h3><p class="hint">${more1(tl("finishSheet.2"), tl("finishSheet.3"))}</p>
    <div class="cf-acts"><button class="btn xl fill press" id="fin">${tl("itemView.57")}</button><button class="btn xl press" data-sclose>${tl("finishSheet.4")}</button></div>`, (el) => {
    const b = el.querySelector("#fin");
    b.onclick = async () => { b.disabled = true;
      try {
        if (it.status !== "approved") await post("/api/status", {p: it.p, i: it.i, v: it.v, status: "approved", rev: it.rev}).catch((e) => {
          if (isConflict(e)) { closeSheet(); setTimeout(() => approveConflict(it, e.body), 280); e.shown = true; } throw e; });
        await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: "[확정] 이 작업은 끝났어요. 더 고칠 것 없어요."});
        await post("/api/comments/send", {p: it.p, i: it.i, v: it.v}).catch(() => null);
        await post("/api/archive", {p: it.p, i: it.i, on: true});
        await post("/api/storage/final", {p: it.p, i: it.i, v: it.v}).catch(() => null);   // 확정 = also the 최종본
        closeSheet(); toast(tl("finishSheet.5"), 2600, "finish"); await load(); wrLive() ? again() : render();
      } catch (e) { if (!e.shown) toast(e.message); b.disabled = false; } };
  });
}
// ---------- full-screen viewer: swipe between a version's files ----------
// The strip follows the finger 1:1, keeps the release velocity, projects where the flick
// was going and settles on a spring from wherever it is - so it can be caught mid-flight.
const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function springTo(get0, set, to, v0, done, response = 0.36, damping = 1) {
  const k = (2 * Math.PI / response) ** 2, c = 4 * Math.PI * damping / response;
  let x = get0(), v = v0, last = performance.now(), id, dead = false;
  const step = (now) => { const dt = Math.min(0.032, (now - last) / 1000); last = now;
    for (let n = 0; n < 4; n++) { const a = -k * (x - to) - c * v; v += a * dt / 4; x += v * dt / 4; }
    if (Math.abs(x - to) < 0.3 && Math.abs(v) < 8) { set(to); done && done(); return; }
    // set() may stop this very spring (a card that flew far enough hands over): no next frame then.
    set(x); if (!dead) id = requestAnimationFrame(step); };
  id = requestAnimationFrame(step);
  return () => { dead = true; cancelAnimationFrame(id); };
}
const project = (v, r = 0.998) => (v / 1000) * r / (1 - r);
function viewer(files, start, it = openItem, from = null) {
  if (!files.length) return;
  const el = document.createElement("div"); el.className = "vw"; el.setAttribute("role", "dialog"); el.setAttribute("aria-label", tl("itemView.38"));
  el.innerHTML = `<div class="vbg"></div><div class="vtrack">${files.map((f) => `<div class="vs">${f.kind === "video"
      ? `<video src="${esc(f.play || f.url)}" loop playsinline preload="metadata" ${sound() ? "" : "muted"} ${f.thumb ? `poster="${esc(f.thumb)}"` : ""}></video>`
      : `<img src="${esc(f.url)}" alt="${esc(f.name)}" draggable="false">`}</div>`).join("")}</div>
    <div class="vspin" hidden>${loadingHtml("", {tight: true})}</div>
    <div class="vtop"><span class="vn num"></span><span class="vname"></span><button class="ib press vplay" type="button" hidden aria-label="${tl("itemView.39")}">${ic("play")}</button><span class="vz num"></span>${files.length > 1 ? `<button class="ib press vsb" type="button" aria-label="${tl("viewer.strip")}" title="${tl("viewer.strip")}">${ic("grid")}</button>` : ""}<a class="ib press" target="_blank" rel="noopener" aria-label="${tl("viewer.3")}">${ic("ext")}</a><button class="ib press" data-vclose aria-label="${tl("itemView.114")}">${ic("x")}</button></div>
    ${files.length > 1 ? `<button class="vnav l press" aria-label="${tl("itemView.27")}">${ic("chev")}</button><button class="vnav r press" aria-label="${tl("itemView.28")}">${ic("chev")}</button>` : ""}
    <div class="vscrub" hidden><u class="fill"></u><i class="ph"></i></div>
    ${files.length > 1 ? `<div class="vstrip">${files.map((f, n) => `<button class="vt press" type="button" data-vt="${n}" aria-label="${esc(f.name)}">${f.kind === "video" && !f.thumb ? ic("play") : `<img src="${esc(f.kind === "video" ? f.thumb : f.url)}" alt="" loading="lazy" draggable="false">`}</button>`).join("")}</div>` : ""}
    ${it?.p ? `<form class="vcm"><input placeholder="${tl("viewer.1")}" autocomplete="off" enterkeyhint="send"><button class="press" aria-label="${tl("viewer.2")}">${ic("up")}</button></form>` : ""}`;
  document.body.appendChild(el);
  el.querySelectorAll("video").forEach((vd) => { vd.playbackRate = rate; });
  const tr = el.querySelector(".vtrack"), bg = el.querySelector(".vbg"), W = () => el.clientWidth, H = () => el.clientHeight;
  let idx = start, x = -start * W(), y = 0, stop = null, stopY = null, stopZ = null, wrote = false;
  // Zoom of the picture on screen: scale and offset from its resting centre.
  let z = {s: 1, tx: 0, ty: 0};
  // A paused video frame zooms like a picture: render noise and edges need a close look too.
  const media = () => { const s = tr.children[idx], v = s?.querySelector("video"); return s?.querySelector("img") || (v && (v.paused || z.s > 1.02) ? v : null); };
  const paintZ = () => { const m = media(); if (m) m.style.transform = z.s === 1 && !z.tx && !z.ty ? "" : `translate3d(${z.tx}px,${z.ty}px,0) scale(${z.s})`;
    el.querySelector(".vz").textContent = z.s > 1.02 ? `${Math.round(z.s * 100)}%` : ""; el.classList.toggle("zoomed", z.s > 1.02); };
  const bounds = (s) => { const m = media(); if (!m) return {x: 0, y: 0};
    const w = m.offsetWidth * s, h = m.offsetHeight * s; return {x: Math.max(0, (w - W()) / 2), y: Math.max(0, (h - H()) / 2)}; };
  const zoomTo = (s, tx, ty) => { stopZ && stopZ(); const b = bounds(s), to = {s, tx: Math.max(-b.x, Math.min(b.x, tx)), ty: Math.max(-b.y, Math.min(b.y, ty))}, from = {...z};
    if (RM()) { z = to; paintZ(); return; }
    let t = 0; stopZ = springTo(() => t, (v) => { t = v; z = {s: from.s + (to.s - from.s) * v, tx: from.tx + (to.tx - from.tx) * v, ty: from.ty + (to.ty - from.ty) * v}; paintZ(); }, 1, 0, () => { z = to; paintZ(); }, 0.3, 1); };
  // Zoom about a screen point: the spot under the finger or cursor stays put.
  const about = (s, px, py, base = z) => { const cx = W() / 2, cy = H() / 2;
    return {s, tx: (px - cx) - ((px - cx) - base.tx) / base.s * s, ty: (py - cy) - ((py - cy) - base.ty) / base.s * s}; };
  const unzoom = () => { stopZ && stopZ(); const m = media(); if (m) m.style.transform = ""; z = {s: 1, tx: 0, ty: 0}; paintZ(); };
  const paint = () => { tr.style.transform = `translate3d(${x}px,${y}px,0)`; bg.style.opacity = String(1 - Math.min(0.6, Math.abs(y) / 500)); };
  // A video here steps frames like the stage does; the frame shows where the zoom % would.
  const vidAt = () => tr.children[idx]?.querySelector("video") || null;
  const frameNow = () => { const vd = vidAt(), f = files[idx]; if (vd) el.querySelector(".vz").textContent = f.fps ? `f${frameOf(vd.currentTime, f.fps)}` : clock(vd.currentTime, true); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt()) frameNow(); })));
  // §4.14: native controls는 없앴으니 재생버튼·스크럽바·버퍼링 스피너를 직접 그린다.
  const vplayBtn = el.querySelector(".vplay"), vscrub = el.querySelector(".vscrub"), vspin = el.querySelector(".vspin");
  const updatePlayIcon = (vd) => { if (!vplayBtn) return;
    const playing = vd && !vd.paused;
    vplayBtn.innerHTML = ic(playing ? "pause" : "play");
    vplayBtn.setAttribute("aria-label", tl(playing ? "showPlay.1" : "itemView.39")); };
  const putScrub = (vd) => { if (!vscrub) return; const dur = Number.isFinite(vd.duration) && vd.duration > 0 ? vd.duration : 1;
    const f = Math.min(1, Math.max(0, vd.currentTime / dur)) * 100;
    vscrub.querySelector(".fill").style.width = f + "%"; vscrub.querySelector(".ph").style.left = f + "%"; };
  vplayBtn?.addEventListener("click", () => { const vd = vidAt(); if (!vd) return; vd.paused ? playNow(vd) : vd.pause(); });
  let scrubbing = false, scrubWasPlaying = false;
  const seekTo = (clientX) => { const vd = vidAt(); if (!vd || !vscrub) return;
    const r = vscrub.getBoundingClientRect(), dur = Number.isFinite(vd.duration) && vd.duration > 0 ? vd.duration : 1;
    vd.currentTime = Math.min(1, Math.max(0, (clientX - r.left) / r.width)) * dur; putScrub(vd); };
  vscrub?.addEventListener("pointerdown", (e) => { const vd = vidAt(); if (!vd) return; e.preventDefault();
    try { vscrub.setPointerCapture(e.pointerId); } catch {} scrubbing = true; scrubWasPlaying = !vd.paused; vd.pause(); seekTo(e.clientX); });
  vscrub?.addEventListener("pointermove", (e) => { if (scrubbing) seekTo(e.clientX); });
  const scrubEnd = (e) => { if (!scrubbing) return; scrubbing = false; try { vscrub.releasePointerCapture(e.pointerId); } catch {}
    if (scrubWasPlaying) playNow(vidAt()); };
  vscrub?.addEventListener("pointerup", scrubEnd); vscrub?.addEventListener("pointercancel", scrubEnd);
  tr.querySelectorAll("video").forEach((vd) => {
    vd.addEventListener("play", () => { if (vd === vidAt()) updatePlayIcon(vd); });
    vd.addEventListener("pause", () => { if (vd === vidAt()) updatePlayIcon(vd); });
    vd.addEventListener("waiting", () => { if (vd === vidAt() && vspin) vspin.hidden = false; });
    ["playing", "canplay"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt() && vspin) vspin.hidden = true; }));
    ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt() && !scrubbing) putScrub(vd); }));
  });
  const label = () => { el.querySelector(".vn").textContent = files.length > 1 ? `${idx + 1} / ${files.length}` : ""; frameNow();
    el.querySelector(".vname").textContent = files[idx].name; el.querySelector(".vtop a").href = files[idx].url;
    el.querySelectorAll("video").forEach((vd, n) => { if (n !== idx) vd.pause(); });
    const vd = vidAt();
    el.classList.toggle("vid", !!vd);
    el.querySelectorAll(".vt").forEach((b, n) => b.classList.toggle("on", n === idx));
    el.querySelector(".vt.on")?.scrollIntoView({block: "nearest", inline: "nearest"});
    if (vplayBtn) vplayBtn.hidden = !vd; if (vscrub) vscrub.hidden = !vd; if (vspin) vspin.hidden = true;
    if (vd) { updatePlayIcon(vd); putScrub(vd); } };
  const vidOf = (n) => tr.children[n]?.querySelector("video");
  const go = (n, vel = 0, glide = false) => { const was = idx; idx = Math.max(0, Math.min(files.length - 1, n));
    if (was !== idx) { const m = tr.children[was]?.querySelector("img"); if (m) m.style.transform = ""; z = {s: 1, tx: 0, ty: 0}; paintZ(); }
    label(); stop && stop();
    if (was !== idx) playNow(vidOf(idx));
    if (!glide && was !== idx) { x = -idx * W(); y = 0; paint(); return; }
    if (RM()) { x = -idx * W(); y = 0; tr.style.transition = "opacity .2s"; tr.style.opacity = ".4"; paint(); requestAnimationFrame(() => tr.style.opacity = "1"); return; }
    stop = springTo(() => x, (v) => { x = v; paint(); }, -idx * W(), vel, null, 0.34, 1);
    if (y) { stopY && stopY(); stopY = springTo(() => y, (v) => { y = v; paint(); }, 0, 0, null, 0.3, 1); } };
  // popped: the phone's back button already took our history entry; otherwise we take it back ourselves.
  const close = (popped) => { vwClose = null; stop && stop(); stopY && stopY(); stopZ && stopZ(); removeEventListener("keydown", key); removeEventListener("resize", fit);
    removeEventListener("popstate", pop);
    if (popped !== true && history.state?.vw) history.back();
    const lv = vidAt(), lt = lv ? lv.currentTime : 0, lp = !!lv && !lv.paused;
    el.querySelectorAll("video").forEach((vd) => vd.pause());
    if (wrote) again();
    if (from?.back && lv && idx === start) from.back(lt, lp);
    if (RM()) { el.remove(); return; }
    el.classList.add("out"); setTimeout(() => el.remove(), 220); };
  const key = (e) => { if (e.target.closest?.(".vcm")) { if (e.key === "Escape") e.target.blur(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;   // Ctrl +/-/0 is the browser's zoom
    if (e.key === "Escape") { if (z.s > 1.02) zoomTo(1, 0, 0); else close(); }
    else if (vidAt() && (e.key === "ArrowRight" || e.key === "ArrowLeft")) { e.preventDefault(); stepVideo(vidAt(), files[idx], (e.key === "ArrowRight" ? 1 : -1) * (e.shiftKey ? 10 : 1)); }
    else if (vidAt() && (e.key === "s" || e.key === "S")) nextRate();
    else if (vidAt() && e.key === " ") { e.preventDefault(); const vd = vidAt(); vd.paused ? vd.play().catch(() => {}) : vd.pause(); }
    else if (e.key === "ArrowRight") go(idx + 1); else if (e.key === "ArrowLeft") go(idx - 1);
    else if (e.key === "+" || e.key === "=") zoomTo(Math.min(6, z.s * 1.5), z.tx * 1.5, z.ty * 1.5);
    else if (e.key === "-") zoomTo(Math.max(1, z.s / 1.5), z.tx / 1.5, z.ty / 1.5);
    else if (e.key === "0") zoomTo(1, 0, 0); };
  addEventListener("keydown", key); vwClose = close;
  // Back on a phone closes full screen and stays on the result (it used to leave to the list).
  const pop = () => close(true);
  try { history.pushState({vw: 1}, ""); addEventListener("popstate", pop); } catch (e) {}
  if (from && vidOf(start)) { const vd = vidOf(start), seek = () => { try { vd.currentTime = from.t; } catch (e) {} if (from.play) playNow(vd); };
    vd.readyState >= 1 ? seek() : vd.addEventListener("loadedmetadata", seek, {once: true}); }
  const fit = () => { stop && stop(); unzoom(); x = -idx * W(); paint(); }; addEventListener("resize", fit);
  el.querySelector("[data-vclose]").onclick = () => close();
  // The file strip along the bottom: every file of the version, folded or shown by the button
  // in the top bar. The choice is kept for the next time.
  const vsb = el.querySelector(".vsb"), stripSet = (on) => { el.classList.toggle("strip", on); vsb.setAttribute("aria-pressed", String(on)); };
  if (vsb) { let on = true; try { on = localStorage.getItem("vstrip") !== "0"; } catch (e) {}
    stripSet(on);
    vsb.onclick = () => { on = !on; stripSet(on); try { localStorage.setItem("vstrip", on ? "1" : "0"); } catch (e) {} };
    el.querySelector(".vstrip").onclick = (e) => { const b = e.target.closest("[data-vt]"); if (b) go(+b.dataset.vt); }; }
  el.querySelector(".vnav.l")?.addEventListener("click", () => go(idx - 1));
  el.querySelector(".vnav.r")?.addEventListener("click", () => go(idx + 1));
  // A comment from here says which file it is about.
  const form = el.querySelector(".vcm");
  form?.querySelector("input").addEventListener("focus", () => vidAt()?.pause());
  if (form) form.onsubmit = async (e) => { e.preventDefault(); const i = form.querySelector("input"), text = i.value.trim(); if (!text) return;
    i.disabled = true;
    const at = whenOf(el.querySelectorAll(".vs")[idx]?.querySelector("video"), files[idx]);
    try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: `[${[files[idx].name, at].filter(Boolean).join(" ")}] ${text}`}); i.value = ""; wrote = true; await sendNow(it); }
    catch (err) { toast(err.message); }
    i.disabled = false; };
  // Pointers: one finger pages (or pans when zoomed), vertical dismisses, two fingers pinch,
  // a double tap zooms in on that spot or back out. Every one follows the finger 1:1.
  const pts = new Map(); let drag = null, pinch = null, lastTap = null, tapTimer = null;
  tr.addEventListener("pointerdown", (e) => { if (onControls(e) || (files.length === 1 && e.target.closest("video"))) return;
    pts.set(e.pointerId, [e.clientX, e.clientY]);
    stop && stop(); stopY && stopY(); stopZ && stopZ();
    if (pts.size === 2 && media()) { const [a, b] = [...pts.values()]; drag = null;
      pinch = {d0: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, m0: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], z0: {...z}};
      pts.forEach((_, id) => { try { tr.setPointerCapture(id); } catch {} }); return; }
    if (pts.size > 2) return;
    drag = {id: e.pointerId, sx: e.clientX, sy: e.clientY, x0: x, z0: {...z}, axis: null, h: [[e.clientX, e.clientY, e.timeStamp]], img: !!e.target.closest("img")}; });
  tr.addEventListener("pointermove", (e) => { if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, [e.clientX, e.clientY]);
    if (pinch && pts.size >= 2) { const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]), m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
      let s = pinch.z0.s * d / pinch.d0; if (s < 1) s = 1 - rubber(1 - s, 1, 0.4); if (s > 8) s = 8;
      const r = about(s, pinch.m0[0], pinch.m0[1], pinch.z0); z = {s, tx: r.tx + m[0] - pinch.m0[0], ty: r.ty + m[1] - pinch.m0[1]}; paintZ(); return; }
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.axis) { if (Math.hypot(dx, dy) < 10) return; drag.axis = drag.z0.s > 1.02 ? "pan" : Math.abs(dx) > Math.abs(dy) ? "x" : "y"; tr.setPointerCapture(e.pointerId); }
    drag.h.push([e.clientX, e.clientY, e.timeStamp]); if (drag.h.length > 5) drag.h.shift();
    if (drag.axis === "pan") { const b = bounds(z.s); let tx = drag.z0.tx + dx, ty = drag.z0.ty + dy;
      if (tx > b.x) tx = b.x + rubber(tx - b.x, W()); else if (tx < -b.x) tx = -b.x - rubber(-b.x - tx, W());
      if (ty > b.y) ty = b.y + rubber(ty - b.y, H()); else if (ty < -b.y) ty = -b.y - rubber(-b.y - ty, H());
      z = {...z, tx, ty}; paintZ(); return; }
    if (drag.axis === "x") { let nx = drag.x0 + dx; const min = -(files.length - 1) * W();
      if (nx > 0) nx = rubber(nx, W()); else if (nx < min) nx = min - rubber(min - nx, W()); x = nx; }
    else y = dy;
    paint(); });
  const up = (e) => { if (!pts.has(e.pointerId)) return; pts.delete(e.pointerId);
    if (pinch) { if (pts.size < 2) { pinch = null; drag = null; zoomTo(z.s < 1.05 ? 1 : z.s, z.s < 1.05 ? 0 : z.tx, z.s < 1.05 ? 0 : z.ty); } return; }
    if (!drag || e.pointerId !== drag.id) return; const d = drag; drag = null;
    const a = d.h[0], b = d.h[d.h.length - 1], dt = Math.max(1, b[2] - a[2]), vx = (b[0] - a[0]) / dt * 1000, vy = (b[1] - a[1]) / dt * 1000;
    if (!d.axis) {                                           // a tap
      const now = e.timeStamp;
      if (lastTap && now - lastTap.t < 300 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 30 && media()) {
        clearTimeout(tapTimer); lastTap = null;
        if (z.s > 1.02) zoomTo(1, 0, 0); else { const r = about(2.5, e.clientX, e.clientY, {s: 1, tx: 0, ty: 0}); zoomTo(2.5, r.tx, r.ty); }
        return; }
      lastTap = {t: now, x: e.clientX, y: e.clientY};
      // One tap beside the picture closes, once it is clear no second tap is coming.
      if (!d.img && z.s <= 1.02) { clearTimeout(tapTimer); tapTimer = setTimeout(close, 300); }
      return; }
    if (d.axis === "pan") { const t = 0.35; zoomTo(z.s, z.tx + vx * t / 2, z.ty + vy * t / 2); return; }
    if (d.axis === "y") { if (Math.abs(y) + Math.abs(project(vy)) * 0.3 > 140) return close(); return go(idx, 0, true); }
    const target = Math.round(-(x + project(vx)) / W());
    go(Math.max(idx - 1, Math.min(idx + 1, target)), vx, true); };
  tr.addEventListener("pointerup", up); tr.addEventListener("pointercancel", up);
  tr.addEventListener("wheel", (e) => { if (!media()) return; e.preventDefault();
    const s = Math.max(1, Math.min(8, z.s * Math.exp(-e.deltaY * 0.0015)));
    if (s === 1) { z = {s: 1, tx: 0, ty: 0}; paintZ(); return; }
    const r = about(s, e.clientX, e.clientY), b = bounds(s);
    z = {s, tx: Math.max(-b.x, Math.min(b.x, r.tx)), ty: Math.max(-b.y, Math.min(b.y, r.ty))}; paintZ(); }, {passive: false});
  paint(); label();
  if (!RM()) { el.classList.add("from"); requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("from"))); }
}
const rubber = (o, d, c = 0.55) => (o * d * c) / (d + c * Math.abs(o));
function rejectSheet(it) {
  const opts = it.reject.length ? rejectList(it.reject) : [tl("rejectSheet.1"), tl("rejectSheet.2"), tl("rejectSheet.3"), tl("rejectSheet.4")];
  // The words come first: a pick alone told the department too little (user, 2026-09-29).
  sheet(`<h3>${tl("rejectSheet.5")}</h3>
    <textarea id="rj" rows="3" enterkeyhint="send" placeholder="${tl("rejectSheet.6")}"></textarea>
    <div class="sub rjq">${tl("rejectSheet.7")}</div><div class="opts">${opts.map((o, n) => `<button class="opt press" data-opt="${n}">${esc(o)}</button>`).join("")}</div>
    <button class="btn xl fill press" id="rjs" disabled>${tl("rejectSheet.8")}</button>`, (el) => {
    let pick = null; const t = el.querySelector("#rj"), b = el.querySelector("#rjs");
    const sync = () => { b.disabled = pick == null && !t.value.trim(); };
    el.querySelectorAll(".opt").forEach((o) => o.onclick = () => { pick = pick === +o.dataset.opt ? null : +o.dataset.opt;
      el.querySelectorAll(".opt").forEach((q) => q.classList.toggle("on", +q.dataset.opt === pick)); sync(); });
    t.oninput = sync; enterSends(t, b);
    b.onclick = async () => { b.disabled = true; await settled(t);
      const words = [pick != null ? opts[pick] : null, t.value.trim()].filter(Boolean).join(" · ");
      if (!words) { b.disabled = false; return; }
      try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: pick != null ? `[거절] ${words}` : words});
        await toChanges({...it, latest: true}); sendNow(it);   // list rows are always the newest version
        closeSheet(); await onward(it, tl("rejectSheet.9", {p0: pname(it.dept || "") || tl("lib.3")}));
      } catch (e) { toast(e.message); b.disabled = false; } };
  });
}
SCREENS.item = () => { const x = myTurn()[0] || D.items.slice().sort(byAt)[0];
  if (x) setTimeout(() => location.replace("#item/" + iid(x)));
  else V().innerHTML = `<div class="card plan none">${mEmpty("emptyInbox")}<p>${tl("item.1")}</p></div>`; return {}; };

// ---------- 부서 ----------
// Forty-odd departments: a state chip narrows to one kind, typing narrows by name or bundle.
// The 30s refresh redraws only the list, so the search box keeps its focus and text.
let deptQ = "";
SCREENS.dept = function () {
  if (!document.getElementById("dpq")) {
    V().innerHTML = `<div class="field">${ic("search")}<input id="dpq" type="search" enterkeyhint="search" placeholder="${tl("dept.1")}" autocomplete="off"></div><div id="dls"></div>`;
    const i = document.getElementById("dpq"); i.value = deptQ;
    i.oninput = () => { deptQ = i.value; SCREENS.dept(); };
  }
  const q = deptQ.trim().toLowerCase(), all = projects().filter((g) => !q || g.name.toLowerCase().includes(q) || pname(g.name).toLowerCase().includes(q));
  const L = all.filter((g) => !inShelf(g.name)), arc = all.filter((g) => inShelf(g.name)), an = shelfNums(arc);
  const P = L.filter((g) => isPinned(g.name)), rest = L.filter((g) => !isPinned(g.name));
  const card = (h, xs, more = "") => xs.length ? `<div class="card" data-pjsort><div class="ch">${h}<span class="n num">${xs.length}</span><span class="sp"></span>${more}</div>${xs.map(deptRow).join("")}<div style="height:10px"></div></div>` : "";
  // Archived projects collapse into one card that opens on click, mirroring the sidebar fold.
  // Shelved ones sit at the bottom: one line naming them by number, opening in place.
  const archCard = arc.length ? `<div class="card"><button class="ch archfold press" data-archx aria-expanded="${showArch}">${ic("archive")}<h2>${tl("archFold.2")}</h2><span class="n num">${arc.length}</span>${an ? `<span class="shnums num">${esc(an)}</span>` : `<span class="sp"></span>`}${ic("chev")}</button>${shelfFold(arc.map(deptRow).join("") + `<div style="height:10px"></div>`)}</div>` : "";
  document.getElementById("dls").innerHTML = all.length
    ? card(`<h2 class="pinh">${tl("dept.2", {ic: ic("star")})}</h2>`, P, P.length > 1 ? `<button class="link" data-sortsheet="pins">${tl("dept.3")}</button>` : "") + card(tl("dept.4"), rest) + archCard
    : `<div class="card plan none"><p>${D.items.length ? tl("dept.5", {esc: esc(deptQ)}) : tl("dept.6")}</p></div>`;
  // The pinned and the other projects are each put in order within their own card.
  document.querySelectorAll("#dls [data-pjsort]").forEach((c) => pjSort(c, ".row[data-dept]", SCREENS.dept));
};
// The project page is a result grid, like the library scoped to one department: status filter
// chips, a card for every result (all of them, never a silent cap), per-card approve/맡기기/치우기,
// and a select mode for approving several at once. deptF/deptSel are kept per department; they
// reset when the reader opens another one.
let deptF = "all", deptKey = "", deptSel = null;
// 목록 or 보드 (web/boardview.js), kept per device.
const deptV = (v) => { try { if (v === undefined) return localStorage.getItem("v2-dview") === "board" ? "board" : "list"; localStorage.setItem("v2-dview", v); } catch { return "list"; } };
const redrawDept = () => { if (detail && detail[0] === "dept") deptView(detail[1]); };
function deptView(key) {
  const g = projects().find((x) => x.name === key);
  if (!g) { V().innerHTML = `<div class="card plan none"><p>${tl("deptView.1")}</p></div>`; head(""); return; }
  if (deptKey !== key) { deptKey = key; deptF = "all"; deptSel = null; }
  const all = g.items.filter((x) => !libHide.has(iid(x))).sort(byAt);
  const reqs = D.board.filter((b) => b.dept === g.name);
  head(esc(pname(g.name)));
  const brd = deptV() === "board" && !!window.BoardView;   // the board shows every result: its cards carry their own state
  const its = all.filter((x) => brd || deptF === "all" || stOf(x) === deptF);
  if (brd) deptSel = null;
  const sel = deptSel && its.filter((x) => deptSel.has(iid(x)));
  const gcard = (x) => `<div class="gw"><button class="gi press${deptSel?.has(iid(x)) ? " picked" : ""}" ${deptSel ? `data-dpick="${esc(iid(x))}" aria-pressed="${deptSel.has(iid(x))}"` : `data-item="${esc(iid(x))}"`}>
      <div class="th">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.kind === "video" ? `<span class="vbadge">${ic("play")}</span>` : ""}${stK(x) !== "approved" ? `<span class="tag ${stCls(x)}"${stTip(x)}>${stName(x)}</span>` : ""}${deptSel ? `<span class="pk">${ic("check")}</span>` : ""}</div>
      <div class="tx"><div class="t">${esc(x.title)}</div><div class="s gm"><span class="gmn">${gname(x) === g.name ? "" : `<span class="gpn">${esc(pname(gname(x)))}</span>`}<span class="grest">${gname(x) === g.name ? "" : " · "}${vShort(x.v)} · ${ago(x.at)}${window.resMeta ? resMeta(x) : ""}</span></span></div></div></button>${deptSel ? "" : gmore(x)}</div>`;
  // A full-width project page: a plain header (no card), an optional 보낸 요청 line only when
  // there is one, then the results as a proper full-width grid — not squeezed into a side column.
  V().innerHTML = `<div class="deptpage">
    <div class="pagehead">${deptIco(g, "ico phic")}<div class="phtx"><h1 class="pht">${esc(pname(g.name))}</h1><div class="phs">${tl("deptView.5", {n: all.length, p3: g.at ? " · " + ago(g.at) : ""})}</div></div><span class="sp"></span><button class="btn sm weak press" data-go="project/${esc(g.name)}">${tl("menu.chat")}</button>${pinBtn(g.name, "big")}${archBtn(g.name, "big")}</div>
    ${reqs.length ? `<div class="card reqcard"><div class="ch"><h2>${tl("deptView.6")}</h2><span class="n num">${reqs.length}</span></div>${reqs.map((b) => `<div class="row">${thumb(b, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(b.title)}</div><div class="s">${{waiting:tl("deptView.2"),delivered:tl("itemView.123"),ack:tl("deptView.3"),done:tl("hitRow.1")}[b.state] || ""} · ${ago(b.asked)}</div></span></div>`).join("")}<div style="height:8px"></div></div>` : ""}
    <div class="ch rhead"><h2>${tl("TABS.3")}</h2><span class="n num">${all.length}</span><span class="sp"></span>${all.length && window.BoardView ? `<div class="seg dvseg" role="group" aria-label="${tl("board.view")}">${[["list", tl("res.tab.list")], ["board", tl("board.board")]].map(([k, n]) => `<button class="press${(k === "board") === brd ? " on" : ""}" aria-pressed="${(k === "board") === brd}" data-dview="${k}">${n}</button>`).join("")}</div>` : ""}${all.length > 1 && !brd ? `<button class="btn sm weak press" data-dsel>${deptSel ? tl("libDraw.12") : tl("libDraw.13")}</button>` : ""}</div>
    ${brd ? "" : stTabs(all, deptF, "df")}
    ${deptSel ? `<div class="selrow"><span>${sel.length ? `<b class="num">${sel.length}</b>${tl("libDraw.10")}` : tl("libDraw.11", {n: its.length})}</span><button class="lnk press" data-dall>${its.length && sel.length === its.length ? tl("libDraw.15") : tl("libDraw.16")}</button>${sel.length ? `<button class="btn sm fill press" data-dok>${tl("libDraw.20", {size: sel.length})}</button>` : ""}</div>` : ""}
    ${its.length ? brd ? `<div class="bdhost" id="bdhost"></div>` : `<div class="gal z-m dgal">${its.map(gcard).join("")}</div>` : `<div class="card plan none">${stNone(deptF)}</div>`}
  </div>`;
  stStrip(V());
  V().querySelectorAll("[data-df]").forEach((b) => b.onclick = () => { deptF = b.dataset.df; deptSel = null; deptView(key); });
  V().querySelectorAll("[data-dview]").forEach((b) => b.onclick = () => { deptV(b.dataset.dview); deptView(key); });
  if (brd && its.length) BoardView.draw(document.getElementById("bdhost"), key, its);
  V().querySelector("[data-dsel]")?.addEventListener("click", () => { deptSel = deptSel ? null : new Set(); deptView(key); });
  V().querySelectorAll("[data-dpick]").forEach((b) => b.onclick = () => { const k = b.dataset.dpick; deptSel.has(k) ? deptSel.delete(k) : deptSel.add(k); deptView(key); });
  V().querySelector("[data-dall]")?.addEventListener("click", () => { const on = its.length && its.every((x) => deptSel.has(iid(x))); its.forEach((x) => on ? deptSel.delete(iid(x)) : deptSel.add(iid(x))); deptView(key); });
  V().querySelector("[data-dok]")?.addEventListener("click", () => { const xs = sel.slice(); deptSel = null; approveMany(xs); redrawDept(); });
  triMark();
}

// ---------- 대화: Claude departments and Codex threads, one list, one pane ----------
let talkQ = "", talkSeg = "all";
// The list beside a conversation takes the width it is dragged to (names were cut at 360px).
// It follows the pointer 1:1, a double click puts it back, arrows nudge it; kept per device.
const CLW = [260, 300, 720];
const clw = (v) => { try { if (v === undefined) return +localStorage.getItem("v2-clw") || CLW[1]; localStorage.setItem("v2-clw", Math.round(v)); } catch { return CLW[1]; } };
const clampW = (w) => Math.max(CLW[0], Math.min(w, CLW[2], innerWidth - railRoom() - 420));
const setClw = (w) => document.documentElement.style.setProperty("--clw", clampW(w) + "px");
setClw(clw());
addEventListener("resize", () => setClw(clw()));
// The item page's right column (comments, versions) drags wider the same way, from its left edge.
const IPW = [320, 320, 760];
// Untouched, the panel leaves the result 520px (defIpw); dragged, it may take 80 more in a window
// under 1280, or the menu's 248 leaves the grip 12px of travel at 1100 (feedback E9). Putting it
// back on the default (double-click) forgets the stored width, so the default follows the window.
const ipwRoom = (keep) => innerWidth - railRoom() - keep;
const defIpw = () => Math.max(IPW[0], Math.min(IPW[1], ipwRoom(520)));
const clampIpw = (w) => Math.max(IPW[0], Math.min(w, IPW[2], ipwRoom(innerWidth < 1280 ? 440 : 520)));
const ipw = (v) => { try { if (v === undefined) { const k = +localStorage.getItem("v2-ipw"); return k ? clampIpw(k) : defIpw(); }
  if (Math.round(v) === Math.round(defIpw())) localStorage.removeItem("v2-ipw"); else localStorage.setItem("v2-ipw", Math.round(v)); } catch { return defIpw(); } };
// One splitter behaviour for every column edge that drags (the item page's panel, the conversation
// screen's list and results): 1:1 with the pointer, double-click puts the default back, arrows
// step it. `o`: range [min, default, max], dir (+1 when dragging right widens the panel, -1 when
// it narrows it), width() the panel's width now, apply(w) -> the clamped width it set, save(w).
function wireColGrip(g, o) {
  // The separator reports the panel width it controls, so a screen reader hears where a drag put
  // it. min/max are the panel's own bounds, not the raw range which the viewport also clamps.
  g.setAttribute("aria-valuemin", o.range[0]); g.setAttribute("aria-valuemax", o.range[2]);
  const set = (w) => { w = o.apply(w); g.setAttribute("aria-valuenow", Math.round(w)); return w; };
  let x0 = 0, w0 = 0, w = o.width(); g.setAttribute("aria-valuenow", Math.round(w));
  g.onpointerdown = (e) => { if (e.button) return; e.preventDefault(); g.setPointerCapture(e.pointerId); x0 = e.clientX; w0 = o.width(); document.body.classList.add("gripping"); };
  g.onpointermove = (e) => { if (g.hasPointerCapture(e.pointerId)) w = set(w0 + o.dir * (e.clientX - x0)); };
  g.onpointerup = g.onpointercancel = (e) => { if (!g.hasPointerCapture(e.pointerId)) return; g.releasePointerCapture(e.pointerId); document.body.classList.remove("gripping"); o.save(w); };
  g.ondblclick = () => { w = set(o.range[1]); o.save(w); };
  g.onkeydown = (e) => { const d = {ArrowLeft: -24, ArrowRight: 24}[e.key]; if (!d) return; e.preventDefault(); w = set(o.width() + o.dir * d); o.save(w); };
}
function wireItemGrip() {
  const g = document.getElementById("igrip"), box = g?.parentElement; if (!g) return;
  wireColGrip(g, {range: [IPW[0], defIpw(), IPW[2]], dir: -1, width: () => box.lastElementChild.getBoundingClientRect().width,
    apply: (w) => { w = clampIpw(w); box.style.setProperty("--ipw", w + "px"); return w; }, save: ipw});
}
function closeResult() {
  const s = document.getElementById("rsheet"); if (!s || !s.classList.contains("on")) return;
  s.classList.remove("in"); if (stageMount && s.contains(stageMount.el)) stageMount = null;
  setTimeout(() => { if (!s.classList.contains("in")) { s.classList.remove("on"); s.innerHTML = ""; } }, 260);
}
let vwClose = null;               // closes the full-screen viewer when one is up
// ---------- sheet: bottom sheet on the phone, centred card on the PC ----------
let sheetFrom = null;
function sheet(html, wire) {
  const s = document.getElementById("sheet");
  if (!s.classList.contains("on")) sheetFrom = document.activeElement;
  s.innerHTML = `<div class="scrim" data-sclose></div><div class="sbox" role="dialog" aria-modal="true"><div class="sgrab" aria-hidden="true"></div><button class="ib sx press" data-sclose aria-label="${tl("itemView.114")}">${ic("x")}</button>${html}</div>`;
  s.classList.add("on");
  const box = s.querySelector(".sbox");
  // The scrim fades with .in; on the phone the sheet itself springs up from below the edge (PC's
  // centred dialog keeps its CSS scale/fade). Springing from a real pixel offset, not the CSS 100%,
  // so an interrupted present reads a value the spring understands.
  if (wide()) requestAnimationFrame(() => s.classList.add("in"));
  else { s.classList.add("in"); box.style.transition = "none"; box.style.transform = `translateY(${box.offsetHeight}px)`;
    requestAnimationFrame(() => springSheet(box, 0)); }
  wire(box);
  liftSheet(box);
  dragSheet(box);
  // Keys stay inside the sheet: Tab goes round its own buttons, not the page behind it.
  box.tabIndex = -1;
  if (!box.contains(document.activeElement)) box.focus({preventScroll: true});
  box.addEventListener("keydown", (e) => { if (e.key !== "Tab") return;
    const f = [...box.querySelectorAll("button,a[href],input,textarea,gk-select")].filter((x) => !x.disabled && x.offsetParent !== null); if (!f.length) return;
    const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === a || document.activeElement === box)) { e.preventDefault(); z.focus(); }
    else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } });
}
// The sheet's vertical motion is a critically-damped spring (damping ratio 1.0), so it never
// overshoots the closed edge and leaves a gap under the sheet. It always starts from the value
// on screen right now, so grabbing it mid-flight and re-targeting is seamless, and it takes the
// finger's release velocity so drag and animation share one continuous motion. Reduced motion
// jumps to the target (the scrim's opacity fade carries the change). translateY only, so the
// keyboard lift (bottom/max-height) still composes.
const sboxY = (box) => { const m = /translateY\(([-\d.]+)px\)/.exec(box.style.transform); return m ? +m[1] : 0; };
function springSheet(box, target, vel = 0, done) {
  cancelAnimationFrame(box._spr || 0);
  if (RM()) { box.style.transition = "none"; box.style.transform = target ? `translateY(${target}px)` : ""; box._spr = 0; done?.(); return; }
  const k = 190, c = 2 * Math.sqrt(k);            // c = 2√k → damping ratio 1.0, response ~0.3s
  let y = sboxY(box), v = vel, last = performance.now();
  box.style.transition = "none";
  const step = (t) => { const dt = Math.min(0.032, (t - last) / 1000); last = t;
    v += (-k * (y - target) - c * v) * dt; y += v * dt;
    if (Math.abs(y - target) < 0.5 && Math.abs(v) < 10) { box.style.transform = target ? `translateY(${target}px)` : ""; box._spr = 0; return done?.(); }
    box.style.transform = `translateY(${y}px)`; box._spr = requestAnimationFrame(step); };
  box._spr = requestAnimationFrame(step);
}
// Where a flick would come to rest (scroll-style exponential projection), used to decide dismiss vs snap-back.
const projectY = (v) => (v / 1000) * 0.998 / (1 - 0.998);
// Drag the grabber (or the strip around it) down to dismiss, the iOS way: 1:1 with the finger,
// let go where its momentum would carry it past the halfway edge and it drops the rest of the way
// at that same speed, otherwise it springs back. PC's centered dialog keeps its close button only.
function dragSheet(box) {
  if (wide()) return;
  const grab = box.querySelector(".sgrab"); if (!grab) return;
  let base = 0, dy = 0, vy = 0, ly = 0, lt = 0, on = false;
  grab.addEventListener("pointerdown", (e) => { on = true;
    cancelAnimationFrame(box._spr || 0);           // grab it mid-flight: carry on from where it is
    base = e.clientY - sboxY(box); dy = sboxY(box); vy = 0; ly = e.clientY; lt = e.timeStamp || performance.now();
    box.style.transition = "none"; grab.setPointerCapture?.(e.pointerId); });
  grab.addEventListener("pointermove", (e) => { if (!on) return; dy = Math.max(0, e.clientY - base);
    const now = e.timeStamp || performance.now(), d = now - lt; if (d > 0) vy = (e.clientY - ly) / d * 1000;
    ly = e.clientY; lt = now; box.style.transform = "translateY(" + dy + "px)"; });
  const up = () => { if (!on) return; on = false;
    // Project where the flick lands; past half the sheet it dismisses, and either way the spring
    // continues at the release velocity.
    (dy + projectY(vy) > box.offsetHeight * 0.4) ? closeSheet(vy) : springSheet(box, 0, vy); };
  grab.addEventListener("pointerup", up); grab.addEventListener("pointercancel", up);
}
// A phone keyboard covers the bottom of the screen, and a bottom sheet with it: sit the
// sheet on top of the keys and fit it in what is left, as sheet.js does for the old page.
function liftSheet(box) {
  const vv = window.visualViewport; if (!vv || wide()) return;
  const lift = () => {
    if (!box.isConnected) { vv.removeEventListener("resize", lift); vv.removeEventListener("scroll", lift); return; }
    const kb = Math.max(0, innerHeight - vv.height - vv.offsetTop);
    box.style.bottom = kb > 80 ? kb + "px" : "";
    box.style.maxHeight = kb > 80 ? Math.max(0, vv.height - 16) + "px" : "";
  };
  vv.addEventListener("resize", lift); vv.addEventListener("scroll", lift);
  lift();                       // the keyboard may already be up before the sheet opens
}
// A yes/no question in the app's own sheet (the browser's confirm() box looked like another program).
// Resolves true only from the main button; any other way the sheet goes away (scrim, X, Esc) is a no.
// "다시 묻지 않기": kinds of harmless, reversible confirms the person switched off, kept in this browser.
// Never offered on anything that deletes or stops. 설정 › 화면·알림 turns them all back on.
const NOASK = "genok.noask";
const noAsk = () => { try { return JSON.parse(localStorage.getItem(NOASK) || "{}") || {}; } catch (e) { return {}; } };
const noAskSet = (k) => { try { localStorage.setItem(NOASK, JSON.stringify({...noAsk(), [k]: 1})); } catch (e) { /* asks again next time */ } };
const noAskClear = () => { try { localStorage.removeItem(NOASK); } catch (e) { /* nothing was kept */ } };
// The text's first question becomes the one-line title, what follows it the dim line; `go` names the button.
function askSheet(title, text, danger, go) {
  const m = /^(.*?\?)\s+(\S.*)$/s.exec(text || "");
  return new Promise((resolve) => {
    let done = false;
    const host = document.getElementById("sheet");
    const end = (v) => { if (done) return; done = true; obs.disconnect(); resolve(v); };
    const obs = new MutationObserver(() => { if (!host.classList.contains("on")) end(false); });
    sheet(`<div class="cf"><h3>${esc(m ? m[1] : title)}</h3><p class="cf-sub" style="white-space:pre-line">${esc(m ? m[2] : text)}</p>
      <div class="cf-acts"><button class="btn xl ${danger ? "danger" : "fill"} press" id="ask-go">${esc(go || title)}</button><button class="btn xl press" data-sclose>${tl("libDraw.22")}</button></div></div>`, (box) => {
      box.querySelector("#ask-go").onclick = () => { end(true); closeSheet(); };
    });
    obs.observe(host, {attributes: true, attributeFilter: ["class"]});
  });
}
function closeSheet(vel = 0) { const s = document.getElementById("sheet"); if (!s.classList.contains("on")) return; s.classList.remove("in");
  const from = sheetFrom; sheetFrom = null; if (from?.isConnected && from !== document.body) from.focus({preventScroll: true});
  const box = s.querySelector(".sbox"), clear = () => { if (!s.classList.contains("in")) { s.classList.remove("on"); s.innerHTML = ""; } };
  // Phone: spring the sheet down (carrying any release velocity) and clear once it lands. PC keeps the CSS fade.
  if (box && !wide()) springSheet(box, box.offsetHeight, vel, clear);
  else setTimeout(clear, 260); }

// ---------- 검색 (overlay) · 명령 ----------
// Ctrl+K also gets things done: ↑↓ pick a row, Enter opens it, and a picked result or
// department shows what can be done to it right there, each with its Alt key. The actions
// are the ones the lists and pages already run.
const itemIt = (x) => ({id: iid(x), p: x.project, i: x.id, v: x.v, dept: x.dept, reject: x.reject || [], status: x.status, latest: false});
// 맞아 on every claimed fix in view: the result page's own button when it is open, else per result.
async function allOk(C) {
  const b = detail?.[0] === "item" && (document.querySelector(".dall") || (C.length === 1 && document.querySelector(".dir .dyes")));
  if (b) return b.click();
  const G = new Map(); C.forEach((c) => { const k = iid(c.it); G.set(k, [...(G.get(k) || []), c.id]); });
  for (const [k, ids] of G) await verdict(k, ids, true);
}
const palActs = (row) => {
  const x = row.dataset.item && D.items.find((y) => iid(y) === row.dataset.item);
  if (!x || (x.status === "approved" && !turnOf(x))) return [];
  return [["ok", tl("STATUS_T.4"), "A", () => approveMany([x])], ["no", tl("palActs.1"), "R", () => rejectSheet(itemIt(x))], ["snz", tl("palActs.2"), "H", () => snoozeSheet(iid(x))]];
};
const palCmds = () => { const C = detail?.[0] === "item" && openItem ? claimedDirs().filter((c) => iid(c.it) === openItem.id) : claimedDirs(), n = stackQueue().length;
  return [["inbox", tl("palCmds.1"), "G I", () => nav("inbox"), true, "bell"],["lib", tl("palCmds.2"), "G L", () => nav("lib"), true, "lib"],
    ["pending", tl("palCmds.3"), "", () => nav("lib?f=pending"), true, "check"],
    n && ["stack", tl("palCmds.4", {n}), "", () => stackOpen(), false, "full"],
    C.length && ["allok", tl("palCmds.5", {n: C.length}), "", () => allOk(C), false, "check"],
  ].filter(Boolean); };
// Leaving the palette first: opened as the #search page, going back is a hash change, and
// that closes any sheet - so what opens a sheet waits for it.
function palRun(fn, goes) {
  if (goes) return fn();
  if (location.hash === "#search" && history.length > 1) { addEventListener("hashchange", () => setTimeout(fn), {once: true}); search(false); history.back(); }
  else { search(false); fn(); }
}
function search(on) {
  const o = document.getElementById("ov");
  // The overlay is a modal dialog: the role/label go on while it is up so a screen reader treats
  // it as one and names it, and come off when it closes so the hidden shell is not announced.
  // What is behind the overlay (title bar, tabs, the page) is out of reach while it is up.
  const behind = (off) => document.querySelectorAll(".app,#tabbar").forEach((el) => { el.inert = off; });
  if (!on) { o.classList.remove("on"); o.removeAttribute("role"); o.removeAttribute("aria-modal"); o.removeAttribute("aria-label"); behind(false); return; }
  if (o.classList.contains("on")) return;
  behind(true);
  o.innerHTML = `<div class="top" style="background:var(--bg)"><div class="field" style="flex:1;margin:0;background:var(--card)">${ic("search")}<input id="q" placeholder="${tl("search.1")}" autocomplete="off"></div><button class="btn" data-close title="Esc" style="background:none;color:var(--t2)">${tl("itemView.114")}</button></div><div id="qr"></div><div class="qhint"><span><kbd>↑</kbd><kbd>↓</kbd> ${tl("search.2")}</span><span><kbd>Enter</kbd> ${tl("search.3")}</span></div>`;
  // Lab 3: search sits in the kit's palette over a blurred backdrop instead of a full opaque sheet.
  if (LAB3) { const pal = document.createElement("div"); pal.className = "glass-search-palette k3pal"; pal.append(...o.childNodes); o.append(pal);
    pal.querySelector(".top").classList.add("search-input-wrap"); pal.querySelector("#q").classList.add("search-input-field"); pal.querySelector("#qr").classList.add("search-results-list");
    o.classList.add("k3ov"); o.onmousedown = (e) => { if (e.target === o) pal.querySelector("[data-close]").click(); }; }
  o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true"); o.setAttribute("aria-label", tl("MENUS.5"));
  o.classList.add("on"); const q = document.getElementById("q"), qr = document.getElementById("qr"); q.focus();
  let sel = -1, acts = [], cmds = [];
  const rowsOf = () => [...qr.querySelectorAll(".row")];
  const pick = (i, scroll = true) => { const R = rowsOf(); qr.querySelector(".pact")?.remove(); R.forEach((r) => r.classList.remove("kfoc")); acts = [];
    if (!R.length) return (sel = -1);
    sel = (i + R.length) % R.length; const r = R[sel]; r.classList.add("kfoc");
    acts = r.dataset.cmd ? [] : palActs(r);
    if (acts.length) r.insertAdjacentHTML("afterend", `<div class="pact">${acts.map(([k, n, key]) => `<button class="chip press" data-pa="${k}">${n}<kbd>Alt ${key}</kbd></button>`).join("")}</div>`);
    if (scroll) (acts.length ? qr.querySelector(".pact") : r).scrollIntoView({block: "nearest"}); };
  const draw = () => { const s = q.value.trim().toLowerCase();
    cmds = palCmds().filter(([, n]) => !s || n.toLowerCase().includes(s)).slice(0, s ? 4 : 5);
    const ms = MENUS.filter((m) => m.k !== "search" && (!s || (m.n + m.d).toLowerCase().includes(s))).slice(0, s ? 5 : 6);
    // Extension screens are found by name, so one that is off in the menu still opens from here.
    const xs = s ? extTabs().filter((t) => !M(t.id) && t.label.toLowerCase().includes(s)).slice(0, 3) : [];
    const ds = s ? projects().filter((g) => (g.name + " " + pname(g.name)).toLowerCase().includes(s)).slice(0, 5) : [];
    const is = s ? D.items.filter((x) => (x.title + x.dept + pname(x.dept || "")).toLowerCase().includes(s)).slice(0, 6) : myTurn().slice(0, 3);
    qr.innerHTML =
      (is.length && !s ? `<div class="sec">${tl("search.4")}</div><div class="card">${is.map((x) => itemRow(x, false)).join("")}</div>` : "")
      + (cmds.length ? `<div class="sec">${tl("search.5")}</div><div class="card">${cmds.map(([k, n, key, , , i]) => `<button class="row press" data-cmd="${k}" style="min-height:56px"><span class="ico sm c-grey">${ic(i)}</span><span class="tx"><div class="t" style="font-size:16px">${esc(n)}</div></span>${key ? `<span class="pkey">${key.split(" ").map((x) => `<kbd>${x}</kbd>`).join(" ")}</span>` : ""}</button>`).join("")}</div>` : "")
      + (ms.length + xs.length ? `<div class="sec">${s ? tl("search.6") : tl("search.7")}</div><div class="card">${ms.map((m) => `<button class="row press" data-go="${m.k}" style="min-height:60px">${menuIco(m, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${m.n}</div></span></button>`).join("")}${xs.map((t) => `<button class="row press" data-go="${esc(t.id)}" style="min-height:60px"><span class="ico sm c-grey">${ic(t.icon)}</span><span class="tx"><div class="t" style="font-size:16px">${esc(t.label)}</div></span></button>`).join("")}</div>` : "")
      + (ds.length ? `<div class="sec">${esc(unitWord())}</div><div class="card">${ds.map(deptRow).join("")}</div>` : "")
      + (is.length && s ? `<div class="sec">${tl("TABS.3")}</div><div class="card">${is.map((x) => itemRow(x, false)).join("")}</div>` : "")
      + (!cmds.length && !ms.length && !xs.length && !ds.length && !is.length ? `<div class="plan" id="qnone"${s.length >= 2 ? ` style="display:none"` : ""}>${mEmpty("emptySearch")}<p>${tl("search.8", {esc: esc(s)})}</p></div>` : "")
      + `<div id="qhits"></div>`;
    // A mouse or keyboard gets the first row picked; a finger just taps.
    if (matchMedia("(hover:hover)").matches) pick(0, false); else sel = -1;
    // Comments and summaries (and finished results the lists no longer carry) come from the server.
    // Nothing local is not yet "nothing": the empty line waits for the server, and a slow or failed
    // server search says so instead of passing for no match.
    clearTimeout(qT); clearTimeout(qW); const ask = ++qAsk; if (s.length < 2) return;
    const hitBox = () => ask === qAsk ? document.getElementById("qhits") : null;
    qW = setTimeout(() => { const b = hitBox(); if (b) b.innerHTML = `<div class="sec" role="status">${tl("search.10")}</div>`; }, 700);
    qT = setTimeout(() => get(`/api/search?q=${encodeURIComponent(s)}`).then((r) => {
      const hs = (r.hits || []).filter((h) => h.where !== "제목" || !D.items.some((x) => iid(x) === h.project + "/" + h.id)).slice(0, 12);
      clearTimeout(qW); const box = hitBox(); if (!box) return;
      if (!hs.length) { box.innerHTML = ""; const n = document.getElementById("qnone"); if (n) n.style.display = ""; return; }
      document.getElementById("qnone")?.remove();
      box.innerHTML = `<div class="sec">${tl("search.9")}</div><div class="card">${hs.map((h) => hitRow(h, s)).join("")}</div>`;
      if (sel < 0 && matchMedia("(hover:hover)").matches) pick(0, false);
    }).catch(() => { clearTimeout(qW); const box = hitBox(); if (!box) return;
      box.innerHTML = `<div class="plan"><p>${tl("search.11")}</p><p><button class="btn weak press" id="qretry">${tl("upd.retry")}</button></p></div>`;
      document.getElementById("qretry").onclick = draw; }), 200); };
  let qT, qW, qAsk = 0;
  const act = (a) => a && palRun(a[3], a[4]);
  q.oninput = draw;
  // A press on the bare backdrop (not a row, the field or the hint bar) leaves the search.
  o.onclick = (e) => { if (e.target === o || e.target === qr) { search(false); if (history.length > 1 && location.hash === "#search") history.back(); } };
  q.onkeydown = (e) => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); pick(sel < 0 && e.key === "ArrowDown" ? 0 : sel + (e.key === "ArrowDown" ? 1 : -1)); }
    else if (e.key === "Enter" && !e.altKey) { const r = rowsOf()[Math.max(sel, 0)]; if (r) { e.preventDefault(); r.click(); } }
    else if (e.altKey && !e.ctrlKey && !e.metaKey && /^Key[A-Z]$/.test(e.code)) { const a = acts.find(([, , k]) => "Key" + k === e.code); if (a) { e.preventDefault(); act(a); } }
  };
  qr.onclick = (e) => { const c = e.target.closest("[data-cmd]"), p = e.target.closest("[data-pa]");
    if (c) { e.stopPropagation(); act(cmds.find(([k]) => k === c.dataset.cmd)); }
    else if (p) { e.stopPropagation(); act(acts.find(([k]) => k === p.dataset.pa)); } };
  draw();
}

// The same lists the 내 차례 page counts, so the two numbers agree.
const claimedDirs = () => D.items.filter((x) => !x.finished && (x.claimed || []).length).flatMap((x) => x.claimed.map((c) => ({...c, it: x})));
// Departments standing still until I act - a question, a prompt, a stuck session, a failed job.
// Results to look at, fixes to confirm and doubled sessions wait without holding anyone up, so
// they stay on 내 차례 but out of the red count.
// 고쳤다고 한 지시, one block per result: each ask with 맞아 / 아직 right there, and 모두 맞아
// for a result whose fixes were already seen in its newest version.
const claimCard = () => { const C = claimedDirs(); if (!C.length) return "";
  const G = new Map(); C.forEach((c) => { const k = iid(c.it); if (!G.has(k)) G.set(k, []); G.get(k).push(c); });
  return `<div class="card"><div class="ch"><h2>${tl("claimCard.2")}</h2><span class="n num">${C.length}</span></div>
    ${[...G].map(([k, L]) => `<div class="clg"><button class="row press clh" data-item="${esc(k)}">${thumb(L[0].it, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(L[0].it.title)}</div><div class="s">${tl("claimCard.1", {esc: esc(L[0].it.dept || ""), esc2: esc(L[0].fixed_in)})}</div></span>${ic("chev", "i go")}</button>
      ${L.map((c) => `<div class="row note dir claimed"${cur === "inbox" ? " data-tk" : ""}><span class="tx"><div class="nt">${esc((c.text || "").split(/\s+/).join(" ").slice(0, 90))}</div></span><span class="dbtns"><button class="btn sm fill press" data-dv="${esc(c.id)}" data-dk="${esc(k)}" data-ok="1">${tl("itemView.10")}</button><button class="btn sm weak press" data-dv="${esc(c.id)}" data-dk="${esc(k)}" data-ok="">${tl("itemView.11")}</button></span></div>`).join("")}
      ${L.length > 1 ? `<div class="clall"><button class="btn sm press" data-dvall="${esc(k)}">${tl("itemView.14", {n: L.length})}</button></div>` : ""}</div>`).join("")}<div style="height:8px"></div></div>`; };
// Home's line for the same asks: one row per result (never one per ask - that flooded the
// list), three at most, each opening the result with its 요청 fold open.
const fixCard = () => { const G = new Map(); claimedDirs().forEach((c) => { const k = iid(c.it); if (!G.has(k)) G.set(k, []); G.get(k).push(c); });
  return G.size ? `<section class="permcard fixcard" aria-label="${tl("claimCard.2")}"><h2>${tl("claimCard.2")}<b class="num">${G.size}</b></h2>${[...G].slice(0, 3).map(([k, L]) => `<div class="permit"><div class="tx"><span class="t">${esc(L[0].it.title)}<i>${esc(pname(L[0].it.dept || ""))}</i></span><span class="s">${tl("fixCard.s", {v: esc(L[0].fixed_in || ""), n: L.length})}</span></div><div class="acts"><button class="btn sm fill press" data-item="${esc(k)}" data-fixgo>${tl("fixCard.go")}</button></div></div>`).join("")}</section>` : ""; };
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-fixgo]"); if (b) dirsOpenOf = b.dataset.item; }, true);
// A verdict from a list: the same call the result page makes, then the row goes at once.
async function verdict(key, ids, ok) {
  const [p, ...r] = key.split("/"), it = D.items.find((x) => iid(x) === key);
  // A verdict names the version that claimed the fix and the directive's own rev - the ones
  // this row showed. Only a row from an older board without them reads the item first.
  const cl = (id) => (it?.claimed || []).find((c) => c.id === id);
  const shown = ids.every((id) => cl(id)?.rev != null && cl(id)?.fixed_in);
  const det = shown ? null : await itemDetail(p, r.join("/")), ds = det?.directives || [];
  const dOf = (id) => (shown ? cl(id) : ds.find((d) => d.id === id) || cl(id)) || {};
  try { for (const id of ids) await post("/api/directive", {p, i: r.join("/"), id, v: dOf(id).fixed_in || it?.v, ok, verdict: ok ? "ok" : "again", rev: dOf(id).rev});
    if (it) it.claimed = (it.claimed || []).filter((c) => !ids.includes(c.id));
    toast(ok ? (ids.length > 1 ? tl("itemView.99", {n: ids.length}) : tl("verdict.1")) : tl("itemView.100"), 2200, ok ? "confirm" : "resent"); }
  catch (e) { if (isConflict(e)) conflictSheet(e.body, {v: it?.v, log: det?.log, reload: () => nav("item/" + key)}); else toast(e.message); }
  if (cur === "inbox" && !detail) SCREENS.inbox(inTab); drawChrome();
}
// ---------- 받은함 · 할 것: everything waiting on me, one list per kind ----------
// The one place the count comes from: the tab badge, the rail, the page title, home and the
// list itself all add up these same lists, so no two of them can disagree.
// Results pushed with a question (--ask), one group per project.
// Only while the question is still the reader's move (status.js): one sent back in words, with
// its question left open, is in the session's hands and in none of the 내 차례 lists.
const askQ = (x) => x.asked > 0 && stK(x) === "ask";
const askMine = () => D.items.filter((x) => askQ(x) && !snoozeOf(x));
const askGroups = (L = askMine()) => { const G = new Map();
  L.sort(byAt).forEach((x) => {
    const n = gname(x); if (!G.has(n)) G.set(n, {dept: n, items: []}); G.get(n).items.push(x); });
  return [...G.values()]; };
const askCard = ({dept, items}, btn = () => "") => `<div class="row"><span class="tx"><div class="t" style="font-size:16px">${esc(dept || tl("askCard.1"))}</div><div class="s"><span class="warn">${tl("askCard.2")}</span></div></span></div>`
  + items.map((x) => `<button class="turnr press" data-item="${esc(iid(x))}">${thumb(x, "ico sm")}<span class="tx"><div class="rt">${esc(x.title)}</div><div class="rs">${tl("askCard.3", {esc: esc(x.v || x.project || ""), asked: x.asked, ago: ago(x.at)})}</div></span><span class="tag pending">${tl("askCard.4")}</span>${btn(x)}</button>`).join("");
// Session and routine kinds (attention.py): held lines, waiting/stuck/doubled sessions, failed
// routines. Part of the red number, so fetched whatever page is open, at most once a minute.
let att = null, attAt = 0;
const attL = (k) => (att && att[k]) || [];
// A session just answered from the chat screen (web/project.js keeps when) is not "my turn" in a
// fresh read either, until it has done something after the answer.
const attAns = () => { const f = window.PjAnswered; if (f && att) attL("rooms").forEach((r) => { if (r.turn && f(r.key, r.active)) r.turn = false; }); };
const attSig = () => att ? ["lost", "blocked", "stuck", "dup", "fail"].map((k) => attL(k).length).join() + "|" + attL("rooms").map((r) => r.key + ":" + r.unread + (r.turn ? "t" : "")).join() : "";
// While the page boots, the first fill must not redraw: the render that follows load() already
// includes it (boot waits for attP, up to half a second), so a redraw here is a second home draw.
let attP = null, attBooting = true;
function refreshAtt(force) {
  if (!force && Date.now() - attAt < 60e3) return;
  attAt = Date.now();
  attP = get("/api/attention" + (force ? "?fresh=1" : "")).then((d) => { const was = attSig(); att = d; attAns(); readOpenRoom(); const now = attSig();
    // The first fill of a quiet account changes nothing on screen (no signature -> all zero): no redraw.
    if (was !== now && !(was === "" && now === "0,0,0,0,0|")) { drawChrome(); if (!attBooting && (cur === "inbox" || cur === "home" || cur === "sessions" || cur === "lib" || cur === "dept")) redraw(); } }).catch(() => {});
}
// Claude permission prompts waiting for a press (permreq.py), answered in place. Asked every few
// seconds only on a PC where the permission hook has run; elsewhere once a minute.
let PERM = [], permOn = false, permAt = 0;
function refreshPerm() {
  if (document.hidden || Date.now() - permAt < (permOn ? 4e3 : 60e3)) return;
  permAt = Date.now();
  get("/api/permission").then((d) => { const was = PERM.map((p) => p.id).join(); PERM = d.pending || []; permOn = !!d.on;
    if (was !== PERM.map((p) => p.id).join()) permDrawn(); }).catch(() => {});
}
const permDrawn = () => { drawChrome(); if (!detail && (cur === "inbox" || cur === "home")) redraw(); };
const permWho = (p) => { const r = attL("rooms").find((x) => x.key === p.sid); return r ? pname(r.dept) : p.cwd.split(/[\\/]/).filter(Boolean).pop() || "Claude"; };
const permCard = () => PERM.length ? `<section class="permcard" aria-label="${tl("perm.h")}"><h2>${tl("perm.h")}<b class="num">${PERM.length}</b></h2>${PERM.map((p) => `<div class="permit"><div class="tx"><span class="t">${esc(permWho(p))}<i>${esc(p.tool)}</i></span><code>${esc(p.text)}</code></div><div class="acts"><button class="btn sm press" data-perm="${esc(p.id)}" data-allow="0">${tl("perm.deny")}</button><button class="btn sm fill press" data-perm="${esc(p.id)}" data-allow="1">${tl("perm.allow")}</button></div></div>`).join("")}</section>` : "";
document.addEventListener("click", async (e) => {
  const b = e.target.closest?.("[data-perm]"); if (!b) return;
  const id = b.dataset.perm; b.closest(".permit").querySelectorAll("button").forEach((x) => x.disabled = true);
  try { await post("/api/permission/answer", {id, allow: b.dataset.allow === "1"}); } catch (err) { toast(err.message); }
  PERM = PERM.filter((p) => p.id !== id); permDrawn();
});
setInterval(refreshPerm, 2e3);
// A room link: the department's session in the project page.
const roomGo = (dept, sid) => "project/" + encodeURIComponent(dept) + (sid ? "/" + sid : "");
// The session rail (wide screens): every conversation that is up, as its project's face and a
// state dot, fixed on the right. A press opens its chat in a pane beside the rail: the same chat
// as the room screen (project.js's pjEmbed). Where that chat is already on the page (the room
// screen, an item's chat tab) the press goes to the room instead: one chat a page.
const SR_ORD = {ask: 0, stuck: 1, work: 2, idle: 3};
const SR_T = LT(() => ({ask: tl("SESS_T.3"), stuck: tl("SESS_T.4"), work: tl("room.fBusy"), idle: tl("room.bgIdle")}));
const srRooms = () => { const K = new Set(attL("stuck").map((r) => r.key));
  return attL("rooms").map((r) => ({r, s: K.has(r.key) ? "stuck" : r.job === "blocked" || r.turn ? "ask" : r.job === "working" ? "work" : "idle"}))
    .sort((a, b) => SR_ORD[a.s] - SR_ORD[b.s] || (Date.parse(b.r.active) || 0) - (Date.parse(a.r.active) || 0)); };
let srOpen = "";
function drawSrail() {
  const el = document.getElementById("srail"); if (!el) return;
  const L = srRooms().slice(0, 10);
  el.hidden = !LAB3 || !L.length || cur === "project";
  if (el.hidden) { if (!LAB3 || cur === "project") srClose(); return; }
  el.setAttribute("aria-label", tl("srail.label"));
  setHTML(el, L.map(({r, s}) => `<button class="sb press${srOpen === r.key ? " on" : ""}" data-sr="${esc(r.key)}" data-s="${s}" title="${esc(pname(r.dept))} · ${esc(SR_T[s])}" aria-label="${esc(pname(r.dept))}, ${esc(SR_T[s])}">${r.icon ? esc(r.icon) : ic("chat")}<span class="sn">${esc(pname(r.dept))}</span><i></i></button>${s === "ask" || s === "stuck" ? `<span class="sk" data-s="${s}">${esc(SR_T[s])}</span>` : ""}`).join("")
    + `<span class="sp"></span><button class="sb all press" data-go="project" title="${esc(tl("menu.chat"))}" aria-label="${esc(tl("menu.chat"))}">${ic("rooms")}<span class="sn">${esc(tl("menu.chat"))}</span></button>`);
  if (!el.onclick) el.onclick = (e) => { const b = e.target.closest("[data-sr]"); if (b) srShow(b.dataset.sr); };
}
function srClose() { const p = document.getElementById("spop"); if (!p || p.hidden) return;
  srOpen = ""; p.hidden = true; p.replaceChildren();
  document.querySelectorAll("#srail .sb.on,#k3r .on").forEach((b) => b.classList.remove("on")); }
// `key` is a live session; without one (lab 3's column also lists projects with no chat up)
// `dept` names the project and the pane finds its session itself.
function srShow(key, dept) {
  const id = key || "d:" + dept;
  if (srOpen === id) return srClose();
  const x = key ? srRooms().find((q) => q.r.key === key) : null; if (!x && !dept) return;
  const r = x ? x.r : {dept, key: "", icon: (projects().find((g) => g.name === dept) || {}).icon || ""}, s = x ? x.s : "", p = document.getElementById("spop");
  srClose();
  if (typeof window.pjEmbed !== "function" || document.getElementById("pj-msgs")) return nav(roomGo(r.dept, r.key));
  srOpen = id;
  p.setAttribute("aria-label", pname(r.dept));
  p.innerHTML = `<div class="spop-h">${deptIco(r, "ico sm")}<span class="tx"><b class="t">${esc(pname(r.dept))}</b><span class="s" data-s="${s}">${esc(SR_T[s] || "")}</span></span><button class="ib press" data-srbig title="${esc(tl("room.bigger"))}" aria-label="${esc(tl("room.bigger"))}">${ic("full")}</button><button class="ib press" data-srx title="${esc(tl("ui.close"))}" aria-label="${esc(tl("ui.close"))}">${ic("x")}</button></div><div class="spop-b"></div>`;
  p.hidden = false;
  p.querySelector("[data-srbig]").onclick = () => { srClose(); nav(roomGo(r.dept, r.key)); };
  p.querySelector("[data-srx]").onclick = srClose;
  if (key) document.querySelector(`#srail [data-sr="${CSS.escape(key)}"]`)?.classList.add("on");
  [...document.querySelectorAll("#k3r [data-k3n]")].find((b) => (b.dataset.k3k || "d:" + b.dataset.k3n) === id)?.classList.add("on");
  const body = p.querySelector(".spop-b");
  window.pjEmbed(body, {sid: key, name: r.dept}).then((v) => {
    if (srOpen === id && body.isConnected && !(v && v.session)) body.innerHTML = `<p class="spop-e">${tl("fl.gone")}</p>`; });
}
addEventListener("hashchange", srClose);
addEventListener("keydown", (e) => { if (e.key === "Escape" && srOpen) srClose(); }, true);
addEventListener("pointerdown", (e) => { if (srOpen && e.target.closest?.("#main, #rail, #k3l")) srClose(); });
// Rooms whose session said something since the room was last read, newest first.
// What counts as an unread conversation: one opened here before (r.seen) whose session has
// answered since and has finished its turn. Not counted: a session still mid-work, one never
// opened here (there is no "since last visit"), and one that ended more than a day ago.
const ROOM_STALE = 864e5;
const roomUnread = (r) => r.unread > 0 && r.seen !== false && r.job !== "working"
  && !(r.state === "ended" && Date.now() - (Date.parse(r.active) || 0) > ROOM_STALE);
// Mark conversations read (session ids; none given = every unread one). The count drops at
// once everywhere; the server moves the same marker that opening the conversation moves.
async function roomsRead(keys) {
  const K = keys || unreadRooms().map((r) => r.key);
  if (!K.length) return;
  attL("rooms").forEach((r) => { if (K.includes(r.key)) { r.unread = 0; r.seen = true; } });
  drawChrome();
  try { await post("/api/room-read-all", {keys: K}); } catch (e) { refreshAtt(true); }
}
// Opening a conversation reads it: its number goes from the sidebar and the list right away.
function readOpenRoom() {
  let h; try { h = decodeURIComponent(location.hash.slice(1)).split("/"); } catch { return; }
  if (h[0] !== "project" || !h[2] || document.hidden) return;
  const ids = h[2].split(","), K = attL("rooms").filter((r) => ids.includes(r.key) && r.unread > 0).map((r) => r.key);
  if (K.length) roomsRead(K);
}
addEventListener("hashchange", readOpenRoom);
const unreadRooms = () => attL("rooms").filter(roomUnread).sort((a, b) => (Date.parse(b.active) || 0) - (Date.parse(a.active) || 0));
async function nextUnread() {
  const d = await get("/api/attention?fresh=1").catch(() => null); if (d) { att = d; attAns(); attAt = Date.now(); }
  if (att && !att.sessions) return toast(tl("nextUnread.off"));
  const R = unreadRooms(); if (!R.length) return toast(tl("nextUnread.none"));
  let here = ""; try { const h = decodeURIComponent(location.hash.slice(1)).split("/"); if (h[0] === "project") here = h[2] || ""; } catch {}
  const r = R[(R.findIndex((x) => x.key === here) + 1) % R.length];
  closeSheet(); vwClose?.(); nav(roomGo(r.dept, r.key));
}
// Sessions that cannot go on without the person: the permission waits `claude agents` names, plus
// every room the server says is their turn (a question, a plan, a result waiting for 승인),
// once each. Working sessions are never in it (sessions_ctl.waits_on_person).
const blockedL = () => { const L = attL("blocked").filter((a) => a.needs && !PERM.some((p) => p.sid === a.session)), seen = new Set(L.map((a) => a.session).filter(Boolean));
  return L.concat(attL("rooms").filter((r) => r.turn && !seen.has(r.key)).map((r) => ({dept: r.dept, session: r.key, needs: r.needs || "input needed", agent: r.agent, mark: r.mark}))); };
// The rows of 할 일 that are not results, as [key, mark] for 나중에 보기 (asideOf).
const SEC_ROW = {
  unsent: (x) => ["u:" + iid(x), x.v + "|" + x.unsent], undeliv: (b) => ["w:" + iid(b), String(b.asked || "")],
  lost: (r) => ["l:" + r.dept + "/" + (r.session || ""), r.n + "|" + r.at], blocked: (a) => ["s:" + (a.session || a.dept), a.needs + "|" + (a.mark || "")],
  stuck: (r) => ["k:" + r.key, String(r.stuck || "")], dup: (r) => ["d:" + r.dept, String(r.extra)], fail: (t) => ["f:" + t.id, String(t.last || "")]};
const secAside = (k, r) => !!asideOf(...SEC_ROW[k](r));
// z: the same sections holding only what was put aside (the 나중에 tab).
const todoSecs = (z = false) => {
  const zi = z ? D.items.filter(snoozeOf) : [], asks = z ? zi.filter(askQ) : askMine(), asked = new Set(asks.map(iid));
  return [
    // Grouped by project for the list, counted by result: every other kind counts its rows too.
    {k: "ask", n: tl("todoSecs.1"), i: "ask", hot: 1, L: askGroups(asks), cnt: (L) => L.reduce((a, g) => a + g.items.length, 0), peek: (g) => g.dept},
    // No "claim" kind: a request a session says it fixed is checked on the result page, when the
    // person looks at that version. Listed here it flooded 내 차례 (user, 2026-10-02).
    {k: "look", n: tl("search.4"), i: "lib", L: z ? zi.filter((x) => stMine(x) && !asked.has(iid(x)) && !libHide.has(iid(x))).sort(byAt) : myTurn().filter((x) => !asked.has(iid(x))), peek: (x) => x.title},
    {k: "unsent", n: tl("itemView.128"), i: "up", L: D.items.filter((x) => x.unsent > 0).sort(byAt), peek: (x) => x.title},
    // Sent, but the department has not taken it yet. Ones still unsent are the row above.
    {k: "undeliv", n: tl("todoSecs.2"), i: "wait", L: D.board.filter((b) => b.state === "waiting" && !(b.unsent > 0)).sort((a, b) => (b.asked || "").localeCompare(a.asked || "")), peek: (b) => b.title},
    // Lines typed into a room that no session took: they sit there until one is woken.
    {k: "lost", n: tl("todoSecs.lost"), i: "chat", hot: 1, c: "orange", L: attL("lost"), peek: (r) => r.dept},
    // Only waits that name what they need (a permission, a question). A session that has merely
    // finished its turn is chat state: it is the quiet unread mark on 모든 대화, never counted here.
    {k: "blocked", n: tl("todoSecs.blocked"), i: "shield", hot: 1, c: "blue", L: blockedL(), peek: (a) => a.dept},
    {k: "stuck", n: tl("todoSecs.stuck"), i: "warn", hot: 1, L: attL("stuck"), peek: (r) => r.dept},
    {k: "dup", n: tl("todoSecs.dup"), i: "copy", L: attL("dup"), peek: (r) => r.dept},
    {k: "fail", n: tl("todoSecs.fail"), i: "clock", hot: 1, L: attL("fail"), peek: (t) => t.name},
  ].map((s) => turnHid(s.k) ? {...s, L: []} : SEC_ROW[s.k] ? {...s, L: s.L.filter((r) => secAside(s.k, r) === z)} : s);
};
// 알림 고르기: the kinds of 내 차례 the person keeps. A kind switched off is gone from the list,
// the count and home, and makes no sound - the work itself is still under 결과물 and 대화.
const TURN_KINDS = {look: ["look"], ask: ["ask"], send: ["unsent", "undeliv"], session: ["lost", "blocked", "stuck", "dup"], routine: ["fail"]};
const turnOffL = () => window.LOOP_TURN?.off() || [];
const turnHid = (k) => turnOffL().some((g) => TURN_KINDS[g]?.includes(k));
function turnSheet() {
  const sw = (on, attr, label) => `<button type="button" class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" ${attr} aria-label="${esc(label)}"></button>`;
  const row = (t, d, s, c = "") => `<div class="tkrow${c}"><div class="tx"><div class="t">${esc(t)}</div><div class="s">${esc(d)}</div></div>${s}</div>`;
  const off = turnOffL();
  const N = {look: [tl("turn.k.look"), tl("turn.k.look.d")], ask: [tl("turn.k.ask"), tl("turn.k.ask.d")], send: [tl("turn.k.send"), tl("turn.k.send.d")],
    session: [tl("turn.k.session"), tl("turn.k.session.d")], routine: [tl("turn.k.routine"), tl("turn.k.routine.d")]};
  sheet(`<h2 style="margin:0 0 4px">${tl("turn.h")}</h2><p class="hint" style="margin:0 0 12px">${tl("turn.d")}</p>
    ${Object.keys(TURN_KINDS).map((g) => row(N[g][0], N[g][1], sw(!off.includes(g), `data-turnk="${g}"`, N[g][0]))).join("")}
    ${row(tl("mode.k.wait"), tl("mode.k.wait.d"), sw(!!window.LOOP_TURN?.wait(), "data-turnwait", tl("mode.k.wait")), " tkwait")}`, (box) => {
    box.addEventListener("click", (e) => {
      const b = e.target.closest("[data-turnk],[data-turnwait]");
      if (!b || !window.LOOP_TURN) return;
      const on = b.getAttribute("aria-checked") !== "true";
      const paint = (v) => { b.classList.toggle("on", v); b.setAttribute("aria-checked", String(v)); };
      paint(on);
      const body = b.dataset.turnk
        ? {turn_off: Object.keys(TURN_KINDS).filter((g) => g === b.dataset.turnk ? !on : turnOffL().includes(g))}
        : {session_wait_notify: on};
      const after = () => { try { drawChrome(); if (cur === "inbox" || cur === "home") render(); } catch {} };
      window.LOOP_TURN.set(body).catch((er) => { paint(!on); after(); toast(er.message); });
      after();
    });
  });
}
// What a waiting session needs, in the person's language (the CLI names it in English).
// 허용 / 거절 can be answered here only for Codex; a Claude Code session is answered in its own window.
const needsText = (n, agent) => n === "permission prompt" ? (agent === "codex" ? tl("att.needs.perm") : tl("att.needs.perm.open")) : n === "input needed" ? tl("att.needs.input") : n || tl("att.blocked.s");
const secN = (s) => s.cnt ? s.cnt(s.L) : s.L.length;
const todoTotal = (T) => T.reduce((a, s) => a + secN(s), 0);
const todoCount = () => { refreshAtt(); return todoTotal(todoSecs()); };
// The number on the installed app's icon, two switches, both on until turned off: "res" counts what
// concerns a result (questions, results to look at, feedback not yet taken), "chat" the sessions
// that wait. v2-badge is the earlier three-way choice (off | res), read until a switch is touched.
const BADGE_RES = ["ask", "look", "unsent", "undeliv"];
const badgeOn = (k) => { const v = lsGet("v2-badge-" + k), old = lsGet("v2-badge");
  return v ? v === "1" : old !== "off" && !(old === "res" && k === "chat"); };
const badgeCount = () => todoTotal(todoSecs().filter((s) => badgeOn(BADGE_RES.includes(s.k) ? "res" : "chat"))) + (badgeOn("chat") ? PERM.length : 0);

// ---------- 받은함: 할 것 · 소식 · 기록 (Linear's Inbox; HEY's Imbox · Feed · Paper Trail) ----------
const INBOX_T = LT(() => ([["do", tl("INBOX_T.1")], ["later", tl("palActs.2")], ["news", tl("bellSearch.1")], ["log", tl("itemView.20")]]));
let inTab = "do";
SCREENS.inbox = function (tab) {
  inTab = INBOX_T.some(([k]) => k === tab) ? tab : "do";
  const T = todoSecs(), todo = todoTotal(T), news = newsUnread(), unread = news || unreadRooms().length;
  const Z = todoSecs(true), aside = todoTotal(Z);
  const tabs = `<div class="chips ibtabs" data-sk="ibt" role="tablist">${INBOX_T.map(([k, n]) => `<button class="chip press ${inTab === k ? "on" : ""}" role="tab" aria-selected="${inTab === k}" data-ibt="${k}">${n}${k === "do" && todo ? ` <em class="num">${todo}</em>` : k === "news" && news ? ` <em class="num">${news}</em>` : k === "later" && aside ? ` <i class="ltn">${aside}</i>` : ""}</button>`).join("")}
    <span class="sp"></span><span class="ibtools">${inTab === "do" && stackQueue().length ? `<button class="chip press ibcatch" data-stack aria-label="${tl("inbox.2")}" title="${tl("inbox.2")}">${ic("stack")}<span>${tl("stackOpen.2")}</span></button>` : ""}${inTab === "news" ? `<button class="chip press ibcatch" data-iball aria-label="${tl("sx.allread")}" title="${tl("sx.allread")}"${unread ? "" : " disabled"}>${icl("read")}<span>${tl("sx.allread")}</span></button>` : ""}<button class="chip press ibcatch${turnOffL().length ? " has" : ""}" data-turnpick aria-label="${tl("turn.h")}" title="${tl("turn.h")}">${ic("bell")}<span>${turnOffL().length ? tl("turn.offn", {n: turnOffL().length}) : tl("turn.btn")}</span></button><button class="chip press ibcatch" data-catch aria-label="${tl("inbox.3")}" title="${tl("inbox.3")}">${ic("clock")}<span>${tl("inbox.3")}</span></button></span></div>`;
  if (inTab === "later") inboxDo(tabs, Z, aside, true);
  else (inTab === "news" ? inboxNews : inTab === "log" ? inboxLog : inboxDo)(tabs + catchBar(), T, todo);
  // 모두 읽음 (소식 only; 할 일 has its own on 신규 and 전부 나중에 on 답변): the news marker and every unread conversation at once.
  const ra = V().querySelector("[data-iball]"); if (ra) ra.onclick = async () => {
    seeAlerts(new Date().toISOString());
    await roomsRead();
    toast(tl("sx.allread.done")); SCREENS.inbox(inTab); drawChrome();
  };
  return {right: bellSearch()};
};
// 할 것: questions first, then what to look at, then what is stuck. Every row can be walked
// with J/K and acted on in place; 하나씩 takes the first three kinds as a stack of cards.
function inboxDo(top, T, n, back = false) {
  const S = Object.fromEntries(T.map((s) => [s.k, s.L]));
  // back: the 나중에 tab, where the action brings the row back to 할 일.
  const act = (k, r) => { const [key, mark] = SEC_ROW[k] ? SEC_ROW[k](r) : [iid(r)]; return back ? backBtn(key) : laterBtn(key, mark); };
  const sec = (k, row, more = "", L = S[k]) => { const s = T.find((x) => x.k === k);
    return L.length ? `<div class="card">${more === null ? `<div style="height:8px"></div>` : `<div class="ch"><h2>${s.n}</h2><span class="n num">${L.length}</span><span class="sp"></span>${more}</div>`}${L.map((r) => row(r, act(k, r))).join("")}<div style="height:8px"></div></div>` : ""; };
  // Kinds that are answered the same way share one card: comments on their way out, and sessions
  // that need a look. Each row says in its own line what it is.
  const grp = (name, parts) => { const rows = parts.map(([k, row]) => S[k].map((r) => row(r, act(k, r))).join("")).join(""), cnt = parts.reduce((a, [k]) => a + S[k].length, 0);
    return cnt ? `<div class="card"><div class="ch"><h2>${name}</h2><span class="n num">${cnt}</span></div>${rows}<div style="height:8px"></div></div>` : ""; };
  // 할 일 only: 신규 above 답변, each head with its number and its one bulk action.
  const K = turnKinds(T), nNew = back ? 0 : todoTotal(K.fresh), lean = {proj: oneProj(), note: new Set(back ? [] : (S.unsent || []).map(iid))},
    look = (L) => sec("look", (x, b) => itemRow(x, false, lean).replace('class="row press"', 'class="row press" data-tk').replace(/<\/button>$/, b + "</button>"), back ? "" : null, L);   // under 신규 / 답변 the head above names the card
  const head = (name, cnt, attr, label, icon) => `<div class="sec ibsec"><span>${name}</span><em class="num">${cnt}</em><span class="sp"></span><button class="ib press" ${attr} aria-label="${label}" title="${label}">${icon}</button></div>`;
  const sendRow = (x, b) => `<div class="row">${thumb(x, "ico sm")}<button class="tx press" data-item="${esc(iid(x))}" style="text-align:left"><div class="t" style="font-size:16px">${esc(x.title)}</div><div class="s">${tl("inboxDo.1", {esc: esc(pname(x.dept)), unsent: x.unsent}).replace(/^\s*·\s*/, "")}</div></button><button class="btn sm fill press" data-sendc="${esc(iid(x))}">${tl("nextCard.6")}</button>${b}</div>`;
  const waitRow = (b, lb) => `<button class="row press" data-tk data-item="${esc(iid(b))}">${thumb(b, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(b.title)}</div><div class="s">${tl("inboxDo.2", {esc: esc(pname(b.dept)), ago: ago(b.asked)})}</div></span><span class="tag pending">${tl("deptView.2")}</span>${lb}</button>`;
  const lostRow = (r, b) => `<div class="row" data-tk><span class="ico sm c-orange">${ic("chat")}</span><button class="tx press" data-go="${esc(roomGo(r.dept, r.session))}" style="text-align:left"><div class="t" style="font-size:16px">${esc(pname(r.dept))}</div><div class="s"><span class="warn">${tl("att.lost.n", {n: r.n})}</span> · ${ago(r.at)}</div></button><button class="btn sm press" data-lostdrop="${esc(r.dept)}" data-lostses="${esc(r.session || "")}">${tl("att.lost.drop")}</button>${b}</div>`;
  const blockRow = (a, b) => `<button class="row press" data-tk data-go="${esc(roomGo(a.dept, a.session))}"><span class="ico sm c-blue">${ic(a.needs === "permission prompt" ? "shield" : "chat")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(pname(a.dept))}</div><div class="s">${esc(needsText(a.needs, a.agent))}</div></span>${b}${ic("chev", "i go")}</button>`;
  const stuckRow = (r, b) => `<button class="row press" data-tk data-go="${esc(roomGo(r.dept, r.key))}"><span class="ico sm c-red">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}</div><div class="s">${esc(r.stuck_hint || r.stuck || "")}</div></span>${b}${ic("chev", "i go")}</button>`;
  const dupRow = (r, b) => `<button class="row press" data-tk data-go="${esc(roomGo(r.dept))}"><span class="ico sm c-teal">${ic("copy")}</span><span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}</div><div class="s">${tl("att.dup.s", {n: r.extra + 1})}</div></span>${b}${ic("chev", "i go")}</button>`;
  const failRow = (t, b) => `<button class="row press" data-tk data-go="routines"><span class="ico sm c-red">${ic("clock")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(t.name)}</div><div class="s">${t.last ? ago(t.last) : ""}${t.note ? " · " + esc(t.note) : ""}</div></span>${b}${ic("chev", "i go")}</button>`;
  // 답변 counts what sits right under it (results and questions): the cards after have their own number.
  const nRep = back ? 0 : K.reply.find((s) => s.k === "look").L.length + secN(T.find((s) => s.k === "ask"));
  const pc = back ? "" : permCard();
  V().innerHTML = top + pc + (n || pc ? "" : back ? `<div class="card plan none"><p>${tl("later.none")}</p></div>` : (window.LOOP_HOME_EMPTY ? window.LOOP_HOME_EMPTY() : `<div class="card plan none"><p>${tl("inboxDo.3")}</p></div>`))
    + (nNew ? head(tl("st.fresh"), nNew, "data-readnew", tl("sx.allread"), icl("read")) + look(K.fresh.find((s) => s.k === "look").L) : "")
    + (!back && nRep ? head(tl("st.reply"), nRep, "data-laterall", tl("later.all"), ic("clock")) : "")
    + look(back ? S.look : K.reply.find((s) => s.k === "look").L)
    + (S.ask.length ? `<div class="card"><div class="ch"><h2>${tl("inboxDo.4")}</h2><span class="n num">${secN(T.find((s) => s.k === "ask"))}</span></div>${S.ask.map((g) => `<div class="askg" data-tk>${askCard(g, (x) => act("ask", x))}</div>`).join("")}<div style="height:8px"></div></div>` : "")
    + grp(tl("inbox.g.send"), [["unsent", sendRow], ["undeliv", waitRow]])
    + grp(tl("inbox.g.sess"), [["blocked", blockRow], ["lost", lostRow], ["stuck", stuckRow], ["dup", dupRow], ["fail", failRow]])
    + (n ? listKeyBar() : "");
  V().querySelectorAll("[data-sendc]").forEach((b) => b.onclick = async (e) => { e.stopPropagation();
    const [p, ...r] = b.dataset.sendc.split("/"), it = D.items.find((x) => iid(x) === b.dataset.sendc); b.disabled = true;
    try { const d = await post("/api/comments/send", {p, i: r.join("/"), v: it?.v});
      toast(d.entry?.live ? tl("inboxDo.8", {p0: pname(it?.dept || "") || tl("sendNow.1")}) : tl("inboxDo.9", {jo: jo(pname(it?.dept || "") || tl("sendNow.1"), "가", "이")})); await load(); SCREENS.inbox("do"); drawChrome(); }
    catch (err) { toast(err.message); b.disabled = false; } });
  const rn = V().querySelector("[data-readnew]"); if (rn) rn.onclick = () => readFresh(K.fresh);
  const la = V().querySelector("[data-laterall]"); if (la) la.onclick = () => laterAll(K.reply.filter((s) => s.k === "look" || s.k === "ask"), tl("later.all.done", {n: nRep}));
  triMark();
}
// 소식: read only, newest first by day. A row is read when it is opened or ticked on its own;
// 모두 읽음 reads the rest (the old 알림 marker).
function inboxNews(top) {
  const L = newsList(), groups = {}; L.forEach((a) => (groups[day(a.at)] ||= []).push(a));
  V().innerHTML = top + (Object.entries(groups).map(([d, xs]) => `<div class="sec">${d}</div><div class="card">${xs.map((a) => `<div class="nrow" data-nk="${esc(newsKey(a))}"><button class="row press" ${a.item ? `data-item="${esc(a.item)}"` : a.talk ? `data-talk="${esc(a.talk)}"` : ""}>${menuIco(a, "ico sm")}<span class="tx"><div class="t" style="font-size:16px;white-space:normal">${newsNew(a) ? `<i class="nd" aria-label="${tl("inboxNews.1")}"></i>` : ""}${esc(a.t)}</div><div class="s">${esc(a.s)} · ${ago(a.at)}</div></span></button>${newsNew(a) ? `<button class="ib press nread" aria-label="${tl("inboxNews.read")}" title="${tl("inboxNews.read")}">${ic("check")}</button>` : ""}</div>`).join("")}</div>`).join("")
    || `<div class="card plan none">${mEmpty("emptyDone")}<p>${tl("inboxNews.2", {p0: NEWS_H / 24})}</p></div>`);
  V().querySelectorAll(".nrow").forEach((r) => {
    r.querySelector(".row").addEventListener("click", () => { if (r.querySelector(".nd")) readNews([r.dataset.nk]); });
    // Ticked in place: the dot and the tick go, the counts follow, nothing else is redrawn.
    r.querySelector(".nread")?.addEventListener("click", () => { readNews([r.dataset.nk]); r.querySelector(".nd").remove(); r.querySelector(".nread").remove();
      const n = newsUnread(), em = V().querySelector('[data-ibt="news"] em');
      if (n) em.textContent = n; else em.remove();
      V().querySelector("[data-iball]").disabled = !n && !unreadRooms().length; drawChrome(); }); });
}
// 기록 (paper trail): what I handed off and how far each got, and what I approved lately.
const TRAIL_C = LT(() => ([["waiting", tl("deptView.2"), "pending", tl("TRAIL_C.1")], ["delivered", tl("itemView.123"), "", tl("TRAIL_C.2")], ["ack", tl("deptView.3"), "work", tl("TRAIL_C.3")], ["approved", tl("STATUS_T.4"), "approved", tl("TRAIL_C.4")]]));
let trailF = null;
function inboxLog(top) {
  const of = (k) => k === "approved" ? D.items.filter((x) => x.status === "approved" && recent(x.at, 24 * 7)).sort(byAt)
    : D.board.filter((b) => b.state === k).sort((a, b) => (b.asked || "").localeCompare(a.asked || ""));
  if (!trailF || !TRAIL_C.some(([k]) => k === trailF)) trailF = (TRAIL_C.find(([k]) => of(k).length) || TRAIL_C[1])[0];
  const [, name, tag, hint] = TRAIL_C.find(([k]) => k === trailF), L = of(trailF);
  V().innerHTML = top + `<div class="chips lfil" data-sk="trailf">${TRAIL_C.map(([k, n]) => `<button class="chip press ${trailF === k ? "on" : ""}" data-trail="${k}">${n} <em class="num">${of(k).length}</em></button>`).join("")}</div>
    ${L.length ? `<div class="card">${L.slice(0, 40).map((b) => `<button class="row press treq" data-item="${esc(iid(b))}">${thumb(b, "ico sm")}<span class="tx">
      <div class="t">${esc(b.title)}</div>${b.said ? `<div class="said">${esc(b.said)}</div>` : ""}
      <div class="s">${esc(pname(gname(b)))} · ${b.v ? esc(b.v) + " · " : ""}${ago(b.asked || b.at)}</div></span>${tag ? `<span class="tag ${tag}">${name}</span>` : ""}</button>`).join("")}<div style="height:6px"></div></div>`
    : `<div class="card plan"><span class="ico c-grey">${ic("check")}</span><p>${tl("inboxLog.1", {name})}</p></div>`}
    <p class="foot-hint">${tl("inboxLog.2", {hint})}</p>`;
  V().querySelectorAll("[data-trail]").forEach((c) => c.onclick = () => { trailF = c.dataset.trail; SCREENS.inbox("log"); });
}

const same = (a, b) => (a || "").replace(/[\\/]+$/, "").toLowerCase() === (b || "").replace(/[\\/]+$/, "").toLowerCase();
const pref = (k, v) => { try { if (v === undefined) return localStorage.getItem("v2-" + k) === "1"; localStorage.setItem("v2-" + k, v ? "1" : "0"); } catch { return false; } };
// ---------- 설정: refern's settings modal (a left menu of pages, a right panel of rows) ----------
// LOOP_SETTINGS takes two forms so other tracks can extend settings; the final merge moves each
// track to the object form. Both are supported here:
//   - a plain function(container)          -> collected onto the "기타" page. It still receives an
//                                             #ext-settings <div> (the old contract), so existing
//                                             connect.js/phone.js/... keep working unchanged.
//   - {page, icon, title, draw(container)} -> its own menu page, slotted by `page`. The reserved
//                                             pages are connect·phone·wake·rules·backup.
let setPage = "connect";
// The settings menu: five groups, each a menu entry whose pages are tabs on the right. Order inside
// the flattened list also sets the tab order; a page not named here (an unknown extension) falls
// into a "기타" tail group. setPage stays a page key, so every deep link (setPage = "license" ...)
// still lands on its page: the group is read off the page.
// Lab 3 sorts the same pages into six smaller groups (five tabs at most, each group one subject):
// the page keys are unchanged, so deep links and the phone list work as before.
const SET_GROUPS = LT(() => (LAB3 ? [
  {k: "connect", i: "plug",    n: tl("ui.setg.connect"), keys: ["connect", "consent", "phone", "apps3d", "wake"]},
  {k: "general", i: "toggle",  n: tl("ui.setg.general"), keys: ["lang", "general"]},
  {k: "look",    i: "monitor", n: tl("ui.setg.screen"),  keys: ["screen", "mode", "views", "beta"]},
  {k: "work",    i: "server",  n: tl("ui.setg.data"),    keys: ["backup", "migrate", "rules", "misc"]},
  {k: "plan",    i: "key",     n: tl("ui.setg.ver"),     keys: ["update", "history", "license"]},
  {k: "info",    i: "info",    n: tl("ui.setg.help"),    keys: ["diag", "selfcheck", "oss", "about"]},
] : [
  {k: "connect", i: "plug",    n: tl("ui.setg.connect"), keys: ["connect", "consent", "phone", "apps3d", "wake"]},
  {k: "look",    i: "monitor", n: tl("ui.setg.look"),    keys: ["lang", "general", "screen", "mode", "views", "beta"]},
  {k: "work",    i: "server",  n: tl("ui.setg.work"),    keys: ["backup", "history", "selfcheck", "diag", "migrate", "rules", "misc"]},
  {k: "plan",    i: "key",     n: tl("ui.setg.plan"),    keys: ["license"]},
  {k: "info",    i: "info",    n: tl("ui.setg.info"),    keys: ["update", "oss", "about"]},
]));
const SET_ORDER = SET_GROUPS.reduce((a, g) => a.concat(g.keys), []);
const SET_GROUP_OF = SET_GROUPS.reduce((m, g, gi) => { g.keys.forEach((k) => m[k] = gi); return m; }, {});
const SET_META = LT(() => ({
  mode:    {i: "sliders", n: tl("custom.tab.mode")},
  screen:  {i: "monitor", n: tl("custom.tab.screen")},
  views:   {i: "list", n: tl("views.title")},
  connect: {i: "plug", n: tl("ui.set.connect")},
  phone:   {i: "phone", n: tl("ui.set.phone")},
  wake:    {i: "bolt", n: tl("ui.set.wake")},
  rules:   {i: "scroll", n: tl("ui.set.rules")},
  backup:  {i: "server", n: tl("ui.set.backup")},
}));
// What a tab says: one or two words. The page under it keeps its full title, and the tab's tooltip says it.
const SET_TAB = LT(() => ({connect: tl("set.tab.connect"), consent: tl("set.tab.consent"), phone: tl("set.tab.phone"), wake: tl("set.tab.wake"), views: tl("set.tab.views"),
  history: tl("set.tab.history"), migrate: tl("set.tab.migrate"), rules: tl("set.tab.rules"), oss: tl("set.tab.oss"), about: tl("set.tab.about"), beta: tl("set.tab.beta")}));
const setTabN = (p) => SET_TAB[p.k] || p.n;
const setRow = (title, desc, ctl) => `<div class="srow"><span class="srtx"><span class="srt">${title}</span>${desc ? `<span class="srd">${desc}</span>` : ""}</span><span class="srctl">${ctl || ""}</span></div>`;
// The taskbar (taskbar.py), where there is one: the app on this PC. Each thing it does has a
// switch of its own; what hangs on another (how usage is drawn, what a pin does) shows with it.
function setBar(box) {
  const B = window.GenokBar;
  if (!box || !B) return;
  if (!B.opts) { B.load().then(() => { if (box.isConnected && B.opts) setBar(box); }, () => {}); return; }
  if (!B.native) return;
  const o = B.opts, held = document.activeElement && box.contains(document.activeElement) ? document.activeElement.dataset.bar : "";
  const rows = [["usage", tl("bar.s.usage")], ["badge", tl("bar.s.badge")], ["pin", tl("bar.s.pin")], ["chat", tl("bar.s.chat")], ["dragout", tl("bar.s.dragout")]]
    .filter(([k]) => o.pin || k !== "chat");
  const styles = [["bar", tl("bar.s.bar")], ["num", tl("bar.s.num")], ["ring", tl("bar.s.ring")]];
  box.innerHTML = `<div class="setsec">${tl("ui.set.sec.taskbar")}</div>` + rows.map(([k, n]) => setRow(n, "", `<button class="sw ${o[k] ? "on" : ""}" role="switch" aria-checked="${!!o[k]}" data-bar="${k}" aria-label="${n}"></button>`)
    + (k === "usage" && o.usage ? setRow(tl("bar.s.style"), "", `<div class="seg" role="group" aria-label="${tl("bar.s.style")}">${styles.map(([v, t]) => `<button class="press ${o.style === v ? "on" : ""}" data-barstyle="${v}" aria-pressed="${o.style === v}">${t}</button>`).join("")}</div>`) : "")).join("");
  if (held) box.querySelector(`[data-bar="${held}"]`)?.focus({preventScroll: true});
  // The switch turns where it stands; the rows are drawn again only when others come or go with it.
  box.querySelectorAll("[data-bar]").forEach((b) => b.onclick = () => { const k = b.dataset.bar, on = !o[k];
    b.classList.toggle("on", on); b.setAttribute("aria-checked", on);
    B.set({[k]: on}).then(() => { if (box.isConnected && (k === "usage" || k === "pin")) setBar(box); }, (e) => { toast(e.message); if (box.isConnected) setBar(box); }); });
  box.querySelectorAll("[data-barstyle]").forEach((b) => b.onclick = () => { const v = b.dataset.barstyle;
    box.querySelectorAll("[data-barstyle]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
    B.set({style: v}).catch((e) => toast(e.message)); });
}
function setGeneral(c) {
  c.innerHTML = `<h2 class="seth">${tl("ui.set.general")}</h2><p class="setd">${tl("ui.set.general.d")}</p>`
    // 언어 comes first: the person finds it before anything else on the page.
    + setRow(tl("lang.label"), tl("lang.d"), langSeg("setlang"))
    // On a phone the two chips are not offered: the heading stays only for the install row.
    + (isPhoneW() && !window.LOOP_PWA ? "" : `<div class="setsec">${tl("ui.set.start")}</div>`)
    + (isPhoneW() ? "" : `<div class="setchips"><button class="setchip press" data-start="connect">${ic("plug")}${tl("connect.title")}</button>`
    + `<button class="setchip press" data-start="phone">${ic("phone")}${tl("phone.title")}</button></div>`)
    + (window.LOOP_PWA ? LOOP_PWA.row() : "")
    + `<div class="setsec">${tl("ui.set.sec.behavior")}</div>`
    + setRow(tl("settings.2"), tl("settings.3"), `<button class="sw ${pref("calm") ? "on" : ""}" role="switch" aria-checked="${pref("calm")}" data-pref="calm" aria-label="${tl("settings.2")}"></button>`)
    + (isPhoneW() ? "" : setRow(tl("settings.keysbar"), tl("settings.keysbar.d"), `<button class="sw ${pref("keys") ? "on" : ""}" role="switch" aria-checked="${pref("keys")}" data-pref="keys" aria-label="${tl("settings.keysbar")}"></button>`))
    + setRow(tl("settings.steps"), tl("settings.steps.d"), `<button class="sw ${pref("steps") ? "on" : ""}" role="switch" aria-checked="${pref("steps")}" data-pref="steps" aria-label="${tl("settings.steps")}"></button>`)
    + setRow(tl("settings.ctxrows"), tl("settings.ctxrows.d"), `<button class="sw ${pref("ctxrows") ? "on" : ""}" role="switch" aria-checked="${pref("ctxrows")}" data-pref="ctxrows" aria-label="${tl("settings.ctxrows")}"></button>`)
    + setRow(tl("settings.redact"), tl("settings.redact.d"), `<button class="sw ${pref("redact") ? "on" : ""}" role="switch" aria-checked="${pref("redact")}" data-pref="redact" aria-label="${tl("settings.redact")}"></button>`)
    + setRow(tl("settings.4"), tl("settings.5"), `<button class="sw ${sound() ? "on" : ""}" role="switch" aria-checked="${sound()}" id="snd" aria-label="${tl("settings.4")}"></button>`)
    + (Object.keys(noAsk()).length ? setRow(tl("noask.t"), tl("noask.d", {n: Object.keys(noAsk()).length}), `<button class="btn sm press" id="noaskb">${tl("noask.on")}</button>`) : "")
    + `<div class="srow" id="autor" hidden><span class="srtx"><span class="srt">${tl("auto.1")}</span><span class="srd">${tl("auto.2")}</span></span><span class="srctl"><button class="sw" role="switch" aria-checked="false" id="autob" aria-label="${tl("auto.1")}"></button></span></div>`
    + `<div class="setsec">${tl("ui.set.sec.notify")}</div>`
    + `<div class="srow"><span class="srtx"><span class="srt">${tl("settings.6")}</span><span class="srd" id="pushs">${tl("settings.7")}</span></span><span class="srctl"><button class="btn sm press" id="pushb" disabled>${tl("settings.8")}</button></span></div>`
    // The icon's number is the phone's business (and an installed PWA's): elsewhere there is no badge to set.
    + (isPhoneW() || navigator.setAppBadge ? [["res", tl("settings.badge.res"), tl("settings.badge.res.d")], ["chat", tl("settings.badge.chat"), tl("settings.badge.chat.d")]].map(([k, n, d]) => setRow(n, d,
      `<button class="sw ${badgeOn(k) ? "on" : ""}" role="switch" aria-checked="${badgeOn(k)}" data-badge="${k}" aria-label="${n}"></button>`)).join("") : "")
    + `<div id="setbar"></div>`;
  setBar(c.querySelector("#setbar"));
  c.querySelectorAll("[data-badge]").forEach((b) => b.onclick = () => { const on = !badgeOn(b.dataset.badge);
    // Both switches are written, so the earlier three-way value stops deciding either of them.
    const now = {res: badgeOn("res"), chat: badgeOn("chat"), [b.dataset.badge]: on};
    lsSet("v2-badge-res", now.res ? "1" : "0"); lsSet("v2-badge-chat", now.chat ? "1" : "0"); lsSet("v2-badge", "");
    b.classList.toggle("on", on); b.setAttribute("aria-checked", on); drawChrome(); });
  c.querySelectorAll("[data-start]").forEach((b) => b.onclick = () => {
    const what = b.dataset.start;
    if (what === "phone") { try { window.LOOP_PHONE?.open(); } catch (e) {} }
    else if (what === "connect") { setPage = "connect"; setShowPage = true; SCREENS.settings(); }
  });
  const na = c.querySelector("#noaskb");
  if (na) na.onclick = () => { noAskClear(); na.closest(".srow").remove(); toast(tl("noask.done")); };
  const snd = c.querySelector("#snd");
  if (snd) snd.onclick = (e) => { const v = !sound(); sound(v); e.currentTarget.classList.toggle("on", v); e.currentTarget.setAttribute("aria-checked", v);
    document.querySelectorAll("video").forEach((x) => x.muted = !v); };
  drawPush(); drawAutostart(); window.LOOP_PWA?.wire(c);
}
// Phone: the languages as a short list, each in its own name, a check on the current one. Picking one
// applies it (setLang, the same as the switch on the PC) and goes back to the list.
function setLanguage(c) {
  c.innerHTML = `<h2 class="seth">${tl("lang.label")}</h2><div class="sgcard langlist" role="radiogroup" aria-label="${tl("lang.label")}">`
    + LANG_NAMES.map(([k, n]) => `<button class="sgrow press" role="radio" aria-checked="${LANG() === k}" data-lang="${k}" lang="${k}"><span class="srn">${n}</span>${LANG() === k ? ic("check", "i ck") : ""}</button>`).join("") + `</div>`;
  // The click itself is handled by the one [data-lang] listener (setLang); this only leaves the page after it.
  c.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.lang === LANG()) return setBackNow?.();
    window.addEventListener("loop-lang", () => setTimeout(() => { if (cur === "settings") setBackNow?.(); }, 0), {once: true});
  }));
}
function setUpdate(c) {
  c.innerHTML = `<h2 class="seth">${tl("update.1")}</h2><p class="setd">${tl("ui.set.update.d")}</p>`
    + `<div class="srow updrow"><span class="srtx"><span class="srt">${tl("update.1")}</span><span class="srd" id="upds" aria-live="polite">…</span></span><span class="srctl"><button class="btn sm press" id="updchk">${tl("upd.check")}</button></span></div>`
    + `<div class="updbox" id="updbox" hidden></div>`
    + setRow(tl("settings.9"), D.at ? hm(D.at) + tl("settings.1") : "", "");
  c.querySelector("#updchk").onclick = () => drawUpdate(true, true);
  // Opening the page looks at the feed once; a redraw of the same page paints what is already known.
  if (UPD.u && setUpdSeen) { drawUpdBox(); drawUpdate(false); } else { setUpdSeen = true; drawUpdate(true); }
}
let setUpdSeen = false;
// The logo mark (web/orb.js markSVG): the breathing ring's still frame in the key colour.
const brandMark = (px) => window.Orb?.markSVG ? window.Orb.markSVG(px) : "";
// "Lite · v0.1.46": plan names are the store's, in English on every screen.
const planName = () => ({free: "Lite", pro: "Pro", lifetime: "Lifetime", trial: "Trial"}[(window.LOOP_PLAN || {}).plan] || "Lite");
const planVer = () => tl("ui.statusPlan", {plan: planName(), v: D.ver});
function setAbout(c) {
  // The top (mark, version, tools, system, update, feedback, licenses) is web/about.js; the tour
  // and the manual stay here.
  c.innerHTML = `<div id="abt-top"></div>`
    + (window.LOOP_TOUR ? `<div class="setsec">${tl("ui.set.help")}</div>`
      + setRow(tl("tour.replay"), tl("tour.replayd"), `<button class="btn sm press" data-tour-replay>${tl("tour.replaybtn")}</button>`) : "")
    // First setup (name, data folder, agent logins in a window on the PC) is the PC's business, as in
    // onboard.js: a phone over serve would replay screens it cannot act on.
    + (["127.0.0.1", "localhost", "::1", ""].includes(location.hostname) ? (window.LOOP_TOUR ? "" : `<div class="setsec">${tl("ui.set.help")}</div>`)
      + setRow(tl("onboard.reopen"), tl("onboard.reopend"), `<button class="btn sm press" data-first-replay>${tl("onboard.reopenbtn")}</button>`) : "")
    + `<div class="setsec">${tl("settings.10")}<button type="button" class="lnk press" id="abt-manb" aria-expanded="false" aria-controls="abt-manual">${tl("ui.more1")}</button></div>`
    + `<div id="abt-manual" hidden>${MENUS.map((m) => setRow(esc(m.n), MANUAL[m.k] || m.d, "")).join("")}</div><p class="abt-foot">© 2026 Genok</p>`;
  try { window.LOOP_ABOUT(c.querySelector("#abt-top")); } catch (e) { console.error(e); }
  // The tour re-creates the sample if it was deleted, and rewinds it to v1 if it was walked.
  // 페이지별 사용법 is reference: one press shows it where it stands.
  c.querySelector("#abt-manb").onclick = (e) => {
    const m = c.querySelector("#abt-manual"), open = m.hidden;
    m.hidden = !open; e.currentTarget.setAttribute("aria-expanded", String(open));
    e.currentTarget.textContent = open ? tl("itemView.30") : tl("ui.more1");
  };
  const rb = c.querySelector("[data-tour-replay]");
  if (rb) rb.onclick = () => { try { window.LOOP_TOUR.start({}); } catch (e) {} };
  const fb = c.querySelector("[data-first-replay]");
  if (fb) fb.onclick = () => { try { window.LOOP_FIRSTRUN ? window.LOOP_FIRSTRUN.replay() : window.LOOP_ONBOARD?.open(); } catch (e) {} };
}
SCREENS.settings = function () {
  // tabs.js sorts LOOP_SETTINGS into own-page entries (object form {page, icon, title, draw}, or
  // a draw function carrying .page/.title) and bare functions (the old 기타 slot). Custom's own
  // pages (mode·screen·views·accounts) are object-form entries, so they land in objPages too.
  const {pages: objPages, misc: fnDraws} = (typeof loopSettings === "function")
    ? loopSettings()
    : {pages: (window.LOOP_SETTINGS || []).filter((f) => f && typeof f === "object" && typeof f.draw === "function"),
       misc: (window.LOOP_SETTINGS || []).filter((f) => typeof f === "function")};
  // No icon twice on one screen: the gear is the way into settings itself (rail, top bar).
  const pages = [{k: "general", i: "toggle", n: tl("ui.set.general"), draw: setGeneral}];
  objPages.forEach((o, i) => { const m = SET_META[o.page] || {}; pages.push({k: o.page || ("ext" + i), i: o.icon || m.i || "tool", n: o.title ? tl(o.title) : (m.n || tl("ui.set.other")), draw: o.draw}); });
  if (fnDraws.length) pages.push({k: "misc", i: "tool", n: tl("ui.set.other"), draw: (c) => { const ext = document.createElement("div"); ext.id = "ext-settings"; c.appendChild(ext);
    // Every entry may decide to show nothing (pack.js outside the installed build): say so instead of a blank page.
    Promise.allSettled(fnDraws.map((f) => { try { return f(ext); } catch (e) { console.error(e); } }))
      .then(() => { if (!ext.children.length) ext.innerHTML = `<div class="s" style="padding:14px 4px">${tl("ui.set.other.empty")}</div>`; }); }});
  // The phone lists 언어 as a row of its own (value on the right); the PC has it at the top of 일반.
  if (isPhoneW()) pages.push({k: "lang", i: "globe", n: tl("lang.label"), draw: setLanguage});
  pages.push({k: "update", i: "dl", n: tl("update.1"), draw: setUpdate});
  pages.push({k: "about", i: "info", n: tl("ui.set.about"), draw: setAbout});
  // Order by the grouped menu; anything unlisted (an unknown extension) tails as its own group.
  const TAIL = SET_GROUPS.length;
  const grpOf = (k) => (k in SET_GROUP_OF ? SET_GROUP_OF[k] : TAIL);
  const rank = (k) => { const i = SET_ORDER.indexOf(k); return i < 0 ? SET_ORDER.length : i; };
  pages.sort((a, b) => (grpOf(a.k) - grpOf(b.k)) || (rank(a.k) - rank(b.k)));
  // On a direct load the page scripts register after this first draw. setPage keeps what was asked
  // for; 일반 stands in (never a lazy page: loading one now would swallow the later registrations)
  // and the screen is drawn again once everything has loaded.
  const found = pages.find((p) => p.k === setPage);
  if (!found && document.readyState !== "complete")
    window.addEventListener("load", () => { if (cur === "settings") SCREENS.settings(); }, {once: true});
  // The phone opens on a short menu: what is changed from a phone. The rest (connections, records,
  // the key) is set up at the PC and waits behind one row.
  // (Since 0.1.55 the phone lists every group as well; SET_PHONE is kept for the count below.)
  const phone = isPhoneW(), short = false;
  const rest = pages.filter((p) => !SET_PHONE.includes(p.k)).length;
  const active = found || pages.find((p) => p.k === "general");
  // One menu entry per group; its pages are the tabs. The phone lists only what it can change, plus
  // the open page (a deep link may land on a PC-only page).
  const shown = (p) => !(phone && p.k === "phone") && (!short || SET_PHONE.includes(p.k) || p === active);
  const groupOf = (gi) => gi < TAIL ? SET_GROUPS[gi] : {k: "other", i: "tool", n: tl("ui.set.other")};
  const inGroup = (gi) => pages.filter((p) => grpOf(p.k) === gi && shown(p));
  const actG = grpOf(active.k);
  setTabOf[groupOf(actG).k] = active.k;
  // The phone's list says under each group what it is set to now (a value this screen already
  // holds; where there is none, the pages inside). The PC menu does not show the line.
  const sumOf = (gi) => {
    const g = groupOf(gi), names = inGroup(gi).map(setTabN).join(" · ");
    try {
      if (g.k === "connect") return CONN ? connLabel() : names;
      if (g.k === "look") return (document.documentElement.dataset.theme === "light" ? tl("custom.theme.light") : tl("custom.theme.dark")) + " · " + (sound() ? tl("ui.sets.snd.on") : tl("ui.sets.snd.off"));
      if (g.k === "plan") return planName();
      if (g.k === "info" && D.ver) return updOn() ? tl("ui.sets.upd", {v: D.ver}) : tl("ui.sets.ver", {v: D.ver});
    } catch (e) {}
    return names;
  };
  // Phone: each group is a card under its own bold header; every row is one page, its current value
  // (where there is one) on the right in the accent colour. The PC keeps one menu entry per group.
  const rowVal = (k) => { try {
    if (k === "lang") return LANG_NAMES.find(([l]) => l === LANG())?.[1] || "";
    if (k === "screen") return document.documentElement.dataset.theme === "light" ? tl("custom.theme.light") : tl("custom.theme.dark");
    if (k === "connect") return CONN ? connLabel() : "";
    if (k === "license") return planName();
    if (k === "update") return updOn() ? tl("set.val.new") : D.ver ? "v" + D.ver : "";
  } catch (e) {} return ""; };
  let menu = "";
  if (phone) {
    for (const gi of LAB3 ? [1, 2, 0, 3, 4, 5, TAIL] : [1, 0, 2, 3, 4, TAIL]) {
      const g = groupOf(gi), gp = inGroup(gi);
      if (!gp.length) continue;
      menu += `<section class="setgrp"><h3 class="setgh">${esc(g.n)}</h3><div class="sgcard">`
        + gp.map((p) => `<button class="sgrow press" data-setp="${esc(p.k)}"><span class="smi">${ic(p.i)}</span><span class="srn">${esc(setTabN(p))}</span>${p.k === "consent" ? `<span class="setmn num" data-setlater hidden></span>` : ""}<span class="srv" data-sv="${esc(p.k)}">${esc(rowVal(p.k))}</span><span class="smc">${ic("chev")}</span></button>`).join("")
        + `</div></section>`;
    }
  }
  for (let gi = 0; gi <= TAIL && !phone; gi++) {
    const g = groupOf(gi), gp = inGroup(gi);
    if (!gp.length) continue;
    // The group opens on the tab last seen in it, or its first.
    const to = gp.find((p) => p.k === setTabOf[g.k]) || gp[0];
    // On the phone the list is a screen of its own: no row is "the open one" there.
    const on = !phone && gi === actG;
    menu += `<button class="setmi press ${on ? "on" : ""}" data-setp="${esc(to.k)}"${on ? ` aria-current="page"` : ""}><span class="smi">${ic(g.i)}</span><span class="smn">${esc(g.n)}</span>${g.k === "connect" ? `<span class="setmn num" data-setlater hidden></span>` : ""}<span class="sms" data-sums="${gi}">${esc(sumOf(gi))}</span><span class="smc">${ic("chev")}</span></button>`;
  }
  if (false && phone && rest) menu += `<button class="setmi setmore press" data-setall aria-expanded="${!short}"><span class="smi">${ic("monitor")}</span>${short ? tl("ui.set.pcmore", {n: rest}) : tl("ui.set.pcless")}</button>`;
  const tabsOf = inGroup(actG);
  const tabs = tabsOf.length > 1 ? `<div class="settabs" role="tablist" aria-label="${esc(groupOf(actG).n)}">`
    + tabsOf.map((p) => `<button class="settab press ${p === active ? "on" : ""}" role="tab" id="settab-${esc(p.k)}" aria-selected="${p === active}" aria-controls="setpanel" tabindex="${p === active ? 0 : -1}" data-setp="${esc(p.k)}"${setTabN(p) !== p.n ? ` title="${esc(p.n)}"` : ""}>${esc(setTabN(p))}</button>`).join("") + `</div>` : "";
  // "again": settings drawn over itself (a row or tab was picked), so the phone does not fade the
  // whole screen in a second time under the page that is sliding.
  V().innerHTML = `<div class="setwrap${V().querySelector(".setwrap") ? " again" : ""}"><div class="setbackdrop" data-back></div>
    <div class="setmodal" role="dialog" aria-modal="true" aria-label="${tl("TABS.4")}">
      <aside class="setmenu"><button class="setbk press" data-setbk aria-label="${tl("head.1")}">${ic("back")}</button><div class="setmtitle">${tl("TABS.4")}<button class="setxm press" data-back aria-label="${tl("ui.close")}">${ic("x")}</button></div>
        <div class="setlist">${menu}</div>
      </aside>
      <section class="setpage" id="setpage"><div class="setnavb"><button class="setback press" data-setback aria-label="${tl("ui.set.menu")}">${ic("back")}${tl("TABS.4")}</button></div>${tabs}</section>
      <button class="setx press" data-back aria-label="${tl("ui.close")}">${ic("x")}</button>
    </div></div>`;
  // On the phone, the list and the page are two layers; showpage means a page is open (with a back
  // button) and setNav places them while one slides over the other. On desktop both panels always
  // show, so the classes are harmless there.
  if (!setNav.run && !setNav.drag) setNav.p = setShowPage ? 1 : 0;
  setNavPaint();
  const pg = document.getElementById("setpage");
  setEdge(pg);
  const body = document.createElement("div"); pg.appendChild(body);
  body.id = "setpanel";
  if (tabs) { body.setAttribute("role", "tabpanel"); body.setAttribute("aria-labelledby", "settab-" + active.k); body.dataset.tab = active.k; }
  // A tab or group that was just picked eases in; a redraw of the same page (fresh values) does not.
  if (setSwap) { body.classList.add("swap"); setSwap = false; }
  try { active.draw(body); } catch (e) { console.error(e); }
  // From the phone's list the page slides in over it (setNavTo); a tab inside an open page eases in as before.
  const goPage = (k, focus) => { const slide = isPhoneW() && !setShowPage; setPage = k; setSwap = !slide;
    // The page is a level of history: the browser's / Android's back leaves it for the list (popstate below).
    if (slide) { setNavTo(1); try { history.pushState({setpage: 1}, ""); } catch (e) {} } else setShowPage = true;
    SCREENS.settings();
    if (focus) { const t = V().querySelector(focus); if (t) t.focus({preventScroll: true}); } };
  V().querySelectorAll(".setmi[data-setp],.sgrow[data-setp]").forEach((b) => b.onclick = (e) => goPage(b.dataset.setp, isPhoneW() || e.detail ? "" : ".setmi.on"));
  const strip = V().querySelector(".settabs");
  if (strip) {
    strip.querySelectorAll(".settab").forEach((b) => b.onclick = (e) => goPage(b.dataset.setp, e.detail ? "" : ".settab.on"));
    // Arrow keys walk the tabs (Home/End jump); the picked tab opens and keeps the focus.
    strip.onkeydown = (e) => {
      const ks = tabsOf.map((p) => p.k), i = ks.indexOf(active.k);
      const j = e.key === "ArrowRight" ? (i + 1) % ks.length : e.key === "ArrowLeft" ? (i - 1 + ks.length) % ks.length
        : e.key === "Home" ? 0 : e.key === "End" ? ks.length - 1 : -1;
      if (j < 0 || j === i) return;
      e.preventDefault(); goPage(ks[j], ".settab.on");
    };
    // A long row scrolls inside itself: keep the open tab in sight.
    const on = strip.querySelector(".settab.on");
    if (on && strip.scrollWidth > strip.clientWidth) strip.scrollLeft = Math.max(0, on.offsetLeft - (strip.clientWidth - on.offsetWidth) / 2);
  }
  // The count of put-off permission requests beside 연결 (web/consent.js owns the number).
  try { window.LOOP_CONSENT?.count(); } catch (e) {}
  const allBtn = V().querySelector("[data-setall]");
  if (allBtn) allBtn.onclick = () => { setAllPages = !setAllPages; SCREENS.settings(); };
  const backBtn = V().querySelector("[data-setback]");
  // Back leaves the way the page came in; the list under it shows what was just changed.
  setSums = () => { V().querySelectorAll("[data-sums]").forEach((s) => { s.textContent = sumOf(+s.dataset.sums); });
    V().querySelectorAll("[data-sv]").forEach((s) => { s.textContent = rowVal(s.dataset.sv); }); };
  // A page opened straight from 전체 goes back to 전체; one opened from this list goes back to the list.
  const bk = () => { setSums(); if (setDeep && window.LOOP_ALL) LOOP_ALL.pop(); else setLeave(); };
  setBackNow = bk;
  if (backBtn) backBtn.onclick = bk;
  // The list's own arrow: back to 전체 when it was opened from there, else where history says.
  const lb = V().querySelector("[data-setbk]");
  if (lb) lb.onclick = () => { if (window.LOOP_ALL?.from()) LOOP_ALL.pop(); else back(); };
};
let setShowPage = false, setAllPages = false, setSwap = false, setSums = null;
let setPopV = 0;           // the speed a swipe let go with, handed on to the slide that popstate then runs
// Leave the open page for the list. The page sits one entry above the list in history (goPage), so
// going back through history is what keeps the arrow, the swipe and the system back in step.
function setLeave(v) { if (history.state?.setpage) { setPopV = v || 0; history.back(); } else setNavTo(0, v); }
addEventListener("popstate", () => {
  if (cur !== "settings" || detail || !setShowPage || setDeep || history.state?.setpage || location.hash !== "#settings") return;
  const v = setPopV; setPopV = 0; setSums?.(); setNavTo(0, v || undefined);
});
let setDeep = false;       // the page on screen was opened straight from a 전체 row (web/all.js), not from the list
let setBackNow = null;     // what the page's back arrow does now (the edge swipe uses the same)
// Phone: the list and the open page as two layers. p runs 0 (list) to 1 (page); run is the spring
// moving it, drag a finger holding it. It lives outside the screen's markup, so a redraw in the
// middle of a slide (a page asking for fresh values) carries on from the same spot.
const setNav = {p: 0, run: null, drag: false};
function setNavPaint() {
  const m = V().querySelector(".setmodal"); if (!m) return;
  const p = Math.min(1, Math.max(0, setNav.p)), mid = !!setNav.run || setNav.drag;
  m.classList.toggle("moving", mid);
  m.classList.toggle("showpage", !mid && p > 0.5);
  // Written on the two layers themselves (a variable on the modal would restyle everything in it
  // each frame) and taken off again at rest. Reduced motion: the page fades, nothing moves.
  const pg = m.querySelector(".setpage").style, mn = m.querySelector(".setmenu").style;
  if (!mid) pg.transform = pg.opacity = mn.transform = mn.opacity = mn.filter = "";
  else if (RM()) { pg.opacity = p.toFixed(3); mn.transform = mn.opacity = mn.filter = ""; }
  else { pg.transform = `translate3d(${((1 - p) * 100).toFixed(3)}%,0,0)`; mn.transform = `translate3d(${(p * -22).toFixed(3)}%,0,0)`; mn.filter = `brightness(${(1 - p * 0.18).toFixed(3)})`; }
}
// Send the page in (1) or out (0) from where it is now, at the speed it has (v, in screens per
// second: a finger's on release, or the unfinished slide's). Critically damped: no bounce, since a
// page overshooting would uncover what is behind it. Reduced motion gets a short fade (v2.css).
function setNavTo(to, v) {
  const was = setNav.run ? setNav.run.stop() : null;
  setNav.run = null; setShowPage = to === 1;
  if (!isPhoneW() || !window.Motion?.drive || !V().querySelector(".setmodal")) { setNav.p = to; return setNavPaint(); }
  setNav.run = Motion.drive({z: 1, r: RM() ? 0.2 : 0.38, from: setNav.p, to, v: v != null ? v : was ? was.v : 0,
    step: (x) => { setNav.p = x; setNavPaint(); }, done: () => { setNav.run = null; setNavPaint(); }});
  setNavPaint();
}
// The open page follows a finger that starts at its left edge, 1:1 from where it was caught. A
// page still sliding can be caught anywhere on it. Letting go carries the finger's speed on, and
// where that flick would coast to decides between going back and staying.
function setEdge(pg) {
  let id = null, x0 = 0, y0 = 0, p0 = 0, lock = false, pts = [];
  const W = () => pg.offsetWidth || innerWidth;
  const end = (e, cancelled) => {
    if (e.pointerId !== id) return;
    id = null;
    if (!setNav.drag) return;
    setNav.drag = false;
    if (!lock) return setNavTo(setShowPage ? 1 : 0, 0);          // caught mid-slide and let go: carry on
    // A finger that stopped before lifting has no speed left, whatever it was doing before.
    const a = pts[0], b = pts[pts.length - 1], vx = cancelled || b.t - a.t < 1 || e.timeStamp - b.t > 80 ? 0 : (b.x - a.x) / (b.t - a.t) * 1000;
    const out = (1 - setNav.p) * W() + Motion.project(vx) > W() / 2;
    if (out) setSums?.();
    if (out && setDeep && window.LOOP_ALL) return void LOOP_ALL.pop();    // opened from 전체: the swipe goes back there
    if (out) return setLeave(-vx / W());
    setNavTo(1, -vx / W());
  };
  pg.addEventListener("pointerdown", (e) => {
    if (id !== null || e.button || !isPhoneW() || RM() || !window.Motion?.drive) return;
    const mid = !!setNav.run;
    if (!mid && (!setShowPage || e.clientX > 32 || e.target.closest("input,textarea,select"))) return;
    id = e.pointerId; x0 = e.clientX; y0 = e.clientY; lock = false; pts = [{x: x0, t: e.timeStamp}];
    if (mid) { setNav.run.stop(); setNav.run = null; setNav.drag = true; setNavPaint(); }
  });
  pg.addEventListener("pointermove", (e) => {
    if (e.pointerId !== id) return;
    const dx = e.clientX - x0, dy = e.clientY - y0;
    if (!lock) {
      // A few px of slack tell a swipe from a tap or a scroll; a page caught in flight needs less.
      if (Math.abs(dx) < (setNav.drag ? 3 : 10) && Math.abs(dy) < 10) return;
      if (Math.abs(dy) > Math.abs(dx) || (!setNav.drag && dx < 0)) { if (setNav.drag) { setNav.drag = false; setNavTo(setShowPage ? 1 : 0, 0); } id = null; return; }
      lock = true; setNav.drag = true; x0 = e.clientX; p0 = setNav.p;
      try { pg.setPointerCapture(id); } catch (er) {}
    }
    pts.push({x: e.clientX, t: e.timeStamp}); while (pts.length > 2 && e.timeStamp - pts[0].t > 100) pts.shift();
    setNav.p = Math.min(1, Math.max(0, p0 - (e.clientX - x0) / W())); setNavPaint();
  });
  // A swipe that is ours is not also the browser's: left alone, Chromium reads the lift as a fling
  // and swallows the next tap (the row tapped right after swiping back did nothing).
  pg.addEventListener("touchmove", (e) => { if (lock && id !== null && e.cancelable) e.preventDefault(); }, {passive: false});
  pg.addEventListener("pointerup", (e) => end(e, false));
  pg.addEventListener("pointercancel", (e) => end(e, true));
}
const setTabOf = {};
// consent: the dialog says a grant can be taken back in settings, so the phone needs that page too.
const SET_PHONE = ["general", "screen", "consent", "update", "about"];
const isPhoneW = () => { try { return matchMedia("(max-width:720px)").matches; } catch (e) { return false; } };
// Only the installed Windows app can start at login; elsewhere the row stays hidden.
// A Store install has no switch of ours: Windows owns it (the package's startup task), so the
// row carries a button that opens Windows' own Startup apps page instead of a switch.
async function drawAutostart() {
  const a = await fetch("/api/autostart").then((r) => r.json()).catch(() => null);
  const row = document.getElementById("autor"), b = document.getElementById("autob");
  if (!a || !row) return;
  if (!a.installed) {
    const m = await fetch("/api/msix").then((r) => r.json()).catch(() => null);
    if (!m || !m.packaged) return;
    row.querySelector(".srd").textContent = tl("auto.store.d");
    const go = document.createElement("button");
    go.className = "btn sm press"; go.id = "autob"; go.textContent = tl("auto.store.b");
    go.onclick = () => post("/api/msix/startup-settings", {}).catch((e) => toast(e.message));
    b.replaceWith(go);
    row.hidden = false;
    return;
  }
  row.hidden = false;
  const show = (v) => { b.classList.toggle("on", v); b.setAttribute("aria-checked", v); };
  show(a.on);
  b.onclick = async () => { const v = b.getAttribute("aria-checked") !== "true"; show(v);
    try { show((await post("/api/autostart", {on: v})).on); } catch (e) { show(!v); toast(e.message); } };
}
document.addEventListener("click", (e) => { if (e.target.closest("[data-openweb]")) post("/api/open-browser", {hash: location.hash}).catch((x) => toast(x.message)); });
// The Windows build updates itself, but only when asked. Settings > 버전 is the full view: 업데이트
// 확인, whether the newer build can be installed at all (an unsigned feed cannot - the server says
// why), what changed, known issues, and the one line of progress. The title-bar pill (updPill)
// is the everyday way in and shares this state (UPD).
// go: the person pressed 업데이트 확인 themselves. A newer build it finds is shown with its notes
// and the 업데이트 button; nothing is fetched until that button is pressed.
const updPhone = () => matchMedia("(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none)").matches;
async function drawUpdate(force, go) {
  const s0 = document.getElementById("upds"), b0 = document.getElementById("updchk");
  if (s0 && force) { s0.textContent = tl("upd.checking"); s0.classList.remove("warn"); if (b0) b0.disabled = true; }
  const u = await getUpd(force);
  const s = document.getElementById("upds"), b = document.getElementById("updchk");
  if (b) b.disabled = false;
  if (u) takeUpd(u);
  if (u && !s && u.available && !u.can_apply && !force) toast(tl("update.3", {v: u.latest}), 4000);
  if (s && !u) { s.textContent = tl("upd.nocheck"); s.classList.add("warn"); if (b) b.textContent = tl("upd.retry"); }
  if (go && u && u.can_apply && !updPhone()) updShow();
}
// What a restart would cut off right now: sessions mid-answer, or text typed and not sent (the
// page reloads, and a draft lives only in the page). The update is fetched anyway and then waits
// with this one line and 지금 다시 켜기 - never a silent restart over someone's work.
const updBusy = () => (D.sessions || []).filter((r) => state(r) === "work").length;
const updDraft = () => typeof pjUnsent === "function" && pjUnsent();
const updHold = () => { const n = updBusy(); return n ? tl("upd.busy", {n}) : updDraft() ? tl("upd.draft") : ""; };
const updList = (a, cls) => `<ul class="${cls}">${a.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>`;
// The one line of progress: 받는 중 n% -> 설치 중 -> 다시 켜는 중.
const updLine = () => UPD.phase === "dl" ? tl("upd.dl", {p: UPD.pct}) : UPD.phase === "install" ? tl("upd.installing") : UPD.phase === "restart" ? tl("upd.restarting") : "";
// The part that changes while an update runs, shared by the settings box (ub*) and the pill's
// popover (up*): the failure, the progress line or why it waits, and at most one button.
function updNow(x) {
  if (updPhone()) return `<p class="ubd">${tl("upd.phone.pc")}</p>`;
  const hold = UPD.phase === "ready" ? updHold() : "";
  let h = UPD.err ? `<p class="${x}w" role="alert">${esc(tl("upd.failed", {why: UPD.err}))}</p>` : "";
  if (UPD.phase === "dl") h += `<div class="ubp" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${UPD.pct}"><i style="width:${UPD.pct}%"></i></div>`;
  if (hold) h += `<p class="${x}w">${esc(hold)}</p>`;
  const line = updLine() || (UPD.phase === "ready" && !hold ? tl("upd.readynote") : "");
  const btn = UPD.phase === "dl" ? `<button class="btn sm press" data-updcancel>${tl("upd.cancel")}</button>`
    : UPD.phase === "ready" ? `<button class="btn sm fill press" data-updapply>${hold ? tl("upd.now") : tl("upd.apply")}</button>`
    : updLocked() ? "" : `<button class="btn sm fill press" data-updgo>${UPD.err ? tl("upd.retry") : tl("upd.go")}</button>`;
  return h + `<div class="${x}a"><span class="${x === "ub" ? "ubd" : "upl"}" aria-live="polite">${esc(line)}</span>${btn}</div>`;
}
// The updater (updater.py latest) words its errors in Korean; the fixed ones read from the dictionary.
const updErr = (e) => LANG() === "ko" ? e : /준비 중/.test(e) ? tl("upd.e.soon") : /목록을 읽지/.test(e) ? tl("upd.e.list") : /연결하지 못했/.test(e) ? tl("upd.e.net") : e;
function drawUpdBox() {
  const s = document.getElementById("upds"), box = document.getElementById("updbox"), b = document.getElementById("updchk"), u = UPD.u;
  if (!s || !box || !u) return;
  const sig = [updPhone(), u.latest, u.found, u.blocked, u.error, u.checked, u.can_apply, UPD.phase, UPD.pct, UPD.err, UPD.phase === "ready" ? updHold() : ""].join("|");
  if (box.dataset.sig === sig) return;
  box.dataset.sig = sig;
  const bad = !u.found && !!u.error, at = u.checked ? " · " + tl("upd.checked", {t: hm(u.checked)}) : "";
  s.classList.toggle("warn", bad || !!u.blocked);
  s.textContent = u.packaged ? tl("upd.store", {cur: u.current})
    : bad ? tl("upd.cur", {cur: u.current}) + " · " + updErr(u.error)
    : u.blocked ? tl("upd.blocked", {cur: u.current, v: u.latest}) + at
    : (u.found ? tl("update.4", {cur: u.current, v: u.latest}) : tl("update.5", {cur: u.current})) + at;
  if (b) { b.hidden = !!u.packaged; b.textContent = bad ? tl("upd.retry") : tl("upd.check"); }
  if (updPhone()) {
    if (b) b.hidden = false;
    box.hidden = false;
    setHTML(box, `<p class="ubd">${tl("upd.phone.pc")}</p>`);
    return;
  }
  if (!u.found || u.packaged) { box.hidden = true; box.innerHTML = ""; return; }
  box.hidden = false;
  let h = `<div class="ubh">${esc(tl("upd.title", {v: u.latest}))}</div>`;
  if (u.blocked) h += `<p class="ubw" role="alert">${esc(u.blocked)}</p><p class="ubd">${tl("upd.blocked.d")}</p>`;
  else {
    h += `<div class="ubs">${tl("upd.notes")}</div>` + (u.notes?.length ? updList(u.notes, "ubl") : `<p class="ubd">${tl("upd.nonotes")}</p>`);
    if (u.known_issues?.length) h += `<div class="ubs">${tl("upd.issues")}</div>` + updList(u.known_issues, "ubl");
    h += u.can_apply ? updNow("ub") : `<p class="ubd">${tl("upd.srconly")}</p>`;
  }
  setHTML(box, h);
}
// After /api/update hands over to the swap script: wait for the new build to answer, then reload.
async function awaitRestart() {
  const t0 = Date.now(); await new Promise((r) => setTimeout(r, 2000));
  while (Date.now() - t0 < 60000) {
    if (await fetch("/api/health").then((r) => r.ok).catch(() => false)) { location.reload(); return true; }
    await new Promise((r) => setTimeout(r, 1000));
  }
  toast(tl("update.7")); return false;
}
// Click-to-update: the server only looks for a newer build (on start, then every few hours) and never
// installs on its own. When one is there, a quiet "업데이트" pill sits at the right end of the title
// bar, just left of the window controls (a button, so dragSpot leaves it out of the window drag).
// One press on it is the update: it downloads, installs and restarts, with the one line of progress
// (and 취소 while it downloads) in the popover under it. Only when a restart would cut work off
// (updHold) does it stop at "ready" and wait for 지금 다시 켜기.
function updOn() { return !!(UPD.u && UPD.u.can_apply) || UPD.phase !== ""; }
function updLabel() { return UPD.phase === "dl" ? `${UPD.pct}%` : UPD.phase === "ready" ? tl("upd.readypill") : updLine() || tl("update.2"); }
const updLocked = () => UPD.phase === "dl" || UPD.phase === "install" || UPD.phase === "restart";
function updPill() {
  if (updPhone() || !updOn()) return "";
  const cls = (Date.now() < UPD.enterUntil ? " enter" : "") + (updLocked() ? " busy" : "");
  return `<button class="updpill press${cls}" data-updpill aria-haspopup="dialog" style="--p:${UPD.pct}%" title="${esc(tl("upd.title", {v: UPD.u?.latest || ""}))}">${ic("dl")}<span>${updLabel()}</span></button>`;
}
// Keep every pill on screen in step without redrawing the header (the next head() draws it the same).
function paintUpd() {
  const t = document.getElementById("top");
  if (t && updOn() && !t.querySelector("[data-updpill]")) {
    const sp = t.querySelector(":scope > .wcsp"), tmp = document.createElement("template");
    tmp.innerHTML = updPill();
    t.insertBefore(tmp.content, sp);
  }
  document.querySelectorAll("[data-updpill]").forEach((b) => {
    if (!updOn()) return b.remove();
    b.classList.toggle("busy", updLocked()); b.style.setProperty("--p", (UPD.phase === "ready" ? 0 : UPD.pct) + "%");
    const sp = b.querySelector("span"); if (sp.textContent !== updLabel()) sp.textContent = updLabel();
  });
  const now = document.querySelector("#updpop .upx"), h = now && updNow("up");
  if (now && now.dataset.h !== h) { now.dataset.h = h; setHTML(now, h); }
  drawUpdBox();
}
function takeUpd(u) {
  const was = updOn(); UPD.u = u;
  if (!was && updOn()) UPD.enterUntil = Date.now() + 700;
  const d = u.download || {};
  // What the server already holds (the page was reloaded mid-way): a running download keeps showing
  // its progress but no longer installs by itself; a finished one waits to be applied; a failed
  // one shows its reason with a retry.
  if (!UPD.phase && u.can_apply) {
    if (d.state === "downloading") { UPD.phase = "dl"; UPD.auto = false; updPoll(); }
    else if (d.state === "ready" && d.version === u.latest) { UPD.phase = "ready"; UPD.pct = 100; }
    else if (d.state === "error" && d.version === u.latest && !UPD.err) UPD.err = d.error || tl("get.1");
  }
  paintUpd();
}
const checkUpd = () => getUpd().then((u) => u && takeUpd(u));
if (!FLOAT) setInterval(checkUpd, 30 * 60e3);
// Title-bar connection pill: what the connect screen found, in one word. "ok" a line reaches a
// session at once, "slow" it is carried in by stop + resume, "off" no agent is connected. Only a
// real detect() result is shown (nothing before the first answer); a click opens 설정 > 연결.
let CONN = "";
const connHidden = () => { try { return localStorage.getItem("loop.connpill") === "0"; } catch (e) { return false; } };
function connKind(s) {
  // Codex needs no hook to talk here: it is up once signed in and a real test turn got a reply.
  const upC = (d) => !!d && d.installed && d.logged_in !== false && (d.pieces?.hook || {}).present === true && d.launcher !== "opaque";
  const c = s && s.claude, x = s && s.codex;
  const up = (d) => d === x ? !!d && d.installed && d.logged_in === true && !!d.talked : upC(d);
  if (!up(c) && !up(x)) return "off";
  // One agent is up while the other is installed here but stopped part-way: name the one that
  // works instead of a bare "연결됨" (an agent that is not installed at all is not counted).
  if (up(c) && x && x.installed && !up(x)) return "onlyc";
  if (up(x) && c && c.installed && !up(c)) return "onlyx";
  return up(c) && c.inbox === false ? "slow" : "ok";
}
const connLabel = () => CONN === "ok" ? tl("connpill.ok") : CONN === "slow" ? tl("connpill.slow")
  : CONN === "onlyc" ? tl("connpill.onlyc") : CONN === "onlyx" ? tl("connpill.onlyx") : tl("connpill.off");
// The pill itself is two small lamps, one per agent, with no words on it: lit = connected,
// hollow = not connected, amber = something to look at. The words are in the tooltip and the
// accessible name. The lamp's look is one class on <html> (lamp-a / lamp-b / lamp-c in v2.css).
document.documentElement.classList.add("lamp-b");
let CONNS = null;
function connLamp(k, s) {
  const d = s && s[k], st = d && d.installed && window.LOOP_CONNECT ? window.LOOP_CONNECT.step(k, s) : "";
  if (st === "done" && !(k === "claude" && d.launcher === "opaque")) return k === "claude" && d.inbox === false ? "slow" : "on";
  // Amber only when there is something to do: parts are in but the check was never passed.
  const any = d && Object.values(d.pieces || {}).some((x) => x && x.present === true);
  return st === "unsure" || (st === "check" && any) ? "need" : "off";
}
const connWord = () => ({on: tl("connpill.ok"), slow: tl("connpill.slow"), need: tl("connpill.need"), off: tl("connpill.off")});
const connLamps = () => [["claude", "Claude", "c"], ["codex", "Codex", "x"]].map(([agent, name, k]) => ({agent, name, k, state: connLamp(agent, CONNS)}))
  .map((l) => ({...l, word: connWord()[l.state]}));
// Each lamp may also carry the agent's weekly plan % (web/connuse.js): then the hover / long-press
// card says it all and the plain title is left off, so two tooltips never show at once.
// The pill as last painted. The first check runs 4 s in (and the plan numbers after it), so the
// pill used to arrive late and push what sits beside it: four buttons 40px on a phone, the bell
// 133px at 800px. Until the first answer the title bar shows the last one, at its settled width.
const CONN_LAST = "loop.connpill.last";
let connLast = "";
try { const h = localStorage.getItem(CONN_LAST) || ""; if (h.startsWith('<button class="connpill')) connLast = h; } catch (e) { /* starts without it */ }
function connPill() {
  if (connHidden()) return "";
  if (!CONN) return connLast;
  const CU = window.ConnUse, sh = CU ? CU.shown() : {}, any = sh.h5 || sh.wk, lamps = connLamps();
  const use = (l) => (CU ? CU.now(l.agent) : null);
  const say = lamps.map((l) => l.name + " " + l.word).join(" · ");
  const full = lamps.map((l) => [l.name + " " + l.word, any ? CU.say(use(l)) : ""].filter(Boolean).join(" ")).join(" · ");
  return `<button class="connpill press${any && lamps.some((l) => CU.lamp(l.k, "", use(l), sh).includes("cu-w")) ? " cunum" : ""}" data-connpill${any ? "" : ` title="${esc(say)}"`} aria-label="${esc(full + " · " + tl("connpill.title"))}">${lamps.map((l) => {
    const cls = l.state === "on" ? "on" : l.state === "off" ? "off" : "wait";
    return CU ? CU.lamp(l.k, cls, use(l), sh) : `<i class="lamp ${l.k} ${cls}"></i>`;
  }).join("")}</button>`;
}
function paintConn() {
  document.querySelectorAll("[data-connpill]").forEach((b) => b.remove());
  const t = document.getElementById("top"); if (!t || !connPill()) return;
  const at = t.querySelector(":scope > [data-updpill]") || t.querySelector(":scope > .wcsp"), tmp = document.createElement("template");
  const h = connPill();
  tmp.innerHTML = h;
  t.insertBefore(tmp.content, at);
  if (CONN && h !== connLast) { connLast = h; try { localStorage.setItem(CONN_LAST, h); } catch (e) { /* this page only */ } }
}
async function checkConn(fresh) {
  const c = window.LOOP_CONNECT; if (!c) return;
  const s = fresh ? await c.refresh() : await c.status();
  if (!s) return;
  const k = connKind(s), was = connPill();
  CONNS = s;
  if (k !== CONN) { CONN = k; if (cur === "settings") setSums?.(); }
  if (connPill() !== was) paintConn();
}
// The one way to the connect card (설정 > 연결): the pill, and any "연결하기" link elsewhere
// (data-connopen), land on the same page.
function openConn() {
  setPage = "connect"; setShowPage = true;
  if (location.hash === "#settings") SCREENS.settings(); else location.hash = "#settings";
}
window.LOOP_CONNPILL = {paint: paintConn, check: checkConn, open: openConn, lamps: connLamps};
setTimeout(checkConn, 4000);
setInterval(() => { if (!document.hidden) checkConn(true); }, 5 * 60e3);
// A lamp that is not lit is asked again every minute while a chat is open: an answer that just
// came back there is the proof (codex_check.last), and the pill must not go on saying otherwise.
setInterval(() => {
  if (document.hidden || !CONNS || !location.hash.startsWith("#project")) return;
  if (["claude", "codex"].some((k) => CONNS[k] && CONNS[k].installed && connLamp(k, CONNS) !== "on")) checkConn(true);
}, 60e3);
document.addEventListener("click", (e) => {
  if (!e.target.closest?.("[data-connpill],[data-connopen]")) return;
  if (e.target.closest("[data-connopen]") && typeof closeSheet === "function") closeSheet();
  openConn();
});   // reads the server's cached check; the server itself looks every few hours
function updPop(open) {
  const old = document.getElementById("updpop");
  document.querySelectorAll("[data-updpill]").forEach((b) => b.setAttribute("aria-expanded", String(!!open)));
  if (old) {
    old.classList.remove("on"); old.removeAttribute("id");
    const rm = () => old.remove(); old.addEventListener("transitionend", rm, {once: true}); setTimeout(rm, 400);
  }
  if (!open || !UPD.u || updPhone()) return false;
  const pill = document.querySelector("[data-updpill]"); if (!pill) return false;
  const u = UPD.u, now = updNow("up");
  const el = document.createElement("div");
  el.id = "updpop"; el.className = "updpop"; el.setAttribute("role", "dialog");
  el.setAttribute("aria-label", tl("upd.title", {v: u.latest}));
  el.innerHTML = `<div class="uph"><b>${esc(tl("upd.title", {v: u.latest}))}</b><span>${esc(tl("upd.cur", {cur: u.current}))}</span></div>`
    + (u.notes?.length || u.known_issues?.length ? `<details class="upd"><summary>${tl("upd.notes")}</summary>`
      + (u.notes?.length ? updList(u.notes.slice(0, 3), "upn") : "")
      + (u.known_issues?.length ? `<p class="upk">${esc(tl("upd.issuesn", {n: u.known_issues.length}))}</p>` : "") + `</details>` : "")
    + `<div class="upx">${now}</div>`;
  el.querySelector(".upx").dataset.h = now;
  const r = pill.getBoundingClientRect();
  el.style.top = Math.round(r.bottom + 8) + "px";
  document.body.appendChild(el);
  el.style.left = Math.max(12, Math.round(r.right - el.offsetWidth)) + "px";   // right edges meet, scrollbar or not
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("on")));
  return true;
}
const updClose = () => { updPop(false); document.querySelector("[data-updpill]")?.focus({preventScroll: true}); };
// Progress shows where the person is looking: the settings box when it is on screen, else the
// popover under the pill.
const updShow = () => !!document.getElementById("updbox") || !!document.getElementById("updpop") || updPop(true);
// The one press (업데이트 확인 that found a newer build, the pill, 업데이트): fetch, then apply.
function updStart() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  if (updLocked()) return updShow();
  if (UPD.phase !== "ready") return updGo();
  if (updHold()) { paintUpd(); return updShow(); }
  updInstall();
}
async function updGo() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  if (updLocked()) return;
  const run = ++UPD.run;
  UPD.auto = true; UPD.err = ""; UPD.phase = "dl"; UPD.pct = 0; paintUpd(); updShow();
  try { await post("/api/update", {step: "download"}); } catch (e) { if (run === UPD.run) updFail(e.message); return; }
  if (run === UPD.run) updPoll();
}
// 취소 while it downloads: the server stops fetching at its next chunk; nothing was installed.
function updCancel() {
  if (UPD.phase !== "dl") return;
  UPD.run++; UPD.phase = ""; UPD.pct = 0; updPop(false); paintUpd();
  post("/api/update", {step: "cancel"}).catch(() => {});
}
// A failure keeps its reason on screen (settings box, popover) with 다시 하기 until the next try.
function updFail(msg, phase = "") { UPD.phase = phase; UPD.pct = phase ? 100 : 0; if (msg) UPD.err = msg; paintUpd(); if (msg && !updShow()) toast(msg, 5000); }
async function updPoll() {
  const run = UPD.run;
  while (UPD.phase === "dl" && run === UPD.run) {
    await new Promise((r) => setTimeout(r, 400));
    const d = (await fetch("/api/update").then((r) => r.json()).catch(() => null))?.download;
    if (run !== UPD.run || UPD.phase !== "dl") return;
    if (!d) continue;
    if (d.state === "error" || d.state === "idle") return updFail(d.error || tl("get.1"));
    UPD.pct = d.total ? Math.min(100, Math.floor(d.done * 100 / d.total)) : 0;
    if (d.state === "ready") {
      UPD.pct = 100;
      if (UPD.auto && !updHold()) return updInstall();
      UPD.phase = "ready"; paintUpd();
      if (!updShow()) toast(updHold() || tl("upd.readynote"), 5000);
      return;
    }
    paintUpd();
  }
}
async function updInstall() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  UPD.phase = "install"; UPD.err = ""; paintUpd();
  try { await post("/api/update", {step: "install"}); } catch (e) { return updFail(e.message, "ready"); }
  UPD.phase = "restart"; paintUpd();
  if (!await awaitRestart()) updFail(tl("update.7"));
}
document.addEventListener("click", (e) => {
  if (e.target.closest?.("[data-updpill]")) {
    // The pill only shows or hides the popover; 업데이트 / 지금 적용 inside it is the person's yes.
    if (document.getElementById("updpop")) return updPop(false);
    return updPop(true);
  }
  if (e.target.closest?.("[data-updgo]")) return updGo();
  if (e.target.closest?.("[data-updcancel]")) return updCancel();
  if (e.target.closest?.("[data-updapply]")) { if (UPD.phase === "ready") { updPop(false); updInstall(); } return; }
  if (document.getElementById("updpop") && !e.target.closest?.("#updpop")) updPop(false);
});
addEventListener("keydown", (e) => { if (e.key === "Escape" && document.getElementById("updpop")) updClose(); });
addEventListener("resize", () => { if (document.getElementById("updpop")) updPop(false); });
// The top bar and chrome are drawn for one side of the 1024 breakpoint, so a window dragged across it is drawn again.
{ const lay = () => wide() ? compact() ? "compact" : "wide" : "phone"; let was = lay();
  addEventListener("resize", () => { if (was === lay()) return; was = lay(); railPeek = false; railMark(); drawChrome(); if (head.last) head(...head.last); redraw(); }); }
const sound = (v) => { try {
  // Key renamed off the old product name "reviewhub"; read it once so a saved preference carries over.
  const p = JSON.parse(localStorage.getItem("genok") ?? localStorage.getItem("reviewhub") ?? "{}");
  if (v === undefined) return p.sound !== false; p.sound = v; localStorage.setItem("genok", JSON.stringify(p)); } catch { return true; } };
// Phone notifications (Web Push via /sw.js). An iPhone only allows them from the home-screen app.
const pushable = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
let swReg = null;
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").then((r) => { swReg = r; return pushSync().catch(() => {}); }).then(() => { if (cur === "settings") drawPush(); }).catch(() => {});
  navigator.serviceWorker.addEventListener("message", (e) => { if (e.data?.open) location.href = e.data.open; });
}
const urlKey = (b64) => Uint8Array.from(atob(b64.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - b64.length % 4) % 4)), (c) => c.charCodeAt(0));
// Keeps this device's subscription deliverable, on every load and before a test. A phone drops
// its subscription without a word (the app was re-added, the permission flipped off and on), the
// PC forgets one its push service called gone, and one made for another server key is refused
// for good. While the permission stands a new one is made without asking again.
// pushLast: how the last notice to this device went ({at, code}), null when none was sent.
let pushLast = null;
async function pushSync() {
  if (!swReg || !pushable || Notification.permission !== "granted" || (window.planCan && !planCan("push_notify"))) return null;
  const {key} = await get("/api/push/key");
  let sub = await swReg.pushManager.getSubscription();
  const made = sub?.options?.applicationServerKey;
  if (made && btoa(String.fromCharCode(...new Uint8Array(made))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") !== key) { await sub.unsubscribe(); sub = null; }
  if (!sub) sub = await swReg.pushManager.subscribe({userVisibleOnly: true, applicationServerKey: urlKey(key)});
  pushLast = (await post("/api/push/subscribe", {subscription: sub.toJSON()})).last || null;
  return sub;
}
async function drawPush() {
  const s = document.getElementById("pushs"), b = document.getElementById("pushb"); if (!s) return;
  // Push notifications are a Pro feature (pricing.md): show a calm hint and open the Pro
  // sheet instead of subscribing. The server also 403s /api/push/* on free.
  if (window.planCan && !planCan("push_notify")) {
    s.textContent = tl("license.pro_push_notify");
    b.textContent = tl("license.pro_enter"); b.disabled = false;
    b.onclick = () => window.proSheet("push_notify");
    return;
  }
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent), home = matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
  // Safari shows no buttons on a notification: say so where approving from one would be expected.
  if (ios && !document.getElementById("pushios")) s.insertAdjacentHTML("afterend", `<span class="srd" id="pushios">${tl("pwa.ios_push")}</span>`);
  if (ios && !home) { s.textContent = tl("drawPush.1"); return; }
  if (!pushable) { s.textContent = tl("drawPush.2"); return; }
  const sub = swReg ? await swReg.pushManager.getSubscription().catch(() => null) : null, on = !!sub && Notification.permission === "granted";
  // One quiet line, and it says what is true: blocked, the last notice did not go out, on, or off.
  const sent2xx = (l) => !l || (l.code >= 200 && l.code < 300);
  s.textContent = Notification.permission === "denied" ? tl("drawPush.6") : on && !sent2xx(pushLast) ? tl("drawPush.failed") : on ? tl("drawPush.3") : tl("drawPush.4");
  b.textContent = on ? tl("drawPush.5") : tl("settings.8"); b.disabled = !swReg;
  b.onclick = async () => { b.disabled = true;
    try {
      if (!on && await Notification.requestPermission() !== "granted") throw new Error(tl("drawPush.6"));
      const mine = await pushSync();
      // The test goes to this device only.
      const {sent, pc, last} = await post("/api/push/test", {endpoint: mine.endpoint}); pushLast = last;
      // Gone at the push service (the PC already forgot it) or refused there: make a new one now.
      if (!sent && (!last || last.code === 403)) { await mine.unsubscribe(); await pushSync(); toast(tl("drawPush.renewed")); }
      else toast(sent ? tl("drawPush.7") : pc ? tl("drawPush.pc") : tl("drawPush.8"));
    } catch (err) { toast(err.message); }
    drawPush(); };
}
// ---------- J/K: 내 차례 and 확인 필요 by keyboard ----------
// J/K walk a ring down the list, Enter opens, A 승인, R 코멘트, H 나중에, Y 맞아 on a claimed
// fix. What was acted on folds away and the ring stays where it was, on the next one. The
// ring is kept by key, so the 30-second redraw does not lose it.
let tkOn = "", tkAt = 0, tkId = "";
const tkPage = () => !detail && ((cur === "inbox" && inTab === "do") || cur === "lib" || cur === "home") ? cur : "";
// Rows inside a folded group are not walked.
const tkEls = () => [...V().querySelectorAll("[data-tk]")].filter((el) => el.offsetParent);
const tkKey = (el) => { const d = el.querySelector("[data-dv]"); if (d) return "d:" + d.dataset.dv;
  const o = el.matches("[data-item],[data-talk],[data-go]") ? el : el.querySelector("[data-item],[data-talk],[data-go]"); return o ? o.dataset.item || o.dataset.talk || o.dataset.go : ""; };
function triMark(scroll = false) {
  const L = tkEls(); L.forEach((el) => el.classList.remove("tkf"));
  if (!tkOn || tkOn !== tkPage() || !L.length) return;
  let i = L.findIndex((el) => tkKey(el) === tkId); if (i < 0) i = Math.min(tkAt, L.length - 1);
  tkAt = i; tkId = tkKey(L[i]); L[i].classList.add("tkf");
  if (scroll) L[i].scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"});
}
// The row closes up before the list redraws without it, so the eye sees where it went.
function tkFold(el, then) {
  tkId = ""; el.style.overflow = "hidden";
  const a = RM() ? el.animate([{opacity: 1}, {opacity: 0}], {duration: 140, fill: "forwards"})
    : el.classList.contains("gw") ? el.animate([{transform: "none", opacity: 1}, {transform: "scale(.92)", opacity: 0}], {duration: 200, easing: "cubic-bezier(.2,.9,.25,1)", fill: "forwards"})
    : el.animate([{height: el.offsetHeight + "px", minHeight: 0, opacity: 1}, {height: "0px", minHeight: 0, paddingTop: 0, paddingBottom: 0, opacity: 0}], {duration: 220, easing: "cubic-bezier(.2,.9,.25,1)", fill: "forwards"});
  a.onfinish = then;
}
// Registered before the page keys, so G then A still goes to 알림 and never approves.
addEventListener("keydown", (e) => {
  const pg = tkPage();
  if (!pg || e.ctrlKey || e.metaKey || e.altKey || (e.repeat && !/^[jk]$/i.test(e.key))) return;
  if (e.target.closest?.("input,textarea,gk-select,[contenteditable]") || document.querySelector(".vw,.stk,#ov.on,#sheet.on") || Date.now() - gAt < 1200) return;
  const k = e.key.toLowerCase();
  keyBarHit(/^[1-7]$/.test(k) ? "1-7" : k);
  // 결과물: 1 to 7 are the lists of the strip, left to right.
  if (pg === "lib" && /^[1-7]$/.test(k)) { e.preventDefault(); return V().querySelectorAll(".lstat [data-lib]")[+k - 1]?.click(); }
  if (k === "j" || k === "k") { e.preventDefault(); const L = tkEls(); if (!L.length) return;
    const i = L.findIndex((el) => el.classList.contains("tkf"));
    tkAt = tkOn !== pg || i < 0 ? (k === "j" ? 0 : L.length - 1) : Math.max(0, Math.min(L.length - 1, i + (k === "j" ? 1 : -1)));
    tkOn = pg; tkId = ""; return triMark(true); }
  // A also reaches the card under the mouse (the 승인 tooltip says so).
  const el = (tkOn === pg && V().querySelector("[data-tk].tkf")) || (k === "a" && V().querySelector(".gw:hover")); if (!el) return;
  if (k === "escape") { tkOn = ""; return triMark(); }
  const key = el.dataset.item || el.querySelector(".gi[data-item]")?.dataset.item, x = key && D.items.find((y) => iid(y) === key), dv = el.querySelector("[data-dv]");
  if (k === "enter") {
    // Enter on a focused button is that button's press.
    if (document.activeElement?.closest?.("button,a,summary,[role=button]") && !el.contains(document.activeElement)) return;
    e.preventDefault(); if (dv) return nav("item/" + dv.dataset.dk);
    return (el.matches("[data-item],[data-talk],[data-go]") ? el : el.querySelector("[data-item],[data-talk],[data-go]"))?.click(); }
  if (k === "a" && x && x.status !== "approved") { e.preventDefault(); const gb = el.querySelector('[data-ga="ok"]');
    // A card says itself what can be done to it: one without 승인 (settled, finished) is left alone.
    return gb ? gb.click() : el.classList.contains("gw") ? undefined : tkFold(el, () => approveMany([x])); }
  if (k === "r" && x) { e.preventDefault(); return rejectSheet(itemIt(x)); }
  if (k === "h" && x && stMine(x)) { e.preventDefault(); return snoozeSheet(key); }
  if (k === "y" && dv) { e.preventDefault(); return tkFold(el, () => verdict(dv.dataset.dk, [dv.dataset.dv], true)); }
});

// ---------- 하나씩: 내 차례 as a stack of cards ----------
// Questions first, then fixes a department says it made, then results to look at. The card
// follows the finger 1:1 and keeps the flick's speed: right says yes (승인 · 맞아 · 보내기),
// left puts it off, up opens it. Short of the line it springs back from wherever it is, and
// a finger can catch it on the way. The same three as buttons and as → ← ↑.
let stkClose = null;
const stackQueue = () => [...myTurn().map((x) => ({t: "i", x}))];
const STK_T = LT(() => ({q: [tl("nextCard.6"), tl("palActs.2"), tl("STK_T.1")], d: [tl("itemView.10"), tl("palActs.2"), tl("STK_T.2")], i: [tl("STATUS_T.4"), tl("palActs.2"), tl("search.3")]}));
const stkCard = (c) => {
  if (c.t === "i") { const x = c.x, [k, col] = KIND[x.kind] || ["doc", "grey"];
    return `<div class="stkm c-${col}">${ic(k)}${x.thumb ? imgTag(x.thumb, {drag: false}) : ""}</div>
      <div class="stkb"><span class="tag pending">${tl("search.4")}</span><h2>${esc(x.title)}</h2><p>${esc(pname(gname(x)))} · ${esc(x.v)} · ${ago(x.at)}${x.asked ? tl("stkCard.1", {asked: x.asked}) : ""}</p></div>`; }
  if (c.t === "d") { const it = c.c.it;
    return `<div class="stkb mid"><span class="tag work">${tl("claimCard.2")}</span><div class="stkq">${esc(c.c.text)}</div>
      <div class="stkr">${thumb(it, "ico sm")}<span class="tx"><div class="t">${esc(it.title)}</div><div class="s">${tl("claimCard.1", {esc: esc(pname(it.dept || "")), esc2: esc(c.c.fixed_in || "")})}</div></span></div></div>`; }
  return "";
};
function stackOpen() {
  const Q = stackQueue(); if (!Q.length) return toast(tl("stackOpen.1"));
  stkClose?.();
  const from = document.activeElement, done = {ok: 0, later: 0};
  let at = 0, busy = false, x = 0, y = 0, stopX = null, stopY = null, card = null;
  const el = document.createElement("div"); el.className = "stk from"; el.tabIndex = -1;
  el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", tl("stackOpen.2"));
  el.innerHTML = `<div class="stk-top"><b class="num" id="stkn"></b><span class="sp"></span><button class="ib press" data-stkx aria-label="${tl("itemView.114")}">${ic("x")}</button></div><div class="stk-deck" id="stkd"></div><div class="stk-bar" id="stkbar"></div>`;
  document.body.appendChild(el); document.body.classList.add("stkon");
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("from")));
  const deck = el.querySelector("#stkd"), bar = el.querySelector("#stkbar"), num = el.querySelector("#stkn");
  const W = () => deck.clientWidth || innerWidth, H = () => deck.clientHeight || innerHeight;
  const halt = () => { stopX?.(); stopY?.(); stopX = stopY = null; };
  const paint = () => { if (!card) return;
    card.style.transform = `translate3d(${x}px,${y}px,0) rotate(${x / W() * 9}deg)`;
    const op = (s, v) => { const n = card.querySelector(s); if (n) n.style.opacity = Math.max(0, Math.min(1, v)); };
    op(".stks.r", x / (W() * .3)); op(".stks.l", -x / (W() * .3)); op(".stks.u", -y / (H() * .2) - Math.abs(x) / (W() * .3)); };
  const settle = (vx = 0, vy = 0) => { halt();
    if (RM()) { x = y = 0; return paint(); }
    stopX = springTo(() => x, (v) => { x = v; paint(); }, 0, vx, null, 0.42, 0.78);
    stopY = springTo(() => y, (v) => { y = v; paint(); }, 0, vy, null, 0.42, 0.78); };
  const close = () => {
    halt(); document.removeEventListener("keydown", onKey, true); stkClose = null; document.body.classList.remove("stkon");
    el.classList.add("from"); setTimeout(() => el.remove(), RM() ? 150 : 220);
    if (from?.isConnected && from !== document.body) from.focus({preventScroll: true});
    redrawTurn(); };
  const act = (dir, c, cd) => {
    if (dir === "u") { close(); return c.t === "q" ? nav("talk/c:" + c.g.r.key) : nav("item/" + iid(c.t === "d" ? c.c.it : c.x)); }
    if (dir === "r") { done.ok++;
      if (c.t === "i") approveMany([c.x]);
      else if (c.t === "d") verdict(iid(c.c.it), [c.c.id], true);
      else { const f = cd.querySelector("form.qsend"); f.dataset.go = "1"; f.requestSubmit(); } }
    else { done.later++; if (c.t === "i") snooze(iid(c.x), SNZ().find(([t]) => t.startsWith(tl("stackOpen.3")))[1]); }
    at++; draw(); };
  const go = (dir, vx = 0, vy = 0) => {
    if (busy || !card) return; const c = Q[at], cd = card;
    if (dir === "r" && c.t === "q" && !cd.querySelector("form.qsend input").value.trim()) {
      settle(vx, vy); cd.querySelector("form.qsend input").focus(); return toast(tl("stackOpen.4")); }
    busy = true; halt();
    let fired = false; const end = () => { if (fired) return; fired = true; halt(); busy = false; act(dir, c, cd); };
    if (RM()) { cd.style.transition = "opacity .15s"; cd.style.opacity = "0"; return setTimeout(end, 150); }
    const out = () => { if (Math.abs(x) > W() * 1.1 || -y > H() * 1.05) end(); };
    const tx = dir === "r" ? W() * 1.5 : dir === "l" ? -W() * 1.5 : x, ty = dir === "u" ? -H() * 1.4 : y;
    stopX = springTo(() => x, (v) => { x = v; paint(); out(); }, tx, vx || (dir === "r" ? 1800 : dir === "l" ? -1800 : 0), end, 0.34);
    stopY = springTo(() => y, (v) => { y = v; paint(); out(); }, ty, vy || (dir === "u" ? -1800 : 0), dir === "u" ? end : null, 0.34); };
  const wire = (cd) => {
    const f = cd.querySelector("form.qsend");
    cd.onpointerdown = (e) => {
      if (e.button || busy || e.target.closest("input,textarea,button,a")) return;
      halt(); cd.setPointerCapture(e.pointerId);
      const x0 = e.clientX - x, y0 = e.clientY - y, S = [[e.timeStamp, x, y]];
      const mv = (ev) => { x = ev.clientX - x0; const dy = ev.clientY - y0; y = dy > 0 ? rubber(dy, H()) : dy; paint();
        S.push([ev.timeStamp, x, y]); if (S.length > 8) S.shift(); };
      const up = (ev) => { cd.removeEventListener("pointermove", mv); cd.removeEventListener("pointerup", up); cd.removeEventListener("pointercancel", up);
        const a = S.find((s) => ev.timeStamp - s[0] < 100) || S[0], dt = Math.max(16, ev.timeStamp - a[0]) / 1000;
        const vx = (x - a[1]) / dt, vy = (y - a[2]) / dt, px = x + project(vx), py = y + project(vy);
        if (ev.type === "pointerup" && -py > H() * .22 && -py > Math.abs(px)) return go("u", vx, vy);
        if (ev.type === "pointerup" && Math.abs(px) > W() * .35) return go(px > 0 ? "r" : "l", vx, vy);
        settle(vx, vy); };
      cd.addEventListener("pointermove", mv); cd.addEventListener("pointerup", up); cd.addEventListener("pointercancel", up); };
  };
  const draw = () => {
    halt(); x = y = 0; const c = Q[at];
    num.textContent = c ? `${at + 1} / ${Q.length}` : "";
    if (!c) { card = null;
      deck.innerHTML = `<div class="stk-end"><span class="ico c-green">${ic("check")}</span><h2>${tl("stackOpen.8")}</h2><p>${[done.ok && tl("stackOpen.5", {ok: done.ok}), done.later && tl("stackOpen.6", {later: done.later})].filter(Boolean).join(" · ") || tl("stackOpen.7")}</p></div>`;
      bar.innerHTML = `<button class="btn xl fill press" data-stkx>${tl("itemView.114")}</button>`; bar.querySelector("button").focus(); return; }
    const T = STK_T[c.t], nx = Q[at + 1];
    deck.innerHTML = (nx ? `<div class="stkc back" aria-hidden="true"><div class="stki">${stkCard(nx)}</div></div>` : "")
      + `<div class="stkc cur enter"><div class="stki">${stkCard(c)}<span class="stks r">${T[0]}</span><span class="stks l">${T[1]}</span><span class="stks u">${T[2]}</span></div></div>`;
    card = deck.querySelector(".stkc.cur");
    requestAnimationFrame(() => requestAnimationFrame(() => card?.classList.remove("enter")));
    bar.innerHTML = `<button class="btn press" data-stka="l">${T[1]}<kbd>←</kbd></button><button class="btn press" data-stka="u">${T[2]}<kbd>↑</kbd></button><button class="btn fill press" data-stka="r">${T[0]}<kbd>→</kbd></button>`;
    wire(card); el.focus({preventScroll: true}); };
  const onKey = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "k") return close();
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const typing = e.target.closest?.("input,textarea");
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); return typing ? e.target.blur() : close(); }
    if (typing || e.isComposing) return;
    const d = {ArrowRight: "r", ArrowLeft: "l", ArrowUp: "u"}[e.key]; if (d && Q[at]) { e.preventDefault(); e.stopPropagation(); go(d); } };
  document.addEventListener("keydown", onKey, true);
  el.addEventListener("click", (e) => { const b = e.target.closest("[data-stkx],[data-stka],[data-sfill]"); if (!b) return;
    if (b.dataset.stkx !== undefined) return close();
    if (b.dataset.stka) return go(b.dataset.stka);
    const i = card?.querySelector("form.qsend input"); if (i) { i.value = b.dataset.sfill; i.focus(); } });
  stkClose = close;
  draw();
}

// ---------- events ----------
let tt0;
// `moment` (optional) names a web/motion.js moment ("approve", "copied", ...): its animated icon leads the text.
let ttEnd = null;                          // what the open action toast still owes when it goes (a deferred send)
const ttDone = (run) => { const e = document.getElementById("toast"), f = ttEnd; ttEnd = null;
  e.onpointerenter = e.onpointerleave = e.onfocusin = e.onfocusout = null; e.classList.remove("hold"); if (run && f) f(); };
// The 반영함 circle's check: one stroke, so it can be drawn on (v2.css .ckm).
const CKM = '<svg class="i ckm" viewBox="0 0 256 256" aria-hidden="true"><polyline points="40 144 96 200 224 72" pathLength="20"/></svg>';
// One-sentence toasts carry no trailing period; server errors arrive with one.
const onePeriod = (t) => typeof t === "string" && /[가-힣]\.$/.test(t) && !/[.?!]\s/.test(t.slice(0, -1)) ? t.slice(0, -1) : t;
function toast(t, ms = 2200, moment) { t = onePeriod(srvT(t)); const e = document.getElementById("toast"), mi = moment && window.Motion ? Motion.tip(moment) : "";
  ttDone(true); e.classList.remove("act", "tln"); e.classList.toggle("m-ico", !!mi);
  if (mi) e.innerHTML = `<span class="ti">${mi}</span><span class="tt ${Motion.textClass(moment)}">${esc(t)}</span>`; else e.textContent = t;
  void e.offsetWidth; e.style.setProperty("--tms", ms + "ms");     // the time line starts over with each toast
  e.classList.add("on", "tln"); clearTimeout(tt0); tt0 = setTimeout(() => e.classList.remove("on"), ms); if (mi) Motion.after(moment, e); }
// Copy text to the clipboard, falling back to a hidden textarea where the async API is not
// allowed (older browsers). Over Tailscale the page is https, so the async path is the norm.
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch (e) {}
  try { const a = document.createElement("textarea"); a.value = t; a.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(a); a.select(); const ok = document.execCommand("copy"); a.remove(); return ok; } catch (e) { return false; }
}
// A toast with one button (되돌리기), up long enough to reach for it. The time left runs out along
// its edge (CSS, --tms) and stops while the mouse or the keyboard is on it. `end` (optional) runs
// when the toast goes without 되돌리기 - timed out, closed, or replaced - so a send that waits for
// the undo window waits exactly as long as the button is there.
function toastAct(t, label, fn, ms = 5000, moment = "alert", end) { t = onePeriod(srvT(t));
  const e = document.getElementById("toast"); ttDone(true); e.classList.remove("m-ico", "act", "tln");
  e.innerHTML = `<span class="ti">${(window.Motion && Motion.tip(moment)) || ic("bell")}</span><span class="tt">${esc(t)}</span><button class="tact press">${esc(label)}</button><button class="tcx press" aria-label="${tl("ui.close")}">${ic("x")}</button>`;
  void e.offsetWidth; e.style.setProperty("--tms", ms + "ms"); e.classList.add("on", "act");
  ttEnd = end || null;
  let left = ms, t0 = 0;
  const close = (run) => { clearTimeout(tt0); e.classList.remove("on"); ttDone(run); };
  const go = () => { t0 = performance.now(); e.classList.remove("hold"); clearTimeout(tt0); tt0 = setTimeout(() => close(true), left); };
  const hold = () => { if (e.classList.contains("hold")) return; left = Math.max(0, left - (performance.now() - t0)); clearTimeout(tt0); e.classList.add("hold"); };
  e.querySelector(".tact").onclick = () => { close(false); fn(); };
  e.querySelector(".tcx").onclick = () => close(true);
  e.onpointerenter = (ev) => { if (ev.pointerType === "mouse") hold(); };
  e.onpointerleave = (ev) => { if (ev.pointerType === "mouse" && !e.querySelector(":focus-visible")) go(); };
  e.onfocusin = () => { if (e.querySelector(":focus-visible")) hold(); };
  e.onfocusout = () => { if (!e.matches(":hover")) go(); };
  go();
}
document.addEventListener("click", (e) => {
  // The floating window's own controls are float.js's: its data-pin is a conversation to float and
  // its data-back closes the chat, not a project to star or a screen to leave.
  if (FLOAT && e.target.closest("#fl")) return;
  const a = e.target.closest("[data-libfil],[data-libo],[data-turnpick],[data-later],[data-unsnz],[data-lostdrop],[data-dvall],[data-dk],[data-sortsheet],[data-libk],[data-libz],[data-fav],[data-pin],[data-arch],[data-archx],[data-railmin],[data-sync],[data-view],[data-go],[data-item],[data-dept],[data-decide],[data-cmt],[data-back],[data-fwd],[data-lib],[data-close],[data-sclose],[data-pref],[data-stack],[data-catch],[data-catchok],[data-ibt]");
  if (!a) return;
  if (a.dataset.later) { e.stopPropagation(); return snooze(a.dataset.later, SNZ_OPEN, a.dataset.mark); }
  if (a.dataset.unsnz) return snooze(a.dataset.unsnz, null);
  if (a.dataset.dk) { a.disabled = true; return verdict(a.dataset.dk, [a.dataset.dv], !!a.dataset.ok); }
  // 말이 안 닿은 프로젝트: nothing took these lines, and until now nothing could clear them either.
  if (a.dataset.lostdrop) { a.disabled = true;
    return post("/api/attention/drop-lost", {dept: a.dataset.lostdrop, session: a.dataset.lostses || ""})
      .then(() => get("/api/attention?fresh=1")).then((d) => { att = d; attAt = Date.now(); toast(tl("att.lost.dropped")); render(); })
      .catch((e) => { a.disabled = false; toast(e.message); }); }
  if (a.dataset.dvall) { a.disabled = true; const k = a.dataset.dvall; return verdict(k, claimedDirs().filter((c) => iid(c.it) === k).map((c) => c.id), true); }
  if (a.dataset.sortsheet) return sortSheet(a.dataset.sortsheet);
  if (a.dataset.libfil !== undefined) return libFilSheet();
  if (a.dataset.libo) { libO(a.dataset.libo); return libDraw(); }
  if (a.dataset.libk !== undefined) { libK = a.dataset.libk; libSel = null; return libDraw(); }
  if (a.dataset.libz) { libZ(a.dataset.libz); return libDraw(); }
  if (a.dataset.fav) { e.preventDefault(); e.stopPropagation(); return toggleFav(a.dataset.fav); }
  if (a.dataset.pin) { e.stopPropagation(); return togglePin(a.dataset.pin); }
  if (a.dataset.arch) { e.preventDefault(); e.stopPropagation(); return toggleArchive(a.dataset.arch); }
  if (a.dataset.archx !== undefined) { e.stopPropagation(); return toggleShelf(); }
  if (a.dataset.railmin !== undefined) return toggleRail();
  if (a.dataset.stack !== undefined) return stackOpen();
  if (a.dataset.turnpick !== undefined) return turnSheet();
  if (a.dataset.catch !== undefined) return catchOpen();
  if (a.dataset.catchok !== undefined) return catchDone();
  if (a.dataset.ibt) { history.replaceState(null, "", "#inbox" + (a.dataset.ibt === "do" ? "" : "/" + a.dataset.ibt)); return render(); }
  if (a.dataset.sclose !== undefined) return closeSheet();
  if (a.dataset.view !== undefined) return viewer(openItem?.pics || [], +a.dataset.view);
  if (a.dataset.close !== undefined) return search(false), history.length > 1 && location.hash === "#search" ? history.back() : null;
  if (a.dataset.pref) { const v = !pref(a.dataset.pref); pref(a.dataset.pref, v); a.classList.toggle("on", v); a.setAttribute("aria-checked", v); if (a.dataset.pref === "redact") Redact.set(v); document.body.classList.toggle("calm", pref("calm")); document.body.classList.toggle("steps", pref("steps")); return; }
  if (a.dataset.back !== undefined) return back();
  if (a.dataset.fwd !== undefined) return history.forward();
  if (a.dataset.decide) return decide(a.dataset.decide);
  if (a.hasAttribute("data-cmt")) return openCmt();
  if (a.dataset.item) return nav("item/" + a.dataset.item);
  if (a.dataset.dept) return nav("dept/" + a.dataset.dept);
  if (a.dataset.lib) { libF = a.dataset.lib; libFAuto = false; libSel = null; try { localStorage.setItem("v2-libf", libF); } catch {} return cur === "lib" && !detail ? libDraw() : nav("lib"); }
  if (a.dataset.sync !== undefined) return syncNow(a);
  if (a.dataset.go) { if (a.dataset.go === "search") return search(true); nav(a.dataset.go); }
});
// Keys as in Linear and GitHub: G then a letter goes to a page, / searches, ? lists them all.
// M, A and T went to 내 차례, 알림 and 할 일; they now open 받은함's matching section.
const GO_KEYS = {h:"home", i:"inbox", m:"inbox", a:"inbox/news", t:"inbox/log", l:"lib", c:"sessions", p:"project", d:"dept", e:"depts", o:"routines", r:"retro", u:"usage", s:"settings"};
// A key whose screen this install does not have (an extension turned off) is left out of help.
const goName = (v) => GO_T[v] || M(v)?.n || extTabs().find((t) => t.id === v)?.label || "";
const GO_T = LT(() => ({inbox: tl("TABS.1"), "inbox/news": tl("bellSearch.1"), "inbox/log": tl("itemView.20"), sessions: tl("menu.chat") + " · " + tl("menu.sessions"), dept: tl("MANUAL.2", {u: unitWord()})}));
let gAt = 0;
function keyHelp() {
  const row = (k, t) => `<div class="kh"><span>${t}</span><span class="khk keys">${k.split(" ").map((x) => `<kbd>${x}</kbd>`).join("")}</span></div>`;
  sheet(`<h2 style="margin:0 0 12px">${tl("keysSheet.20")}</h2>
    ${row("Ctrl K", tl("MENUS.5"))}${row("/", tl("MENUS.5"))}${row("[", tl("keyHelp.2"))}
    ${Object.entries(GO_KEYS).filter(([k, v]) => k !== "m" && goName(v)).map(([k, v]) => row("G " + k.toUpperCase(), tl("keyHelp.1", {name: goName(v)}))).join("")}
    ${row("G M", tl("keyHelp.6"))}${row("?", tl("keyHelp.help"))}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.rooms")}</div>
    ${row("Ctrl J", tl("keyHelp.next"))}${row("Alt J", tl("keyHelp.next"))}${row("Ctrl 1-3", tl("keyHelp.pane"))}${row("Alt W", tl("keyHelp.paneX"))}${row("Alt T", tl("pj.turns.menu"))}${row("Ctrl /", tl("pj.snip.menu"))}${row("Alt ↑", tl("pj.mine.menu"))}${IN_APP ? row("Ctrl F", tl("pj.find.menu")) : ""}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.18")}</div>
    ${row("J K", tl("keyHelp.7"))}${row("Enter", tl("search.3"))}${row("A", tl("STATUS_T.4"))}${row("R", tl("cmt.1"))}${row("H", tl("palActs.2"))}${row("1-7", tl("keybar.lists"))}${row("Y", tl("keyHelp.8"))}${row("Ctrl K", tl("keyHelp.9"))}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.19")}</div>
    ${row("← →", tl("keyHelp.10"))}${row(", .", tl("keyHelp.11"))}${row("↑ ↓", tl("keysSheet.3"))}${row("0-9", tl("keyHelp.12"))}${row("M", tl("keyHelp.13"))}${row("Space", tl("keyHelp.14"))}${row("A", tl("STATUS_T.4"))}${row("R", tl("cmt.1"))}${row("N", tl("keyHelp.15"))}${row("Shift+N", tl("keybar.prev"))}${row("J K L", tl("keyHelp.16"))}${row("F", tl("keybar.focus"))}${row("T", tl("keyHelp.17"))}${row("H", tl("snoozeSheet.1"))}${row("I O X", tl("keyHelp.20"))}
    <button class="lnk press" id="khitem" style="margin-top:14px">${tl("keybar.allitem")}</button>`, (el) => { el.querySelector("#khitem").onclick = () => { closeSheet(); setTimeout(keysSheet, 280); }; });
}
addEventListener("keydown", (e) => { if (FLOAT) return;
  if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); search(true); }
  // Ctrl J (Alt J where the browser keeps Ctrl J): the next conversation with unread lines.
  if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.key === "j" || e.key === "J")) { e.preventDefault(); return nextUnread(); }
  const typ = e.target.matches?.("input,textarea,gk-select,[contenteditable]");
  const free = !e.ctrlKey && !e.metaKey && !e.altKey && !typ && !document.querySelector(".vw,.stk");
  if (free && !(detail?.[0] === "item")) {
    const k = e.key.toLowerCase();
    if (k === "g") { gAt = Date.now(); return; }
    if (Date.now() - gAt < 1200 && GO_KEYS[k]) { gAt = 0; e.preventDefault(); closeSheet(); return nav(GO_KEYS[k]); }
    if (e.key === "/") { e.preventDefault(); return search(true); }
    // Where the list has its own key bar, ? is that bar's switch (its 전체 보기 opens this sheet).
    if (e.key === "?") { e.preventDefault(); return document.getElementById("kbar") ? undefined : keyHelp(); }
  }
  if (e.key === "[" && !e.ctrlKey && !e.metaKey && !e.altKey && wide() && !e.target.matches?.("input,textarea,gk-select,[contenteditable]") && !window.LOOP_LAYER_UP?.()) toggleRail();
  if (e.key === "{" && !e.ctrlKey && !e.metaKey && !e.altKey && wide() && !e.target.matches?.("input,textarea,gk-select,[contenteditable]") && !window.LOOP_LAYER_UP?.()) railHide();
  if (e.key === "Escape") {
    // Settings closes like a panel: with nothing open over it and no field in use, Esc goes back to the screen before it.
    const leave = cur === "settings" && !detail && !typ && !e.defaultPrevented && !window.LOOP_LAYER_UP?.() && !document.querySelector(".pj-pop,#updpop");
    search(false); closeSheet();
    if (leave) { if (history.length > 1 && sessionStorage.getItem("v2-inner")) history.back(); else nav("home"); }
  } });

// Lists refresh in the background; a screen being typed in or read in detail is left alone.
// The 30s round. The three list screens are drawn from D alone, so a round that brought nothing
// new leaves them standing (it used to rebuild the whole page every time); they are still redrawn
// every two minutes so "3분 전" keeps moving. Other screens fetch their own data in their draw.
let roundSig = "", roundAt = 0;
setInterval(async () => {
  if (document.hidden || FLOAT) return;
  await load();
  const sig = JSON.stringify([D.board, D.items, D.pins, D.favs, D.hidden, D.shelved]);
  const same = sig === roundSig && ["home", "inbox", "lib"].includes(cur) && Date.now() - roundAt < 120000;
  roundSig = sig;
  const typing = document.activeElement?.matches?.("input,textarea,gk-select");
  if (!same && !typing && !document.getElementById("sheet").classList.contains("on")) { redraw(); roundAt = Date.now(); }
  drawChrome();
}, 30000);

document.body.classList.toggle("calm", pref("calm"));
// The chat shows what a session says; the lines for each tool it ran in between are a setting, off until asked for.
document.body.classList.toggle("steps", pref("steps"));
// The first look at the app in a tab: the logo, its ring turning while the first data comes in.
// It stays at least 0.8s so it never just flashes, leaves at 6s whatever happens, and a tap
// sends it off at once. A reload in the same tab goes straight to the page (v2.html).
function splashOut(now) {
  const s = document.getElementById("splash"); if (!s || s.classList.contains("out")) return;
  try { sessionStorage.setItem("v2-in", "1"); } catch {}
  const go = () => { if (s.classList.contains("out")) return; s.classList.add("out"); setTimeout(() => s.remove(), 480); };
  if (now) go(); else if (!s.dataset.out) { s.dataset.out = "1"; setTimeout(go, Math.max(0, 800 - performance.now())); }
}
document.getElementById("splash")?.addEventListener("pointerdown", () => splashOut(true));
document.getElementById("splash")?.setAttribute("aria-label", tl("load.label"));
setTimeout(() => splashOut(true), 6000);
// Open on what was last seen, at once, then bring it up to date: over the phone's link the
// first load takes a second or two, and a blank screen for that long reads as broken.
// The refresh button's "n분 전 동기화" says honestly how old the shown data is meanwhile.
const bootSeen = lsGet("v2-seen-at");
(async () => {
  if (FLOAT) { document.getElementById("splash")?.remove(); return; }
  let shown = false;
  try { const c = JSON.parse(localStorage.getItem("v2-cache") || "null"); if (c?.at) { D = {...D, ...c}; render(); shown = true; } } catch {}
  // The logo that greets a first visit leaves once there is something to show.
  if (shown) splashOut();
  // No copy yet (cleared storage, a new browser): draw the frame now, so the tabs and the
  // "불러오는 중" line stand there instead of a white page until the data comes.
  else try { render(); } catch {}
  await load();
  // First visit: the title row takes its 의견 남기기 slot before the logo lifts, so the centred pill does not jump.
  if (!shown && fbUrl()) try { render(); } catch {}
  splashOut();
  if (attP) await Promise.race([attP, new Promise((r) => setTimeout(r, 500))]);
  attBooting = false;
  const typing = document.activeElement?.matches?.("input,textarea,gk-select");
  // A reader who started scrolling while it loaded stays where they were.
  if (!typing) { const y = scrollY; render(); scrollTo(0, y); }
  // Away long enough (by this browser or the server's last look): what happened meanwhile.
  awayCheck(later(bootSeen, D.seen_at)); hereNow(true); drawUpdate(false);
  setInterval(() => { if (!document.hidden) hereNow(); }, 60000);
})();
// A mobile browser can drop its compositor layer on a short lock/unlock or app-switch even
// when it isn't away long enough for the AWAY_MS data refresh below - the page is fine
// underneath but the screen paints solid black until something forces a reflow. A page-level
// refresh does nothing (the break is below the DOM), so nudge layout directly: toggling display
// off and back is the cheap, reliable way to make a browser repaint a stuck compositor layer.
// web/repaint.js keeps the display restore in a finally and rescues a body left on none.
function nudgeRepaint() { if (window.LOOP_REPAINT) window.LOOP_REPAINT.nudgeRepaint(document); }
// Back to the tab after a while: the same check, against the look before this one.
document.addEventListener("visibilitychange", async () => {
  if (FLOAT) return;
  // Leaving is when the icon is looked at: its number is set once more from what is known now.
  if (document.hidden) { try { drawChrome(); } catch {} return hereNow(true); }
  nudgeRepaint();
  const last = lsGet("v2-seen-at"); if (!last || Date.now() - new Date(last) < AWAY_MS) return hereNow();
  await load(); drawChrome(); awayCheck(later(last, D.seen_at)); hereNow(true);
});
// iOS Safari restoring the page from its back-forward cache (swipe back, reopen from the app
// switcher) can skip visibilitychange entirely and hand back a page frozen mid-paint - the
// dedicated signal for that is pageshow with event.persisted set.
window.addEventListener("pageshow", (e) => { if (e.persisted) nudgeRepaint(); });
