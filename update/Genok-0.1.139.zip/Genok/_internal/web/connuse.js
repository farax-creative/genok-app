// Plan usage on the title-bar lamps (the connection pill in v2.js, connPill()).
//
// Each agent's lamp can carry its plan %: the 5-hour window, the weekly one, both or neither. The
// two switches are per-browser display preferences (localStorage "loop.connusage.h5" and
// "loop.connusage.wk", set in 설정 › 연결 › 더 보기, web/connect.js), like the pill's own on/off
// ("loop.connpill"). Both start on; the old single pick "loop.connusage" = "off" starts both off.
//
// The numbers are the ones the 사용량 screen shows (web/usage.js, GET /api/usage): Claude's from
// the app's own limit reading when it is turned on (claude_limit.py, u.limit), else what a status
// line saved (u.claude_rate); Codex's from its session logs (u.codex_rate). Nothing is asked here
// that the usage screen does not ask: the read goes through usage.js's quiet fetch (never the
// permission dialog), at the pill's own 5-minute pace, and every answer that screen gets is taken
// too. No reading = no number: the lamp stays plain and the card says so, with the way to turn it on.
//
// Colour: plain text below 70%, amber from 70%, red from 90%, per window. Hover (PC) or a
// tap/click opens a small usage card in place, without navigation: per agent its name, then a
// block per window that has a reading (label, reset time, the % and its bar).
// Pure parts (shown, level, read, lamp, card) are tested in tests/connuse.test.js.
(function () {
  "use strict";
  const KEY = "loop.connusage";
  const WINDOWS = ["h5", "wk"];
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));

  // A phone's title bar is short: there both start off (the same widths v2.css calls a phone).
  const PHONE = "(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none)";
  const phone = () => { try { return matchMedia(PHONE).matches; } catch (e) { return false; } };
  // Which windows the lamps show: {h5, wk}. `small`: asked for a phone.
  function shown(store, small) {
    try {
      const st = store || localStorage, def = st.getItem(KEY) === "off" || (small == null ? !store && phone() : small) ? "0" : "1";
      return Object.fromEntries(WINDOWS.map((w) => [w, (st.getItem(`${KEY}.${w}`) || def) === "1"]));
    } catch (e) { return {h5: true, wk: true}; }
  }
  function setShown(w, on, store) {
    if (!WINDOWS.includes(w)) return;
    try { (store || localStorage).setItem(`${KEY}.${w}`, on ? "1" : "0"); } catch (e) { /* this page only */ }
  }
  // Thresholds are on the number shown, so 69.6 (shown 70) is already amber.
  const level = (p) => (p >= 90 ? "crit" : p >= 70 ? "warn" : "ok");

  // What is known about one agent's plan right now, from a /api/usage answer:
  // {pct, level, five, fiveLevel, resets, fiveResets, stale, at, why}. pct is the weekly window, five the
  // 5-hour one; each is null without a reading. With neither, `why` says which: "consent" (usage not allowed yet), "off" (Claude's limit reading is
  // off), a claude_limit state while it is on and has nothing ("loading", "login", ...), or "none".
  function read(agent, u, now) {
    now = now || Date.now() / 1000;
    const none = {pct: null, level: "", five: null, fiveLevel: "", resets: null, fiveResets: null, stale: false, at: null, why: "none"};
    if (!u) return none;
    if (u.need_consent || u.declined) return {...none, why: "consent"};
    const lim = u.limit || null;
    const src = (agent === "claude" ? (lim && lim.rate) || u.claude_rate || u.rate : u.codex_rate) || null;
    const live = (w) => (w && typeof w === "object" && w.pct != null && Number.isFinite(Number(w.pct))
      && !(w.resets_at && w.resets_at <= now) ? w : null);
    // A 5-hour window that reset since its last reading: nothing was used here since, so it is 0.
    const lapsed = src && Array.isArray(src.lapsed) && src.lapsed.includes("five_hour");
    const wk = src && live(src.seven_day), five = src && (live(src.five_hour) || (lapsed ? {pct: 0} : null));
    if (!wk && !five) {
      const why = agent !== "claude" || !lim ? "none" : !lim.on ? "off" : lim.state && lim.state !== "ok" && lim.state !== "stale" ? lim.state : "none";
      return {...none, why};
    }
    const whole = (w) => (w ? Math.min(Math.max(Math.round(Number(w.pct)), 0), 100) : null);
    const pct = whole(wk), f = whole(five);
    return {pct, level: wk ? level(pct) : "", five: f, fiveLevel: five ? level(f) : "",
      resets: wk ? wk.resets_at || null : null, fiveResets: five ? five.resets_at || null : null, fiveLapsed: !!(five && lapsed && !five.resets_at), stale: !!src.stale, at: src.updated || null, why: ""};
  }

  // One lamp. `k` is the lamp's own class (c / x), `cls` its connection class (on / off / wait),
  // `sh` which windows are shown. A window without a reading is left out, never shown as 0.
  // `who` ({name, hi}) is for the desktop title bar: the agent's name goes beside its numbers, and `hi`
  // marks the one that is further along, which is the only one a narrow bar keeps.
  function lamp(k, cls, r, sh, who) {
    const dot = `<i class="lamp ${k} ${cls}"></i>`;
    const K = {h5: tl("connuse.k.h5"), wk: tl("connuse.k.wk")};
    const cell = (w, n, lv) => `<span class="cu-w ${w} ${lv}"><small>${E(K[w])}</small><em>${n}%</em></span>`;
    const cells = !r ? "" : (sh.h5 && r.five != null ? cell("h5", r.five, r.fiveLevel) : "")
      + (sh.wk && r.pct != null ? cell("wk", r.pct, r.level) : "");
    // The share used, said once after the last number: a bare % reads as either used or left.
    const name = who && who.name ? `<b class="cu-n">${E(who.name)}</b>` : "";
    return cells ? `<span class="cu ${k}${who && who.hi ? " hi" : ""}">${dot}${name}${cells.replace(/<\/span>$/, `<small>${E(tl("connuse.used"))}</small></span>`)}</span>` : dot;
  }

  // "10/7(수) 9시" / "Wed 10/7 9:00", the 사용량 screen's own way of saying a reset.
  function when(t) {
    const d = new Date(t * 1000), en = (typeof window !== "undefined" && window.I18N_LANG) === "en";
    const wd = d.toLocaleDateString(en ? "en-US" : "ko-KR", {weekday: "short"}), h = tl("home.act.hour", {h: d.getHours()});
    return en ? `${wd} ${d.getMonth() + 1}/${d.getDate()} ${h}` : `${d.getMonth() + 1}/${d.getDate()}(${wd}) ${h}`;
  }
  function asOf(t) {
    const d = new Date(t * 1000), hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
    return d.toDateString() === new Date().toDateString() ? hm : `${d.getMonth() + 1}/${d.getDate()} ${hm}`;
  }
  const WHY = {loading: "uz.lim.loading", login: "uz.lim.login", unavailable: "uz.lim.unavail", error: "uz.lim.error"};
  // One window of the card: its name and reset time (`note`: other words for that place), then
  // the % beside its bar.
  const win = (name, n, lv, t, note) => `<div class="w ${lv}"><span class="k">${E(name)}</span><span class="t">${t ? E(tl("uz.reset", {t})) : E(note || "")}</span>`
    + `<span class="v">${E(tl("connuse.v", {n}))}</span><i class="bar" aria-hidden="true"><i style="width:${n}%"></i></i></div>`;
  // What the card says under one agent's name.
  function sub(r) {
    if (r.pct == null && r.five == null) {
      const go = r.why === "consent" || r.why === "off"
        ? ` · <button type="button" class="go" data-cuse>${E(tl("connuse.on"))}</button>` : "";
      const why = WHY[r.why] ? ` · ${E(tl(WHY[r.why]))}` : "";
      return `<div class="s no">${E(tl("connuse.none"))}${go || why}</div>`;
    }
    return (r.five != null ? win(tl("connuse.t.h5"), r.five, r.fiveLevel, r.fiveResets && asOf(r.fiveResets), r.fiveLapsed ? tl("connuse.lapsed") : "") : "")
      + (r.pct != null ? win(tl("connuse.t.wk"), r.pct, r.level, r.resets && when(r.resets)) : "")
      + (r.stale ? `<div class="s">${E(r.at ? tl("uz.lim.asof", {t: asOf(r.at)}) : tl("uz.stale"))}</div>` : "");
  }
  // rows: [{agent, name, r, conn}] - conn is a word for a lamp that is not plainly on, else "".
  // `sh` (which windows the lamps show): the card ends with their two switches and "숫자 숨김"
  // (the lamps alone, as a phone starts), which is on while both are off.
  function card(rows, sh) {
    const sw = (w) => `<button type="button" role="switch" aria-checked="${!!sh[w]}" data-cushow="${w}">${E(w === "h5" ? tl("connuse.t.h5") : tl("connuse.t.wk"))}</button>`;
    return rows.map((x) => `<section><button type="button" class="r" data-cagent="${x.agent === "codex" ? "codex" : "claude"}" aria-label="${E(tl("connuse.details", {name: x.name}))}"><i class="agdot${x.agent === "codex" ? " cx" : ""}" aria-hidden="true"></i><b>${E(x.name)}</b>`
      + `${x.conn ? `<small>${E(x.conn)}</small>` : ""}<span class="more" aria-hidden="true">›</span></button>${sub(x.r)}</section>`).join("")
      + (sh ? `<div class="opt" role="group" aria-label="${E(tl("connuse.showIn"))}"><span>${E(tl("connuse.showIn"))}</span>${sw("h5")}${sw("wk")}<button type="button" role="switch" aria-checked="${!sh.h5 && !sh.wk}" data-cushow="none">${E(tl("connuse.t.none"))}</button></div>` : "");
  }
  // For the pill's accessible name: "5시간 18% 주간 42%", whatever of it is known.
  const say = (r) => (!r ? "" : [r.five != null ? tl("connuse.h5", {n: r.five}) : "", r.pct != null ? tl("connuse.aria", {n: r.pct}) : ""].filter(Boolean).join(" "));

  // The reading furthest along (either window), to tell which agent a narrow title bar keeps.
  const worst = (r) => (r ? Math.max(r.five == null ? -1 : r.five, r.pct == null ? -1 : r.pct) : -1);

  const api = {KEY, WINDOWS, shown, setShown, level, read, lamp, card, say, worst};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;

  // ---- live: the last answer, the pace, the card -------------------------------------------
  let U = null, tries = 0;
  // The last answer's plan rows, kept so the pill starts with the numbers it ended with (v2.js
  // paints the remembered pill first; a pill without numbers at 4 s would shrink it and grow it back).
  const LAST = KEY + ".last";
  let U0 = null;
  try { U0 = JSON.parse(localStorage.getItem(LAST) || "null"); } catch (e) { /* starts without it */ }
  const known = () => U || U0;
  const keep = (u) => { try { localStorage.setItem(LAST, JSON.stringify({need_consent: u.need_consent, declined: u.declined, limit: u.limit && {on: u.limit.on, state: u.limit.state, rate: u.limit.rate}, claude_rate: u.claude_rate, rate: u.rate, codex_rate: u.codex_rate})); } catch (e) { /* this page only */ } };
  const on = () => { const sh = shown(); return sh.h5 || sh.wk; };
  const pill = () => window.LOOP_CONNPILL;
  const repaint = () => { try { pill().paint(); } catch (e) { /* no title bar */ } if (tip) fill(); };
  function take(u) {
    if (!u || u.warming) return;
    const was = JSON.stringify([read("claude", known()), read("codex", known())]);
    U = u; keep(u);
    if (JSON.stringify([read("claude", U), read("codex", U)]) !== was) repaint();
  }
  // Every whole-screen answer usage.js gets (its tabs per agent carry the same plan rows).
  window.addEventListener("loop:usage", (e) => take(e.detail));
  async function pull(asked) {
    if ((!on() && !asked) || document.hidden || !window.LOOP_USAGE) return;
    if (U && (U.need_consent || U.declined)) return;    // asked again once 사용량 is allowed
    try {
      const u = await window.LOOP_USAGE.read();
      if (u && u.warming) { if (tries++ < 3) setTimeout(pull, 3000); return; }
      tries = 0; take(u);
    } catch (e) { /* keeps the last reading */ }
  }
  setTimeout(pull, 4500);
  setInterval(pull, 5 * 60e3);                          // the pill's own pace (v2.js checkConn)

  api.now = (agent) => read(agent, known());
  // "숫자 숨김": both windows off; turned off again, the weekly number comes back.
  const showNone = (v) => { if (v) WINDOWS.forEach((w) => setShown(w, false)); else setShown("wk", true); };
  api.show = (w, v) => { if (w === "none") showNone(v); else setShown(w, v); hide(); repaint(); if (on() && !U) pull(); };

  // The card: under the pill, right edges lined up; fades in place.
  let tip = null, openT = 0, closeT = 0, pinned = false, at = null, restoring = false;
  function fill() {
    const L = (pill() && pill().lamps && pill().lamps()) || [];
    tip.innerHTML = card(L.map((l) => ({agent: l.agent, name: l.name, conn: l.state === "on" ? "" : l.word, r: read(l.agent, known())})), shown());
  }
  function place(p) {
    const r = p.getBoundingClientRect(), w = tip.offsetWidth;
    tip.style.top = Math.round(r.bottom + 6) + "px";
    tip.style.left = Math.round(Math.max(12, Math.min(r.right - w, innerWidth - 12 - w))) + "px";
  }
  function show(p, force) {
    clearTimeout(closeT);
    if (p && !p.isConnected) p = document.querySelector(PILL);         // repainted meanwhile
    if (!p || (!on() && !force)) return;
    if (!tip) {
      tip = document.createElement("div");
      tip.className = "cutip"; tip.setAttribute("role", "dialog"); tip.setAttribute("aria-label", tl("connuse.title")); tip.id = "cutip";
      document.body.appendChild(tip);
      requestAnimationFrame(() => requestAnimationFrame(() => tip && tip.classList.add("on")));
    }
    at = p; fill(); place(p);
    if (!U && force) pull(true);                        // lamps without numbers: the card still has them
    p.setAttribute("aria-controls", "cutip"); p.setAttribute("aria-haspopup", "dialog"); p.setAttribute("aria-expanded", "true");
  }
  function hide() {
    clearTimeout(openT); clearTimeout(closeT); pinned = false;
    if (!tip) return;
    const old = tip; tip = null; old.removeAttribute("id"); old.classList.remove("on");
    if (at) { at.removeAttribute("aria-controls"); at.setAttribute("aria-expanded", "false"); }
    const rm = () => old.remove(); old.addEventListener("transitionend", rm, {once: true}); setTimeout(rm, 300);
  }
  const PILL = "[data-connpill]", BOTH = "[data-connpill],.cutip";
  document.addEventListener("pointerover", (e) => {
    if (e.pointerType !== "mouse" || !on()) return;
    const p = e.target.closest && e.target.closest(PILL);
    if (p) { clearTimeout(closeT); if (!tip) { clearTimeout(openT); openT = setTimeout(() => show(p), 250); } }
    else if (e.target.closest && e.target.closest(".cutip")) clearTimeout(closeT);
  });
  document.addEventListener("pointerout", (e) => {
    if (e.pointerType !== "mouse") return;
    const from = e.target.closest && e.target.closest(BOTH), to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(BOTH);
    if (from && !to && !pinned) { clearTimeout(openT); closeT = setTimeout(hide, 200); }
  });
  // Keyboard: the card follows focus on the pill.
  document.addEventListener("focusin", (e) => {
    if (restoring) return;
    const p = e.target.closest && e.target.closest(PILL);
    if (p) { if (on() && p.matches(":focus-visible")) show(p); }
    else if (tip && !(e.target.closest && e.target.closest(".cutip"))) hide();
  });
  // A regular tap/click stays here. The connection settings have their own explicit entry.
  document.addEventListener("pointerdown", (e) => {
    if (tip && !(e.target.closest && e.target.closest(BOTH))) hide();
  });
  document.addEventListener("click", (e) => {
    const p = e.target.closest && e.target.closest(PILL);
    if (!p) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (tip && pinned) hide(); else { show(p, true); pinned = true; }
  }, true);
  document.addEventListener("contextmenu", (e) => { if (e.target.closest && e.target.closest(PILL) && on()) e.preventDefault(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && tip) {
      const origin = at;
      hide(); restoring = true;
      if (origin && origin.isConnected) origin.focus({preventScroll: true});
      restoring = false;
    }
  });
  addEventListener("hashchange", hide);
  try { matchMedia(PHONE).addEventListener("change", repaint); } catch (e) { /* an old browser: the next paint has it */ }
  addEventListener("resize", () => { if (tip && at && at.isConnected) place(at); else hide(); });
  // The card's one action: the 사용량 screen, at its switch (or its permission question).
  document.addEventListener("click", (e) => {
    const row = e.target.closest && e.target.closest("[data-cagent]");
    if (row) {
      window.LOOP_USAGE_AGENT = row.dataset.cagent;
      hide();
      if (location.hash === "#usage") dispatchEvent(new HashChangeEvent("hashchange")); else location.hash = "usage";
      return;
    }
    // Its switches: what the lamps show changes under the card, which stays.
    const s = e.target.closest && e.target.closest("[data-cushow]");
    if (s) {
      if (s.dataset.cushow === "none") showNone(s.getAttribute("aria-checked") !== "true");
      else setShown(s.dataset.cushow, s.getAttribute("aria-checked") !== "true");
      repaint();
      const p = document.querySelector(PILL);
      if (tip && p) { at = p; place(p); p.setAttribute("aria-expanded", "true"); }
      if (tip && !e.detail) { const again = tip.querySelector(`[data-cushow="${s.dataset.cushow}"]`); if (again) again.focus({preventScroll: true}); }
      if (on() && !U) pull();
      return;
    }
    const b = e.target.closest && e.target.closest("[data-cuse]");
    if (!b) return;
    hide();
    window.LOOP_USAGE_FOCUS = "limit";
    if (location.hash === "#usage") dispatchEvent(new HashChangeEvent("hashchange")); else location.hash = "usage";
  });
  window.ConnUse = api;
})();
