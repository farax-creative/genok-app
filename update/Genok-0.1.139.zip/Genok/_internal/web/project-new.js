// Genok web UI, cut from project.js: 새 대화 and several rooms at once (#project/~multi).
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- 새 대화: department (search, recent first), Claude | Codex, keep | new, first line, model --
  // 새 대화: a card grid of every department, filed under the register's groups. One pick works as
  // before (open it and go there). Several get the same first line each, two at a time, and the
  // sheet stays to say how each one went; one that fails does not stop the others.
  async function newChat(preset) {
    ensureCss();                                        // opened from home (the first-use guide) before the chat page ever drew
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const rooms = (roomsCache || []).slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
    const by = {};
    rooms.forEach((r) => { by[r.name] = r; });
    // The first-use guide passes {text, mk, agent}: the first line and a new project's name, already filled in.
    const pre = preset && typeof preset === "object" ? preset : null;
    if (pre) preset = "";
    const sel = new Set(preset && by[preset] ? [preset] : []);
    let agent = (pre && pre.agent === "codex") || (preset && by[preset] && by[preset].agent === "codex") ? "codex" : "claude", mode = "auto", model = "", q = "", running = false;   // model: "" until a segment is pressed (nothing is passed)
    const nowOf = {};                                   // project -> what a new session there starts on (/api/session/model `now`)
    const named = groupsSeen.filter((g) => rooms.some((r) => r.group === g));
    const sections = [...named.map((g) => [g, rooms.filter((r) => r.group === g)]),
      [named.length ? tl("room.pk.other") : "", rooms.filter((r) => !named.includes(r.group))]].filter((s) => s[1].length);
    const canKeep = (r) => !!(r.sid && (r.agent || "claude") === agent);
    const isUp = (r) => canKeep(r) && !!r.state && r.state !== "ended";
    // Where one department's line goes. Left alone, the conversation it has gets the line (one
    // conversation per department); only the switch opens another.
    const modeOf = (r, n) => mode === "new" ? "new" : mode === "keep" ? ((n > 1 ? isUp(r) : canKeep(r)) ? "keep" : "new") : canKeep(r) ? "keep" : "new";
    const SEGLAB = {mode: tl("room.mode"), model: tl("room.model"), agent: "Claude / Codex"};
    const seg = (k, opts, cur) => `<div class="seg pj-seg2" data-seg="${k}" role="group" aria-label="${esc(SEGLAB[k])}">${opts.map(([v, l]) =>
      `<button class="${v === cur ? "on" : ""} press" data-v2="${v}" aria-pressed="${v === cur}">${k === "agent" ? window.agDot(v) : ""}${esc(l)}</button>`).join("")}</div>`;
    sheet(`<div class="pj-dlg pj-new"><h3>${tl("room.newTitle")}</h3>
      <div class="pj-ntop">${seg("agent", [["claude", "Claude"], ["codex", "Codex"]], agent)}
        <input class="pj-search" type="search" data-q placeholder="${esc(tl("room.searchOnly"))}" aria-label="${esc(tl("room.searchOnly"))}">
        <button type="button" class="btn sm press pj-mkbtn" data-mk aria-expanded="false">${ic("plus")}<span>${tl("room.mkOpen")}</span></button></div>
      <div class="pj-mkbox" data-mkbox hidden><div class="lbl">${tl("room.mkName")}</div>
        <input class="tin" data-mkn type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.mkNamePh"))}" aria-label="${esc(tl("room.mkName"))}">
        ${onThisPc() ? `<div class="lbl">${tl("room.loc.label")}</div><div class="fx-loc ed"><input class="tin" data-mkp type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("room.loc.label"))}"><button type="button" class="btn sm press" data-loc aria-haspopup="dialog" aria-expanded="false">${ic("folder")}<span>${tl("room.loc.pick")}</span></button></div>` : ""}</div>
      <div class="pj-pg" data-pg role="listbox" aria-multiselectable="true" aria-label="${esc(tl("room.dept"))}"></div>
      <div class="pj-nfoot"><div data-modebox></div>
        <div class="pj-to" data-to aria-live="polite"></div>
        <textarea class="pj-ta2" data-text rows="2" placeholder="${esc(tl("room.firstPh"))}" aria-label="${esc(tl("room.first"))}"></textarea>
        <div class="pj-hint" data-hint></div>
        <div class="pj-nrow"><div data-modelbox></div>
          <button type="button" class="pj-text press" data-more>${tl("room.firstMore")}</button>
          <span class="sp"></span><button class="pj-btn light press" data-go>${tl("room.start")}</button></div></div></div>`, (box) => {
      box.classList.add("pj-wide");
      const pg = box.querySelector("[data-pg]"), mb = box.querySelector("[data-modebox]"), hint = box.querySelector("[data-hint]");
      const go = box.querySelector("[data-go]"), ta = box.querySelector("[data-text]"), qi = box.querySelector("[data-q]"), to = box.querySelector("[data-to]");
      let cur = [];
      // The first chat ever (the guide's line, no project yet): only the line, the agent and [시작].
      let first = !!(pre && pre.mk && !rooms.length);
      const root0 = box.querySelector(".pj-new"), moreB = box.querySelector("[data-more]");
      root0.classList.toggle("pj-first", first);
      moreB.onclick = () => { first = false; root0.classList.remove("pj-first"); sync(); };
      // 새로 만들기: a name typed in its own box (never the search box) that is no project yet shows
      // as one more card, picked; starting it makes the folder in the place shown, registers the
      // project and opens the chat. The place is a field: typed, pasted or picked.
      let mkRoot = "", mkPar = "", mkName = "";
      const mkb = box.querySelector("[data-mk]"), mkbox = box.querySelector("[data-mkbox]"), mkn = box.querySelector("[data-mkn]"), mkp = box.querySelector("[data-mkp]"), mkloc = mkbox.querySelector("[data-loc]");
      const body = (j, text) => Object.assign({name: j.r.name, agent, text, model, mode: j.mode, sid: j.mode === "keep" ? j.r.sid || "" : ""},
        j.r.fresh ? Object.assign({create: true}, mkp ? {parent: mkPar.toLowerCase() === mkRoot.toLowerCase() ? "" : mkPar} : {}) : {});
      get("/api/depts").then((d) => { mkRoot = d.default_root || ""; mkPar = d.parent || mkRoot; if (mkp && !mkp.value) mkp.value = mkPar; if (box.isConnected) sync(); }).catch(() => {});
      const fresh = () => {
        const nm = mkName.trim();
        return nm && !rooms.some((r) => r.name.toLowerCase() === nm.toLowerCase()) ? nm : "";
      };
      const wireSeg = () => box.querySelectorAll("[data-seg]").forEach((sg) => sg.querySelectorAll("[data-v2]").forEach((b) => b.onclick = () => {
        const k = sg.dataset.seg, v = b.dataset.v2;
        // A model segment pressed is a pick; pressed again it is let go, and the start passes nothing.
        if (k === "model") { model = model === v ? "" : v; return paintModel(); }
        if (k === "agent") { agent = v; mode = "auto"; } else mode = v;
        sg.querySelectorAll("[data-v2]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        sync();
      }));
      // The model row has no "default": the model a new session really starts on is the segment
      // that is marked (the chip's own resolver, per project), with a line saying how that is
      // known. It is only shown: until a segment is pressed no model is passed. Projects that
      // start on different models, or none that can be named, leave every segment unmarked.
      let newNames = [];
      const paintModel = () => {
        const mbx = box.querySelector("[data-modelbox]");
        newNames.forEach((nm) => { if (nowOf[nm] !== undefined) return; nowOf[nm] = null;
          get("/api/session/model?name=" + enc(nm)).then((r) => { nowOf[nm] = r.now || {}; if (box.isConnected) paintModel(); }).catch(() => { nowOf[nm] = {}; if (box.isConnected) paintModel(); }); });
        const got = newNames.map((nm) => nowOf[nm]), ready = got.length && got.every(Boolean);
        const keys = ready ? [...new Set(got.map((x) => x.family || x.name || ""))] : [];
        const now = keys.length === 1 && keys[0] ? got[0] : null, LIST = ["haiku", "sonnet", "opus"];
        const own = now && !LIST.includes(now.family);     // a model outside the row: a segment under its own name
        const cur = model || (now ? (own ? "" : now.family) : null);
        const cap = model ? (model === "auto" ? tl("room.modelAuto") : "") : !ready ? "" : now ? (MTAG[now.source] ? tl("room.modelShown", {how: MTAG[now.source]()}) : "")
          : keys.length > 1 ? tl("room.modelMixed") : tl("room.modelNone");
        mbx.innerHTML = seg("model", [...(own ? [["", now.name]] : []), ["haiku", "Haiku"], ["sonnet", "Sonnet"], ["opus", "Opus"], ["auto", tl("room.auto")]], cur)
          + `<div class="pj-mcap" aria-live="polite">${esc(cap)}</div>`;
        wireSeg();
      };
      const cardH = (r) => {
        const on = sel.has(r.name);
        return `<button class="pj-pc press ${on ? "on" : ""} ${isUp(r) ? "up" : ""}" role="option" aria-selected="${on}" tabindex="-1" data-dn="${esc(r.name)}"${isUp(r) ? ` title="${esc(tl("room.pk.up"))}"` : ""}>
          ${em(r.emoji, "", r.icon)}<span class="t">${esc(pname(r.name))}</span>${r.sid ? dot(pjKindOf(r.state || "ended", r.at)) : ""}<span class="pj-ck">${ic("check")}</span></button>`;
      };
      const roam = (c) => pg.querySelectorAll("[data-dn]").forEach((x) => { x.tabIndex = x === c ? 0 : -1; });
      const paintGrid = () => {
        const f = foldQ(q);
        cur = sections.map(([g, rs]) => [g, f ? rs.filter((r) => hay(r).includes(f)) : rs]).filter((s) => s[1].length);
        // A register group can be renamed for the screens here (its pencil); the leftover section is not one.
        const gren = (g) => groupsSeen.includes(g) ? `<button class="pj-gn press" data-gren="${esc(g)}" aria-label="${esc(tl("room.groupRename"))}" title="${esc(tl("room.groupRename"))}">${ic("pen")}</button>` : "";
        const nm = fresh();
        if (nm && !by[nm]) by[nm] = {name: nm, fresh: true};
        pg.innerHTML = (cur.length ? cur.map(([g, rs], i) => `${g ? `<div class="pj-gh"><span class="g">${esc(gpname(g))}</span><span class="n">${rs.length}</span>${gren(g)}<span class="sp"></span>
            <button class="pj-text press" data-gall="${i}"></button></div>` : ""}<div class="pj-pgg">${rs.map(cardH).join("")}</div>`).join("")
          : nm ? "" : `<div class="pj-empty">${rooms.length ? tl("room.noMatch") : tl("room.mkEmpty")}</div>`)
          + (nm ? `<div class="pj-gh"><span class="g">${tl("room.mkHead")}</span></div><div class="pj-pgg"><button class="pj-pc pj-mk press ${sel.has(nm) ? "on" : ""}" role="option" aria-selected="${sel.has(nm)}" tabindex="-1" data-dn="${esc(nm)}">
            <span class="pj-em">${ic("plus")}</span><span class="t">${esc(tl("room.mkCard").replace("{n}", nm))}</span><span class="pj-ck">${ic("check")}</span></button></div>` : "");
        roam(pg.querySelector("[data-dn].on") || pg.querySelector("[data-dn]"));
      };
      const sync = () => {
        pg.querySelectorAll("[data-dn]").forEach((c) => {
          const r = by[c.dataset.dn], on = sel.has(c.dataset.dn);
          c.classList.toggle("on", on); c.setAttribute("aria-selected", on); c.classList.toggle("up", isUp(r));
        });
        pg.querySelectorAll("[data-gall]").forEach((b) => { b.textContent = cur[+b.dataset.gall][1].every((r) => sel.has(r.name)) ? tl("room.pk.none") : tl("room.pk.all"); });
        const picks = [...sel].map((n) => by[n]), n = picks.length;
        const ups = picks.filter(isUp).length, anyKeep = n > 1 ? ups > 0 : picks.some(canKeep);
        if (!anyKeep) mode = "auto";
        mb.innerHTML = anyKeep ? seg("mode", n > 1 ? [["keep", tl("room.pk.keepUp")], ["new", tl("room.pk.allNew")]]
          : [["keep", tl("room.keep")], ["new", tl("room.fresh")]], mode === "auto" ? (picks.some((r) => modeOf(r, n) === "keep") ? "keep" : "new") : mode) : "";
        const keeps = picks.filter((r) => modeOf(r, n) === "keep").length, news = n - keeps;
        box.querySelector("[data-modelbox]").hidden = (n > 0 && !news) || agent === "codex";
        newNames = agent === "codex" ? [] : picks.filter((r) => modeOf(r, n) === "new").map((r) => r.name);
        hint.textContent = !n ? tl("room.pk.hint0")
          : n === 1 && picks[0].fresh ? tl("room.mkHint").replace("{f}", (mkPar ? mkPar.replace(/[\\/]+$/, "") + "\\" : "") + picks[0].name)
          : n === 1 ? (keeps ? (isUp(picks[0]) ? tl("room.pk.hintUp") : tl("room.hintKeep")) : agent === "codex" ? tl("room.hintCodex") : tl("room.hintNew"))
          : keeps && news ? tl("room.pk.hintMix", {news, keeps})
          : keeps ? tl("room.pk.hintKeeps", {n: keeps})
          : tl("room.pk.hintNews", {n: news});
        if (first && n === 1 && picks[0].fresh) hint.textContent = tl("room.firstHint", {n: picks[0].name});
        hint.classList.remove("err");
        // Codex picked but it cannot answer on this PC yet: say which step is missing and lead
        // to the connect card, instead of letting the start fail with an error.
        const cx = agent === "codex" && window.LOOP_CONNECT && window.LOOP_CONNECT.step ? window.LOOP_CONNECT.step("codex") : "";
        if (cx === "install" || cx === "login") {
          hint.innerHTML = `${esc(cx === "install" ? tl("room.cxNeedInstall") : tl("room.cxNeedLogin"))} <button type="button" class="lnk press" data-connopen>${esc(tl("room.cxConnect"))}</button>`;
          hint.classList.add("err");
        }
        // Who gets the first line: the project, the conversation (the one that is up, or a new one), the agent.
        to.innerHTML = !n ? "" : n > 1 ? toLine({n, names: picks.map((r) => r.name), agent})
          : toLine({name: picks[0].name, emoji: picks[0].emoji, agent,
            conv: keeps ? (picks[0].fixed || (picks[0].title && picks[0].title !== "(제목 없음)" ? picks[0].title : tl("room.keep"))) : tl("room.toNew")});
        go.disabled = !n;
        go.textContent = n > 1 ? tl("room.pk.startN", {n}) : tl("room.start");
        paintModel();
      };
      const toggle = (name) => { if (sel.has(name)) sel.delete(name); else sel.add(name); sync(); };
      pg.onclick = (e) => {
        const gr = e.target.closest("[data-gren]");
        if (gr) return groupRename(gr.dataset.gren, () => { paintGrid(); sync(); });
        const g = e.target.closest("[data-gall]"), c = e.target.closest("[data-dn]");
        if (g) {
          const rs = cur[+g.dataset.gall][1], all = rs.every((r) => sel.has(r.name));
          rs.forEach((r) => { if (all) sel.delete(r.name); else sel.add(r.name); });
          return sync();
        }
        if (!c) return;
        toggle(c.dataset.dn); roam(c);
        // The fast path: one click on a card, type, Enter.
        if (e.detail > 0 && wide() && sel.size === 1 && sel.has(c.dataset.dn) && !ta.value) ta.focus({preventScroll: true});
      };
      pg.onkeydown = (e) => {
        const c = e.target.closest("[data-dn]");
        if (!c || e.isComposing) return;
        const cards = [...pg.querySelectorAll("[data-dn]")], i = cards.indexOf(c), top = (x) => x.getBoundingClientRect().top;
        let to = null;
        if (e.key === "ArrowRight") to = cards[i + 1];
        else if (e.key === "ArrowLeft") to = cards[i - 1];
        else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          const r0 = c.getBoundingClientRect(), down = e.key === "ArrowDown";
          const pool = (down ? cards.slice(i + 1) : cards.slice(0, i).reverse()).filter((x) => Math.abs(top(x) - r0.top) > 4);
          if (pool.length) {
            const y = top(pool[0]), dx = (x) => Math.abs(x.getBoundingClientRect().left - r0.left);
            to = pool.filter((x) => Math.abs(top(x) - y) < 4).sort((a, b) => dx(a) - dx(b))[0];
          } else if (!down) { e.preventDefault(); return qi.focus(); }
        } else if (e.key === "Home") to = cards[0];
        else if (e.key === "End") to = cards[cards.length - 1];
        else if (e.key === " ") { e.preventDefault(); return toggle(c.dataset.dn); }
        else if (e.key === "Enter") { e.preventDefault(); if (!sel.has(c.dataset.dn)) toggle(c.dataset.dn); return start(); }
        else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) return ta.focus();   // typing goes to the first line
        else return;
        e.preventDefault();
        if (to) { roam(to); to.focus(); }
      };
      qi.oninput = () => { q = qi.value; paintGrid(); sync(); };
      mkb.onclick = () => {
        const open = mkbox.hidden;
        mkbox.hidden = !open; mkb.setAttribute("aria-expanded", open);
        if (open) mkn.focus({preventScroll: true}); else { mkn.value = ""; mkn.oninput(); }
      };
      mkn.oninput = () => {
        mkName = mkn.value;
        // a half-typed new name is not a pick: only the name in the box right now can be made
        Object.keys(by).forEach((n) => { if (by[n].fresh && n !== fresh()) { sel.delete(n); delete by[n]; } });
        const nm = fresh();
        if (nm) { by[nm] = {name: nm, fresh: true}; sel.add(nm); }
        paintGrid(); sync();
      };
      mkn.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); if (fresh()) ta.focus(); } };
      if (pre && pre.mkOpen) setTimeout(() => { if (box.isConnected && mkbox.hidden) mkb.onclick(); }, 0);
      if (mkp) {
        mkp.oninput = () => { mkPar = typedPath(mkp.value) || mkRoot; sync(); };
        mkloc.onclick = () => { if (mkloc.getAttribute("aria-expanded") === "true") return;
          folderPop(mkloc, mkPar, fresh(), (p) => { mkPar = p; mkp.value = p; sync(); }, () => { mkp.focus(); mkp.select(); }); };
      }
      qi.onkeydown = (e) => {
        if (e.isComposing || e.keyCode === 229) return;
        const cards = pg.querySelectorAll("[data-dn]");
        if (e.key === "ArrowDown" && cards[0]) { e.preventDefault(); roam(cards[0]); cards[0].focus(); }
        else if (e.key === "Enter") { e.preventDefault(); if (cards.length === 1) { sel.add(cards[0].dataset.dn); sync(); ta.focus(); } }
      };
      // Enter starts on a keyboard (Shift+Enter is a new line); on a phone Enter stays a new line.
      ta.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229 && wide()) { e.preventDefault(); start(); } };

      const bulk = (jobs, text) => {
        const root = box.querySelector(".pj-new");
        root.innerHTML = `<h3 data-bh aria-live="polite"></h3><div class="pj-pg pj-res" data-res role="list"></div>
          <div class="pj-nfoot"><div class="pj-hint" data-bhint></div><div class="pj-nrow" data-bact></div></div>`;
        const res = root.querySelector("[data-res]"), bh = root.querySelector("[data-bh]"), ba = root.querySelector("[data-bact]"), bhint = root.querySelector("[data-bhint]");
        const TXT = {wait: tl("room.bulk.wait"), run: tl("room.starting"), new: tl("room.bulk.new"), keep: tl("room.bulk.keep"), fail: tl("room.bulk.fail"), skip: tl("room.bulk.skip")};
        let stop = false;
        const count = (...st) => jobs.filter((j) => st.includes(j.st)).length;
        const paint = () => {
          const ok = count("new", "keep"), bad = count("fail"), left = count("wait", "run"), skip = count("skip");
          bh.textContent = left ? tl("room.bulk.prog", {n: jobs.length, done: jobs.length - left}) : bad || skip ? tl("room.bulk.part", {ok, bad: bad + skip}) : tl("room.bulk.allOk", {n: ok});
          res.innerHTML = jobs.map((j, i) => {
            const tag = j.sid && !left ? "button" : "div";
            const say = j.st === "run" && j.mode === "keep" ? tl("room.sending") : TXT[j.st] + (j.msg ? " · " + j.msg : "");
            return `<${tag} class="pj-rr ${j.st}${tag === "button" ? " press" : ""}" role="listitem"${tag === "button" ? ` data-open="${i}"` : ""}>${em(j.r.emoji, "", j.r.icon)}
              <span class="tx"><span class="t">${esc(pname(j.r.name))}</span><span class="s">${esc(say)}</span></span>
              ${j.st === "new" || j.st === "keep" ? `<span class="pj-ck">${ic("check")}</span>` : j.st === "fail" || j.st === "skip" ? `<span class="pj-ck no">!</span>` : ""}</${tag}>`;
          }).join("");
          res.querySelectorAll("[data-open]").forEach((b) => b.onclick = () => { const j = jobs[+b.dataset.open]; closeSheet(); nav("project/" + enc(j.r.name) + "/" + enc(j.sid)); });
          if (left) { bhint.textContent = tl("room.bulk.going"); ba.innerHTML = ""; return; }
          const sids = jobs.map((j) => j.sid).filter(Boolean);
          bhint.textContent = bad ? tl("room.bulk.badHint") : skip ? tl("room.bulk.skipHint") : tl("room.bulk.okHint");
          ba.innerHTML = `${bad + skip ? `<button class="pj-btn press" data-again>${tl("room.bulk.again")}</button>` : ""}
            ${sids.length > 1 ? `<button class="pj-btn press" data-side>${tl("room.bulk.side")}</button>` : ""}<span class="sp"></span><button class="pj-btn light press" data-close>${tl("ui.close")}</button>`;
          const ag = ba.querySelector("[data-again]"), sd = ba.querySelector("[data-side]");
          if (ag) ag.onclick = () => runAll(jobs.filter((j) => j.st === "fail" || j.st === "skip"));
          if (sd) sd.onclick = () => { closeSheet(); goMulti(sids.slice(0, MAXP)); };
          ba.querySelector("[data-close]").onclick = () => { closeSheet(); if (location.hash === "#project") render(); };
          ba.querySelector("[data-close]").focus({preventScroll: true});
        };
        const one = async (j) => {
          j.st = "run"; j.msg = ""; paint();
          try {
            const r = await act("/api/session/new", body(j, text));
            j.sid = r.sid || ""; j.st = r.kept ? "keep" : "new"; j.msg = r.kept || r.sid ? "" : tl("room.bulk.soon");
          } catch (e) {
            if (e.message === "cancelled") { j.st = "skip"; j.msg = tl("room.bulk.denied"); stop = true; }
            else { j.st = "fail"; j.msg = e.message; }
          }
          paint();
        };
        const runAll = async (list) => {
          stop = false; running = true;
          list.forEach((j) => { j.st = "wait"; j.msg = ""; });
          paint();
          let i = 0;
          const worker = async () => { while (i < list.length && !stop) await one(list[i++]); };
          // The first one alone: it is the one that may ask for permission. If it did, the rest go
          // one at a time so two permission dialogs never stack; otherwise two at a time.
          let asked = false;
          const watch = setInterval(() => { if (document.querySelector(".cs-box")) asked = true; }, 120);
          if (list.length) await one(list[i++]);
          clearInterval(watch);
          await Promise.all(asked ? [worker()] : [worker(), worker()]);
          list.forEach((j) => { if (j.st === "wait") { j.st = "skip"; j.msg = tl("room.bulk.skipped"); } });
          running = false; roomsCache = null;
          if (root.isConnected) paint();
          else toast(count("fail", "skip") ? tl("room.bulk.part", {ok: count("new", "keep"), bad: count("fail", "skip")}) : tl("room.pk.startN", {n: count("new", "keep")}));
        };
        runAll(jobs);
      };
      async function start() {
        if (running) return;
        const text = ta.value.trim(), picks = [...sel].map((n) => by[n]).filter(Boolean);
        if (!picks.length) return toast(tl("room.hintPick"));
        if (!text) { ta.focus(); return toast(tl("room.needFirst")); }
        const jobs = picks.map((r) => ({r, mode: modeOf(r, picks.length), st: "wait", msg: "", sid: ""}));
        if (jobs.length > 1) return bulk(jobs, text);
        running = true; go.disabled = true; go.innerHTML = loadingHtml(tl("room.starting"), {inline: true});
        try {
          const r = await act("/api/session/new", body(jobs[0], text));
          closeSheet(); toast(r.message || tl("room.started")); roomsCache = null;
          started(r.name || picks[0].name);
          // Claude has not named the new session yet: the page waits for it instead of opening
          // the project's older one (V11 #3).
          if (!r.kept && (r.sid || r.job)) pendNew[r.name || picks[0].name] = {job: r.job, sid: r.sid, text, at: Date.now()};
          nav("project/" + enc(r.name || picks[0].name) + (r.sid ? "/" + enc(r.sid) : ""));
        } catch (e) {
          running = false; go.disabled = false; go.textContent = tl("room.start");
          if (jobs[0].r.fresh) roomsCache = null;      // it may have been made even though the chat did not start
          // The reason stays on the sheet (a toast is gone before a long one is read).
          // Said once: on the sheet while it is up, as a toast only when it is not.
          if (e.message !== "cancelled") { hint.textContent = e.message; hint.classList.add("err"); if (!hint.isConnected) toast(e.message); }
        }
      }
      go.onclick = start;
      paintGrid(); sync();
      if (pre) {
        ta.value = pre.text || "";
        if (pre.mk) { mkbox.hidden = false; mkb.setAttribute("aria-expanded", true); mkn.value = pre.mk; mkn.oninput(); }
      }
      if (!wide()) return;
      if (sel.size) ta.focus({preventScroll: true}); else qi.focus({preventScroll: true});
    });
  }

  // + 새 대화: two questions and nothing else. Which folder (recent first, a search once the list
  // is long, or a new one by name), then Claude or Codex. It ends on that folder's empty chat,
  // ready to type in. A first line for several folders at once and a model stay on newChat().
  async function newTalk(preset, toMake) {
    ensureCss();
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const at = (r) => String(r.at || "");
    const rooms = (roomsCache || []).filter((r) => !r.lost).sort((a, b) => (b.name === preset) - (a.name === preset) || at(b).localeCompare(at(a)));
    let name = "", made = "", busy = false;
    sheet(`<div class="pj-dlg pj-nt"></div>`, (box) => {
      const root = box.querySelector(".pj-nt");
      const head = (n, t) => `<div class="pj-nts">${n} / 2</div><h3>${esc(t)}</h3>`;
      const where = () => {
        root.innerHTML = head(1, tl("room.nt.where"))
          + (rooms.length > 8 ? `<input class="pj-search" type="search" data-q placeholder="${esc(tl("room.searchOnly"))}" aria-label="${esc(tl("room.searchOnly"))}">` : "")
          + `<div class="pj-ntl" data-l role="listbox" aria-label="${esc(tl("room.nt.where"))}"></div>
          <div class="pj-ntm"><input class="tin" data-mk type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.mkName"))}" aria-label="${esc(tl("room.mkName"))}">
            <button class="pj-btn light press" data-mkgo disabled>${tl("onboard.next")}</button></div>
          <div class="pj-ntf"><span class="sp"></span><button class="pj-text press" data-more>${tl("room.nt.more")}</button></div>`;
        const l = root.querySelector("[data-l]"), q = root.querySelector("[data-q]"), mk = root.querySelector("[data-mk]"), mkgo = root.querySelector("[data-mkgo]");
        const paint = () => {
          const f = foldQ(q ? q.value : ""), rs = f ? rooms.filter((r) => hay(r).includes(f)) : rooms;
          l.innerHTML = rs.map((r) => `<button class="pj-pc press" role="option" data-dn="${esc(r.name)}">${em(r.emoji, "", r.icon)}<span class="t">${esc(pname(r.name))}</span></button>`).join("")
            || `<div class="pj-hint">${esc(tl(rooms.length ? "room.noMatch" : "room.mkEmpty"))}</div>`;
          l.querySelectorAll("[data-dn]").forEach((b) => b.onclick = () => { name = b.dataset.dn; made = ""; who(); });
        };
        const fresh = () => { const v = mk.value.trim(); return v && !rooms.some((r) => r.name.toLowerCase() === v.toLowerCase()) ? v : ""; };
        const next = () => { if (!fresh()) return; made = fresh(); name = ""; who(); };
        if (q) q.oninput = paint;
        mk.value = made;
        mk.oninput = () => { mkgo.disabled = !fresh(); };
        mk.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); next(); } };
        mkgo.onclick = next;
        root.querySelector("[data-more]").onclick = () => { closeSheet(); newChat(preset); };
        paint(); mk.oninput();
        if (wide() || toMake) { const f = (!toMake && l.querySelector("[data-dn]")) || mk; f.focus({preventScroll: true}); }
      };
      const who = () => {
        const r = rooms.find((x) => x.name === name), was = r && (draftAgent[name] || r.agent) === "codex" ? "codex" : "claude";
        root.innerHTML = head(2, tl("room.nt.who"))
          + `<div class="pj-nta">${[["claude", "Claude"], ["codex", "Codex"]].map(([v, t]) => `<button class="pj-pc press" data-ag="${v}">${window.agDot(v)}<span class="t">${t}</span></button>`).join("")}</div>
          <div class="pj-hint${made ? "" : " pj-ntw"}" data-hint>${made ? esc(tl("room.firstHint", {n: made})) : em(r.emoji, "", r.icon) + `<span class="t">${esc(pname(name))}</span>`}</div>
          <div class="pj-ntf"><button class="pj-text press" data-prev>${tl("head.1")}</button><span class="sp"></span></div>`;
        const hint = root.querySelector("[data-hint]");
        root.querySelector("[data-prev]").onclick = where;
        root.querySelectorAll("[data-ag]").forEach((b) => b.onclick = async () => {
          if (busy) return;
          const agent = b.dataset.ag;
          let to = name;
          if (made) {
            busy = true; hint.classList.remove("err"); hint.innerHTML = loadingHtml(tl("room.starting"), {inline: true});
            try { const r = await act("/api/depts/create", {name: made, agent, create: true}); to = (r.dept && r.dept.name) || made; roomsCache = null; }
            catch (e) { busy = false; hint.textContent = e.message === "cancelled" ? tl("room.firstHint", {n: made}) : e.message; hint.classList.toggle("err", e.message !== "cancelled"); return; }
          }
          draftAgent[to] = agent;
          closeSheet(); nav("project/" + enc(to) + "/" + NEW);
        });
        if (wide()) root.querySelector(`[data-ag="${was}"]`).focus({preventScroll: true});
      };
      where();
    });
  }

  // new-default:begin
  // Where [새 세션] opens when nothing is selected: the project talked in last (its newest line),
  // else the first one listed. A project whose folder is gone (`lost`) is passed over, and
  // `skipped` names it when it would have been the pick, so the page can say so.
  function newDefault(list) {
    const at = (r) => String(r.at || ""), newest = (rs) => rs.reduce((a, b) => (at(b) > at(a) ? b : a), rs[0]);
    const had = (list || []).filter((r) => r.sid), ok = had.filter((r) => !r.lost);
    const room = ok.length ? newest(ok) : (list || []).find((r) => !r.lost) || null;
    const was = had.length ? newest(had) : null;
    return {room, skipped: room && was && was.lost ? was : null};
  }
  // new-default:end
  // A first line was really taken by a session: the first-use guide moves on from this, not from a click.
  const started = (name) => { try { window.dispatchEvent(new CustomEvent("loop:session-new", {detail: {name}})); } catch (e) { /* old engine */ } };
  // The guide's [대화 시작]: the same composer as [새 세션] with the first line already in the box.
  // No project yet: the new-chat sheet, with a new project's name filled in as well.
  window.LOOP_FIRST_LINE = async function (text, agent) {
    if (!roomsCache) { try { await loadRooms(); } catch (e) { toast(e.message); return false; } }
    const d = newDefault(roomsCache || []);
    if (!d.room) { await newChat({text, agent, mk: tl("onboard.ohFirstProj")}); return true; }
    if (!drafts[d.room.name]) drafts[d.room.name] = text;
    if (agent === "codex") draftAgent[d.room.name] = "codex";
    nav("project/" + enc(d.room.name) + "/" + NEW);
    return true;
  };
  window.LOOP_NEW_CHAT = (x) => x && typeof x === "object" ? newChat(x) : newTalk(x);      // the sessions screen's [새 대화] and per-group "+" open the same sheet
  // A session opened a moment ago that has no id yet, by project: {job, text, at}.
  const pendNew = {};
  // new-wait:begin
  const PEND_MAX = 90000;
  const PEND_SID = 20000;                              // a session that has its id is listed within moments; after this the pane says so
  // The session opened a moment ago (`pp`) that the page at `sid` waits for, else null. With no id
  // in the address it is the one Claude has not named yet. With an id it is that very session
  // while the list does not have it: the page waits there and never opens the empty draft or an
  // older session in its place (0.1.64: a Codex line sent from the draft "just disappeared").
  function pendFor(pp, sid, listed, now) {
    if (!pp) return null;
    if (sid) return pp.sid === sid && !listed ? pp : null;
    return !pp.sid && now - pp.at < PEND_MAX ? pp : null;
  }
  // Whether the answer kept from last time (`v`) is worth painting before the fresh one arrives.
  // Not on a page that already shows this very chat (`same`: a refresh - the kept answer is older
  // than what is drawn and would take a new row out for a moment), and not when it does not know
  // the session asked for (a new one: the page would open another chat in the meantime).
  function seenPaint(v, sid, isNew, same) {
    if (!v || same) return false;
    return !sid || isNew || (v.sessions || []).some((s) => s.id === sid);
  }
  // new-wait:end
  const draftErr = {}, draftCode = {};   // why the first line did not go, and the server's code for it
  const draftBusy = {};                              // name -> the first line still on its way (survives a redraw)
  let readOffer = null;                               // that offer, while its bar is up
  // Nothing is read until [허용] is pressed; [닫기] only takes the bar away.
  function readBar(box, redraw, after) {
    if (!readOffer || box.querySelector(".pj-rbar")) return;
    const bar = document.createElement("div");
    bar.className = "pj-rbar"; bar.setAttribute("role", "status");
    bar.innerHTML = `<span>${tl("room.readBar")}</span><span class="a"><button class="pj-btn light press" data-ok>${tl("room.readBarOk")}</button><button class="pj-btn press" data-no>${tl("room.readBarNo")}</button></span>`;
    const scope = readOffer.scope;
    bar.querySelector("[data-ok]").onclick = () => { readOffer = null; bar.remove();
      post("/api/consent/grant", {scope}).then(redraw).catch((e) => toast(e.message)); };
    bar.querySelector("[data-no]").onclick = () => { readOffer = null; bar.remove(); };
    if (after) after.after(bar); else box.prepend(bar);
  }
  let offered = false;                               // the Codex record read was offered this run                                 // why the last first line did not go out, per project (shown in the draft until the next try)

  // A group's display name (the register and the folders keep the real one). Empty puts it back.
  function groupRename(g, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("room.groupRename")}</h3>
      <input class="pj-search" data-gn maxlength="60" spellcheck="false" value="${esc(gpname(g))}" placeholder="${esc(g)}" aria-label="${esc(tl("room.groupRename"))}" style="width:100%;margin-top:10px">
      <div class="pj-hint">${esc(tl("room.groupRenameNote", {name: g}))}</div>
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-gn]");
      setTimeout(() => { inp.focus(); inp.select(); }, 50);
      const save = async () => {
        try {
          const r = await post("/api/custom/identity", {group: g, name: inp.value.trim()});
          D.gident = r.group_names || {}; closeSheet(); toast(tl("room.groupRenamed"));
          if ((r.renamed || []).length) await load();      // its members' names followed it
          if (again) again(); else render();
        } catch (e) { toast(e.message); }
      };
      const run = saving(box.querySelector("[data-go]"), save);
      box.querySelector("[data-go]").onclick = run;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); run(); } };
    });
  }
  window.LOOP_GROUP_RENAME = groupRename;
  // One save at a time: Enter twice, or Enter and then the button, sent the same save again
  // while the first was still on its way (three presses, three requests).
  const saving = (go, fn) => async () => {
    if (go.disabled) return;
    go.disabled = true; go.setAttribute("aria-busy", "true");
    try { await fn(); } finally { go.disabled = false; go.removeAttribute("aria-busy"); }
  };
  // A session's name here (the record keeps its own title). Empty puts the record's back.
  function sessRename(s, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("pj.name.h")}</h3>
      <input class="pj-search" data-sn maxlength="120" spellcheck="false" value="${esc(s.renamed ? s.title : "")}" placeholder="${esc(title(s))}" aria-label="${esc(tl("pj.name.h"))}" style="width:100%;margin-top:10px">
      <div class="pj-hint">${tl("pj.name.note")}</div>
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-sn]");
      setTimeout(() => { inp.focus(); inp.select(); }, 50);
      const save = async () => {
        try {
          await post("/api/sessions/rename", {id: s.id, name: inp.value.trim()});
          closeSheet(); await load(); if (again) again(); else render();
        } catch (e) { toast(e.message); }
      };
      const run = saving(box.querySelector("[data-go]"), save);
      box.querySelector("[data-go]").onclick = run;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); run(); } };
    });
  }

  // ---- several rooms at once: #project/~multi/<sid>,<sid>… (up to 6) ------------------------------
  async function pickPanes(have, done) {
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const rooms = (roomsCache || []).filter((r) => r.sid && !have.includes(r.sid)), sel = new Set(), room = MAXP - have.length;
    sheet(`<div class="pj-dlg"><h3>${tl("room.pickTitle")}</h3><div class="pj-hint" style="margin-top:0">${esc(tl("room.pickHint", {n: room}))}</div>
      <div class="pj-dl pj-pick" style="max-height:48vh">${rooms.map((r) => `<button class="press" data-ps="${esc(r.sid)}" aria-pressed="false">
          ${em(r.emoji, "", r.icon)}<span class="t">${esc(pname(r.name))}</span>${dot(r.state || "ended")}<span class="pj-ck">${ic("check")}</span></button>`).join("")
        || `<div class="pj-empty">${tl("room.noSession")}</div>`}</div>
      <div class="acts"><button class="pj-btn light full press" data-go disabled>${tl("room.openPanes")}</button></div></div>`, (box) => {
      const go = box.querySelector("[data-go]");
      box.querySelectorAll("[data-ps]").forEach((b) => b.onclick = () => {
        const id = b.dataset.ps;
        if (sel.has(id)) sel.delete(id); else if (sel.size < room) sel.add(id); else return toast(tl("room.max", {n: MAXP}));
        b.setAttribute("aria-pressed", sel.has(id)); b.classList.toggle("on", sel.has(id));
        go.disabled = !sel.size; go.textContent = sel.size ? tl("room.openN", {n: sel.size}) : tl("room.openPanes");
      });
      go.onclick = () => { closeSheet(); done([...have, ...sel]); };
    });
  }
  function saveBundle(ids, again) {
    sheet(`<div class="pj-dlg"><h3>${tl("room.saveBundle")}</h3>
      <input class="pj-search" data-bn maxlength="40" placeholder="${esc(tl("room.bundleName"))}" aria-label="${esc(tl("room.bundleName"))}" style="width:100%;margin-top:10px">
      <div class="acts"><button class="pj-btn light full press" data-go>${tl("room.save")}</button></div></div>`, (box) => {
      const inp = box.querySelector("[data-bn]"), go = box.querySelector("[data-go]");
      setTimeout(() => inp.focus(), 50);
      const save = async () => {
        const name = inp.value.trim(); if (!name) return inp.focus();
        try { await post("/api/room-bundles", {name, ids}); closeSheet(); toast(tl("room.saved")); again(); }
        catch (e) { toast(e.message); }
      };
      const run = saving(go, save);
      go.onclick = run;
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); run(); } };
    });
  }
  async function drawMulti(el, ids, my) {
    ids = [...new Set(ids.filter(Boolean))].slice(0, MAXP);
    tab = "conv";                                      // panes show only the chat
    if (!ids.length) return nav(listHash());
    el.innerHTML = loadingHtml(tl("room.loading"), {fill: true});
    const [infos, bund] = await Promise.all([
      Promise.all(ids.map((id) => get("/api/project/session?id=" + enc(id)).catch((e) => ({failed: e})))),
      bundlesOf(), roomsCache ? null : loadRooms().catch(() => null)]);
    if (!live(my)) return;
    const panes = ids.map((id, i) => Object.assign({}, infos[i], {id}));
    if (mFocus >= panes.length) mFocus = 0;
    const emo = (p) => ((roomsCache || []).find((r) => r.name === p.project) || {}).emoji || "";
    const n = panes.length, allPh = tl("room.sendAll", {n});
    el.innerHTML = `<button class="pj-back press" data-b>← ${tl("room.rooms")}</button>
      <div class="pj-top"><div class="pj-lab" style="margin:0">${tl("room.multi")} <span class="n">${n}</span></div><span class="sp"></span>
        ${bund.map((b, i) => `<button class="pj-chip press" data-bund="${i}">${esc(b.name)}</button>`).join("")}
        <button class="pj-text press" data-save>${tl("room.saveBundle")}</button>
        ${n < MAXP ? `<button class="pj-btn press" data-add>${ic("plus")}<span>${tl("room.addPane")}</span></button>` : ""}</div>
      <div class="pj-all"><textarea rows="1" data-all placeholder="${esc(allPh)}" aria-label="${esc(allPh)}"></textarea>
        <button class="pj-btn light press" data-allgo>${tl("room.sendAllGo")}</button></div>
      <div class="pj-to">${toLine({n: Math.max(2, panes.filter((p) => p.found && p.project).length), names: panes.filter((p) => p.found && p.project).map((p) => p.project)})}</div>
      <div class="pj-mtabs" role="tablist">${panes.map((p, i) => `<button class="press ${i === mFocus ? "on" : ""}" role="tab" aria-selected="${i === mFocus}" data-mt="${i}">${esc(emo(p))} ${esc(pname(p.project || "") || p.id.slice(0, 8))}</button>`).join("")}</div>
      <div class="pj-mgrid n${n} r${n > 3 ? 2 : 1}">${panes.map((p, i) => `<section class="pj-mp pj-anim ${i === mFocus ? "focus" : ""}" data-mp="${i}" aria-label="${esc(pname(p.project || ""))}">
        <div class="pj-mhead">${em(emo(p), "", icoOf(p.project)).replace("<span ", '<span style="font-size:16px" ')}<span class="t">${esc(pname(p.project || ""))}</span>
          <span class="s">${p.found ? esc(title(p)) : ""}</span><span class="sp"></span>
          <button class="pj-more press" data-big="${i}" aria-label="${esc(tl("room.bigger"))}" title="${esc(tl("room.bigger"))}">${ic("full")}</button>
          <button class="pj-more press" data-x="${i}" aria-label="${esc(tl("room.closePane"))}" title="${esc(tl("room.closePane"))}">${ic("x")}</button></div>
        <div class="pj-mb"></div></section>`).join("")}</div>`;
    el.querySelector("[data-b]").onclick = () => nav(listHash());
    el.querySelectorAll("[data-bund]").forEach((b) => b.onclick = () => goMulti(bund[+b.dataset.bund].ids));
    el.querySelector("[data-save]").onclick = () => saveBundle(ids, () => draw(el));
    const add = el.querySelector("[data-add]");
    if (add) add.onclick = () => pickPanes(ids, goMulti);
    el.querySelectorAll("[data-x]").forEach((b) => b.onclick = () => { const rest = ids.filter((_, i) => i !== +b.dataset.x); rest.length ? goMulti(rest) : nav(listHash()); });
    el.querySelectorAll("[data-big]").forEach((b) => b.onclick = () => { const p = panes[+b.dataset.big]; nav("project/" + enc(p.project || "") + "/" + enc(p.id)); });
    el.querySelectorAll("[data-mt]").forEach((b) => b.onclick = () => {
      mFocus = +b.dataset.mt;
      el.querySelectorAll("[data-mt]").forEach((x, i) => { x.classList.toggle("on", i === mFocus); x.setAttribute("aria-selected", i === mFocus); });
      el.querySelectorAll("[data-mp]").forEach((x, i) => x.classList.toggle("focus", i === mFocus));
    });
    panes.forEach((p, i) => {
      const body = el.querySelector(`[data-mp="${i}"] .pj-mb`);
      if (p.failed) return failed(body, p.failed);     // not read is not gone: say why, with one way to ask again
      if (!p.found || !p.project) { body.innerHTML = `<div class="pj-empty">${tl("room.gone")}</div>`; return; }
      body.dataset.multi = "1";
      drawSession(body, el, p.project, p, my);
    });
    // One line to every open room: each goes through that room's own route (live inbox, hold, wake).
    const all = el.querySelector("[data-all]"), allGo = el.querySelector("[data-allgo]");
    const grow = () => { all.style.height = "auto"; all.style.height = Math.min(all.scrollHeight, 120) + "px"; };
    all.addEventListener("input", grow);
    const sendAll = async () => {
      const text = all.value.trim(); if (!text || allGo.disabled) return;
      allGo.disabled = true; all.value = ""; grow();
      let ok = 0;
      for (const [i, p] of panes.entries()) {
        if (!p.found || !p.project) continue;
        const body = el.querySelector(`[data-mp="${i}"] .pj-mb`), c = C(p.id), pe = {text, tag: tl("room.sending"), busy: true, at: Date.now()};
        c.pend.push(pe); c.stick = true; paint(body, c, false, c.entries.length);
        try {
          const r = await act("/api/session/tell", {sid: p.id, text}); ansMark(p.id, true);
          pe.tag = r.routed === "live" ? tl("room.sent") : (r.message || tl("room.sent")); pe.busy = false; pe.route = r.routed; ok++;
          if (p.agent !== "codex" && r.routed !== "hook") c.waiting = true;
          if (c.kick) c.kick();
        } catch (e) { c.pend.splice(c.pend.indexOf(pe), 1); if (e.message !== "cancelled") toast(e.message); }
        paint(body, c, false, c.entries.length);
      }
      allGo.disabled = false;
      // Nothing went out: the line goes back in the box instead of being lost.
      if (ok) toast(tl("room.sentAll", {n: ok})); else if (!all.value) { all.value = text; grow(); }
    };
    allGo.onclick = sendAll;
    let composing = false;
    all.addEventListener("compositionstart", () => { composing = true; });
    all.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    all.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); sendAll();
    });
  }

  // A menu opens under its button, on the page itself: inside a card or the chat panel it was cut
  // off by their overflow whenever the column was narrower than the menu. Kept inside the window,
  // flipped above the button when there is no room below; gone on an outside press, Esc or a scroll.
  let kbLast = false;                                 // the last thing pressed was a key, not the pointer
  addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") kbLast = true; }, true);
  addEventListener("pointerdown", () => { kbLast = false; }, true);
  function popAt(pop, btn) {
    document.body.appendChild(pop);
    const at = ctxAt; ctxAt = null;                   // a right click: at the pointer, not under a button
    const b = btn.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight, m = 8;
    const below = at ? at.y + h <= innerHeight - m : !btn.closest(".pj-fab") && b.bottom + 4 + h <= innerHeight - m;   // the phone's floating button opens upward, clear of the tab bar
    if (at) {
      const p = window.PjCtx.place(at.x, at.y, w, h, innerWidth, innerHeight, m, at.row && matchMedia("(pointer:coarse)").matches ? at.row.getBoundingClientRect() : null);
      pop.style.left = p.left + "px"; pop.style.top = p.top + "px";
      pop.style.transformOrigin = (p.below ? "top " : "bottom ") + (p.right ? "left" : "right");
    } else {
      pop.style.left = Math.max(m, Math.min(b.right - w, innerWidth - w - m)) + "px";
      pop.style.top = Math.max(m, below ? b.bottom + 4 : b.top - 4 - h) + "px";
      pop.style.transformOrigin = below ? "top right" : "bottom right";
    }
    if (window.Motion && Motion.menuIn) Motion.menuIn(pop);
    else if (!RM()) pop.animate([{opacity: 0, transform: "scale(.96)"}, {opacity: 1, transform: "none"}], {duration: 180, easing: "cubic-bezier(.2,.9,.25,1)"});
    // The button says its menu is open for as long as the menu is there, however it closes
    // (a choice removes it without passing through off).
    if (!at && btn.matches("button")) {
      btn.setAttribute("aria-expanded", "true");
      const gone = new MutationObserver(() => { if (!pop.isConnected) { gone.disconnect(); btn.setAttribute("aria-expanded", "false"); } });
      gone.observe(document.body, {childList: true});
    }
    const off = () => { if (window.Motion && Motion.menuOut) Motion.menuOut(pop); else pop.remove(); document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", key, true);
      removeEventListener("scroll", moved, true); removeEventListener("resize", off); removeEventListener("hashchange", off); removeEventListener("blur", off); };
    const out = (e) => { if (!pop.contains(e.target)) off(); };
    const back = at && at.row && at.row.isConnected ? at.row : btn;   // where the keyboard goes back to
    // Only a scroll that carries the menu's own anchor away closes it. A working chat scrolls by
    // itself each time a line arrives, and that used to shut a menu opened from the header.
    const moved = (e) => { const t = e.target; if (t === document || (t.contains && t.contains(back))) off(); };
    const menu = !!at || pop.classList.contains("cm"), byKey = kbLast;
    const key = (e) => {
      if (!pop.isConnected) return off();              // closed by a choice: its keys are the page's again (Esc then closes the sheet that choice opened)
      if (e.key === "Escape") { e.stopPropagation(); off(); back.focus({preventScroll: true}); return; }
      // A choice's own letter (shown beside it) runs it: by the key's place, so it answers in 한글
      // mode too. Not with a modifier held, nor while a syllable is being composed.
      if (pop.isConnected && /^Key[A-Z]$/.test(e.code || "") && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && !e.isComposing) {
        const k = [...pop.querySelectorAll("button[data-k]")].find((x) => x.dataset.k === e.code.slice(3) && !x.closest("[hidden]"));
        if (k) { e.preventDefault(); e.stopPropagation(); k.click(); return; }
      }
      // A menu: up and down walk the choices, Home and End jump, Tab leaves and closes. (A menu
      // opened from its button had none of this: the keys went to the list behind it.)
      if (!menu || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName || "")) return;
      if (e.key === "Tab") { off(); back.focus({preventScroll: true}); return; }
      const list = [...pop.querySelectorAll("button")].filter((x) => !x.closest("[hidden]")), to = window.PjCtx.step(list.length, list.indexOf(document.activeElement), e.key);
      if (to < 0) return;
      e.preventDefault(); e.stopPropagation(); list[to].focus({preventScroll: true});
    };
    if (at) {
      pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", at.label || "");
      pop.querySelectorAll("button").forEach((x) => { x.setAttribute("role", "menuitem"); x.tabIndex = -1; });
      const f = pop.querySelector("button:not([aria-disabled])") || pop.querySelector("button");
      if (f && at.kb) f.focus({preventScroll: true});
    }
    else if (menu && byKey) {                          // opened with Enter or Space: the first choice has the keys
      if (!pop.getAttribute("role")) pop.setAttribute("role", "menu");
      const f = pop.querySelector("button:not([aria-disabled]):not([hidden])");
      if (f) f.focus({preventScroll: true});
    }
    setTimeout(() => { document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", key, true);
      addEventListener("scroll", moved, true); addEventListener("resize", off); addEventListener("hashchange", off); if (at) addEventListener("blur", off); }, 0);
    return off;
  }

  // The caret beside [새 세션]: the quieter way to start. 새 세션 itself stays one press.
  const pinMk = () => `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>`;
  function newMenu(btn) {
    // A second press on the caret closes the menu it opened (the outside-press already did).
    if (popBusy("new")) return;
    if (btn.getAttribute("aria-expanded") === "true" || performance.now() - (btn._shut || 0) < 320) return;
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm pj-nm"; pop.setAttribute("role", "menu");
    const it = (k, i, t) => `<button role="menuitem" data-a="${k}">${ic(i)}<span>${t}</span></button>`;
    pop.innerHTML = it("find", "power", tl("room.nmOn")) + (window.LOOP_BULK_START && onThisPc() ? it("many", "list", tl("bk.pick")) : "") + it("make", "plus", tl("room.nmMake"));
    const off = popAt(pop, btn);      // off, not only removed: its Esc listener would swallow the sheet's Esc
    expanded("new", "[data-newmenu]", pop);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); off();
      if (b.dataset.a === "find") return findOn();
      if (b.dataset.a === "many") return manyOn();
      // Another device may not make a folder here by itself: it keeps the way that starts a talk.
      if (b.dataset.a === "make" && !onThisPc()) return newChat({mkOpen: true});
      // A new folder is made where a new chat is: its name, then who. Role and icon come after.
      if (b.dataset.a === "make") return newTalk("", true);
      talkMake("fixed"); });
  }

  // 말로 만들기 (만들기 and 담당 in that menu): one line of what the work is, and the connected
  // CLI proposes a name and a role for it (/api/depts/propose makes nothing). The proposal fills a
  // card the person can change, and only the card's button creates, through the same calls the
  // typed forms use. With no proposal the card opens with the person's own words and says so.
  async function talkMake(kind) {
    ensureCss();
    const fixed = kind === "fixed", head = fixed ? tl("room.fixed.new") : tl("room.mkNew");
    const path = fixed ? "/api/session/standing" : "/api/depts/create";
    let seq = 0, text = "", agents = {}, defRoot = "", parent = "", groups = [];
    get("/api/depts").then((d) => { agents = d.agents || {}; defRoot = d.default_root || ""; parent = d.parent || defRoot; groups = d.groups || []; }).catch(() => {});
    sheet(`<div class="pj-dlg pj-tm"></div>`, (box) => {
      const root = box.querySelector(".pj-tm");
      const fade = () => { if (!RM()) root.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease"}); };
      const own = (t) => fixed ? {name: "", task: t.slice(0, 200)} : {name: "", role: t.slice(0, 40), group: ""};
      // sug: true the CLI's proposal, false it was asked and nothing came, null the person skipped it.
      const card = (p, sug) => {
        const agent = !agents.claude && agents.codex ? "codex" : "claude";
        let pseq = 0, ready = "", busy = false, timer = 0, auto = "";
        const f2 = fixed ? ["task", tl("room.fixed.task"), 200] : ["role", tl("depts.role"), 40];
        root.innerHTML = `<h3>${sug ? tl("room.tm.sug") : head}</h3>${sug === false ? `<p class="hint">${tl("room.tm.none")}</p>` : ""}
          <div class="lbl">${tl("room.fixed.name")}</div>
          <div class="tm-nm"><button type="button" class="tm-em press" data-em aria-expanded="false" aria-label="${esc(tl("depts.emoji"))}" title="${esc(tl("depts.emoji"))}"></button><input class="tin" data-n type="text" maxlength="60" spellcheck="false" autocomplete="off" aria-label="${esc(tl("room.fixed.name"))}"></div>
          <div class="tm-grid" data-eg role="listbox" aria-label="${esc(tl("depts.emoji"))}" hidden></div>
          <div class="lbl">${f2[1]}</div><input class="tin" data-f2 type="text" maxlength="${f2[2]}" autocomplete="off" aria-label="${esc(f2[1])}">
          ${fixed ? "" : `<div class="lbl">${tl("depts.group")}</div><input class="tin" data-g type="text" maxlength="40" autocomplete="off" aria-label="${esc(tl("depts.group"))}"><div class="tm-gs" data-gs></div>`}
          <div data-pv aria-live="polite"></div>
          ${fixed || !onThisPc() ? "" : `<div data-par hidden><div class="lbl">${tl("depts.folder.where")}</div><div class="tm-par"><input class="tin" data-pin type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("depts.folder.where"))}">${sysPick() ? `<button type="button" class="pj-text press" data-ppick>${tl("room.loc.pick")}</button>` : ""}</div></div>`}
          <div class="pj-tmr"><button type="button" class="pj-text press" data-tmback>${tl("room.tm.back")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-go disabled>${tl("depts.pv.make")}</button></div>`;
        fade();
        const q = (x) => root.querySelector(x), nameEl = q("[data-n]"), f2El = q("[data-f2]"), gEl = q("[data-g]"), pv = q("[data-pv]"), go = q("[data-go]"), emEl = q("[data-em]"), parEl = q("[data-par]");
        nameEl.value = p.name || ""; f2El.value = p[f2[0]] || ""; if (gEl) gEl.value = p.group || "";
        const body = (dry) => Object.assign({name: nameEl.value.trim(), agent, [f2[0]]: f2El.value.trim()}, fixed ? {} : {group: gEl.value.trim(), create: true},
          onThisPc() ? {parent: String(parent).toLowerCase() === String(defRoot).toLowerCase() ? "" : parent} : {}, p.emoji ? {emoji: p.emoji} : {}, dry ? {dry_run: true} : {});
        const key = () => JSON.stringify(body(true));
        const sync = () => { go.disabled = busy || !ready || ready !== key(); emEl.textContent = p.emoji || auto || ""; };
        const preview = async () => {
          const my = ++pseq, k = key();
          if (!nameEl.value.trim()) { ready = ""; auto = ""; pv.innerHTML = ""; return sync(); }
          try {
            const v = (await post(path, body(true))).preview;
            if (my !== pseq || !root.isConnected) return;
            auto = v.emoji || "";
            pv.innerHTML = (parEl ? `<button type="button" class="tm-at press" data-atedit aria-expanded="${!parEl.hidden}" title="${esc(v.folder)}">` : `<div class="tm-at" title="${esc(v.folder)}">`) + `${ic("folder")}<span><bdi>${esc(v.folder)}</bdi></span>${parEl ? ic("pen") + "</button>" : "</div>"}` + (v.warnings || []).map((w) => `<p class="hint">${esc(w)}</p>`).join("");
            ready = k;
          } catch (err) {
            if (my !== pseq || !root.isConnected) return;
            pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = "";
          }
          sync();
        };
        const later = () => { ready = ""; sync(); clearTimeout(timer); timer = setTimeout(preview, 220); };
        const make = async () => {
          if (go.disabled) return;
          busy = true; sync();
          try {
            const r = await act(path, body(false));
            if (fixed) {
              roomsCache = null; closeSheet();
              toast(tl("room.fixed.made", {n: r.title || r.name}));
              return nav("project/" + enc(r.name));
            }
            if (!r || !r.dept) { busy = false; return sync(); }
            roomsCache = null; if (railNow) railNow();
            const pn = r.dept.name;
            root.innerHTML = `<div class="tm-done"><span class="e" aria-hidden="true">${esc(r.dept.emoji || "")}</span><b>${esc(pname(pn))}</b><span role="status">${tl("room.tm.done")}</span></div>
              <div class="pj-tmr"><button type="button" class="pj-text press" data-sclose>${tl("itemView.114")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-on>${icl("play")}<span>${tl("room.on")}</span></button></div>`;
            fade();
            const on = root.querySelector("[data-on]");
            on.onclick = async () => { closeSheet(); if (!roomsCache) { try { await loadRooms(); } catch (e) { /* the start says why */ } } turnOn(pn, null, () => { if (railNow) railNow(); }); };
            if (wide()) on.focus({preventScroll: true});
          } catch (err) {
            busy = false; sync();
            if (err.message !== "cancelled") { pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = ""; sync(); }
          }
        };
        // The face is a button: the fitting few first, then every one. The pick goes out with the rest.
        const egEl = q("[data-eg]"), EM = window.LOOP_EMOJI;
        emEl.onclick = () => {
          const on = egEl.hidden; egEl.hidden = !on; emEl.setAttribute("aria-expanded", on);
          if (!on || !EM) return;
          const first = EM.suggest(nameEl.value || f2El.value, [], 8), all = EM.search("", 2000).map((o) => o.e).filter((e) => !first.includes(e));
          egEl.innerHTML = first.concat(all).map((e) => `<button type="button" role="option" data-e="${e}" aria-label="${e}">${e}</button>`).join("");
        };
        egEl.onclick = (ev) => { const b = ev.target.closest("[data-e]"); if (!b) return; p.emoji = b.dataset.e; egEl.hidden = true; emEl.setAttribute("aria-expanded", false); later(); };
        // The groups there are, one press each, on show only while the field is being filled: a
        // name being typed narrows them, and one that is already a group offers the others.
        const gsEl = q("[data-gs]");
        const drawGs = () => { if (!gsEl) return;
          const v = gEl.value.trim(), lv = v.toLowerCase(), all = !v || groups.includes(v);
          gsEl.innerHTML = groups.filter((g) => g !== v && (all || g.toLowerCase().includes(lv))).map((g) => `<button type="button" class="press" data-g1="${esc(g)}">${esc(g)}</button>`).join(""); };
        if (gsEl) {
          gsEl.onpointerdown = (ev) => ev.preventDefault();      // the press must not take the field's focus, which closes the row
          gsEl.onclick = (ev) => { const b = ev.target.closest("[data-g1]"); if (!b) return; gEl.value = b.dataset.g1; gEl.blur(); later(); };
          gEl.addEventListener("input", drawGs);
          // The sheet is centred, so a taller card would lift the fields above: the card is held where it
          // stood and grows downward, as far as the window lets it.
          const hold = (y0) => { if (!wide()) return; box.style.translate = ""; const r = box.getBoundingClientRect(); box.style.translate = `0 ${Math.round(Math.min(y0 - r.top, Math.max(0, innerHeight - 12 - r.bottom)))}px`; };
          let top0 = 0;
          gEl.addEventListener("focus", () => { top0 = box.getBoundingClientRect().top; drawGs(); gsEl.classList.add("on"); hold(top0); if (!RM()) gsEl.animate([{opacity: 0}, {opacity: 1}], {duration: 120, easing: "ease"}); });
          gEl.addEventListener("input", () => hold(top0));
          gEl.addEventListener("blur", () => { gsEl.classList.remove("on"); box.style.translate = ""; });
        }
        // Where the folder goes: the line opens a field for the place it is made in.
        const pinEl = q("[data-pin]"), ppick = q("[data-ppick]");
        if (parEl) {
          pinEl.value = parent;
          pv.onclick = (ev) => { if (!ev.target.closest("[data-atedit]")) return; parEl.hidden = !parEl.hidden; if (!parEl.hidden) { pinEl.focus(); pinEl.select(); } };
          pinEl.oninput = () => { parent = pinEl.value.trim().replace(/^"+|"+$/g, "").trim() || defRoot; later(); };
          if (ppick) ppick.onclick = async () => { let got = null; try { got = await sysPick()(parent); } catch (e) { /* no dialog */ }
            if (got) { pinEl.value = parent = String(got); later(); } else pinEl.focus(); };
        }
        [nameEl, f2El, gEl].forEach((i) => { if (!i) return; i.oninput = later;
          i.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } }); });
        q("[data-tmback]").onclick = () => { pseq++; clearTimeout(timer); write(); };
        go.onclick = make;
        sync(); preview();
        if (wide()) setTimeout(() => { if (nameEl.isConnected) { nameEl.focus({preventScroll: true}); if (!sug) nameEl.select(); } }, 60);
      };
      const write = () => {
        root.innerHTML = `<h3>${head}</h3>
          <textarea class="pj-ta2" data-tx rows="2" maxlength="400" placeholder="${esc(tl("room.tm.ph"))}" aria-label="${esc(tl("room.tm.ph"))}"></textarea>
          <div class="pj-tmr"><button type="button" class="pj-text press" data-self>${tl("room.tm.self")}</button><span class="sp"></span><button type="button" class="pj-btn light press" data-ask><span class="pj-spin" hidden></span><span data-l></span></button></div>`;
        fade();
        const tx = root.querySelector("[data-tx]"), go = root.querySelector("[data-ask]"), lab = go.querySelector("[data-l]"), spin = go.querySelector(".pj-spin");
        let busy = false;
        tx.value = text;
        const sync = () => { go.disabled = !busy && !tx.value.trim(); spin.hidden = !busy; lab.textContent = busy ? tl("libDraw.22") : tl("room.tm.next"); tx.readOnly = busy; go.setAttribute("aria-busy", busy); };
        const run = async () => {
          if (busy) { seq++; busy = false; return sync(); }      // a press while it waits takes the question back
          text = tx.value.trim();
          if (!text) return;
          const my = ++seq; busy = true; sync();
          let r = null;
          try { r = await post("/api/depts/propose", {text, kind}); } catch (e) { r = null; }
          if (my !== seq || !root.isConnected) return;
          card(r && r.proposal ? r.proposal : own(text), !!(r && r.suggested));
        };
        go.onclick = run;
        root.querySelector("[data-self]").onclick = () => { seq++; text = tx.value.trim(); card(own(text), null); };
        tx.oninput = sync;
        tx.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); if (!busy) run(); } };
        sync();
        if (wide()) setTimeout(() => { if (tx.isConnected) tx.focus({preventScroll: true}); }, 60);
      };
      write();
    });
  }

