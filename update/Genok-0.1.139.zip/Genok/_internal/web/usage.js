// 이번 주 사용량: the home card and the full screen. Part of the app core.
//
// Every number is an ESTIMATE made from the local Claude Code and Codex session logs
// (GET /api/usage[?agent=claude|codex]) unless it is a plan limit. The plan's weekly percentage
// is not fetched unless the person turns that on in the Claude limit row (claude_limit.py: the
// Claude Code login asks Anthropic's usage address and only the numbers are kept; u.limit).
// Otherwise what is shown as a limit comes from files on this PC only (usage.py): Codex's own
// numbers in its session log, Claude's from a status line that saves them, and a Claude window
// the account ran into (a refused request is logged with its reset time). A personal extension
// may supply the real weekly % through the overlay hook below. Reading the logs asks first - the
// API answers with a consent dialog, and until it is allowed both the card and the screen show
// one quiet state line with a single neutral button.
//
// Minimal by rule: one title and at most one sub line per section, "estimated" said once at the
// foot, nothing listed that has nothing to say (no advice row without advice), and the lists
// that repeat the same shares (계정별, 대화별) start folded.
//
// Loading never blanks the screen. The first open shows one small loader and resolves within
// TIMEOUT to numbers or to an honest "can't load right now" with a retry. After that: a refresh
// keeps what is shown until the new numbers are in, a tab press moves the pick at once and
// paints from what is already known (the other tabs are fetched ahead), and only a section still
// waiting shows its own small loader in place.
//
// Overlay hook (personal extensions only): window.LOOP_USAGE_OVERLAYS.push(async () => data)
// with data = {enabled, rate:{seven_day:{pct,resets_at}, five_hour, more, stale, why}, pace,
// tightest, window_start, account, accounts:[{id, rate, pace, account}]}. Overlays run after the
// estimate is painted and are laid over it when they answer; absent, disabled, slow or failing
// ones are ignored and the estimate stands alone.
//
// Class names are all prefixed uz-: the app's own stylesheet has bare .top/.num/.tr rules that
// leak into anything unprefixed.
//
// Attaches through the extension hooks (web/tabs.js):
//   window.LOOP_TABS.push({id, label, icon, draw(el)})
//   window.LOOP_HOME_CARDS.push({id, title, draw(el)})
// App globals: esc, ic, tl, loopFetch (consent.js), pname/gpname/projects/identFace (v2.js).
(function () {
  "use strict";
  // Inline copy in two languages (these extension files carry their own text, not i18n keys).
  const L = (ko, en) => (window.I18N_LANG === "en" ? en : ko);
  if (window.__usageCore) return;                      // one registration, whatever the load order
  window.__usageCore = true;

  const _esc = typeof esc === "function" ? esc : (s) => String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const en = () => (typeof LANG === "function" ? LANG() : "ko") === "en";
  // A folder Codex or a browser tool named after a URL ("https-markloop-io-https-markloop-io")
  // reads as the site it stands for.
  const tidy = (s) => {
    if (!/^https?-/.test(s)) return s;
    const parts = [...new Set(s.split(/https?-/).map((x) => x.replace(/-+$/, "")).filter(Boolean))];
    return parts.join(" · ").replace(/-(io|com|net|org|app|dev|ai|kr|co)(?![a-z0-9])/g, ".$1") || s;
  };
  // What a project (or a group) is called on screen: the display name a person gave it (v2.js).
  const _pn = (n) => tidy(String(n === "기타" ? tl("uz.other") : typeof pname === "function" ? pname(n) : n));
  const _gn = (g) => (g === "기타" ? tl("uz.other") : typeof gpname === "function" ? gpname(g) : g);
  const chev = ic("chev");

  const md = (t) => { const x = new Date(t * 1000); return `${x.getMonth() + 1}/${x.getDate()}`; };
  // Never round a part up to a full "100%" while something else holds the rest (99.7 + 0.3).
  const pct = (share) => { const v = share * 100; return v < 10 || (v > 99 && v < 99.95) ? `${v.toFixed(1)}%` : `${Math.round(v)}%`; };
  const wan = (n) => (en() ? `${Math.round(n / 1000)}K` : `${Math.round(n / 10000)}만`);

  // Colour follows the business group, by rank, from a small muted set.
  const PALETTE = ["#6f7bd6", "#4c93e0", "#3aa683", "#c9963a", "#cf6a8e", "#d0744a", "#9a90e0", "#3aa7b2"];
  const OTHER = "#6b6b6b";
  const AGENT = { claude: { name: "Claude", color: "#c9805a" }, codex: { name: "Codex", color: "#5b9bd5" } };
  function groupSummary(depts) {
    const by = new Map();
    for (const d of depts || []) by.set(d.group || "기타", (by.get(d.group || "기타") || 0) + d.share);
    const rows = [...by.entries()].filter(([, s]) => s > 0).sort((a, b) => b[1] - a[1]);
    let i = 0;
    return rows.map(([name, share]) => ({ name, share, color: name === "기타" ? OTHER : PALETTE[i++ % PALETTE.length] }));
  }
  const colorOf = (group, groups) => (groups.find((g) => g.name === (group || "기타")) || { color: OTHER }).color;
  // A project's own face, the one the sidebar and the chat list show (its icon or emoji); a
  // project without one keeps its group's colour dot.
  function face(name, color) {
    let icon = "";
    try {
      const g = typeof projects === "function" ? projects().find((p) => p.name === name) : null;
      icon = (g && g.icon) || "";
      if ((icon || (D.ident && D.ident[name] && D.ident[name].icon)) && typeof identFace === "function") {
        const h = identFace(name, icon);
        if (h) return `<span class="uz-face" aria-hidden="true">${h}</span>`;
      }
    } catch (e) { /* the app's lists are not there (a bare page): the dot stands in */ }
    return `<i class="uz-sw" style="background:${_esc(color || OTHER)}"></i>`;
  }
  // An account is shown by its label; the built-in ones by their agent; a folder name last.
  const acctName = (a) => a.label
    || (a.id === "default" ? tl("uz.acct.claude") : a.id === "codex" ? tl("uz.acct.codex") : null)
    || (a.account && a.account.folder && a.account.folder.split(/[\\/]/).filter(Boolean).pop()) || a.id;
  const MODEL = { opus: "Opus", sonnet: "Sonnet", haiku: "Haiku", fable: "Fable" };
  // A set agent model may be a full id ("claude-sonnet-4-6"): show its family name.
  const setName = (m) => { const k = Object.keys(MODEL).find((x) => String(m).toLowerCase().includes(x)); return k ? MODEL[k] : m; };
  const kindOf = (a) => (a.kind === "codex" ? "codex" : "claude");
  // The 스위치 extension (loop_ext/controls) owns the agent-model switch; link to it only when installed.
  const hasSwitch = () => (typeof window.loopTabs === "function" ? window.loopTabs() : window.LOOP_TABS || []).some((t) => t && t.id === "controls");

  const WHY = {
    long: (n) => [tl("uz.long", { n: wan(n) }), tl("uz.why.long.d", { n: wan(n) })],
    rebuild: (n) => [tl("uz.why.rebuild", { n }), tl("uz.why.rebuild.d")],
    agents: (n) => [tl("uz.why.agents", { n: Math.round(n * 100) }), tl("uz.why.agents.d")],
  };

  const CSS = `
.uz{color:var(--t1);font-variant-numeric:tabular-nums;--uz-spring:cubic-bezier(.34,1.4,.64,1)}
.uz *{box-sizing:border-box}
.uz-cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px;align-items:start}
.uz-cols>div{min-width:0}
.uz-panel{background:var(--card);border-radius:var(--r-card,12px);margin-bottom:12px;overflow:hidden}
.uz-cols>div>.uz-panel:last-child{margin-bottom:0}
.uz-sec{border-top:1px solid var(--line)}
.uz-panel>.uz-sec:first-child{border-top:0}
.uz-sh{display:flex;align-items:center;gap:8px;width:100%;min-height:44px;padding:0 16px;text-align:left;color:var(--t3);cursor:pointer}
.uz-sh:hover{color:var(--t2)}
.uz-sh .l{flex:1;min-width:0;font-size:12px;font-weight:700;letter-spacing:.07em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.uz-sh .n{font-size:12px;font-weight:500;letter-spacing:0;color:var(--t3)}
.uz-sh .uz-cv{flex:none;display:grid;place-items:center;width:20px;height:20px;transition:transform .5s var(--uz-spring)}
.uz-sh .uz-cv svg{width:16px;height:16px;transform:rotate(90deg)}
.uz-sec.shut .uz-sh .uz-cv{transform:rotate(-90deg)}
.uz-sb{display:grid;grid-template-rows:1fr;transition:grid-template-rows .5s var(--uz-spring),opacity .25s ease}
.uz-sb>div{overflow:hidden;min-height:0}
.uz-sec.shut .uz-sb{grid-template-rows:0fr;opacity:0}
.uz-bd{padding:2px 16px 16px}
.uz-line{margin:0;font-size:13px;line-height:1.5;color:var(--t2)}
.uz-line b{color:var(--t1);font-weight:600}
.uz-mut{margin:6px 0 0;font-size:12px;line-height:1.5;color:var(--t3)}
.uz-mut b{color:var(--t2);font-weight:600}
.uz-btn{display:block;width:100%;height:38px;margin-top:12px;border-radius:8px;background:var(--btn-hi,#323232);color:var(--t1);font-size:14px;font-weight:600}
.uz-askb{display:flex;gap:8px}.uz-askb .uz-btn{flex:1}.uz-btn.weak{flex:none;width:auto;padding:0 16px;background:none;color:var(--t2);font-weight:500;white-space:nowrap}
.uz-btn:hover{background:var(--card-hi);filter:brightness(1.25)}
.uz-btn:active{transform:scale(.985)}
.uz-hero{padding:0 16px 4px}
.uz-hero .uz-leg{padding:0}
.uz-leg{list-style:none;margin:12px 0 0;padding:0 16px;display:flex;flex-wrap:wrap;gap:6px 16px;font-size:12px}
.uz-leg li{display:inline-flex;align-items:center;gap:6px;min-width:0}
.uz-leg .g{color:var(--t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:140px}
.uz-leg .v{color:var(--t1);font-weight:600}
.uz-home{padding-bottom:16px}
.uz-home .uz-bd{padding-top:0}
.uz-sw{width:8px;height:8px;border-radius:50%;flex:none;display:inline-block}
.uz-face{flex:none;display:inline-grid;place-items:center;width:20px;height:20px;font-size:15px;line-height:1;color:var(--t2)}
.uz-face svg,.uz-face img{width:18px;height:18px}
.uz-row{display:grid;grid-template-columns:minmax(0,132px) minmax(0,1fr) 48px;align-items:center;gap:8px;min-height:32px;font-size:13px}
.uz-row>span:first-child{display:flex;align-items:center;gap:8px;min-width:0;color:var(--t2)}
.uz-row>span:first-child>em{font-style:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.uz-tr{height:6px;border-radius:99px;background:var(--btn);overflow:hidden;display:flex}
.uz-tr i{display:block;height:100%;transform-origin:left;transition:transform .7s var(--uz-spring)}
.uz-n{text-align:right;color:var(--t2)}
.uz-hd{display:flex;align-items:center;gap:8px;min-width:0}
.uz-hd b{flex:1;min-width:0;font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.uz-hd .uz-n{flex:none;font-size:13px}
.uz-ac,.uz-ses,.uz-tip{padding:8px 0;border-top:1px solid var(--line)}
.uz-ac:first-child,.uz-ses:first-child,.uz-tip:first-child{border-top:0;padding-top:2px}
.uz-ac .uz-tr,.uz-ses .uz-tr{height:5px;margin-top:8px}
.uz-ses small{display:block;margin-top:2px;font-size:12px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.uz-pill{display:inline-block;font-style:normal;font-size:12px;font-weight:600;color:var(--t2);background:var(--btn);padding:1px 8px;border-radius:99px;margin-left:6px;vertical-align:1px}
.uz-tip summary{list-style:none;cursor:pointer;display:block}
.uz-tip summary::-webkit-details-marker{display:none}
.uz-tip summary .uz-mut{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:4px}
.uz-tip[open] summary .uz-mut{white-space:normal}
.uz-tip .uz-more{margin-top:6px}
.uz-tip .uz-more .uz-mut{margin-top:4px}
.uz-seg{display:flex;background:var(--btn);border-radius:99px;padding:4px;gap:2px;overflow-x:auto;overflow-y:hidden;scrollbar-width:none;margin:0 16px 8px}
.uz-seg::-webkit-scrollbar{display:none}
#view>.uz-still{animation:none}
.uz-seg button{height:28px;padding:0 12px;border-radius:99px;font-size:12px;font-weight:600;color:var(--t3);white-space:nowrap;flex:none}
.uz-seg button.on{background:var(--btn-hi);color:var(--t1)}
.uz-seg.uz-main{margin:0 0 12px}
.uz-seg.uz-main button{flex:1;height:32px}
.uz-chart svg{width:100%;height:96px;display:block}
.uz-ax{display:flex;justify-content:space-between;font-size:12px;color:var(--t3);padding-top:4px}
.uz-load{padding:16px}
.uz-state{display:grid;place-content:center;justify-items:center;gap:16px;min-height:min(48vh,360px);padding:16px;text-align:center;color:var(--t3);font-size:14px;line-height:1.5}
.uz-state .btn{box-shadow:inset 0 0 0 1px var(--line)}
@media(pointer:coarse){.uz-state .btn{min-height:44px}}
.uz-wait{min-height:28px;padding:4px 0}
.uz-foot{margin:8px 4px 0;font-size:12px;line-height:1.5;color:var(--t3)}
.uz-sh .sm{flex:none;font-size:12px;font-weight:500;letter-spacing:0;color:var(--t3);white-space:nowrap}
.uz-alert{display:flex;align-items:flex-start;gap:8px;margin:0 0 12px;padding:8px 16px;border-radius:var(--r-card,12px);background:color-mix(in srgb,#d0744a 14%,var(--card));color:var(--t1);font-size:13px;line-height:1.45}
.uz-alert i{flex:none;width:8px;height:8px;margin-top:6px;border-radius:50%;background:#d0744a}
.uz-alert b{font-weight:600}
.uz-who{margin:0 0 6px;font-size:12px;color:var(--t3)}
.uz-who b{color:var(--t2);font-weight:600}
.uz-fig{display:flex;align-items:baseline;gap:8px;min-width:0}
.uz-fig .v{font-size:38px;font-weight:700;letter-spacing:-.03em;line-height:1.05}
.uz-fig .v small{font-size:19px;font-weight:600;color:var(--t2);margin-left:1px}
.uz-fig .s{flex:1;min-width:0;font-size:12px;line-height:1.4;color:var(--t3)}
.uz-fig .s b{color:var(--t1);font-weight:600}
.uz-gauge{position:relative;height:8px;margin:12px 0 0;border-radius:99px;background:var(--btn)}
html[data-theme="light"] :is(.uz-gauge,.uz-tr):not(:is(#k3l,#k3r,#tabbar,.setmodal,.d2-hero-card,.d2-stacked-item,.d2-card-peek) *){background:rgba(0,0,0,.08)}
.uz-hero>.uz-gauge:first-child{margin-top:4px}
.uz-gauge>div{display:flex;gap:2px;height:100%;border-radius:99px;overflow:hidden;transform-origin:left;transition:width .7s var(--uz-spring)}
.uz-gauge>div>i{display:block;height:100%;min-width:2px}
.uz-gauge>b{position:absolute;top:-3px;bottom:-3px;width:2px;margin-left:-1px;border-radius:1px;background:var(--t2)}
.uz-verdict{display:flex;align-items:center;gap:8px;margin:8px 0 0;font-size:13px;line-height:1.4;color:var(--t2)}
.uz-verdict .d{flex:none;width:8px;height:8px;border-radius:50%;background:#3aa683}
.uz-verdict[data-l=warning] .d{background:#c9963a}
.uz-verdict[data-l=serious] .d{background:#d0744a}
.uz-verdict[data-l=critical] .d{background:#d45a5a}
.uz-h5{display:grid;grid-template-columns:auto minmax(0,1fr) 40px;align-items:center;gap:8px;margin-top:16px;font-size:13px;color:var(--t2)}
.uz-h5 .n{text-align:right;color:var(--t1);font-weight:600}
.uz-h5 small{grid-column:1/-1;margin-top:-4px;font-size:12px;color:var(--t3)}
.uz-tag2{font-style:normal;font-size:12px;font-weight:600;color:var(--t2);background:var(--btn);padding:1px 8px;border-radius:99px;margin-left:6px;vertical-align:1px}
.uz-tag2.tight{color:#e09a78}
.uz-hacc{list-style:none;margin:12px 0 0;padding:0 16px;font-size:13px}
.uz-hacc li{display:flex;align-items:center;gap:8px;min-height:28px;color:var(--t2)}
.uz-hacc .an{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.uz-hacc .av{color:var(--t1);font-weight:600}
.uz-legk{color:var(--t3)}
.uz-svc{padding:12px 0;border-top:1px solid var(--line)}
.uz-svc:first-child{border-top:0;padding-top:2px}
.uz-svc .uz-tr{margin-top:8px}
.uz-svc .uz-mut{margin-top:4px}
.uz-big{display:flex;align-items:center;gap:16px;margin:8px 0 0}
.uz-big .v{font-size:40px;font-weight:700;letter-spacing:-.03em;line-height:1;flex:none}
.uz-big .v small{font-size:16px;font-weight:600;color:var(--t2);margin-left:1px}
.uz-lk{flex:none;position:relative;min-height:24px;padding:0 2px;font-size:12px;color:var(--t3)}
.uz-lk::before{content:"";position:absolute;inset:-10px -8px}
.uz-lk:hover{color:var(--t1)}
.uz-svc .uz-btn{margin-top:8px}
.uz-nw{white-space:nowrap}
.uz-big .s{min-width:0;font-size:13px;line-height:1.5;color:var(--t3)}
@media (max-width:720px){.uz-cols{grid-template-columns:1fr}}
@media (max-width:420px){.uz-row{grid-template-columns:minmax(0,104px) minmax(0,1fr) 46px;gap:8px}}
@media (prefers-reduced-motion:reduce){
  .uz-sh .uz-cv,.uz-sb,.uz-tr i,.uz-gauge>div{transition:opacity .2s ease}
  .uz-sec.shut .uz-sh .uz-cv{transform:none}
}`;

  function injectCss() {
    if (document.getElementById("uz-style")) return;
    const s = document.createElement("style");
    s.id = "uz-style";
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  // ---- data ---------------------------------------------------------------------------------
  // Every read gives up after TIMEOUT and says so: a screen must never sit on a spinner. The
  // answer is ready-made on the server (usage.py builds it after each scan), so a slow one means
  // the app is busy or gone, and trying again is the right next step.
  const TIMEOUT = 8000;
  async function read(url) {
    const ac = typeof AbortController === "function" ? new AbortController() : null;
    const timer = setTimeout(() => ac && ac.abort(), TIMEOUT);
    try {
      const r = await fetch(url, { cache: "no-store", signal: ac ? ac.signal : undefined });
      const j = await r.json().catch(() => ({}));
      if (!r.ok && !j.need_consent) { const said = typeof j.error === "string" && /[가-힣]/.test(j.error);   // the server's own sentence, not an exception's name
        throw Object.assign(new Error(said ? j.error : tl("uz.fail")), { said }); }
      return j;
    } catch (e) {
      throw e && e.said ? e : new Error(tl("uz.fail"));
    } finally { clearTimeout(timer); }
  }
  // interactive=true opens the permission dialog when it is needed (the person came to this
  // screen on purpose); the home card only reads quietly and shows the state line instead.
  // onAsk runs when the dialog is about to open, so the screen under it stops looking busy.
  async function fetchUsage(interactive, agent, onAsk) {
    const url = "/api/usage" + (agent && agent !== "all" ? `?agent=${agent}` : "");
    // Home draws its cards more than once on load: ask once per 20s, not four to six times
    // (each unconsented ask is a 428 in the console).
    const hit = interactive ? null : quietMemo.get(url);
    let p = hit && Date.now() - hit.at < 20000 ? hit.p : null;
    if (!p) {
      p = read(url);
      quietMemo.set(url, { at: Date.now(), p });
      p.catch(() => quietMemo.delete(url));
    }
    const j = await p;
    if (j.warming) quietMemo.delete(url);               // not an answer yet: ask again next time
    // The title-bar lamps (web/connuse.js) show the same plan % and take every whole answer.
    if (!agent || agent === "all") { try { window.dispatchEvent(new CustomEvent("loop:usage", { detail: j })); } catch (e) { /* no listener */ } }
    if (j.need_consent && interactive && typeof loopFetch === "function") {
      quietMemo.clear();                                // consent may change the answer
      if (onAsk) onAsk();
      return loopFetch(url);
    }
    return j;
  }
  const quietMemo = new Map();
  // The lamps' own read: the quiet one (never the permission dialog), sharing the 20s memo above.
  window.LOOP_USAGE = { read: () => fetchUsage(false, null) };

  // The estimate first; the personal overlays (see the header) after it is on screen. Each is
  // given 3 seconds, may fail or answer {enabled:false}, and what the last one said is laid over
  // every later answer at once, so a repaint never drops the official number it already showed.
  let _off = null;
  async function loadUsage(interactive, agent, onOfficial, onAsk) {
    const u = await fetchUsage(interactive, agent, onAsk);
    if (!u || u.need_consent || u.declined || !u.ready) return u;
    if (_off) mergeOfficial(u, _off);
    const ovs = window.LOOP_USAGE_OVERLAYS || [];
    if (ovs.length) (async () => {
      let got = null;
      for (const ov of ovs) {
        try {
          const off = await Promise.race([Promise.resolve().then(ov), new Promise((_, no) => setTimeout(no, 3000))]);
          if (off && off.enabled && off.rate) got = off;
        } catch (e) { /* off, absent or slow: the estimate stands */ }
      }
      if (!got) return;
      const was = JSON.stringify(_off);
      _off = got;
      mergeOfficial(u, got);
      if (onOfficial && JSON.stringify(got) !== was) onOfficial(u);
    })();
    return u;
  }
  // Lay the official per-account plan numbers over the estimate, in place.
  function mergeOfficial(u, off) {
    if (!off || !off.enabled || !off.rate) return;
    if (u.limit && u.limit.rate && !u.limit.rate.stale) return;   // the app's own fresh reading wins
    u.rate = off.rate; u.claude_rate = off.rate; u.pace = off.pace; u.tightest = off.tightest; u.window_start = off.window_start || u.window_start;
    if (off.account) u.official_account = off.account;
    const by = {};
    (off.accounts || []).forEach((a) => { by[a.id] = a; });
    (u.accounts || []).forEach((a) => { const o = by[a.id]; if (o) { a.rate = o.rate; a.pace = o.pace; } });
  }

  const DAY = 86400, HOUR = 3600, H5_WARN = 80;
  const hourT = (h) => tl("home.act.hour", { h });
  const resetAt = (t) => { const d = new Date(t * 1000), wd = d.toLocaleDateString(en() ? "en-US" : "ko-KR", { weekday: "short" });
    return en() ? `${wd} ${d.getMonth() + 1}/${d.getDate()} ${hourT(d.getHours())}` : `${d.getMonth() + 1}/${d.getDate()}(${wd}) ${hourT(d.getHours())}`; };
  // What the number means right now: will this pace hold until the reset?
  function verdict(pctv, start, resetsAt) {
    const now = Date.now() / 1000, elapsed = Math.min(Math.max((now - start) / (7 * DAY), 0), 1);
    if (pctv >= 100) return { level: "critical", text: tl("uz.v.full"), elapsed };
    if (elapsed < 0.02 || pctv <= 0) return { level: "good", text: tl("uz.v.new"), elapsed };
    const full = now + (100 - pctv) / (pctv / (now - start));
    if (full < resetsAt) return { level: full - now < 24 * HOUR ? "critical" : "serious", text: tl("uz.v.hit", { t: resetAt(full) }), elapsed };
    const projected = Math.round(pctv / elapsed);
    return { level: projected > 85 ? "warning" : "good", text: tl("uz.v.end", { n: projected }), elapsed };
  }
  // A slice of the week as it reads next to the hero: points of the plan's limit when the real
  // weekly % is known, a plain share otherwise.
  let _wk = null;                                       // the official weekly window of the screen being painted
  const lim = (share) => (_wk ? `${(_wk.pct * share).toFixed(1)}%p` : pct(share));

  const HIDE_KEY = "uz-home-hide";
  const homeHid = () => { try { return localStorage.getItem(HIDE_KEY) === "1"; } catch { return false; } };
  function askState(canHide) {
    return `<div class="uz-bd"><p class="uz-line">${more1(tl("uz.ask.1"), tl("uz.ask.2"), "uzask")}</p>
      <div class="uz-askb"><button class="uz-btn press" data-ask>${tl("uz.ask.ok")}</button>${canHide ? `<button class="uz-btn weak press" data-uzhide>${tl("uz.ask.hide")}</button>` : ""}</div></div>`;
  }
  // The whole-screen states stand in the middle, like the chat list's: one line, and the one thing to press.
  const firstRead = () => `<div class="uz-state">${tl("uz.first")}</div>`;
  const failState = (msg) => `<div class="uz-state uz-fail"><div>${_esc(msg || tl("uz.fail"))}</div><button class="btn press" data-retry>${tl("uz.retry")}</button></div>`;

  // section id -> folded, kept while the page lives. The two lists that say the same shares
  // again (per account, per conversation) start folded.
  const shut = { accts: true, sess: true };
  // `sub` is the small right-hand label; a `count` sits beside the title.
  function sec(id, label, count, body, sub) {
    return `<div class="uz-sec${shut[id] ? " shut" : ""}" data-sec="${id}">
      <button class="uz-sh press" aria-expanded="${shut[id] ? "false" : "true"}"><span class="l">${label}${count != null ? ` <span class="n">${count}</span>` : ""}</span>${sub ? `<span class="sm">${sub}</span>` : ""}<span class="uz-cv">${chev}</span></button>
      <div class="uz-sb"><div><div class="uz-bd">${body}</div></div></div></div>`;
  }
  // A section whose numbers are still on their way: its own small loader, in place.
  const waitSec = (id, label) => sec(id, label, null, `<div class="uz-wait" data-wait>${loadingHtml("", { quiet: true })}</div>`);
  function wireFold(root) {
    root.querySelectorAll(".uz-sh").forEach((b) => {
      b.addEventListener("click", () => {
        const s = b.closest(".uz-sec"), id = s.dataset.sec;
        shut[id] = !shut[id];
        s.classList.toggle("shut", shut[id]);
        b.setAttribute("aria-expanded", shut[id] ? "false" : "true");
      });
    });
  }

  // ---- hero: the weekly limit (official) or the last 7 days by share (estimate) --------------
  const acctLine = (u) => {
    const a = u.official_account, multi = (u.accounts || []).filter((x) => kindOf(x) === "claude").length > 1;
    const t = multi ? (u.accounts || []).find((x) => x.id === u.tightest) : null;
    const bits = [t ? `<b>${_esc(acctName(t))}</b> · ${tl("uz.tightest")}` : "", a && a.email ? _esc(a.email) : "", a && a.plan ? _esc(a.plan) : ""].filter(Boolean);
    return bits.length ? `<p class="uz-who">${bits.join(" · ")}</p>` : "";
  };
  // The stacked meter by business group. With the official % the coloured part is only as long as
  // the share of the limit used, and a tick marks how far into the week it is.
  function gauge(groups, wk, v) {
    const fill = wk ? Math.min(Math.max(Number(wk.pct), 0), 100) : 100;
    return `<div class="uz-gauge" role="img" aria-label="${wk ? tl("uz.aria.used", { n: Math.round(wk.pct) }) : tl("uz.aria.groups")}">
      <div style="width:${wk ? Math.max(fill, 1.5) : 100}%">${groups.length ? groups.map((g) => `<i style="flex:${g.share};background:${g.color}" title="${_esc(_gn(g.name))} ${lim(g.share)}"></i>`).join("") : `<i style="flex:1;background:var(--btn-hi)"></i>`}</div>
      ${v ? `<b style="left:${v.elapsed * 100}%" title="${tl("uz.elapsed", { n: Math.round(v.elapsed * 100) })}"></b>` : ""}</div>`;
  }
  const legend = (groups, n) => `<ul class="uz-leg">${groups.slice(0, n).map((g) => `<li><span class="uz-sw" style="background:${g.color}"></span><span class="g">${_esc(_gn(g.name))}</span><span class="v">${lim(g.share)}</span></li>`).join("")}</ul>`;
  const agentLeg = (u) => {
    const ag = Object.entries(u.agents || {}).filter(([, v]) => v > 0.0005).sort((a, b) => b[1] - a[1]);
    return ag.length > 1 ? `<ul class="uz-leg" style="margin-top:8px;padding:0">${ag.map(([k, v]) => `<li>${AGENT[k] ? agDot(k) : `<span class="uz-sw" style="background:${OTHER}"></span>`}<span class="g">${(AGENT[k] || { name: k }).name}</span><span class="v">${pct(v)}</span></li>`).join("")}</ul>` : "";
  };
  const h5Row = (five) => five ? `<div class="uz-h5"><span>${tl("uz.h5")}</span><span class="uz-tr"><i style="width:${Math.min(Number(five.pct), 100)}%;background:${five.pct >= H5_WARN ? "#d0744a" : "#4c93e0"}"></i></span><span class="n">${Math.round(five.pct)}%</span>
      <small>${tl("uz.h5.free", { h: new Date(five.resets_at * 1000).getHours() })}</small></div>` : "";
  const LIMIT_T = () => ({ seven_day_opus: tl("uz.lim.opus"), seven_day_sonnet: tl("uz.lim.sonnet") });

  // The hero body, shared by the home card and the screen's first section. Without an official
  // number it is only the meter and its legend: the title above already says what it is.
  function heroBody(u, groups, full) {
    const wk = _wk, five = u.rate && u.rate.five_hour, v = wk ? verdict(Number(wk.pct), u.window_start || wk.resets_at - 7 * DAY, wk.resets_at) : null;
    if (!wk) return `${gauge(groups, null, null)}${groups.length > 1 ? legend(groups, full ? 6 : 5) : ""}${agentLeg(u)}`;
    const stale = u.rate.stale ? ` · ${tl("uz.blocked")}${u.rate.why ? ` (${_esc(u.rate.why)})` : ""}` : "";
    const used = Math.min(Math.max(Math.round(wk.pct), 0), 100), T = LIMIT_T();
    const more = Object.entries(u.rate.more || {}).filter(([k, w]) => T[k] && w && w.pct != null)
      .map(([k, w]) => `<div class="uz-h5"><span>${T[k]}</span><span class="uz-tr"><i style="width:${Math.min(w.pct, 100)}%;background:#4c93e0"></i></span><span class="n">${Math.round(w.pct)}%</span></div>`).join("");
    return `${full ? acctLine(u) : ""}<div class="uz-fig"><span class="v">${used}<small>${tl("uz.used")}</small></span>
      <span class="s"><b>${tl("uz.left", { n: 100 - used })}</b> · ${tl("uz.reset", { t: resetAt(wk.resets_at) })}${stale}</span></div>
      ${gauge(groups, wk, v)}
      ${v ? `<div class="uz-verdict" data-l="${v.level}"><span class="d"></span><span>${u.pace && u.pace.hours ? paceText(u.pace) : v.text}</span></div>` : ""}
      ${legend(groups, full ? 6 : 5)}${h5Row(five)}${full ? more : ""}${agentLeg(u)}`;
  }
  const paceText = (p) => (p.full_at ? tl("uz.p.hit", { h: p.hours, t: resetAt(p.full_at) }) : tl("uz.p.end", { h: p.hours, n: p.end_pct }));
  const useOfficial = (u) => (u.rate && u.rate.seven_day && !u.rate.seven_day.hit && _agent !== "codex" ? u.rate.seven_day : null);

  // ---- 한도: one row per tool, saying only what is known about its plan limit ----------------
  // Used / left / reset come from the plan's own numbers (usage.py claude_rate, with_hits,
  // codex_rates). A window the account ran into is said as that - full until its reset. A tool
  // with nothing readable gets one plain line, never an invented number and never a badge.
  // The Claude row may also show the app's own reading (claude_limit.py, u.limit): off until the
  // person turns it on right here, with one line saying what is read and where it goes. Then:
  // loading, the numbers, the last numbers marked with their time when a refresh failed, or one
  // line saying why there are none (login needed, not possible on this device, could not ask).
  const asOf = (t) => { const d = new Date(t * 1000), hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
    return d.toDateString() === new Date().toDateString() ? hm : `${d.getMonth() + 1}/${d.getDate()} ${hm}`; };
  const agoText = (t) => { const m = Math.max(0, Math.floor((Date.now() / 1000 - t) / 60));
    return m < 1 ? tl("ago.2") : m < 60 ? tl("ago.3", { p0: m }) : m < 1440 ? tl("ago.4", { p0: Math.floor(m / 60) }) : tl("ago.5", { p0: Math.floor(m / 1440) }); };
  const limWhy = (lim) => (lim.state === "login" ? tl("uz.lim.login") : lim.state === "unavailable" ? tl("uz.lim.unavail")
    : lim.state === "error" ? tl("uz.lim.error") : tl("uz.lim.loading"));
  // A gateway's spend limit: its period when Claude Code knew it, and the dollars when it had them.
  const spendName = (sp) => (sp.period === "daily" ? tl("uz.spend.day") : sp.period === "weekly" ? tl("uz.spend.week")
    : sp.period === "monthly" ? tl("uz.spend.month") : tl("uz.spend"));
  const usd = (n) => "$" + Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const spendLine = (sp, main) => {
    if (!sp) return "";
    const money = sp.used_usd != null && sp.limit_usd != null ? tl("uz.spend.usd", { a: usd(sp.used_usd), b: usd(sp.limit_usd) }) : "";
    const bits = main === sp ? [money] : [`${spendName(sp)} ${Math.round(sp.pct)}%`, money, tl("uz.reset", { t: resetAt(sp.resets_at) })];
    return bits.some(Boolean) ? `<p class="uz-mut">${bits.filter(Boolean).join(" · ")}</p>` : "";
  };
  function svcSec(u) {
    const kinds = [...new Set((u.accounts || []).map(kindOf))];
    const lim = u.limit || null;
    const cl = (lim && lim.rate) || u.claude_rate || u.rate;
    const rows = ["claude", "codex"].filter((k) => kinds.includes(k) && (_agent === "all" || _agent === k)).map((k) => {
      const src = (k === "claude" ? cl : u.codex_rate) || {}, wk = src.seven_day || null, five = src.five_hour || null;
      const mine = k === "claude" && lim && !lim.store;   // the Store package has no switch
      const head = `<div class="uz-hd">${agDot(k)}<b>${AGENT[k].name}</b>${mine && lim.on ? `<button class="uz-lk press" data-limoff>${tl("uz.lim.stop")}</button>` : ""}</div>`;
      // Under the row: the switch while it is off, or why there is no number while it is on.
      const foot = !mine ? "" : !lim.on ? `<p class="uz-mut">${tl("uz.lim.off")}</p><button class="uz-btn press" data-limon>${tl("uz.lim.on")}</button>`
        : !lim.rate && lim.state !== "line" ? `<p class="uz-mut" data-limstate="${_esc(lim.state)}">${limWhy(lim)}</p>` : "";
      // The official way (rateline.py): Claude Code's own status line saves the numbers. Offered
      // first (the Store package has no other), only while there is no number; it can be turned
      // off from the row once on. Numbers appear after the next reply in a terminal session.
      const rl = k === "claude" && u.rateline && u.rateline.supported ? u.rateline : null;
      // Behind a gateway there is no plan window, only a spend limit (the status line's `spend_limit`).
      const spend = src.spend_limit || null;
      const hasNum = !!(wk || five || spend);
      const rlHead = rl && rl.on ? `<button class="uz-lk press" data-rloff>${tl("uz.rl.stop")}</button>` : "";
      const rlFoot = !rl || hasNum ? "" : !rl.on ? `<p class="uz-mut">${tl("uz.rl.off")}</p><button class="uz-btn press" data-rlon>${tl("uz.rl.on")}</button>`
        : `<p class="uz-mut" data-rlwait>${tl("uz.rl.wait")}</p>`;
      const head2 = rlHead ? head.replace("</div>", `${rlHead}</div>`) : head, foot2 = rlFoot + foot;
      const hit = wk && wk.hit ? ["uz.hit.7", wk] : five && five.hit ? ["uz.hit.5", five] : null;
      if (hit) return `<div class="uz-svc">${head2}<p class="uz-line">${hit[0] === "uz.hit.7" ? tl("uz.hit.7", { t: resetAt(hit[1].resets_at) }) : tl("uz.hit.5", { t: resetAt(hit[1].resets_at) })}</p>${foot2}</div>`;
      // The app's own reading may hold only the 5-hour window: then that one is the big number.
      const main = wk || (src.own ? five : null) || spend;
      if (!main) return `<div class="uz-svc">${head2}${foot2 || `<p class="uz-mut">${tl("uz.nolimit")}</p>`}</div>`;
      const used = Math.min(Math.max(Math.round(main.pct), 0), 100);
      // Every Claude number says how old it is (status line or the app's own reading), so a quiet one is not mistaken for a live one.
      const age = k === "claude" && src.updated && !src.stale ? ` · <span class="uz-nw">${agoText(src.updated)}</span>` : "";
      const old = age ? age : !src.stale ? "" : src.own && src.updated ? ` · <span class="uz-nw">${tl("uz.lim.asof", { t: asOf(src.updated) })}</span>` : ` · ${tl("uz.stale")}`;
      const rest = src.own && wk && five ? `<p class="uz-mut">${tl("uz.h5")} ${Math.round(five.pct)}% · ${tl("uz.h5.free", { h: new Date(five.resets_at * 1000).getHours() })}</p>`
        : src.own && wk && (src.lapsed || []).includes("five_hour") ? `<p class="uz-mut">${tl("uz.h5")} 0% · ${tl("connuse.lapsed")}</p>` : "";
      return `<div class="uz-svc">${head2}
        <div class="uz-big"><span class="v">${used}<small>%</small></span><span class="s">${main === wk ? "" : main === spend ? `${spendName(spend)} · ` : `${tl("uz.h5")} · `}${tl("uz.left", { n: 100 - used })} · ${tl("uz.reset", { t: resetAt(main.resets_at) })}${old}</span></div>
        <div class="uz-tr" role="img" aria-label="${tl("uz.aria.used", { n: used })}"><i style="width:${Math.max(used, 1.5)}%;background:${AGENT[k].color}"></i></div>${rest}${spendLine(spend, main)}${foot2}</div>`;
    });
    return rows.length ? sec("svc", tl("uz.sec.limit"), null, rows.join("")) : "";
  }
  // The switch: POST /api/usage/limit {on}. The answer is the new u.limit; every answer already
  // read gets it at once (and loses the app's own numbers when it went off), then the tab re-reads.
  async function limSwitch(on) {
    const r = await fetch("/api/usage/limit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on }) });
    const lim = await r.json();
    if (!r.ok || !lim || typeof lim.on !== "boolean") throw new Error(tl("uz.fail"));
    quietMemo.clear(); homeMemo = null;
    Object.values(tabMemo).forEach((m) => {
      m.limit = lim;
      if (lim.rate) return;
      ["rate", "claude_rate"].forEach((k) => { if (m[k] && m[k].own) m[k] = null; });
      (m.accounts || []).forEach((a) => { if (a.rate && a.rate.own) a.rate = null; });
    });
    return lim;
  }

  // The status-line switch: POST /api/usage/rateline (asks first through loopFetch's dialog) or
  // /api/usage/rateline-off. Resolves with the new u.rateline, or null when the person said "later".
  async function rlSwitch(on) {
    const j = await window.loopFetch(on ? "/api/usage/rateline" : "/api/usage/rateline-off", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    if (j.declined) return null;
    if (on && j.result !== "written") throw new Error(j.result === "unreadable" ? tl("uz.rl.unreadable") : tl("uz.rl.fail"));
    const rl = { on: !!j.on, supported: j.supported !== false, store: !!j.store };
    quietMemo.clear(); homeMemo = null;
    Object.values(tabMemo).forEach((m) => { m.rateline = rl; });
    return rl;
  }

  // ---- home card ----------------------------------------------------------------------------
  // The card already has its title ("이번 주 사용량") from the home screen: not repeated here.
  // Returns the promise so a refresh (v2.js holdWrites) keeps the old card until the new one is in.
  function drawHome(el) {
    injectCss();
    if (!el.querySelector(".uz")) el.innerHTML = `<div class="uz uz-home"><div class="uz-load">${loadingHtml("", { quiet: true })}</div></div>`;
    const again = (u) => { if (el.isConnected) paintHome(el, u, run); };
    const paint = (p) => p.then((u) => paintHome(el, u, run))
      .catch(() => { if (el.querySelector(".uz-load")) el.innerHTML = ""; });      // a failed refresh keeps the old card
    const run = (interactive) => paint(loadUsage(interactive, null, again));
    // Home draws its cards twice on boot: the first quiet read is shared for a few seconds.
    // Retries and the permission path (run) always ask again.
    if (!homeMemo || Date.now() - homeAt > 5000) {
      homeAt = Date.now();
      homeMemo = loadUsage(false, null, again);
      homeMemo.catch(() => { homeMemo = null; });
    }
    return paint(homeMemo);
  }
  let homeMemo = null, homeAt = 0;

  function paintHome(el, u, run) {
    if (u.need_consent || u.declined) {
      // Hidden here = "not using usage": the whole home card goes away. The 사용량 screen still asks.
      const card = el.closest(".homecard");
      if (homeHid()) { el.innerHTML = ""; if (card) card.hidden = true; return; }
      el.innerHTML = `<div class="uz uz-home">${askState(true)}</div>`;
      el.querySelector("[data-ask]").onclick = () => run(true);
      el.querySelector("[data-uzhide]").onclick = () => {
        try { localStorage.setItem(HIDE_KEY, "1"); } catch {}
        el.innerHTML = ""; if (card) card.hidden = true;
      };
      return;
    }
    { const card = el.closest(".homecard"); if (card) card.hidden = false; }
    if (u.warming) { setTimeout(() => { if (el.isConnected) run(false); }, 2000); return; }   // see drawTab
    const depts = u.depts || [], groups = groupSummary(depts);
    if (!depts.length) {
      el.innerHTML = `<div class="uz uz-home"><div class="uz-bd"><p class="uz-line">${u.ready ? tl("uz.none") : tl("uz.first")}</p></div></div>`;
      if (!u.ready) setTimeout(() => { if (el.isConnected) run(false); }, 6000);
      return;
    }
    _wk = u.rate && u.rate.seven_day && !u.rate.seven_day.hit ? u.rate.seven_day : null;
    const accts = (u.accounts || []).filter((a) => kindOf(a) === "claude");
    const val = (a) => (a.rate && a.rate.seven_day ? Math.round(a.rate.seven_day.pct) + "%" + (a.rate.stale ? ` · ${tl("uz.stale")}` : "") : a.share != null ? pct(a.share) : "—");
    el.innerHTML = `<div class="uz uz-home"><div class="uz-hero">${heroBody(u, groups, false)}</div>
      ${accts.length > 1 ? `<ul class="uz-hacc">${accts.map((a) => `<li><i class="uz-sw" style="background:${_esc(a.color)}"></i><span class="an">${_esc(acctName(a))}${_wk && a.id === u.tightest ? ` <em class="uz-tag2 tight">${tl("uz.tight")}</em>` : ""}</span><span class="av">${val(a)}</span></li>`).join("")}</ul>` : ""}
    </div>`;
  }

  // ---- full screen --------------------------------------------------------------------------
  let _el = null, _dayP = 0, _agent = "all";
  const tabMemo = {};                                   // agent -> the last answer, shown at once

  function drawTab(el) {
    injectCss();
    _el = el;
    const requested = ["claude", "codex"].includes(window.LOOP_USAGE_AGENT) ? window.LOOP_USAGE_AGENT : null;
    window.LOOP_USAGE_AGENT = null;
    if (requested) _agent = requested;
    // The screen shares one host element with every other screen: a late answer must not paint
    // over whatever the person moved on to, so it only writes while our own root is still there.
    const alive = () => _el === el && el.isConnected && el.firstElementChild && el.firstElementChild.classList.contains("uz");
    const first = () => !!el.querySelector(".uz-load, .uz-fail");      // nothing of ours shown yet
    // An overlay answered: lay it over whatever this tab shows now (a refresh may have replaced
    // the answer the overlay was started for).
    const official = () => { const m = tabMemo[_agent]; if (alive() && m && !first()) { mergeOfficial(m, _off); paintTab(el, m, load); } };
    const asking = () => { if (alive() && first()) { el.innerHTML = `<div class="uz"><div class="uz-load" style="padding:0">${firstRead()}</div></div>`; actSec(el); } };
    const load = () => { const ag = _agent; return loadUsage(true, ag, official, asking).then((u) => {
      if (u && u.ready) tabMemo[ag] = u;
      if (!alive() || ag !== _agent) return;            // a slower answer for a tab already left
      // The app is still summing its first answer (a few seconds after it starts): keep what is
      // shown and ask again shortly.
      if (u && u.warming) { clearTimeout(retryT); retryT = setTimeout(() => { if (alive()) load(); }, 1500); return; }
      paintTab(el, u, load);
      // The limit switch is on and its first answer is still on its way (a few seconds at most):
      // look again shortly, and once more after it lands so the week above follows it.
      const ls = u && u.limit && u.limit.on ? u.limit.state : "";
      if (ls === "loading" ? limTries++ < 8 : limTries > 0 && !(limTries = 0)) { clearTimeout(retryT); retryT = setTimeout(() => { if (alive()) load(); }, 2000); }
      if (u && u.ready) ahead(u);
    }).catch((e) => {
      if (!alive() || ag !== _agent) return;
      if (first()) return fail(e);                      // nothing shown yet: say so, with a retry
      // Numbers are on screen: a failed refresh keeps them. Only a section still waiting for
      // this tab says it could not load.
      el.querySelectorAll("[data-wait]").forEach((w) => { w.removeAttribute("data-wait"); w.innerHTML = `<p class="uz-mut">${tl("uz.fail")} <button class="lnk press" data-retry>${tl("uz.retry")}</button></p>`; });
      wireRetry();
    }); };
    let retryT = 0, limTries = 0;
    const wireRetry = () => el.querySelectorAll("[data-retry]").forEach((b) => { b.onclick = () => { clearTimeout(retryT); b.disabled = true; load(); }; });
    const fail = (e) => {
      el.innerHTML = `<div class="uz">${failState(e && e.message)}</div>`;
      actSec(el);
      wireRetry();
      // Tries again by itself while this state is still what is shown.
      clearTimeout(retryT);
      retryT = setTimeout(() => { if (alive() && el.querySelector(".uz-fail")) load(); }, TIMEOUT);
    };
    // The other tabs' answers, fetched once the first is on screen, so a tab press paints at once.
    const ahead = (u) => {
      const kinds = [...new Set((u.accounts || []).map(kindOf))];
      if (kinds.length < 2) return;
      ["all", ...kinds].filter((k) => k !== _agent).forEach((k) => {
        fetchUsage(false, k).then((x) => { if (x && x.ready) { if (_off) mergeOfficial(x, _off); tabMemo[k] = x; } }).catch(() => {});
      });
    };
    if (requested && el.querySelector(".uz") && (tabMemo[_agent] || tabMemo.all)) {
      paintTab(el, tabMemo[_agent] || {...tabMemo.all, _wait: true}, load);
    }
    if (!el.querySelector(".uz")) {
      // A fresh open starts on today; a refresh keeps the pick of the day and what is shown.
      _dayP = 0;
      if (tabMemo[_agent]) paintTab(el, tabMemo[_agent], load);
      else { el.innerHTML = `<div class="uz"><div class="uz-panel uz-load">${loadingHtml("", { quiet: true })}</div></div>`; actSec(el); }
    }
    return load();
  }

  // The banner the hub leads with: the 5h window nearly full, else a chat that is wasting right now.
  function alertHTML(u) {
    const h5 = u.rate && u.rate.five_hour;
    if (h5 && !h5.hit && h5.pct >= H5_WARN && h5.resets_at * 1000 > Date.now())
      return `<div class="uz-alert"><i></i><span>${tl("uz.alert.h5", { n: Math.round(h5.pct), h: new Date(h5.resets_at * 1000).getHours() })}</span></div>`;
    const f = (u.waste || []).find((x) => x.alert);
    return f ? `<div class="uz-alert"><i></i><span>${tl("uz.alert.leak", { v: lim(f.cost) }).replace("{d}", _esc(_pn(f.dept)))}</span></div>` : "";
  }

  function paintTab(el, u, reload) {
    paintTab0(el, u, reload);
    actSec(el);
    // Came from the lamps' card ("사용량에서 켜기"): land on the switch, or on the permission question.
    if (window.LOOP_USAGE_FOCUS === "limit") {
      const b = el.querySelector("[data-limon],[data-ask]");
      window.LOOP_USAGE_FOCUS = null;
      if (b) { b.scrollIntoView({ block: "center" }); b.focus({ preventScroll: true }); }
    }
  }
  // The activity block (v2.js): Genok's own counts need no grant, so it follows every state of
  // this screen - loading and a failed load too.
  function actSec(el) { try { if (window.LOOP_ACT_SEC) window.LOOP_ACT_SEC(el.querySelector(".uz")); } catch (e) {} }
  function paintTab0(el, u, reload) {
    if (u.need_consent || u.declined) {
      el.innerHTML = `<div class="uz"><div class="uz-panel">${askState()}</div></div>`;
      el.querySelector("[data-ask]").onclick = () => { try { localStorage.removeItem(HIDE_KEY); } catch {} reload(); };
      return;
    }
    if (!u.ready) {
      el.innerHTML = `<div class="uz">${firstRead()}</div>`;
      setTimeout(() => { if (_el === el && el.isConnected && el.firstElementChild && el.firstElementChild.classList.contains("uz") && !el.querySelector(".uz-cols")) reload(); }, 6000);
      return;
    }
    const kinds = [...new Set([...(u.accounts || []).map(kindOf), ...(_agent === "all" ? [] : [_agent])])];
    if (!kinds.includes(_agent)) _agent = "all";
    _wk = useOfficial(u);
    const groups = groupSummary(u.depts);
    const wait = !!u._wait;                             // this tab's own numbers are still coming
    const left = wait ? [svcSec(u), acctSec(u), waitSec("hero", tl("uz.sec.week7")), waitSec("dept", tl("uz.sec.dept"))]
      : [svcSec(u), acctSec(u), heroSec(u, groups), sinceSec(u), deptSec(u, groups)];
    const right = wait ? [waitSec("sess", tl("uz.sec.sess")), waitSec("day", tl("uz.sec.day"))]
      : [wasteSec(u), _agent === "codex" ? "" : modelSec(u), sessionSec(u, groups), daySec(u, groups)];
    const panel = (parts) => `<div class="uz-panel">${parts.filter(Boolean).join("")}</div>`;
    const tabs = kinds.length > 1 ? `<div class="uz-seg uz-main" role="tablist">${[["all", tl("uz.tab.all")], ["claude", "Claude"], ["codex", "Codex"]]
      .filter(([k]) => k === "all" || kinds.includes(k))
      .map(([k, n]) => `<button class="press ${k === _agent ? "on" : ""}" role="tab" aria-selected="${k === _agent}" data-agent="${k}">${k === "all" ? "" : agDot(k)}${n}</button>`).join("")}</div>` : "";
    // Lab only: the limits as one row of cards, the way the kit shows quotas.
    const rate = () => (u.limit && u.limit.rate) || u.claude_rate || u.rate || {};
    const limCard = (name, label, r) => (r && r.pct != null ? `<div class="uz-lim" data-ag="${name.toLowerCase()}" style="--p:${Math.min(100, Math.max(0, Math.round(r.pct)))}"><span class="k">${name} · ${label}</span><b class="num">${Math.round(r.pct)}<small>%</small></b><i class="bar"><i style="width:${Math.min(100, Math.max(0, Math.round(r.pct)))}%"></i></i><span class="s">${tl("uz.left", { n: Math.max(0, 100 - Math.round(r.pct)) })}${r.resets_at ? ` · ${tl("uz.reset", { t: resetAt(r.resets_at) })}` : ""}</span></div>` : "");
    const lims = document.documentElement.classList.contains("lab") && !wait
      ? [limCard("Claude", tl("uz.h5"), rate().five_hour), limCard("Claude", tl("uz.sec.week7"), rate().seven_day), limCard("Codex", tl("uz.h5"), (u.codex_rate || {}).five_hour), limCard("Codex", tl("uz.sec.week7"), (u.codex_rate || {}).seven_day)].filter(Boolean).join("") : "";
    // Painting over numbers already on screen (a tab, a refresh) is not an arrival: no entrance fade.
    el.innerHTML = `<div class="uz${el.querySelector(".uz-cols") ? " uz-still" : ""}">
      ${alertHTML(u)}
      ${tabs}
      ${lims ? `<div class="uz-lims">${lims}</div>` : ""}
      <div class="uz-cols"><div>${panel(left)}</div><div>${panel(right)}</div></div>
      <p class="uz-foot">${tl("uz.est")}${u.once ? ` · ${tl("uz.once")}` : ""}</p></div>`;
    wireFold(el);
    el.querySelectorAll("[data-agent]").forEach((b) => b.addEventListener("click", () => {
      if (_agent === b.dataset.agent) return;
      _agent = b.dataset.agent;
      // The pick moves now. What was last read for that tab shows at once; without it, the parts
      // every tab shares (the limits, the accounts) do, and each section still waiting shows its
      // own small loader until the answer lands. Nothing blanks and nothing fades.
      paintTab(el, tabMemo[_agent] || { ...(tabMemo.all || u), _wait: true }, reload);
      const on = el.querySelector(`[data-agent="${_agent}"]`); if (on) on.focus();
      reload();
    }));
    el.querySelectorAll("[data-rlon],[data-rloff]").forEach((b) => b.addEventListener("click", () => {
      b.disabled = true;
      rlSwitch(b.hasAttribute("data-rlon")).then((rl) => {
        if (!rl || !(_el === el && el.isConnected)) { b.disabled = false; return; }
        paintTab(el, tabMemo[_agent] || { ...u, rateline: rl }, reload);
        reload();
      }).catch((e) => { b.disabled = false; if (window.toast) toast(e.message || tl("uz.fail")); });
    }));
    el.querySelectorAll("[data-limon],[data-limoff]").forEach((b) => b.addEventListener("click", () => {
      b.disabled = true;
      limSwitch(b.hasAttribute("data-limon")).then((lim) => {
        if (!(_el === el && el.isConnected)) return;
        paintTab(el, tabMemo[_agent] || { ...u, limit: lim }, reload);
        reload();
      }).catch(() => { b.disabled = false; });
    }));
    // 모델 조언 → 스위치: the write stays in the controls extension (its own consent + confirm).
    el.querySelectorAll("[data-uzswitch]").forEach((b) => b.addEventListener("click", () => { location.hash = "controls"; }));
    const day = el.querySelector("#uz-day");
    if (day) day.addEventListener("click", (e) => {
      const b = e.target.closest("[data-v]");
      if (!b) return;
      _dayP = +b.dataset.v;
      day.innerHTML = dayBody(u, groups);
    });
  }

  // 이번 주 한도 (official) / 최근 7일 (estimate): the hero.
  function heroSec(u, groups) {
    return _wk ? sec("hero", tl("uz.sec.week"), null, `<div class="uz-hero" style="padding:0">${heroBody(u, groups, true)}</div>`, tl("uz.official"))
      : sec("hero", tl("uz.sec.week7"), null, `<div class="uz-hero" style="padding:0">${heroBody(u, groups, true)}</div>`);
  }

  // The week since the reset, day by day, as parts of the weekly %. Official only.
  const dayName = (d) => (d.day === 0 ? tl("uz.today") : d.day === 1 ? tl("uz.yday") : `${+d.date.slice(5, 7)}/${+d.date.slice(8)}`);
  function sinceSec(u) {
    const wk = _wk, ds = (u.daily || []).slice().reverse(), T = ds.reduce((a, d) => a + d.total, 0);
    if (!wk || !ds.length || !T) return "";
    const rows = ds.map((d) => ({ d, v: wk.pct * d.total / T })), mx = Math.max(...rows.map((r) => r.v), 0.1);
    const f = (v) => (v < 10 ? v.toFixed(1) : Math.round(v));
    const now = Date.now() / 1000, gone = Math.max((now - (wk.resets_at - 7 * DAY)) / DAY, 1 / 24), left = Math.max((wk.resets_at - now) / DAY, 1 / 24);
    const per = Math.max(100 - wk.pct, 0) / left;
    const dur = gone >= 1 ? tl("uz.dur.dh", { d: Math.floor(gone), h: Math.round((gone % 1) * 24) }) : tl("uz.dur.h", { h: Math.round(gone * 24) });
    return sec("since", tl("uz.sec.since"), rows.length, rows.map(({ d, v }) => `<div class="uz-row"><span><em>${dayName(d)}</em></span><span class="uz-tr"><i style="width:${v / mx * 100}%;background:#4c93e0"></i></span><span class="uz-n">${f(v)}%</span></div>`).join("")
      + `<p class="uz-mut">${tl("uz.since.sum", { t: dur, p: Math.round(wk.pct), a: f(wk.pct / gone) })}${wk.pct < 100 ? ` · ${tl("uz.since.rest", { n: f(per) })}` : ""}</p>`);
  }

  // 계정별: one row per account, only when there are two or more (with one, the hero says it
  // all). Official % and 빠듯/여유 tags when the plan numbers are in, otherwise the estimated
  // share of the week with no tag - we cannot honestly call an account tight against a limit we
  // do not read. In a Claude/Codex tab the share is of that tool's own week.
  function acctSec(u) {
    const all = (u.accounts || []).filter((a) => _agent === "all" || kindOf(a) === _agent);
    if (all.length < 2) return "";
    const base = _agent === "all" ? 1 : all.reduce((t, a) => t + (a.share || 0), 0);
    const withPct = all.filter((a) => a.rate && a.rate.seven_day);
    const loose = withPct.length > 1 ? withPct.reduce((m, a) => (a.rate.seven_day.pct < m.rate.seven_day.pct ? a : m)) : null;
    const top = Math.max(...all.map((a) => (a.share || 0) / (base || 1)), 0.0001);
    const row = (a) => {
      const wk = a.rate && a.rate.seven_day, share = a.share != null && base ? a.share / base : null;
      const tag = wk && a.id === u.tightest ? `<em class="uz-tag2 tight">${tl("uz.tight")}</em>` : wk && loose && a.id === loose.id ? `<em class="uz-tag2">${tl("uz.loose")}</em>` : "";
      const w = wk ? Math.max(wk.pct, 1.5) : share != null ? share / top * 100 : 0;
      const d = (a.depts || [])[0];
      return `<div class="uz-ac"><div class="uz-hd"><i class="uz-sw" style="background:${_esc(a.color)}"></i><b>${_esc(acctName(a))}${tag}</b><span class="uz-n">${wk ? Math.round(wk.pct) + "%" + (a.rate.stale ? ` · ${tl("uz.stale")}` : "") : share != null ? pct(share) : "—"}</span></div>
        <div class="uz-tr"><i style="width:${Math.min(w, 100)}%;background:${_esc(a.color)}"></i></div>
        <p class="uz-mut" style="display:flex;align-items:center;gap:6px">${d ? `${face(d.name, a.color)}<span><b>${_esc(_pn(d.name))}</b> ${pct(d.share)}</span>` : tl("uz.acct.none")}</p></div>`;
    };
    // An estimated share weighs tokens by price; models with no known price are said once, on the section.
    const odd = [...new Set(all.filter((a) => !(a.rate && a.rate.seven_day)).flatMap((a) => (a.mix || []).filter((m) => m.unpriced).map((m) => m.model)))];
    return sec("accts", tl("uz.sec.accts"), all.length, all.map(row).join(""), odd.length ? `<span title="${_esc(odd.join(", "))}">${tl("uz.acct.unpriced")}</span>` : "");
  }

  function deptSec(u, groups) {
    const dp = (u.depts || []).slice(0, 10), t1 = (dp[0] && dp[0].share) || 1;
    if (!dp.length) return "";
    return sec("dept", tl("uz.sec.dept"), dp.length, dp.map((d) => `<div class="uz-row"><span>${face(d.name, colorOf(d.group, groups))}<em>${_esc(_pn(d.name))}</em></span>
      <span class="uz-tr"><i style="width:${d.share / t1 * 100}%;background:${colorOf(d.group, groups)}"></i></span><span class="uz-n">${lim(d.share)}</span></div>`).join(""));
  }

  function sessionSec(u, groups) {
    const ss = (u.sessions || []).slice(0, 8), top = (ss[0] && ss[0].share) || 1;
    if (!ss.length) return "";
    const span = (s) => s.first ? (md(s.first) === md(s.last) ? md(s.first) : `${md(s.first)}–${md(s.last)}`) : "";
    const col = (d) => colorOf(((u.depts || []).find((x) => x.name === d.dept) || {}).group, groups);
    return sec("sess", tl("uz.sec.sess"), ss.length, ss.map((d) => `<div class="uz-ses" title="${_esc(d.ask || d.title || "")}">
      <div class="uz-hd">${face(d.dept, col(d))}<b>${_esc(_pn(d.dept))}${d.heavy ? `<em class="uz-pill">${tl("uz.long", { n: wan(d.ctx) })}</em>` : ""}</b><span class="uz-n">${lim(d.share)}</span></div>
      <small>${tl("uz.sess.sub", { span: span(d), n: Math.round(d.sub * 100) })}</small>
      <div class="uz-tr"><i style="width:${d.share * (1 - d.sub) / top * 100}%;background:#6f7bd6"></i><i style="width:${d.share * d.sub / top * 100}%;background:#454b86"></i></div></div>`).join(""));
  }

  // One line per finding; the reasoning opens underneath. No finding, no section.
  function wasteSec(u) {
    const ws = (u.waste || []).slice(0, 5);
    if (!ws.length) return "";
    return sec("waste", tl("uz.sec.waste"), ws.length, ws.map((f) => `<details class="uz-tip"><summary><div class="uz-hd">${face(f.dept, OTHER)}<b>${_esc(_pn(f.dept))}${f.alert ? `<em class="uz-pill">${tl("uz.now")}</em>` : ""}</b><span class="uz-n" title="${tl("uz.tip.save")}">−${lim(f.cost)}</span></div>
          <p class="uz-mut">${f.why.map((w) => WHY[w.kind](w.n)[0]).join(" · ")}</p></summary>
          <div class="uz-more">${f.ask ? `<p class="uz-mut">“${_esc(f.ask)}”</p>` : ""}
          ${f.why.map((w) => `<p class="uz-mut"><b>${WHY[w.kind](w.n)[0]}</b> · ${WHY[w.kind](w.n)[1]}${w.cost ? ` ${tl("uz.more.cost", { v: lim(w.cost) })}` : ""}</p>`).join("")}</div></details>`).join(""));
  }

  // B7: which projects' agents ran on the heavy models enough that a lighter one would have
  // saved. Only projects with something to change (or a switch already set) are listed.
  function modelSec(u) {
    const rows = (u.model_advice || []).filter((a) => a.set || a.agents_saved || a.main_saved);
    if (!rows.length) return "";
    return sec("model", tl("uz.sec.model"), rows.length, rows.map((a) => `<details class="uz-tip"><summary><div class="uz-hd">${face(a.name, OTHER)}<b>${_esc(_pn(a.name))}${a.set ? `<em class="uz-tag2">${_esc(tl("uz.agentset", { m: setName(a.set) }))}</em>` : ""}</b>${a.saved + a.main_saved ? `<span class="uz-n" title="${tl("uz.tip.light")}">−${lim(a.saved + a.main_saved)}</span>` : ""}</div>
          <p class="uz-mut">${a.agents_saved ? tl("uz.m.agents", { a: pct(a.agents_opus), s: pct(a.saved) }) : a.main_saved ? tl("uz.m.main", { a: pct(a.main_fable), s: pct(a.main_saved) }) : _esc(tl("uz.agentnext"))}</p></summary>
          <div class="uz-more">${a.main_saved ? `<p class="uz-mut">${tl("uz.m.main.d", { a: pct(a.main_fable), s: pct(a.main_saved) })}</p>` : ""}
          <p class="uz-mut">${tl("uz.m.agents.d", { a: pct(a.agents), o: pct(a.agents_opus) })} ${a.set ? _esc(tl("uz.agentnext")) : _esc(tl("uz.m.where"))}</p>
          ${hasSwitch() && (a.set || a.agents_saved) ? `<button class="btn sm press" data-uzswitch>${_esc(a.set ? tl("uz.agentundo") : tl("uz.agentswitch"))}</button>` : ""}</div></details>`).join(""));
  }

  function dayBody(u, groups) {
    const ds = u.daily || [];
    if (!ds.length) return `<div class="uz-bd"><p class="uz-line">${tl("uz.day.wait")}</p></div>`;
    const d = ds.find((x) => x.day === _dayP) || ds[0], top = d.depts.slice(0, 5), t1 = (top[0] && top[0].share) || 1;
    const hm = Math.max(...d.hours, 0.0001), pk = d.hours.indexOf(Math.max(...d.hours)), bw = 100 / 24;
    const ampm = (h) => (h < 12 ? tl("uz.am", { h: (h % 12) || 12 }) : tl("uz.pm", { h: (h % 12) || 12 }));
    return `<div class="uz-seg" data-sk="uzday">${ds.map((x) => `<button class="press ${x === d ? "on" : ""}" data-v="${x.day}">${dayName(x)}</button>`).join("")}</div>
      <div class="uz-bd">${top.map((x) => `<div class="uz-row"><span>${face(x.name, colorOf(x.group, groups))}<em>${_esc(_pn(x.name))}</em></span>
        <span class="uz-tr"><i style="width:${x.share / t1 * 100}%;background:${colorOf(x.group, groups)}"></i></span><span class="uz-n">${Math.round(x.share * 100)}%</span></div>`).join("")}
      <div class="uz-chart" style="margin-top:10px"><svg viewBox="0 0 100 40" preserveAspectRatio="none" role="img" aria-label="${tl("uz.aria.hours")}">${d.hours.map((v, h) => { const hh = Math.max(v / hm * 38, v ? .8 : .3); return `<rect x="${h * bw + bw * .15}" y="${40 - hh}" width="${bw * .7}" height="${hh}" rx=".5" fill="${h === pk ? "#6f7bd6" : "#3a3a3a"}"><title>${ampm(h)} · ${Math.round(v * 100)}%</title></rect>`; }).join("")}</svg>
        <div class="uz-ax"><span>${hourT(0)}</span><span>${hourT(12)}</span><span>${hourT(23)}</span></div></div>
      <p class="uz-mut">${tl("uz.day.peak", { t: ampm(pk), n: Math.round(d.hours[pk] * 100) })}</p></div>`;
  }
  function daySec(u, groups) {
    // Not folded by sec(): the day picker swaps its own body, so keep one stable container.
    return `<div class="uz-sec${shut.day ? " shut" : ""}" data-sec="day">
      <button class="uz-sh press" aria-expanded="${shut.day ? "false" : "true"}"><span class="l">${tl("uz.sec.day")}</span><span class="uz-cv">${chev}</span></button>
      <div class="uz-sb"><div id="uz-day">${dayBody(u, groups)}</div></div></div>`;
  }

  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({ id: "usage", get title() { return L("이번 주 사용량", "Usage this week"); }, draw: drawHome });
  (window.LOOP_TABS = window.LOOP_TABS || []).push({ id: "usage", get label() { return L("사용량", "Usage"); }, icon: "chart", draw: drawTab });
})();
