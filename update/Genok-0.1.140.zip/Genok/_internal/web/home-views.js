// Genok web UI: home as a to-do desk: the first thing that waits, large and answered where it
// stands; the rest in a short line under it; beside it, who is at work and what each one is doing now.
// A classic script in the page's shared scope: reads D, PERM, GQ and the rooms list of project.js
// by name. The queue's buttons keep queue.js's names (data-gq, data-gqa, data-gqsz) so its one
// listener answers them here too.
document.head.appendChild(Object.assign(document.createElement("link"), {rel: "stylesheet", href: "/s-home.css"}));
const ROOMS_TTL = 15000;
let homeTry = 0;

// ---- departments (the rooms list of project.js) ----
// The first draw can come before project.js has run: the list is then simply not there yet.
const hbReady = () => typeof loadRooms === "function";
const hbList = () => hbReady() ? roomsCache || roomsSeen : null;
const hbAt = (r) => Date.parse(r.at) || 0;
const hbState = (r) => r.lost ? "lost" : UP_ST.includes(r.state) ? (r.turn ? "turn" : r.busy ? "busy" : "wait") : r.sid && r.state === "ended" ? "ended" : "off";
const hbWord = (k) => ({turn: tl("room.fTurn"), busy: tl("room.fBusy"), wait: tl("home.b.idle"), ended: tl("home.b.ended"), off: tl("mode.v.off"), lost: tl("depts.noFolder")})[k];
const hbName = (r) => unEm(r.shown || pname(r.name), r.emoji || icoHtml(r.icon));
// Pinned first, then the given order: a department keeps its place inside its group.
const hbOrder = (A) => { const p = (D.pins || []).map((n) => A.find((r) => r.name === n)).filter(Boolean); return p.concat(A.filter((r) => !p.includes(r))); };
const hbHue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.codePointAt(0)) % 360; return h; };
const hbConv = (r) => r.named || r.label || r.title || "";
const hbPerm = () => typeof PERM !== "undefined" ? PERM : [];
const hxOff = (k) => k === "off" || k === "ended";
// A department's face: its emoji or icon on a tile of its own colour, else its initial on a tile
// of a muted hue taken from its name. Never the same grey folder twice.
const hxCol = (r) => r.color || D.ident?.[r.name]?.color || "";
function hxFace(r, size = "") {
  const name = hbName(r), col = hxCol(r);
  if (r.emoji || r.icon) return `<span class="hx-face${size}"${col ? ` style="--c:${esc(col)}"` : ""} aria-hidden="true">${em(r.emoji, "", r.icon)}</span>`;
  return `<span class="hx-face hx-ini${size}" style="--hue:${hbHue(r.name)}" aria-hidden="true">${esc(([...name.trim()][0] || "?").toUpperCase())}</span>`;
}
// What a department is doing, in one line: its live line while it works or asks, else the first
// line of what it said last, else the conversation's name.
const hxPlain = (t) => String(t || "").split("\n").map((s) => s.replace(/[*_`#>]+/g, "").replace(/^\s*[-•]\s*/, "").trim()).find(Boolean) || "";
const hxLine = (r) => (hbState(r) === "busy" || hbState(r) === "turn") && r.now ? r.now : hxPlain(r.last) || hbConv(r);
const hxGo = (r) => hbState(r) === "lost" ? "" : roomGo(r.name, r.sid && !hxOff(hbState(r)) ? r.sid : "");
// An off department: its face, when it last ran, and 켜기 as a real button (a and c share it).
const hxOffRow = (r) => `<div class="hx-offt">${hxFace(r)}<span class="hx-on1"><b>${esc(hbName(r))}</b><span>${r.at ? ago(r.at) : esc(hbWord(hbState(r)))}</span></span>${hbState(r) === "lost" ? "" : hxOnBtn(r, "g-btn hx-sm")}</div>`;
const hxOnBtn = (r, cls = "g-btn") => `<button type="button" class="${cls}" data-hbon="${esc(r.name)}"${starting.has(r.name) ? ` disabled aria-busy="true"` : ""}>${tl(starting.has(r.name) ? "room.onBusy" : "room.on")}</button>`;
function hxDepts() {
  const all = (hbList() || []).filter((r) => r.registered || r.sid || r.lost), of = (k) => hbOrder(all.filter((r) => hbState(r) === k));
  return {all, turn: of("turn"), busy: of("busy"), wait: of("wait"),
    off: hbOrder(all.filter((r) => r.registered && ["off", "ended", "lost"].includes(hbState(r))).sort((a, b) => hbAt(b) - hbAt(a)))};
}

// ---- results ----
const hxItems = () => (D.items || []).filter((x) => !libHide.has(iid(x))).sort(byAt);
const hxPic = (x, cls = "") => `<span class="hx-pic${cls}" data-k="${esc(x.kind || "")}">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.kind === "video" && x.thumb ? `<span class="hx-play">${ic("play")}</span>` : ""}</span>`;
const hxDayN = (h = 24) => hxItems().filter((x) => x.at && Date.now() - Date.parse(x.at) < h * 36e5).length;
// A fresh result is judged right here: 승인 goes the usual way (five seconds to take it back), 고치기
// opens the usual sheet.
document.addEventListener("click", (e) => {
  const ok = e.target.closest?.("[data-hxok]"), fix = e.target.closest?.("[data-hxfix]");
  const x = (ok || fix) && D.items.find((y) => iid(y) === (ok || fix).dataset[ok ? "hxok" : "hxfix"]);
  if (!x) return;
  e.stopPropagation();
  if (ok) approveMany([x]); else rejectSheet(itemIt(x));
});

// ---- what waits: the queue's 결정 tier, then results nobody has looked at yet ----
function hxWaits() {
  if (!window.GQ?.list) return [];
  return [...GQ.list(0), ...GQ.list(1).filter(({e}) => e.kind === "look")];
}
const HX_KIND = () => ({perm: tl("home.x.k.perm"), ask: tl("home.x.k.ask"), gate: tl("home.x.k.gate"), wait: tl("home.x.k.wait"), look: tl("home.x.k.look")});
// Whose it is, for the line over a card.
function hxWho(e) {
  if (e.kind === "perm") { const r = (hbList() || []).find((v) => v.sid === e.p.sid); return r ? hbName(r) : permWho(e.p); }
  if (e.kind === "wait") return pname(e.a.dept);
  return e.x ? pname(gname(e.x)) : "";
}
// The answer buttons of an entry. The first, or the recommended one, is the primary.
function hxActs(e, f, small = false) {
  const b = small ? "g-btn hx-sm" : "g-btn";
  if (e.kind === "look") return `<button type="button" class="${b} primary" data-hxok="${esc(iid(e.x))}">${tl("STATUS_T.4")}</button><button type="button" class="${b}" data-hxfix="${esc(iid(e.x))}">${tl("gq.fix")}</button>`;
  const A = f.acts || [];
  return A.map((a, i) => `<button type="button" class="${b}${(f.rec != null ? i === f.rec : i === 0) ? " primary" : ""}" data-gqa="${i}" title="${esc(a)}">${esc(a)}</button>`).join("");
}
const hxLater = () => `<button type="button" class="g-btn quiet hx-later" data-gqsz="o" title="${esc(tl("gq.snz.open"))}">${tl("gq.snooze")}</button>`;

// ---------- a: 할 일 ----------
function deskFocus({e, f}) {
  const x = e.x, q = x && x.ask_next, perm = e.kind === "perm";
  const title = perm ? tl("home.x.perm.t", {tool: e.p.tool}) : e.kind === "ask" && q ? q.q : e.kind === "wait" ? f.s : x ? x.title : f.t;
  const sub = perm ? "" : e.kind === "ask" && q ? x.title : x ? [x.v, ago(x.at)].filter(Boolean).join(" · ") : "";
  const pic = x ? `<button type="button" class="hx-fpic press" data-item="${esc(iid(x))}" aria-label="${esc(x.title)}">${hxPic(x)}</button>` : "";
  const code = perm ? `<code class="hx-code">${esc(e.p.text)}</code>` : "";
  return `<article class="hx-focus${pic ? " has-pic" : ""}" data-gq="${esc(e.key)}" data-kind="${e.kind}">${pic}
    <div class="hx-fbody"><p class="hx-eye"><span class="hx-k">${esc(HX_KIND()[e.kind] || "")}</span><span>${esc(hxWho(e))}</span></p>
      <button type="button" class="hx-ft" data-gqopen><span class="hx-t1">${esc(title)}</span>${sub ? `<span class="hx-t2">${esc(sub)}</span>` : ""}</button>
      ${code}<div class="hx-acts">${hxActs(e, f)}${hxLater()}</div></div></article>`;
}
function deskRow({e, f}) {
  const x = e.x, lead = x ? hxPic(x, " sm") : `<span class="hx-pic sm">${ic(e.kind === "perm" ? "shield" : "chat")}</span>`;
  // A permission row names its command: two Bash asks in a row must not read the same.
  const t = e.kind === "ask" && x?.ask_next ? x.ask_next.q : e.kind === "perm" ? e.p.text : x ? x.title : f.t;
  const one = e.kind === "perm" ? `<button type="button" class="g-btn primary hx-sm" data-gqa="0">${esc(f.acts[0])}</button>`
    : e.kind === "look" ? `<button type="button" class="g-btn hx-sm" data-hxok="${esc(iid(x))}">${tl("STATUS_T.4")}</button>` : "";
  return `<div class="hx-qrow" data-gq="${esc(e.key)}" data-kind="${e.kind}"><button type="button" class="g-row hx-qmain press" data-gqopen>${lead}
    <span class="g-body"><span class="g-l1">${esc(t)}</span><span class="g-l2">${esc(e.kind === "perm" ? e.p.tool : HX_KIND()[e.kind] || "")} · ${esc(hxWho(e))}</span></span></button>${one}</div>`;
}
function deskLive(r) {
  const k = hbState(r), line = hxLine(r);
  return `<button type="button" class="hx-live press" data-go="${esc(hxGo(r))}">${hxFace(r)}<span class="hx-lb"><span class="hx-ln"><b>${esc(hbName(r))}</b><span class="hx-when num">${r.at ? ago(r.at) : ""}</span></span>
    ${line ? `<span class="hx-ll">${esc(line)}</span>` : ""}${k === "turn" ? `<span class="hx-st" data-st="turn">${esc(hbWord(k))}</span>` : ""}</span></button>`;
}
function homeDesk(c) {
  const W = hxWaits(), [top, ...rest] = W, R = hxItems(), shown = new Set(W.map(({e}) => e.x && iid(e.x)).filter(Boolean));
  const fresh = R.filter((x) => !shown.has(iid(x))).slice(0, 6);
  const work = [...c.turn, ...c.busy], idle = c.wait;
  const focus = top ? deskFocus(top) : `<article class="hx-focus hx-calm"><div class="hx-fbody"><p class="hx-t1">${tl("home.x.clear")}</p>
    <p class="hx-t2">${work.length ? tl("home.b.t", {n: work.length}) : tl("home.b.t0")}</p></div></article>`;
  const next = rest.length ? `<section class="hx-sec"><div class="hx-lab"><h3>${tl("home.x.next")}<span class="hx-n num">${rest.length}</span></h3></div>
    <div class="hx-q">${rest.slice(0, 5).map(deskRow).join("")}</div>${rest.length > 5 ? `<button type="button" class="hx-more press" data-go="inbox">${tl("home.v.more", {n: rest.length - 5})}${ic("chev", "i")}</button>` : ""}</section>` : "";
  const made = fresh.length ? `<section class="hx-sec"><div class="hx-lab"><h3>${tl("home.b.recent")}</h3><button type="button" class="hx-more press" data-go="lib">${tl("home.b.seeall")}${ic("chev", "i")}</button></div>
    <div class="hx-strip">${fresh.map((x) => `<button type="button" class="hx-shot press" data-item="${esc(iid(x))}" title="${esc(x.title)}">${hxPic(x)}<span class="hx-st1">${esc(x.title)}</span><span class="hx-st2">${esc(pname(gname(x)))} · ${ago(x.at)}</span></button>`).join("")}</div></section>` : "";
  const live = work.length ? `<section class="hx-sec"><div class="hx-lab"><h3>${tl("room.fBusy")}<span class="hx-n num">${work.length}</span></h3></div><div class="hx-lives">${work.map(deskLive).join("")}</div></section>` : "";
  const wait = idle.length ? `<section class="hx-sec"><div class="hx-lab"><h3>${tl("home.b.idle")}<span class="hx-n num">${idle.length}</span></h3></div>
    <div class="hx-chips">${idle.map((r) => `<button type="button" class="hx-chip press" data-go="${esc(hxGo(r))}">${hxFace(r, " xs")}<span>${esc(hbName(r))}</span></button>`).join("")}</div></section>` : "";
  const off = c.off.length ? `<section class="hx-sec"><div class="hx-lab"><h3>${tl("mode.v.off")}<span class="hx-n num">${c.off.length}</span></h3></div>
    <div class="hx-offs">${c.off.slice(0, 6).map(hxOffRow).join("")}</div>
    ${c.off.length > 6 ? `<button type="button" class="g-btn quiet hx-more press" data-go="depts">${tl("home.v.more", {n: c.off.length - 6})}${ic("chev", "i")}</button>` : ""}</section>` : "";
  return {title: W.length ? tl("home.x.a.t", {n: W.length}) : tl("home.x.clear"),
    sub: tl("home.x.day", {n: hxDayN()}),   // the side says how many work; the title, how many wait
    body: `<div class="hx-desk"><div class="hx-main"><div class="gq-home hx-host" data-gqhost>${focus}${next}</div>${made}</div>
      <aside class="hx-side">${live}${wait}${off}</aside></div>`};
}

// ---------- the page ----------
document.addEventListener("click", (e) => {
  const on = e.target.closest?.("[data-hbon]");
  if (on) {
    e.stopPropagation();
    const r = (hbList() || []).find((v) => v.name === on.dataset.hbon); if (!r) return;
    const b = r.back && r.back.sid ? r.back : r.sid && r.state === "ended" ? {sid: r.sid, title: r.title, agent: r.agent} : null;
    return turnOn(r.name, b && {sid: b.sid, title: b.title, agent: b.agent}, () => { if (cur === "home") redraw(); });
  }
});
SCREENS.home = function () {
  if (brief) return briefScreen();
  const items = D.items || [], L = hbList();
  if (hbReady() && (!L || Date.now() - roomsAt > ROOMS_TTL)) {
    if (Date.now() - homeTry > ROOMS_TTL) { homeTry = Date.now(); loadRooms().then(() => { if (cur === "home") redraw(); }).catch(() => {}); }
  }
  const c = hxDepts(), empty = L && !c.all.length;
  const v = homeDesk(c);
  V().innerHTML = `<div class="home hx" data-hx="a">
    <header class="g-head hx-head"><div class="g-ht"><h2 class="g-title">${esc(v.title)}</h2><p class="g-sub">${esc(v.sub)}</p></div></header>
    ${empty ? `<div class="hx-empty"><span>${tl("home.b.none")}</span><button type="button" class="g-btn" data-go="depts">${tl("home.b.new")}</button></div>` : ""}
    ${v.body}
  </div>`;
  const hm = V().querySelector(".home"), first = window.LOOP_HOME_FIRST ? window.LOOP_HOME_FIRST() : "";
  if (first) hm.insertAdjacentHTML("afterbegin", first);
  triMark();
  // First run: nothing pushed and no department yet; the first-use card takes the page.
  if (!items.length && empty && typeof window.LOOP_HOME_EMPTY === "function") {
    try {
      const html = window.LOOP_HOME_EMPTY(hm);
      if (typeof html === "string" && html.includes('class="card oh"')) { hm.innerHTML = html; hm.classList.add("first"); }
    } catch (e) { console.error(e); }
  }
};
