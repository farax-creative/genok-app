// Genok web UI, cut from project.js: the room screen's stylesheet, first half (ensureCss in project.js puts it on the page).
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
const PJ_CSS_1 = `
  .pj{max-width:100%;overflow-x:hidden;padding-bottom:calc(96px + env(safe-area-inset-bottom))}
  .pj-lab{display:flex;align-items:center;gap:8px;margin:16px 2px 8px;font-size:12px;font-weight:600;letter-spacing:.08em;
    text-transform:uppercase;color:var(--t3)}
  .pj-lab .n{color:var(--t4);letter-spacing:0}
  .pj-lab .sp{flex:1}
  .pj-lab button{font-size:12px;letter-spacing:0;text-transform:none;color:var(--t3);font-weight:500}
  .pj-lab button:hover{color:var(--t1)}
  .pj-head{display:flex;align-items:center;gap:16px;padding:6px 2px 4px}
  .pj-head .em{font-size:30px;line-height:1;flex:none}
  .pj-head .tx{min-width:0;flex:1}
  .pj-head h1{margin:0;font-size:22px;font-weight:700;letter-spacing:-.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-head .fo{font-size:12px;color:var(--t3);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-back{font-size:13px;color:var(--t3);padding:6px 2px;display:inline-flex;align-items:center;gap:4px}
  .pj-back:hover{color:var(--t1)}
  .pj-btn{height:36px;padding:0 16px;border-radius:8px;background:var(--btn);color:var(--t1);font-size:14px;font-weight:600;
    display:inline-flex;align-items:center;justify-content:center;gap:6px;white-space:nowrap;transition:background .15s}
  .pj-btn:hover{background:var(--btn-hi)} .pj-btn:disabled{opacity:.45;cursor:default}
  .pj-btn.full{width:100%}
  .pj-fail{display:grid;place-content:center;justify-items:center;gap:16px;min-height:min(48vh,360px)}
  .pj-fail .pj-btn{box-shadow:inset 0 0 0 1px var(--line)}
  @media(pointer:coarse){.pj-fail .pj-btn,[data-serr] .pj-btn{min-height:44px}}
  .pj-btn.light{background:#dcdcdc;color:#141414} .pj-btn.light:hover{background:#eee}
  /* On a light page the pale pill read as switched off: it goes to ink there. */
  html[data-theme="light"] .pj-btn.light{background:#111114;color:#fff} html[data-theme="light"] .pj-btn.light:hover{background:#2a2a30}
  .pj-text{height:34px;padding:0 12px;border-radius:8px;font-size:14px;color:var(--t3);font-weight:500}
  .pj-text:hover{color:var(--t1);background:var(--btn)}
  .pj-grid{display:grid;gap:8px;grid-template-columns:repeat(auto-fill,minmax(230px,1fr))}
  .pj-card{position:relative;text-align:left;background:var(--card);border-radius:var(--r-card);padding:12px 16px;
    display:flex;flex-direction:column;gap:8px;min-width:0;border:1px solid transparent;transition:background .15s,border-color .15s}
  .pj-card:hover{background:var(--card-hi)}
  .pj-card.on{border-color:rgba(255,255,255,.16);background:var(--card-hi)}
  .pj-card .r1{display:flex;align-items:flex-start;gap:8px}
  .pj-card .t{flex:1;min-width:0;font-size:14.5px;font-weight:600;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;
    -webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
  .pj-card .r2{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--t3);flex-wrap:wrap}
  .pj-dot{width:7px;height:7px;border-radius:var(--rad-pill);flex:none;background:var(--t4)}
  .pj-dot.live{background:var(--sr-work,var(--green))} .pj-dot.idle{background:var(--orange)}
  .pj-ag,.pj-bg{display:inline-flex;align-items:center;flex:none;box-sizing:border-box;height:18px;padding:0 6px;border:1px solid var(--line);border-radius:6px;
    font-size:12px;font-weight:600;letter-spacing:.02em;line-height:1;color:var(--t2);white-space:nowrap}
  .pj-bg{color:var(--t3)}
  .pj-stl{display:inline-flex;align-items:center;height:18px;line-height:1;white-space:nowrap}
  .pj-stl.stale{color:var(--blue-t)} .pj-stl.stuck{color:var(--red)}
  .pj-ico{display:inline-flex;flex:none;width:14px;height:14px;color:var(--t3)} .pj-ico svg{width:100%;height:100%}
  .pj-ico.stale{color:var(--blue-t)}
  .pj-more{flex:none;width:28px;height:28px;margin:-4px -6px 0 0;border-radius:8px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center}
  .pj-more:hover{background:var(--btn);color:var(--t1)}
  .pj-more svg{width:16px;height:16px}
  .pj-pop{position:fixed;z-index:400;min-width:176px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);max-height:calc(100dvh - 16px);overflow-y:auto;overscroll-behavior:contain;transform-origin:top right}
  .pj-pop.wide{width:300px}
  .pj-pop button{display:flex;width:100%;align-items:center;color:var(--t1);text-align:left}
  body .pj-pop button.two{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;height:auto;min-height:var(--menu-row);padding:8px 12px}
  .pj-pop button small{font-size:12px;line-height:1.4;color:var(--t3);font-weight:400;white-space:normal}
  body .pj-pop button:disabled,body .pj-pop button[aria-disabled="true"]{color:var(--t4);cursor:default}
  body .pj-pop button[aria-disabled="true"]:hover{background:none}
  .pj-pop button[aria-disabled="true"] small{color:var(--orange)}
  .pj-pop hr{border:0;border-top:1px solid var(--line);margin:4px 2px}
  /* A row's menu: an icon and a name of a few words per choice, the rare ones folded under 더 보기. */
  .pj-pop.cm{width:max-content;min-width:184px;max-width:min(260px,calc(100vw - 16px))}
  body .pj-pop.cm button{gap:8px;white-space:nowrap}
  .pj-pop.cm button>svg{flex:none;width:16px;height:16px;fill:currentColor;color:var(--t3)}
  /* The menu beside [새 세션]: three short names, each with an outline glyph of one weight. */
  .pj-tmr .pj-btn svg.lu{width:18px;height:18px;fill:none;color:var(--t2)}
  .pj-pop.cm button>svg.up{transform:rotate(-90deg)}.pj-pop.cm button>svg.dn{transform:rotate(90deg)}
  .pj-pop.cm button[aria-disabled="true"]>svg{color:var(--t4)}
  .pj-pop.cm button>svg.cv{width:12px;height:12px;margin-left:auto;color:var(--t4);transition:transform .18s cubic-bezier(.2,.9,.25,1)}
  .pj-pop.cm button[aria-expanded="true"]>svg.cv{transform:rotate(90deg)}
  .pj-pop.cm .mx[hidden]{display:none}
  .pj-pop.cm .mx{margin:2px 0 0;padding:2px 0 2px 8px;border-radius:var(--r-sm);background:color-mix(in srgb,var(--t1) 4%,transparent)}
  .pj-pop.cm button.dz:not([aria-disabled]){color:var(--red)}.pj-pop.cm button.dz:not([aria-disabled])>svg{color:var(--red)}
  @media(prefers-reduced-motion:reduce){.pj-pop.cm button>svg.cv{transition:none}}
  /* The letter that runs a choice while the menu is open, at the row's right end. */
  .pj-pop.cm button>.mk{margin-left:auto;padding-left:16px;display:inline-flex;gap:4px}
  @media(pointer:coarse){.pj-pop.cm button>.mk{display:none}}
  @media(pointer:coarse),(max-width:600px){.pj-pop.cm{min-width:216px}body .pj-pop.cm button{height:44px;gap:12px;font-size:15px}.pj-pop.cm button>svg{width:18px;height:18px}}
  .pj-empty{color:var(--t3);font-size:13px;padding:24px 4px;text-align:center;line-height:1.6}
  .pj-cols{display:grid;gap:16px;grid-template-columns:minmax(0,1fr);align-items:start}
  /* html.pj3 = the page has room for the list, a 380px chat and the results side by side
     (threeCols() below measures the page, so a folded app menu or a wide window both count). */
  html.pj3 .pj-cols{grid-template-columns:var(--rw,232px) minmax(0,1fr) var(--sw,300px);gap:16px;
      transition:grid-template-columns var(--m-snap-d,.45s) var(--m-snap,cubic-bezier(.2,.9,.25,1))}
  html.pj3 .pj-cols.no-rail{--rw:40px} html.pj3 .pj-cols.no-side{--sw:40px}
  /* The list and the results drag wider from their inner edge (v2.css .cgrip, v2.js wireColGrip). */
  html.pj3 .pj-cols{position:relative}
  html.pj3 .pj-cols>.pj-g{display:block;position:absolute;top:0;bottom:0;height:auto;width:14px;z-index:2}
  html.pj3 .pj-cols>.pj-g.l{left:calc(var(--rw,232px) + 1px)} html.pj3 .pj-cols>.pj-g.r{right:calc(var(--sw,300px) + 2px)}
  html.pj3 .pj-cols.no-rail>.pj-g.l,html.pj3 .pj-cols.no-side>.pj-g.r{display:none}
  /* The grip is only its short handle here. v2.css draws a full-height hairline for the item page;
     in this grid it read as a stray line through the chat, and while a panel opened it stood at the
     final edge before the column got there. It comes in once the column has arrived. */
  html.pj3 body:not(.gripping) .pj-cols>.pj-g:not(:hover):not(:focus-visible)::before{background:transparent}
  /* With a mouse the handle rests unseen too (a lone pill between two cards read as a stray bar);
     it shows under the pointer, on keyboard focus and while dragging. Touch keeps it in sight. */
  @media(hover:hover){html.pj3 body:not(.gripping) .pj-cols>.pj-g:not(:hover):not(:focus-visible)::after{background:transparent}}
  html.pj3 .pj-cols>.pj-g{animation:pj-gin .16s ease .42s backwards}
  @keyframes pj-gin{from{opacity:0}}
  body.gripping .pj-cols>.pj-g{animation:none}
  /* A panel that opens is not squeezed while its column grows from the 40px strip: its rows keep
     the width the column is heading for and are uncovered instead (a 70px column wrapped the
     heading one letter per line and stacked the cards' marks on top of each other). */
  html.pj3 .pj-cols>.pj-rail,html.pj3 #pj-side{overflow-x:hidden}
  html.pj3 .pj-cols:not(.no-rail)>.pj-rail>*{min-width:calc(var(--rw,232px) - 18px)}
  html.pj3 .pj-cols:not(.no-side) #pj-side>*{min-width:calc(var(--sw,300px) - 12px)}
  body.gripping .pj-cols{transition:none}
  html.pj3 .pj-body{display:contents}
  @media(prefers-reduced-motion:reduce){.pj-cols{transition:none!important}html.pj3 .pj-cols>.pj-g{animation:none}}
  .pj-fbtn{flex:none;width:26px;height:26px;margin:-6px -2px -6px 0;border-radius:8px;color:var(--t3);display:none;align-items:center;justify-content:center}
  .pj-fbtn svg{width:16px;height:16px}
  .pj-fbtn.r svg,.pj-strip.r svg{transform:scaleX(-1)}
  .pj-lab .pj-fbtn:hover{background:var(--btn);color:var(--t1)}
  html.pj3 .pj-fbtn{display:inline-flex}
  .pj-strip{display:flex;flex-direction:column;align-items:center;gap:8px;width:40px;height:100%;min-height:120px;padding:8px 0;border-radius:8px;
    background:var(--card);color:var(--t2);font-size:13px;font-weight:600;transition:background .15s,color .15s}
  .pj-strip:hover{background:var(--card-hi);color:var(--t1)}
  .pj-strip svg{width:18px;height:18px;flex:none}
  /* Under the panel icon: what is inside, as a small icon over its count. The words are in the
     button's label and tooltip, never turned on their side. */
  .pj-strip .c{display:flex;flex-direction:column;align-items:center;gap:4px;color:var(--t3)}
  .pj-strip .c svg{width:15px;height:15px}
  .pj-strip .c b{min-width:18px;height:16px;padding:0 4px;border-radius:8px;background:var(--btn);color:var(--t2);
    font-size:12px;font-weight:600;line-height:16px;letter-spacing:0;text-align:center;font-variant-numeric:tabular-nums}
  .pj-strip .c.hot b{background:var(--orange);color:#141414}
  .pj-strip:hover .c{color:var(--t2)}
  /* Results not looked at yet: the strip takes the accent and the count becomes their number. It
     moves once (.pop: the number springs in under a wash that fades), never in a loop. */
  .pj-strip{position:relative}
  .pj-strip.new{background:color-mix(in srgb,var(--blue) 14%,var(--card));color:var(--blue-t);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 42%,transparent)}
  .pj-strip.new:hover{background:color-mix(in srgb,var(--blue) 22%,var(--card));color:var(--blue-t)}
  .pj-strip .c.new,.pj-strip.new:hover .c.new{color:var(--blue-t)}
  .pj-strip .c.new b{background:var(--blue);color:var(--on-blue,#fff)}
  .pj-strip.pop::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:var(--blue);opacity:0;animation:pj-wash .9s ease-out 1}
  .pj-strip.pop .c.new b,.pj-nb.pop{animation:pj-pop var(--m-pop-d,.5s) var(--m-pop,cubic-bezier(.34,1.56,.64,1)) 1 backwards}
  @keyframes pj-wash{from{opacity:.4}}
  @keyframes pj-pop{from{transform:scale(.3)}}
  .pj-nb{display:inline-grid;place-items:center;min-width:17px;height:17px;margin-left:6px;padding:0 4px;border-radius:8px;background:var(--blue);color:var(--on-blue,#fff);
    font-size:12px;font-weight:700;line-height:1;letter-spacing:0;font-variant-numeric:tabular-nums;vertical-align:1px}
  @media(prefers-reduced-motion:reduce){.pj-strip.pop::after{display:none}.pj-strip.pop .c.new b,.pj-nb.pop{animation:none}}
  /* The results as small rows (the panel head's switch): picture and one line of title. */
  .pj-fbtn.pj-rdn{display:inline-flex;position:relative}
  .pj-fbtn[aria-pressed="true"]{background:var(--btn);color:var(--t1)}
  .pj-fbtn:focus-visible,.pj-strip:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-dn1 .pj-res{gap:8px;min-height:36px;padding:4px 8px 4px 4px;margin-bottom:2px;border-radius:8px;background:none}
  .pj-dn1 .pj-res:hover{background:var(--card)}
  .pj-dn1 .pj-res .th{width:28px;height:28px;border-radius:6px;background:var(--card)}
  .pj-dn1 .pj-res:hover .th{background:var(--bg)}
  .pj-dn1 .pj-res .th svg{width:14px;height:14px} .pj-dn1 .pj-res .th .play{display:none}
  .pj-dn1 .pj-res .t,.pj-dn1 .pj-item .t{display:block;font-size:13px;font-weight:500;white-space:nowrap;text-overflow:ellipsis}
  .pj-dn1 .pj-res .s,.pj-dn1 .pj-item .s{display:none}
  .pj-dn1 .pj-item{min-height:36px;padding:4px 8px;margin-bottom:2px;border-radius:8px;background:none}
  .pj-dn1 .pj-item:hover{background:var(--card)}
  .pj-dn1 .pj-lab{margin-top:16px;margin-bottom:6px}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-dn1 .pj-res,.pj-dn1 .pj-item{min-height:44px}.pj-dn1 .pj-res .th{width:32px;height:32px}
    .pj-fbtn.pj-rdn::before{content:"";position:absolute;inset:-9px}}
  .pj-seg{margin:6px 0 4px}
  html.pj3 .pj-seg{display:none}
  .pj-conv{position:relative;background:var(--card);border-radius:var(--r-card);display:flex;flex-direction:column;min-width:0;overflow:hidden}
  .pj-state{display:flex;align-items:center;gap:8px;padding:12px 16px;font-size:13px;color:var(--t2);border-bottom:1px solid var(--line)}
  .pj-state .sp{flex:1}
  .pj-state>span{white-space:nowrap}
  .pj-state>button{flex:none;white-space:nowrap}
  /* A session that ended keeps one small way back beside its state; the rest is in its menu. */
  .pj-row.busy{opacity:.55;pointer-events:none}
  .pj-note button{margin-left:8px;height:24px;padding:0 8px;border-radius:6px;background:var(--btn);color:var(--t1);font-size:12px;font-weight:600}
  .pj-note button:hover{background:var(--btn-hi)}
  .pj-q{overflow-wrap:anywhere}
  .pj-qq{margin-top:8px}
  .pj-qq>div:has(>[data-qpick]){display:flex;align-items:baseline;gap:8px;color:var(--t2)}   /* a long description wraps beside its option, not under it */
  .pj-q [data-qpick]{flex:none;margin:4px 0 0}
  .pj-q [data-qpick][aria-pressed="true"]{background:var(--t1);color:var(--card)}
  .pj-q input{display:block;width:100%;max-width:480px;height:28px;margin-top:8px;padding:0 8px;border:1px solid var(--line);border-radius:6px;background:none;color:var(--t1);font:inherit}
  .pj-qa{margin-top:8px}
  .pj-qa button:first-child{margin-left:0}
  /* Allow and deny sit on their own line under the command, not wherever its text happens to end.
     On a touch screen they were 24px tall and 8px apart: each now takes 44px and they stand 16px apart. */
  @media(pointer:coarse){.pj-note .pj-qa button{position:relative;height:32px;padding:0 14px;margin-left:16px}.pj-note .pj-qa button:first-child{margin-left:0}.pj-note .pj-qa button::after{content:"";position:absolute;inset:-6px -8px}}
  @media(pointer:coarse){.pj-q button,.pj-q input{height:36px}.pj-q input{font-size:16px}}
  .pj-msgs{display:flex;flex-direction:column;gap:12px;padding:16px;overflow-y:auto;overscroll-behavior:contain;
    height:calc(100vh - 535px);height:calc(100dvh - 535px);min-height:260px;scroll-behavior:auto}
  /* Desktop: the three columns fill exactly the room between the toolbar and the status bar (fit() sets
     --pjh from what is really there), the log takes whatever the chrome around it leaves and scrolls,
     and the composer stays at the bottom edge of the panel. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){
    main:has(.pj-cols){padding-bottom:12px}
    .pj{padding-bottom:0}
    .pj-cols{height:var(--pjh,calc(var(--vh,100dvh) - 230px));min-height:0;align-items:stretch}
    .pj-rail,#pj-side{min-height:0;overflow-y:auto;overscroll-behavior:contain}
    .pj-body{display:flex;flex-direction:column;min-height:0;height:100%}
    .pj-body>.pj-conv{flex:1 1 auto;min-height:0}
    .pj-body>#pj-side{flex:1 1 auto}
    .pj-wrap{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
    .pj-msgs{flex:1 1 auto;height:auto;min-height:0}
  }
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){html:not(.pj3) .pj-cols{display:flex;flex-direction:column}html:not(.pj3) .pj-rail{flex:none;max-height:40%}html:not(.pj3) .pj-body{flex:1 1 auto}}
  html.pj3 .pj-body{display:contents}html.pj3 .pj-conv,html.pj3 #pj-side{min-height:0}
  /* Korean breaks between words, not inside them; a long path or address may still break anywhere. */
  /* The app shell disables text selection on body; conversation text opts back in. */
  .pj-msg{max-width:88%;font-size:14.5px;line-height:1.6;white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere;min-width:0;-webkit-user-select:text;user-select:text;cursor:text}
  .pj-holding{outline:1.5px solid color-mix(in srgb,var(--blue) 45%,transparent);outline-offset:-1px;filter:brightness(1.08)}
  /* Keep native selection handles and the system copy menu available on touch screens. */
  .pj-msgs .pj-msg.user,.pj-msgs .pj-msg.claude{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default}
  .pj-msg a{color:var(--blue-t);text-decoration:underline;text-underline-offset:2px;overflow-wrap:anywhere}
  /* A long press on a list card lifts it (menu / reorder): no text loupe or callout from the phone. */
  @media(pointer:coarse){.pj-srow,.pj-card{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}}
  .pj-msg.user{align-self:flex-end;background:var(--btn-hi);padding:8px 12px;border-radius:12px 12px 4px 12px}
  .pj-msg.claude{align-self:flex-start;color:var(--t1)}
  /* Wide pane: the header, the bars and the box span it, the talk keeps a reading measure. The
     column is left-aligned under the title; the person's bubbles end at the column's right edge. */
  @media(min-width:1500px){body .pj-conv .pj-wrap .pj-msgs{padding-right:max(16px,calc(100% - max(1120px,70%)))}}
  .pj-msg.claude{max-width:min(88%,820px)}.pj-msg.user{max-width:min(88%,720px)}
  .pj-msg.tool{align-self:flex-start;color:var(--t3);font-size:12px;font-family:ui-monospace,Menlo,Consolas,monospace;
    max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* The log is a column that scrolls, so nothing in it may give up its height: a tool line (it clips
     its own overflow, so its floor is 0) used to shrink to nothing in a long chat and leave only the
     row gap behind - 36 calls in a row read as 500px of nothing. A run of them sits closer together. */
  .pj-msgs>*{flex:none}
  .pj-msg.tool+.pj-msg.tool,.pj-tfold+.pj-msg.tool{margin-top:-8px}
  /* A long run of tool lines is one quiet row and its last two lines; the row opens the rest in place. */
  .pj-msg.tool.fd{display:none}
  /* A subagent's run: one quiet line that opens on its brief and its report. */
  .pj-sub{align-self:flex-start;max-width:min(100%,820px);min-width:0;margin-left:-6px;font-size:13px;line-height:20px;color:var(--t3)}
  .pj-sub.fd{display:none}
  .pj-sub+.pj-sub,.pj-subsum+.pj-sub{margin-top:-8px}
  .pj-subh{display:flex;align-items:flex-start;gap:8px;max-width:100%;min-height:28px;padding:4px 6px;border-radius:8px;text-align:left}
  @media(hover:hover){.pj-subh:hover,.pj-subsum button:hover{background:var(--btn)}}
  .pj-subh .smk{flex:none;display:grid;place-items:center;width:14px;height:20px}
  .pj-subh .smk svg{width:14px;height:14px} .pj-subh .smk .pj-spin{width:10px;height:10px}
  .pj-sub[data-st="bad"] .smk,.pj-sub[data-st="bad"] .sst{color:var(--red)} .pj-sub[data-st="run"] .sst{color:var(--t1)}
  .pj-subh .stx{min-width:0;overflow-wrap:anywhere;font-variant-numeric:tabular-nums}
  .pj-subh .stx b{font-weight:600;color:var(--t2)} .pj-subh .sds{color:var(--t2)}
  .pj-subh>svg{flex:none;width:12px;height:12px;margin-top:4px;transform:rotate(90deg);transition:transform .16s ease}
  .pj-subh[aria-expanded="true"]>svg{transform:rotate(-90deg)}
  .pj-subb{margin:4px 0 4px 22px;padding:2px 0 2px 12px;border-left:1px solid var(--line);font-size:13.5px;line-height:1.6;color:var(--t2);-webkit-user-select:text;user-select:text}
  .pj-subb h5{margin:8px 0 2px;font-size:12px;font-weight:600;line-height:18px;color:var(--t3)} .pj-subb h5:first-child{margin-top:0}
  .pj-subb .bf,.pj-subb .rp{white-space:pre-wrap;overflow-wrap:anywhere} .pj-subb .bf{max-height:220px;overflow-y:auto} .pj-subb .no{color:var(--t3)}
  .pj-subsum{align-self:flex-start;display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;max-width:100%;font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-subsum button{position:relative;margin-left:-4px;padding:2px 4px;border-radius:6px;font-weight:600;color:var(--t2)}
  @media(pointer:coarse){.pj-subh{min-height:44px;align-items:center}.pj-subh>svg{margin-top:0}.pj-subsum button::after{content:"";position:absolute;inset:-12px -6px}}
  @media(prefers-reduced-motion:reduce){.pj-subh>svg{transition:none}}
  .pj-tfold{align-self:flex-start;display:inline-flex;align-items:center;gap:4px;min-height:22px;margin:-2px 0 0 -6px;padding:0 4px 0 6px;border-radius:6px;
    font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums;cursor:pointer}
  .pj-tfold:hover{background:var(--btn);color:var(--t2)}
  .pj-tfold svg{width:12px;height:12px;flex:none;transform:rotate(90deg);transition:transform .16s ease}
  .pj-tfold[aria-expanded="true"] svg{transform:rotate(-90deg)}
  @media(pointer:coarse){.pj-tfold{min-height:32px}}
  @media(prefers-reduced-motion:reduce){.pj-tfold svg{transition:none}}
  .fl-body .pj-msg.claude:has(+.pj-tfold) .fl-meta{display:none}
  /* The first look reads the end of a long record: this row at the head of the log brings what was said before it. */
  .pj-older{align-self:center;display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:28px;padding:0 12px;border-radius:999px;
    font-size:12px;line-height:18px;color:var(--t3);cursor:pointer}
  .pj-older:hover{background:var(--btn);color:var(--t1)}
  .pj-older:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-text[aria-busy="true"]{opacity:.5;cursor:progress}
  .pj-older .pj-spin{display:none} .pj-older[aria-busy="true"] .pj-spin{display:block}
  @media(pointer:coarse){.pj-older{min-height:44px;padding:0 16px;font-size:13px}}
  /* The log is what was said; what a turn did is one quiet row per run that opens on its lines
     (2026-10-08; before that the lines were hidden outright, user 2026-10-05). A line opens on
     the command, what came back, and an edit's diff. */
  .pj-msg.tool.act{white-space:normal;overflow:visible;max-width:min(100%,820px);min-width:0;margin-left:-6px}
  .pj-msg.act>.ah{display:flex;align-items:center;gap:6px;max-width:100%;min-width:0;padding:1px 6px;border-radius:6px;font:inherit;color:inherit;text-align:left;cursor:pointer}
  .pj-msg.act>.ah:hover{background:var(--btn);color:var(--t2)}
  .pj-msg.act>.ah:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-msg.act>.ah b{flex:none;font-weight:600;color:var(--t2)}
  .pj-msg.act .aw{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-msg.act .am{flex:none;display:inline-flex;gap:6px;font-variant-numeric:tabular-nums} .pj-msg.act .am:empty{display:none}
  .pj-msg.act .am i,.pj-chgs .n i{font-style:normal} .pj-msg.act .bad{color:var(--red,#d9534f)}
  .pj-msg.act i.da,.pj-chgs i.da{color:var(--green,#3a9d5d)} .pj-msg.act i.dd,.pj-chgs i.dd{color:var(--red,#d9534f)}
  .pj-msg.act>.ab{margin:4px 0 8px 6px;padding-left:10px;border-left:1px solid var(--line);-webkit-user-select:text;user-select:text}
  .pj-msg.act pre{margin:0 0 4px;font:inherit;line-height:18px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow-y:auto}
  .pj-msg.act pre.ac{color:var(--t2)} .pj-msg.act pre.ar.bad{color:var(--red,#d9534f)}
  .pj-msg.act .at{font-family:var(--font,inherit);font-size:13px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow-y:auto}
  .pj-msg.act .an{display:flex;align-items:center;gap:10px;font-family:var(--font,inherit)}
  .pj-msg.act .an button{position:relative;padding:2px 4px;margin-left:-4px;border-radius:6px;font-weight:600;color:var(--t2);cursor:pointer}
  .pj-diff{margin:0 0 6px;max-width:100%;overflow-x:auto;border:1px solid var(--line);border-radius:8px;font:12px/18px ui-monospace,Menlo,Consolas,"Pretendard Variable",monospace;color:var(--t2)}
  .pj-diff>div{white-space:pre;padding:0 8px;min-width:max-content}
  .pj-diff .dh{color:var(--t3)} .pj-diff .da{background:rgba(58,157,93,.14)} .pj-diff .dd{background:rgba(217,83,79,.14)}
  .pj-dnone{font-size:12px;line-height:18px;color:var(--t3)}
  .pj-msg.user.clip>.ut{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:8;overflow:hidden}
  .pj-msg.user>.um{display:block;position:relative;margin-top:4px;font-size:12px;line-height:18px;font-weight:600;color:var(--t2);cursor:pointer}
  .pj-quote{position:absolute;z-index:3;min-height:28px;padding:0 10px;border:1px solid var(--line);border-radius:999px;background:var(--bg);color:var(--t1);font-size:12px;font-weight:600;box-shadow:0 2px 8px rgba(0,0,0,.18)}
  @media(pointer:coarse){.pj-quote{min-height:44px;padding:0 16px;font-size:13px}.pj-msg.user>.um::after{content:"";position:absolute;inset:-13px -10px}}
  /* A line kept (고정): its mark sits under the copy button. A pointer shows it on hover; on a kept
     line it stays, so the line is known at a glance and a finger can let it go. */
  .pj-bk{position:absolute;display:grid;place-items:center;width:28px;height:24px;border-radius:var(--rad-ctl);color:var(--t3);opacity:0;transition:opacity .14s ease,background-color .14s ease,color .14s ease}
  .pj-bk svg{width:14px;height:14px;fill:currentColor}
  .pj-msg.claude>.pj-bk{left:100%;top:24px}
  .pj-msg.user>.pj-bk{right:calc(100% + 28px);top:-4px}
  /* A kept line wears a plate: with a pale accent the colour alone is the text colour and says nothing. */
  .pj-msg[data-mk]>.pj-bk{opacity:1;color:var(--blue-t);background:var(--blue-w)}
  .pj-bk:focus-visible{opacity:1;outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-msg:hover>.pj-bk{opacity:1}.pj-bk:hover{color:var(--t1);background:var(--btn)}}
  @media(pointer:coarse){.pj-msg:not([data-mk])>.pj-bk{display:none}.pj-msg.claude>.pj-bk{top:0}.pj-msg.user>.pj-bk{right:100%;top:0}.pj-bk::after{content:"";position:absolute;inset:-10px -8px}}
  /* 차례 목록 and 자주 쓰는 문구: one line and a quiet line under it per row, in the app's sheet. */
  .pj-tl .tl-rows{display:flex;flex-direction:column;gap:2px;margin:0 -8px 8px}
  .pj-tl .tl-row{display:flex;align-items:center;gap:4px;min-width:0}
  .pj-tl .tl-go{flex:1;min-width:0;display:block;min-height:44px;padding:6px 8px;border-radius:10px;text-align:left}
  .pj-tl .tl-go .t{display:block;font-size:14px;line-height:1.45;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-tl.sn .tl-go .t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:pre-wrap;overflow-wrap:anywhere}
  .pj-tl .tl-go .s{display:block;margin-top:2px;font-size:12px;line-height:1.4;color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-tl .tl-x{flex:none;display:grid;place-items:center;width:44px;height:44px;border-radius:10px;color:var(--t3)}
  .pj-tl .tl-x svg{width:16px;height:16px;fill:currentColor}
  .pj-tl .tl-none{margin:4px 0 8px;font-size:13px;line-height:1.5;color:var(--t3)}
  .pj-tl .tl-go:focus-visible,.pj-tl .tl-x:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){.pj-tl .tl-go:hover,.pj-tl .tl-x:hover{background:var(--card-hi)}.pj-tl .tl-x:hover{color:var(--t1)}}
  /* A result the session pushed, in the log where it was pushed: it opens the result. */
  .pj-rc{align-self:flex-start;flex:none;display:flex;align-items:center;gap:10px;max-width:min(88%,420px);min-height:48px;padding:6px 14px 6px 6px;border-radius:12px;background:var(--card);text-align:left}
  .pj-rc .th{position:relative;flex:none;display:grid;place-items:center;width:36px;height:36px;border-radius:8px;overflow:hidden;background:var(--bg);color:var(--t3)}
  .pj-rc .th svg{width:16px;height:16px;fill:currentColor} .pj-rc .th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover} .pj-rc .th .play{display:none}
  .pj-rc .tx{min-width:0} .pj-rc .t{font-size:13.5px;font-weight:600;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .pj-rc .s{font-size:12px;line-height:1.4;color:var(--t3)}
  .pj-rc:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-rc:hover{background:var(--card-hi)}}
  /* The result a comment line names, as a way to it. */
  .pj-lk{font:inherit;color:inherit;text-decoration:underline;text-underline-offset:3px;text-decoration-color:color-mix(in srgb,currentColor 45%,transparent);cursor:pointer}
  /* What the list's search found inside the records, under the sessions it found by name. */
  .pj-talk{margin:12px 0 8px}
  .pj-talk .h{padding:0 12px 4px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-tk{display:block;width:100%;min-height:44px;padding:8px 12px;border-radius:var(--r-lg);text-align:left}
  .pj-tk .t{display:flex;gap:6px;font-size:13px;font-weight:600;line-height:1.4;color:var(--t1)} .pj-tk .t span{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .pj-tk .t i{flex:none;font-style:normal;font-weight:500;color:var(--t3)}
  .pj-tk .x{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:2px;font-size:12.5px;line-height:1.45;color:var(--t3);overflow-wrap:anywhere}
  .pj-tk mark{background:none;color:var(--t1);font-weight:600}
  .pj-tk:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){.pj-tk:hover{background:var(--card-hi)}}
  .pj-files.pj-chgs .rw{display:block;padding:0} .pj-chgs .rw>button{display:flex;gap:8px;width:100%;min-height:44px;align-items:center;padding:8px 2px;text-align:left;cursor:pointer}
  .pj-files.pj-chgs .dv,.pj-files.pj-chgs .dv div{display:block;min-width:0;padding:0;border-top:0;font-size:inherit}
  .pj-files.pj-chgs .dv{padding-bottom:8px} .pj-files.pj-chgs .pj-diff{border:1px solid var(--line);font-size:12px} .pj-files.pj-chgs .pj-diff>div{padding:0 8px;min-width:max-content}
  @media(pointer:coarse){.pj-msg.act>.ah{min-height:44px}.pj-msg.act .an button::after{content:"";position:absolute;inset:-12px -6px}}
  /* The session's task list, on demand: one quiet line above the box that opens on the items. */
  .pj-todo{padding:6px 12px 0;font-size:12px;line-height:18px;color:var(--t3)} .pj-todo[hidden]{display:none}
  .pj-todo>button{display:flex;align-items:center;gap:6px;max-width:100%;min-width:0;padding:2px 6px;margin-left:-6px;border-radius:6px;color:inherit;text-align:left;cursor:pointer}
  .pj-todo>button:hover{background:var(--btn);color:var(--t2)}
  .pj-todo>button b{flex:none;font-weight:600;color:var(--t2);font-variant-numeric:tabular-nums}
  .pj-todo>button span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-todo>button svg{width:12px;height:12px;flex:none;transform:rotate(90deg)} .pj-todo>button[aria-expanded="true"] svg{transform:rotate(-90deg)}
  .pj-todo ul{list-style:none;margin:2px 0 4px;padding:0;max-height:min(40vh,260px);overflow-y:auto}
  .pj-todo li{display:flex;gap:8px;padding:2px 0;color:var(--t2);overflow-wrap:anywhere}
  .pj-todo li::before{content:"";flex:none;width:10px;height:10px;margin-top:4px;border-radius:50%;border:1.5px solid var(--t3);box-sizing:border-box}
  .pj-todo li.in_progress{color:var(--t1)} .pj-todo li.in_progress::before{border-color:var(--accent,var(--t1));background:radial-gradient(var(--accent,var(--t1)) 38%,transparent 42%)}
  .pj-todo li.completed{color:var(--t3);text-decoration:line-through} .pj-todo li.completed::before{background:var(--t3)}
  @media(pointer:coarse){.pj-todo>button{min-height:44px}}
  /* When a line was said, small and quiet, the way a messenger shows it: beside my bubble (which
     leaves room for it), under what the session wrote. A run from one side within a minute shows
     it once, on its last line; a new day gets a line of its own across the log. */
  .pj-tm{font-size:12px;line-height:16px;font-weight:400;letter-spacing:0;color:var(--t3);font-variant-numeric:tabular-nums;
    white-space:nowrap;-webkit-user-select:none;user-select:none}
  .pj-tm[hidden]{display:none}
  .pj-msg.user{position:relative;max-width:min(88%,calc(100% - 72px))}
  .pj-msg.user>.pj-tm{position:absolute;right:100%;bottom:0;margin-right:6px}
  .pj-msg.claude>.pj-tm{display:block;margin-top:4px}
  .fl-body .pj-msg.claude>.pj-tm{display:none}
  .pj-day{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:var(--fs-meta);line-height:16px;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-day:before,.pj-day:after{content:"";flex:1;height:1px;background:var(--line)}
  /* The session's lines are read as markdown (markdown.js, the same reader as a pushed document). */
  .pj-md{white-space:normal}
  /* Reading: a paragraph apart from the next by most of a line, list rows apart, headings a size up,
     the bold words at full weight. One block run into the next read as a wall of text. */
  .pj-md p,.pj-md ul,.pj-md ol{margin:0 0 12px}
  .pj-md li{margin:6px 0}.pj-md li>:is(p,ul,ol){margin-bottom:6px}
  .pj-md h1,.pj-md h2{font-size:1.2em;font-weight:700;line-height:1.4;margin:20px 0 8px}
  .pj-md h3,.pj-md h4{font-size:1.08em;font-weight:700;line-height:1.45;margin:16px 0 6px}
  .pj-md strong{font-weight:700}
  .pj-md>:first-child{margin-top:0}.pj-md>:last-child{margin-bottom:0}
  .pj-md code,.pj-msg.tool{font-family:ui-monospace,Menlo,Consolas,"Pretendard Variable",monospace}
  .pj-md code{font-size:12px}
  .pj-md pre{max-width:100%;margin:0 0 6px}
  /* A word said in code is a small chip in a warm tone, so it stands out of the sentence around it. */
  .pj-md :not(pre)>code{padding:1px 5px;border-radius:6px;background:color-mix(in srgb,var(--t1) 7%,transparent);box-shadow:inset 0 0 0 1px var(--line);
    color:color-mix(in srgb,var(--red) 72%,var(--t1))}
  /* A table: one rounded frame, rows parted by a line, the head quiet, the first column the row's name.
     A cell folds between words (the chat's own break-anywhere crushed a narrow column to "Op / us");
     the frame scrolls only when a single word is wider than the room. */
  .pj-md .doc-table{max-width:100%;margin:0 0 12px;border-radius:12px;box-shadow:inset 0 0 0 1px var(--line);overflow-x:auto}
  .pj-md table{width:100%;border-collapse:collapse;font-size:.93em;line-height:1.5}
  /* A table wider than its room: the side it goes on to fades out (a phone shows no scroll bar, so
     eight columns looked cut off at the fourth). Only while it scrolls; one that fits has no timeline. */
  @property --pj-tl{syntax:"<length>";inherits:false;initial-value:0px}
  @property --pj-tr{syntax:"<length>";inherits:false;initial-value:0px}
  @supports (animation-timeline:scroll()){
    .pj-md .doc-table{-webkit-mask-image:linear-gradient(to right,transparent,#000 var(--pj-tl),#000 calc(100% - var(--pj-tr)),transparent);mask-image:linear-gradient(to right,transparent,#000 var(--pj-tl),#000 calc(100% - var(--pj-tr)),transparent);animation:pj-tedge linear both;animation-timeline:scroll(self inline)}
    @keyframes pj-tedge{0%{--pj-tl:0px;--pj-tr:28px}8%,92%{--pj-tl:28px;--pj-tr:28px}100%{--pj-tl:28px;--pj-tr:0px}}
  }
  .pj-md th,.pj-md td{border:0;border-top:1px solid var(--line);padding:10px 12px;text-align:left;vertical-align:top;overflow-wrap:break-word;word-break:keep-all}
  .pj-md thead th{border-top:0;font-weight:500;color:var(--t2);background:color-mix(in srgb,var(--t1) 5%,transparent)}
  .pj-md td:first-child{font-weight:700}
  /* Code in a cell folds anywhere, so it is plain warm text there (a chip broken over six lines read as
     a stack of boxes) and its column keeps a floor: a cramped table scrolls a little before it goes four letters wide. */
  .pj-md td code{overflow-wrap:anywhere;padding:0;background:none;box-shadow:none}
  .pj-md td:has(code){min-width:112px}
  /* Copy: one small button per line of the chat (beside the bubble, in the room it leaves free)
     and one per code block. A pointer shows it on hover or focus and it fades where it is; a
     finger holds the line (or the code block) instead, so it has no button there. */
  .pj-msg.claude{position:relative}
  .pj-cp{position:absolute;display:grid;place-items:center;width:28px;height:24px;border-radius:var(--rad-ctl);color:var(--t3);opacity:0;transition:opacity .14s ease,background-color .14s ease,color .14s ease}
  .pj-cp svg{width:14px;height:14px;fill:currentColor}
  .pj-msg.claude>.pj-cp{left:100%;top:0}
  .pj-msg.user>.pj-cp{right:100%;top:-4px}
  /* A code block: a head with its name and the copy button (always there, a finger has it too), and
     the code wrapped under it. Long lines fold: nothing in the chat slides sideways. */
  .pj-prew{position:relative;max-width:100%;margin:0 0 12px;border-radius:12px;overflow:hidden;box-shadow:inset 0 0 0 1px var(--line)}
  .pj-prew::before{content:attr(data-l);display:block;height:36px;padding:0 48px 0 12px;font-size:12px;font-weight:500;line-height:36px;color:var(--t3);background:color-mix(in srgb,var(--t1) 5%,transparent);
    border-bottom:1px solid var(--line);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}
  .pj-md .pj-prew pre{margin:0;padding:10px 12px;border-radius:0;white-space:pre-wrap;overflow-wrap:anywhere;word-break:normal;line-height:1.55}
  .pj-prew>.pj-cp{right:4px;top:4px;width:28px;height:28px;opacity:1}
  .pj-cp:focus-visible{opacity:1;outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-msg:hover>.pj-cp,.pj-prew:hover>.pj-cp{opacity:1}.pj-cp:hover{color:var(--t1);background:var(--btn)}}
  /* A finger: the code's button is a 44px press; the last answer keeps one copy button under it
     (the older lines are held instead). */
  @media(pointer:coarse){.pj-msg>.pj-cp{display:none}
    .pj-prew::before{height:44px;line-height:44px;font-size:13px}
    .pj-prew>.pj-cp{right:0;top:0;width:44px;height:44px}.pj-prew>.pj-cp svg{width:18px;height:18px}
    .pj-msgs>.pj-msg.claude:nth-last-child(1 of .pj-msg.claude)>.pj-cp{display:grid;position:static;opacity:1;width:44px;height:44px;margin:4px 0 -8px -13px}
    .pj-msgs>.pj-msg.claude:nth-last-child(1 of .pj-msg.claude)>.pj-cp svg{width:18px;height:18px}}
  @media(prefers-reduced-motion:reduce){.pj-cp{transition:none}}
  /* A line of mine on its way: it is on the screen at once, dimmed with a small ring until the
     server has it; one that did not get through stays, outlined, with the way to send it again. */
  .pj-msg.pending{opacity:.68}
  .pj-msg .tg{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:4px;font-size:12px;line-height:16px;color:var(--t3);
    font-family:inherit;white-space:nowrap;height:auto;min-height:0;max-width:none;padding:0;border-radius:0;background:none;font-weight:400}
  .pj-msg .tg .pj-spin{width:9px;height:9px}
  .pj-msg.failed{box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--red) 60%,transparent)}
  .pj-msg .tg.bad{color:var(--red);flex-wrap:wrap;white-space:normal;margin-top:6px}
  .pj-msg .tg.bad svg{width:12px;height:12px;flex:none}
  .pj-msg .tg button{min-height:var(--g-hit);padding:0 var(--sp-3);border-radius:var(--rad-ctl);background:var(--bg);color:var(--t1);font-size:var(--fs-body);font-weight:var(--fw-b)}
  .pj-msg .tg button:hover{background:var(--card)}
  /* The message box is one field: picture, text and send inside a single border. Focus is the
     field's own edge taking the accent with a soft ring around it (v2.css --focus-line/--focus-glow),
     not a heavy outline on the text area alone. */
  .pj-in{padding:8px 12px 12px;border-top:1px solid var(--line)}
  .pj-box{display:flex;align-items:flex-end;gap:2px;padding:4px;border-radius:12px;background:var(--bg);border:1px solid var(--line);cursor:text;
    transition:border-color .14s ease,box-shadow .14s ease}
  @media(hover:hover){.pj-box:hover:not(:focus-within){border-color:color-mix(in srgb,var(--t4) 70%,transparent)}}
  .pj-box:focus-within{border-color:var(--focus-line);box-shadow:0 0 0 3px var(--focus-glow)}
  .pj-go{flex:none;width:34px;height:34px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;
    background:var(--t1);color:var(--bg);transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  .pj-go svg{width:17px;height:17px}
  .pj-go .pj-spin{display:none}
  @media(hover:hover){.pj-go:hover:not(:disabled){background:color-mix(in srgb,var(--t1) 86%,var(--bg))}}
  .pj-go:active:not(:disabled){background:color-mix(in srgb,var(--t1) 74%,var(--bg))}
  .pj-go:disabled{background:var(--btn);color:var(--t3);box-shadow:inset 0 0 0 1px var(--line);cursor:default}
  .pj-go.busy:disabled svg{display:none} .pj-go.busy:disabled .pj-spin{display:block}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-go{width:var(--g-hit);height:var(--g-hit)}.pj-box .pj-clip{width:36px;height:36px}
    /* The send button is drawn at the 44px a finger needs. */
    .pj-go{position:relative}.pj-go::before{content:"";position:absolute;inset:-4px;border-radius:50%}}
  html[data-theme="light"] .pj-go:not(:disabled){background:#111114;color:#fff}
  @media(hover:hover){html[data-theme="light"] .pj-go:hover:not(:disabled){background:#2a2a30}}
  html[data-theme="light"] .pj-go:active:not(:disabled){background:#3a3a41}
  @media(prefers-reduced-motion:reduce){.pj-box,.pj-go,.pj-clip{transition:none}}
  /* Who receives the next message: one line, the same wherever something is about to be sent. */
  .pj-to{display:flex;align-items:center;gap:6px;min-width:0;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-to:empty{display:none}
  .pj-to .k{flex:none} .pj-to .pj-em{flex:none;font-size:13px;width:auto} .pj-to .pj-ag{flex:none}
  .pj-to b{flex:0 1 auto;min-width:0;font-weight:600;color:var(--t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-to .s{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-conv>.pj-to{padding:8px 12px 0;border-top:1px solid var(--line)}
  /* 가림 모드 is on: said once, quietly, over the box, with the way back beside it. */
  .pj-rd{display:flex;align-items:center;gap:6px;padding:6px 12px 0;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-rd[hidden]{display:none}
  .pj-rd svg{flex:none;width:14px;height:14px}
  .pj-rd button{position:relative;font-weight:600;color:var(--t2);text-decoration:underline;text-underline-offset:3px}
  .pj-rd button::after{content:"";position:absolute;inset:-13px -10px}
  .pj-rd+.pj-to{border-top:0;padding-top:2px}
  .pj-conv>.pj-to+.pj-in{border-top:0;padding-top:6px}
  .pj-all+.pj-to{padding:6px 12px 0} .pj-nfoot .pj-to{margin-bottom:6px}
  .pj-head .ow{display:flex;align-items:center;gap:6px;min-width:0;max-width:100%;margin-top:4px;padding:0;font-size:12px;color:var(--t3);text-align:left}
  .pj-head .ow .t{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--t2)}
  .pj-head .ow .k,.pj-head .ow .st{flex:none}
  .pj-gh .pj-gn{display:inline-flex;align-items:center;width:22px;height:22px;justify-content:center;border-radius:6px;color:var(--t4)}
  .pj-gh .pj-gn svg{width:13px;height:13px}
  @media(hover:hover){.pj-gh .pj-gn:hover{background:var(--btn);color:var(--t1)}}
  .pj-in textarea{flex:1;min-width:0;resize:none;background:none;border:0;border-radius:0;color:var(--t1);outline:none;
    font:inherit;font-size:14.5px;line-height:1.5;letter-spacing:inherit;word-break:keep-all;overflow-wrap:anywhere;
    padding:6px 6px;min-height:34px;max-height:160px}
  .pj-in textarea::placeholder{color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-item{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:8px 12px;border-radius:8px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-item:hover{background:var(--card-hi)}
  .pj-item .tx{flex:1;min-width:0}
  .pj-item .t{font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-item .s{font-size:12px;color:var(--t3);margin-top:1px}
  .pj-item .cm{font-size:12px;font-weight:600;color:var(--orange)}
  .pj-cur{display:flex;align-items:center;gap:8px;width:100%;background:var(--card);border-radius:var(--r-card);padding:12px 16px;text-align:left;min-width:0}
  .pj-cur .t{flex:1;min-width:0;font-size:14.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-cur .s{font-size:12px;color:var(--t3)}
  .pj-dlg h3{margin:2px 0 4px;font-size:16px;font-weight:600;letter-spacing:-.01em;line-height:1.4}
  .pj-dlg .acts{display:flex;flex-direction:column;gap:6px;margin-top:20px}
  @media(pointer:coarse){.pj-dlg .acts .pj-btn{min-height:44px}}
  .pj-dlg .row2{display:flex;gap:6px;justify-content:center}
  .pj-access .hint{white-space:normal;overflow-wrap:anywhere}
  .pj-access dl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px 16px;margin:20px 0}
  .pj-access-run dl{margin-top:0;padding-top:20px;border-top:1px solid var(--line)}
  .pj-access dt,.pj-access dd{margin:0;overflow-wrap:anywhere}
  .pj-access dd{color:var(--t2);text-align:right}
  .pj-access [data-access-settings]{min-height:44px;width:100%;white-space:normal;margin-top:12px}
  .pj-dot.stuck{background:var(--red)}
  .pj-un{flex:none;min-width:18px;height:18px;padding:0 4px;border-radius:8px;background:var(--blue);color:#fff;font-size:12px;font-weight:700;line-height:18px;text-align:center}
  .pj-rbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 8px;margin:0 0 8px;padding:8px 12px;border-radius:var(--r-sm);background:var(--btn);font-size:12px;line-height:1.5;color:var(--t2)}
  .pj-rbar>span:first-child{flex:1 1 180px;min-width:0}.pj-rbar .a{display:flex;gap:6px;flex:none}
  .pj-rbar .pj-btn{height:30px;padding:0 12px;font-size:12px}
  .pj-conv>.pj-rbar{flex:none;margin:0 12px 8px}
  .pj-note{padding:8px 16px;font-size:12px;line-height:1.5;color:var(--t2);border-bottom:1px solid var(--line);background:var(--card)}
  .pj-note.bad{color:var(--red)}
  .pj-note:empty{display:none} .pj-note>div{text-wrap:balance;word-break:keep-all;overflow-wrap:anywhere}
  .pj-note b{font-weight:600;color:var(--t1)}
  .pj-files{display:flex;flex-direction:column;margin:8px 0 2px;max-height:52vh;overflow:auto}
  .pj-files div{display:flex;gap:8px;padding:8px 2px;border-top:1px solid var(--line);font-size:13px;min-width:0}
  .pj-files .p{flex:1;min-width:0;overflow-wrap:anywhere;color:var(--t1)}
  .pj-files .n{flex:none;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-log{margin:8px 0 0;padding:12px;max-height:56vh;overflow:auto;background:var(--bg);border-radius:8px;
    font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;color:var(--t2);white-space:pre-wrap;overflow-wrap:anywhere}
  .pj-unread{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600;letter-spacing:.08em;color:var(--red);flex:none}
  .pj-unread:before,.pj-unread:after{content:"";flex:1;height:1px;background:currentColor;opacity:.35}
  .pj-att{display:flex;gap:8px;flex-wrap:wrap;padding:8px 12px 0}
  .pj-att .th{position:relative;width:56px;height:56px;border-radius:8px;overflow:hidden;background:var(--bg)}
  .pj-att img{width:100%;height:100%;object-fit:cover;display:block}
  .pj-att .th.doc{display:flex;align-items:center;gap:6px;width:auto;height:36px;max-width:min(220px,100%);padding:0 8px 0 10px;border:1px solid var(--line);font-size:12px;color:var(--t2)}
  .pj-att .th.doc button{position:relative;top:auto;right:auto;flex:none} @media(pointer:coarse){.pj-att .th.doc{height:44px}}
  .pj-att .th.doc>svg{flex:none;width:14px;height:14px;color:var(--t3)} .pj-att .th.doc span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-att button{position:absolute;top:2px;right:2px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;
    display:inline-flex;align-items:center;justify-content:center}
  .pj-att button svg{width:11px;height:11px}
  /* Pictures stand on their own above the words (mine: on the right), a tidy row of the same height. */
  .pj-pics{align-self:flex-end;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px;max-width:min(88%,460px);min-width:0}
  .pj-pics+.pj-msg{margin-top:-6px}
  .pj-pics.pending{opacity:.68}
  /* What the session sent (SendUserFile) sits on its side of the chat: pictures open in the viewer, other files in a tab. */
  .pj-pics.sent{align-self:flex-start;justify-content:flex-start}
  .pj-sent{align-self:flex-start;display:flex;flex-wrap:wrap;gap:6px;max-width:min(88%,460px);min-width:0}
  .pj-file{display:inline-flex;align-items:center;gap:6px;min-width:0;max-width:100%;min-height:32px;padding:4px 12px;border:1px solid var(--line);border-radius:10px;color:var(--t1);font-size:13px;text-decoration:none}
  .pj-file span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-file svg{flex:none;width:14px;height:14px;color:var(--t3)}
  @media(pointer:coarse){.pj-file{min-height:44px}}
  .pj-pic{flex:none;display:flex;justify-content:center;height:132px;min-width:72px;max-width:100%;padding:0;border-radius:12px;overflow:hidden;background:var(--btn);cursor:zoom-in}
  .pj-pics.one .pj-pic{height:200px}
  .pj-pic img{display:block;flex:none;height:100%;width:auto}
  .pj-md img{display:block;max-width:min(100%,360px);max-height:240px;margin:6px 0;border-radius:12px;cursor:zoom-in}
  /* What the session is doing right now, under the newest line. It keeps its room when it goes
     quiet, so the log does not move when the work ends. */
  .pj-now{align-self:flex-start;display:flex;align-items:center;gap:8px;max-width:100%;min-width:0;height:20px;font-size:12px;line-height:20px;color:var(--t3);transition:opacity .18s ease}
  .pj-now:not(.on){opacity:0;pointer-events:none}
  .pj-now .mk{flex:none;display:flex;align-items:center;--orb-ink:var(--sr-work,var(--t2))}
  .pj-now .mk i.st-dot{width:8px;height:8px;margin:0 3px 0 0;border-radius:50%;background:var(--sr-work,var(--t2))}
  .pj-now .tx{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--t2)}
  /* A row that carries a button (a line the session is holding) grows to fit it. */
  .pj-now:has([data-peeraccept]){height:auto}
  .pj-now .tx:has([data-peeraccept]){display:flex;align-items:center;gap:10px;overflow:visible}
  .pj-now .tx span{color:var(--t3)}
  .pj-now.bad{height:auto;align-items:flex-start}
  .pj-now.bad .tx{white-space:normal;color:var(--red)}
  .pj-now.bad .mk{color:var(--red);padding-top:4px}
  .pj-now.bad .mk svg{width:13px;height:13px}
  /* not ".sec": that is the app's section-label class (a margin and a heavier weight) */
  .pj-now .nsec{flex:none;margin:0;white-space:pre;font-variant-numeric:tabular-nums;text-transform:none;letter-spacing:0;font:inherit;line-height:20px;color:var(--t3)}
  .pj-conv.drop{outline:2px dashed var(--t4);outline-offset:-6px}
  .pj-clip{flex:none;width:34px;height:34px;border-radius:8px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center;
    transition:background-color .14s ease,color .14s ease}
  .pj-clip:hover{background:var(--btn);color:var(--t1)}
  .pj-clip svg{width:18px;height:18px}
  /* Speaking into the box. The mic sits beside send. While it listens the row is only what the
     words need: take them away, the level, stop (the words stay), send (they go at once). */
  .pj-mic .i+.i,.pj-vx,.pj-wave{display:none}
  .pj-in .pj-box.pj-rec :is(#pj-clip,.pj-mwrap,.pj-pjn,.pj-enter,.pj-agseg){display:none}
  .pj-in .pj-box.pj-rec .pj-vx{display:inline-flex}
  .pj-in .pj-box.pj-rec :is(.pj-vx,.pj-mic){border:0;border-radius:50%;background:var(--btn);color:var(--t1)}
  @media(hover:hover){.pj-in .pj-box.pj-rec :is(.pj-vx,.pj-mic):hover{background:var(--btn-hi)}}
  .pj-box.pj-rec .pj-mic .i{display:none}.pj-box.pj-rec .pj-mic .i+.i{display:block;width:14px;height:14px}
  .pj-box.pj-rec .pj-wave{flex:1 1 0;min-width:0;height:34px;display:flex;align-items:center;justify-content:flex-end;gap:3px;padding:0 8px;overflow:hidden}
  .pj-wrap{position:relative}
  /* The way down to the newest line: a round button over the log's bottom edge, there only while
     the end is out of sight. Lines that arrived meanwhile are a count on it, not a second control. */
  .pj-newpill{position:absolute;left:50%;bottom:12px;width:32px;height:32px;margin-left:-16px;border-radius:50%;
    display:grid;place-items:center;background:var(--btn-hi);color:var(--t1);
    box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--t1) 16%,transparent),0 4px 14px rgba(0,0,0,.32);
    opacity:0;visibility:hidden;translate:0 4px;transition:opacity .14s ease,translate .14s ease,background-color .14s ease,visibility 0s .14s}
  .pj-newpill.on{opacity:1;visibility:visible;translate:none;transition-delay:0s}
  .pj-newpill svg{width:16px;height:16px;transform:rotate(180deg)}
  .pj-newpill b{position:absolute;top:-7px;right:-9px;min-width:17px;height:17px;padding:0 4px;border-radius:8px;display:grid;place-items:center;
    background:var(--blue);color:var(--on-blue,#fff);font-size:12px;font-weight:700;line-height:1;font-variant-numeric:tabular-nums;box-shadow:0 0 0 2px var(--card)}
  .pj-newpill b:empty{display:none}
  .pj-newpill:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  .pj-msgs:focus{outline:none}
  /* Find in this conversation (Ctrl+F, or its menu): a bar over the log's top edge that fades in
     place. Matches are marked by the highlight API, so no line is drawn again for it. */
  .pj-find{position:absolute;top:8px;right:12px;z-index:3;display:flex;align-items:center;gap:2px;max-width:calc(100% - 24px);padding:4px 4px 4px 12px;border-radius:12px;
    background:var(--btn-hi);color:var(--t1);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--t1) 16%,transparent),0 4px 14px rgba(0,0,0,.32);
    opacity:0;visibility:hidden;transition:opacity .14s ease,visibility 0s .14s}
  .pj-find.on{opacity:1;visibility:visible;transition-delay:0s}
  .pj-find>svg{flex:none;width:15px;height:15px;color:var(--t3)}
  .pj-find input{flex:1 1 auto;min-width:0;width:190px;height:30px;padding:0 6px;border:0;background:none;color:inherit;font:inherit;font-size:14px;outline:none}
  .pj-find input::-webkit-search-cancel-button{display:none}
  .pj-find .n{flex:none;min-width:36px;text-align:right;font-size:12px;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap}
  .pj-find button{flex:none;width:30px;height:30px;border-radius:8px;display:grid;place-items:center;color:var(--t2)}
  .pj-find button:hover{background:var(--btn);color:var(--t1)}
  .pj-find button:disabled{color:var(--t4);background:none}
  .pj-find button svg{width:15px;height:15px}
  .pj-find [data-fd="1"] svg{transform:rotate(180deg)}
  ::highlight(pj-find){background-color:color-mix(in srgb,var(--blue) 32%,transparent);color:inherit}
  ::highlight(pj-find-on){background-color:var(--blue);color:var(--on-blue,#fff)}
  @media (prefers-reduced-motion:reduce){.pj-find{transition:none}}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    .pj-find{left:10px;right:10px;max-width:none;padding-left:12px}
    .pj-find input{width:auto;height:40px;font-size:16px}
    .pj-find button{width:44px;height:44px}}
  @media(hover:hover){.pj-newpill:hover{background:color-mix(in srgb,var(--t1) 12%,var(--btn-hi))}}
  @media(pointer:coarse){.pj-newpill::after{content:"";position:absolute;inset:-6px}}
  @media(prefers-reduced-motion:reduce){.pj-newpill{translate:none;transition:opacity .14s ease,visibility 0s .14s}}
  .pj-tip{display:flex;align-items:center;gap:8px;padding:8px 16px;font-size:12px;color:var(--t2);border-bottom:1px solid var(--line)}
  .pj-tip[hidden]{display:none}
  .pj-tip span{flex:1;min-width:0}
  .pj-tip button{flex:none;width:24px;height:24px;border-radius:6px;color:var(--t3);display:inline-flex;align-items:center;justify-content:center}
  .pj-tip button:hover{background:var(--btn);color:var(--t1)}
  .pj-tip svg{width:12px;height:12px}
  .pj-spin{flex:none;width:12px;height:12px;border-radius:50%;border:1.5px solid var(--t4);border-top-color:var(--t1);animation:pj-turn .9s linear infinite}
  @keyframes pj-turn{to{transform:rotate(360deg)}}
  @media(prefers-reduced-motion:reduce){.pj-spin{animation:none}}
  .pj-state .off{color:var(--orange);font-size:12px}
  .pj-msg .tg.ok{color:var(--green)}
  .pj-rail{min-width:0}
  .pj-rail .pj-lab:first-child{margin-top:4px}
  .pj-row{padding:8px 12px;gap:4px;border-radius:8px;margin-bottom:4px}
  .pj-row .t{font-size:13px;-webkit-line-clamp:1}
  .pj-row .r1{align-items:center;gap:8px}
  .pj-row .r2{gap:6px;font-size:11.5px}
  .pj-row .pj-more{margin:-2px -4px -2px 0}
  .pj-fold{display:flex;align-items:center;gap:6px;width:100%;padding:8px 2px;margin-top:4px;font-size:12px;color:var(--t3);text-align:left}
  .pj-fold:hover{color:var(--t1)}
  .pj-unl{display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;padding:8px 2px 4px;margin-top:4px;font-size:12px;line-height:1.5;color:var(--t3)}
  .pj-unl>span{flex:1 1 180px;min-width:0;word-break:keep-all}
  .pj-unl .pj-text{flex:none;height:28px;padding:0 8px;margin:0 -8px 0 0;font-size:12px;color:var(--t2)}
  .pj-fold svg{width:12px;height:12px;transition:transform .2s cubic-bezier(.2,.9,.25,1)}
  .pj-fold[aria-expanded="true"] svg{transform:rotate(90deg)}
  @media(pointer:coarse){.pj-fold{min-height:40px}}   /* 33px rows 4px apart on the pick page: 44px from one to the next now */
  .pj-res{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:8px;border-radius:12px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-res:hover{background:var(--card-hi)}
  .pj-res .th{position:relative;flex:none;width:64px;height:64px;border-radius:8px;overflow:hidden;background:var(--bg);
    display:flex;align-items:center;justify-content:center;color:var(--t3)}
  .pj-res .th svg{width:22px;height:22px}
  .pj-res .th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
  .pj-res .th .play{position:absolute;right:4px;bottom:4px;width:18px;height:18px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;
    display:flex;align-items:center;justify-content:center}
  .pj-res .th .play svg{width:10px;height:10px}
  .pj-res .tx{flex:1;min-width:0}
  .pj-res .t{font-size:13px;font-weight:600;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
  .pj-res .s{font-size:12px;color:var(--t3);margin-top:2px}
  .pj-head{position:relative}
  .pj-top{display:flex;align-items:center;gap:8px;margin:4px 0 2px;flex-wrap:wrap;min-width:0}
  .pj-top .sp{flex:1}
  /* Phone: search and 새 세션 share the first row, the quieter links the second. */
  @media(max-width:479px){.pj-top .pj-search{order:-2;flex:1 1 calc(100% - 120px)}.pj-top .pj-search~[data-new]{order:-1}}
  /* On a phone the row's buttons stand as tall as the search field beside them (44 beside 36 and 34). */
  @media(max-width:479px){.pj-top :is(.pj-btn,.pj-text){min-height:44px}}
  .pj-search{flex:1;min-width:0;height:36px;padding:0 12px;border-radius:8px;background:var(--card);border:1px solid var(--line);
    color:var(--t1);font:inherit;font-size:14px}
  .pj-search::placeholder{color:var(--t3)}
  .pj-search:focus{outline:none;border-color:var(--focus-line);box-shadow:0 0 0 3px var(--focus-glow)}
  .pj-em{display:inline-flex;align-items:center;justify-content:center;flex:none;width:24px;height:24px;font-size:16px;line-height:1;overflow:hidden;white-space:nowrap}
  .pj-head .em{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;overflow:hidden;white-space:nowrap}
  .sbox.pj-wide{overflow:hidden}
  .sbox.pj-wide>.pj-new{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.sbox.pj-wide{width:min(880px,calc(100vw - 48px))}}
  .pj-ntop{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
  .pj-dlg .pj-ntop .seg,.pj-dlg .pj-nrow .seg,.pj-dlg .pj-nfoot>div>.seg{margin-top:0}
  .pj-dlg .pj-ntop .pj-search{flex:1 1 180px;width:auto}
  .pj-pg{flex:1 1 auto;min-height:132px;overflow-y:auto;overscroll-behavior:contain;margin:8px -6px 0;padding:0 6px 8px}
  .pj-pgg{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
  /* Phone, 새로 만들기 open: the box left the list a strip. The sheet's body scrolls as one and the foot stays in view. */
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.sbox.pj-wide>.pj-new:has(>.pj-mkbox:not([hidden])){overflow-y:auto;overscroll-behavior:contain}
    .pj-new:has(>.pj-mkbox:not([hidden]))>.pj-pg{flex:none;min-height:0;overflow:visible;display:flex;flex-direction:column;margin:8px 0 0;padding:0 0 8px}   /* no side bleed here: nothing clips it, so it would make the sheet scroll sideways */
    .pj-pg>.pj-gh:has(+.pj-pgg>.pj-mk),.pj-pg>.pj-pgg:has(>.pj-mk){order:-1} .pj-pgg:has(>.pj-mk){grid-template-columns:minmax(0,1fr)}   /* the one being made shows first, under its box */
    .pj-new:has(>.pj-mkbox:not([hidden]))>.pj-nfoot{position:sticky;bottom:0;z-index:1;background:var(--card)}}
  @media(min-width:640px){.pj-pgg{grid-template-columns:repeat(3,minmax(0,1fr))}}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.pj-pgg{grid-template-columns:repeat(4,minmax(0,1fr))}}
  .pj-gh{display:flex;align-items:center;gap:6px;position:sticky;top:0;z-index:1;background:var(--card);padding:8px 2px 4px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-gh .n{color:var(--t4);font-variant-numeric:tabular-nums} .pj-gh .sp{flex:1}
  .pj-gh .pj-text{height:26px;padding:0 8px;font-size:12px}
  .pj-pc{display:flex;align-items:center;gap:8px;min-width:0;height:44px;padding:0 8px;border-radius:8px;background:var(--bg);border:1px solid transparent;
    text-align:left;font-size:13px;color:var(--t1);transition:background .15s,border-color .15s}
  .pj-pc:hover{background:var(--btn)}
  .pj-pc.on{background:var(--btn-hi);border-color:var(--t4)}
  .pj-pc.pj-mk{border:1px dashed var(--line2,var(--t4))}
  .pj-pc.pj-mk.on{border-style:solid}
  .pj-pc.pj-mk .pj-em svg{width:16px;height:16px}
  .pj-pc:focus-visible{outline:2px solid var(--t2);outline-offset:1px}
  .pj-pc .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-pc .pj-ck{width:18px;height:18px;opacity:0;transform:scale(.5);
    transition:transform .45s linear(0,.19 6%,.56 14%,.85 22%,1.01 30%,1.06 38%,1.05 46%,1.02 56%,1 68%,1),opacity .15s}
  .pj-pc.on .pj-ck{opacity:1;transform:none;background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-nfoot{flex:none;border-top:1px solid var(--line);padding-top:8px}
  .pj-nfoot .pj-ta2{min-height:56px;margin-top:0}
  .pj-nfoot [data-modebox]:not(:empty){margin-bottom:8px}
  .pj-nfoot .pj-hint{margin-top:8px;word-break:keep-all;overflow-wrap:anywhere} .pj-nfoot .pj-hint.err{color:var(--red)}
  .pj-nrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
  /* The very first chat (from the home guide, no project yet): the line and one button. The rest waits behind 더 보기. */
  .pj-first .pj-search,.pj-first .pj-mkbtn,.pj-first .pj-mkbox,.pj-first .pj-pg,.pj-first .pj-to,.pj-first [data-modelbox]{display:none!important}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.sbox.pj-wide:has(>.pj-first){width:min(480px,calc(100vw - 48px))}}
  .pj-first .pj-nfoot{border-top:0;padding-top:12px} .pj-first .pj-ta2{min-height:72px}
  .pj-new:not(.pj-first) [data-more]{display:none}
  .pj-nrow .sp{flex:1} .pj-nrow .pj-btn{min-width:112px}
  .pj-nrow>[data-modelbox]{min-width:0;max-width:100%;display:flex;flex-direction:column;align-items:flex-start}
  .pj-nrow>[data-modelbox][hidden]{display:none}
  .pj-new .pj-nrow{align-items:flex-start}
  @media(max-width:639px){.pj-nrow>[data-modelbox]{flex:1 1 100%;align-items:stretch}.pj-nrow>[data-modelbox] .seg{display:flex}.pj-nrow>[data-modelbox] .seg button{flex:1 1 auto;min-width:0;padding-left:6px;padding-right:6px}}
  .pj-mcap{margin:6px 2px 0;font-size:12px;line-height:1.4;color:var(--t3)}
  .pj-mcap:empty{display:none}
  @media(max-width:639px){.pj-nrow .pj-btn{flex:1 1 100%}.pj-nrow .sp{display:none}}
  .pj-pg.pj-res{display:flex;flex-direction:column;gap:4px}
  .pj-rr{display:flex;align-items:center;gap:8px;flex:none;width:100%;min-height:48px;padding:6px 12px;border-radius:8px;background:var(--bg);text-align:left;transition:opacity .2s,background .15s}
  button.pj-rr:hover{background:var(--btn)}
  .pj-rr .tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .pj-rr .t{font-size:14px;color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-rr .s{font-size:12px;line-height:1.45;color:var(--t3);word-break:keep-all;overflow-wrap:break-word}
  .pj-rr.wait{opacity:.55} .pj-rr.new .s,.pj-rr.keep .s{color:var(--t2)} .pj-rr.fail .s{color:var(--red)}
  .pj-rr .pj-ck{background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-rr .pj-ck.no{background:none;border-color:var(--t4);color:var(--t2);font-size:12px;font-weight:700}
  @media(prefers-reduced-motion:reduce){.pj-pc .pj-ck{transform:none;transition:opacity .2s}}
  .pj-badge{flex:none;min-width:20px;height:20px;padding:0 6px;border-radius:8px;background:var(--red);color:#fff;
    font-size:12px;font-weight:700;letter-spacing:0;display:inline-flex;align-items:center;justify-content:center;font-variant-numeric:tabular-nums}
  .pj-last{font-size:13px;line-height:1.45;color:var(--t2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
    overflow:hidden;word-break:break-word;min-height:2.9em}
  .pj-last b{font-weight:600;color:var(--t3)}
  .pj-card .r2 .sp{flex:1}
  /* A folder card's foot is one line: a pinned card with a long state (215px in 203) dropped its time
     to a second line and stood taller than its neighbours. The state's word and the count give way
     (the mark beside the word still says which state); the time and the button never do. */
  .pj-card .r2:has(>.sp){flex-wrap:nowrap;gap:6px}
  .pj-card .r2:has(>.sp)>*{flex:none;white-space:nowrap}
  .pj-card .r2:has(>.sp)>:is(span:not([class]),.pj-stl){flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-card .r2:has(>.sp)>.pj-stl{display:block;line-height:18px}
  .pj-card .r2:has(>.sp)>.sp{flex:1 1 0;min-width:0}
  .pj-card .r2:has(>.sp)>.sp~span{flex:none}
  .pj-pinmk{display:inline-flex;color:var(--t2)} .pj-pinmk svg{width:12px;height:12px}
  .pj-chips{display:flex;gap:6px;flex-wrap:wrap}
  .pj-chip{height:30px;padding:0 12px;border-radius:16px;background:var(--btn);color:var(--t1);font-size:13px;font-weight:500;
    display:inline-flex;align-items:center;gap:6px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-chip:hover{background:var(--btn-hi)}
  .pj-chip em{font-style:normal;color:var(--t3);font-size:12px}
  .pj-tag{flex:none;font-size:12px;font-weight:600;color:var(--t3);border:1px solid var(--line);border-radius:6px;padding:0 6px;line-height:18px}
  .pj-tag.on{color:var(--green);border-color:currentColor}
  .pj-hint{margin-top:8px;font-size:12px;line-height:1.5;color:var(--t3);overflow-wrap:anywhere}
  .pj-hint code{font:12px ui-monospace,Menlo,Consolas,monospace;color:var(--t1);background:var(--bg);padding:1px 4px;border-radius:6px;user-select:all}
  .pj-dlg .seg{margin-top:12px}
  .pj-dlg .pj-lab{margin-top:16px}
  .pj-dlg .pj-search{width:100%}
  .pj-dl{display:flex;flex-direction:column;gap:2px;margin-top:6px;max-height:30vh;overflow-y:auto;overscroll-behavior:contain}
  .pj-dl button{display:flex;align-items:center;gap:8px;width:100%;min-height:40px;padding:0 12px;border-radius:8px;text-align:left;
    font-size:14px;color:var(--t1);transition:background .15s}
  .pj-dl button:hover{background:var(--btn)}
  .pj-dl button.on{background:var(--btn-hi)}
  .pj-dl .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-ck{flex:none;width:20px;height:20px;border-radius:50%;border:1.5px solid var(--t4);display:inline-flex;align-items:center;justify-content:center;color:transparent}
  .pj-ck svg{width:12px;height:12px}
  .pj-dl button.on .pj-ck{background:#dcdcdc;border-color:#dcdcdc;color:#141414}
  .pj-ta2{width:100%;resize:vertical;background:var(--bg);border:1px solid var(--line);border-radius:8px;color:var(--t1);
    font:inherit;font-size:14.5px;line-height:1.45;padding:8px 12px;min-height:72px;max-height:40vh}
  .pj-ta2:focus{outline:none;border-color:var(--focus-line);box-shadow:0 0 0 1px var(--focus-line),0 0 0 4px var(--focus-glow)}
  .pj-mtabs{display:none;gap:6px;overflow-x:auto;margin:8px 0 0;padding-bottom:2px;scrollbar-width:none}
  .pj-mtabs::-webkit-scrollbar{display:none}
  .pj-mtabs button{flex:none;height:32px;padding:0 12px;border-radius:16px;background:var(--card);color:var(--t2);font-size:13px;
    font-weight:500;white-space:nowrap;max-width:60vw;overflow:hidden;text-overflow:ellipsis}
  .pj-mtabs button.on{background:var(--btn-hi);color:var(--t1);font-weight:600}
  .pj-mgrid{display:grid;gap:8px;margin-top:12px;grid-template-columns:repeat(2,minmax(0,1fr))}
  .pj-mgrid.n1{grid-template-columns:minmax(0,1fr)}
  @media(min-width:1100px){.pj-mgrid.n3,.pj-mgrid.n5,.pj-mgrid.n6{grid-template-columns:repeat(3,minmax(0,1fr))}}
  .pj-mp{min-width:0;display:flex;flex-direction:column;gap:6px}
  .pj-mhead{display:flex;align-items:center;gap:8px;min-width:0;padding:0 2px}
  .pj-mhead .t{font-size:14px;font-weight:600;flex:none;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-mhead .s{font-size:12px;color:var(--t3);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-mhead .sp{flex:1}
  .pj-mhead .pj-more{margin:0}
  .pj-mb [data-col="side"],.pj-mb .pj-seg,.pj-mb .pj-tip{display:none!important}
  .pj-mb .pj-msgs{height:calc(var(--vh,100dvh) - 400px);min-height:240px}
  .pj-mgrid.r2 .pj-mb .pj-msgs{height:calc((var(--vh,100dvh) - 470px) / 2);min-height:200px}
  .pj-all{display:flex;gap:8px;align-items:flex-end;margin-top:8px;padding:8px;border-radius:var(--r-card);background:var(--card)}
  .pj-all textarea{flex:1;min-width:0;resize:none;background:var(--bg);border:0;border-radius:8px;color:var(--t1);
    font:inherit;font-size:14.5px;line-height:1.45;padding:8px 12px;min-height:38px;max-height:120px}
  .pj-all .pj-btn{height:38px}
  .pj-all textarea:focus{outline:none;box-shadow:0 0 0 1px var(--focus-line),0 0 0 4px var(--focus-glow)}
  @media(max-width:759px){.pj-mtabs{display:flex}.pj-mgrid{grid-template-columns:minmax(0,1fr)}
    .pj-mp{display:none}.pj-mp.focus{display:flex}.pj-mb .pj-msgs,.pj-mgrid.r2 .pj-mb .pj-msgs{height:calc(var(--vh,100dvh) - 430px);min-height:240px}}
  .pj-agt{display:flex;align-items:center;gap:8px;padding:8px 8px 8px 12px;border-radius:8px;background:var(--card);margin-bottom:6px;min-width:0}
  .pj-agt .go{flex:1;min-width:0;display:flex;align-items:center;gap:8px;text-align:left}
  .pj-agt .tx{flex:1;min-width:0}
  .pj-agt .t{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-agt .s{font-size:12px;color:var(--t3);margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-agt .stp{flex:none;height:30px;padding:0 12px;border-radius:8px;font-size:12px;font-weight:600;color:var(--t1);background:var(--btn)}
  .pj-agt .stp:hover{background:var(--btn-hi)}
  /* html.pj2 = room for the list beside the chat but not for the results as well: two columns,
     the results stay behind the 대화 / 결과물 switch. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){html.pj2 .pj-cols{display:grid;grid-template-columns:minmax(240px,min(340px,40%)) minmax(0,1fr);gap:16px}
    html.pj2 .pj-rail{max-height:none}}
  /* The list beside the chat, in the app menu's own row shape: 새 세션, a search field, a filter,
     then one row per session under its project's name; sessions made outside this app are folded
     at the bottom. */
  .pj-rail>.pj-btn.full{margin:2px 0 8px}
  :root{--ag-claude:#c9805a;--ag-codex:#5b9bd5}
  html[data-theme="light"]{--ag-claude:#b0643c;--ag-codex:#3b7dbd}
  .pj-ag.cl,.pj-agw.cl{color:var(--ag-claude)} .pj-ag.cx,.pj-agw.cx{color:var(--ag-codex)}
  .pj-ag.cl{border-color:color-mix(in srgb,var(--ag-claude) 40%,transparent)} .pj-ag.cx{border-color:color-mix(in srgb,var(--ag-codex) 40%,transparent)}
  .pj-lhd{display:flex;flex-wrap:wrap;justify-content:flex-end;align-items:center;gap:8px;margin:2px 0 12px 8px;container-type:inline-size}
  .pj-lhd b{flex:1;min-width:0;font-size:19px;font-weight:700;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  /* 보기: one button for how the list looks (view, size, order). It says what it is. */
  .pj-vwb{position:relative;flex:none;display:inline-flex;align-items:center;gap:4px;height:34px;padding:0 8px 0 12px;border-radius:999px;color:var(--t2);font-size:13px;font-weight:600;white-space:nowrap;
    box-shadow:inset 0 0 0 1px var(--line);transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  .pj-vwb svg{flex:none;width:15px;height:15px}
  .pj-vwb .cv{width:11px;height:11px;color:var(--t3);transform:rotate(90deg);transition:transform .2s var(--ease)}
  .pj-vwb[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-vwb[aria-expanded="true"] .cv{transform:rotate(-90deg)}
  .pj-vwb:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(hover:hover){.pj-vwb:hover{background:var(--card-hi);color:var(--t1)}}
  /* The menu under it: how the list looks on two small segmented rows, then what it can do to
     the order as plain menu rows. The same surface, row height and hairline as every other menu. */
  .pj-pop.vm{width:236px}
  .pj-vm{display:flex;flex-direction:column;gap:6px;padding:4px}
  .pj-dlg .pj-vm{gap:8px;padding:0}
  .pj-vm .vr{display:flex;align-items:center;gap:8px;min-height:30px}
  .pj-vm .vl{flex:none;width:34px;font-size:12px;font-weight:600;line-height:14px;letter-spacing:.02em;color:var(--t4)}
  .pj-vm .seg{flex:1 1 0;min-width:0;margin:0;padding:2px;gap:2px;border-radius:var(--r-md,10px)}
  body .pj-vm .seg button{flex:1 1 0;width:auto;min-width:0;height:28px;padding:0 6px;display:flex;flex-direction:row;align-items:center;justify-content:center;gap:4px;
    text-align:center;font-size:12px;font-weight:600;line-height:16px;color:var(--t3);border-radius:var(--r-sm);white-space:nowrap}
  body .pj-vm .seg button.on{background:var(--btn-hi);color:var(--t1)}
  body .pj-vm .seg button:focus-visible,body .pj-vm .va:focus-visible,body .pj-vm .vrs:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  .pj-vm svg{flex:none;width:14px;height:14px;fill:currentColor}
  .pj-vm hr{border:0;border-top:1px solid var(--line);margin:2px 0}
  .pj-vm .vo{flex:1 1 0;min-width:0;display:flex;gap:4px}
  body .pj-vm .va{display:flex;align-items:center;flex:1 1 0;width:auto;min-width:0;height:30px;padding:0 6px;justify-content:center;gap:4px;font-size:12px;font-weight:600;line-height:16px;color:var(--t2);
    border-radius:var(--r-md,10px);box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap}
  .pj-vm .va svg{color:var(--t3)}
  body .pj-vm .vrs{flex:none;width:auto;align-self:flex-end;white-space:nowrap;height:24px;min-height:0;padding:0 6px;margin:-2px 0 0;font-size:11.5px;font-weight:500;color:var(--t3);border-radius:var(--r-sm)}
  body .pj-vm .vrs:disabled{color:var(--t4);opacity:.6}
  @media(hover:hover){body .pj-vm .seg button:not(.on):hover{background:none;color:var(--t1)}body .pj-vm .va:hover{color:var(--t1);background:var(--card-hi)}body .pj-vm .vrs:not(:disabled):hover{color:var(--t1);background:none;text-decoration:underline}}
  @media(pointer:coarse){body .pj-vm .seg button{height:40px;font-size:14px}.pj-vm .vl{width:40px;font-size:12px}body .pj-vm .va{height:42px;font-size:14px}body .pj-vm .vrs{height:36px;font-size:13px}.pj-vm svg{width:16px;height:16px}}
  @media(pointer:coarse){body .pj-vm .seg button{min-height:44px;font-size:14px}}
  /* 새 세션 and its caret are one pill: the pill owns the colour and the shape, so no seam shows
     between the halves at any zoom; the caret half is a full 34px with a soft rule before it. */
`;
