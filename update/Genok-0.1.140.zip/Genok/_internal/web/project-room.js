// Genok web UI, cut from project.js: #project/<name>[/<sid>]: the session cards, a session not opened yet, 새로 시작.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- #project/<name>[/<sid>] ---------------------------------------------------------------------
  // What /api/project last said, per project: a conversation picked in the list is shown from
  // it at once, and the answer that follows only writes what differs.
  const projSeen = {};
  // When the person last pressed or typed: what changes by itself afterwards does not glide.
  let actedAt = -1e9;
  ["pointerdown", "keydown"].forEach((t) => addEventListener(t, () => { actedAt = performance.now(); }, true));
  async function drawProject(el, name, sid, my) {
    let v, shown = "", wait = 0, up = false;
    const seen = projSeen[name];
    // A page that is up stays up: the list, the chat's frame and what is typed are kept, and only
    // what changed is written. The loading page is for a cold start alone (a link straight to a
    // conversation with nothing drawn yet), and only once the answer has taken 300ms.
    // The last answer is painted only when it brings the picked chat sooner (seenPaint): a page
    // that already shows this chat waits the moment for the fresh answer, so a row that came
    // since is never taken out and put back.
    if (el.querySelector(".pj-cols")) {
      up = true;
      if (!pendNew[name] && seenPaint(seen && seen.v, sid, sid === NEW, seenAt === name + "/" + (sid || ""))) { shown = seen.k; projShow(el, name, sid, my, seen.v); }
    } else if (!pendNew[name] && seenPaint(seen && seen.v, sid, sid === NEW, false)) {
      // Back from another screen: this folder was read before, so its last answer goes up at once
      // instead of a blank page for as long as the read takes. The fresh answer replaces it only
      // when it differs.
      shown = seen.k; projShow(el, name, sid, my, seen.v);
    } else {
      const cold = () => {
        if (!live(my) || el.querySelector(".pj-cols") || el.querySelector("rl-load")) return;   // a loader already up stays as it is
        el.innerHTML = loadingHtml(tl("room.loading"), {fill: true});
      };
      // Nothing drawn yet: the loader is put in at once (its mark still waits its own 250ms, so a fast
      // answer shows nothing), instead of leaving a blank page for 300ms first.
      if (!el.firstElementChild) cold(); else { wait = setTimeout(() => { cold(); }, 300); timers.add(wait); }
    }
    // Nothing known of the folders yet (a reload straight into a chat): they are read alongside
    // the chat instead of after it. The chat does not wait for them: the list is drawn, whole,
    // when they are in (a read that failed leaves the open folder's rows).
    if (!roomsCache && !roomsSeen && !roomsFirst) roomsFirst = quietRooms().catch(() => {}).then(() => { roomsFirst = null; if (!roomsSeen) roomsSeen = []; if (railNow) railNow(); });
    try { v = await readOrAsk("/api/project?name=" + enc(name)); }
    catch (e) { clearTimeout(wait); if (live(my) && !shown && !up) failed(el, e); return; }
    clearTimeout(wait);
    if (!live(my)) return;
    // An address this install cannot open (an old link, a chat hidden for good, a folder that is
    // gone). The page used to show the folder's other chat under the dead address without a word,
    // so a line typed there went to that other session; a folder that does not exist became an
    // empty chat ready to type in. Now it says so and the address is put right.
    if (!v.need_consent && !pendNew[name] && sid !== NEW) {
      const d = v.dept || {}, rows = v.sessions || [];
      if (d.registered === false && !d.folder && !rows.length && where().name === name) {
        // The list this page remembers may still hold it (renamed or removed a moment ago): left
        // there, a wide window would jump straight back into it, and round again until the next read.
        if (roomsSeen) roomsSeen = roomsSeen.filter((x) => x.name !== name);
        roomsCache = null; if (lastOpen && lastOpen.name === name) lastOpen = null;
        toast(tl("pjx.nofolder", {n: name})); return nav("project");
      }
      if (sid && sid[0] !== "~" && !rows.some((s) => s.id === sid)) {
        // Only one the server does not know at all: one opened a moment ago that the list does
        // not have yet (a reload while it starts) is known, and the page waits for it as before.
        const st = await get("/api/project/session?id=" + enc(sid)).catch(() => null);
        if (!live(my)) return;
        if (st && st.found === false) {
          // (A phone's list page passes the chat it last showed: its own address is left alone.)
          if (where().sid === sid) { history.replaceState(null, "", "#project/" + enc(name)); toast(tl("pjx.gone")); }
          sid = ""; shown = "";
        }
      }
    }
    const k = JSON.stringify(v);
    if (!v.need_consent) projSeen[name] = {k, v: JSON.parse(k)};
    if (k !== shown) projShow(el, name, sid, my, v);
    pjStop.sweep();
  }
  function projShow(el, name, sid, my, v) {
    // The list is shown, but Codex's records are not read yet (an install that connected Codex
    // before connecting asked for it): offered once, as a bar over the session list that holds
    // nothing up. From then on it waits in settings, like a question answered "later".
    if (v.offer_consent && !offered) {
      offered = true; readOffer = v.offer_consent;
      post("/api/consent/defer", {scope: readOffer.scope}).catch(() => {});
    }
    if (v.need_consent) {
      el.innerHTML = `<button class="pj-back press" data-b>← ${tl("menu.chat")}</button>
        <div class="pj-empty">${tl("pjx.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("pjx.askAgain")}</button></div>`;
      el.querySelector("[data-b]").onclick = backToList;
      el.querySelector("[data-retry]").onclick = () => draw(el);
      return;
    }
    // Ended sessions this app did not open (s.old) stay out of the list: one folded row at its
    // bottom shows them in place. One of them opened by its address is shown like any other.
    const open1 = sid && sid !== NEW ? sid : "", shows = (s) => listed(s, tidOn());
    topPins = new Set(v.top_pins || []);
    const all = v.sessions || [], vis = all.filter((s) => shows(s) && !s.old);
    const olds = all.filter((s) => s.old && shows(s));
    all.forEach((s) => { s.pinned = !!v.pin && s.id === v.pin; if (s.pinned && v.standing) s.fixed = v.standing; });
    const hidden = all.filter((s) => s.tidied).length;
    // The chat is the page: with no session in the address, the one that is up (or the newest) opens.
    // The department's own session (its pin) comes first, like the hub's room.
    // A session opened a moment ago with no id yet: wait for it here, do not open an older one.
    // One that has its id but is not in the list yet (its record is not read yet, or may not be
    // read at all) waits the same way: the page never falls back to the empty draft with the line gone.
    const hit = sid && sid !== NEW ? all.find((s) => s.id === sid) : null, pp = pendNew[name];
    const pn = pendFor(pp, sid, !!hit, Date.now());
    if (!pn) delete pendNew[name];
    const cur = pn || sid === NEW ? null : hit || vis.find((s) => s.pinned) || pickCurrent(vis);
    // 새 세션, or a project with no session to open: the chat is there anyway, ready to type in.
    // Nothing is opened (and nothing is sent for the person) until the first line goes out.
    if (sid === NEW) draftGone.delete(name);
    const draft = !cur && !pn;
    // A standing project nobody has talked to yet: the empty chat is the standing session to come.
    const fixedNew = draft && v.standing && !v.pin ? v.standing : "";
    // (An older session opened by its address no longer unfolds the old rows: railHTML shows it apart.)
    if (cur) lastOpen = {name, sid: cur.id};
    // The project's own conversation (its pin): said in words under the name, not only a pin mark.
    const own = all.find((s) => s.pinned);
    const head = Object.assign({}, v.dept, {fixed: fixedNew, fresh: sid === NEW});
    const three = document.documentElement.classList.toggle("pj3", threeNow());   // decided once per draw
    const two = document.documentElement.classList.toggle("pj2", !three && twoNow());
    const cols2 = three || two;                        // the list sits beside the chat
    // One pane (a phone): the list and the chat are two pages. A chat opened from anywhere else
    // shows the chat; its back arrow shows the list.
    const page = listAt && !cols2;                     // a phone's 대화: the list is the page (#project)
    const at = page ? "~list" : name + "/" + (sid || "");
    // Wide: 결과물 is a stored choice (panes and the embed reset it to the chat). A phone shows one of
    // the two at a time, so there it is a visit: a chat opened anew is the chat, and nothing is stored.
    tab = wide() ? (folded("tab") ? "side" : "conv") : at === seenAt ? tab : "conv";
    if (!cols2 && at !== seenAt) listOpen = false;
    if (page) listOpen = true;
    seenAt = at;
    const seenWas = seenPrev; seenPrev = at;
    const showRail = cols2 || listOpen || !!pn;
    const listOnly = !cols2 && listOpen && !pn;
    const bare = cols2 || !!cur || draft;              // the chat names itself: no page head above it
    const railOff = three && cur && folded("rail");
    const upN = vis.filter((s) => s.state !== "ended").length;
    // Folded (wide screens only): the list becomes a 40px strip that opens it again, and the chat
    // takes the room. Drawn in place so the chat under it keeps its scroll and its draft.
    const rail = () => {
      railNow = rail;
      const box = el.querySelector(".pj-rail"); if (!box) return;
      // A reload straight into a chat: the folders are not read yet. Drawn now, the list would be
      // the open folder's rows alone, and the open row would drop when the rest arrives. It waits.
      if (bare && (cols2 || listOnly) && !roomsCache && !roomsSeen) return;
      if (ORD && ORD.live()) return ORD.later(rail);
      if (SW && SW.live()) return SW.later(rail);
      box.dataset.pn = name;                           // split.js: the project the session rows belong to
      const off = three && cur && folded("rail"), y = box.scrollTop;
      const ms = sessQ;
      el.querySelector(".pj-cols").classList.toggle("no-rail", !!off);
      const html = off ? `<button class="pj-strip pj-anim press" data-fold="rail" aria-expanded="false" aria-label="${tl("pjx.listOpenUp", {n: upN})}" title="${tl("pjx.listOpenUp", {n: upN})}">${ICO.panel}<span class="c" aria-hidden="true">${ic("list")}<b>${upN}</b></span></button>`
        : railHTML(vis, cur, hidden, three && !!cur, {olds, draft, name, head, open: cur, listOnly, rooms: bare ? roomsCache || roomsSeen || [] : null});
      // Rows never move under the pointer: a redraw that would reorder them waits until it leaves.
      if (!off && box._off === false && box._ms === ms && box.matches(":hover")) {
        const t = document.createElement("div"); t.innerHTML = html;
        const sig = (n) => [...n.querySelectorAll(".pj-srow[data-sid]")].map((r) => r.dataset.sid).join();
        if (sig(t) !== sig(box)) { clearTimeout(box._rt); box._rt = setTimeout(rail, 1600); return; }
      }
      // While the search field is being typed in only the rows change: the field, its caret and a
      // Korean syllable still being composed stay as they are.
      const sq0 = box.querySelector(".pj-sq"), rows0 = box.querySelector(".pj-srows");
      if (!off && sq0 && rows0 && sq0 === document.activeElement) {
        const t = document.createElement("div"); t.innerHTML = html;
        const r1 = t.querySelector(".pj-srows"); if (r1) rows0.replaceWith(r1);
      } else {
        // A redraw (the list is read again every few seconds) keeps the row the keyboard is on.
        const f = document.activeElement, fr = f && box.contains(f) && f.closest(".pj-srow,.pj-sgh"), fk = fr && fr === f ? [fr.dataset.sid, fr.dataset.p, fr.dataset.gf] : null;
        if (!off && box._off === false && box.firstElementChild) morphTo(box, html); else box.innerHTML = html;
        const sq1 = box.querySelector(".pj-sq"); if (sq1 && sq1.value !== sessQ) sq1.value = sessQ;
        if (fk) { const n = [...box.querySelectorAll(".pj-srow,.pj-sgh")].find((x) => (fk[0] && x.dataset.sid === fk[0]) || (!fk[0] && fk[1] && !x.dataset.sid && x.dataset.p === fk[1]) || (fk[2] && x.dataset.gf === fk[2])); if (n) n.focus({preventScroll: true}); }
      }
      // The selection bar is one line; where the header it replaces was two, the list keeps its place.
      const lh = !off && box.querySelector(".pj-lhd");
      // (as margin, not padding: the bar sticks, and what it covers while it does must stay one line tall)
      if (lh) { if (!lh.classList.contains("pj-pick")) lhdH = lh.offsetHeight; else { lh.style.marginBottom = ""; const d = lhdH - lh.offsetHeight; if (d > 0) lh.style.marginBottom = (parseFloat(getComputedStyle(lh).marginBottom) || 0) + d + "px"; } }
      if (!off) readBar(box, () => draw(el));
      box.scrollTop = y;
      lhFit(box); box.onscroll = () => lhMark(box);
      box._ms = ms; box._off = !!off;
      const sq = box.querySelector(".pj-sq");
      if (sq) sq.oninput = () => { sessQ = sq.value; rail(); };
      const fc = box.querySelector("[data-fclear]");
      if (fc) fc.onclick = () => { sessQ = ""; rail(); const n = box.querySelector(".pj-sq"); if (n) n.focus({preventScroll: true}); };
      const refocus = (q) => { const b = box.querySelector(q); if (b) b.focus({preventScroll: true}); };
      // The new-session row has no session to open; while picking, a click only picks it.
      box.querySelectorAll("[data-dr]").forEach((c) => c.onclick = (e) => { if (!e.target.closest("[data-dm],.pj-pop")) pickClick(e, c); });
      // Up and down walk the rows (and the projects' names); down from the search field enters the
      // list, up from the first row goes back to it. No motion: it is pressed over and over.
      box.onkeydown = (e) => {
        if (e.altKey || e.ctrlKey || e.metaKey || e.isComposing) return;
        const t = e.target, at0 = t.closest && t.closest(".pj-srows .pj-srow,.pj-srows .pj-sgh");
        if ((e.key === "Enter" || e.key === " ") && at0 === t && t.matches(".pj-srow[data-p]")) { e.preventDefault(); return t.click(); }
        const d = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0; if (!d) return;
        const field = box.querySelector(".pj-sq"), stops = [...box.querySelectorAll(".pj-srows .pj-srow[tabindex],.pj-srows .pj-sgh")];
        if (t === field) { if (d > 0 && stops[0]) { e.preventDefault(); stops[0].focus(); } return; }
        if (at0 !== t) return;                         // inside a menu button: its own keys
        e.preventDefault();
        const to = stops[stops.indexOf(t) + d];
        if (to) to.focus(); else if (d < 0 && field) field.focus();
      };
      const nb = box.querySelector("[data-newsess]");
      if (nb) nb.onclick = () => newTalk(name, false, nb);
      const ob = box.querySelector("[data-old]");
      if (ob) ob.onclick = () => {
        showOld = !showOld;
        if (showOld && bare && oldInfo.only) { oldRooms = null; loadOld().then(() => { if (live(my)) rail(); }); }
        rail();
      };
      box.querySelectorAll("[data-p]").forEach((c) => c.onclick = () => { listOpen = false; if (page) return fromList("project/" + enc(c.dataset.p)); if (c.dataset.p !== name || sid === NEW) nav("project/" + enc(c.dataset.p)); else if (listOnly) draw(el); });
      const tid = box.querySelector("[data-tid]");
      if (tid) tid.onclick = () => { showTidied = tidOn() ? "" : where().name; draw(el); };
      const fold = box.querySelector("[data-past]");
      if (fold) fold.onclick = () => { showPast = !showPast; draw(el); };
      box.querySelectorAll("[data-sid]").forEach((c) => {
        const go = (e) => {
          if (e.target.closest("[data-more],.pj-pop")) return;
          if (pickClick(e, c)) return;
          listOpen = false; setFold("list", false);
          if (cols2 && !c.classList.contains("on")) {
            box.querySelectorAll(".pj-srow.on").forEach((n) => { n.classList.remove("on"); n.removeAttribute("aria-current"); });
            c.classList.add("on"); c.setAttribute("aria-current", "true");
          }
          if (page) return fromList("project/" + enc(c.dataset.pn || name) + "/" + c.dataset.sid);
          if (listOnly && cur && c.dataset.sid === cur.id) draw(el); else nav("project/" + enc(c.dataset.pn || name) + "/" + c.dataset.sid);
        };
        c.onclick = go;
        c.onkeydown = (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === c) { e.preventDefault(); go(e); } };
      });
      box.querySelectorAll("[data-more]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); menu(b, all.find((s) => s.id === b.dataset.more), name, () => draw(el)); });
      splitMarks(el);
      box.querySelectorAll("[data-pk]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); pickDo(b.dataset.pk, b, () => draw(el)); });
      pickMarks(box);
      if (!off) talkPut(box);
    };
    el.onclick = (e) => {
      const f = e.target.closest("[data-fold]"); if (!f) return;
      const k = f.dataset.fold; setFold(k, !folded(k));
      // Side by side: the side that was just opened takes its room from the other side before it
      // takes a pane away; whenever a different number of panes fits, the page is drawn again.
      const o = k === "rail" ? "side" : "rail";
      if (splitDrawn(el) > 1 && !folded(k) && !folded(o) && splitCap(el) < splitDrawn(el)) { setFold(o, true); return draw(el); }
      if (splitWant(el) !== splitDrawn(el) || splitStale(el)) return draw(el);
      const fp = el.querySelector(".pj-pane.focus");
      if (k === "rail") rail();
      else { const c = fp ? convs[fp.dataset.pane] : cur && C(cur.id); el.querySelector(".pj-cols").classList.toggle("no-side", folded("side")); if (c) side(el.querySelector("#pj-side"), c.room || name, c); }
      colGrips(el);                                    // the side that opened takes its width from the other, never from the chat's 380px
      const back = el.querySelector(`[data-fold="${k}"]`); if (back) back.focus({preventScroll: true});
    };
    const y0 = (el.querySelector(".pj-rail") || {}).scrollTop || 0;      // the list keeps its place across a redraw
    const kept = !!el.querySelector(":scope>.pj-cols");
    const shell = (bare ? "" : `<button class="pj-back press" data-b>← ${tl("menu.chat")}</button>
      <div class="pj-head">${emAs("em", head.emoji, head.color, head.icon || icoOf(name))}
        <div class="tx"><h1>${esc(pname(name))}</h1><div class="fo">${esc(head.folder || "")}</div>
          ${own ? `<button class="ow press" data-own="${esc(own.id)}"><span class="k">${esc(tl("room.owner"))}</span><span class="t">${esc(title(own))}</span><span class="st">· ${esc(LABEL[pjKindOf(own.state, own.last)] || own.state || "")}</span>${agentTag(own.agent)}</button>`
            : all.length ? `<div class="ow"><span class="k">${esc(tl("room.ownerNone"))}</span></div>` : ""}</div>
        ${showRail && !railOff ? "" : `<button class="pj-btn light press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button>`}
        <button class="pj-more press" data-hm aria-label="${esc(tl("room.deptMenu"))}" style="margin:0">${ic("more")}</button></div>`) + `
      ${(cur || draft) && !bare ? `<button class="pj-cur press" data-cur aria-expanded="${listOpen}" style="margin-top:8px">${dot(cur ? pjKindOf(cur.state, cur.last) : "ended")}<span class="t">${esc(cur ? title(cur) : fixedNew || tl("room.newSess"))}</span>
         <span class="s">${listOpen ? tl("pjx.listFold") : tl("pjx.listOpenN", {n: vis.length})}</span></button>` : ""}
      <div class="pj-cols${three && cur && folded("side") ? " no-side" : ""}${listOnly ? " pj-listonly" : ""}" style="margin-top:${bare ? 4 : 14}px">
        ${showRail ? `<div class="pj-rail"></div>` : ""}
        <div class="pj-body" id="pj-body"></div>
        ${three && cur ? ["l", "r"].map((k) => `<div class="cgrip pj-g ${k}" data-grip="${k}" role="separator" aria-orientation="vertical" tabindex="0" aria-label="${esc(k === "l" ? tl("room.gripL") : tl("room.gripR"))}" title="${esc(tl("room.gripTip"))}"></div>`).join("") : ""}</div>`;
    if (kept) {
      morphTo(el, shell);
      const pc = el.querySelector(":scope>.pj-cols");
      pc.classList.toggle("no-side", !!(three && cur && folded("side"))); pc.classList.toggle("pj-listonly", !!listOnly); pc.style.marginTop = (bare ? 4 : 14) + "px";
    } else el.innerHTML = shell;
    rail();
    // The list keeps up on its own: what the open chat's header learns goes onto its row at once
    // (rowSync), and every row is read again every few seconds. Only the list is drawn again, so
    // the chat, its scroll and the line being typed are not touched - the page's own 30s redraw
    // is skipped while a text box has the caret, which in a chat is nearly always.
    rowSync = (id, st) => { if (live(my) && syncRow(all, roomsCache, id, st)) rail(); };
    clearInterval(listTimer);
    const myTimer = listTimer = setInterval(async () => {
      if (!live(my) || !el.isConnected) return clearInterval(myTimer);
      if (document.hidden || !el.querySelector(".pj-rail")) return;
      try {
        const [f] = await Promise.all([get("/api/project?name=" + enc(name)), quietRooms()]);
        if (!live(my)) return;
        (f.sessions || []).forEach((n) => syncRow(all, null, n.id, n));
        rail();
      } catch (e) { /* offline: the chat says so */ }
    }, LIST_EVERY);
    const rb = el.querySelector(".pj-rail");
    if (rb && cols2) rb.scrollTop = y0;
    // The projects in the list are the room list's: read again when it is not fresh.
    if (!roomsFirst && (cols2 || listOnly) && (!roomsCache || Date.now() - roomsAt > 15000)) loadRooms().then(() => { if (live(my)) rail(); }).catch(() => { if (!roomsSeen) { roomsSeen = []; if (live(my)) rail(); } });
    colGrips(el);
    const bk = el.querySelector("[data-b]");
    if (bk) bk.onclick = backToList;
    const ow = el.querySelector("[data-own]");
    if (ow) ow.onclick = () => { listOpen = false; nav("project/" + enc(name) + "/" + enc(ow.dataset.own)); };
    const cb = el.querySelector("[data-cur]");
    if (cb) cb.onclick = () => { listOpen = !listOpen; setFold("list", listOpen); draw(el); };
    shownCur = three && cur ? {id: cur.id, p: name} : null;
    const sp = shownCur ? pjSplitPlan(el, cur, name) : null;
    // What the chat column shows. The same thing as before is left as it is: its lines, its
    // scroll, its box and its loops carry on. Another conversation is drawn into the same column.
    const pb0 = el.querySelector("#pj-body"), bkey = [sp ? "split" : cur ? "s:" + cur.id : pn ? "pend" : "draft:" + name, three, cols2, bare].join("|");
    const same = pb0._pjKey === bkey && pb0.firstElementChild;
    el.querySelector(".pj-cols").classList.toggle("pj-sp", !!sp);
    if (!sp) { const old = pb0.querySelector(":scope>.pj-split"); if (old) old.remove(); }
    if (sp) splitDraw(el, sp, name, all, my);
    else if (cur) {
      if (!same || !pb0._pjRun) {
        const swap = kept && !same && !!pb0.querySelector(":scope>.pj-conv");
        drawSession(pb0, el, name, cur, my);
        const m = swap && pb0.querySelector("#pj-msgs"); if (m) m.classList.add("pj-swap");
      }
    }
    else if (pn) {
      // The line that was sent stays on the page while its session is on the way.
      const pb = pb0; endRun(pb);
      pb.innerHTML = `<div class="pj-pendc" data-pend><div class="pj-msgs">${pendRow({text: pn.text, busy: !pn.late, tag: pn.late ? "" : tl("room.pendNew")}, 0)}</div>
        ${pn.late ? `<div class="pj-empty" role="alert">${tl("room.openLate")}<br><button class="pj-btn light press" style="margin-top:12px" data-recheck>${tl("room.recheck")}</button></div>` : ""}</div>`;
      const rc = pb.querySelector("[data-recheck]");
      if (rc) rc.onclick = () => { pn.late = false; pn.at = Date.now(); roomsCache = null; draw(el); };
      waitNew(name, pn, my);
    }
    // On a phone the draft opens unfocused: a focused box means body.typing, which hides the tab bar.
    else if (!same) { endRun(pb0); drawDraft(pb0, name, head, wide()); }
    pb0._pjKey = bkey;
    // Beside the list the chat names itself: the conversation, then project · agent · when.
    const conv = !sp && bare && el.querySelector("#pj-body .pj-conv");
    const nth0 = conv && conv.querySelector(":scope>.pj-nth");
    if (nth0) nth0.remove();
    // The name is what this conversation is about; the dept, the state and the tool are the one line under it.
    const ttl = cur ? cur.fixed || cur.label || cur.named || (cur.title && cur.title !== "(제목 없음)" ? cur.title : "") || pname(name) : fixedNew || tl("room.newSess");
    if (conv) conv.insertAdjacentHTML("afterbegin", `<div class="pj-nth pl-ph${cur && ttl !== pname(name) ? "" : " pn"}">${cols2 ? "" : `<button class="pj-more press" data-list aria-label="${esc(tl("room.listBack"))}" title="${esc(tl("room.listBack"))}">${ic("back")}</button>`}<div class="tx"><div class="t">${(cur ? cur.fixed : fixedNew) ? pinMk() : ""}${esc(Redact.show(ttl))}</div>
      ${cur ? "" : `<div class="s">${esc([pname(name), (draftAgent[name] || head.agent) === "codex" ? "Codex" : "Claude", tl("room.draftRow")].join(" · "))}</div>`}</div>
      ${railOff ? `<button class="pj-btn press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button>` : ""}
      ${cur && !cols2 ? `<button class="pj-more press" data-res data-t="side" aria-label="${esc(tl("pj.tab.side"))}" title="${esc(tl("pj.tab.side"))}">${ic("tray")}</button>` : ""}
      ${cur && cols2 && three ? `<button class="g-btn pl-resb press" data-resb data-fold="side" aria-expanded="${!folded("side")}">${tl("room.tabRes")}<b class="pl-n"></b></button>` : ""}
      ${cur ? `<button class="pj-more press" data-cmenu aria-label="${tl("pj.menu")}" title="${tl("pj.menu")}">${ic("more")}</button>` : ""}</div>`);
    const nb = el.querySelector("[data-new]");
    if (nb) nb.onclick = () => nav("project/" + enc(name) + "/" + NEW);
    const lb = el.querySelector("[data-list]");
    if (lb) lb.onclick = () => { if (phoneList()) return toList(); listOpen = true; draw(el); };
    if (!cols2 && !page && (cur || draft)) lastChat = {name, sid: cur ? cur.id : NEW};
    // The list comes back where it was left.
    if (page && seenWas !== "~list" && pjListY) { const y = pjListY; scrollTo(0, y); requestAnimationFrame(() => { if (seenAt === "~list") scrollTo(0, y); }); }
    const hm = el.querySelector("[data-hm]");
    if (hm) hm.onclick = (e) => { e.stopPropagation(); headMenu(e.currentTarget, name, head.registered, () => draw(el)); };
    const rsb = el.querySelector("[data-res]"), sideTab = el.querySelector(`.pj-seg [data-t="side"]`);
    if (rsb && sideTab) { rsb.onclick = () => sideTab.click(); const c = C(cur.id); side(el.querySelector("#pj-side"), name, c); }
    // Phone: the list is closed, so the bar goes under the chat's own header.
    if (!showRail) { let h = el.querySelector("#pj-body .pj-nth"); if (h && h.nextElementSibling && h.nextElementSibling.classList.contains("pj-state")) h = h.nextElementSibling; readBar(h ? h.parentNode : el.querySelector("#pj-body"), () => draw(el), h); }
    fit(); requestAnimationFrame(fit); phoneChat();
  }

  // Ask for the new session's id until Claude names it, then open that session (it is pinned by
  // then). Leaving the page stops the asking; after PEND_MAX the page falls back to the list.
  async function waitNew(name, pn, my) {
    while (pn.sid && live(my) && pendNew[name] === pn) {
      // It has its id: wait for the list to show it. Late is said in the pane, and the asking goes on.
      const v = await get("/api/project?name=" + enc(name)).catch(() => null);
      if (!live(my) || pendNew[name] !== pn) return;
      if (v && (v.sessions || []).some((s) => s.id === pn.sid)) { roomsCache = null; return render(); }
      if (!pn.late && Date.now() - pn.at > PEND_SID) { pn.late = true; return render(); }
      await new Promise((ok) => setTimeout(ok, pn.late ? 5000 : 1000));
    }
    while (live(my) && pendNew[name] === pn) {
      const r = await get("/api/project/job-session?job=" + enc(pn.job) + "&name=" + enc(name)).catch(() => null);
      if (!live(my) || pendNew[name] !== pn) return;
      if (r && r.sid) { delete pendNew[name]; roomsCache = null; return nav("project/" + enc(name) + "/" + enc(r.sid)); }
      if (Date.now() - pn.at > PEND_MAX) { delete pendNew[name]; toast(tl("room.pendLate")); return render(); }
      await new Promise((ok) => setTimeout(ok, 1500));
    }
  }

  // The list (left) and the results (right) drag wider from their inner edge: the item screen's
  // grip (v2.js wireColGrip), widths kept on this device like its --ipw.
  const PJW = {l: ["v2-pjrw2", [180, 300, 440], "--rw"], r: ["v2-pjsw", [240, 300, 560], "--sw"]};
  // Not dragged yet: the list grows a little with a wide window (300px up to 360px at 2250).
  const pjw0 = (k) => k === "l" ? Math.round(Math.max(PJW.l[1][1], Math.min(360, innerWidth * .16))) : PJW[k][1][1];
  const pjw = (k) => { try { return +localStorage.getItem(PJW[k][0]) || pjw0(k); } catch (e) { return pjw0(k); } };
  const colFit = new WeakSet();
  function colGrips(el) {
    const cols = el.querySelector(".pj-cols"); if (!cols) return;
    // The first fit of a drawn screen places the columns; only a later change (a fold, a wider
    // window) glides. Reading the width below computes the style once with nothing set, and
    // from there the list used to grow 232px -> its own width over the snap on every arrival.
    const first = !colFit.has(cols);
    if (first) { colFit.add(cols); cols.style.transition = "none"; }
    const px = (k) => parseFloat(getComputedStyle(cols).getPropertyValue(PJW[k][2])) || PJW[k][1][1];
    // Side by side the list gives way (down to its narrowest) until every pane has the chat's 380px.
    const chat = splitDrawn(el) > 1 ? splitDrawn(el) * 380 + (splitDrawn(el) - 1) * SP.GAP : 380;
    Object.keys(PJW).forEach((k) => {
      const [key, range, prop] = PJW[k], other = k === "l" ? "r" : "l";
      // The chat keeps at least 380px whatever the two sides ask for.
      const clamp = (w) => Math.round(Math.max(range[0], Math.min(w, range[2], cols.clientWidth - px(other) - 36 - chat)));
      el.style.setProperty(prop, clamp(pjw(k)) + "px");
      const g = cols.querySelector(`[data-grip="${k}"]`);
      if (!g || g.dataset.wired || typeof wireColGrip !== "function") return;   // fitted again on a width change
      g.dataset.wired = "1";
      wireColGrip(g, {range, dir: k === "l" ? 1 : -1, width: () => px(k),
        apply: (w) => { w = clamp(w); el.style.setProperty(prop, w + "px"); return w; },
        save: (w) => { try { localStorage.setItem(key, Math.round(w)); } catch (e) { /* this visit only */ } }});
    });
    if (first) { void cols.offsetWidth; cols.style.transition = ""; }
  }

  // The list, the chat and the results sit side by side when the page itself has room for the
  // narrowest three (180 + 380 + 240 and the gaps: PJW below): a 1280 window, or 1100 with the
  // app menu folded. Narrower: one at a time (at 1100 with the menu open the chat column was 138px
  // wide and its menu was clipped away). It used to be the window width (1360), which ignored a
  // folded menu. A draw measures (threeNow) and marks <html> with .pj3 for the CSS above;
  // threeCols() is the shape that was drawn, so everything between two draws agrees with it.
  const THREE_MIN = 880;
  const threeNow = () => { const v = document.getElementById("view"); return wide() && (v ? v.clientWidth : innerWidth - 350) >= THREE_MIN; };
  const threeCols = () => document.documentElement.classList.contains("pj3");
  // Two columns (list | chat) need less: any window from 1024 where the page keeps 620px.
  const TWO_MIN = 620;
  const twoNow = () => { const v = document.getElementById("view"); return wide() && (v ? v.clientWidth : innerWidth - 350) >= TWO_MIN; };
  // The session the page opens on: one that is up (working first), else the newest.
  const pickCurrent = (vis) => vis.find((s) => s.state === "live") || vis.find((s) => s.state === "idle" || s.state === "stuck") || vis[0] || null;

  // The conversation shown last (this run of the app only): 대화 opens on it again.
  let lastOpen = null, lhdH = 0;
  // The list's head sticks at the top of what scrolls: the list itself, or the page (then under the
  // page's top bar). `.scr` (rows have gone under it) draws the hairline below it.
  function lhMark(box) { box.classList.toggle("scr", box._lhOwn ? box.scrollTop > 0 : box.getBoundingClientRect().top < box._lhTop - 1); }
  function lhFit(box) {
    if (!box.querySelector(".pj-lh")) return;
    box._lhOwn = /auto|scroll/.test(getComputedStyle(box).overflowY);
    // Whatever bar is pinned over the list's column (the top bar; a style may bring its own): the head stops under it.
    let top = 0;
    if (!box._lhOwn) {
      const r = box.getBoundingClientRect();
      for (let y = -1, k = 0; y < top && k < 3; k++) for (let n of document.elementsFromPoint(r.left + r.width / 2, (y = top) + 1)) {   // bars may be stacked
        while (n && n !== document.body && !/fixed|sticky/.test(getComputedStyle(n).position)) n = n.parentElement;
        const b = n && n !== document.body && !box.contains(n) ? Math.round(n.getBoundingClientRect().bottom) : 0;
        if (b < innerHeight / 3) top = Math.max(top, b);                                    // a sheet over the page is not a bar
      }
    }
    // The head covers the rows under it with the colour of the panel it sits on, whatever the style made that.
    let bg = "";
    for (let e = box; e && !bg; e = e.parentElement) { const c = getComputedStyle(e).backgroundColor; if (!/^transparent$|, 0\)$/.test(c)) bg = c; }
    box.style.setProperty("--lh-bg", bg || "var(--bg)");
    box._lhTop = top;
    box.style.setProperty("--lh-top", box._lhTop + "px"); lhMark(box);
  }
  addEventListener("scroll", () => { const box = document.querySelector(".pj-rail"); if (box && box._lhOwn === false) lhMark(box); }, {passive: true});
  // Another theme or style: the panel's colour is read again (once more after a colour transition has run).
  new MutationObserver(() => { const fit = () => { const box = document.querySelector(".pj-rail"); if (box) lhFit(box); }; fit(); setTimeout(fit, 400); })
    .observe(document.documentElement, {attributes: true, attributeFilter: ["data-theme", "data-skin"]});
  // The first session row of the list as it would be drawn with no project open: the same rows,
  // order, view and filters as the list beside the chat (railHTML itself, read back).
  const topRow = (rooms) => {
    const t = document.createElement("template");
    t.innerHTML = railHTML([], null, 0, false, {rooms, name: "", head: {}, olds: []});
    const r = t.content.querySelector(".pj-srows .pj-srow[data-sid]");
    return r ? {name: r.dataset.pn, sid: r.dataset.sid} : null;
  };

  // The compact list: what is up first; finished sessions fold under one line (open when the
  // one being read is among them).
  // `x`: {olds, draft, name, head, rooms}. With `rooms` (the list sits beside the chat) it is the
  // whole list: 새 세션 on top, one card per project with the open project's sessions under its
  // card, and at the very bottom one folded row for the sessions made outside this app.
  function railHTML(vis, cur, hidden, canFold, x) {
    x = x || {};
    const up = vis.filter((s) => s.state !== "ended"), done = vis.filter((s) => s.state === "ended");
    const open = showPast || (cur && done.some((s) => s.id === cur.id));
    // The list alone on a phone: no chat is up, so no row is the open one (it was painted as open
    // and lost its "your turn" mark, though nothing had been opened).
    const sel = cur && !x.listOnly ? cur.id : "";
    const foldBtn = canFold ? `<span class="sp"></span><button class="pj-fbtn press" data-fold="rail" aria-expanded="true" aria-label="${tl("pjx.listFold")}" title="${tl("pjx.listFold")}">${ICO.panel}</button>` : "";
    const newBtn = `<button class="pj-btn light full press" data-newsess>${ic("plus")}<span>${tl("room.newSess")}</span></button>`;
    const sess = (x.draft ? `<div class="pj-card pj-row on" aria-current="true"><div class="r1">${dot("ended")}<div class="t">${tl("room.newSess")}</div></div>
        <div class="r2"><span>${tl("room.draftRow")}</span></div></div>` : "")
      + (up.length ? up.map((s) => card(s, sel)).join("") : x.draft ? "" : `<div class="pj-empty" style="text-align:left;padding:6px 2px">${tl("pjx.noneUp")}</div>`)
      + (done.length ? `<button class="pj-fold press" data-past aria-expanded="${open}">${ic("chev", "i")}<span>${tl("pjx.past", {n: done.length})}</span></button>`
        + (open ? done.map((s) => card(s, sel)).join("") : "") : "")
      + (hidden ? `<button class="pj-fold press" data-tid><span>${tidOn() ? tl("room.tidHide") : tl("room.tidShow", {n: hidden})}</span></button>` : "");
    const olds = x.olds || [], oldN = olds.length + (x.rooms ? oldInfo.only : 0);
    const others = x.rooms && showOld && oldInfo.only ? (oldRooms ? oldRooms.filter((r) => r.name !== x.name).map((r) => roomCard(r)).join("") : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`) : "";
    const old = oldN ? `<button class="pj-fold press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n: oldN})}</span></button>`
      + (showOld ? `<div class="pj-olds pj-anim">${olds.map((s) => card(s, sel)).join("")}${others}</div>` : "") : "";
    if (!x.rooms) return newBtn + `<div class="pj-lab">${tl("pjx.sess")} <span class="n">${up.length}</span>${foldBtn}</div>` + sess + old + unlinkRows();
    // Beside the chat: one list of conversations in sections by need (내 차례, 작업 중, 대기), the
    // ended ones folded. A row is the department, then what the conversation is about. The only
    // controls above the first row are the filter and 새 대화.
    const list = ORD.arrange(x.rooms.some((r) => r.name === x.name) ? x.rooms
      : [...x.rooms, {name: x.name, emoji: x.head.emoji, agent: x.head.agent, registered: x.head.registered, sid: null}], listOrd.depts, (r) => r.name, (r) => r.born);
    ordKeys.depts = list.map((r) => r.name); ordKeys.sess = {};
    const phone = phoneList();
    // A department's name as a person says it: an unregistered folder is its prettified folder name.
    const deptName = (r) => r.unregistered && r.shown ? r.shown : unEm(pname(r.name), r.emoji || icoHtml(r.icon));
    // What a conversation is called: the standing session's name, a name it was given, the server's
    // label (P1), else its first words. Never the department's own name twice.
    const labOf = (s, fixed) => fixed || s.label || s.named || (s.title && s.title !== "(제목 없음)" ? s.title : "");
    const clean = (t) => flat1(unnote(t));
    railRows.clear();
    const seenRows = new Set();                       // the sessions the list below really draws
    const row = (r, o) => {
      if (o.turn && o.sid && isAnswered(o.sid, o.at)) o.turn = false;   // answered a moment ago: not the person's until the session moves on
      if (o.sid && !railRows.has(o.sid)) railRows.set(o.sid, {name: r.name, s: o.s || {id: o.sid, title: o.t, state: o.st || "ended", agent: o.agent || "claude", pinned: !!o.pinned, unread: +!!o.turn}});
      return Object.assign({pn: r.name, emo: r.emoji, ico: r.icon || "", col: r.color || "", dn: deptName(r), unreg: !!r.unregistered, k: o.st ? pjKindOf(o.st, o.at) : "", live: o.st === "live"}, o);
    };
    const ofS = (r, s) => row(r, {t: labOf(s, s.fixed) || title(s), lab: labOf(s, s.fixed), nw: s.now || "", pin: !!s.fixed, st: s.state, at: s.last, born: s.started, agent: s.agent, on: s.id === sel, turn: !!s.turn && s.id !== sel, sid: s.id, s, unread: s.unread || 0});
    // The standing session leads its project and is never folded away, ended or not.
    const own = vis.find((s) => s.fixed), rest = done.filter((s) => s !== own);
    // Every session the list knows: all of the open project's, and for the others the one each
    // would open on plus its newer ones (`more`, absent from an older server: then that one alone).
    const rowsOf = (r) => {
      if (r.name === x.name) return (x.draft && !draftGone.has(x.name) ? [row(r, {t: x.head.fixed || tl("room.newSess"), lab: x.head.fixed || tl("room.newSess"), pin: !!x.head.fixed, draft: true, on: true, dr: true})] : [])
        .concat((own ? [own] : []).concat(up.filter((s) => s !== own), rest).map((s) => ofS(r, s)));
      if (!r.sid) return [row(r, {t: r.fixed || pname(r.name), lab: r.fixed || "", pin: !!r.fixed, draft: true, mut: true, none: !r.fixed})];
      const lab = labOf(r, r.fixed);
      return [row(r, {t: lab || deptName(r), lab, nw: r.now || clean(r.last), pin: !!r.fixed, st: r.state, at: r.at, born: r.sborn, agent: r.agent, turn: !!r.turn, sid: r.sid, pinned: r.pinned, unread: r.unread || 0})]
        .concat((r.more || []).map((m) => { const l = labOf(m); return row(r, {t: l || deptName(r), lab: l, nw: m.now || "", st: m.state, at: m.at, born: m.born, agent: m.agent, turn: !!m.turn, sid: m.sid, unread: m.unread || 0}); }));
    };
    const groups = list.map((r) => ({r, all: rowsOf(r)})), every = [].concat(...groups.map((g) => g.all));
    dupSids = []; dupUnder = new Map();                // a label tells conversations apart: nothing is folded behind a twin
    // 꺼진 부서 (registered, nothing of it up) are not in this list: the 새 대화 picker finds them.
    const dark = groups.filter((g) => darkRoom(g.r) && g.r.name !== x.name && !g.all.some((o) => o.sid)
      && !(Date.now() - (startedAt[g.r.name] || 0) < START_HOLD)).map((g) => g.r), darkN = new Set(dark.map((r) => r.name));
    ordLast = {list, groups, every};
    const kindOf = (o) => o.draft ? "draft" : o.turn ? "turn" : o.k === "live" ? "live" : o.k === "idle" || o.k === "stale" || o.k === "stuck" ? "wait" : "ended";
    // The filter: the words typed (Claude / Codex narrows by tool the same way).
    const q = foldQ(sessQ), agName = (o) => o.agent === "codex" ? "Codex" : "Claude";
    const okQ = (o) => !q || foldQ([o.lab, o.nw, o.dn, o.pn, agName(o)].join(" ")).includes(q);
    const keep = (o) => okQ(o) && !o.none && !darkN.has(o.pn);
    const stName = (o) => o.turn ? tl("room.fTurn") : o.draft ? tl("room.draftRow") : LABEL[o.k] || LABEL.ended;
    const perDept = new Map(); every.forEach((o) => { if (o.sid) perDept.set(o.pn, (perDept.get(o.pn) || 0) + 1); });
    // Line 2: what it is about and what it is doing; with two or more conversations in one
    // department the label comes first so they can be told apart.
    const line2 = (o) => {
      if (o.draft) return o.pin ? o.lab : tl("room.draftRow");
      const a = clean(o.lab), b = clean(o.nw), many = perDept.get(o.pn) > 1;
      return (many ? [a, b] : [b || a]).filter((v, i, L) => v && L.indexOf(v) === i).join(" · ") || stName(o);
    };
    const keyOf = (o) => o.sid || "p:" + o.pn;
    const when = (o) => String(o.at || ""), bornOf = (o) => o.draft ? "~~" : o.born || "";
    const mk = (o) => {
      if (o.sid) seenRows.add(o.sid);
      const inert = !o.sid && o.pn === x.name;        // the chat being typed in: nothing to open
      const kind = kindOf(o), word = stName(o), l2 = Redact.show(line2(o));
      const lead = o.unreg ? ic("folder") : icoHtml(o.ico) || esc(em1(o.emo)) || ic("folder");
      const end = o.turn ? `<span class="pl-badge me">${tl("room.fTurn")}</span>` : o.unread ? `<span class="pl-badge">${o.unread > 99 ? "99+" : o.unread}</span>` : o.at ? `<span class="pl-time">${esc(ago(o.at))}</span>` : "";
      const say = [o.dn, l2, word, agName(o), o.at ? ago(o.at) : ""].filter(Boolean).join(", ");
      return `<div class="pj-srow pl-row s-${o.turn ? "turn" : o.k || "new"}${inert ? " inert" : " press"}${o.agent === "codex" ? " cx" : ""}${o.on ? " on" : ""}" ${inert ? "" : `role="button" tabindex="0" aria-label="${esc(Redact.show(say))}" `}title="${esc(Redact.show([word, agName(o)].join(" · ") + "\n" + l2))}" ${o.sid ? `data-sid="${esc(o.sid)}" data-pn="${esc(o.pn)}"` : o.dr ? `data-dr="${esc(o.pn)}"` : inert ? "" : `data-p="${esc(o.pn)}"`}${o.on ? ` aria-current="true"` : ""}>
        <span class="pl-lead" aria-hidden="true">${lead}<i class="pl-dot k-${kind}"></i></span>
        <span class="pl-body"><span class="pl-1">${esc(Redact.show(o.dn))}${topPinned(o) ? `<span class="pj-pinmk" title="${esc(tl("session.top.mark"))}">${ic("pin")}</span>` : ""}${o.pin ? pinMk() : ""}</span><span class="pl-2">${esc(l2)}</span></span>
        <span class="pl-end">${end}</span></div>`;
    };
    // The order the person placed (or, until then, a new conversation on top); the sections only
    // split it by need, so a placed row keeps its place among its own kind.
    const L = every.filter((o) => !o.none);
    const all = phone && !listOrd.flat.length ? phoneOrder(L, keyOf) : ORD.arrange(L, listOrd.flat, keyOf, bornOf);
    ordKeys.flat = all.filter((o) => o.sid).map(keyOf);
    const shownRows = all.filter(keep);
    const by = {draft: [], turn: [], live: [], wait: [], ended: []};
    shownRows.forEach((o) => by[kindOf(o)].push(o));
    const sec = (k, label, rows, fold) => rows.length ? `<div class="pl-sec" data-g="sec:${k}"><div class="pl-lab"><span>${esc(label)}</span><span class="pl-n">${rows.length}</span></div>${rows.map(mk).join("")}</div>` : "";
    const endOpen = showPast || !!q || (cur && by.ended.some((o) => o.sid === cur.id));
    const endedBlock = by.ended.length ? `<div class="pl-sec" data-g="sec:ended"><button class="pl-fold press" data-past aria-expanded="${endOpen}">${ic("chev", "i")}<span>${tl("pjx.past", {n: by.ended.length})}</span></button>${endOpen ? by.ended.map(mk).join("") : ""}</div>` : "";
    const rows0 = by.draft.map(mk).join("") + sec("turn", tl("room.fTurn"), by.turn) + sec("live", tl("room.fBusy"), by.live) + sec("wait", LABEL.idle, by.wait) + endedBlock;
    const chosen = sessQ.trim() ? `"${sessQ.trim()}"` : "";
    const rows = rows0 || (q ? `<div class="pj-empty pj-none"><span>${esc(tl("room.noMatchF", {what: chosen}))}</span><button class="pj-fclr press" data-fclear>${tl("room.fClear")}</button></div>` : oldN ? "" : `<div class="pj-empty">${tl("room.noSession")}</div>`);
    const home = list.find((r) => r.name === x.name);
    const oldRows = oldN && showOld ? `<div class="pj-olds pl-sec"><div class="pl-lab"><span>${tl("room.oldLab")}</span></div>`
      + olds.map((s) => mk(ofS(home, s))).join("")
      + (oldInfo.only ? (oldRooms ? oldRooms.filter((r) => r.name !== x.name).map((r) => mk(row(r, {t: deptName(r), lab: "", st: r.state, at: r.at, agent: r.agent}))).join("")
        : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`) : "") + `</div>` : "";
    const oldBtn = oldN && !q ? `<button class="pl-fold pj-oldb press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n: oldN})}</span></button>` + oldRows : "";
    // The open session when the list does not draw it (opened from a link; hidden, older, or past the
    // fold): in its own marked spot on top, so it never takes a place among the rows or moves them.
    const op = x.open && x.open.id && !seenRows.has(x.open.id) && home ? ofS(home, x.open) : null;
    const apartHtml = op && keep(op) ? `<div class="pj-apart pl-sec"><div class="pl-lab"><span>${tl("room.openApart")}</span></div>${mk(op)}</div>` : "";
    const sq = `<input class="pj-search pj-sq" type="search" value="${esc(sessQ)}" placeholder="${esc(tl("room.sessSearch"))}" aria-label="${esc(tl("room.sessSearch"))}">`;
    const newb = `<button class="pj-btn pj-newb g-btn primary" data-newsess aria-haspopup="dialog">${ic("plus")}<span>${tl("room.newSess")}</span></button>`;
    // On a phone the picking bar sits at the foot of the screen, where the thumb is (pickMarks moves it).
    const dock = pickOn && phone;
    return `<div class="pj-lh">` + (pickOn && !dock ? pickBar() : `<div class="pj-lhd pl-hd">${sq}${newb}</div>`) + `</div>
      <div class="pj-srows">${apartHtml}${rows}${hidden ? `<button class="pl-fold pj-tidb press" data-tid><span>${tidOn() ? tl("room.tidHide") : tl("room.tidShow", {n: hidden})}</span></button>` : ""}${oldBtn}${unlinkRows()}</div>${dock ? pickBar(true) : ""}`;
  }

  // ---- a session not opened yet -----------------------------------------------------------------
  // 새 세션 opens nothing by itself (Claude Code has no documented way to hold a background
  // session open without a first line, and a line is never sent in the person's name): the chat
  // is drawn empty with the box ready, and the first line typed opens the real session with it.
  // The model is the one chosen for new sessions (the line under the box changes it).
  // The model chip in the box's lower row and the popover above it: which model and how deep a
  // think this conversation gets. The chip names the pick where the next line will run on it (a
  // session not opened yet, an ended one that resumes with flags, a background job the server
  // starts again on it), with a hollow dot until it is really in effect; else what the session
  // is running on (/api/session/model says which, in `when`). A session opened in a window takes
  // no pick here: its rows are off. A draft keeps its pick here until its first line.
  const MSPARK = `<svg class="sk" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"/></svg>`;
  // No "default" row: the model a session runs on (or will start with) is the row that is marked,
  // with a small tag saying how that is known (now.source). Until a row is pressed nothing is
  // passed, so Claude Code's own default is what runs. A model that is not one of the list gets a
  // first row under its own name. Where nothing says which model it is, no row is marked and the
  // chip reads "모델": no name is made up.
  const MDESC = {"": (src) => src === "run" ? tl("mdl.dKeep") : tl("mdl.dSet"), fable: () => tl("mdl.dFable"), opus: () => tl("mdl.dOpus"),
    sonnet: () => tl("mdl.dSonnet"), haiku: () => tl("mdl.dHaiku")};
  const MTAG = {run: () => tl("mdl.tRun"), set: () => tl("mdl.tSet"), app: () => tl("mdl.tApp"), recent: () => tl("mdl.tRecent")};
  const EDESC = {"": () => tl("mdl.eDef0"), low: () => tl("mdl.eLow"), medium: () => tl("mdl.eMedium"),
    high: () => tl("mdl.eHigh"), xhigh: () => tl("mdl.eXhigh"), max: () => tl("mdl.eMax")};
  // The effort switch reads in the reader's language; the raw step names stay in the data.
  const ESHORT = {low: () => tl("mdl.sLow"), medium: () => tl("mdl.sMedium"), high: () => tl("mdl.sHigh"), xhigh: () => tl("mdl.sXhigh"), max: () => tl("mdl.sMax")};
  // Codex has the same chip over its own names: the models and the levels each one takes come from
  // the installed Codex (the server asks it), so a draft keeps a Codex pick apart from a Claude one.
  // chat-meter:begin
  // A token count as a person says it, a turn's few thousand still showing: 88300 -> "8.8만" / "88.3k".
  const ctxTok = (n) => {
    const f = (v, u) => (v >= 100 ? Math.round(v) : Math.round(v * 10) / 10) + u;
    return LANG() === "ko" ? (n >= 10000 ? f(n / 10000, "만") : n >= 1000 ? f(n / 1000, "천") : String(n)) : n >= 1e6 ? f(n / 1e6, "M") : n >= 1000 ? f(n / 1000, "k") : String(n);
  };
  // How full a conversation is, as one small number (the share where the CLI's record gives one,
  // else the length), orange from 90%. The whole sentence is the tooltip. `k` is the server's `context`.
  function ctxChip(k) {
    if (!k || !k.tokens) return "";
    const up = k.delta ? "+" + ctxTok(k.delta) : "";
    const say = [k.pct != null ? tl("ctx.pct", {pct: k.pct}) : tl("ctx.len", {n: ctxTok(k.tokens)}), k.window ? ctxTok(k.tokens) + " / " + ctxTok(k.window) : "", up ? tl("ctx.turn", {n: up}) : ""].filter(Boolean).join(" · ");
    return `<span class="pj-ctx${k.pct >= 90 ? " hot" : ""}" role="img" aria-label="${esc(say)}" title="${esc(say)}">${k.pct != null ? k.pct + "%" : ctxTok(k.tokens)}</span>`;
  }
  // Beside the model chip: a small ring for how full the conversation is. No number and no red;
  // the numbers are one press away (useCard). Orange only from 90%, where the CLI is about to compact.
  function ctxGauge(k) {
    if (!k || !k.tokens) return "";
    const C = 2 * Math.PI * 5.5, f = k.pct != null ? Math.max(0, Math.min(100, k.pct)) / 100 : 0;
    const say = k.pct != null ? tl("ctx.pct", {pct: k.pct}) : tl("ctx.len", {n: ctxTok(k.tokens)});
    return `<button class="pj-gauge press${k.pct >= 90 ? " hot" : ""}" data-gauge aria-haspopup="dialog" aria-expanded="false" aria-label="${esc(say)}" title="${esc(say)}"><svg viewBox="0 0 16 16" aria-hidden="true"><circle class="tr" cx="8" cy="8" r="5.5"/>${f ? `<circle class="ar" cx="8" cy="8" r="5.5" stroke-dasharray="${(C * f).toFixed(2)} ${C.toFixed(2)}"/>` : ""}</svg></button>`;
  }
  // The gauge's popover: the conversation's memory, then the plan's windows as far as there is a
  // reading (r: ConnUse.read's answer, or null), then the way to the whole usage screen.
  function useCard(k, r, when) {
    const row = (name, t, v, pct, hot) => `<div class="w${hot ? " hot" : ""}"><span class="k">${esc(name)}</span><span class="t">${esc(t || "")}</span><span class="v">${esc(v)}</span>`
      + (pct != null ? `<span class="bar" aria-hidden="true"><i style="width:${Math.max(2, Math.min(100, pct))}%"></i></span>` : "") + `</div>`;
    const size = k.window ? `${ctxTok(k.tokens)} / ${ctxTok(k.window)}` : ctxTok(k.tokens);
    const ctx = row(tl("use.ctx"), k.window && k.pct != null ? size : "", k.pct != null ? k.pct + "%" : size, k.pct, k.pct >= 90)
      + (k.pct >= 90 ? `<p class="s">${tl("use.ctxFull")}</p>` : k.delta ? `<p class="s">${esc(tl("use.turn", {n: ctxTok(k.delta)}))}</p>` : "");
    const wins = !r ? "" : (r.five != null ? row(tl("connuse.t.h5"), r.fiveResets ? tl("uz.reset", {t: when(r.fiveResets)}) : "", tl("connuse.v", {n: r.five}), r.five, r.five >= 90) : "")
      + (r.pct != null ? row(tl("connuse.t.wk"), r.resets ? tl("uz.reset", {t: when(r.resets)}) : "", tl("connuse.v", {n: r.pct}), r.pct, r.pct >= 90) : "");
    return `${ctx}<hr><h5>${tl("use.plan")}</h5>${wins || `<p class="s">${tl("connuse.none")}</p>`}<button type="button" class="go press" data-ugo>${tl("use.more")}</button>`;
  }
  // The same number on a list row or a widget block: only for who asked for it in settings (a bare
  // "93%" beside a session reads as nothing), and with the word in front.
  function ctxRow(k) {
    try { if (localStorage.getItem("v2-ctxrows") !== "1") return ""; } catch { return ""; }
    return ctxChip(k).replace(/(title="[^"]*">)/, "$1" + `<small>${esc(tl("ctx.word"))}</small>`);
  }
  // chat-meter:end
  const draftKey =(name, agent) => (agent === "codex" ? "codex\n" : "") + name;
  function modelChip(wrap, at) {                      // at: {sid} of a conversation, or {name, agent} of a draft
    let v = null, pop = null, sp = null, closing = false, wt = 0, sc = null;
    // The effort control is one mounted element kept across redraws of the popover, so its thumb
    // travels from where it was. Anything with this mount(el, {steps, value, onChange}) fits here.
    let em = null, emHost = null, emKey = "";
    const effortCtl = (host, o) => window.EffortMove.mount(host, o);
    const effLabel = (e) => e ? (ESHORT[e] ? ESHORT[e]() : e) : tl("room.modelBase");
    const effSay = (e) => {                             // while dragging: the level under the thumb, in words
      const a = pop && pop.querySelector("[data-el]"), b = pop && pop.querySelector(".ed");
      if (a) a.textContent = effLabel(e);
      if (b) b.textContent = e ? (EDESC[e] ? EDESC[e]() : "") : cx() ? tl("mdl.cx.eDef0") : EDESC[""]();
    };
    const dk = draftKey(at.name, at.agent);
    const url = "/api/session/model?" + (at.sid ? "sid=" + enc(at.sid) : "name=" + enc(at.name) + (at.agent === "codex" ? "&agent=codex" : ""));
    const pick = () => at.sid ? v.choice : draftModel[dk] || {model: "", effort: ""};
    const cx = () => v.agent === "codex";
    // The levels on offer: Claude's are one list, Codex's belong to the model that would run.
    const levels = (p) => cx() ? ((v.models.find((m) => m.id === (p.model || v.now.family)) || {}).efforts || []) : v.efforts;
    const live = () => v.when === "start" || v.when === "next";
    const off = () => v.when === "restart";              // a window's own session: nothing here changes it
    // A pick on a job takes a moment (it is started again), or waits for the answer in progress:
    // ask again until the server says it is in effect.
    const watch = () => {
      clearTimeout(wt);
      if (!at.sid || !v || !v.waits || v.stuck || v.when !== "next") return;
      wt = setTimeout(async () => {
        if (!wrap.isConnected) return;
        try { v = await get(url); } catch (e) { /* asked again below */ }
        show(pop && pop.contains(document.activeElement) && document.activeElement.parentNode ? document.activeElement.parentNode.dataset.g : "");
      }, 2000);
    };
    const face = () => {
      const p = pick(), m = live() && v.models.find((x) => x.id === p.model);
      // An effort nothing names is left out rather than called "default". The dot: filled while the next line will change something, hollow while a pick waits.
      return {model: m ? m.name : v.now.name || tl("mdl.none"), effort: (live() && p.effort) || v.now.effort || "",
        dot: v.waits ? "w" : live() && ((p.model && p.model !== v.now.family) || (p.effort && p.effort !== v.now.effort)) ? "on" : ""};
    };
    // The gauge beside the chip opens its own small card: fades in place, shut by a press outside or Esc.
    let up = null;
    const useWhen = (t) => { const d = new Date(t * 1000), hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
      return d.toDateString() === new Date().toDateString() ? hm : `${d.getMonth() + 1}/${d.getDate()} ${hm}`; };
    const useFill = () => {
      up.innerHTML = useCard(v.context, window.ConnUse && ConnUse.now ? ConnUse.now(cx() ? "codex" : "claude") : null, useWhen);
      const cr = (wrap.closest(".pj-conv") || document.body).getBoundingClientRect(), wr = wrap.getBoundingClientRect(), gr = wrap.querySelector(":scope>.pj-gauge").getBoundingClientRect();
      const w = Math.min(264, cr.width - 16);
      up.style.width = w + "px";
      up.style.left = Math.max(cr.left + 8, Math.min(gr.left + gr.width / 2 - w / 2, cr.right - 8 - w)) - wr.left + "px";
      up.style.maxHeight = Math.max(160, wr.top - cr.top - 16) + "px";
    };
    const useOut = (e) => { if (e.type === "keydown" ? e.key === "Escape" : !up.contains(e.target) && !e.target.closest("[data-gauge]")) useShut(); };
    const useShut = () => {
      if (!up) return;
      const old = up; up = null;
      document.removeEventListener("pointerdown", useOut, true); document.removeEventListener("keydown", useOut, true);
      const g = wrap.querySelector(":scope>.pj-gauge"); if (g) g.setAttribute("aria-expanded", "false");
      old.classList.remove("on"); setTimeout(() => old.remove(), 160);
    };
    const useOpen = () => {
      shut();
      up = document.createElement("div");
      up.className = "pj-mpop pj-upop"; up.setAttribute("role", "dialog"); up.setAttribute("aria-label", tl("connuse.title"));
      up.onclick = (e) => { e.stopPropagation(); if (e.target.closest("[data-ugo]")) { useShut(); location.hash = "usage"; } };
      wrap.appendChild(up); useFill();
      wrap.querySelector(":scope>.pj-gauge").setAttribute("aria-expanded", "true");
      requestAnimationFrame(() => up && up.classList.add("on"));
      document.addEventListener("pointerdown", useOut, true); document.addEventListener("keydown", useOut, true);
    };
    wrap.addEventListener("click", (e) => { if (e.target.closest("[data-gauge]")) { e.stopPropagation(); if (up) useShut(); else useOpen(); } });
    const html = () => {
      // nowId: the row of what really runs ("" = a row of its own, null = not known, no row marked).
      const p = pick(), listed = v.models.some((m) => m.id === v.now.family), nowId = listed ? v.now.family : v.now.name ? "" : null;
      // The model that runs is the marked row and carries the word for why (in use, the default).
      // "기본" is a row of its own only while what runs is not one of the listed models.
      const on = p.model || nowId || "", eon = p.effort || v.now.effort || "";
      const rows = nowId ? v.models : [{id: "", name: tl("room.modelBase") + (nowId === "" ? " · " + v.now.name : "")}, ...v.models];
      const tag = cx() && v.now.source === "set" ? tl("mdl.cx.tSet") : MTAG[v.now.source] ? MTAG[v.now.source]() : "";
      const desc = (id) => cx() ? (id ? "" : v.now.source === "run" ? tl("mdl.dKeep") : tl("mdl.cx.dSet")) : MDESC[id]?.(v.now.source) || "";
      const lv = levels(p);
      // One line of explanation at most: why a pick is not in effect, else the note on versions.
      const wn = off() ? tl("mdl.wRestart") : v.when === "move" ? tl("mdl.wMove") : v.waits && v.stuck ? tl("mdl.wFail") : v.waits && v.busy ? tl("mdl.wBusy") : v.waits && v.when === "next" && !cx() ? tl("mdl.wApply") : "";
      // One tab stop per group: the marked one, else the first.
      const radio = (on, val, first) => `role="radio" aria-checked="${on}" tabindex="${on || first ? 0 : -1}" data-v="${esc(val)}"${off() ? ` aria-disabled="true"` : ""}`;
      // An effort that is known is marked like the model; "기본" stays only while nothing says it.
      const effs = v.now.effort ? lv : ["", ...lv];
      return `<div class="hd"><h4 id="pj-mh">${tl("mdl.title")}</h4><button class="mx press" data-mx aria-label="${tl("mdl.close")}" title="${tl("mdl.close")}">${ic("x")}</button></div>${wn ? `<p class="wn">${wn}</p>` : ""}
        <div role="radiogroup" aria-label="${tl("mdl.model")}" data-g="model">${rows.map((m, i) =>
          `<button class="pj-mrow" ${radio(m.id === on, m.id, on == null && !i)}><span class="tx"><span class="nm">${esc(m.name)}${m.id === nowId && tag ? `<em>${esc(tag)}</em>` : ""}</span>${desc(m.id) ? `<span class="ds">${esc(desc(m.id))}</span>` : ""}</span><span class="ck" aria-hidden="true">${ic("check")}</span></button>`).join("")}</div>
        ${wn ? "" : `<p class="nt">${cx() ? (nowId == null && !p.model ? tl("mdl.cx.unknown") : tl("mdl.cx.note")) : nowId == null && !p.model ? tl("mdl.unknown") : tl("mdl.note")}</p>`}
        ${lv.length ? `<div class="lb" id="pj-mle">${tl("mdl.effSub")}<b data-el>${esc(effLabel(eon))}</b></div>
        ${window.EffortMove ? `<div data-em></div>` : ""}<div class="pj-meff" role="radiogroup" aria-labelledby="pj-mle" data-g="effort"${window.EffortMove ? " hidden" : ""}>${effs.map((e) =>
          `<button ${radio(e === eon, e)}>${esc(e ? (ESHORT[e]?.() || e) : tl("room.modelBase"))}</button>`).join("")}</div>
        <p class="ed" aria-live="polite">${esc(eon ? (EDESC[eon] ? EDESC[eon]() : "") : cx() ? tl("mdl.cx.eDef0") : EDESC[""]())}</p>` : ""}`;
    };
    // Where it fits: left edge on the chip's, pulled back inside the chat panel, never taller than the room above.
    // On a phone's open chat the popover is a bottom sheet over a veil; it only fades.
    const sheetMode = () => !wide() && document.body.classList.contains("pjchat");
    const place = () => {
      if (pop && pop.classList.contains("sheet")) return;
      const cr = (wrap.closest(".pj-conv") || document.body).getBoundingClientRect(), br = wrap.getBoundingClientRect();
      const w = cr.width < 420 ? cr.width - 16 : 264;      // a phone: the full width, 8px each side
      pop.style.width = w + "px";
      pop.style.left = Math.max(cr.left + 8, Math.min(br.left, cr.right - 8 - w)) - br.left + "px";
      pop.style.maxHeight = Math.max(160, br.top - cr.top - 16) + "px";
      pop.style.transformOrigin = `${Math.round(br.width / 2 - parseFloat(pop.style.left))}px 100%`;
    };
    const show = (focus) => {
      if (!wrap.isConnected || !v || v.hidden) { wrap.innerHTML = ""; pop = null; return; }
      watch();
      let b = wrap.querySelector("[data-mb]");
      if (!b) {
        wrap.innerHTML = `<button class="pj-mbtn press" data-mb aria-haspopup="dialog" aria-expanded="false"></button>`;
        b = wrap.querySelector("[data-mb]");
        b.onclick = (e) => { e.stopPropagation(); if (pop && !closing) shut(); else open(); };
      }
      const f = face();
      b.title = f.dot === "w" ? (v.when === "move" ? tl("mdl.wMove") : v.stuck ? tl("mdl.wFail") : v.busy ? tl("mdl.wBusy") : tl("mdl.chipWait")) : tl("mdl.chip");
      b.setAttribute("aria-label", tl("mdl.chip") + ": " + f.model + (f.effort ? ", " + f.effort : ""));
      b.innerHTML = `${MSPARK}<span class="mn">${esc(f.model)}</span>${f.effort ? `<span class="sep">·</span><b>${esc(f.effort)}</b>` : ""}${f.dot ? `<span class="dt ${f.dot}"></span>` : ""}${ic("chev", "i cv")}`;
      // Beside the chip: how full the conversation is, without opening anything.
      const was = wrap.querySelector(":scope>.pj-gauge"), chip = ctxGauge(v.context);
      if (!was) b.insertAdjacentHTML("afterend", chip);
      else if (was.outerHTML.replace(' aria-expanded="true"', ' aria-expanded="false"') !== chip) { was.outerHTML = chip; const g = up && wrap.querySelector(":scope>.pj-gauge"); if (g) g.setAttribute("aria-expanded", "true"); }
      if (up) { if (v.context && v.context.tokens) useFill(); else useShut(); }
      if (!pop) return;
      pop.innerHTML = html();
      pop.classList.toggle("off", off());
      const slot = pop.querySelector("[data-em]");
      if (slot) {
        const p = pick(), lv = levels(p), val = p.effort || v.now.effort || "";
        const steps = (v.now.effort ? lv : ["", ...lv]).map((e) => ({id: e, label: effLabel(e)})), key = steps.map((s) => s.id).join();
        if (!em) {
          emHost = document.createElement("div"); emHost.className = "pj-mem";
          em = effortCtl(emHost, {steps, value: val, ariaLabel: tl("mdl.effSub"), onChange: (id) => set("effort", id), onInput: effSay});
          emKey = key; slot.replaceWith(emHost);
        } else { slot.replaceWith(emHost); if (key !== emKey) { em.setSteps(steps, val); emKey = key; } else em.setValue(val); }
        if (focus === "effort") emHost.querySelector(".em-track").focus({preventScroll: true});
      }
      place();
      if (focus) { const r = pop.querySelector(`[data-g="${focus}"] [aria-checked="true"]`); if (r) r.focus({preventScroll: true}); }
    };
    const set = async (g, val) => {
      if (off()) { show(g); return; }
      const p = Object.assign({}, pick(), {[g]: val});
      if (p.effort && !levels(p).includes(p.effort)) p.effort = "";     // a level the newly picked model does not take
      if (!at.sid) { if (p.model || p.effort) draftModel[dk] = p; else delete draftModel[dk]; show(g); return; }
      v.choice = p;
      v.waits = !live() && !!((p.model && p.model !== v.now.family) || (p.effort && p.effort !== v.now.effort));
      show(g);
      try { v = await post("/api/session/model", {sid: at.sid, model: p.model, effort: p.effort}); }
      catch (e) { toast(e.message); try { v = await get(url); } catch (e2) { /* keeps what it shows */ } }
      show(pop && pop.contains(document.activeElement) ? g : "");
    };
    const onKey = (e) => { if (e.key === "Escape" && pop) { e.stopPropagation(); shut(); const b = wrap.querySelector("[data-mb]"); if (b) b.focus(); } };
    // Open and close grow from the chip on one stepped spring, so a press mid-way turns it round
    // from where it is. Reduced motion: no movement, a short fade.
    const draw = (x) => { if (!pop) return; pop.style.opacity = Math.max(0, Math.min(1, x * 1.5)).toFixed(3);
      if (sc) sc.style.opacity = Math.max(0, Math.min(1, x)).toFixed(3);
      pop.style.transform = x > 0.999 || pop.classList.contains("sheet") ? "" : `translateY(${((1 - x) * 8).toFixed(2)}px) scale(${(0.9 + 0.1 * x).toFixed(4)})`; };
    let portalWatch = null;
    const out = (e) => { if (pop && !wrap.contains(e.target) && !pop.contains(e.target)) shut(); };
    const gone = () => { if (portalWatch) portalWatch.disconnect(); portalWatch = null;
      if (pop) pop.remove(); if (sc) sc.remove(); if (em) em.destroy(); pop = sp = em = emHost = sc = null; closing = false; };
    const shut = () => {
      if (!pop || closing) return;
      closing = true; pop.style.pointerEvents = "none";
      const b = wrap.querySelector("[data-mb]");
      if (b) b.setAttribute("aria-expanded", "false");
      document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", onKey, true); removeEventListener("resize", place);
      if (sp && !RM()) sp.set(0);
      else if (pop.animate) { if (sc) sc.animate([{opacity: 1}, {opacity: 0}], {duration: 140, easing: "ease-out", fill: "forwards"});
        const a = pop.animate([{opacity: 1}, {opacity: 0}], {duration: 140, easing: "ease-out", fill: "forwards"}); a.onfinish = a.oncancel = gone; }
      else gone();
    };
    const open = () => {
      useShut();
      if (!pop) {
        pop = document.createElement("div");
        pop.className = "pj-mpop"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-labelledby", "pj-mh");
        if (sheetMode()) {
          pop.classList.add("sheet");
          sc = document.createElement("div"); sc.className = "pj-mscrim"; document.body.appendChild(sc);
          sc.onclick = (e) => { e.stopPropagation(); shut(); };
          const a = document.activeElement; if (a && a.matches && a.matches("textarea,input")) a.blur();   // the keyboard goes down: the sheet has the room
        }
        // Fixed sheets must escape the composer's clipping and transform contexts.
        (sc ? document.body : wrap).appendChild(pop);
        if (sc) { portalWatch = new MutationObserver(() => { if (!wrap.isConnected) {
          document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", onKey, true);
          removeEventListener("resize", place); gone();
        } }); portalWatch.observe(document.body, {childList: true, subtree: true}); }
        pop.onclick = (e) => {
          e.stopPropagation();
          if (e.target.closest("[data-mx]")) { shut(); const b = wrap.querySelector("[data-mb]"); if (b) b.focus({preventScroll: true}); return; }
          // The marked row can be pressed too: shown as the default it passes nothing, pressed it is a pick.
          const r = e.target.closest("[role=radio]"), g = r && r.parentNode.dataset.g;
          if (r && (r.getAttribute("aria-checked") !== "true" || pick()[g] !== r.dataset.v)) set(g, r.dataset.v);
        };
        // Arrows move the choice inside a group, as radios do; Tab goes on to the next group.
        pop.onkeydown = (e) => {
          const r = e.target.closest("[role=radio]"), d = {ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1}[e.key];
          if (!r || !d) return;
          e.preventDefault();
          const all = [...r.parentNode.querySelectorAll("[role=radio]")];
          set(r.parentNode.dataset.g, all[(all.indexOf(r) + d + all.length) % all.length].dataset.v);
        };
        if (window.Motion && Motion.phys && !RM()) { sp = Motion.phys(0, 520, 40, draw); sp.rest = () => { if (closing) gone(); }; draw(0); }
        else if (pop.animate) { pop.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); if (sc) sc.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
      } else if (!sp) { pop.getAnimations().forEach((a) => { a.onfinish = a.oncancel = null; a.cancel(); }); }   // caught while fading out
      closing = false; pop.style.pointerEvents = "";
      wrap.querySelector("[data-mb]").setAttribute("aria-expanded", "true");
      document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", onKey, true); addEventListener("resize", place);
      show("model");
      if (sp) sp.set(1);
      // The session may have ended or started since the chip was drawn: ask again, quietly.
      get(url).then((r) => { v = r; if (pop) show(pop.contains(document.activeElement) ? document.activeElement.parentNode.dataset.g : ""); else show(); }).catch(() => {});
    };
    get(url).then((r) => { v = r; show(); }).catch(() => {});
    // An answer may come from another model than the chip names (started again, switched inside
    // the session): when the chat grows the chip asks again, at most every 8s, and shows what is true.
    const msgs = at.sid && window.MutationObserver && (wrap.closest(".pj-conv") || document).querySelector("#pj-msgs");
    if (msgs) {
      let last = Date.now(), due = 0;
      const mo = new MutationObserver(() => {
        if (!wrap.isConnected) return mo.disconnect();
        if (due) return;
        due = setTimeout(() => { due = 0; last = Date.now();
          if (!wrap.isConnected || document.hidden) return;
          get(url).then((r) => { if (!v || JSON.stringify([r.now, r.choice, r.when, r.waits, r.context]) === JSON.stringify([v.now, v.choice, v.when, v.waits, v.context])) return;
            v = r; show(); }).catch(() => {}); }, Math.max(1500, 8000 - (Date.now() - last)));
      });
      mo.observe(msgs, {childList: true, subtree: true});
    }
    // The lower row holds picture, chip, department and send; where the box is too narrow for all
    // of them the department (the header says it too) and the Enter hint give way.
    const box = wrap.closest(".pj-box");
    if (box && window.ResizeObserver) new ResizeObserver(([e]) => { box.classList.toggle("pj-tight", e.contentRect.width < 520); box.classList.toggle("pj-slim", e.contentRect.width < 440); }).observe(box);
  }
  function drawDraft(body, name, head, focus) {
    // Which one answers is picked here, before the first line: the department's own is only the start.
    // It sits in the box beside the model chip (the state row above is hidden under the chat's own header).
    let agent = draftAgent[name] || (head.agent === "codex" ? "codex" : "claude");
    // Once only: the dim line under a first Codex draft (kept in this browser, like other prefs).
    const cxSeen = () => { try { return localStorage.getItem("genok.cxapphint") === "1"; } catch (err) { return true; } };
    const pick = `<div class="seg pj-seg2 pj-agseg" data-agseg role="group" aria-label="Claude / Codex">${[["claude", "Claude"], ["codex", "Codex"]].map(([v, l]) =>
      `<button class="${v === agent ? "on" : ""} press" data-v2="${v}" aria-pressed="${v === agent}">${window.agDot(v)}${l}</button>`).join("")}</div>`;
    body.innerHTML = `<div class="pj-conv pj-draft" data-col="conv">
        <div class="pj-state">${dot("ended")}<span>${esc(head.fixed || tl("room.newSess"))}</span><span class="sp"></span></div>
        <div class="pj-wrap"><div class="pj-msgs" id="pj-msgs"><div class="pj-empty pj-anim"><b>${tl("room.draftHead")}</b>${tl("room.draftSub")}</div></div></div>
        <div class="pj-to" id="pj-to">${toLine({name, emoji: head.emoji || emoOf(name), conv: head.fixed || tl("room.toNew"), agent})}</div>
        <div class="pj-in"><div class="pj-box">
          <textarea id="pj-ta" rows="1" placeholder="${esc(tl("room.draftPh"))}" aria-label="${esc(tl("room.draftPh"))}"></textarea>
          ${pick}<span class="pj-mwrap" id="pj-ml"></span><span class="pj-pjn">${em(head.emoji || emoOf(name), "", head.icon || icoOf(name))}<span>${esc(unEm(pname(name), head.emoji || emoOf(name) || icoHtml(head.icon || icoOf(name))))}</span></span><span class="pj-enter">${tl("room.enterSend")}</span>
          ${micHtml()}
          <button class="pj-go press" id="pj-send" aria-label="${tl("pj.send")}" title="${tl("pj.send")}" disabled>${ic("up")}<span class="pj-spin" aria-hidden="true"></span></button></div></div>
        <div class="pj-hint" id="pj-cxh" style="margin:6px 14px 0"${agent === "codex" && !cxSeen() ? "" : " hidden"}>${tl("connect.cx_app")}</div>
      </div>`;
    const ta = body.querySelector("#pj-ta"), go = body.querySelector("#pj-send"), box0 = body.querySelector(".pj-box");
    let sending = false;
    ta.value = drafts[name] || "";
    body.querySelectorAll("[data-agseg] [data-v2]").forEach((b) => b.onclick = () => {
      if (sending || b.dataset.v2 === agent) return;
      // In place: the header, the typed text and the caret stay where they are.
      agent = draftAgent[name] = b.dataset.v2;
      body.querySelectorAll("[data-agseg] [data-v2]").forEach((x) => { const on = x.dataset.v2 === agent; x.classList.toggle("on", on); x.setAttribute("aria-pressed", on); });
      const to = body.querySelector("#pj-to");
      const cxh = body.querySelector("#pj-cxh"); if (cxh) cxh.hidden = agent !== "codex" || cxSeen();
      if (to) to.innerHTML = toLine({name, emoji: head.emoji || emoOf(name), conv: head.fixed || tl("room.toNew"), agent});
      const hs = body.querySelector(".pj-nth .s");   // the chat's own header says who answers
      if (hs) hs.textContent = [pname(name), agent === "codex" ? "Codex" : "Claude", tl("room.draftRow")].join(" · ");
      const m = body.querySelector("#pj-ml");
      if (m) { const n = m.cloneNode(false); m.replaceWith(n); modelChip(n, {name, agent}); }   // a fresh node: the old chip's late answers land nowhere
      ta.focus({preventScroll: true});
    });
    const sync = () => {
      go.disabled = sending || !ta.value.trim(); go.classList.toggle("busy", sending);
      // Measured while the screen was not laid out yet, scrollHeight is 0 and "0px" would stick
      // (the empty box cut its own placeholder in half): an empty or unmeasured box keeps its CSS height.
      if (!ta.value || !ta.scrollHeight) { ta.style.height = ""; return; }
      ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 160) + "px";
    };
    ta.addEventListener("input", () => { drafts[name] = ta.value; sync(); });
    box0.addEventListener("click", (e) => { if (e.target === box0) ta.focus(); });
    // What the pane shows: the invitation, the line on its way, or why it did not go (with a way to
    // try again). The typed text stays in the box until a session has really taken it.
    const msgs = body.querySelector("#pj-msgs"), invite = msgs.innerHTML;
    const failed = (why) => {
      // Folder trust is Claude Code's own question: one button opens it there, then try again.
      const tf = draftCode[name] === "folder_untrusted" ? `<button class="pj-btn light press" style="margin:12px 6px 0 0" data-tf>${tl("perm.cli_cc_btn")}</button>` : "";
      msgs.innerHTML = `<div class="pj-empty" role="alert" data-serr><b>${tl("room.sendFail")}</b>${esc(why)}<br>${tf}<button class="pj-btn${tf ? "" : " light"} press" style="margin-top:12px" data-again>${tl("room.retry")}</button></div>`;
      msgs.querySelector("[data-again]").onclick = () => send();
      // Each request opens a terminal: three presses while the first was on its way opened three.
      if (tf) { const tb = msgs.querySelector("[data-tf]"); tb.onclick = saving(tb, () => post("/api/connect/trust-folder", {name}).then(() => toast(tl("perm.cli_opened"))).catch((e) => toast(e.message))); }
    };
    if (draftErr[name]) failed(draftErr[name]);
    // Drawn again while the first line is still on its way: it is still shown as on its way.
    const going = (text) => { sending = true; ta.readOnly = true; sync(); msgs.innerHTML = pendRow({text, busy: true, tag: tl("room.sending")}, 0); };
    if (draftBusy[name]) going(draftBusy[name]);
    const send = async () => {
      Dictate.cut();
      const text = ta.value.trim(); if (!text || sending) return;
      delete draftErr[name]; delete draftCode[name];
      draftBusy[name] = text; going(text);
      try {
        // What the chip picked goes with the first line; nothing picked sends nothing.
        const dm = draftModel[draftKey(name, agent)] || {}, m = {};
        if (dm.model) m.model = dm.model;
        if (dm.effort) m.effort = dm.effort;
        // Only 새 세션 pressed by the person opens another; otherwise the server sends the line
        // to the conversation the project has, and opens one when it has none.
        const r = await act("/api/session/new", Object.assign({name, agent, text}, head.fresh ? {mode: "new"} : {}, m));
        delete draftBusy[name];
        started(r.name || name);
        delete drafts[name]; delete draftModel[name]; delete draftModel[draftKey(name, "codex")]; delete draftAgent[name]; roomsCache = null;
        if (agent === "codex") { try { localStorage.setItem("genok.cxapphint", "1"); } catch (err) { /* shown again next time */ } }
        // Claude has not named it yet: the page waits for it (waitNew) instead of an older one.
        // One with an id waits for the list the same way, so the page never opens something else.
        if (r.sid || r.job) pendNew[r.name || name] = {job: r.job, sid: r.sid, text, at: Date.now()};
        nav("project/" + enc(r.name || name) + (r.sid ? "/" + enc(r.sid) : ""));
      } catch (e) {
        delete draftBusy[name];
        sending = false; ta.readOnly = false; sync();
        if (e.message === "cancelled") msgs.innerHTML = invite;
        else { draftErr[name] = e.message || tl("room.failed"); draftCode[name] = e.code; failed(draftErr[name]); if (!msgs.isConnected) toast(draftErr[name]); }   // said once: in the pane when it is up
        if (!msgs.isConnected && where().name === name) render();   // the pane was drawn again meanwhile
      }
    };
    go.onclick = send;
    micWire(body, ta);
    // Enter sends, Shift+Enter breaks the line; the Enter that ends a composition does not send.
    let composing = false;
    ta.addEventListener("compositionstart", () => { composing = true; });
    ta.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    ta.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); send();
    });
    sync();
    const ml = body.querySelector("#pj-ml");
    if (ml) modelChip(ml, {name, agent});
    if (focus) setTimeout(() => { if (ta.isConnected) ta.focus({preventScroll: true}); }, 60);
  }

  function card(s, selSid) {
    const k = pjKindOf(s.state, s.last);
    return `<div class="pj-card pj-row press ${s.id === selSid ? "on" : ""}${busy[s.id] ? " busy" : ""}" data-sid="${esc(s.id)}" role="button" tabindex="0"${busy[s.id] ? ` aria-busy="true"` : ""}>
      <div class="r1">${dot(k)}<div class="t">${esc(Redact.show(title(s)))}</div>${s.unread && s.id !== selSid ? `<b class="pj-un num" aria-label="${tl("room.unread", {n: s.unread})}">${s.unread >= 99 ? "99+" : s.unread}</b>` : ""}
        <button class="pj-more press" data-more="${esc(s.id)}" aria-label="${tl("pj.menu")}">${ic("more")}</button></div>
      <div class="r2"><span class="pj-stl ${k}">${esc(busy[s.id] || LABEL[k] || k)}</span>${agentTag(s.agent)}${window.RLAcct ? RLAcct.chip(s) : ""}${s.bg ? `<span class="pj-bg">${tl("pj.bg")}</span>` : ""}${s.moved ? `<span class="pj-bg">${tl("pj.moved")}</span>` : ""}${s.pinned ? `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>` : ""}${ctxRow(s.context)}<span>${s.last ? ago(s.last) : ""}</span></div></div>`;
  }

  // Projects being opened right now, and when one was last opened from the list (its new session
  // takes a moment to be read into the list; 켜기 stays away meanwhile so it is not pressed twice).
  const UP_ST = ["live", "idle", "stuck"], START_HOLD = 90000, starting = new Set(), startedAt = {};
  // A session just opened for a department: once the list has it, it is the one shown (while the
  // person is still on that department's page).
  async function followStart(pn) {
    for (const t0 = Date.now(); Date.now() - t0 < START_HOLD;) {
      await new Promise((ok) => setTimeout(ok, 2000));
      const d = await get("/api/project/rooms").catch(() => null), r = d && (d.rooms || []).find((v) => v.name === pn);
      if (!r || !r.sid || !UP_ST.includes(r.state)) continue;
      roomsCache = null;
      if (location.hash === "#project/" + enc(pn)) nav("project/" + enc(pn) + "/" + enc(r.sid));
      return;
    }
  }
  // 켜기 (the list beside the chat and the phone's cards share it). `redraw` paints the caller's list.
  const darkRoom = (r) => !!r.registered && !r.sid && !r.fixed && !UP_ST.includes(r.state) && !r.copies;
  // `pick`: the past talk to bring back ({sid, title, agent}), or null for a new session.
  async function turnOn(pn, pick, redraw) {
    if (starting.has(pn)) return;
    const b = pick;
    starting.add(pn); redraw();
    let ok = false;
    if (b) await control("open", {id: b.sid, agent: b.agent || "claude", state: "ended", title: b.title}, pn, () => { ok = true; });
    else ok = await openDept(pn);
    starting.delete(pn);
    if (!ok) return redraw();
    startedAt[pn] = Date.now(); roomsCache = null; sessQ = "";
    if (b) return nav("project/" + enc(pn) + "/" + enc(b.sid));
    nav("project/" + enc(pn)); followStart(pn);
  }
  // The talks a department that is off had, newest first (the first is where Enter lands), then
  // 새로 시작: one press on a line does it. `shut` closes what holds the lines.
  const pastOf = (pn) => { const r = (roomsCache || roomsSeen || []).find((v) => v.name === pn), bk = r && r.back; return bk ? (bk.past && bk.past.length ? bk.past : [bk]) : []; };
  function onLines(pn) {
    const past = pastOf(pn), r = (roomsCache || roomsSeen || []).find((v) => v.name === pn), n = (r && r.back && r.back.n) || 0;
    const line = (m, i) => `<button class="two" role="menuitem" data-i="${i}"${i ? "" : ` aria-current="true"`}><span>${esc(m.title && m.title !== "(제목 없음)" ? m.title : pname(pn))}</span><small>${m.at ? esc(ago(m.at)) : ""}</small></button>`;
    return past.map(line).join("") + (n > past.length ? `<button role="menuitem" data-a="past">${ic("list")}<span>${tl("room.offPast", {n})}</span></button>` : "")
      + `<hr><button role="menuitem" data-a="fresh">${ic("plus")}<span>${tl("room.offFresh")}</span></button>`;
  }
  function onWire(box, pn, shut, redraw) {
    const past = pastOf(pn);
    box.querySelectorAll("button[data-i],button[data-a]").forEach((m) => m.onclick = (e) => {
      e.stopPropagation(); shut();
      if (m.dataset.a === "past") { showOld = true; return nav("project/" + enc(pn)); }
      turnOn(pn, m.dataset.a === "fresh" ? null : past[+m.dataset.i], redraw);
    });
    const first = box.querySelector("button[data-i]"); if (first) first.focus({preventScroll: true});
    box.onkeydown = (e) => { if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
      const l = [...box.querySelectorAll("button[data-i],button[data-a]")], i = l.indexOf(document.activeElement); if (i < 0) return;
      e.preventDefault(); l[(i + (e.key === "ArrowDown" ? 1 : l.length - 1)) % l.length].focus({preventScroll: true}); };
  }
  // 켜기 asks which. One with no past talk starts new at once. Beside the button on a wide window,
  // the bottom sheet on a phone.
  function askOn(btn, pn, redraw) {
    if (starting.has(pn)) return;
    if (!pastOf(pn).length) return turnOn(pn, null, redraw);
    if (!wide()) return sheet(`<div class="pj-onp" role="menu" aria-label="${esc(pname(pn))}"><b class="h">${esc(pname(pn))}</b>${onLines(pn)}</div>`, (box) => onWire(box.querySelector(".pj-onp"), pn, closeSheet, redraw));
    document.querySelectorAll(".pj-pop").forEach((n) => n.remove());
    const pop = document.createElement("div"); pop.className = "pj-pop cm pj-onp"; pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", tl("room.on"));
    pop.innerHTML = onLines(pn);
    const off = popAt(pop, btn);
    onWire(pop, pn, off, redraw);
  }
  // 여러 {unit} 고르기 (same caret): the folders that are off, newest first, as a checklist (bulkstart.js).
  async function manyOn() {
    if (!roomsCache) { try { await loadRooms(); } catch (e) { return toast(e.message); } }
    const off = (roomsCache || []).filter(darkRoom).sort((a, b) => String((b.back && b.back.at) || "").localeCompare(String((a.back && a.back.at) || "")));
    window.LOOP_BULK_START(off.map((r) => ({name: r.name, mark: em(r.emoji, r.color, r.icon)})), () => { roomsCache = null; if (railNow) railNow(); });
  }
  const onBtnHtml = (pn, tag) => starting.has(pn) ? `<${tag} class="pj-on" data-on="${esc(pn)}" ${tag === "button" ? "disabled" : `role="button" aria-disabled="true"`} aria-busy="true">${tl("room.onBusy")}</${tag}>`
    : `<${tag} class="pj-on press" data-on="${esc(pn)}"${tag === "button" ? "" : ` role="button" tabindex="0"`}>${tl("room.on")}</${tag}>`;
  async function openDept(name) {                     // true once it opened; why not is said in a toast
    try {
      if (window.RLAcct && !(await RLAcct.confirmStart([name]))) return false;
      const res = await act("/api/depts/open", {name});
      toast((res && res.note) || tl("pjx.done.open"));
      if (res && res.via === "bg" && window.RLAcct) RLAcct.watchStart(name);
      return !!res;
    }
    catch (e) { if (e.message !== "cancelled") toast(e.message); return false; }
  }

