// Genok web UI, 결과물 › 기록: every result ever pushed, approved or put away, as
// project -> conversation -> a filmstrip of versions. Approving a result takes it off the review
// queue, not out of sight: the old cuts stay here to look back at.
// A classic script in the page's shared scope; v2.html loads it after v2-results.js, which draws
// the other tab ("검토할 것") and calls recDraw() when this one is chosen.
//
// Data: /api/projects gives each project's counts (live + archived); a project's results are read
// when it is opened: /api/items?p=X (live) and &archived=1, each carrying `vers`, its versions
// (web/../index.py). A conversation is named from the open rooms when they know it, else by
// department and day.
const resTab = (v) => { try { if (v) localStorage.setItem("genok-res-tab", v); else return localStorage.getItem("genok-res-tab") === "record" ? "record" : "review"; } catch { /* storage blocked */ } return v || "review"; };
let recProj = null, recProjAt = 0, recProjP = null;
const recOpen = new Set(), recItems = new Map(), recFail = new Set();
let recSeeded = false;

// The page header both tabs share: title, one sub line, the two tabs.
const resHead = (tab, sub) => `<header class="g-head rv-head"><div class="g-ht"><h1>${esc(tl("TABS.3"))}</h1><p class="g-sub" id="rvsub">${sub}</p></div></header>
  <div class="g-seg rv-seg" role="tablist" aria-label="${esc(tl("lib.tab"))}">${[["review", tl("lib.tab.review")], ["record", tl("lib.tab.record")]].map(([k, n]) =>
    `<button type="button" class="press${k === tab ? " on" : ""}" role="tab" aria-selected="${k === tab}" data-rvtab="${k}">${esc(n)}</button>`).join("")}</div>`;
const recTotal = () => (recProj || []).reduce((a, p) => a + p.items + p.archived, 0);
// "검토할 것 3 · 전체 580": the total comes with the projects, so the line grows once they are in.
const resSub = (mine) => {
  const sub = recProj ? tl("lib.sub.review", {n: mine, all: recTotal()}) : tl("lib.sub.review1", {n: mine});
  if (!recProj) recProjects().then(() => { const el = document.getElementById("rvsub"); if (el && cur === "lib" && resTab() === "review") el.textContent = tl("lib.sub.review", {n: D.items.filter(stMine).length, all: recTotal()}); }).catch(() => {});
  return esc(sub);
};

function recProjects() {
  if (recProj && Date.now() - recProjAt < 30000) return Promise.resolve(recProj);
  return recProjP ||= get("/api/projects").then((l) => {
    recProj = l.filter((p) => p.items + p.archived > 0).sort((a, b) => (b.updated || "").localeCompare(a.updated || ""));
    recProjAt = Date.now(); return recProj;
  }).finally(() => { recProjP = null; });
}
// sid -> the name the conversation goes by, from the rooms the app already holds.
function recNames() {
  const m = new Map();
  attL("rooms").forEach((r) => {
    if (r.sid) m.set(r.sid, r.named || r.label || r.title || "");
    [r.back, ...(r.back?.past || [])].forEach((b) => { if (b?.sid) m.set(b.sid, b.title || b.label || ""); });
  });
  return m;
}
const recDay = (t) => t ? new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "short", day: "numeric"}) : "";
const recWord = (s) => s === "approved" ? tl("STATUS_T.4") + " ✓" : s === "changes" ? tl("STATUS_T.2") : s === "hold" ? tl("STATUS_T.3") : tl("lib.rec.pending");

// One cluster per conversation that pushed; versions with no conversation id cluster by
// department and day. Newest cluster first; inside, the versions in time order.
function recClusters(items) {
  const m = new Map();
  for (const x of items) for (const w of x.vers || []) {
    const k = w.sid ? "s:" + w.sid : "d:" + (w.dept || "") + "|" + (w.at || "").slice(0, 10);
    let c = m.get(k); if (!c) m.set(k, c = {k, sid: w.sid || "", dept: w.dept || "", vs: []});
    c.vs.push({x, w});
  }
  const L = [...m.values()];
  L.forEach((c) => c.vs.sort((a, b) => (a.w.at || "").localeCompare(b.w.at || "")));
  return L.sort((a, b) => (b.vs.at(-1).w.at || "").localeCompare(a.vs.at(-1).w.at || ""));
}
function recTile({x, w}) {
  const id = iid(x), latest = x.vers.at(-1).v, can = w.v !== latest;
  return `<li class="rv-t"><a class="rv-tb press" href="#item/${esc(id)}" data-hv="${esc(id)}" data-v="${esc(w.v)}" data-latest="${esc(latest)}" aria-label="${esc(tl("lib.rec.open", {t: x.title, v: vShort(w.v)}))}">
      <span class="rv-th">${ic((KIND[w.kind] || ["doc"])[0])}${w.thumb ? imgTag(w.thumb) : ""}</span>
      <span class="rv-tt">${esc(x.title)}</span><span class="rv-tm${w.s === "approved" ? " ok" : ""}">${esc(vShort(w.v))} · ${esc(recWord(w.s))}</span></a>
    ${can ? `<a class="rv-cmp press" href="#item/${esc(id)}" data-hc="${esc(id)}" data-v="${esc(w.v)}" data-latest="${esc(latest)}" aria-label="${esc(tl("lib.rec.cmp.a", {t: x.title, v: vShort(w.v)}))}">${esc(tl("lib.rec.cmp"))}</a>` : ""}</li>`;
}
function recBody(items) {
  if (!items.length) return `<p class="rv-none">${esc(tl("lib.rec.none"))}</p>`;
  const names = recNames();
  return recClusters(items).map((c) => {
    const first = c.vs[0].w.at, last = c.vs.at(-1).w.at, a = recDay(first), b = recDay(last);
    const title = names.get(c.sid) || `${pname(c.dept || gname(c.vs[0].x))} · ${a}`;
    return `<div class="rv-cl"><div class="rv-ct"><span class="rv-cn">${esc(title)}</span><span class="rv-cs">${esc(a === b ? a : a + " – " + b)} · ${esc(tl("lib.rec.vers", {n: c.vs.length}))}</span></div>
      <ul class="rv-strip">${c.vs.map(recTile).join("")}</ul></div>`;
  }).join("");
}
async function recLoad(name) {
  if (recItems.has(name)) return;
  try {
    const q = "/api/items?p=" + encodeURIComponent(name);
    const [live, arch] = await Promise.all([get(q), get(q + "&archived=1")]);
    recItems.set(name, [...live, ...arch]); recFail.delete(name);
  } catch { recFail.add(name); }
}
async function recFill(name) {
  const sec = [...document.querySelectorAll(".rv-p")].find((s) => s.dataset.p === name), box = sec?.querySelector(".rv-pb");
  if (!box || !recOpen.has(name)) return;
  if (!recItems.has(name)) {
    box.innerHTML = `<div class="rv-ld">${loadingHtml("", {size: 20})}</div>`;
    await recLoad(name);
    if (!box.isConnected || !recOpen.has(name)) return;
  }
  box.innerHTML = recFail.has(name) ? `<p class="rv-none">${esc(tl("lib.rec.err"))} <button type="button" class="g-btn quiet press" data-rvretry="${esc(name)}">${esc(tl("netBar.2"))}</button></p>` : recBody(recItems.get(name));
  box.classList.add("in");
}
function recDraw() {
  V().innerHTML = `<div class="rv rv-rec">${resHead("record", esc(recProj ? tl("lib.sub.record", {u: unitWord(), p: recProj.length, n: recTotal()}) : ""))}<div class="rv-list" id="rvl">${recProj ? "" : `<div class="rv-ld">${loadingHtml("", {size: 20})}</div>`}</div></div>`;
  const paint = () => {
    const host = document.getElementById("rvl"); if (!host || resTab() !== "record") return;
    if (!recSeeded) { recSeeded = true; recProj.slice(0, 3).forEach((p) => recOpen.add(p.name)); }
    document.getElementById("rvsub").textContent = tl("lib.sub.record", {u: unitWord(), p: recProj.length, n: recTotal()});
    host.innerHTML = recProj.length ? recProj.map((p) => {
      const on = recOpen.has(p.name);
      return `<section class="rv-p" data-p="${esc(p.name)}"><button type="button" class="g-row rv-ph press" data-rp="${esc(p.name)}" aria-expanded="${on}">
        <span class="g-lead">${ic("folder")}${p.thumb ? imgTag(p.thumb) : ""}</span>
        <span class="g-body"><span class="g-l1">${esc(pname(p.name))}</span><span class="g-l2">${esc(tl("lib.rec.res", {n: p.items + p.archived}))} · ${ago(p.updated)}</span></span>
        <span class="g-end">${ic("chev", "i fc")}</span></button><div class="rv-pb"${on ? "" : " hidden"}></div></section>`;
    }).join("") : `<p class="rv-none">${esc(tl("lib.rec.none"))}</p>`;
    recProj.forEach((p) => recFill(p.name));
  };
  recProjects().then(paint, () => { const h = document.getElementById("rvl"); if (h) h.innerHTML = `<p class="rv-none">${esc(tl("lib.rec.err"))} <button type="button" class="g-btn quiet press" data-rvretry="">${esc(tl("netBar.2"))}</button></p>`; });
  return {};
}

document.addEventListener("click", (e) => {
  const t = e.target.closest?.("[data-rvtab],[data-rp],[data-rvretry],a[data-hv],a[data-hc]"); if (!t || cur !== "lib" || detail) return;
  if (t.dataset.rvtab) { if (resTab() !== t.dataset.rvtab) { resTab(t.dataset.rvtab); libSel = null; SCREENS.lib(); } return; }
  if (t.dataset.rp !== undefined) {
    const n = t.dataset.rp, on = !recOpen.has(n);
    on ? recOpen.add(n) : recOpen.delete(n);
    t.setAttribute("aria-expanded", on); t.nextElementSibling.hidden = !on;
    if (on) { t.nextElementSibling.classList.remove("in"); recFill(n); }
    return;
  }
  if (t.dataset.rvretry !== undefined) {
    if (t.dataset.rvretry) { recFail.delete(t.dataset.rvretry); recFill(t.dataset.rvretry); } else recDraw();
    return;
  }
  e.preventDefault();
  const id = t.dataset.hv || t.dataset.hc, v = t.dataset.v, latest = t.dataset.latest;
  // A version opens the item on that version; the compare puts it against the newest.
  if (t.dataset.hc) return nav(cmpHashStr(id, latest, v, cmpMode()).slice(1));
  if (v === latest) delete verPick[id]; else verPick[id] = v;
  nav("item/" + id);
});
