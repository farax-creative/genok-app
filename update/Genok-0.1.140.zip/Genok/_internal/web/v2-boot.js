// Genok web UI, cut from v2.js: J/K, 하나씩, and the page's events (the last part: it starts the app).
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- J/K: 내 차례 and 확인 필요 by keyboard ----------
// J/K walk a ring down the list, Enter opens, A 승인, R 코멘트, H 나중에, Y 맞아 on a claimed
// fix. What was acted on folds away and the ring stays where it was, on the next one. The
// ring is kept by key, so the 30-second redraw does not lose it.
let tkOn = "", tkAt = 0, tkId = "";
const tkPage = () => !detail && ((cur === "inbox" && inTab === "do" && !window.GQ) || cur === "lib" || cur === "home") ? cur : "";
// Rows inside a folded group are not walked.
const tkEls = () => [...V().querySelectorAll("[data-tk]")].filter((el) => el.offsetParent);
const tkKey = (el) => { const d = el.querySelector("[data-dv]"); if (d) return "d:" + d.dataset.dv;
  const o = el.matches("[data-item],[data-talk],[data-go]") ? el : el.querySelector("[data-item],[data-talk],[data-go]"); return o ? o.dataset.item || o.dataset.talk || o.dataset.go : ""; };
function triMark(scroll = false) {
  const L = tkEls(); L.forEach((el) => el.classList.remove("tkf"));
  if (!tkOn || tkOn !== tkPage() || !L.length) return;
  let i = L.findIndex((el) => tkKey(el) === tkId); if (i < 0) i = Math.min(tkAt, L.length - 1);
  tkAt = i; tkId = tkKey(L[i]); L[i].classList.add("tkf");
  if (scroll) L[i].scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"});
}
// The row closes up before the list redraws without it, so the eye sees where it went.
function tkFold(el, then) {
  tkId = ""; el.style.overflow = "hidden";
  const a = RM() ? el.animate([{opacity: 1}, {opacity: 0}], {duration: 140, fill: "forwards"})
    : el.classList.contains("gw") ? el.animate([{transform: "none", opacity: 1}, {transform: "scale(.92)", opacity: 0}], {duration: 200, easing: "cubic-bezier(.2,.9,.25,1)", fill: "forwards"})
    : el.animate([{height: el.offsetHeight + "px", minHeight: 0, opacity: 1}, {height: "0px", minHeight: 0, paddingTop: 0, paddingBottom: 0, opacity: 0}], {duration: 220, easing: "cubic-bezier(.2,.9,.25,1)", fill: "forwards"});
  a.onfinish = then;
}
// Registered before the page keys, so G then A still goes to 알림 and never approves.
addEventListener("keydown", (e) => {
  const pg = tkPage();
  if (!pg || e.ctrlKey || e.metaKey || e.altKey || (e.repeat && !/^[jk]$/i.test(e.key))) return;
  if (e.target.closest?.("input,textarea,gk-select,[contenteditable]") || document.querySelector(".vw,.stk,#ov.on,#sheet.on") || Date.now() - gAt < 1200) return;
  const k = e.key.toLowerCase();
  keyBarHit(/^[1-7]$/.test(k) ? "1-7" : k);
  // 결과물: 1 to 7 are the lists of the strip, left to right.
  if (pg === "lib" && /^[1-7]$/.test(k)) { e.preventDefault(); return V().querySelectorAll(".lstat [data-lib]")[+k - 1]?.click(); }
  if (k === "j" || k === "k") { e.preventDefault(); const L = tkEls(); if (!L.length) return;
    const i = L.findIndex((el) => el.classList.contains("tkf"));
    tkAt = tkOn !== pg || i < 0 ? (k === "j" ? 0 : L.length - 1) : Math.max(0, Math.min(L.length - 1, i + (k === "j" ? 1 : -1)));
    tkOn = pg; tkId = ""; return triMark(true); }
  // A also reaches the card under the mouse (the 승인 tooltip says so).
  const el = (tkOn === pg && V().querySelector("[data-tk].tkf")) || (k === "a" && V().querySelector(".gw:hover")); if (!el) return;
  if (k === "escape") { tkOn = ""; return triMark(); }
  const key = el.dataset.item || el.querySelector(".gi[data-item]")?.dataset.item, x = key && D.items.find((y) => iid(y) === key), dv = el.querySelector("[data-dv]");
  if (k === "enter") {
    // Enter on a focused button is that button's press.
    if (document.activeElement?.closest?.("button,a,summary,[role=button]") && !el.contains(document.activeElement)) return;
    e.preventDefault(); if (dv) return nav("item/" + dv.dataset.dk);
    return (el.matches("[data-item],[data-talk],[data-go]") ? el : el.querySelector("[data-item],[data-talk],[data-go]"))?.click(); }
  if (k === "a" && x && x.status !== "approved") { e.preventDefault(); const gb = el.querySelector('[data-ga="ok"]');
    // A card says itself what can be done to it: one without 승인 (settled, finished) is left alone.
    return gb ? gb.click() : el.classList.contains("gw") ? undefined : tkFold(el, () => approveMany([x])); }
  if (k === "r" && x) { e.preventDefault(); return rejectSheet(itemIt(x)); }
  if (k === "h" && x && stMine(x)) { e.preventDefault(); return snoozeSheet(key); }
  if (k === "y" && dv) { e.preventDefault(); return tkFold(el, () => verdict(dv.dataset.dk, [dv.dataset.dv], true)); }
});

// ---------- 하나씩: 내 차례 as a stack of cards ----------
// Questions first, then fixes a department says it made, then results to look at. The card
// follows the finger 1:1 and keeps the flick's speed: right says yes (승인 · 맞아 · 보내기),
// left puts it off, up opens it. Short of the line it springs back from wherever it is, and
// a finger can catch it on the way. The same three as buttons and as → ← ↑.
let stkClose = null;
const stackQueue = () => [...myTurn().map((x) => ({t: "i", x}))];
const STK_T = LT(() => ({q: [tl("nextCard.6"), tl("palActs.2"), tl("STK_T.1")], d: [tl("itemView.10"), tl("palActs.2"), tl("STK_T.2")], i: [tl("STATUS_T.4"), tl("palActs.2"), tl("search.3")]}));
const stkCard = (c) => {
  if (c.t === "i") { const x = c.x, [k, col] = KIND[x.kind] || ["doc", "grey"];
    return `<div class="stkm c-${col}">${ic(k)}${x.thumb ? imgTag(x.thumb, {drag: false}) : ""}</div>
      <div class="stkb"><span class="tag pending">${tl("search.4")}</span><h2>${esc(x.title)}</h2><p>${esc(pname(gname(x)))} · ${esc(x.v)} · ${ago(x.at)}${x.asked ? tl("stkCard.1", {asked: x.asked}) : ""}</p></div>`; }
  if (c.t === "d") { const it = c.c.it;
    return `<div class="stkb mid"><span class="tag work">${tl("claimCard.2")}</span><div class="stkq">${esc(c.c.text)}</div>
      <div class="stkr">${thumb(it, "ico sm")}<span class="tx"><div class="t">${esc(it.title)}</div><div class="s">${tl("claimCard.1", {esc: esc(pname(it.dept || "")), esc2: esc(c.c.fixed_in || "")})}</div></span></div></div>`; }
  return "";
};
function stackOpen() {
  const Q = stackQueue(); if (!Q.length) return toast(tl("stackOpen.1"));
  stkClose?.();
  const from = document.activeElement, done = {ok: 0, later: 0};
  let at = 0, busy = false, x = 0, y = 0, stopX = null, stopY = null, card = null;
  const el = document.createElement("div"); el.className = "stk from"; el.tabIndex = -1;
  el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", tl("stackOpen.2"));
  el.innerHTML = `<div class="stk-top"><b class="num" id="stkn"></b><span class="sp"></span><button class="ib press" data-stkx aria-label="${tl("itemView.114")}">${ic("x")}</button></div><div class="stk-deck" id="stkd"></div><div class="stk-bar" id="stkbar"></div>`;
  document.body.appendChild(el); document.body.classList.add("stkon");
  const unhold = modalHold(el, from);
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("from")));
  const deck = el.querySelector("#stkd"), bar = el.querySelector("#stkbar"), num = el.querySelector("#stkn");
  const W = () => deck.clientWidth || innerWidth, H = () => deck.clientHeight || innerHeight;
  const halt = () => { stopX?.(); stopY?.(); stopX = stopY = null; };
  const paint = () => { if (!card) return;
    card.style.transform = `translate3d(${x}px,${y}px,0) rotate(${x / W() * 9}deg)`;
    const op = (s, v) => { const n = card.querySelector(s); if (n) n.style.opacity = Math.max(0, Math.min(1, v)); };
    op(".stks.r", x / (W() * .3)); op(".stks.l", -x / (W() * .3)); op(".stks.u", -y / (H() * .2) - Math.abs(x) / (W() * .3)); };
  const settle = (vx = 0, vy = 0) => { halt();
    if (RM()) { x = y = 0; return paint(); }
    stopX = springTo(() => x, (v) => { x = v; paint(); }, 0, vx, null, 0.42, 0.78);
    stopY = springTo(() => y, (v) => { y = v; paint(); }, 0, vy, null, 0.42, 0.78); };
  const close = () => {
    halt(); document.removeEventListener("keydown", onKey, true); stkClose = null; document.body.classList.remove("stkon");
    el.classList.add("from"); setTimeout(() => el.remove(), RM() ? 150 : 220);
    unhold();
    redrawTurn(); };
  const act = (dir, c, cd) => {
    if (dir === "u") { close(); return c.t === "q" ? nav("talk/c:" + c.g.r.key) : nav("item/" + iid(c.t === "d" ? c.c.it : c.x)); }
    if (dir === "r") { done.ok++;
      if (c.t === "i") approveMany([c.x]);
      else if (c.t === "d") verdict(iid(c.c.it), [c.c.id], true);
      else { const f = cd.querySelector("form.qsend"); f.dataset.go = "1"; f.requestSubmit(); } }
    else { done.later++; if (c.t === "i") snooze(iid(c.x), SNZ().find(([t]) => t.startsWith(tl("stackOpen.3")))[1]); }
    at++; draw(); };
  const go = (dir, vx = 0, vy = 0) => {
    if (busy || !card) return; const c = Q[at], cd = card;
    if (dir === "r" && c.t === "q" && !cd.querySelector("form.qsend input").value.trim()) {
      settle(vx, vy); cd.querySelector("form.qsend input").focus(); return toast(tl("stackOpen.4")); }
    busy = true; halt();
    let fired = false; const end = () => { if (fired) return; fired = true; halt(); busy = false; act(dir, c, cd); };
    if (RM()) { cd.style.transition = "opacity .15s"; cd.style.opacity = "0"; return setTimeout(end, 150); }
    const out = () => { if (Math.abs(x) > W() * 1.1 || -y > H() * 1.05) end(); };
    const tx = dir === "r" ? W() * 1.5 : dir === "l" ? -W() * 1.5 : x, ty = dir === "u" ? -H() * 1.4 : y;
    stopX = springTo(() => x, (v) => { x = v; paint(); out(); }, tx, vx || (dir === "r" ? 1800 : dir === "l" ? -1800 : 0), end, 0.34);
    stopY = springTo(() => y, (v) => { y = v; paint(); out(); }, ty, vy || (dir === "u" ? -1800 : 0), dir === "u" ? end : null, 0.34); };
  const wire = (cd) => {
    const f = cd.querySelector("form.qsend");
    cd.onpointerdown = (e) => {
      if (e.button || busy || e.target.closest("input,textarea,button,a")) return;
      halt(); cd.setPointerCapture(e.pointerId);
      const x0 = e.clientX - x, y0 = e.clientY - y, S = [[e.timeStamp, x, y]];
      const mv = (ev) => { x = ev.clientX - x0; const dy = ev.clientY - y0; y = dy > 0 ? rubber(dy, H()) : dy; paint();
        S.push([ev.timeStamp, x, y]); if (S.length > 8) S.shift(); };
      const up = (ev) => { cd.removeEventListener("pointermove", mv); cd.removeEventListener("pointerup", up); cd.removeEventListener("pointercancel", up);
        const a = S.find((s) => ev.timeStamp - s[0] < 100) || S[0], dt = Math.max(16, ev.timeStamp - a[0]) / 1000;
        const vx = (x - a[1]) / dt, vy = (y - a[2]) / dt, px = x + project(vx), py = y + project(vy);
        if (ev.type === "pointerup" && -py > H() * .22 && -py > Math.abs(px)) return go("u", vx, vy);
        if (ev.type === "pointerup" && Math.abs(px) > W() * .35) return go(px > 0 ? "r" : "l", vx, vy);
        settle(vx, vy); };
      cd.addEventListener("pointermove", mv); cd.addEventListener("pointerup", up); cd.addEventListener("pointercancel", up); };
  };
  const draw = () => {
    halt(); x = y = 0; const c = Q[at];
    num.textContent = c ? `${at + 1} / ${Q.length}` : "";
    if (!c) { card = null;
      deck.innerHTML = `<div class="stk-end"><span class="ico c-green">${ic("check")}</span><h2>${tl("stackOpen.8")}</h2><p>${[done.ok && tl("stackOpen.5", {ok: done.ok}), done.later && tl("stackOpen.6", {later: done.later})].filter(Boolean).join(" · ") || tl("stackOpen.7")}</p></div>`;
      bar.innerHTML = `<button class="btn xl fill press" data-stkx>${tl("itemView.114")}</button>`; bar.querySelector("button").focus(); return; }
    const T = STK_T[c.t], nx = Q[at + 1];
    deck.innerHTML = (nx ? `<div class="stkc back" aria-hidden="true"><div class="stki">${stkCard(nx)}</div></div>` : "")
      + `<div class="stkc cur enter"><div class="stki">${stkCard(c)}<span class="stks r">${T[0]}</span><span class="stks l">${T[1]}</span><span class="stks u">${T[2]}</span></div></div>`;
    card = deck.querySelector(".stkc.cur");
    requestAnimationFrame(() => requestAnimationFrame(() => card?.classList.remove("enter")));
    bar.innerHTML = `<button class="btn press" data-stka="l">${T[1]}<kbd>←</kbd></button><button class="btn press" data-stka="u">${T[2]}<kbd>↑</kbd></button><button class="btn fill press" data-stka="r">${T[0]}<kbd>→</kbd></button>`;
    wire(card); el.focus({preventScroll: true}); };
  const onKey = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "k") return close();
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const typing = e.target.closest?.("input,textarea");
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); return typing ? e.target.blur() : close(); }
    if (typing || e.isComposing) return;
    const d = {ArrowRight: "r", ArrowLeft: "l", ArrowUp: "u"}[e.key]; if (d && Q[at]) { e.preventDefault(); e.stopPropagation(); go(d); } };
  document.addEventListener("keydown", onKey, true);
  el.addEventListener("click", (e) => { const b = e.target.closest("[data-stkx],[data-stka],[data-sfill]"); if (!b) return;
    if (b.dataset.stkx !== undefined) return close();
    if (b.dataset.stka) return go(b.dataset.stka);
    const i = card?.querySelector("form.qsend input"); if (i) { i.value = b.dataset.sfill; i.focus(); } });
  stkClose = close;
  draw();
}

// ---------- events ----------
let tt0;
// `moment` (optional) names a web/motion.js moment ("approve", "copied", ...): its animated icon leads the text.
let ttEnd = null;                          // what the open action toast still owes when it goes (a deferred send)
const ttDone = (run) => { const e = document.getElementById("toast"), f = ttEnd; ttEnd = null;
  e.onpointerenter = e.onpointerleave = e.onfocusin = e.onfocusout = null; e.classList.remove("hold"); if (run && f) f(); };
// The 반영함 circle's check: one stroke, so it can be drawn on (v2.css .ckm).
const CKM = '<svg class="i ckm" viewBox="0 0 256 256" aria-hidden="true"><polyline points="40 144 96 200 224 72" pathLength="20"/></svg>';
// One-sentence toasts carry no trailing period; server errors arrive with one.
const onePeriod = (t) => typeof t === "string" && /[가-힣]\.$/.test(t) && !/[.?!]\s/.test(t.slice(0, -1)) ? t.slice(0, -1) : t;
function toast(t, ms = 2200, moment) { t = onePeriod(srvT(t)); const e = document.getElementById("toast"), mi = moment && window.Motion ? Motion.tip(moment) : "";
  ttDone(true); e.classList.remove("act", "tln"); e.classList.toggle("m-ico", !!mi);
  if (mi) e.innerHTML = `<span class="ti">${mi}</span><span class="tt ${Motion.textClass(moment)}">${esc(t)}</span>`; else e.textContent = t;
  void e.offsetWidth; e.style.setProperty("--tms", ms + "ms");     // the time line starts over with each toast
  e.classList.add("on", "tln"); clearTimeout(tt0); tt0 = setTimeout(() => e.classList.remove("on"), ms); if (mi) Motion.after(moment, e); }
// Copy text to the clipboard, falling back to a hidden textarea where the async API is not
// allowed (older browsers). Over Tailscale the page is https, so the async path is the norm.
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch (e) {}
  try { const a = document.createElement("textarea"); a.value = t; a.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(a); a.select(); const ok = document.execCommand("copy"); a.remove(); return ok; } catch (e) { return false; }
}
// A toast with one button (되돌리기), up long enough to reach for it. The time left runs out along
// its edge (CSS, --tms) and stops while the mouse or the keyboard is on it. `end` (optional) runs
// when the toast goes without 되돌리기 - timed out, closed, or replaced - so a send that waits for
// the undo window waits exactly as long as the button is there.
function toastAct(t, label, fn, ms = 5000, moment = "alert", end) { t = onePeriod(srvT(t));
  const e = document.getElementById("toast"); ttDone(true); e.classList.remove("m-ico", "act", "tln");
  e.innerHTML = `<span class="ti">${(window.Motion && Motion.tip(moment)) || ic("bell")}</span><span class="tt">${esc(t)}</span><button class="tact press">${esc(label)}</button><button class="tcx press" aria-label="${tl("ui.close")}">${ic("x")}</button>`;
  void e.offsetWidth; e.style.setProperty("--tms", ms + "ms"); e.classList.add("on", "act");
  ttEnd = end || null;
  let left = ms, t0 = 0;
  const close = (run) => { clearTimeout(tt0); e.classList.remove("on"); ttDone(run); };
  const go = () => { t0 = performance.now(); e.classList.remove("hold"); clearTimeout(tt0); tt0 = setTimeout(() => close(true), left); };
  const hold = () => { if (e.classList.contains("hold")) return; left = Math.max(0, left - (performance.now() - t0)); clearTimeout(tt0); e.classList.add("hold"); };
  e.querySelector(".tact").onclick = () => { close(false); fn(); };
  e.querySelector(".tcx").onclick = () => close(true);
  e.onpointerenter = (ev) => { if (ev.pointerType === "mouse") hold(); };
  e.onpointerleave = (ev) => { if (ev.pointerType === "mouse" && !e.querySelector(":focus-visible")) go(); };
  e.onfocusin = () => { if (e.querySelector(":focus-visible")) hold(); };
  e.onfocusout = () => { if (!e.matches(":hover")) go(); };
  go();
}
document.addEventListener("click", (e) => {
  // The floating window's own controls are float.js's: its data-pin is a conversation to float and
  // its data-back closes the chat, not a project to star or a screen to leave.
  if (FLOAT && e.target.closest("#fl")) return;
  const a = e.target.closest("[data-libfil],[data-libo],[data-turnpick],[data-later],[data-unsnz],[data-lostdrop],[data-dvall],[data-dk],[data-sortsheet],[data-libk],[data-libz],[data-fav],[data-pin],[data-arch],[data-archx],[data-railmin],[data-sync],[data-view],[data-go],[data-item],[data-dept],[data-decide],[data-cmt],[data-back],[data-fwd],[data-lib],[data-close],[data-sclose],[data-pref],[data-stack],[data-catch],[data-catchok],[data-ibt]");
  if (!a) return;
  if (a.dataset.later) { e.stopPropagation(); return snooze(a.dataset.later, SNZ_OPEN, a.dataset.mark); }
  if (a.dataset.unsnz) return snooze(a.dataset.unsnz, null);
  if (a.dataset.dk) { a.disabled = true; return verdict(a.dataset.dk, [a.dataset.dv], !!a.dataset.ok); }
  // 말이 안 닿은 프로젝트: nothing took these lines, and until now nothing could clear them either.
  if (a.dataset.lostdrop) { a.disabled = true;
    return post("/api/attention/drop-lost", {dept: a.dataset.lostdrop, session: a.dataset.lostses || ""})
      .then(() => get("/api/attention?fresh=1")).then((d) => { att = d; attAt = Date.now(); toast(tl("att.lost.dropped")); render(); })
      .catch((e) => { a.disabled = false; toast(e.message); }); }
  if (a.dataset.dvall) { a.disabled = true; const k = a.dataset.dvall; return verdict(k, claimedDirs().filter((c) => iid(c.it) === k).map((c) => c.id), true); }
  if (a.dataset.sortsheet) return sortSheet(a.dataset.sortsheet);
  if (a.dataset.libfil !== undefined) return libFilSheet();
  if (a.dataset.libo) { libO(a.dataset.libo); return libDraw(); }
  if (a.dataset.libk !== undefined) { libK = a.dataset.libk; libSel = null; return libDraw(); }
  if (a.dataset.libz) { libZ(a.dataset.libz); return libDraw(); }
  if (a.dataset.fav) { e.preventDefault(); e.stopPropagation(); return toggleFav(a.dataset.fav); }
  if (a.dataset.pin) { e.stopPropagation(); return togglePin(a.dataset.pin); }
  if (a.dataset.arch) { e.preventDefault(); e.stopPropagation(); return toggleArchive(a.dataset.arch); }
  if (a.dataset.archx !== undefined) { e.stopPropagation(); return toggleShelf(); }
  if (a.dataset.railmin !== undefined) return toggleRail();
  if (a.dataset.stack !== undefined) return stackOpen();
  if (a.dataset.turnpick !== undefined) return turnSheet();
  if (a.dataset.catch !== undefined) return catchOpen();
  if (a.dataset.catchok !== undefined) return catchDone();
  if (a.dataset.ibt) { history.replaceState(null, "", "#inbox" + (a.dataset.ibt === "do" ? "" : "/" + a.dataset.ibt)); return render(); }
  if (a.dataset.sclose !== undefined) return closeSheet();
  if (a.dataset.view !== undefined) return viewer(openItem?.pics || [], +a.dataset.view);
  if (a.dataset.close !== undefined) return search(false, true), history.length > 1 && location.hash === "#search" ? history.back() : null;
  if (a.dataset.pref) { const v = !pref(a.dataset.pref); pref(a.dataset.pref, v); a.classList.toggle("on", v); a.setAttribute("aria-checked", v); if (a.dataset.pref === "redact") Redact.set(v); document.body.classList.toggle("calm", pref("calm")); document.body.classList.toggle("steps", pref("steps")); return; }
  if (a.dataset.back !== undefined) return back();
  if (a.dataset.fwd !== undefined) return history.forward();
  if (a.dataset.decide) return decide(a.dataset.decide);
  if (a.hasAttribute("data-cmt")) return openCmt();
  if (a.dataset.item) return nav("item/" + a.dataset.item);
  if (a.dataset.dept) return nav("dept/" + a.dataset.dept);
  if (a.dataset.lib) { libF = a.dataset.lib; libFAuto = false; libSel = null; try { localStorage.setItem("v2-libf", libF); } catch {} return cur === "lib" && !detail ? libDraw() : nav("lib"); }
  if (a.dataset.sync !== undefined) return syncNow(a);
  if (a.dataset.go) { if (a.dataset.go === "search") return search(true); nav(a.dataset.go); }
});
// Keys as in Linear and GitHub: G then a letter goes to a page, / searches, ? lists them all.
// M, A and T went to 내 차례, 알림 and 할 일; they now open 받은함's matching section.
const GO_KEYS = {h:"home", i:"inbox", m:"inbox", a:"inbox/news", t:"inbox/log", l:"lib", c:"sessions", p:"project", d:"dept", e:"depts", o:"routines", r:"retro", u:"usage", s:"settings"};
// A key whose screen this install does not have (an extension turned off) is left out of help.
const goName = (v) => GO_T[v] || M(v)?.n || extTabs().find((t) => t.id === v)?.label || "";
const GO_T = LT(() => ({inbox: tl("TABS.1"), "inbox/news": tl("bellSearch.1"), "inbox/log": tl("itemView.20"), sessions: tl("menu.chat") + " · " + tl("menu.sessions"), dept: tl("MANUAL.2", {u: unitWord()})}));
let gAt = 0;
function keyHelp() {
  const row = (k, t) => `<div class="kh"><span>${t}</span><span class="khk keys">${k.split(" ").map((x) => `<kbd>${x}</kbd>`).join("")}</span></div>`;
  sheet(`<h2 style="margin:0 0 12px">${tl("keysSheet.20")}</h2>
    ${row("Ctrl K", tl("MENUS.5"))}${row("/", tl("MENUS.5"))}${row("[", tl("keyHelp.2"))}
    ${Object.entries(GO_KEYS).filter(([k, v]) => k !== "m" && goName(v)).map(([k, v]) => row("G " + k.toUpperCase(), tl("keyHelp.1", {name: goName(v)}))).join("")}
    ${row("G M", tl("keyHelp.6"))}${row("N", tl("gq.next.key"))}${row("Ctrl Shift J", tl("gq.next.key"))}${row("?", tl("keyHelp.help"))}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.rooms")}</div>
    ${row("Ctrl J", tl("keyHelp.next"))}${row("Alt J", tl("keyHelp.next"))}${row("Ctrl 1-3", tl("keyHelp.pane"))}${row("Alt W", tl("keyHelp.paneX"))}${row("Alt T", tl("pj.turns.menu"))}${row("Ctrl /", tl("pj.snip.menu"))}${row("Alt ↑", tl("pj.mine.menu"))}${IN_APP ? row("Ctrl F", tl("pj.find.menu")) : ""}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.18")}</div>
    ${row("J K", tl("keyHelp.7"))}${row("Enter", tl("search.3"))}${row("A", tl("STATUS_T.4"))}${row("R", tl("cmt.1"))}${row("H", tl("palActs.2"))}${row("1-7", tl("keybar.lists"))}${row("Y", tl("keyHelp.8"))}${row("Ctrl K", tl("keyHelp.9"))}
    <div class="sub" style="padding:14px 0 6px">${tl("keyHelp.19")}</div>
    ${row("← →", tl("keyHelp.10"))}${row(", .", tl("keyHelp.11"))}${row("↑ ↓", tl("keysSheet.3"))}${row("0-9", tl("keyHelp.12"))}${row("M", tl("keyHelp.13"))}${row("Space", tl("keyHelp.14"))}${row("A", tl("STATUS_T.4"))}${row("R", tl("cmt.1"))}${row("N", tl("keyHelp.15"))}${row("Shift+N", tl("keybar.prev"))}${row("J K L", tl("keyHelp.16"))}${row("F", tl("keybar.focus"))}${row("T", tl("keyHelp.17"))}${row("H", tl("snoozeSheet.1"))}${row("I O X", tl("keyHelp.20"))}
    <button class="lnk press" id="khitem" style="margin-top:14px">${tl("keybar.allitem")}</button>`, (el) => { el.querySelector("#khitem").onclick = () => { closeSheet(); setTimeout(keysSheet, 280); }; });
}
addEventListener("keydown", (e) => { if (FLOAT) return;
  if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); search(true); }
  // Ctrl J (Alt J where the browser keeps Ctrl J): the next conversation with unread lines.
  if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.key === "j" || e.key === "J")) { e.preventDefault(); return nextUnread(); }
  const typ = e.target.matches?.("input,textarea,gk-select,[contenteditable]");
  const free = !e.ctrlKey && !e.metaKey && !e.altKey && !typ && !document.querySelector(".vw,.stk");
  if (free && !(detail?.[0] === "item")) {
    const k = e.key.toLowerCase();
    if (k === "g") { gAt = Date.now(); return; }
    if (Date.now() - gAt < 1200 && GO_KEYS[k]) { gAt = 0; e.preventDefault(); closeSheet(); return nav(GO_KEYS[k]); }
    if (e.key === "/") { e.preventDefault(); return search(true); }
    // Where the list has its own key bar, ? is that bar's switch (its 전체 보기 opens this sheet).
    if (e.key === "?") { e.preventDefault(); return document.getElementById("kbar") ? undefined : keyHelp(); }
  }
  if (e.key === "[" && !e.ctrlKey && !e.metaKey && !e.altKey && wide() && !e.target.matches?.("input,textarea,gk-select,[contenteditable]") && !window.LOOP_LAYER_UP?.()) toggleRail();
  if (e.key === "{" && !e.ctrlKey && !e.metaKey && !e.altKey && wide() && !e.target.matches?.("input,textarea,gk-select,[contenteditable]") && !window.LOOP_LAYER_UP?.()) railHide();
  if (e.key === "Escape") {
    // Picking results is left with Esc, as the chat list's picking is (an open sheet shuts first).
    if (!typ && !document.querySelector("#sheet.on,#ov.on,.pj-pop") && !window.LOOP_LAYER_UP?.()) {
      if (libSel && cur === "lib" && !detail) { libSel = null; libNow(); }
      else if (deptSel && detail?.[0] === "dept") { deptSel = null; redrawDept(); } }
    // Settings closes like a panel: with nothing open over it and no field in use, Esc goes back to the screen before it.
    const leave = cur === "settings" && !detail && !typ && !e.defaultPrevented && !window.LOOP_LAYER_UP?.() && !document.querySelector(".pj-pop,#updpop");
    search(false, true); closeSheet();
    if (leave) setClose();
  } });

// Lists refresh in the background; a screen being typed in or read in detail is left alone.
// The 30s round. The three list screens are drawn from D alone, so a round that brought nothing
// new leaves them standing (it used to rebuild the whole page every time); they are still redrawn
// every two minutes so "3분 전" keeps moving. Other screens fetch their own data in their draw.
let roundSig = "", roundAt = 0;
setInterval(async () => {
  if (document.hidden || FLOAT) return;
  await load();
  const sig = JSON.stringify([D.board, D.items, D.pins, D.favs, D.hidden, D.shelved]);
  const same = sig === roundSig && ["home", "inbox", "lib"].includes(cur) && Date.now() - roundAt < 120000;
  roundSig = sig;
  const typing = document.activeElement?.matches?.("input,textarea,gk-select");
  if (!same && !typing && !document.getElementById("sheet").classList.contains("on")) { redraw(); roundAt = Date.now(); }
  drawChrome();
}, 30000);

document.body.classList.toggle("calm", pref("calm"));
// The chat shows what a session says; the lines for each tool it ran in between are a setting, off until asked for.
document.body.classList.toggle("steps", pref("steps"));
// The first look at the app in a tab: the logo, its ring turning while the first data comes in.
// It stays at least 0.8s so it never just flashes, leaves at 6s whatever happens, and a tap
// sends it off at once. A reload in the same tab goes straight to the page (v2.html).
function splashOut(now) {
  const s = document.getElementById("splash"); if (!s || s.classList.contains("out")) return;
  try { sessionStorage.setItem("v2-in", "1"); } catch {}
  const go = () => { if (s.classList.contains("out")) return; s.classList.add("out"); setTimeout(() => s.remove(), 480); };
  if (now) go(); else if (!s.dataset.out) { s.dataset.out = "1"; setTimeout(go, Math.max(0, 800 - performance.now())); }
}
document.getElementById("splash")?.addEventListener("pointerdown", () => splashOut(true));
document.getElementById("splash")?.setAttribute("aria-label", tl("load.label"));
setTimeout(() => splashOut(true), 6000);
// Open on what was last seen, at once, then bring it up to date: over the phone's link the
// first load takes a second or two, and a blank screen for that long reads as broken.
// The refresh button's "n분 전 동기화" says honestly how old the shown data is meanwhile.
const bootSeen = lsGet("v2-seen-at");
(async () => {
  if (FLOAT) { document.getElementById("splash")?.remove(); return; }
  let shown = false;
  try { const c = JSON.parse(localStorage.getItem("v2-cache") || "null"); if (c?.at) { D = {...D, ...c}; render(); shown = true; } } catch {}
  // The logo that greets a first visit leaves once there is something to show.
  if (shown) splashOut();
  // No copy yet (cleared storage, a new browser): draw the frame now, so the tabs and the
  // "불러오는 중" line stand there instead of a white page until the data comes.
  else try { render(); } catch {}
  await load();
  // First visit: the title row takes its 의견 남기기 slot before the logo lifts, so the centred pill does not jump.
  if (!shown && fbUrl()) try { render(); } catch {}
  splashOut();
  if (attP) await Promise.race([attP, new Promise((r) => setTimeout(r, 500))]);
  attBooting = false;
  const typing = document.activeElement?.matches?.("input,textarea,gk-select");
  // A reader who started scrolling while it loaded stays where they were.
  if (!typing) { const y = scrollY; render(); scrollTo(0, y); }
  // Away long enough (by this browser or the server's last look): what happened meanwhile.
  briefCheck(true).finally(() => { if (!brief) awayCheck(later(bootSeen, D.seen_at)); }); hereNow(true); drawUpdate(false);
  setInterval(() => { if (!document.hidden) hereNow(); }, 60000);
})();
// A mobile browser can drop its compositor layer on a short lock/unlock or app-switch even
// when it isn't away long enough for the AWAY_MS data refresh below - the page is fine
// underneath but the screen paints solid black until something forces a reflow. A page-level
// refresh does nothing (the break is below the DOM), so nudge layout directly: toggling display
// off and back is the cheap, reliable way to make a browser repaint a stuck compositor layer.
// web/repaint.js keeps the display restore in a finally and rescues a body left on none.
function nudgeRepaint() { if (window.LOOP_REPAINT) window.LOOP_REPAINT.nudgeRepaint(document); }
// Back to the tab after a while: the same check, against the look before this one.
document.addEventListener("visibilitychange", async () => {
  if (FLOAT) return;
  // Leaving is when the icon is looked at: its number is set once more from what is known now.
  if (document.hidden) { try { drawChrome(); } catch {} return hereNow(true); }
  nudgeRepaint(); briefCheck();
  const last = lsGet("v2-seen-at"); if (!last || Date.now() - new Date(last) < AWAY_MS) return hereNow();
  await load(); drawChrome(); awayCheck(later(last, D.seen_at)); hereNow(true);
});
// iOS Safari restoring the page from its back-forward cache (swipe back, reopen from the app
// switcher) can skip visibilitychange entirely and hand back a page frozen mid-paint - the
// dedicated signal for that is pageshow with event.persisted set.
window.addEventListener("pageshow", (e) => { if (e.persisted) nudgeRepaint(); });
