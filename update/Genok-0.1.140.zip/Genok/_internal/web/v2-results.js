// Genok web UI, cut from v2.js: 결과물: the board, the library, the actions on a result card.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- 결과물 ----------
// 결과물 › 보드: every project's results on one board (web/boardview.js), each opened in place.
document.head.appendChild(Object.assign(document.createElement("link"), {rel: "stylesheet", href: "/s-board.css"}));
SCREENS.board = function () {
  const its = D.items.filter((x) => !libHide.has(iid(x)));
  if (softN > 0 && its.length && window.BoardView?.same?.(document.getElementById("bdhost"), "*", its)) return {};
  // One title, one sub line, then the same three-way switch the storage screen draws.
  V().innerHTML = `<header class="g-head bd-head"><div class="g-ht"><h1>${esc(tl("board.board"))}</h1><p class="g-sub">${esc(tl("board.sub", {n: its.length}))}</p></div></header>${window.resTabs ? resTabs("board") : ""}${its.length ? `<div class="bdhost" id="bdhost"></div>` : `<div class="card plan none">${stNone("all")}</div>`}`;
  if (its.length && window.BoardView) BoardView.draw(document.getElementById("bdhost"), "*", its);
  return {};
};
// 결과물 › 검토할 것: the results waiting on the reader as plain rows (the Row primitive). One 상태
// chip picks another list (a session's turn, stopped, over); 판정 stays the primary action. The
// whole history, approved work included, is the other tab (web/record.js).
// The list it opens on is the one last chosen ("genok-res-st"); before any choice, the reader's own.
const RES_ST = ["mine", ...ST_MAIN.filter((k) => !ST_MINE.includes(k)), "all"];
let k3f = ((s) => RES_ST.includes(s) ? s : "mine")(lsGet("genok-res-st"));
let jdRows = [];
const resStName = (k) => k === "mine" ? tl("lib.tab.review") : k === "all" ? tl("all.tab") : ST_TABN[k];
function libKit() {
  const base = D.items.filter((x) => !libHide.has(iid(x))).sort(byAt);
  const mine = base.filter(stMine), open = base.filter((x) => stOf(x) !== "finished");
  const rows = k3f === "mine" ? mine : k3f === "all" ? open : base.filter((x) => stOf(x) === k3f);
  // A list that waits on the reader, two or more: a held row begins picking several to approve
  // (web/longpress.js); a tap then picks, the bar below approves.
  const pick = (k3f === "mine" || ST_MINE.includes(k3f)) && rows.length > 1;
  if (!pick) libSel = null;
  if (!libSel) selOff("lib");
  const hit = (x) => libSel ? `" data-sel="${esc(iid(x))}" aria-pressed="${libSel.has(iid(x))}` : `" data-item="${esc(iid(x))}`;
  const badge = (x) => libSel ? (libSel.has(iid(x)) ? `<span class="g-badge me">${ic("check")}</span>` : "") : `<span class="g-badge${stMine(x) ? " me" : ""}">${esc(stName(x))}</span>`;
  const row = (x) => `<li class="rv-rw"><button type="button" class="g-row press${libSel?.has(iid(x)) ? " on" : ""}${hit(x)}"${stTip(x)}>
      <span class="g-lead">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}</span>
      <span class="g-body"><span class="g-l1">${esc(x.title)}</span><span class="g-l2">${esc(pname(gname(x)))} · ${esc(vShort(x.v))} · ${ago(x.at)}</span></span>
      <span class="g-end">${badge(x)}</span></button></li>`;
  const body = rows.length ? `<ul class="rv-ul">${rows.map(row).join("")}</ul>` : `<div class="k3none">${stNone(ST_NONE[k3f] ? k3f : "all")}</div>`;
  const chip = `<label class="rv-st"><gk-select class="rv-sel" id="rvst" aria-label="${esc(tl("lib.state"))}">${RES_ST.map((k) => `<option value="${k}"${k === k3f ? " selected" : ""}>${esc(resStName(k))}</option>`).join("")}</gk-select></label>`;
  const judge = rows.length ? `<button type="button" class="g-btn primary press" data-judge title="${esc(tl("jd.open_t"))}">${esc(tl("jd.open"))}</button>` : "";
  V().innerHTML = `<div class="rv k3lib${pick ? " pickable" : ""}${libSel ? " picking" : ""}">${resHead("review", resSub(mine.length))}
    <div class="rv-tools">${chip}${judge}</div>${body}</div>${libSel ? `<div class="ctapad"></div>` : ""}`;
  jdRows = rows;     // 판정 모드 (web/judge.js) opens on this list
  V().querySelector("#rvst").onchange = (e) => { k3f = e.target.value; lsSet("genok-res-st", k3f); libSel = null; libKit(); };
  // A tap picks in place (no redraw, so nothing under the finger moves); the last one let go of
  // ends a picking that a long press began.
  const bar = () => selBar(libSel ? libSel.size : null, () => { libSel = null; libKit(); }, () => approveMany(rows.filter((x) => libSel.has(iid(x)))));
  V().querySelectorAll(".k3lib [data-sel]").forEach((b) => { b.onclick = () => { const k = b.dataset.sel; libSel.has(k) ? libSel.delete(k) : libSel.add(k);
    if (!libSel.size && selHold) { libSel = null; return libKit(); }
    b.classList.toggle("on", libSel.has(k)); b.setAttribute("aria-pressed", libSel.has(k));
    b.querySelector(".g-end").innerHTML = badge(D.items.find((x) => iid(x) === k)); bar(); }; });
  bar();
}
SCREENS.lib = function () {
  if (resTab() === "record") return softN > 0 && V().querySelector(".rv-rec") ? {} : recDraw();
  if (LAB3) return libKit();
  const depts = [...new Set(D.items.map((x) => gname(x)))].sort((a, b) => a.localeCompare(b, "ko"));
  const sel = (id, label, opts, cur) => `<gk-select id="${id}" class="lsel" aria-label="${label}">${opts.map(([k, n]) => `<option value="${esc(k)}" ${k === cur ? "selected" : ""}>${esc(n)}</option>`).join("")}</gk-select>`;
  // One toolbar row: search takes the slack, the rest are equal 36px controls on one edge.
  V().innerHTML = `${window.resTabs ? resTabs("lib") : ""}<div class="ltool"><div class="field lq">${ic("search")}<input id="libq" type="search" enterkeyhint="search" placeholder="${tl("lib.2")}" autocomplete="off" value="${esc(libQ)}"></div>
    <button class="lfbtn press" data-libfil aria-haspopup="dialog">${ic("sliders")}<span>${tl("lib.fil")}</span><em class="num" hidden></em></button>
    ${sel("libd", unitWord(), [["", tl("lib.1", {u: unitWord()})], ...depts.map((d) => [d, pname(d)])].concat(libD && !depts.includes(libD) ? [[libD, libD]] : []), libD)}
    <gk-select id="libk" class="lsel" aria-label="${tl("libDraw.24")}"></gk-select>
    <div class="seg lord" role="group" aria-label="${tl("libDraw.6")}">${[["new", tl("LIB_ORD.1")], ["dept", tl("LIB_ORD.3", {u: unitWord()})]].map(([k, n]) => `<button class="press" data-libo="${k}">${esc(n)}</button>`).join("")}</div>
    <div class="seg zoom" role="group" aria-label="${tl("libDraw.9")}">${[["s",tl("libDraw.3")],["m",tl("libDraw.4")],["l",tl("libDraw.5")]].map(([k, n]) => `<button class="press" data-libz="${k}">${n}</button>`).join("")}</div>
    <button class="zcyc press" data-libz="" aria-label="${tl("libDraw.7")}">${ic("grid")}</button></div>
    <div id="libg"></div><div id="libs"></div>${listKeyBar()}`;
  const q = document.getElementById("libq"), dd = document.getElementById("libd");
  let t0;
  q.oninput = () => { libQ = q.value; libSel = null; clearTimeout(t0); t0 = setTimeout(libDraw, 120); };
  dd.onchange = () => { libD = dd.value; libSel = null; libDraw(); };
  document.getElementById("libk").onchange = (e) => { libK = e.target.value; libSel = null; libDraw(); };
  libDraw();
};
// Phone: project, kind, order, card size and the saved views sit behind one 필터 button, so the
// first card starts right under the search. The sheet sets the same state the toolbar does.
const libFilN = () => (libD ? 1 : 0) + (libK ? 1 : 0) || (document.querySelector("#vwbar .vwc-w.on") ? 1 : 0);
function libFilSheet() {
  const chip = (attr, k, n, on) => `<button class="chip press${on ? " on" : ""}" ${attr}="${esc(k)}" aria-pressed="${on}">${n}</button>`;
  const seg = (attr, label, opts, cur) => `<div class="seg lfs" role="group" aria-label="${label}">${opts.map(([k, n]) => `<button class="press${k === cur ? " on" : ""}" ${attr}="${k}" aria-pressed="${k === cur}">${esc(n)}</button>`).join("")}</div>`;
  const body = () => {
    const depts = [...new Set(D.items.map((x) => gname(x)))].sort((a, b) => a.localeCompare(b, "ko"));
    if (libD && !depts.includes(libD)) depts.push(libD);
    const kinds = LIB_KINDS.filter(([k]) => !k || D.items.some((x) => (!libD || gname(x) === libD) && kindOf(x) === k));
    const views = [...document.querySelectorAll("#vwbar .vwc-w")], save = document.querySelector("#vwbar [data-vsave]"), manage = document.querySelector("#vwbar [data-viewmanage]");
    return (views.length ? `<div class="lbl">${tl("views.title")}</div><div class="lfc">${views.map((w) => chip("data-lfv", w.dataset.vw, w.querySelector(".vwc").innerHTML, w.classList.contains("on"))).join("")}</div>` : "")
      + `<div class="lbl">${esc(unitWord())}</div><div class="lfc">${[["", tl("lib.1", {u: unitWord()})], ...depts.map((d) => [d, pname(d)])].map(([k, n]) => chip("data-lfd", k, deptMark(k) + esc(n), k === libD)).join("")}</div>
      <div class="lbl">${tl("libDraw.24")}</div><div class="lfc">${kinds.map(([k, n, i]) => chip("data-lfk", k, (i ? ic(i) : "") + esc(n), k === libK)).join("")}</div>
      <div class="lbl">${tl("lib.fil.sort")}</div>${seg("data-lfo", tl("libDraw.6"), [["new", tl("LIB_ORD.1")], ["dept", tl("LIB_ORD.3", {u: unitWord()})]], libOrd())}
      <div class="lbl">${tl("libDraw.9")}</div>${seg("data-lfz", tl("libDraw.9"), [["s", tl("libDraw.3")], ["m", tl("libDraw.4")], ["l", tl("libDraw.5")]], libZ())}
      ${save || manage ? `<div class="lfm">${save ? `<button class="lnk press" data-lfsave>${ic("plus")}${tl("views.savethis")}</button>` : ""}${manage ? `<button class="lnk press" data-lfmanage>${tl("views.manage")}</button>` : ""}</div>` : ""}
      <div class="lfa"><button class="btn xl press" data-lfreset ${libD || libK ? "" : "disabled"}>${tl("lib.fil.reset")}</button><button class="btn xl fill press" data-sclose>${tl("lib.fil.done")}</button></div>`;
  };
  sheet(`<h3>${tl("lib.fil")}</h3><div class="lfb">${body()}</div>`, (box) => {
    const inner = box.querySelector(".lfb");
    const redo = () => { const dd = document.getElementById("libd"); if (dd) dd.value = libD; libSel = null; libDraw(); inner.innerHTML = body(); };
    inner.onclick = (e) => {
      const a = e.target.closest("[data-lfv],[data-lfd],[data-lfk],[data-lfo],[data-lfz],[data-lfreset],[data-lfsave],[data-lfmanage]"); if (!a) return;
      const d = a.dataset;
      // Saved views and their name form belong to the bar on the page: press its own buttons.
      if (d.lfv !== undefined) { document.querySelector(`#vwbar [data-view="${CSS.escape(d.lfv)}"]`)?.click(); return setTimeout(() => { if (inner.isConnected) inner.innerHTML = body(); }); }
      if (d.lfsave !== undefined) { closeSheet(); return setTimeout(() => document.querySelector("#vwbar [data-vsave]")?.click(), 320); }
      if (d.lfmanage !== undefined) return document.querySelector("#vwbar [data-viewmanage]")?.click();
      if (d.lfd !== undefined) { libD = d.lfd; if (libK && !D.items.some((x) => (!libD || gname(x) === libD) && kindOf(x) === libK)) libK = ""; }
      else if (d.lfk !== undefined) libK = d.lfk;
      else if (d.lfo) libO(d.lfo);
      else if (d.lfz) libZ(d.lfz);
      else if (d.lfreset !== undefined) { libD = ""; libK = ""; }
      redo();
    };
  });
}
// Kinds as ThreeUI sorts its catalogue: chips over the grid, only the ones there are.
const LIB_KINDS = LT(() => ([["", tl("LIB_KINDS.1"), ""], ["video", tl("LIB_KINDS.2"), "video"], ["image", tl("LIB_KINDS.3"), "image"], ["html", tl("LIB_KINDS.4"), "code"], ["doc", tl("LIB_KINDS.5"), "doc"]]));
const kindOf = (x) => x.kind === "text" || x.kind === "link" ? "doc" : x.kind;
const libZ = (v) => { try { if (v === undefined) return localStorage.getItem("v2-libz") || "m"; localStorage.setItem("v2-libz", v); } catch { return "m"; } };
// Order of the list: newest first, oldest first, or one department after another. Left
// unset, 확인 필요 goes by department and the rest newest first, as before.
// Piles can also go by session (병렬 작업: one per worktree) or by role (메인 + 서브에이전트: the
// main session's own pushes, then one pile per subagent/teammate role).
const LIB_ORD = LT(() => ([["new", tl("LIB_ORD.1")], ["old", tl("LIB_ORD.2")], ["dept", tl("LIB_ORD.3", {u: unitWord()})],
  ["session", tl("LIB_ORD.4")], ["role", tl("LIB_ORD.5")], ["due", tl("LIB_ORD.6")]]));
// Where 결과물 opens: the reader's own pick, else the 사용 방식 결과물 묶기 knob.
const LIB_KNOB = {unit: "dept", session: "session", role: "role", date: "new"};
const libOrd = () => { const o = libO(); return LIB_ORD.some(([k]) => k === o) ? o : LIB_KNOB[knob("lib_group")] || "dept"; };
const PILED = ["dept", "session", "role"];
const libGroupOf = (x, ord) => ord === "role" ? (x.role || tl("mode.main")) : ord === "session" ? (x.session || gname(x)) : gname(x);
// Library groups the reader folded away, by project name (kept across visits).
const libFold = (() => { try { return new Set(JSON.parse(localStorage.getItem("v2-libfold") || "[]")); } catch { return new Set(); } })();
const saveFold = () => { try { localStorage.setItem("v2-libfold", JSON.stringify([...libFold])); } catch {} };
// A project's emoji on library rows, so piles tell apart at a glance.
const deptMark = (name) => { const r = D.items.find((x) => gname(x) === name && x.icon); return r ? `<span class="dmk" aria-hidden="true">${identFace(name, r.icon)}</span>` : ""; };
const libO = (v) => { try { if (v === undefined) return localStorage.getItem("v2-libo") || ""; localStorage.setItem("v2-libo", v); } catch { return ""; } };
const libHide = new Set();                 // approved from the list, still inside the 5 seconds to take it back
function libHash() {
  if (cur !== "lib" || detail) return;
  const u = new URLSearchParams(); if (libF && !libFAuto) u.set("f", libF); if (libD) u.set("d", libD); if (libQ.trim()) u.set("q", libQ.trim()); if (libK) u.set("k", libK);
  const s = u.toString(); if (location.hash.slice(1) !== "lib" + (s ? "?" + s : "")) history.replaceState(null, "", "#lib" + (s ? "?" + s : ""));
}
// 끝난 작업, one project at a time: a line that sums the project up, then its results as a
// plain list, newest first. Each row opens the result; its 기록 button unfolds that result's
// own run in place (every version and what was said on it, oldest first), read once on demand.
const finOpen = new Set(), finHist = new Map();
const finDay = (t) => t ? new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "short", day: "numeric"}) : "";
function finLines(d) {
  const L = [];
  (d.versions || []).forEach((v) => L.push({at: v.at || "", ic: "up", t: tl("fin.h.ver", {v: vShort(v.v)})}));
  (d.log || []).forEach((e) => {
    if ((e.kind === "comment" || e.kind === "message") && e.text) L.push({at: e.at || "", ic: "chat", t: String(e.text).replace(/\s+/g, " ").slice(0, 120)});
    else if (e.kind === "status" && STATUS_T[e.status]) L.push({at: e.at || "", ic: e.status === "approved" ? "check" : "bendBack", t: STATUS_T[e.status]});
  });
  if (d.finished) L.push({at: d.finished, ic: "flag", t: tl("fin.h.end")});
  return L.sort((a, b) => a.at.localeCompare(b.at));
}
const finHistHtml = (k) => { const L = finHist.get(k);
  return !L ? `<div class="finh">${loadingHtml("", {size: 20})}</div>` : `<ol class="finh">${L.length ? L.map((l) => `<li>${ic(l.ic, "i")}<span class="ft">${esc(l.t)}</span><time>${finDay(l.at)}</time></li>`).join("") : `<li><span class="ft">${tl("fin.h.none")}</span></li>`}</ol>`; };
function finGroup(d, xs) {
  const vs = xs.reduce((a, x) => a + (x.count || 0), 0), cs = xs.reduce((a, x) => a + (x.comments || 0), 0);
  return `<div class="finl"${libFold.has(d) ? " hidden" : ""}><p class="fins">${tl("fin.sum", {v: vs, c: cs})}</p>${xs.map((x) => { const k = iid(x), on = finOpen.has(k);
    return `<div class="finr"><button class="finb press" data-item="${esc(k)}"><span class="fth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}</span><span class="ftx"><span class="t">${esc(x.title)}</span><span class="s">${stK(x) === "approved" ? `<i class="fok">${tl("STATUS_T.4")}</i>` : ""}${vShort(x.v)} · ${finDay(x.finished || x.at)}</span></span></button><button class="finx press" data-finx="${esc(k)}" aria-expanded="${on}">${on ? tl("fin.hist.off") : tl("fin.hist")}${ic("chev", "i")}</button>${on ? finHistHtml(k) : ""}</div>`; }).join("")}</div>`;
}
function finWire(g) {
  g.querySelectorAll("[data-finx]").forEach((b) => b.onclick = async () => { const k = b.dataset.finx;
    if (finOpen.has(k)) { finOpen.delete(k); return libDraw(); }
    finOpen.add(k); libDraw();
    if (finHist.has(k)) return;
    const [p0, ...r] = k.split("/"), d = await itemDetail(p0, r.join("/"));
    finHist.set(k, d ? finLines(d) : []); if (finOpen.has(k)) libDraw(); });
}
let libAsk = 0;
// The bar at the foot of the screen while results are picked: 취소, and 승인 for the picked (`n`
// null takes it away). It hangs off the body: inside the moving page a fixed bar is fixed to the
// page, not the screen.
function selBar(n, off, ok) {
  let sb = document.getElementById("selbar");
  if (n == null) { if (sb) sb.remove(); return; }
  if (!sb) { sb = document.createElement("div"); sb.id = "selbar"; sb.className = "selbar"; document.body.appendChild(sb); }
  sb.innerHTML = `<div class="in"><button class="btn xl press" id="seloff">${tl("libDraw.22")}</button><button class="btn xl fill press" id="selok" ${n ? "" : "disabled"}>${n ? tl("libDraw.20", {size: n}) : tl("libDraw.21")}</button></div>`;
  sb.querySelector("#seloff").onclick = off; sb.querySelector("#selok").onclick = ok;
}
// A picking begun with a long press is a step on the history: the back gesture leaves it
// (web/longpress.js). selHold drops the step again when the picking ends some other way.
let selHold = null;
function selOn(k, out) { selOff(); const back = LongPress.step(() => { if (selHold && selHold.back === back) selHold = null; out(); }); selHold = {k, back}; }
function selOff(k) { if (!selHold || (k && selHold.k !== k)) return; const b = selHold.back; selHold = null; b(); }
const libNow = () => { if (cur === "lib" && !detail) LAB3 || resTab() === "record" ? SCREENS.lib() : libDraw(); };
function libDraw() {
  const g = document.getElementById("libg"); if (!g) return;
  // A fresh open always lands on 새로 온 것, empty or not: skipping to the next tab read as "something is waiting".
  if (libFAuto || !libF) libF = "fresh";
  libHash();
  const qq = libQ.trim().toLowerCase();
  const base0 = D.items.filter((x) => !libHide.has(iid(x)) && (!libD || gname(x) === libD)
    && Triage.match(`${x.title} ${x.dept || ""} ${pname(x.dept || "")} ${x.project} ${pname(x.project)}`, qq));
  const base = base0.filter((x) => !libK || kindOf(x) === libK);
  // By department unless the reader picked another order: one pile by date was hard to tell apart.
  const ord = libOrd();
  const L = base.filter((x) => libF === "all" ? stOf(x) !== "finished" : stOf(x) === libF).sort(byAt);
  if (ord === "old") L.reverse();
  // Due soonest first (overdue on top); items without a due date go last, newest first.
  if (ord === "due") L.sort((a, b) => (a.due ? 0 : 1) - (b.due ? 0 : 1) || (a.due || "").localeCompare(b.due || "") || byAt(a, b));
  // What came in the last 15 minutes is its own group on top, so a fresh push is not lost in 오늘.
  // 확인 필요 goes by department, so one department's pile is looked through in one go.
  // Departments come in order of their newest push, so whoever just sent something is on top.
  // 멈춤 goes by who stopped it (the reader, or nobody), so the ones that just ended can be
  // finished in one go. 끝난 작업 always goes by project: one project's whole run in one place.
  const byWho = libF === "stalled", fin = libF === ST_DONE;
  const byDept = fin || (PILED.includes(ord) && !byWho), gord = fin ? "dept" : ord, groups = {};
  if (byDept) L.forEach((x) => (groups[libGroupOf(x, gord)] ||= []).push(x));
  else if (byWho) [[true, tl("st.g.mine")], [false, tl("st.g.ended")]].forEach(([m, t]) => { const xs = L.filter((x) => !!stJ(x).mine === m); if (xs.length) groups[t] = xs; });
  else if (ord === "due") L.forEach((x) => (groups[x.due ? tl("libDraw.27") : tl("libDraw.28")] ||= []).push(x));
  else L.forEach((x) => (groups[justIn(x) && ord === "new" ? tl("libDraw.2") : day(x.at)] ||= []).push(x));
  // 확인 필요: several can be approved in one go - a department's pile it has already been
  // looked through elsewhere, or a row of small fixes.
  const pick = ST_MINE.includes(libF) && L.length > 1;
  if (!pick) libSel = null;
  const G = Object.entries(groups);
  // Project piles follow the order set in the sidebar; the rest keep newest-first.
  if (byDept && gord === "dept") { const po = pjOrder(), at = (d) => { const i = po.indexOf(d); return i < 0 ? 1e6 : i; }; G.sort((a, b) => at(a[0]) - at(b[0])); }
  const K = LIB_KINDS.filter(([k]) => !k || base0.some((x) => kindOf(x) === k));
  // The toolbar above is static (so the search keeps its focus); only its state is synced here.
  const kSel = document.getElementById("libk");
  if (kSel) { const ko = K.map(([k, n]) => `<option value="${k}">${n}</option>`).join(""); if (kSel.dataset.o !== ko) { kSel.innerHTML = ko; kSel.dataset.o = ko; } kSel.value = libK; }
  document.querySelectorAll(".ltool .lord [data-libo]").forEach((b) => { const on = ord === b.dataset.libo; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  document.querySelectorAll(".ltool .seg.zoom [data-libz]").forEach((b) => { const on = libZ() === b.dataset.libz; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  const zc = document.querySelector(".ltool .zcyc"); if (zc) zc.dataset.libz = {s: "m", m: "l", l: "s"}[libZ()];
  const fb = document.querySelector(".ltool .lfbtn em"); if (fb) { const n = libFilN(); fb.hidden = !n; fb.textContent = n || ""; fb.parentElement.classList.toggle("on", !!n); }
  g.innerHTML = stTabs(base, libF, "lib")
    + (pick ? `<div class="selrow"><span>${libSel ? `<b class="num">${libSel.size}</b>${tl("libDraw.10")}` : tl("libDraw.11", {n: L.length})}</span><button class="btn sm weak press" id="selon">${libSel ? tl("libDraw.12") : tl("libDraw.13")}</button></div>` : "")
    + (L.length ? G.map(([d, xs], gi) => `<div class="sec${byDept ? " secd" : ""}${byDept && !fin && !libSel && G.length === 1 && gord === "dept" && !libFold.has(d) ? " solo" : ""}">${byDept ? `<button class="fold press" data-fold="${esc(d)}" aria-expanded="${!libFold.has(d)}">${gord === "role" ? `<span class="dmk">${ic("people")}</span>` : gord === "session" ? `<span class="dmk">${ic("chat")}</span>` : deptMark(d) || `<span class="dmk">${ic("folder")}</span>`}<b>${esc(gord === "role" || gord === "session" ? d : pname(d))}</b><em class="num">${xs.length}</em>${xs.some(stMine) && !ST_MINE.includes(libF) ? `<span class="warn">${tl("fold.1", {n: xs.filter(stMine).length})}</span>` : ""}${ic("chev", "i fc")}</button>` : byWho ? `<b class="gwho">${esc(d)}</b><em class="num">${xs.length}</em>` : esc(d)}${libSel ? ` <button class="lnk press" data-selg="${gi}">${xs.every((x) => libSel.has(iid(x))) ? tl("libDraw.15") : tl("libDraw.16")}</button>` : byWho ? ` <button class="lnk press" data-finall="${gi}">${ic("flag")}${tl("fin.all", {n: xs.length})}</button>` : fin || !(ST_MINE.includes(libF) || libF === "all") ? "" : xs.filter(gtri).length > 1 ? ` <button class="lnk press" data-triall="${gi}">${tl("libDraw.17", {p1: xs.filter(gtri).length})}</button>` : ""}</div>${fin ? finGroup(d, xs) : `<div class="gal z-${libZ()}"${byDept && libFold.has(d) ? " hidden" : ""}>${xs.map((x) => `<div class="gw"${libSel ? "" : " data-tk"}><button class="gi press${libSel?.has(iid(x)) ? " picked" : ""}" ${libSel ? `data-sel="${esc(iid(x))}" aria-pressed="${libSel.has(iid(x))}"` : `data-item="${esc(iid(x))}"`}>
      <div class="th">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${libF === "fresh" && stName(x) === tl("st.fresh") ? "" : `<span class="tag ${stCls(x)}"${stTip(x)}>${stName(x)}</span>`}${libSel ? `<span class="pk">${ic("check")}</span>` : lintTag(iid(x) + "@" + x.v, x.lint)}</div>
      <div class="tx"><div class="t">${esc(x.title)}</div><div class="s gm"><span class="gmn">${byDept && gord === "dept" ? "" : `<span class="gpn">${deptMark(gname(x))}${esc(pname(gname(x)))}</span>`}<span class="grest">${byDept && gord === "dept" ? "" : " · "}${esc(x.v)} · ${ago(x.at)}${window.resMeta ? resMeta(x) : ""}</span></span>${x.open ? `<span class="gop"> · <b class="opn">${tl("open.1", {n: x.open})}</b></span>` : ""}</div>${x.comments && x.note ? `<div class="s">${noteTag(x).slice(3)}</div>` : ""}</div></button>${libSel ? "" : gmore(x)}</div>`).join("")}</div>`}`).join("")
      // A search that finds nothing in this list but something in another says so, one press away.
      : `<div class="card plan none">${mEmpty(qq || libD ? "emptySearch" : "emptyInbox")}${qq || libD ? `<p>${tl("libDraw.18")}</p>${libF !== "all" && base.length ? `<p class="act"><button class="btn press" data-lib="all">${tl("lib.q.else", {n: base.length})}</button></p>` : ""}` : stNone(libF) + stNext(libF)}</div>`)
    + (libSel ? `<div class="ctapad"></div>` : "");
  if (!libSel) selOff("lib");
  selBar(libSel ? libSel.size : null, () => { libSel = null; libDraw(); }, () => approveMany(L.filter((x) => libSel.has(iid(x)))));
  stStrip(g);
  // 멈춤: a whole group ended in one press (작업 끝내기 on each), with the toast's 되돌리기.
  g.querySelectorAll("[data-finall]").forEach((b) => b.onclick = () => libFin(G[+b.dataset.finall][1].slice(), true));
  finWire(g);
  document.getElementById("selon")?.addEventListener("click", () => { libSel = libSel ? null : new Set(); libDraw(); });
  g.querySelectorAll("[data-sel]").forEach((b) => b.onclick = () => { const k = b.dataset.sel; libSel.has(k) ? libSel.delete(k) : libSel.add(k); if (!libSel.size && selHold) libSel = null; libDraw(); });
  g.querySelectorAll("[data-selg]").forEach((b) => b.onclick = () => { const xs = G[+b.dataset.selg][1], all = xs.every((x) => libSel.has(iid(x)));
    xs.forEach((x) => all ? libSel.delete(iid(x)) : libSel.add(iid(x))); libDraw(); });
  g.querySelectorAll("[data-fold]").forEach((b) => b.onclick = () => { const k = b.dataset.fold; libFold.has(k) ? libFold.delete(k) : libFold.add(k); saveFold(); libDraw(); });
  g.querySelectorAll("[data-triall]").forEach((b) => b.onclick = () => triage(G[+b.dataset.triall][1].filter(gtri)));
  triMark();
  // Words that are in comments or summaries, not in titles: the server looks through those.
  const s = document.getElementById("libs"), ask = ++libAsk;
  if (qq.length < 2) { s.innerHTML = ""; return; }
  get(`/api/search?q=${encodeURIComponent(qq)}`).then((r) => {
    if (ask !== libAsk) return;
    const hs = (r.hits || []).filter((h) => h.where !== "제목" && (!libD || gname(h) === libD));
    s.innerHTML = hs.length ? `<div class="sec">${tl("libDraw.23", {n: hs.length})}</div><div class="card">${hs.map((h) => hitRow(h, qq)).join("")}</div>` : "";
  }).catch(() => {});
}
// Hovering a video's card plays it in place, as ThreeUI's catalogue does, so a pile of renders can
// be told apart without opening each one. PC only, after a short rest, never with reduced motion.
const hoverFiles = new Map();
let hoverT = 0, hoverVd = null;
// Only one preview streams at a time; the old one lets go of its connection at once.
const dropHover = (vd) => { if (!vd) return; if (hoverVd === vd) hoverVd = null;
  vd.classList.remove("in"); setTimeout(() => { vd.pause(); vd.removeAttribute("src"); vd.load(); vd.remove(); }, 200); };
async function hoverClip(key) {
  if (!hoverFiles.has(key)) { const [p, ...r] = key.split("/");
    hoverFiles.set(key, get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(r.join("/"))}`).then((d) => {
      const v = (d.versions || []).at(-1), f = (v?.files || []).find((f) => f.kind === "video" && f.play);
      return f?.play || null; }).catch(() => null)); }
  return hoverFiles.get(key);
}
document.addEventListener("pointerover", (e) => {
  if (e.pointerType !== "mouse" || RM()) return;
  const card = e.target.closest?.(".gi[data-item]"); if (!card || card.contains(e.relatedTarget)) return;
  const x = D.items.find((y) => iid(y) === card.dataset.item); if (x?.kind !== "video") return;
  clearTimeout(hoverT);
  hoverT = setTimeout(async () => {
    const url = await hoverClip(card.dataset.item); if (!url || !card.matches(":hover") || card.querySelector("video")) return;
    const th = card.querySelector(".th"), vd = document.createElement("video");
    Object.assign(vd, {src: url, muted: true, loop: true, playsInline: true, preload: "metadata"}); vd.className = "hov";
    dropHover(hoverVd); hoverVd = vd;
    vd.addEventListener("playing", () => vd.classList.add("in"), {once: true});
    th.appendChild(vd); vd.play().catch(() => vd.remove());
  }, 350);
});
document.addEventListener("pointerout", (e) => {
  const card = e.target.closest?.(".gi[data-item]"); if (!card || card.contains(e.relatedTarget)) return;
  clearTimeout(hoverT); dropHover(card.querySelector("video.hov"));
});
// A found line with the words marked, for the list's and the search screen's 코멘트 · 요약 results.
const hitRow = (h, q) => { const at = h.hit.toLowerCase().indexOf(q.toLowerCase());
  const hit = at < 0 ? esc(h.hit) : esc(h.hit.slice(0, at)) + `<b>${esc(h.hit.slice(at, at + q.length))}</b>` + esc(h.hit.slice(at + q.length));
  return `<button class="row press hit" data-item="${esc(h.project + "/" + h.id)}"><span class="ico sm c-grey">${ic(h.where === "코멘트" ? "chat" : "doc")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(h.title)}${h.archived ? ` <span class="tag">${tl("hitRow.1")}</span>` : ""}</div><div class="s">${esc(h.where === "코멘트" ? tl("hit.w.comment") : h.where === "요약" ? tl("hit.w.sum") : h.where)} · ${hit}</div></span></button>`; };
// ---------- X15: result card actions (승인 · 맡기기 · 정리), right on the card ----------
// One click per result for a pile that grew too tall to open one by one: 승인, 맡기기 (off the
// list, and its project decides whether a newer cut, a finished one or nothing should come back),
// 정리 (off the list, nobody told). They used to sit behind a ⋯ and a centred sheet; now the row is
// on the card itself (PC: in place of the meta line on hover or focus; touch: always there), and
// 되돌리기 in the toast stands in for the confirm step.
// A settled (approved, no turn) card can still be cleared off the grid - it just needs 정리, not
// the 승인/맡기기 pair. gtri stays the "still needs a decision" predicate for the bulk actions.
const gtri = (x) => !x.finished && !(x.status === "approved" && !turnOf(x));
// Phosphor regular, same source as the P table (licenses/phosphor.md).
Object.assign(P, {
  "sort-descending": '<path d="M40,128a8,8,0,0,1,8-8h72a8,8,0,0,1,0,16H48A8,8,0,0,1,40,128Zm8-56h56a8,8,0,0,0,0-16H48a8,8,0,0,0,0,16ZM184,184H48a8,8,0,0,0,0,16H184a8,8,0,0,0,0-16ZM229.66,82.34l-40-40a8,8,0,0,0-11.32,0l-40,40a8,8,0,0,0,11.32,11.32L176,67.31V144a8,8,0,0,0,16,0V67.31l26.34,26.35a8,8,0,0,0,11.32-11.32Z"/>',
  kbd:'<path fill-rule="evenodd" d="M32 48h192a16 16 0 0 1 16 16v128a16 16 0 0 1-16 16H32a16 16 0 0 1-16-16V64a16 16 0 0 1 16-16Zm0 16v128h192V64ZM60 88h16v16H60Zm40 0h16v16h-16Zm40 0h16v16h-16Zm40 0h16v16h-16ZM60 124h16v16H60Zm40 0h16v16h-16Zm40 0h16v16h-16Zm40 0h16v16h-16ZM84 160h88v16H84Z"/>',
  power:'<path d="M120,128V48a8,8,0,0,1,16,0v80a8,8,0,0,1-16,0Zm60.37-78.7a8,8,0,0,0-8.74,13.4C194.74,77.77,208,101.57,208,128a80,80,0,0,1-160,0c0-26.43,13.26-50.23,36.37-65.3a8,8,0,0,0-8.74-13.4C47.9,67.38,32,96.06,32,128a96,96,0,0,0,192,0C224,96.06,208.1,67.38,180.37,49.3Z"/>',
  wait:'<path d="M200,75.64V40a16,16,0,0,0-16-16H72A16,16,0,0,0,56,40V76a16.07,16.07,0,0,0,6.4,12.8L114.67,128,62.4,167.2A16.07,16.07,0,0,0,56,180v36a16,16,0,0,0,16,16H184a16,16,0,0,0,16-16V180.36a16.09,16.09,0,0,0-6.35-12.77L141.27,128l52.38-39.6A16.05,16.05,0,0,0,200,75.64ZM72,40H184V75.64L178.23,80H77.33L72,76Zm56,78L98.67,96h58.4Zm56,98H72V180l48-36v24a8,8,0,0,0,16,0V144.08l48,36.28Z"/>',
  undo:'<path d="M224,128a96,96,0,0,1-94.71,96H128A95.38,95.38,0,0,1,62.1,197.8a8,8,0,0,1,11-11.63A80,80,0,1,0,71.43,71.39a3.07,3.07,0,0,1-.26.25L44.59,96H72a8,8,0,0,1,0,16H24a8,8,0,0,1-8-8V56a8,8,0,0,1,16,0V85.8L60.25,60A96,96,0,0,1,224,128Z"/>',
  tack:'<path d="M235.32,81.37,174.63,20.69a16,16,0,0,0-22.63,0L98.37,74.49c-10.66-3.34-35-7.37-60.4,13.14a16,16,0,0,0-1.29,23.78L85,159.71,42.34,202.34a8,8,0,0,0,11.32,11.32L96.29,171l48.29,48.29A16,16,0,0,0,155.9,224c.38,0,.75,0,1.13,0a15.93,15.93,0,0,0,11.64-6.33c19.64-26.1,17.75-47.32,13.19-60L235.33,104A16,16,0,0,0,235.32,81.37ZM224,92.69h0l-57.27,57.46a8,8,0,0,0-1.49,9.22c9.46,18.93-1.8,38.59-9.34,48.62L48,100.08c12.08-9.74,23.64-12.31,32.48-12.31A40.13,40.13,0,0,1,96.81,91a8,8,0,0,0,9.25-1.51L163.32,32,224,92.68Z"/>',
  folders:'<path d="M224,64H154.67L126.93,43.2a16.12,16.12,0,0,0-9.6-3.2H72A16,16,0,0,0,56,56V72H40A16,16,0,0,0,24,88V200a16,16,0,0,0,16,16H192.89A15.13,15.13,0,0,0,208,200.89V184h16.89A15.13,15.13,0,0,0,240,168.89V80A16,16,0,0,0,224,64ZM192,200H40V88H85.33l29.87,22.4A8,8,0,0,0,120,112h72Zm32-32H208V112a16,16,0,0,0-16-16H122.67L94.93,75.2a16.12,16.12,0,0,0-9.6-3.2H72V56h45.33L147.2,78.4A8,8,0,0,0,152,80h72Z"/>',
  user:'<path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"/>',
  cal:'<path d="M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z"/>',
  stack:'<path d="M230.91,172A8,8,0,0,1,228,182.91l-96,56a8,8,0,0,1-8.06,0l-96-56A8,8,0,0,1,36,169.09l92,53.65,92-53.65A8,8,0,0,1,230.91,172ZM220,121.09l-92,53.65L36,121.09A8,8,0,0,0,28,134.91l96,56a8,8,0,0,0,8.06,0l96-56A8,8,0,1,0,220,121.09ZM24,80a8,8,0,0,1,4-6.91l96-56a8,8,0,0,1,8.06,0l96,56a8,8,0,0,1,0,13.82l-96,56a8,8,0,0,1-8.06,0l-96-56A8,8,0,0,1,24,80Zm23.88,0L128,126.74,208.12,80,128,33.26Z"/>',
  note:'<path d="M229.66,58.34l-32-32a8,8,0,0,0-11.32,0l-96,96A8,8,0,0,0,88,128v32a8,8,0,0,0,8,8h32a8,8,0,0,0,5.66-2.34l96-96A8,8,0,0,0,229.66,58.34ZM124.69,152H104V131.31l64-64L188.69,88ZM200,76.69,179.31,56,192,43.31,212.69,64ZM224,128v80a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V48A16,16,0,0,1,48,32h80a8,8,0,0,1,0,16H48V208H208V128a8,8,0,0,1,16,0Z"/>',
  sun:'<path d="M120,40V16a8,8,0,0,1,16,0V40a8,8,0,0,1-16,0Zm72,88a64,64,0,1,1-64-64A64.07,64.07,0,0,1,192,128Zm-16,0a48,48,0,1,0-48,48A48.05,48.05,0,0,0,176,128ZM58.34,69.66A8,8,0,0,0,69.66,58.34l-16-16A8,8,0,0,0,42.34,53.66Zm0,116.68-16,16a8,8,0,0,0,11.32,11.32l16-16a8,8,0,0,0-11.32-11.32ZM192,72a8,8,0,0,0,5.66-2.34l16-16a8,8,0,0,0-11.32-11.32l-16,16A8,8,0,0,0,192,72Zm5.66,114.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32-11.32ZM48,128a8,8,0,0,0-8-8H16a8,8,0,0,0,0,16H40A8,8,0,0,0,48,128Zm80,80a8,8,0,0,0-8,8v24a8,8,0,0,0,16,0V216A8,8,0,0,0,128,208Zm112-88H216a8,8,0,0,0,0,16h24a8,8,0,0,0,0-16Z"/>',
  ask:'<path d="M140,180a12,12,0,1,1-12-12A12,12,0,0,1,140,180ZM128,72c-22.06,0-40,16.15-40,36v4a8,8,0,0,0,16,0v-4c0-11,10.77-20,24-20s24,9,24,20-10.77,20-24,20a8,8,0,0,0-8,8v8a8,8,0,0,0,16,0v-.72c18.24-3.35,32-17.9,32-35.28C168,88.15,150.06,72,128,72Zm104,56A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/>',
  shield:'<path d="M208,40H48A16,16,0,0,0,32,56v56c0,52.72,25.52,84.67,46.93,102.19,23.06,18.86,46,25.26,47,25.53a8,8,0,0,0,4.2,0c1-.27,23.91-6.67,47-25.53C198.48,196.67,224,164.72,224,112V56A16,16,0,0,0,208,40Zm0,72c0,37.07-13.66,67.16-40.6,89.42A129.3,129.3,0,0,1,128,223.62a128.25,128.25,0,0,1-38.92-21.81C61.82,179.51,48,149.3,48,112l0-56,160,0ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"/>',
  copy:'<path d="M216,32H88a8,8,0,0,0-8,8V80H40a8,8,0,0,0-8,8V216a8,8,0,0,0,8,8H168a8,8,0,0,0,8-8V176h40a8,8,0,0,0,8-8V40A8,8,0,0,0,216,32ZM160,208H48V96H160Zm48-48H176V88a8,8,0,0,0-8-8H96V48H208Z"/>',
  sliders:'<path d="M40,88H73a32,32,0,0,0,62,0h81a8,8,0,0,0,0-16H135a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16Zm64-24A16,16,0,1,1,88,80,16,16,0,0,1,104,64ZM216,168H199a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16h97a32,32,0,0,0,62,0h17a8,8,0,0,0,0-16Zm-48,24a16,16,0,1,1,16-16A16,16,0,0,1,168,192Z"/>',
  monitor:'<path d="M208,40H48A24,24,0,0,0,24,64V176a24,24,0,0,0,24,24H208a24,24,0,0,0,24-24V64A24,24,0,0,0,208,40Zm8,136a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V64a8,8,0,0,1,8-8H208a8,8,0,0,1,8,8Zm-48,48a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,224Z"/>',
  phone:'<path d="M176,16H80A24,24,0,0,0,56,40V216a24,24,0,0,0,24,24h96a24,24,0,0,0,24-24V40A24,24,0,0,0,176,16ZM72,64H184V192H72Zm8-32h96a8,8,0,0,1,8,8v8H72V40A8,8,0,0,1,80,32Zm96,192H80a8,8,0,0,1-8-8v-8H184v8A8,8,0,0,1,176,224Z"/>',
  bolt:'<path d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"/>',
  scroll:'<path d="M96,104a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H104A8,8,0,0,1,96,104Zm8,40h64a8,8,0,0,0,0-16H104a8,8,0,0,0,0,16Zm128,48a32,32,0,0,1-32,32H88a32,32,0,0,1-32-32V64a16,16,0,0,0-32,0c0,5.74,4.83,9.62,4.88,9.66h0A8,8,0,0,1,24,88a7.89,7.89,0,0,1-4.79-1.61h0C18.05,85.54,8,77.61,8,64A32,32,0,0,1,40,32H176a32,32,0,0,1,32,32V168h8a8,8,0,0,1,4.8,1.6C222,170.46,232,178.39,232,192ZM96.26,173.48A8.07,8.07,0,0,1,104,168h88V64a16,16,0,0,0-16-16H67.69A31.71,31.71,0,0,1,72,64V192a16,16,0,0,0,32,0c0-5.74-4.83-9.62-4.88-9.66A7.82,7.82,0,0,1,96.26,173.48ZM216,192a12.58,12.58,0,0,0-3.23-8h-94a26.92,26.92,0,0,1,1.21,8,31.82,31.82,0,0,1-4.29,16H200A16,16,0,0,0,216,192Z"/>',
  stopfill:'<rect x="56" y="56" width="144" height="144" rx="28"/>',
  mic:'<path d="M128,176a48.05,48.05,0,0,0,48-48V64a48,48,0,0,0-96,0v64A48.05,48.05,0,0,0,128,176ZM96,64a32,32,0,0,1,64,0v64a32,32,0,0,1-64,0Zm40,143.6V240a8,8,0,0,1-16,0V207.6A80.11,80.11,0,0,1,48,128a8,8,0,0,1,16,0,64,64,0,0,0,128,0,8,8,0,0,1,16,0A80.11,80.11,0,0,1,136,207.6Z"/>',
  globe:'<path d="M128,24h0A104,104,0,1,0,232,128,104.12,104.12,0,0,0,128,24Zm87.62,96H175.79C174,83.49,159.94,57.67,148.41,42.4A88.19,88.19,0,0,1,215.63,120ZM96.23,136h63.54c-2.31,41.61-22.23,67.11-31.77,77C118.45,203.1,98.54,177.6,96.23,136Zm0-16C98.54,78.39,118.46,52.89,128,43c9.55,9.93,29.46,35.43,31.77,77Zm11.36-77.6C96.06,57.67,82,83.49,80.21,120H40.37A88.19,88.19,0,0,1,107.59,42.4ZM40.37,136H80.21c1.82,36.51,15.85,62.33,27.38,77.6A88.19,88.19,0,0,1,40.37,136Zm108,77.6c11.53-15.27,25.56-41.09,27.38-77.6h39.84A88.19,88.19,0,0,1,148.41,213.6Z"/>',
  toggle:'<path d="M176,56H80a72,72,0,0,0,0,144h96a72,72,0,0,0,0-144Zm0,128H80A56,56,0,0,1,80,72h96a56,56,0,0,1,0,112ZM80,88a40,40,0,1,0,40,40A40,40,0,0,0,80,88Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,80,152Z"/>',
  info:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"/>',
  steth:'<path d="M220,160a12,12,0,1,1-12-12A12,12,0,0,1,220,160Zm-4.55,39.29A48.08,48.08,0,0,1,168,240H144a48.05,48.05,0,0,1-48-48V151.49A64,64,0,0,1,40,88V40a8,8,0,0,1,8-8H72a8,8,0,0,1,0,16H56V88a48,48,0,0,0,48.64,48c26.11-.34,47.36-22.25,47.36-48.83V48H136a8,8,0,0,1,0-16h24a8,8,0,0,1,8,8V87.17c0,32.84-24.53,60.29-56,64.31V192a32,32,0,0,0,32,32h24a32.06,32.06,0,0,0,31.22-25,40,40,0,1,1,16.23.27ZM232,160a24,24,0,1,0-24,24A24,24,0,0,0,232,160Z"/>',
  import:'<path d="M223.16,68.42l-16-32A8,8,0,0,0,200,32H56a8,8,0,0,0-7.16,4.42l-16,32A8.08,8.08,0,0,0,32,72V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V72A8.08,8.08,0,0,0,223.16,68.42ZM60.94,48H195.06l8,16H52.94ZM208,208H48V80H208V208Zm-42.34-61.66a8,8,0,0,1,0,11.32l-32,32a8,8,0,0,1-11.32,0l-32-32a8,8,0,0,1,11.32-11.32L120,164.69V104a8,8,0,0,1,16,0v60.69l18.34-18.35A8,8,0,0,1,165.66,146.34Z"/>',
  key:'<path d="M216.57,39.43A80,80,0,0,0,83.91,120.78L28.69,176A15.86,15.86,0,0,0,24,187.31V216a16,16,0,0,0,16,16H72a8,8,0,0,0,8-8V208H96a8,8,0,0,0,8-8V184h16a8,8,0,0,0,5.66-2.34l9.56-9.57A79.73,79.73,0,0,0,160,176h.1A80,80,0,0,0,216.57,39.43ZM224,98.1c-1.09,34.09-29.75,61.86-63.89,61.9H160a63.7,63.7,0,0,1-23.65-4.51,8,8,0,0,0-8.84,1.68L116.69,168H96a8,8,0,0,0-8,8v16H72a8,8,0,0,0-8,8v16H40V187.31l58.83-58.82a8,8,0,0,0,1.68-8.84A63.72,63.72,0,0,1,96,95.92c0-34.14,27.81-62.8,61.9-63.89A64,64,0,0,1,224,98.1ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z"/>',
  hist:'<path d="M136,80v43.47l36.12,21.67a8,8,0,0,1-8.24,13.72l-40-24A8,8,0,0,1,120,128V80a8,8,0,0,1,16,0Zm-8-48A95.44,95.44,0,0,0,60.08,60.15C52.81,67.51,46.35,74.59,40,82V64a8,8,0,0,0-16,0v40a8,8,0,0,0,8,8H72a8,8,0,0,0,0-16H49c7.15-8.42,14.27-16.35,22.39-24.57a80,80,0,1,1,1.66,114.75,8,8,0,1,0-11,11.64A96,96,0,1,0,128,32Z"/>',
  eye:'<path d="M247.31,124.76c-.35-.79-8.82-19.58-27.65-38.41C194.57,61.26,162.88,48,128,48S61.43,61.26,36.34,86.35C17.51,105.18,9,124,8.69,124.76a8,8,0,0,0,0,6.5c.35.79,8.82,19.57,27.65,38.4C61.43,194.74,93.12,208,128,208s66.57-13.26,91.66-38.34c18.83-18.83,27.3-37.61,27.65-38.4A8,8,0,0,0,247.31,124.76ZM128,192c-30.78,0-57.67-11.19-79.93-33.25A133.47,133.47,0,0,1,25,128,133.33,133.33,0,0,1,48.07,97.25C70.33,75.19,97.22,64,128,64s57.67,11.19,79.93,33.25A133.46,133.46,0,0,1,231.05,128C223.84,141.46,192.43,192,128,192Zm0-112a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Z"/>',
  checkCircle:'<path d="M173.66,98.34a8,8,0,0,1,0,11.32l-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35A8,8,0,0,1,173.66,98.34ZM232,128A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/>',
  bendBack:'<path d="M232,200a8,8,0,0,1-16,0,88.1,88.1,0,0,0-88-88H51.31l34.35,34.34a8,8,0,0,1-11.32,11.32l-48-48a8,8,0,0,1,0-11.32l48-48A8,8,0,0,1,85.66,61.66L51.31,96H128A104.11,104.11,0,0,1,232,200Z"/>',
});
// Which glyph each action wears. Swapping one after the user's pick is this one line.
const GACT_IC = {ok: "checkCircle", tri: "bendBack", off: "archive", fin: "flag", re: "undo"};
// The app's own spring (motion.js puts it on :root as --m-snap), so the cards move as everything else does.
const gaSpring = () => { const c = getComputedStyle(document.documentElement);
  return {easing: c.getPropertyValue("--m-snap").trim() || "cubic-bezier(.2,.9,.25,1)", duration: parseFloat(c.getPropertyValue("--m-snap-d")) || 420}; };
// One 되돌리기 at a time. A new action inside the six seconds sends the waiting one at once (it was
// going to be sent anyway, only without a way back), and the toast is about the latest.
const gaSettle = () => { sendMany(); triSend(); };
let gactOpen = "";                         // narrowest cards: whose 맡기기/정리 are unfolded
// Named gmore for its two call sites (libDraw, deptView); it is the whole row now. The long
// explanations the sheet had are the tooltips.
const gmore = (x) => {
  const k = esc(iid(x)), one = (a, t, h, c, w = t) => `<button class="ga press ${c}" data-ga="${a}" data-gk="${k}" aria-label="${esc(t)}" title="${esc(h)}">${ic(GACT_IC[a])}<span>${w}</span></button>`;
  // 끝난 작업: 다시 열기 takes it back to its list, 정리 puts it away for good (the archive).
  if (x.finished) return `<div class="gact two" role="group" aria-label="${tl("gact.6")}">${one("re", tl("fin.re"), tl("fin.re.h"), "mid")}${one("off", tl("gact.4"), tl("gact.3"), "quiet")}</div>`;
  return `<div class="gact${gactOpen === iid(x) ? " open" : ""}" role="group" aria-label="${tl("gact.6")}">${gtri(x)
    ? one("ok", tl("gact.9"), tl("gact.5") + (tkPage() === "lib" ? " (A)" : ""), "pri") + `<button class="gax press" data-gax="${k}" aria-label="${tl("gact.7")}" aria-expanded="${gactOpen === iid(x)}">${ic("more")}</button>` + one("tri", tl("gact.2"), tl("gact.1"), "mid") : ""}${one("fin", tl("fin.do"), tl("fin.do.h"), "quiet", tl("fin.short"))}</div>`;
};
// The card that left shrinks away where it stood and the rest spring into the gap (FLIP), instead
// of the grid snapping. fn redraws; a redraw in the middle (되돌리기) just starts from where things
// are. Reduced motion: a plain fade, nothing slides.
const gaCalm = async () => { while (performance.now() < gaBusy) await new Promise((r) => setTimeout(r, gaBusy - performance.now() + 20)); };
// A card that stays through a redraw keeps the picture it had: the new <img> would load and fade in again.
const gaGone = new Map();                  // the picture a card left with: 되돌리기 brings it back whole, not as a placeholder
function gaPics(fn) {
  const had = new Map([...V().querySelectorAll(".gw")].map((el) => [el.querySelector(".gi")?.dataset.item, el.querySelector(".th img:not(.loading)")]));
  fn();
  V().querySelectorAll(".gw").forEach((el) => { const a = had.get(el.querySelector(".gi")?.dataset.item), b = el.querySelector(".th img");
    if (a && b && a !== b && a.getAttribute("src") === b.getAttribute("src")) { a.classList.remove("imgin"); b.replaceWith(a); } });
  had.forEach((img, k) => { if (k && img && !img.isConnected) { if (gaGone.size > 40) gaGone.clear(); gaGone.set(k, img); } });
}
// While the cards are moving nothing on them answers: the neighbour slides in under the pointer
// with 정리 exactly where the last 정리 was, and the second half of a double click cleared it too.
let gaMoveT = 0;
const gaMove = (ms) => { document.body.classList.add("gamove"); clearTimeout(gaMoveT); gaMoveT = setTimeout(() => document.body.classList.remove("gamove"), ms); };
function gactFlip(fn) {
  const cards = () => [...V().querySelectorAll(".gw")].map((el) => [el.querySelector(".gi")?.dataset.item, el]);
  // Fresh cards are content-visibility:auto and measure as 300px placeholders until their first
  // paint: read in that state, every card "moved" by hundreds of px and sprang back. The cards
  // within a screen of the viewport are measured whole (.gafl); the rest keep the height they had
  // (measuring all 259 of a long list whole took 160ms of the click). `at` is where each card
  // really is on the screen right now, for the ghost.
  const H = innerHeight, at = new Map(cards().map(([k, el]) => [k, el.getBoundingClientRect()]));
  const near = (r) => r.bottom > -H && r.top < 2 * H, nr = new Set([...at].filter(([, r]) => near(r)).map(([k]) => k));
  cards().forEach(([k, el]) => { if (nr.has(k)) el.classList.add("gafl"); });
  const was = new Map(cards().map(([k, el]) => [k, [el, el.getBoundingClientRect()]])), rm = RM(), sp = gaSpring();
  // The pressed button is seen (hold), the card goes, and only then do the others set off: a
  // neighbour sliding over a card that is still solid read as two cards printed on each other.
  // (Nothing leaving - a card coming back - and they all move at once.)
  gaPics(fn);
  cards().forEach(([k, el]) => { const o = was.get(k);
    if (!o || nr.has(k)) el.classList.add("gafl"); else el.style.containIntrinsicHeight = `auto ${o[1].height}px`; });
  const now = new Set(cards().map(([k]) => k)), hold = [...was.values()].some(([el]) => el.querySelector(".ga.done")) ? 60 : 0,
    lag = rm || ![...was.keys()].some((k) => k && !now.has(k)) ? 0 : hold + 50;
  gaBusy = performance.now() + (rm ? 160 : sp.duration) + lag; gaMove((rm ? 160 : sp.duration) + lag);
  // A card coming back while its ghost is still leaving (되돌리기 mid-way) starts from where the ghost is.
  const gh = new Map();
  document.querySelectorAll(".gaghost").forEach((g) => { const c = getComputedStyle(g); gh.set(g.querySelector(".gi")?.dataset.item, [c.opacity, c.transform]); g.remove(); });
  cards().forEach(([k, el]) => { const o = was.get(k), r = el.getBoundingClientRect();
    if (r.bottom < 0 || r.top > H) return;
    if (!o) { const h = gh.get(k), a = gaGone.get(k), b = el.querySelector(".th img");
      if (a && b && a.getAttribute("src") === b.getAttribute("src")) { a.classList.remove("imgin"); b.replaceWith(a); }
      gaGone.delete(k);
      return el.animate([{opacity: h ? h[0] : 0, transform: rm ? "none" : h ? h[1] : "scale(.94)"}, {opacity: 1, transform: "none"}], rm ? {duration: 160, easing: "ease-out"} : sp); }
    const dx = o[1].left - r.left, dy = o[1].top - r.top;
    if (!o[1].width || !(dx || dy)) return;
    // Reduced motion: nothing slides - a card that changed places fades in where it now is.
    if (rm) el.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
    else el.animate([{transform: `translate(${dx}px,${dy}px)`}, {transform: "none"}], {...sp, delay: lag, fill: "backwards"}); });
  was.forEach(([el], k) => { const r = at.get(k); if (!k || now.has(k) || !r.width || r.bottom < 0 || r.top > H) return;
    const g = el.cloneNode(true); g.className = "gw gaghost"; g.setAttribute("aria-hidden", "true");
    g.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
    document.body.appendChild(g);
    g.animate(rm ? [{opacity: 1}, {opacity: 0}] : [{opacity: 1, transform: "none"}, {opacity: 0, transform: "scale(.95)"}],
      {duration: rm ? 160 : 150, delay: rm ? 0 : hold, easing: "ease-out", fill: "forwards"}).onfinish = () => g.remove(); });
  V().querySelectorAll(".gw.gafl").forEach((el) => { el.style.containIntrinsicHeight = `auto ${el.offsetHeight}px`; el.classList.remove("gafl"); });
}
// A redraw replaces every card: the one that had the keyboard focus gets it back.
const gactDraw = () => { const f = document.activeElement?.closest?.(".gw > .gi")?.dataset.item;
  gaPics(() => { libNow(); redrawDept(); });
  if (f) [...V().querySelectorAll(".gw > .gi")].find((b) => b.dataset.item === f)?.focus({preventScroll: true}); };
// 정리 is sent at once; 되돌리기 takes it back out of the archive, as it was (undo: no "kept" mark).
async function libOff(xs, how) {
  gaSettle();
  if (how === "tri") return triage(xs);
  if (how === "fin" || how === "re") return libFin(xs, how === "fin");
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const bad = [];
  for (const x of xs) {
    try { await post("/api/archive", {p: x.project, i: x.id, on: true}); }
    catch (e) { bad.push(x); libHide.delete(iid(x)); } }
  const ok = xs.filter((x) => !bad.includes(x));
  if (ok.length) toastAct(tl("libOff.2", {n: ok.length}), tl("toggleFav.3"), async () => {
    for (const x of ok) await post("/api/archive", {p: x.project, i: x.id, on: false, undo: true}).catch(() => {});
    await load(); gactFlip(() => { ok.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); toast(tl("libOff.3"), 2200, "restore"); }, 6000, "archive");
  if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
  // The answer comes within the spring: the redraw waits for the cards to settle, or it would cut it short.
  await load(); await gaCalm(); ok.forEach((x) => libHide.delete(iid(x))); gactDraw();
}
// 작업 끝내기 is a mark on the result, sent at once: the card leaves for 끝난 작업 and nothing
// derived (a comment read, a waiting session) brings it back. 되돌리기 - or 다시 열기 there -
// takes the mark off and the result is back where its status puts it.
async function libFin(xs, on, undo = true) {
  gaSettle();
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const bad = [];
  for (const x of xs) {
    try { await post("/api/finish", {p: x.project, i: x.id, on}); }
    catch (e) { bad.push(x); } }
  const ok = xs.filter((x) => !bad.includes(x)), said = on ? tl("fin.done", {n: ok.length}) : tl("fin.back");
  if (ok.length && undo) toastAct(said, tl("toggleFav.3"), () => libFin(ok, !on, false), 6000, on ? "finish" : "restore");
  else if (ok.length) toast(said, 2200, on ? "finish" : "restore");
  if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
  await load(); await gaCalm();
  const draw = () => { xs.forEach((x) => libHide.delete(iid(x))); gactDraw(); };
  // 되돌리기 brings the card back into the list on screen: it springs in like any card that returns.
  undo ? draw() : gactFlip(draw);
}
// The same on the item's own screen (the chip under the title): the screen stays, its status turns.
async function itemFin(p, i, on, undo = true) {
  try { await post("/api/finish", {p, i, on}); } catch (e) { return toast(tl("libOff.4", {n: 1}), 4000); }
  await load(); again();
  const t = on ? tl("fin.done", {n: 1}) : tl("fin.back");
  if (undo) toastAct(t, tl("toggleFav.3"), () => itemFin(p, i, !on, false), 6000, on ? "finish" : "restore");
  else toast(t, 2200, on ? "finish" : "restore");
}
// 맡기기 tells the project, and that cannot be unsaid: like 승인 it is off the list at once but only
// sent once the six seconds of 되돌리기 are over (or the page is left), so taking it back is real.
let triLater = null;
function triage(xs) {
  if (!xs.length) return;
  triSend();
  xs.forEach((x) => libHide.add(iid(x))); gactDraw();
  const o = triLater = {xs};                // sent when the toast's time is up (it waits while the toast is held)
  toastAct(tl("libOff.1", {n: xs.length}), tl("toggleFav.3"), () => {
    if (!triLater) return toast(tl("gact.8"));
    clearTimeout(triLater.timer); const back = triLater.xs; triLater = null;
    gactFlip(() => { back.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); toast(tl("libOff.3"), 2200, "restore"); }, 6000, "archive", () => { if (triLater === o) triSend(); });
}
function triSend() {
  const o = triLater; if (!o) return; triLater = null; clearTimeout(o.timer);
  Promise.all(o.xs.map((x) => fetch("/api/triage", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: x.project, i: x.id, on: true})}).then((r) => r.ok ? null : x, () => x)))
    .then(async (bad) => { bad = bad.filter(Boolean); await load(); o.xs.forEach((x) => libHide.delete(iid(x)));
      if (bad.length) toast(tl("libOff.4", {n: bad.length}), 4000);
      if (!document.activeElement?.matches?.("input,textarea,gk-select")) gactDraw(); });
}
addEventListener("pagehide", () => { triSend(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) triSend(); });
document.addEventListener("click", (e) => { const m = e.target.closest("[data-gax]");
  if (m) { e.stopPropagation(); gactOpen = gactOpen === m.dataset.gax ? "" : m.dataset.gax;
    document.querySelectorAll(".gact").forEach((r) => { const on = !!gactOpen && r.querySelector("[data-gax]")?.dataset.gax === gactOpen; r.classList.toggle("open", on); r.querySelector("[data-gax]")?.setAttribute("aria-expanded", on); }); return; }
  const b = e.target.closest("[data-ga]"); if (!b) return;
  if (gaTipped) { gaTipped = false; e.stopPropagation(); e.preventDefault(); return; }   // that press was a hold to read, not a tap
  e.stopPropagation(); const x = D.items.find((y) => iid(y) === b.dataset.gk); if (!x) return;
  gactOpen = "";
  // From the keyboard the focus would fall off with the card: it moves on to the card that takes its place.
  const at = e.detail || !e.isTrusted ? -1 : [...V().querySelectorAll(".gw")].indexOf(b.closest(".gw"));
  b.classList.add("done");                // the pressed state leaves with the card (the ghost is a copy of it)
  gactFlip(() => { b.dataset.ga === "ok" ? approveMany([x], 6000) : libOff([x], b.dataset.ga); });
  if (at >= 0) { const L = V().querySelectorAll(".gw > .gi"); L[Math.min(at, L.length - 1)]?.focus({preventScroll: true}); } }, true);
// Held on a touch screen, a button says what it does (its tooltip, which a finger cannot hover for),
// and the press that showed it does nothing.
let gaTipT = 0, gaTipped = false;
const gaTipOff = () => document.querySelectorAll(".gatip").forEach((t) => t.remove());
document.addEventListener("pointerdown", (e) => { clearTimeout(gaTipT); gaTipOff(); gaTipped = false;
  const b = e.pointerType !== "mouse" && e.target.closest?.(".ga[title]"); if (!b) return;
  gaTipT = setTimeout(() => { gaTipped = true;
    const t = document.createElement("div"), r = b.getBoundingClientRect(); t.className = "gatip"; t.setAttribute("role", "tooltip"); t.textContent = b.title;
    document.body.appendChild(t);
    t.style.left = Math.max(12, Math.min(innerWidth - t.offsetWidth - 12, r.left + r.width / 2 - t.offsetWidth / 2)) + "px";
    t.style.top = Math.max(12, r.top - t.offsetHeight - 8) + "px"; }, 450); }, true);
["pointerup", "pointercancel"].forEach((n) => document.addEventListener(n, () => { clearTimeout(gaTipT); if (gaTipped) gaTipT = setTimeout(gaTipOff, 2600); }, true));
document.addEventListener("contextmenu", (e) => { if (gaTipped && e.target.closest?.(".ga")) e.preventDefault(); }, true);
// Held on a touch screen, a results card starts 여러 개 승인 with that card picked (as a phone's photo
// or mail list does), where the list offers it: the results (either layout) and a project's
// results. The hold itself, and the lift that opens nothing, are web/longpress.js.
LongPress.add({rows: "#view .gi[data-item],#view .k3lib [data-item]",
  can: () => !libSel && !deptSel && (detail ? detail[0] === "dept" && !!V().querySelector("[data-dsel]")
    : cur === "lib" && !!(LAB3 ? V().querySelector(".k3lib.pickable") : document.getElementById("selon"))),
  hold: (c) => { const k = c.dataset.item;
    if (detail) { deptSel = new Set([k]); selOn("dept", () => { deptSel = null; redrawDept(); }); return redrawDept(); }
    libSel = new Set([k]); selOn("lib", () => { libSel = null; libNow(); }); libNow(); }});
// ---------- /X15 ----------
// Several approved at once: gone from the list at once, sent after five seconds unless taken back.
let manyLater = null;
