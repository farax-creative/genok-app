// Genok web UI, cut from project.js: the per-session menu, several sessions at once, right click, side by side.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- per-session menu -----------------------------------------------------------------------------
  // `again` redraws whichever screen the menu was opened from (the project page or the room grid).
  // A menu row's shortcut, one cap per key: the same caps as the key bar and the shortcut sheet.
  const keyCaps = (k) => `<span class="mk keys" aria-hidden="true">${k.split(" ").map((x) => `<kbd>${x}</kbd>`).join("")}</span>`;
  function menu(btn, s, name, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    // A few words and an icon per choice. One that does not apply to this session is left out;
    // one that could but cannot right now is dimmed and says why when pressed.
    const ended = s.state === "ended", codex = s.agent === "codex";
    const MN = {top: ["pin", topPinned(s) ? tl("session.top.off") : tl("session.top.on")], open: ["play", tl("mn.open")], fresh: ["plus", tl("mn.fresh")], split: ["sidebar", tl("mn.split")], lighten: ["swap", tl("mn.lighten")],
      read: ["eye", s.unread ? tl("mn.read") : tl("mn.unread")], pick: ["check", tl("mn.pick")],
      pin: ["pin", s.pinned ? tl("mn.unpin") : tl("mn.pin")], stop: ["stop", codex ? tl("room.codexStop") : tl("mn.stop")], tidy: ["archive", s.tidied ? tl("mn.untidy") : tl("mn.tidy")]};
    const item = (a) => { const o = what(a, s), m = a === "float" ? ["ext", floating.has(s.id) ? tl("fl.unpin") : tl("fl.pin")] : MN[a];
      return `<button data-a="${a}"${a === "stop" ? ` class="dz"` : ""}${o.off ? ` aria-disabled="true"` : ""}${MK[a] ? ` data-k="${MK[a]}" aria-keyshortcuts="${MK[a]}"` : ""}>${ic(m[0])}<span>${esc(m[1])}</span>${MK[a] ? keyCaps(MK[a]) : ""}</button>`; };
    const ordRow = btn.closest(".pj-srow");
    // A phone folds a running session's state row into the name's row, which hides 변경 and 화면
    // there: the chat's own menu carries them instead, so nothing the PC offers is lost.
    const chN = s.changes ? (s.changes.files || 0) + (s.changes.untracked || 0) : 0;
    const folded = !ended && phoneList() && btn.matches("[data-cmenu]")
      ? (chN ? `<button data-x="chg">${ic("list")}<span>${tl("pj.chg", {n: chN})}</span></button>` : "") + (s.bg ? `<button data-x="bg">${ic("full")}<span>${tl("pj.bglog")}</span></button>` : "") : "";
    // Find in this conversation: also Ctrl+F, but a phone has no keys and the app's window no find of its own.
    // These four answer to a chord, not to a letter while the menu is up: the hint says so the way the letters do.
    const hint = keyCaps;
    const findIt = btn.matches("[data-cmenu]") && btn.closest(".pj-conv") ? `<button data-x="find"${appWin() ? ` aria-keyshortcuts="Control+F"` : ""}>${ic("search")}<span>${tl("pj.find.menu")}</span>${appWin() ? hint("Ctrl F") : ""}</button>` : "";
    // In a chat with lines of mine: to my newest (where the newest answer begins; Alt+Up from anywhere),
    // and under 더 보기 the newest answer whole and the conversation as loaded, both as Markdown.
    const cv = findIt && convs[s.id], said = cv && cv.entries.some((e) => e.kind === "user"), ans = cv ? lastAnswer(cv.entries) : "";
    const recN = convs[s.id] && convs[s.id].work ? convs[s.id].work.files.length : 0;   // files the record says this session edited
    const mineIt = said ? `<button data-x="mine" aria-keyshortcuts="Alt+ArrowUp">${ic("up")}<span>${tl("pj.mine.menu")}</span>${hint("Alt ↑")}</button>` : "";
    // 차례 목록 (a long conversation as a list) and 자주 쓰는 문구 (lines saved to send again).
    const turnsIt = cv && cv.loaded ? `<button data-x="turns" aria-keyshortcuts="Alt+T">${ic("list")}<span>${tl("pj.turns.menu")}</span>${hint("Alt T")}</button>` : "";
    const snipIt = findIt ? `<button data-x="snip" aria-keyshortcuts="Control+/">${ic("book")}<span>${tl("pj.snip.menu")}</span>${hint("Ctrl /")}</button>` : "";
    const maskIt = findIt ? `<button data-x="mask">${ic("lock")}<span>${Redact.on() ? tl("pj.mask.off") : tl("pj.mask.on")}</span></button>` : "";
    const copyIt = (ans ? `<button data-x="cpa">${ic("copy")}<span>${tl("pj.copy.last")}</span></button>` : "") + (said || ans ? `<button data-x="cpc">${ic("doc")}<span>${tl("pj.copy.conv")}</span></button>` : "");
    // An ended Claude session can be handed to the Claude desktop app (`claude --desktop --resume`):
    // only on this PC, and shown once the server says the app and a new enough Claude Code are here.
    const deskIt = ended && !codex && onThisPc() ? `<button data-x="desk"${deskCan ? "" : ` style="display:none"`}>${ic("ext")}<span>${tl("mn.desktop")}</span></button>` : "";
    if (deskIt && !deskCan) get("/api/session/desktop").then((r) => { deskCan = !!r.can; const b = pop.querySelector('[data-x="desk"]'); if (b && deskCan) b.style.display = ""; }).catch(() => {});
    // A taskbar button of its own (taskbar.py): where there is a taskbar and pinning is switched on.
    const B = window.GenokBar, barOn = !!B && B.pins.includes(s.id);
    const barIt = !phoneList() && B && B.native && B.opts && B.opts.pin ? `<button data-x="bar">${ic("pin")}<span>${barOn ? tl("bar.unpin") : tl("bar.pin")}</span></button>` : "";
    pop.innerHTML = item("top") + (ended ? item("open") : "") + item("fresh") + (splitCan(s.id) ? item("split") : "") + (phoneList() ? "" : item("float")) + barIt + (codex ? "" : item("read")) + (ordRow && !pickOn ? item("pick") : "")
      + findIt + mineIt + turnsIt + snipIt + maskIt + folded + (!folded.includes(`"chg"`) && btn.matches("[data-cmenu]") && recN ? `<button data-x="chg">${ic("list")}<span>${tl("pj.chg", {n: recN})}</span></button>` : "")
      + moreRow(item("lighten") + item("pin") + ordItems(ordRow) + (s.fixed ? "" : `<button data-x="name">${ic("pen")}<span>${tl("pj.name.menu")}</span></button>`) + copyIt + deskIt + `<button data-x="access">${ic("shieldCheck")}<span>${tl("session.access.title")}</span></button>` + (phoneList() && name ? `<button data-x="dept">${ic("folder")}<span>${tl("room.deptMenu")}</span></button>` : ""))
      + `<hr>` + item("tidy") + (ended ? "" : item("stop"));
    popAt(pop, btn);
    ordWire(pop, ordRow); moreWire(pop);
    // Whether it is on the floating stack is asked when the menu opens (the stack is changed from
    // its own window too); the row is corrected in place if the answer differs.
    const F = window.GenokFloat;
    (F && F.pins ? Promise.resolve(F.pins()).then((v) => ({cards: [...(v || [])].map((c) => ({sid: c && c.sid ? c.sid : c}))})) : get("/api/float")).then((v) => { const was = floating.has(s.id); floating = new Set((v.cards || []).map((c) => c.sid));
      const b = pop.querySelector('[data-a="float"]'); if (b && pop.isConnected && was !== floating.has(s.id)) { const role = b.getAttribute("role"), had = b === document.activeElement; b.outerHTML = item("float");
        const nb = pop.querySelector('[data-a="float"]'); if (role) { nb.setAttribute("role", role); nb.tabIndex = -1; } if (had) nb.focus({preventScroll: true}); }
      const n = pop.querySelector('[data-a="float"]'); if (n && !n.onclick) n.onclick = (e) => { e.stopPropagation(); pop.remove(); control("float", s, name, again); }; }).catch(() => {});
    pop.querySelectorAll("[data-x]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); pop.remove(); if (b.dataset.x === "bar") return B.pin(s.id, !barOn, {name, title: title(s), agent: s.agent || "claude"}).then(() => toast(barOn ? tl("bar.unpinned") : tl("bar.pinned")), (er) => toast(er.message));
      if (b.dataset.x === "access") return showSessionAccess(s); if (b.dataset.x === "name") return sessRename(s, again); if (b.dataset.x === "desk") return openDesktop(s, again); if (b.dataset.x === "mask") return Redact.set(!Redact.on()); if (b.dataset.x === "chg") return showChanges(s.id); if (b.dataset.x === "find") return findOpen(btn.closest(".pj-conv")); if (b.dataset.x === "turns") return turnsOpen(btn.closest(".pj-conv"), cv); if (b.dataset.x === "snip") return snipOpen(btn.closest(".pj-conv")); if (b.dataset.x === "bg") return showAgentLog(s.bg);
      if (b.dataset.x === "mine") { const bx = btn.closest(".pj-conv").querySelector("#pj-msgs"); return hop(bx, cv, -1, true); }
      if (b.dataset.x === "cpa" || b.dataset.x === "cpc") return copyText(Redact.show(b.dataset.x === "cpa" ? ans : convMarkdown(cv.entries, {title: title(s), me: tl("pj.md.me"), agent: codex ? "Codex" : "Claude Code",
        words: (t) => parts(unnote(t)).words, when: (at) => new Date(at).toLocaleString(tmLoc(), {dateStyle: "medium", timeStyle: "short"})}))).then((ok) => toast(ok ? tl("pj.copied") : tl("pj.copyFail")));
      // A phone's list has no project lines, so the project's own menu is reached from any of its sessions.
      const r = (roomsCache || roomsSeen || []).find((x) => x.name === name); if (btn.isConnected) headMenu(btn, name, !!(r && r.registered), again); });
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const off = what(b.dataset.a, s).off;
      if (off) return toast(off);
      pop.remove(); control(b.dataset.a, s, name, again);
    });
  }
  let deskCan = false;                 // GET /api/session/desktop said `claude --desktop` can run here
  async function openDesktop(s, again) {
    try { await act("/api/session/open", {sid: s.id, via: "desktop"}); toast(tl("pjx.done.app")); roomsCache = null; again(); }
    catch (e) { if (e.message !== "cancelled") toast(e.message); }
  }
  // Genok grants do not describe the agent's current sandbox or approval policy.
  function showSessionAccess(s) {
    const agent = s.agent === "codex" ? "codex" : "claude";
    sheet(`<div class="pj-dlg pj-access"><h3>${tl("session.access.title")}</h3><p class="hint">${esc(title(s))} · ${agent === "codex" ? "Codex" : "Claude"}</p>
      <div class="pj-access-state" role="status">${tl("session.access.loading")}</div>
      <div class="pj-access-run" hidden></div>
      <p class="hint" data-access-note>${tl("session.access.agent")}</p>
      <button class="btn press" data-access-settings>${tl("session.access.settings")}</button></div>`, (box) => {
      box.querySelector("[data-access-settings]").onclick = () => { closeSheet(); setPage = "connect"; setShowPage = true; location.hash = "#settings"; };
      const state = box.querySelector(".pj-access-state");
      // What the agent itself may do is the agent's to say: Codex's newest turn (approval, sandbox) or Claude Code's last permission mode, from its record.
      // Not known (no turn yet, or the ask failed): the sheet keeps saying it cannot be checked here.
      get("/api/session/model?sid=" + enc(s.id)).then((r) => {
        const a = r && r.access; if (!a || !box.isConnected) return;
        const run = box.querySelector(".pj-access-run");
        if (agent === "claude") {
          if (!a.mode) return;
          const MODE = {default: () => tl("session.mode.default"), acceptEdits: () => tl("session.mode.edits"), plan: () => tl("session.mode.plan"),
            auto: () => tl("session.mode.auto"), bypassPermissions: () => tl("session.mode.bypass"), dontAsk: () => tl("session.mode.dontAsk")};
          run.innerHTML = `<dl><dt>${tl("session.mode")}</dt><dd>${MODE[a.mode] ? MODE[a.mode]() : esc(a.mode)}</dd></dl>`;
          run.hidden = false; box.querySelector("[data-access-note]").textContent = tl("session.mode.note");
          return;
        }
        const ASK = {never: () => tl("session.run.ask.never"), "on-request": () => tl("session.run.ask.request"), untrusted: () => tl("session.run.ask.untrusted"), "on-failure": () => tl("session.run.ask.failure")};
        const BOX = {"danger-full-access": () => tl("session.run.box.full"), "workspace-write": () => tl("session.run.box.folder"), "read-only": () => tl("session.run.box.read")};
        const word = (map, v) => v == null ? tl("session.access.unknown") : map[v] ? map[v]() : esc(v);
        run.innerHTML = `<dl><dt>${tl("session.run.ask")}</dt><dd>${word(ASK, a.approval)}</dd>
          <dt>${tl("session.run.box")}</dt><dd>${word(BOX, a.sandbox)}</dd>
          <dt>${tl("session.run.net")}</dt><dd>${a.network == null ? tl("session.access.unknown") : a.network ? tl("session.access.allowed") : tl("session.access.notAllowed")}</dd></dl>`;
        run.hidden = false; box.querySelector("[data-access-note]").textContent = tl("session.run.note");
      }, () => {});
      get("/api/connect/perms").then((r) => {
        if (!box.isConnected) return;
        const items = r && r[agent] && r[agent].items;
        if (!Array.isArray(items)) throw new Error("Missing permission state");
        const value = (scope) => {
          const item = items.find((x) => x.scope === scope);
          return !item || typeof item.on !== "boolean" ? tl("session.access.unknown") : item.on ? tl("session.access.allowed") : tl("session.access.notAllowed");
        };
        state.innerHTML = `<dl><dt>${tl("session.access.read")}</dt><dd>${value("read:" + agent + "-sessions")}</dd>
          <dt>${tl("session.access.send")}</dt><dd>${value("session:wake")}</dd>
          <dt>${tl("session.access.manage")}</dt><dd>${value("session:hide")}</dd></dl>`;
      }).catch(() => { if (box.isConnected) state.textContent = tl("session.access.failed"); });
    });
  }
  // One place for an action's name, its one line, and why it is not available right now. The
  // names keep three things apart: 끝내기 turns the session off, 목록에서 숨기기 only hides it from
  // this list, and folding a panel touches no session at all.
  let floating = new Set();
  const MK = {open: "O", fresh: "N", split: "B", float: "F", read: "U", pick: "S", lighten: "M", pin: "P", stop: "E", tidy: "A"};   // the letter beside each choice
  function what(a, s) {
    const ended = s.state === "ended", codex = s.agent === "codex";
    if (a === "pick") return {label: tl("mn.pick")};
    if (a === "read") return {label: s.unread ? tl("mn.read") : tl("mn.unread"),
      off: !s.unread && (where().sid === s.id || (convs[s.id] && convs[s.id].body && convs[s.id].body.isConnected)) ? tl("rd.open") : ""};
    if (a === "split") return {label: tl("split.open"), sub: tl("split.openSub"), off: splitWhy(s.id)};
    if (a === "float") return floating.has(s.id) ? {label: tl("fl.unpin"), sub: tl("fl.unpinSub")} : {label: tl("fl.pin"), sub: tl("fl.pinSub")};
    if (a === "open") return {label: tl("pjx.open"), sub: tl("pjx.open.sub"), short: tl("pjx.open.short"),
      off: ended ? "" : tl("pjx.open.off")};
    if (a === "fresh") return {label: tl("pjx.fresh"), sub: tl("pjx.fresh.sub"), short: tl("pjx.fresh.short")};
    if (a === "lighten") return {label: tl("pjx.move"), sub: tl("pjx.move.sub"), short: tl("pjx.move.short"),
      off: codex ? tl("pjx.move.offCodex") : ended ? tl("pjx.move.offEnded")
        : s.moved ? tl("pjx.move.offMoved")
        : s.lighten && s.lighten.state === "writing" ? tl("pjx.move.offWriting") : ""};
    if (a === "top") return {label: topPinned(s) ? tl("session.top.off") : tl("session.top.on"), sub: tl("session.top.sub")};
    if (a === "pin") return {label: s.pinned ? tl("room.unpin") : tl("room.pin"), sub: s.pinned ? tl("pjx.unpin.sub") : tl("pjx.pin.sub")};
    if (a === "stop") return codex ? {label: tl("room.codexStop"), sub: tl("pjx.cstop.sub"), short: tl("pjx.cstop.short")}
      : {label: tl("mn.stop"), sub: tl("pjx.stop.sub"), short: tl("pjx.stop.short"), off: ended ? tl("pjx.stop.off") : ""};
    return s.tidied ? {label: tl("pjx.untidy"), sub: tl("pjx.untidy.sub"), short: tl("pjx.untidy.short")}
      : {label: tl("pick.tidy"), sub: codex ? tl("pjx.tidy.subCodex") : tl("pjx.tidy.sub"), short: tl("pjx.tidy.short"),
        off: ""};
  }
  // Only a step that cannot simply be taken back asks first. 이어서 하기 wakes the same
  // conversation and 숨기기 only hides a row (its toast offers 되돌리기): both go at one press.
  const ASK = {
    get fresh() { return [tl("pjx.fresh.ask"), tl("pjx.fresh"), "fresh"]; },   // harmless, so it may be switched off
    lighten: null,                       // the server asks (it knows if the session is up)
    stop: null,                          // the server asks twice
  };
  const DONE = LT(() => ({tidy: tl("pjx.done.tidy"), fresh: tl("pjx.done.fresh"), open: tl("pjx.done.open"), stop: tl("pjx.done.stop"), lighten: tl("pjx.done.lighten")}));
  const BUSY = LT(() => ({top: tl("session.top.busy"), open: tl("pjx.busy.open"), fresh: tl("pjx.busy.fresh"), lighten: tl("pjx.busy.move"), stop: tl("pjx.busy.stop"), tidy: tl("pjx.busy.tidy"), pin: tl("pjx.busy.pin")}));
  // What is being done to a session right now: shown on its row and above its chat, and its
  // buttons wait, so a slow answer never looks like a press that did nothing.
  const busy = {};
  function setBusy(sid, txt) {
    if (txt) busy[sid] = txt; else delete busy[sid];
    document.querySelectorAll(".pj-row[data-sid]").forEach((n) => { if (n.dataset.sid !== sid) return;
      n.classList.toggle("busy", !!txt); txt ? n.setAttribute("aria-busy", "true") : n.removeAttribute("aria-busy");
      const l = n.querySelector(".pj-stl"); if (l) { if (txt) { l.dataset.was = l.dataset.was || l.textContent; l.textContent = txt; } else if (l.dataset.was) { l.textContent = l.dataset.was; delete l.dataset.was; } } });
    const c = convs[sid];
    if (c && c.body && c.body.isConnected) paint(c.body, c, false, c.entries.length);
  }
  async function control(action, s, name, again) {
    const off = what(action, s).off;
    if (off) return toast(off);
    if (action === "split") return splitAdd({id: s.id, p: name}, "", "");
    if (action === "read") return readFlip(s, again);
    if (action === "pick") { picked.add(s.id); pickFrom = s.id; return pickShow(); }
    if (busy[s.id]) return toast(tl("pjx.busy.wait"));
    const tick = (on) => setBusy(s.id, on ? BUSY[action] : "");
    try {
      if (action === "top") {
        const on = !topPinned(s), r = await act("/api/session/top-pin", {sid: s.id, on}, 0, tick);
        topPins = new Set(r.top_pins || []);
        toast(on ? tl("session.top.done") : tl("session.top.undone")); roomsCache = null; return again();
      }
      if (action === "pin") {
        await act("/api/session/pin", s.pinned ? {name, off: 1} : {name, sid: s.id}, 0, tick);
        toast(s.pinned ? tl("room.unpinned") : tl("room.pinnedNow")); roomsCache = null; return again();
      }
      if (action === "float") {
        // The floating stack (floatwin.py): a card of this conversation on top of other apps.
        const on = !floating.has(s.id), F = window.GenokFloat;
        if (F && F.set) {
          const r = await (on ? F.set(s.id, true, {name, title: title(s), agent: s.agent || "claude"}) : F.off ? F.off(s.id) : F.set(s.id, false));
          on ? floating.add(s.id) : floating.delete(s.id);
          // Only what happened is said: it is up, it is kept for the PC app, or the window did not come up.
          return toast(!on ? tl("fl.unpinned") : !r || r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
        }
        const r = await post("/api/float/pin", {sid: s.id, on, name, title: title(s), agent: s.agent || "claude", open: true});
        floating = new Set(r.pins || []);
        return toast(!on ? tl("fl.unpinned") : r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
      }
      if (action === "tidy" && s.tidied) {
        tick(true); await post("/api/session/untidy", {sid: s.id}); toast(tl("pjx.done.untidy")); return again();
      }
      const q = ASK[action];
      if (q && (await confirmDlg(q[0], q[1], q[2])) !== "ok") return;
      let r;
      if (action === "open") {
        r = await act("/api/session/revive", {sid: s.id}, 0, tick);
        if (r.fallback === "open") {
          // A Claude session reopens in the Claude app's Code list; Codex keeps its terminal.
          r = await act("/api/session/open", s.agent === "codex" ? {sid: s.id} : {sid: s.id, via: "app"}, 0, tick);
          if (r.via === "app") r.message = r.message || tl("pjx.done.app");
        }
      } else if (action === "tidy" && dupUnder.has(s.id)) r = await act("/api/session/tidy-many", {sids: withTwins([s.id])}, 0, tick);   // with the ones folded behind it
      else r = await act("/api/session/" + action, {sid: s.id}, 0, tick);
      if (r.terminal) { tick(false); await infoDlg(r.message); return; }
      if (action === "tidy") showTidied = "";   // a hide puts the row away, even with the hidden ones open
      if (action === "tidy" && typeof toastAct === "function") toastAct(r.message || (r.app === "codex" ? tl("pjx.done.tidyCodex") : DONE.tidy), tl("toggleFav.3"), async () => {
        try { await post("/api/session/untidy", {sids: r.sids || [s.id]}); roomsCache = null; again(); } catch (e) { toast(e.message); } });
      else toast(r.message || DONE[action] || tl("pjx.done"));
      if (action === "tidy" && where().sid === s.id) return nav("project/" + enc(name));
      roomsCache = null;
      // 새로 켜기 opens in the background and answers with the new session: go straight to it.
      if (action === "fresh" && r.sid && where().name !== MULTI) return nav("project/" + enc(name) + "/" + enc(r.sid));
      again();
    } catch (e) { if (e.message !== "cancelled") toast(e.message); }
    finally { setBusy(s.id, ""); }
  }

  // 읽지 않음으로 표시 puts the read marker back before the newest reply (the row gets its dot and
  // 내 차례 again); 읽음으로 표시 moves it to the end, as opening the chat does.
  async function readFlip(s, again) {
    const sid = s.id, n = s.unread ? 0 : 1;
    try {
      if (!n) await post("/api/room-read-all", {keys: [sid]});
      else if (!(await post("/api/room-unread", {sid})).ok) return toast(tl("rd.none"));
      readLocal(sid, n);
      if (typeof drawChrome === "function") drawChrome();
      toast(n ? tl("rd.unreadDone") : tl("rd.readDone")); again();
    } catch (e) { toast(e.message); }
  }
  // What the list remembers follows at once (as markRead does for a chat that was opened).
  function readLocal(sid, n) {
    Object.keys(projSeen).forEach((p) => { const v = projSeen[p], x = ((v.v && v.v.sessions) || []).find((y) => y.id === sid); if (x && (x.unread || 0) !== n) { x.unread = n; v.k = JSON.stringify(v.v); } });
    (roomsCache || []).forEach((r) => { if (r.sid === sid) r.unread = n; (r.more || []).forEach((m) => { if (m.sid === sid) m.unread = n; }); });
    if (typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.unread = n; });
    if (convs[sid]) convs[sid].readSent = null;        // opening it later reads it again
  }

  // The new-session row's menu: the one choice, 숨기기, like a session's. `again` redraws the list.
  function draftMenu(btn, name, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    pop.innerHTML = `<button data-a="tidy">${ic("archive")}<span>${esc(tl("mn.tidy"))}</span></button>`;
    popAt(pop, btn);
    pop.querySelector("[data-a]").onclick = (e) => { e.stopPropagation(); pop.remove(); hideDraft(name, again); };
  }
  function hideDraft(name, again) {
    const was = dropDraft(name), at = where();
    toastAct(tl("pick.tidyDone", {n: 1}), tl("pick.undo"), () => { backDraft(name, was); if (where().name === name && where().sid === NEW) again(); else nav("project/" + enc(name) + "/" + NEW); });
    if (at.name === name && at.sid === NEW) nav("project/" + enc(name)); else again();
  }

  // ---- several sessions at once ----------------------------------------------------------------
  // Ctrl (or Cmd) click picks a row, Shift click picks the run up to it, 선택 in a row's menu
  // starts it too. While picking, a click picks instead of opening and a bar stands in the list's
  // head: 읽음으로 표시, 목록에서 숨기기, and more behind the dots. Each does what the row's own
  // menu does, once for all of them. 끝내기 shows only while a picked session is on, and asks
  // once before it ends them. Esc or the cross leaves.
  const picked = new Set();
  let pickOn = false, pickFrom = "", pickNew = false;
  const pickRows = () => [...document.querySelectorAll(".pj-rail .pj-srows .pj-srow[data-sid],.pj-rail .pj-srows .pj-srow[data-dr]")];
  const pkey = (r) => r.dataset.sid || (r.dataset.dr ? NEW : "");     // the new-session row is picked as NEW
  const pickUp = () => [...picked].filter((id) => railRows.has(id) && railRows.get(id).s.state !== "ended");
  const pickBar = (dk) => { const none = picked.size ? "" : ` aria-disabled="true"`, b = (k, i, t, short) => `<button class="pj-pb press${k === "end" ? " dz" : ""}${short ? " lb" : ""}${k === "tidy" || k === "end" ? " tx" : ""}" data-pk="${k}"${k === "off" || k === "more" ? "" : none} aria-label="${esc(t)}" title="${esc(t)}"${k === "more" ? ` aria-haspopup="menu"` : ""}>${ic(i)}${short ? `<span class="pj-pl">${esc(short)}</span>` : ""}</button>`;
    return `<div class="pj-lhd pj-pick${dk ? " dk" : ""}${pickNew ? " new" : ""}" role="toolbar" aria-label="${esc(tl("pick.bar"))}">${b("off", "x", tl("pick.off"))}<b aria-live="polite">${esc(tl("pick.n", {n: picked.size}))}</b>${b("read", "check", tl("mn.read"), tl("pick.read.s"))}${b("tidy", "archive", tl("pick.tidy"), tl("pick.tidy.s"))}${pickUp().length ? b("end", "power", tl("mn.stop"), tl("mn.stop")) : ""}${b("more", "more", tl("mn.more"))}</div>`; };
  function pickMarks(box) {
    box.classList.toggle("picking", pickOn); pickNew = false;
    // Where the sticky bar stops: the top of the list when it scrolls itself, else under the page's top bar.
    const own = /auto|scroll/.test(getComputedStyle(box).overflowY), tb = document.getElementById("top");
    box.style.setProperty("--pk-top", !pickOn || own || !tb ? "0px" : Math.max(0, Math.round(tb.getBoundingClientRect().bottom)) + "px");
    box.querySelectorAll(".pj-srows .pj-srow[data-sid],.pj-srows .pj-srow[data-dr]").forEach((r) => { const on = pickOn && picked.has(pkey(r)); r.classList.toggle("pk", on); on ? r.setAttribute("aria-selected", "true") : r.removeAttribute("aria-selected"); });
    // The phone's bar is fixed to the screen, which the list (a container) cannot hold: it lives on the body.
    const bar = box.querySelector(".pj-pick.dk"); let dk = document.getElementById("pjpk");
    box.classList.toggle("pkdock", !!bar);
    if (!bar) { if (dk) dk.remove(); return; }
    if (!dk) { dk = document.createElement("div"); dk.id = "pjpk"; dk.className = "pj-pkd"; document.body.appendChild(dk); }
    dk.replaceChildren(bar);
  }
  // pickHold: the picking began with a long press, so letting go of its last row ends it, and the
  // back gesture leaves it (pickBack drops that step again when it ends some other way).
  let pickStay = false, pickHold = false, pickBack = null;
  function pickShow() { pickNew = !pickOn; pickOn = true; if (railNow) railNow(); }
  function pickEnd() { if (!pickOn) return; pickOn = false; pickStay = pickHold = false; picked.clear(); pickFrom = ""; if (pickBack) { const b = pickBack; pickBack = null; b(); } if (railNow) railNow(); }
  // A long press on a phone's row (web/longpress.js): the row is in the hand, as before, and let go
  // where it is it starts picking with that row. A row that cannot change places is picked at once,
  // and while picking a hold only adds its row.
  function pickHeld(row, e) {
    const sid = pkey(row);
    const pick = () => { if (!row.isConnected) return false;
      if (!pickOn) { pickHold = true; if (window.LongPress) pickBack = LongPress.step(() => { pickBack = null; pickEnd(); }); }
      picked.add(sid); pickFrom = sid; pickShow(); return true; };
    if (pickOn || !(SP && SP.grab && SP.grab(e, row, pick))) pick();
  }
  const PK_ROWS = ".pj-rail .pj-srows .pj-srow[data-sid],.pj-rail .pj-srows .pj-srow[data-dr]";
  if (window.LongPress) LongPress.add({rows: PK_ROWS, can: (row, e) => phoneList() && !e.target.closest(".pj-more,.sr-m,.sw-tray,a,input,textarea"), hold: pickHeld});
  addEventListener("hashchange", () => { if (location.hash.startsWith("#project")) return; pickEnd(); document.getElementById("pjpk")?.remove(); });
  // A click on a session row: true when it picked (and so must not open the chat).
  function pickClick(e, c) {
    const sid = pkey(c), mod = e.ctrlKey || e.metaKey;
    if (!c.matches(".pj-srows .pj-srow") || (!pickOn && !mod && !e.shiftKey)) return false;
    // With a mouse a plain click leaves the picking and opens the session, as in a file manager;
    // a finger has no Ctrl, so a tap keeps picking.
    // Unless picking was asked for by its button: then every click picks, until the bar is shut.
    if (pickOn && !mod && !e.shiftKey && !phoneList() && !pickStay) { pickEnd(); return false; }
    const ids = pickRows().map(pkey), on = document.querySelector(".pj-rail .pj-srow.on[data-sid]");
    const a = ids.indexOf(pickFrom || (on ? on.dataset.sid : sid)), b = ids.indexOf(sid);
    if (e.shiftKey && a >= 0 && b >= 0) { ids.slice(Math.min(a, b), Math.max(a, b) + 1).forEach((x) => picked.add(x)); const sel = getSelection(); if (sel) sel.removeAllRanges(); }
    else { picked.has(sid) ? picked.delete(sid) : picked.add(sid); pickFrom = sid; }
    if (pickHold && !picked.size) { pickEnd(); return true; }
    pickShow();
    return true;
  }
  function pickDo(a, btn, again) {
    if (a === "off") return pickEnd();
    if (a === "more") return pickMenu(btn, again);
    if (a === "all" || a === "stale") { pickRows().forEach((r) => { if (a === "all" || r.classList.contains("s-stale")) picked.add(pkey(r)); });
      if (a === "stale" && !document.querySelector(".pj-rail .pj-srows .pj-srow.s-stale[data-sid]")) toast(tl("pick.staleNone"));
      return pickShow(); }
    pickRun(a, again);
  }
  // The bar's dots, and a right click on a row while picking: the same choices, with their letters.
  function pickMenu(btn, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    const none = picked.size ? "" : ` aria-disabled="true"`, K = {read: "U", tidy: "A", end: "E"};
    const it = (a, i, t) => `<button data-a="${a}"${a === "end" ? ` class="dz"` : ""}${K[a] ? none + ` data-k="${K[a]}" aria-keyshortcuts="${K[a]}"` : ""}>${ic(i)}<span>${esc(t)}</span>${K[a] ? keyCaps(K[a]) : ""}</button>`;
    pop.innerHTML = it("all", "check", tl("pick.all")) + it("stale", "moon", tl("pick.stale")) + `<hr>` + it("read", "eye", tl("mn.read")) + it("tidy", "archive", tl("pick.tidy")) + (pickUp().length ? `<hr>` + it("end", "stop", tl("mn.stop")) : "");
    popAt(pop, btn);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); if (b.getAttribute("aria-disabled")) return toast(tl("pick.none")); pop.remove(); pickDo(b.dataset.a, b, again); });
  }
  async function pickRun(a, again) {
    const sids = [...picked].filter((id) => railRows.has(id)), up = sids.filter((id) => railRows.get(id).s.state !== "ended"), ended = sids.filter((id) => !up.includes(id));
    const dr = a === "tidy" && picked.has(NEW);        // the new-session row: hiding it forgets the draft
    if (!sids.length && !dr) return toast(tl("pick.none"));
    try {
      if (a === "read") {
        await post("/api/room-read-all", {keys: sids}); sids.forEach((id) => readLocal(id, 0));
        if (typeof drawChrome === "function") drawChrome();
        toast(tl("pick.readDone", {n: sids.length}));
      } else if (a === "end") {
        // 끝내기 for the ones that are on, asked once for all of them (취소 has the focus). Each is
        // ended the way its own row's 끝내기 does, one after another; what has ended is left alone.
        if (!up.length) return toast(tl("pick.endNone"));
        const nm = (id) => title(railRows.get(id).s), names = up.slice(0, 5).map(nm).join(", ") + (up.length > 5 ? " " + tl("pick.endMore", {n: up.length - 5}) : "");
        if ((await ask(`<h3>${esc(tl("pick.endAsk", {n: up.length}))}</h3><p class="pj-dsub">${esc(names)}</p>
          <div class="acts"><button class="pj-btn light full press" data-v="ok">${esc(tl("mn.stop"))}</button><button class="pj-btn full press" data-v="cancel">${tl("libDraw.22")}</button></div>`,
          (box) => setTimeout(() => { const c = box.querySelector("[data-v='cancel']"); if (c && c.isConnected) c.focus({preventScroll: true}); }, 0))) !== "ok") return;
        let done = 0; const bad = [];
        for (const id of up) {
          setBusy(id, BUSY.stop);
          try { const r = await act("/api/session/stop", {sid: id, confirm: 2}); if (r.terminal || r.ok === false) bad.push(nm(id)); else done++; }
          catch (e) { if (e.message === "cancelled") { setBusy(id, ""); break; } bad.push(nm(id)); }
          setBusy(id, "");
        }
        toast(bad.length ? tl("pick.endFail", {n: done, bad: bad.join(", ")}) : tl("pick.endDone", {n: done}));
      } else {
        // Hiding is reversible and never stops selected sessions. A picked row takes the same-titled
        // sessions folded behind it along; the toast counts the rows that were picked.
        const done = sids.length ? (await act("/api/session/tidy-many", {sids: withTwins(sids)})).sids || [] : [], at = where(), was = dr ? dropDraft(at.name) : null; showTidied = "";
        toastAct(tl("pick.tidyDone", {n: sids.filter((id) => done.includes(id)).length + (dr ? 1 : 0)}), tl("pick.undo"), () => (done.length ? post("/api/session/untidy", {sids: done}) : Promise.resolve()).then(() => { if (dr) backDraft(at.name, was); roomsCache = null; again(); }).catch((e) => toast(e.message)));
        if (done.includes(at.sid) || (dr && at.sid === NEW)) { pickEnd(); return nav("project/" + enc(at.name)); }
      }
      pickEnd(); roomsCache = null; again();
    } catch (e) { if (e.message !== "cancelled") toast(e.message); }
  }
  // A click anywhere else (the chat, the page around the list, the list's blank space) leaves the
  // picking. The bar, its menus, dialogs and toasts do not; neither do the list's own controls
  // and rows (a row has its own rule above). The click that ends a drag never gets here (split.js).
  document.addEventListener("click", (e) => {
    if (!pickOn || !e.isTrusted && !e.detail && e.target === document) return;
    const t = e.target; if (!t || !t.closest || !t.isConnected) return;
    if (t.closest(".pj-pick,.pj-pop,#sheet,#ov,#toast,.toast,.pj-dlg,dialog,[role=dialog],[role=menu],.pj-srow,.pj-sgl,.pj-sgrp")) return;
    const rail = t.closest(".pj-rail");
    if (rail && t !== rail && !t.matches(".pj-srows")) return;
    pickEnd();
  });
  document.addEventListener("keydown", (e) => {
    if (!pickOn || e.isComposing || document.querySelector(".pj-pop,#sheet.on,#ov.on")) return;
    if (e.key === "Escape") { e.preventDefault(); return pickEnd(); }
    // Ctrl A picks every row shown, unless a field is being typed in.
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.code === "KeyA" && !(e.target.closest && e.target.closest("input,textarea,[contenteditable]"))) { e.preventDefault(); pickDo("all"); }
  });

  // ---- right click on a row --------------------------------------------------------------------
  // A session row, a session card and a project's name open the menu their ⋯ button opens, at the
  // pointer: right click, Shift F10 or the menu key on a focused row, a long press on a touch
  // screen. Nothing else is touched: text, fields and links keep whatever a right click did there.
  const CTX_ROWS = ".pj-srow[data-sid],.pj-srow[data-dr],.pj-card.pj-row[data-sid],.pj-sgl,.pj-srow[data-p],.pj-head";
  let ctxDown = 0, ctxHold = 0, ctxXY = null, ctxHeld = 0, ctxDownHeld = false, ctxLift = 0;
  function rowCtx(row, x, y, kb) {
    // The page's own wrapper: drawn on #view itself, a second copy of the page was added under the first.
    const el = document.querySelector("#view>.pj") || document.querySelector("#view"), again = () => { if (el && el.isConnected && location.hash.startsWith("#project")) draw(el); };
    const h = row.matches(".pj-srow[data-sid]") ? railRows.get(row.dataset.sid) : null;
    const btn = h ? null : row.querySelector("[data-more],[data-gm],[data-hm],[data-dm]");
    if (!h && !btn) return false;
    if (kb) { const b = row.getBoundingClientRect(); x = b.left + Math.min(40, b.width / 2); y = b.bottom - 6; }
    const to = row.matches(".pj-sgl") ? row.querySelector(".pj-sgh") || row : row.matches(".pj-head") ? btn : row;
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    ctxAt = {x, y, row: to, kb, label: h || row.matches(".pj-card") ? tl("pj.menu") : tl("room.deptMenu")};
    // While picking: the row joins the pick and the menu is the one for all of them.
    if (h && pickOn) { picked.add(row.dataset.sid); pickShow(); pickMenu(row, again); }
    else if (h) menu(row, h.s, h.name, again); else btn.click();
    ctxAt = null;                                      // not taken (the button was waiting on something): no stray point
    return true;
  }
  let ctxPress = null;
  function clearPress() {
    if (!ctxPress) return;
    const p = ctxPress; ctxPress = null;
    if (p.spring) p.spring.jump(1);
    p.row.style.removeProperty("scale"); p.row.classList.remove("pj-holding");
  }
  function pressRow(row) {
    row.classList.add("pj-holding");
    const p = ctxPress = {row, spring: null};
    if (!RM() && window.Motion && Motion.phys) {
      p.spring = Motion.phys(1, 420, 40, (x) => { row.style.scale = String(x); });
      p.spring.set(.985);
    }
  }
  document.addEventListener("pointerdown", (e) => {
    ctxDown = performance.now(); clearTimeout(ctxHold); clearPress(); ctxXY = null; ctxDownHeld = false;
    if (e.pointerType === "mouse" || !e.target.closest) return;
    const row = e.target.closest(CTX_ROWS); if (!row || e.target.closest(".pj-more,a,input,textarea")) return;
    if (phoneList() && row.matches(PK_ROWS)) return;       // a phone's session row: its hold picks (pickHeld)
    const x = e.clientX, y = e.clientY; ctxXY = [x, y]; pressRow(row);
    // Held without moving: the row is in the hand (it can be carried to another place), and let
    // go where it is it opens the menu. A row that cannot change places opens the menu at once
    // (a phone browser without a contextmenu event gets it here).
    const say = () => { if (row.isConnected && rowCtx(row, x, y, false)) { ctxHeld = performance.now(); return true; } return false; };
    ctxHold = setTimeout(() => { ctxXY = null; clearPress(); if (!row.isConnected) return;
      const got = SP && SP.grab && SP.grab(e, row, say);
      if (got) ctxHeld = performance.now();           // the browser's own long-press menu is not wanted over it
      if (got || say()) { ctxDownHeld = true; if (navigator.vibrate) navigator.vibrate(12); } }, 520);
  }, true);
  document.addEventListener("pointermove", (e) => { if (ctxXY && Math.hypot(e.clientX - ctxXY[0], e.clientY - ctxXY[1]) > 8) { clearTimeout(ctxHold); clearPress(); ctxXY = null; } }, true);
  ["pointerup", "pointercancel"].forEach((k) => document.addEventListener(k, () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; if (ctxDownHeld) { ctxDownHeld = false; ctxLift = performance.now(); } }, true));
  addEventListener("blur", () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; });
  addEventListener("hashchange", () => { clearTimeout(ctxHold); clearPress(); ctxXY = null; });
  // A row in the hand keeps the page from scrolling under the finger.
  document.addEventListener("touchmove", (e) => { if (SP && SP.dragging() && e.cancelable) e.preventDefault(); }, {passive: false});
  // The lift that ends a hold must not also open the conversation under the finger.
  // Nor press whatever the menu put under it: the click of that same lift is dropped wherever it lands.
  document.addEventListener("click", (e) => { const now = performance.now(); if (!e.isTrusted) return;
    if ((ctxLift && now - ctxLift < 500) || (ctxHeld && now - ctxHeld < 1200 && !e.target.closest(".pj-pop"))) { ctxHeld = ctxLift = 0; e.preventDefault(); e.stopPropagation(); } }, true);
  document.addEventListener("contextmenu", (e) => {
    const t = e.target;
    if (!t.closest || t.closest("input,textarea,[contenteditable],a[href],.pj-pop")) return;
    const row = t.closest(CTX_ROWS); if (!row) return;
    const sel = getSelection(); if (sel && !sel.isCollapsed && row.contains(sel.anchorNode)) return;   // marked text: copy stays
    if ((SP && SP.dragging()) || (ctxHeld && performance.now() - ctxHeld < 1200)) return e.preventDefault();   // the hold already answered
    clearTimeout(ctxHold); ctxXY = null;
    // No press came before it: the keyboard asked (Shift F10, the menu key).
    const kb = performance.now() - ctxDown > 700 && row.contains(document.activeElement);
    if (rowCtx(row, e.clientX, e.clientY, kb)) { e.preventDefault(); if (e.pointerType === "touch") ctxHeld = performance.now(); }
  });

  // ==== side by side (web/split.js) ================================================================
  // Up to three columns of conversations on a wide screen, two stacked in each (3 x 2). split.js
  // keeps the layout ({panes, rows, w, h, focus}, on this device) and its limits, the drag out of
  // the list and the dividers; here the panes
  // are drawn (each one is the ordinary chat: drawSession) and the room for them is found.
  // The address always names the focused pane, so a reload, a link and the list all agree.
  const SP = window.PjSplit || null;
  let shownCur = null, splitFresh = null;             // the chat that is drawn ({id, p}); the pane just dropped in
  const splitEl = () => document.querySelector("#view .pj");
  // Width left for the chats with the list `railW` wide and the results `sideW` (36 = the two gaps).
  function splitRoom(el, railW, sideW) {
    const c = el.querySelector(".pj-cols"), cs = c ? null : getComputedStyle(el);
    const w = c ? c.clientWidth : el.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
    return w - railW - sideW - 36;
  }
  // As the two sides are now: the list gives way down to its narrowest by itself (colGrips).
  const splitCap = (el) => SP.cap(splitRoom(el, folded("rail") ? 40 : PJW.l[1][0], folded("side") ? 40 : PJW.r[1][0]));
  const splitBest = (el) => SP.cap(splitRoom(el, 40, 40));               // with both sides folded to their strips
  // Rows that fit in the chat column's height (a short window stacks nothing).
  const splitRows = (el) => { const b = el.querySelector("#pj-body"); return b && b.clientHeight ? SP.capRows(b.clientHeight) : SP.MAXR; };
  // Columns drawn / columns that should be; splitStale: the panes drawn are not the ones that fit now.
  const splitDrawn = (el) => { const s = el.querySelector(".pj-split"); return s ? +s.dataset.n : 1; };
  const splitWant = (el) => { const L = SP && shownCur && SP.load(); return L ? SP.shown(L, splitCap(el)).n : 1; };
  function splitStale(el) {
    const s = el.querySelector(".pj-split"), L = s && SP.load(); if (!L) return false;
    return SP.view(L, splitCap(el), splitRows(el)).panes.map((p) => p.id).join() !== [...s.querySelectorAll(".pj-pane")].map((b) => b.dataset.pane).join();
  }
  // The layout a drop is added to: the saved one, or the single chat on screen.
  // A change always starts from what is on screen: panes the window has no room for right now
  // (kept in the saved layout while it is only looked at) are let go once the person rearranges.
  function splitBase() {
    if (!SP || !shownCur) return null;
    const L = SP.load(), el = splitEl(), ids = el ? [...el.querySelectorAll(".pj-pane")].map((n) => n.dataset.pane) : [];
    if (!L || ids.length < 2) return {panes: [shownCur], w: [1], focus: 0};
    let B = L;
    L.panes.forEach((p) => { if (B && !ids.includes(p.id)) B = SP.remove(B, p.id); });
    return B || {panes: [shownCur], w: [1], focus: 0};
  }
  const splitAt = (p) => "#project/" + enc(p.p) + "/" + enc(p.id);
  // A list row names its session (data-sid) or a project that opens on its current one (data-p).
  function splitRow(row) {
    const box = row.closest(".pj-rail");
    if (row.dataset.sid) return {id: row.dataset.sid, p: row.dataset.pn || (box && box.dataset.pn) || where().name};
    const r = (roomsCache || roomsSeen || []).find((x) => x.name === row.dataset.p);
    return r && r.sid ? {id: r.sid, p: r.name} : null;
  }
  const splitCan = (id) => !!SP && wide() && threeCols() && !!shownCur && SP.indexOf(splitBase(), id) < 0;
  // The most this window can hold: columns with both sides folded, rows by its height.
  const splitFit = (el) => ({c: Math.min(SP.MAXC, splitBest(el)), r: splitRows(el)});
  // Why one more would not fit anywhere, in a line ("" when it does).
  function splitWhy(id) {
    const el = splitEl(), L = splitBase(); if (!el || !L) return "";
    const f = splitFit(el);
    if (SP.indexOf(L, id) >= 0 || SP.add(L, {id}, f.c, f.r) !== L) return "";
    return f.c >= SP.MAXC && f.r >= SP.MAXR ? tl("split.full", {n: SP.MAXC * SP.MAXR}) : f.c * f.r < 2 ? tl("split.none") : tl("split.fit", {n: f.c * f.r});
  }
  // One side of a pane: "" it may land there, "same" it would change nothing, else why not.
  function splitSide(pane, target, side) {
    const el = splitEl(), L = splitBase(); if (!el || !L) return "same";
    const no = SP.can(L, pane.id, target, side), f = splitFit(el), tb = side === "t" || side === "b";
    if (no === "same") return no;
    if (no) return splitWhy(pane.id) || (no === "rows" ? tl("split.maxRows", {n: SP.MAXR}) : tl("split.max", {n: SP.MAXC}));   // no place at all, else this side
    if (tb) return f.r < 2 ? tl("split.short") : "";
    return SP.drop(L, pane, target, side).rows.length <= f.c ? "" : f.c < 2 ? tl("split.none") : tl("split.fit", {n: f.c});
  }
  function pjSplitPlan(el, cur, name) {
    let L = SP && SP.load(); if (!L) return null;
    // A stored layout past 3 x 2 was brought inside it: the panes that found no place are named once.
    if (SP.spilled) { toast(tl("split.spilled", {n: SP.spilled.length})); SP.spilled = null; }
    const N = SP.open(L, {id: cur.id, p: name});
    if (N !== L) SP.save(L = N);
    const v = SP.view(L, splitCap(el), splitRows(el)); if (v.panes.length < 2) return null;
    return {L, from: v.from, cols: v.cols, panes: v.panes};
  }
  function splitDraw(el, sp, name, all, my) {
    SP.ensureCss();
    const body = el.querySelector("#pj-body"), fid = sp.L.panes[sp.L.focus].id, n = sp.cols.length;
    const share = sp.cols.reduce((a, c, j) => a + sp.L.w[sp.from + j], 0) || 1;
    el.querySelector(".pj-cols").classList.add("pj-sp");
    // A pane is its session: the box that already shows it stays (its lines, scroll, caret and
    // loop carry on), wherever the layout puts it. Only a pane that was not there is built, and
    // only that one comes in with motion. The order is the layout's, never the list's.
    let wrap = body.querySelector(":scope>.pj-split");
    if (!wrap) { endRun(body); body.innerHTML = `<div class="pj-split"></div><div data-col="side" id="pj-side"></div>`; wrap = body.firstElementChild; }
    wrap.dataset.n = n;
    const had = {}, seq = sp.cols.map((c) => c.map((p) => p.id).join(",")).join("\n");
    wrap.querySelectorAll(".pj-pane").forEach((b) => { had[b.dataset.pane] = b; });
    const fresh = new Set(), gripping = document.body.classList.contains("gripping");
    const slots = [...wrap.querySelectorAll(".pj-pane")], now = new Set(sp.panes.map((p) => p.id));
    const boxes = sp.panes.map((p, i) => {
      let box = had[p.id]; delete had[p.id];
      // Another session took this pane's place: the frame stays, what is in it is drawn again.
      const prev = !box && !(splitFresh && splitFresh.id === p.id) && slots[i];
      if (prev && !now.has(prev.dataset.pane) && had[prev.dataset.pane] === prev) {
        box = prev; delete had[prev.dataset.pane];
        endRun(box); delete box.dataset.up; box.dataset.pane = p.id; box._swap = true;
        box.classList.remove("in", "l", "r", "t", "b");
      } else if (!box) {
        box = document.createElement("section"); fresh.add(box);
        box.className = "pj-pane" + (splitFresh && splitFresh.id === p.id ? " in " + splitFresh.side : "");
        box.dataset.pane = p.id; box.dataset.multi = "1";
      } else box.classList.remove("in", "l", "r", "t", "b");
      box.classList.toggle("focus", p.id === fid);
      if (box.dataset.up && !box._pjRun) delete box.dataset.up;      // its loop ended: it is drawn again
      const k = box.querySelector(":scope>.pj-conv>.pj-nth .k");
      if (k && k.textContent !== String(i + 1)) { k.textContent = i + 1; k.title = "Ctrl " + (i + 1); }
      return box;
    });
    Object.keys(had).forEach((id) => { endRun(had[id]); had[id].remove(); });
    if (wrap._seq !== seq) {
      wrap._seq = seq;
      wrap.querySelectorAll(".pj-dv,.pj-dh").forEach((d) => d.remove());
      // A column is a plain box around its one or two panes: the panes move between them whole.
      const cols = [...wrap.querySelectorAll(":scope>.pj-col")];
      while (cols.length < n) { const c = document.createElement("div"); c.className = "pj-col"; wrap.appendChild(c); cols.push(c); }
      let k = 0;
      sp.cols.forEach((c, j) => c.forEach((p, r) => { const box = boxes[k++]; if (cols[j].children[r] !== box) mMove(cols[j], box, cols[j].children[r] || null); }));
      cols.splice(n).forEach((c) => c.remove());
      cols.slice(1).forEach((c) => c.insertAdjacentHTML("beforebegin", `<div class="pj-dv" role="separator" aria-orientation="vertical" tabindex="0" aria-label="${esc(tl("split.dv"))}" title="${esc(tl("split.dvTip"))}"></div>`));
      // What the dividers leave is written to the columns (and the stacked pair) they stand between.
      const keep = (set) => { const L = SP.load(); if (L && set(L) !== false) SP.save(L); };
      SP.dividers(wrap, (f) => keep((L) => {
        const at = [...wrap.querySelectorAll(":scope>.pj-col")].map((c) => SP.where(L, c.firstElementChild.dataset.pane)); if (at.some((t) => !t)) return false;
        const sum = at.reduce((a, t) => a + L.w[t.c], 0);
        at.forEach((t, j) => { L.w[t.c] = f[j] * sum; });
      }));
      cols.forEach((c) => {
        if (c.children.length < 2) return;
        c.firstElementChild.insertAdjacentHTML("afterend", `<div class="pj-dh" role="separator" aria-orientation="horizontal" tabindex="0" aria-label="${esc(tl("split.dh"))}" title="${esc(tl("split.dhTip"))}"></div>`);
        SP.dividers(c, (f) => keep((L) => { const t = SP.where(L, c.firstElementChild.dataset.pane); if (!t || SP.rowsOf(L)[t.c] < 2) return false; L.h[t.c] = f[0]; }), true);
      });
    }
    // Each column's share of the width, and the top pane's share of a stacked column.
    if (!gripping || fresh.size) {
      let k = 0;
      sp.cols.forEach((c, j) => {
        const col = boxes[k].parentNode, h = sp.L.h && sp.L.h[sp.from + j] > 0 && sp.L.h[sp.from + j] < 1 ? sp.L.h[sp.from + j] : 0.5;
        col.style.flexGrow = (sp.L.w[sp.from + j] / share * n).toFixed(5);
        c.forEach((p, r) => { boxes[k++].style.flexGrow = c.length < 2 ? "1" : ((r ? 1 - h : h) * 2).toFixed(5); });
      });
    }
    splitFresh = null;
    colGrips(el);                                      // the two sides give the panes their room
    const mount = (box, p, s, k) => {
      if (!live(my) || !box.isConnected || box.dataset.up || box.dataset.pane !== p.id) return;
      box.dataset.up = "1"; box.setAttribute("aria-label", title(s));
      drawSession(box, el, s.project || p.p || name, s, my);
      box.querySelector(".pj-conv").insertAdjacentHTML("afterbegin", `<div class="pj-nth${sessName(s, s.project || p.p || name).includes(pname(s.project || p.p || name)) ? " pn" : ""}"><span class="k" title="Ctrl ${k}" aria-hidden="true">${k}</span><div class="tx"><div class="t" title="${esc(title(s))}">${faceMk(emoOf(s.project || p.p || name), colOf(s.project || p.p || name), icoOf(s.project || p.p || name))}${s.fixed ? pinMk() : ""}${esc(unEm(sessName(s, s.project || p.p || name), emoOf(s.project || p.p || name) || icoHtml(icoOf(s.project || p.p || name))))}</div></div>
        <button class="pj-more pj-px press" data-px aria-label="${esc(tl("room.closePane"))}" title="${esc(tl("split.closeTip"))}">${ic("x")}</button></div>`);
      box.querySelector("[data-px]").onclick = (e) => { e.stopPropagation(); splitLeave(el, p.id); };
      if (box._swap) { box._swap = false; const m = box.querySelector("#pj-msgs"); if (m) m.classList.add("pj-swap"); }
    };
    sp.panes.forEach((p, i) => {
      const box = boxes[i], known = p.p === name && all.find((s) => s.id === p.id), c = convs[p.id];
      if (fresh.has(box)) {
        const on = () => { if (!box.classList.contains("focus")) splitFocus(el, box.dataset.pane); };
        box.addEventListener("pointerdown", on, true); box.addEventListener("focusin", on);
      }
      if (box.dataset.up) return;                      // already showing it
      if (known) return mount(box, p, known, i + 1);
      // A session of another project (or one this list no longer shows): what is remembered of it
      // is drawn at once, and the server is asked whether it still exists. Gone: it leaves the layout.
      if (c && c.state && c.state.id === p.id) mount(box, p, c.state, i + 1);
      else if (!box.firstElementChild) box.innerHTML = `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`;
      get("/api/project/session?id=" + enc(p.id)).then((s) => {
        if (!live(my) || !box.isConnected || box.dataset.pane !== p.id) return;
        if (!s || s.found === false) return splitLeave(el, p.id);
        mount(box, p, Object.assign({}, s, {id: p.id}), i + 1);
      }).catch(() => { /* offline: the pane keeps what it shows */ });
    });
    // Panes there is no room to draw are asked about too, so one that is gone does not come back later.
    sp.L.panes.filter((p) => !sp.panes.includes(p) && !(p.p === name && all.some((s) => s.id === p.id))).forEach((p) =>
      get("/api/project/session?id=" + enc(p.id)).then((s) => { if (s && s.found === false) SP.save(SP.remove(SP.load(), p.id)); }).catch(() => {}));
    splitMarks(el);
  }
  // A pane was pressed or typed in: it is the one the address, the results and the list follow.
  // Nothing is drawn again, so the caret and the scroll of every pane stay where they are.
  function splitFocus(el, id) {
    const L = SP.load(), i = SP.indexOf(L, id); if (i < 0) return;
    const p = L.panes[i];
    el.querySelectorAll(".pj-pane").forEach((n) => n.classList.toggle("focus", n.dataset.pane === id));
    if (L.focus !== i) { L.focus = i; SP.save(L); }
    if (location.hash !== splitAt(p)) history.replaceState(null, "", splitAt(p));
    shownCur = {id, p: p.p}; lastSid = id; seenAt = p.p + "/" + id;
    const c = convs[id], box = el.querySelector("#pj-body>#pj-side");
    if (c && box) { delete box.dataset.strip; side(box, c.room || p.p, c); }
    splitMarks(el);
  }
  // Close a pane (its ✕, Alt W, or a session that no longer exists) and show what is left.
  function splitLeave(el, id) {
    const L = SP.load(); if (!L) return draw(el);
    const N = SP.remove(L, id), keep = N ? N.panes[N.focus] : L.panes.find((p) => p.id !== id);
    SP.save(N);
    if (keep) history.replaceState(null, "", splitAt(keep));
    draw(el);
  }
  // Open `pane` on one side of the pane `target` ("l" | "r" | "t" | "b"), or with no target where
  // there is room (a column right of the focused one, else stacked under it). A place the limits
  // or the window have no room for changes nothing and says why. The list narrows by itself; when
  // that is not enough the results fold to their strip, then the list.
  function splitAdd(pane, target, side) {
    const el = splitEl(), base = splitBase(); if (!el || !base) return;
    const why = target ? splitSide(pane, target, side) : splitWhy(pane.id); if (why) return why === "same" ? null : toast(why);
    const f = splitFit(el), N = target ? SP.drop(base, pane, target, side) : SP.add(base, pane, f.c, f.r);
    if (!N || N === base) return;
    const n = N.rows.length;
    if (splitCap(el) < n) setFold("side", true);
    if (splitCap(el) < n) setFold("rail", true);
    SP.save(N);
    splitFresh = {id: pane.id, side: target ? side : SP.where(N, pane.id).r ? "b" : "r"};
    history.replaceState(null, "", splitAt(pane));
    draw(el);
  }
  // The list shows which rows are open in a pane, and which one is the focused pane.
  function splitMarks(el) {
    const rail = el.querySelector(".pj-rail"); if (!rail || !SP) return;
    // On screen: the panes that are drawn (one the window has no room for is not).
    const L = el.querySelector(".pj-split") ? SP.load() : null, ids = L ? [...el.querySelectorAll(".pj-split .pj-pane")].map((n) => n.dataset.pane) : [], fid = L ? L.panes[L.focus].id : "";
    const seen = new Set();
    rail.querySelectorAll(SP.host.rows).forEach((r) => {
      const p = splitRow(r), inp = !!p && ids.includes(p.id);
      r.classList.toggle("vis", inp);
      if (inp) { r.dataset.vis = "1"; seen.add(p.id); } else delete r.dataset.vis;
      if (!L || !p) return;
      r.classList.toggle("on", p.id === fid);
      if (p.id === fid) r.setAttribute("aria-current", "true"); else r.removeAttribute("aria-current");
    });
    // A pane whose row is not in the list (its project is folded, or shows only its newest few).
    rail.querySelectorAll(".pj-sgrp>.pj-sgl").forEach((h) => {
      const g = h.parentNode.dataset.g;
      h.classList.toggle("vis", !!L && L.panes.some((p) => p.p === g && ids.includes(p.id) && !seen.has(p.id)));
    });
  }
  const sideOf = (body) => body.querySelector("#pj-side") || (body.matches(".pj-pane.focus") ? document.querySelector("#pj-body>#pj-side") : null);
  if (SP) {
    SP.host = {
      rows: ".pj-rail .pj-srow[data-sid],.pj-rail .pj-srow[data-p]",
      ok: () => wide() && threeCols() && !!shownCur && !!splitEl(),
      pick: splitRow,
      find: (pane) => [...document.querySelectorAll(SP.host.rows)].find((r) => { const p = splitRow(r); return p && p.id === pane.id; }) || null,
      targets: () => {
        const el = splitEl(), panes = [...el.querySelectorAll(".pj-pane")];
        if (panes.length) return panes.map((n) => ({el: n, id: n.dataset.pane}));
        const c = el.querySelector("#pj-body>.pj-conv");
        return c && shownCur ? [{el: c, id: shownCur.id}] : [];
      },
      // One side of a pane: {ok} it can land there, {hint} it cannot and why, null it would change nothing.
      check: (pane, target, side) => { const why = splitSide(pane, target, side); return why === "same" ? null : why ? {hint: why} : {ok: true}; },
      drop: splitAdd,
      // Let go outside the app's window: the conversation floats where it was let go (floatwin.py
      // reads the pointer's place itself, in the screen's own pixels).
      out: {
        can: (row) => { const B = window.GenokBar; return !!row.dataset.sid && !phoneList() && !!(B && B.native && B.opts && B.opts.dragout); },
        drop: (row) => {
          const sid = row.dataset.sid, p = splitRow(row);
          post("/api/float/pin", {sid, on: true, open: true, at: "cursor", name: p.p, agent: row.classList.contains("cx") ? "codex" : "claude"})
            .then((r) => { floating = new Set(r.pins || []); toast(r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp")); }, (e) => toast(e.message));
        },
      },
      // The same drag changes a row's place in the list; a project's name carries the project.
      sort: !ORD ? null : {
        rows: ".pj-rail .pj-srows .pj-sgl,.pj-rail .pj-srows .pj-srow[data-sid]",
        can: (row) => { const u = ordUnits(row); return !!u && u.units.length > 1; },
        multi: (row) => ordMany(ordUnits(row)).length,
        start: (row) => {
          let u = ordUnits(row); if (!u) return null;
          const grp = ordMany(u);
          // Picked rows leave the list while they are in the hand; the rest trade places around the grabbed one.
          if (grp.length) u = Object.assign({}, u, {every: u.units.map(u.key), many: grp.map(u.key), fold: grp.filter((x) => x !== u.unit), units: u.units.filter((x) => x === u.unit || !grp.includes(x))});
          // A phone's list scrolls with the page: the page is what moves at the edges, under the bars.
          const st = ORD.start(phoneList() ? Object.assign({}, u, {scroller: document.scrollingElement, over: () => {
            const t = document.getElementById("top"), b = document.getElementById("tabbar");
            return {top: t ? t.getBoundingClientRect().bottom : 0, bottom: b ? b.getBoundingClientRect().top : innerHeight};
          }}) : u);
          if (st) st.u = u; return st;
        },
        move: ORD.move, drop: ORD.drop,
        done: (st) => { const r = ORD.done(st); if (r) ordCommit(st.u, r.from, r.to); },
      },
    };
    // Right click (or the menu key) on a list row: the same way in without a drag.
    document.addEventListener("contextmenu", (e) => {
      if (e.defaultPrevented) return;                  // the row's own menu (rowCtx) opened: 나란히 열기 is in it
      const row = e.target.closest && e.target.closest(SP.host.rows); if (!row || !SP.host.ok()) return;
      const p = splitRow(row); if (!p || !splitCan(p.id)) return;
      e.preventDefault();
      document.querySelectorAll(".pj-pop").forEach((x) => x.remove());
      const pop = document.createElement("div"), why = splitWhy(p.id);
      pop.className = "pj-pop wide";
      pop.innerHTML = `<button class="two" ${why ? `aria-disabled="true"` : ""}><span>${esc(tl("split.open"))}</span><small>${esc(why || tl("split.openSub"))}</small></button>`;
      popAt(pop, row);
      pop.firstChild.onclick = (ev) => { ev.stopPropagation(); if (why) return toast(why); pop.remove(); splitAdd(p, "", ""); };
    });
    // Ctrl 1-6 (Alt 1-6 where the browser keeps Ctrl): that pane, ready to type in. Alt W closes
    // the focused pane. Esc does too, but only when nothing else would take it: not while typing
    // or composing, and not with a menu, a sheet or the search open.
    addEventListener("keydown", (e) => {
      if (!location.hash.startsWith("#project/")) return;
      const el = splitEl(), panes = el ? [...el.querySelectorAll(".pj-pane")] : []; if (panes.length < 2) return;
      const k = e.ctrlKey !== e.altKey && !e.shiftKey && !e.metaKey && /^Digit[1-6]$/.test(e.code || "") ? +e.code.slice(5) : 0;
      if (k) {
        const p = panes[k - 1]; if (!p) return;
        e.preventDefault(); splitFocus(el, p.dataset.pane);
        const ta = p.querySelector("#pj-ta"); if (ta) ta.focus({preventScroll: true});
        return;
      }
      const typing = e.target.matches && e.target.matches("input,textarea,gk-select,[contenteditable]");
      const shut = (e.altKey && !e.ctrlKey && !e.metaKey && e.code === "KeyW") || (e.key === "Escape" && !typing && !e.isComposing && e.keyCode !== 229);
      if (!shut || SP.dragging() || (window.LOOP_LAYER_UP && window.LOOP_LAYER_UP()) || document.querySelector(".pj-pop,#ov.on")) return;
      if (pickOn && e.key === "Escape") return;        // Esc leaves the picking first
      const f = el.querySelector(".pj-pane.focus"); if (!f) return;
      e.preventDefault();
      const L = SP.remove(SP.load(), f.dataset.pane), next = L ? L.panes[L.focus] : panes.map((n) => n.dataset.pane).find((id) => id !== f.dataset.pane);
      const c = convs[L ? next.id : next]; if (c) c.focusDraft = true;      // the keyboard stays in a chat
      splitLeave(el, f.dataset.pane);
    }, true);
  }

