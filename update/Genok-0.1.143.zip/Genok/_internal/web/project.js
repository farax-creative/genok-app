// Project page (P5): a department's sessions, one session's conversation with a chat box,
// its results and open comments beside it, and per-session controls (켜기 · 새로 켜기 · 정리).
//
// Loaded after v2.js, so it reads v2.js's globals (get, esc, ic, nav, toast, ago, RM, wide, D,
// iid, vShort, sheet, closeSheet, copyText) and joins the app as an extension screen through
// window.LOOP_TABS (web/tabs.js). Sub-navigation lives in the hash:
//   #project                 pick a department (a wide window opens the most recent one instead)
//   #project/~all            the pick list itself, also on a wide window
//   #project/<name>/~new     a session not opened yet: the chat is ready, the first line opens it
//   #project/<name>          its session cards
//   #project/<name>/<sid>    one session: conversation | results + open comments
//   #project/~multi/<sid,…>  up to six rooms side by side with one line to all of them (M13)
// Look follows the refern reference: dark neutral panels, UPPERCASE 11px section labels,
// full-width neutral buttons, state line before the action, tiny dots instead of colored fills.
"use strict";
  function ensureCss() {
    if (document.getElementById("pj-style")) return;
    const s = document.createElement("style"); s.id = "pj-style"; s.textContent = PJ_CSS_1 + PJ_CSS_2;
    document.head.appendChild(s);
  }

  const LABEL = LT(() => ({live: tl("pj.st.live"), idle: tl("pj.st.idle"), stale: tl("pj.st.stale"), stuck: tl("pj.st.stuck"), ended: tl("pj.st.ended")}));
  // Outline icons this screen needs that the app set (v2.js, filled) does not have: Phosphor regular.
  const ICO = {panel: ic("sidebar"), moon: ic("moon")};
  // 대기 is a session that just finished a turn; one nobody has touched for two hours is still
  // up (and still costs a slot), which is a different thing to act on: its own word, icon and colour.
  const STALE_MS = 2 * 3600 * 1000;
  const pjKindOf = (st, last) => st === "idle" && last && Date.now() - Date.parse(last) > STALE_MS ? "stale" : (st || "ended");
  const dot = (st) => st === "stale" ? `<span class="pj-ico stale">${ICO.moon}</span>` : `<span class="pj-dot ${st}"></span>`;
  const mark = (st, last) => { const k = pjKindOf(st, last); return dot(k) + `<span class="pj-stl ${k}">${LABEL[k] || k}</span>`; };
  const agentTag = (a) => `<span class="pj-ag ${a === "codex" ? "cx" : "cl"}">${window.agDot(a)}${a === "codex" ? "Codex" : "Claude"}</span>`;
  const enc = encodeURIComponent;
  // What a session is called in the flat list, a chat's head, a pane's head and a float block:
  // the standing session's fixed name, else the name it was given (Claude's custom title, or the
  // app's own title when that is not the first message again), else its project's shown name.
  // What was said (the title the folder view shows) tells same-named sessions apart in the tooltip.
  const sessName = (s, pn) => s.fixed || s.named || pname(pn);
  const title = (s) => s.fixed || (s.title && s.title !== "(제목 없음)" ? s.title : tl("pjx.sessOf", {id: s.id.slice(0, 8)}));
  // A list preview is one line of plain words: the marks of markdown (bold, code, a link's address,
  // a heading or list sign) are dropped, what they wrap is kept.
  const flat1 = (t) => (typeof inlineRuns === "function" ? inlineRuns(String(t || "")).map((r) => r.t === "img" ? "" : r.v).join("") : String(t || ""))
    .replace(/^\s*(?:#{1,6}|>|[-*+]|\d+[.)])\s+/gm, "").replace(/```\w*/g, "").replace(/\s+/g, " ").trim();
  // The inbox stamps a line with a note saying who is speaking; the person typed one sentence.
  // chat-order:begin (pure; tests/chatorder.test.js runs this block on its own)
  const unnote = (t) => String(t || "").replace(/^\[Genok\] 사용자가[^\n]*:\s*/, "").trim();
  // Whether a transcript line is the one I sent. The transcript trims it, may end its lines
  // differently, and cuts a long one short with an ellipsis: none of that makes it another line.
  const lineKey = (t) => unnote(t).replace(/\r\n?/g, "\n").replace(/[ \t]+\n/g, "\n").trim();
  const sameLine = (mine, theirs) => { const a = lineKey(mine), b = lineKey(theirs);
    return a === b || (b.length > 200 && b.endsWith("…") && a.startsWith(b.slice(0, -1))); };
  // Where a line that is not in the transcript yet stands: before the first thing the session
  // wrote after it was sent (-1 = last). `ats` are the timestamps of what the session wrote.
  const pendSlot = (ats, at) => at ? ats.findIndex((t) => Date.parse(t) > at) : -1;
  // chat-order:end

  // ---- dialogs: refern-style rows, one calm primary, quieter secondary --------------------------
  // Resolves with the button's value; a swipe/scrim/Esc dismissal resolves "cancel".
  // Waits a beat first so a sheet that just closed has finished before the next one opens.
  function ask(html, wire) {
    return new Promise((res) => setTimeout(res, 320)).then(() => new Promise((res) => {
      let done = false;
      const fin = (v) => { if (done) return; done = true; clearInterval(t); document.removeEventListener("keydown", key, true); res(v); };
      let first = null;
      // Enter presses the dialog's first (primary) button, unless a field or another button has the focus.
      const key = (e) => {
        if (e.key !== "Enter" || e.isComposing || !first || !first.isConnected || first.disabled) return;
        const a = document.activeElement;
        if (a && a !== first && /^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(a.tagName) && a.closest(".pj-dlg")) return;
        e.preventDefault(); e.stopPropagation(); first.click();
      };
      sheet(`<div class="pj-dlg">${html}</div>`, (box) => {
        box.querySelectorAll("[data-v]").forEach((b) => b.onclick = () => { fin(b.dataset.v); closeSheet(); });
        first = box.querySelector(".acts [data-v]:not([data-v='cancel'])");
        if (wire) wire(box);
      });
      document.addEventListener("keydown", key, true);
      const t = setInterval(() => { const s = document.getElementById("sheet"); if (!s || !s.classList.contains("on")) fin("cancel"); }, 200);
    }));
  }
  // One question, one dim line under it (the text after the first "? "), two buttons side by side.
  // `kind` is given only for a harmless, reversible confirm: it gets "다시 묻지 않기", and once that
  // was ticked the question is skipped. Nothing that deletes or stops passes a kind.
  const confirmDlg = (msg, go, kind, danger, m = /^(.*?\?)\s+(\S.*)$/s.exec(msg || "")) => kind && noAsk()[kind] ? Promise.resolve("ok") : ask(
    `<div class="cf"><h3>${esc(m ? m[1] : msg)}</h3>${m ? `<p class="cf-sub">${esc(m[2])}</p>` : ""}
     ${kind ? `<label class="cf-never"><input type="checkbox" id="cf-never">${tl("noask.box")}</label>` : ""}
     <div class="acts cf-acts"><button class="pj-btn ${danger ? "danger" : "light"} full press" data-v="ok">${esc(go || tl("pjx.go"))}</button>
     <button class="pj-btn full press" data-v="cancel">${tl("libDraw.22")}</button></div></div>`, (box) => {
      const ok = box.querySelector("[data-v='ok']"), was = ok.onclick;
      ok.onclick = () => { const c = box.querySelector("#cf-never"); if (kind && c && c.checked) noAskSet(kind); was(); };
    });
  // The app's shared consent dialog (web/consent.js) answers every {need_consent} / 428.
  // "cancelled" is thrown on a decline so callers stay quiet.
  // A server that wants more than one "are you sure" answers {need_confirm: <level>, what, go};
  // the level goes back as body.confirm until it stops asking (stop asks twice).
  // `tick(true|false)`: the request is out / a question is on the screen (the busy mark follows it).
  async function act(path, body, depth, tick) {
    if (tick) tick(true);
    const j = await loopFetch(path, {method: "POST", json: body || {}});
    if (j.declined) throw new Error("cancelled");
    if (j.need_confirm && (depth || 0) < 4) {
      if (tick) tick(false);
      if ((await confirmDlg(srvT(j.what) || tl("pjx.goAsk"), srvT(j.go), undefined, true)) !== "ok") throw new Error("cancelled");
      return act(path, Object.assign({}, body, {confirm: Number(j.need_confirm) || 1}), (depth || 0) + 1, tick);
    }
    return j;
  }
  const infoDlg = (msg) => ask(`<div class="cf"><h3>${esc(msg)}</h3><div class="acts cf-acts"><button class="pj-btn light full press" data-v="ok">${tl("pjx.ok")}</button></div></div>`);
  // A GET that may need consent; returns the {need_consent, declined} body if declined.
  const readOrAsk = (path) => loopFetch(path);

  // ---- routing + per-screen state ---------------------------------------------------------------
  function where() {
    let raw = location.hash.slice(1); try { raw = decodeURIComponent(raw); } catch (e) {}
    const seg = raw.split("/");
    return {name: seg[1] || "", sid: seg[2] || ""};
  }
  const deptMore = new Set();                          // projects whose fold of older sessions is unfolded (the list, beside the chat)
  let gen = 0, tab = "conv", listOpen = false, showTidied = "", showPast = false, showOld = false, lastSid = "";
  const timers = new Set();
  const convs = {};                                   // sid -> {entries, offset, results, queued, draft, pend, state}
  const aborts = new Set();                          // open long-polls, cut when the page changes
  // A chat's own loops (start) belong to the box it is drawn in: they go on while that box shows
  // that chat, across redraws of the page around it, and end when the box is gone or shows another.
  const runs = new Set();                            // {body, ac}
  // The box's loop ends. Only the loop: start() calls this for the box drawSession just wired,
  // and taking the press listener with it left every button in the chat dead (0.1.67).
  const endLoop = (body) => { const r = body && body._pjRun; if (!r) return; r.ac.abort(); runs.delete(r); body._pjRun = null; };
  // The box is about to show something else: its loop ends, and so does what a press in it did.
  const endRun = (body) => {
    if (body && body._pjClick) { body.removeEventListener("click", body._pjClick); body._pjClick = null; }
    endLoop(body);
  };
  const pjStop = (all) => { timers.forEach(clearTimeout); timers.clear(); aborts.forEach((a) => a.abort()); aborts.clear();
    runs.forEach((r) => { if (all || !r.body.isConnected || r.body._pjRun !== r) { r.ac.abort(); runs.delete(r); } }); };

  // ---- keep what is on screen -------------------------------------------------------------------
  // A redraw makes the page like its new html and keeps the nodes that are there: a row stays the
  // same element (its hover, its focus, the list's scroll), only what changed in it is written.
  // Rows are matched by their session, groups by their project, the rest by place and kind.
  // The list and the chat are drawn by their own code (MKEEP): only their attributes follow.
  const MKEEP = ".pj-rail,#pj-body";
  const mKey = (n) => n.nodeType !== 1 ? "" : n.dataset.sid ? "s:" + n.dataset.sid : n.dataset.g ? "g:" + n.dataset.g : n.dataset.grip ? "grip:" + n.dataset.grip
    : n.id ? "#" + n.id : n.classList.contains("pj-rail") ? "rail" : n.classList.contains("pj-cols") ? "cols" : "";
  const mBar = (n) => n.nodeType === 1 && n.classList.contains("pj-rbar");   // put there by readBar, not by the html
  function mPool(root) {
    const pool = new Map();
    const walk = (n) => [...n.children].forEach((c) => { const k = mKey(c); if (k && !pool.has(k)) pool.set(k, c); if (!c.matches(MKEEP) && !c.nodeName.includes("-")) walk(c); });
    walk(root); return pool;
  }
  // Move a node without losing what it holds: its scroll positions, and (moveBefore) its hover and animations.
  function mMove(parent, n, before) {
    if (n.parentNode === parent && n.nextSibling === before) return;
    if (parent.moveBefore && n.isConnected && parent.isConnected) { try { parent.moveBefore(n, before); return; } catch (e) { /* not movable that way */ } }
    const sc = n.nodeType === 1 ? [...n.querySelectorAll(".pj-msgs")].map((m) => [m, m.scrollTop]) : [];
    parent.insertBefore(n, before);
    sc.forEach(([m, y]) => { m.scrollTop = y; });
  }
  const mData = (n) => [...n.attributes].map((x) => x.name).filter((x) => x.startsWith("data-")).join();
  function morph(a, b, pool) {
    const own = a.classList.contains("pj-cols");     // its classes and widths are set while the page settles
    if (mData(a) !== mData(b)) a.onclick = a.onkeydown = a.oninput = null;   // another button now: its old press is not kept
    [...a.attributes].forEach((x) => { if (!b.hasAttribute(x.name) && !(own && (x.name === "style" || x.name === "class"))) a.removeAttribute(x.name); });
    [...b.attributes].forEach((x) => { if (own && (x.name === "style" || x.name === "class")) return; if (a.getAttribute(x.name) !== x.value) a.setAttribute(x.name, x.value); });
    if (a.matches(MKEEP) || a.nodeName.includes("-")) return;
    morphKids(a, b, pool);
  }
  // keep:begin
  // The longest run of kept children that are already in their new order: these never move, the
  // others are carried to their place (one row that changed its place moves alone).
  function mStay(ms, olds) {
    const at = new Map(olds.map((n, i) => [n, i])), seq = ms.filter((m) => m && at.has(m)), tails = [], prev = [];
    seq.forEach((m, j) => {
      const v = at.get(m); let lo = 0, hi = tails.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (at.get(seq[tails[mid]]) < v) lo = mid + 1; else hi = mid; }
      prev[j] = lo ? tails[lo - 1] : -1; tails[lo] = j;
    });
    const stay = new Set();
    for (let j = tails.length ? tails[tails.length - 1] : -1; j >= 0; j = prev[j]) stay.add(seq[j]);
    return stay;
  }
  // keep:end
  function morphKids(a, b, pool) {
    const olds = [...a.childNodes], used = new Set(), news = [...b.childNodes]; let i = 0;
    const cur = () => { while (i < olds.length && (olds[i].parentNode !== a || used.has(olds[i]) || mBar(olds[i]))) i++; return olds[i] || null; };
    const fit = (x, y) => x.nodeType === y.nodeType && x.nodeName === y.nodeName && (x.nodeType !== 1 || (!mKey(x) && (x.classList[0] || "") === (y.classList[0] || "")));
    const ms = news.map((nb) => { const k = mKey(nb); if (!k) return null; let m = pool.get(k) || null; if (m && m.nodeName !== nb.nodeName) m = null; if (m) pool.delete(k); return m; });
    const stay = mStay(ms.filter((m) => m && m.parentNode === a), olds);
    news.forEach((nb, j) => {
      let at = cur(), m = ms[j];
      if (m && stay.has(m)) while (at && at !== m) { i++; at = cur(); }      // what stood before it goes later, or goes away
      if (!m && !mKey(nb) && at) {
        if (fit(at, nb)) m = at;
        else if (nb.nodeType === 1 && nb.classList.length) {
          // Something left from before it (a row of chips that is gone): the box that is still wanted is further on.
          const o = olds.slice(i + 1).find((x) => x.parentNode === a && !used.has(x) && !mBar(x) && x.nodeType === 1 && fit(x, nb));
          if (o) { while (at && at !== o) { i++; at = cur(); } m = o; }
        }
      }
      if (!m) {
        // A new box around rows that are on screen: the box is new, the rows in it are the same ones.
        if (nb.nodeType === 1 && !mKey(nb) && !nb.matches(MKEEP) && !nb.nodeName.includes("-") && nb.querySelector("[data-sid],[data-g]")) {
          const sh = nb.cloneNode(false); a.insertBefore(sh, at); return void morphKids(sh, nb, pool);
        }
        return void a.insertBefore(nb, at);
      }
      used.add(m);
      if (m !== at) mMove(a, m, at);
      if (nb.nodeType === 1) morph(m, nb, pool); else if (m.nodeValue !== nb.nodeValue) m.nodeValue = nb.nodeValue;
    });
    olds.forEach((n) => { if (n.parentNode === a && !used.has(n) && !mBar(n)) a.removeChild(n); });
  }
  pjStop.sweep = () => runs.forEach((r) => { if (!r.body.isConnected || r.body._pjRun !== r) { r.ac.abort(); runs.delete(r); } });
  const morphTo = (root, html) => { const t = root.cloneNode(false); t.innerHTML = html; morphKids(root, t, mPool(root)); };
  // An embedded pane (pjEmbed, the item screen's chat tab) lives as long as its element does.
  const live = (my) => my && my.embed ? my.embed.isConnected : my === gen && location.hash.startsWith("#project");

  async function draw(el) {
    if (el && el._pjEmbed) return el._pjEmbed().catch(() => null);      // an embedded pane redraws itself, not the room screen (a failed read keeps what is shown)
    if (ORD && ORD.live()) return ORD.later(() => draw(el));   // a row is in the hand: the list waits for it to land
    if (SW && SW.live()) return SW.later(() => draw(el));      // so does a row or a chat pulled sideways (web/swipe.js)
    ensureCss(); pjStop();
    if (!el.classList.contains("pj") || !el.querySelector(".pj-cols")) shownCur = null;   // side by side: set again once a chat is drawn
    const my = ++gen, {name, sid} = where();
    if (lastSid && lastSid !== sid && convs[lastSid]) convs[lastSid].divTs = undefined;   // next visit re-reads the marker
    lastSid = sid;
    // Scope our padding/overflow to a wrapper: #view is shared with every other screen.
    if (!el.classList.contains("pj")) { const w = document.createElement("div"); w.className = "pj"; el.appendChild(w); el = w; }
    if (!name || name === ALL) return drawPick(el, my, name === ALL);
    // A phone shows one chat at a time: a side-by-side address opens its first project alone.
    if (name === MULTI && phoneList()) return location.replace("#project/" + enc(sid.split(",")[0] || ""));
    if (name === MULTI) return drawMulti(el, sid.split(","), my);
    listAt = false;
    return drawProject(el, name, sid, my);
  }

  // ---- #project: pick a department (M13: the hub's room list) ---------------------------------
  // The pick screen is the hub's room list: every department with its current session (its pin,
  // else a live one, else the newest), the last line said, and how many replies are unread.
  let topPins = new Set();
  const topPinned = (s) => topPins.has(s.id || s.sid);
  const topOrder = (list) => list.slice().sort((a, b) => Number(topPinned(b)) - Number(topPinned(a)));
  let roomsCache = null, roomQ = "", bgOpen = false, mFocus = 0;
  let roomsFirst = null;                                             // the folders' first read, running beside a chat's
  // A first read that failed: what went wrong and one way to ask again (it was a dead end: only
  // leaving the screen and coming back read it again).
  const failed = (el, e) => { el.innerHTML = `<div class="pj-empty pj-fail"><div>${esc(e.message)}</div><button class="pj-btn press" data-retry>${tl("upd.retry")}</button></div>`;
    el.querySelector("[data-retry]").onclick = () => render(); };
  let roomsSeen = null, bundSeen = [], groupsSeen = [];               // the last list we showed: painted first, then refreshed
  // Panels folded by the person (wide screens), kept on this device.
  // Without the three columns (threeCols()) there are none to fold: the same two choices are the session list toggle
  // ("list", stored when open) and the 대화 / 결과물 tab ("tab", stored when on 결과물).
  // dense = the list in one-line rows, rdense = the results as small rows. side starts folded: it is
  // open only once the person opened it ("0"), so its key is written both ways.
  const FOLD = {rail: "rl-pj-rail", side: "rl-pj-side", list: "rl-pj-list", tab: "rl-pj-tab", dense: "rl-pj-dense", rdense: "rl-pj-rdense", more: "rl-pj-more"};
  // `dense` (one-line rows in the chat list) is on until 크게 is chosen; `side` likewise until it is opened.
  const folded = (k) => { const dflt = k === "side"; try { const v = localStorage.getItem(FOLD[k]); return dflt ? v !== "0" : v === "1"; } catch (e) { return dflt; } };
  const setFold = (k, on) => { try { on ? localStorage.setItem(FOLD[k], "1") : k === "side" ? localStorage.setItem(FOLD[k], "0") : localStorage.removeItem(FOLD[k]); } catch (e) { /* this visit only */ } };
  // A result not looked at yet = its item still carries the app's own 새 버전 mark (D.items[].new,
  // cleared by opening the item: /api/seen), unless this session's results were already looked
  // through here with the panel open. That second half is kept on this device, per session:
  // {sid: {"project/item": version seen in the panel}}, the 60 sessions used last.
  const RSEEN = "rl-pj-rseen", rkey = (r) => r.project + "/" + r.item;
  const rseen = () => { try { return JSON.parse(localStorage.getItem(RSEEN) || "{}") || {}; } catch (e) { return {}; } };
  const unseenRes = (sid, res) => { const m = rseen()[sid] || {};
    return res.filter((r) => { let it = null; try { it = (D.items || []).find((x) => iid(x) === rkey(r)); } catch (e) { /* items not loaded yet */ }
      return !!(it && it.new) && m[rkey(r)] !== r.v; }).length; };
  const seeRes = (sid, res) => { try { const all = rseen(), m = {}; res.forEach((r) => { m[rkey(r)] = r.v; });
    delete all[sid]; all[sid] = m; const ks = Object.keys(all); while (ks.length > 60) delete all[ks.shift()];
    localStorage.setItem(RSEEN, JSON.stringify(all)); } catch (e) { /* this visit only */ } };
  listOpen = folded("list");
  const MULTI = "~multi", MAXP = 6, ALL = "~all", NEW = "~new";
  // The pick list's address: on a wide window #project itself opens the most recent room.
  const listHash = () => wide() ? "project/" + ALL : "project";
  // What the room list left out: ended sessions this app did not open. `only` counts the ones in
  // folders that hold nothing else (those folders are not listed); oldRooms is those folders, read
  // when the fold is opened.
  let oldInfo = {only: 0}, oldRooms = null, roomsAt = 0;
  let seenAt = "";                                    // the chat last drawn (project/session)
  const turnHeld = new Set();                         // rows the 내 차례 tab keeps while it is open
  let sessQ = "", sessF = "all";                      // the list's search words and filter (all | turn | busy)
  // Claude | Codex: which tool's sessions the list shows (all | claude | codex). Kept on this device.
  const AG_KEY = "rl-pj-agent", AGS = ["all", "claude", "codex"];
  let sessA = (() => { try { const v = localStorage.getItem(AG_KEY); return AGS.includes(v) ? v : "all"; } catch (e) { return "all"; } })();
  const setAgent = (v) => { sessA = AGS.includes(v) ? v : "all"; try { localStorage.setItem(AG_KEY, sessA); } catch (e) { /* this visit only */ } };
  // How the list beside the chat is laid out, kept on this device: "flat" = every session by its
  // title, newest first (what a device that never chose gets); "folder" = sessions under their
  // project. A device whose storage is closed keeps the choice for this visit.
  const VIEW_KEY = "rl-pj-view", GFOLD_KEY = "rl-pj-gfold";
  let viewNow = "", gfoldNow = null;
  const dupOpen = new Set();                           // lead rows (by key) whose same-titled older sessions are unfolded
  let dupSids = [];                                  // older sessions sharing a title with a newer one, as the list last drew them
  // A row's sid -> the older same-titled sessions standing folded behind it, as the list last drew
  // them. Hiding the row hides these too: left behind, the next one came up under the same title
  // and the row looked as if it had never gone.
  let dupUnder = new Map();
  const withTwins = (sids) => [...new Set([].concat(...sids.map((id) => [id].concat(dupUnder.get(id) || []))))];
  const byRecent = () => { try { return localStorage.getItem("loop.sess.recent") === "1"; } catch (e) { return false; } };
  const setRecent = (on) => { try { localStorage.setItem("loop.sess.recent", on ? "1" : "0"); } catch (e) { /* this visit only */ } };
  // Chats stand under their folder unless the person chose the flat list.
  const VIEWS = ["folder", "flat", "proj"];
  const listView = () => { if (viewNow) return viewNow; try { const v = localStorage.getItem(VIEW_KEY); return VIEWS.includes(v) ? v : "folder"; } catch (e) { return "folder"; } };
  // 묶음별: folders that share a group stand as one list, wherever they are on the disk. The group
  // is the folder's own (the register's), or the one the person put it in here: kept in this app
  // only (GRP_KEY, folder name -> group), nothing on the disk or in the register is touched.
  const GRP_KEY = "rl-pj-grp";
  let grpNow = null;
  const grpMap = () => { if (!grpNow) { try { const m = JSON.parse(localStorage.getItem(GRP_KEY) || "{}"); grpNow = m && typeof m === "object" && !Array.isArray(m) ? m : {}; } catch (e) { grpNow = {}; } } return grpNow; };
  const grpOf = (r) => { const m = grpMap(); return typeof m[r.name] === "string" ? m[r.name] : r.group || ""; };
  const setGrp = (name, g) => { const m = grpMap(); if (g == null) delete m[name]; else m[name] = String(g).trim().slice(0, 40); try { localStorage.setItem(GRP_KEY, JSON.stringify(m)); } catch (e) { /* this visit only */ } };
  let projTag = null;                                // while 묶음별 draws a group: the group's shown name
  const setView = (v) => { viewNow = VIEWS.includes(v) ? v : "flat"; try { localStorage.setItem(VIEW_KEY, viewNow); } catch (e) { /* this visit only */ } };
  // The projects folded shut in 폴더별 (by name).
  const gfold = () => { if (!gfoldNow) { try { gfoldNow = new Set(JSON.parse(localStorage.getItem(GFOLD_KEY) || "[]")); } catch (e) { gfoldNow = new Set(); } } return gfoldNow; };
  const setGfold = (name, shut) => { const g = gfold(); shut ? g.add(name) : g.delete(name); try { localStorage.setItem(GFOLD_KEY, JSON.stringify([...g].slice(-200))); } catch (e) { /* this visit only */ } };
  const railPops = {};                                // the header's open menus, by name
  const railRows = new Map();                         // session id -> {s, name}: what a row's menu acts on
  let ctxAt = null;                                   // {x, y, row, kb, label}: the next menu opens at this point (popAt takes it)
  // The list's order (web/listorder.js): what the person placed, kept on the server for the PC and
  // the phone alike. `ordKeys` is every key of each list as last drawn, shown or folded away.
  const ORD = window.PjOrder;
  const SW = window.PjSwipe;                          // a phone's sideways gestures (web/swipe.js)
  let listOrd = {depts: [], sess: {}, flat: []}, ordSaving = 0, ordAt = -1, railNow = null;
  const ordKeys = {depts: [], sess: {}, flat: []};
  // A phone has one list: every session. Until the person has placed one by hand (a long press, then
  // carrying it, the same order the desktop keeps: listOrd.flat) the one that last had something
  // happen is on top; from then on the list is fixed like the desktop's, what is made later stacking
  // on top. The 폴더별 / 크게 choices (the desktop's, kept as saved) are not offered. While a finger
  // is on the screen or the list is still scrolling, and for a second after, the order shown stands;
  // it is caught up afterwards.
  const phoneList = () => innerWidth < 1024 && matchMedia("(pointer:coarse)").matches;
  let phoneOrd = null, phoneTouch = false, phoneAt = -1e9, phoneT = 0;
  const phoneHeld = () => phoneTouch || performance.now() - phoneAt < 1000;
  const phoneLater = () => { clearTimeout(phoneT); phoneT = setTimeout(() => { if (phoneHeld()) return phoneLater(); if (railNow && phoneList()) railNow(); }, 1050); };
  addEventListener("touchstart", () => { phoneTouch = true; }, {capture: true, passive: true});
  ["touchend", "touchcancel"].forEach((t) => addEventListener(t, (e) => { phoneTouch = e.touches.length > 0; phoneAt = performance.now(); }, {capture: true, passive: true}));
  addEventListener("scroll", () => { phoneAt = performance.now(); }, {capture: true, passive: true});
  function phoneOrder(L, keyOf) {
    const at = (o) => String(o.at || o.born || "");
    const fresh = L.slice().sort((a, b) => !!b.draft - !!a.draft || at(b).localeCompare(at(a)));
    if (!phoneOrd || !phoneHeld()) { phoneOrd = fresh.map(keyOf); return fresh; }
    const was = new Map(phoneOrd.map((k, i) => [k, i])), i = (o) => was.has(keyOf(o)) ? was.get(keyOf(o)) : -1;
    const out = fresh.sort((a, b) => i(a) - i(b));
    if (out.some((o, j) => keyOf(o) !== phoneOrd[j])) phoneOrd = out.map(keyOf);
    phoneLater();
    return out;
  }
  const ordPlaced = () => listOrd.depts.length + listOrd.flat.length + Object.keys(listOrd.sess).length > 0;
  function ordSave(order) {
    ordSaving++;
    post("/api/project/order", {order}).then((r) => { if (ordSaving === 1 && r && r.order) listOrd = r.order; })
      .catch((e) => toast(e.message)).finally(() => { ordSaving--; ordAt = performance.now(); });
  }
  // The order a list read brought is taken unless it was asked for before the last save had
  // landed: that answer still holds the order from before the drop and put the row back.
  const ordFresh = (t0) => !ordSaving && t0 > ordAt;
  // The rows that can trade places with `row`: the sessions of its project (폴더별), every session
  // (세션), or the projects themselves for a project's name and a project shown as one row.
  function ordUnits(row) {
    const box = row.closest(".pj-rail"), rows = box && box.querySelector(".pj-srows");
    // Not the rows that stand outside the order: the old ones, the open one shown apart, and a
    // same-titled twin unfolded under its newest (it always stands right under it).
    if (!rows || !rows.contains(row) || row.closest(".pj-olds,.pj-apart,.pj-pgrp") || row.classList.contains("tw")) return null;
    const grp = row.closest(".pj-sgrp"), sess = row.matches(".pj-srow[data-sid]");
    // Pinned sessions are held on top (topOrder), so a row trades places on its own side of the
    // pins only (PjOrder.peers); with newest-first on nothing is held, and placing a row ends it (ordCommit).
    const side = (L) => { const us = L.filter((u) => !u.closest(".pj-olds,.pj-apart") && !u.classList.contains("tw")); if (byRecent()) return us;
      const ks = new Set(ORD.peers(us.map((u) => u.dataset.sid), row.dataset.sid, (k) => topPins.has(k))); return us.filter((u) => ks.has(u.dataset.sid)); };
    if (!grp) return sess ? {box, unit: row, units: side([...rows.querySelectorAll(".pj-srow[data-sid]")]), scope: "flat", key: (u) => u.dataset.sid} : null;
    if (sess && grp.querySelector(".pj-sgl")) return {box, unit: row, units: side([...grp.querySelectorAll(".pj-srow[data-sid]")]), scope: "sess", name: row.dataset.pn, key: (u) => u.dataset.sid};
    return grp.dataset.g ? {box, unit: grp, units: [...rows.querySelectorAll(".pj-sgrp[data-g]")], scope: "depts", key: (u) => u.dataset.g} : null;
  }
  // The unit at `from` now stands where the one at `to` stood: said relative to that neighbour, so
  // rows folded away or filtered out keep their places around it.
  // The picked rows that go with `u.unit` when it is in the hand (it is one of them; two or more
  // sessions of this list), else none. A project's name carries no picked rows.
  function ordMany(u) {
    if (!u || !pickOn || u.scope === "depts" || !picked.has(u.key(u.unit))) return [];
    const g = u.units.filter((x) => picked.has(u.key(x)));
    return g.length > 1 && u.units.length > g.length ? g : [];
  }
  function ordCommit(u, from, to) {
    // Newest-first lets the clock order the rows, so a row put somewhere went straight back. Placing
    // one by hand ends it: the list is kept as it stood on the screen, with the row where it was put.
    if (byRecent()) {
      listOrd = u.scope === "flat" ? Object.assign({}, listOrd, {flat: ordKeys.flat.slice()}) : Object.assign({}, listOrd, {depts: ordKeys.depts.slice(), sess: Object.assign({}, ordKeys.sess)});
      setRecent(false); toast(tl("ord.fixedNow"));
    }
    const keys = u.units.map(u.key), full = u.scope === "sess" ? ordKeys.sess[u.name] || keys : ordKeys[u.scope];
    // Picked rows move together: the grabbed one lands where it would have alone, the others follow it.
    const base = full.length ? full : u.every || keys;
    const ri = base.indexOf(keys[to]);
    const next = u.many ? (ri < 0 ? base.slice() : ORD.movedMany(base, u.many, ri + (to > from ? 1 : 0)))
      : ORD.moved(base, keys[from], keys[to], to > from);
    if (u.scope === "sess") listOrd = Object.assign({}, listOrd, {sess: Object.assign({}, listOrd.sess, {[u.name]: next})});
    else listOrd = Object.assign({}, listOrd, {[u.scope]: next});
    ordSave(listOrd);
    if (!RM()) u.box._ms = "";                        // already where it landed: nothing to carry there
    if (railNow && u.box.isConnected) railNow();
  }
  // 한 번 정렬: the list is put in that order once and kept as the person's own order. It is not
  // a mode: nothing sorts again afterwards, and what is made later still lands on top.
  let ordLast = null;                                 // {list, groups, every}: the rows of the last drawn list
  function ordOnce(kind) {
    const L = ordLast; if (!L || phoneList()) return false;
    const txt = (a, b) => String(a).localeCompare(String(b), "ko"), late = (a, b) => String(b.at || "").localeCompare(String(a.at || ""));
    const ids = (rows) => rows.filter((o) => o.sid).sort(kind === "name" ? (a, b) => txt(a.t, b.t) : late).map((o) => o.sid);
    const sess = {}; L.groups.forEach((g) => { const k = ids(g.all); if (k.length) sess[g.r.name] = k; });
    // A project is as recent as its most recent session, not only the one it opens on.
    const gAt = new Map(L.groups.map((g) => [g.r.name, g.all.reduce((m, o) => String(o.at || "") > m ? String(o.at) : m, String(g.r.at || ""))]));
    listOrd = {depts: L.list.slice().sort(kind === "name" ? (a, b) => txt(pname(a.name), pname(b.name)) : (a, b) => (gAt.get(b.name) || "").localeCompare(gAt.get(a.name) || "")).map((r) => r.name), sess, flat: ids(L.every)};
    ordSave(listOrd);
    return true;
  }
  // 위로 이동 / 아래로 이동 from a menu: one place, among the rows on the screen.
  function ordStep(row, by) {
    const u = row && row.isConnected && ordUnits(row); if (!u) return;
    const i = u.units.indexOf(u.unit), j = i + by; if (i < 0 || j < 0 || j >= u.units.length) return;
    const k = u.key(u.unit), box = u.box;
    ordCommit(u, i, j);
    const n = [...box.querySelectorAll(u.scope === "depts" ? ".pj-sgrp[data-g]" : ".pj-srow[data-sid]")].find((x) => u.key(x) === k);
    const f = n && (n.matches(".pj-srow") ? n : n.querySelector(".pj-sgh,.pj-srow"));
    if (f) { f.focus({preventScroll: true}); f.scrollIntoView({block: "nearest"}); }
  }
  const ordItems = (row) => { const u = row && ordUnits(row); if (!u || u.units.length < 2) return "";
    const i = u.units.indexOf(u.unit), b = (d, off) => `<button data-mv="${d}"${off ? ` aria-disabled="true"` : ""}>${ic("chev", d < 0 ? "i up" : "i dn")}<span>${d < 0 ? tl("ord.up") : tl("ord.down")}</span></button>`;
    return b(-1, i <= 0) + b(1, i >= u.units.length - 1); };
  // 더 보기 in a row's menu: the rare choices unfold in place (a phone has no room for a second
  // menu beside the first), and the menu stays inside the window as it grows.
  const moreRow = (inner) => inner ? `<hr><button data-mx aria-expanded="false">${ic("more")}<span>${tl("mn.more")}</span>${ic("chev", "i cv")}</button><div class="mx" hidden>${inner}</div>` : "";
  const moreWire = (pop) => { const b = pop.querySelector("[data-mx]"), x = pop.querySelector(".mx"); if (!b) return;
    b.onclick = (e) => { e.stopPropagation(); const on = x.hidden; x.hidden = !on; b.setAttribute("aria-expanded", String(on));
      pop.style.top = Math.max(8, Math.min(parseFloat(pop.style.top) || 8, innerHeight - 8 - pop.offsetHeight)) + "px";
      if (on && b === document.activeElement) { const f = x.querySelector("button"); if (f) f.focus({preventScroll: true}); } }; };
  const ordWire = (pop, row) => pop.querySelectorAll("[data-mv]").forEach((b) => b.onclick = (e) => { e.stopPropagation();
    if (b.getAttribute("aria-disabled")) return; pop.remove(); ordStep(row, +b.dataset.mv); });
  const draftModel = {};                              // project -> {model, effort} picked for the session not opened yet
  const draftAgent = {};   // Claude or Codex picked on the new-session draft, per department
  const drafts = {};                                  // project -> what was typed for a session not opened yet
  // A new-session draft is only a screen (nothing exists on disk), so hiding one forgets what it
  // holds and takes its row out of the list; 새 세션 brings it back. An empty draft left by opening
  // another session is gone with the route, so none piles up. `dropDraft` returns what to restore.
  // draft-hide:begin
  const draftGone = new Set();
  function dropDraft(name) {
    const was = {text: drafts[name], agent: draftAgent[name], m: draftModel[name], mc: draftModel["codex\n" + name]};
    delete drafts[name]; delete draftAgent[name]; delete draftModel[name]; delete draftModel["codex\n" + name];
    draftGone.add(name);
    return was;
  }
  function backDraft(name, was) {
    draftGone.delete(name);
    if (was.text) drafts[name] = was.text;
    if (was.agent) draftAgent[name] = was.agent;
    if (was.m) draftModel[name] = was.m;
    if (was.mc) draftModel["codex\n" + name] = was.mc;
  }
  // Which rows the list holds comes from the data and the filter only, never from which row is open:
  // a hidden session is listed only while 숨긴 세션 is on. One that is open anyway (opened from a link)
  // is shown apart (openApart), so opening a row never adds or removes a row.
  const listed = (s, showAll) => showAll || !s.tidied;
  // The hidden sessions are shown only in the project they were opened in, and only until the
  // next hide: kept on across projects, sessions put away came back everywhere.
  const tidOn = () => !!showTidied && showTidied === where().name;
  // draft-hide:end
  // Search that forgives how a name was typed: case, spaces / _ / -, and the look-alikes O-0 and
  // l-I-1 ("A20" finds "A2O"). Used by the room list and the 새 대화 picker alike.
  const foldQ = (s) => String(s || "").toLowerCase().replace(/[\s_\-]+/g, "").replace(/o/g, "0").replace(/[li|]/g, "1");
  // Both names find it: the one the screens show and the one the register keeps (a group too).
  const hay = (r) => foldQ(r.name + " " + pname(r.name) + " " + String(r.folder || "").split(/[\\/]/).slice(-2).join(" ") + " " + (r.group || "") + " " + gpname(r.group || ""));
  // One glyph per project. A joined emoji this machine cannot join draws as two or three side by
  // side and pushes the name out of line, so that one falls back to its first part (measured once).
  const emSeen = {};
  let emCtx = null;
  function em1(e) {
    e = String(e || "");
    if (e.indexOf("‍") < 0) return e;
    if (!(e in emSeen)) {
      emSeen[e] = e;
      try {
        emCtx = emCtx || document.createElement("canvas").getContext("2d");
        emCtx.font = "18px " + getComputedStyle(document.body).fontFamily;
        if (emCtx.measureText(e).width > emCtx.measureText("\u{1F642}").width * 1.4) emSeen[e] = e.split("‍")[0];
      } catch (x) { /* no canvas: leave it as written */ }
    }
    return emSeen[e];
  }
  // c: the colour the person picked for it (a soft tile behind the picture); none, as before.
  // i: an icon in a style other than emoji ("duotone/rocket", web/icons.js), drawn in place of
  // the emoji; a build or a device that does not know the icon shows the emoji, as before.
  const icoHtml = (i) => (i && window.LOOP_ICONS && window.LOOP_ICONS.html(i)) || "";
  // A project's face beside a title (a list row, a pane's head): the styled icon or the emoji at
  // text size, no tile behind it. Nothing when the project has neither. Bold and fill carry more
  // ink than the title beside them, so they are drawn a little smaller (`hv`).
  const faceMk = (e, c, i) => { const h = icoHtml(i); return h || e ? `<span class="pj-face${h ? " ph" + (/^(bold|fill)\//.test(i) ? " hv" : "") : ""}${tintAttr(c) ? " tint" : ""}"${tintAttr(c)} aria-hidden="true">${h || esc(em1(e))}</span>` : ""; };
  // The title beside a face: the emoji the title opens with is not said twice (web/emoji.js bare).
  // `face`: a face is drawn there. Labels, tooltips and the search keep the name as it is.
  const unEm = (t, face) => face && window.LOOP_EMOJI && window.LOOP_EMOJI.bare ? window.LOOP_EMOJI.bare(t) : t;
  const emAs = (cls, e, c, i) => { const h = icoHtml(i); return `<span class="${cls}${h ? " ph" : ""}${tintAttr(c) ? " tint" : ""}"${tintAttr(c)}>${h || esc(em1(e))}</span>`; };
  const em = (e, c, i) => emAs("pj-em", e, c, i);
  // The same on a picture that is already on the page.
  const emPut = (el, e, c, i) => { const h = icoHtml(i); if (h) el.innerHTML = h; else el.textContent = em1(e); el.classList.toggle("ph", !!h); el.classList.toggle("tint", !!c); el.style.setProperty("--em-c", c || "transparent"); };
  const icoOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).icon || (D.ident && D.ident[name] && D.ident[name].icon) || "";
  const colOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).color || "";
  const emoOf = (name) => ((roomsCache || roomsSeen || []).find((r) => r.name === name) || {}).emoji || (D.ident && D.ident[name] && D.ident[name].emoji) || "";
  // "받는 곳": which project, which conversation, which agent gets what is about to be sent.
  // `conv` is the conversation's title (or what will be opened); `n` > 1 names several at once.
  const toLine = (o) => `<span class="k">${esc(tl("room.to"))}</span>` + (o.n > 1
    ? `<b>${esc(tl("room.toN", {n: o.n}))}</b><span class="s">${esc(o.names.map(pname).join(", "))}</span>`
    : `${o.emoji ? em(o.emoji, "", icoOf(o.name)) : ""}<b>${esc(unEm(pname(o.name), o.emoji))}</b>${o.conv ? `<span class="s">· ${esc(unEm(o.conv, o.emoji))}</span>` : ""}`) + (o.agent ? agentTag(o.agent) : "");
  // An agent that is not connected here: its conversations are not listed (the server sends only
  // how many there are). One quiet row per agent says so and leads to 설정 › 연결.
  let unlinkedSeen = [];
  const unlinkRows = () => unlinkedSeen.map((u) => `<div class="pj-unl"><span>${esc(tl("room.unlinked", {agent: u.agent === "codex" ? "Codex" : "Claude Code", n: u.count}))}</span><button class="pj-text press" data-golink>${tl("room.unlinkedGo")}</button></div>`).join("");
  document.addEventListener("click", (e) => { if (e.target.closest?.("[data-golink]")) { setPage = "connect"; setShowPage = true; location.hash = "#settings"; } });
  // row-sync:begin
  // One state per conversation. The chat's header asks the server every few seconds; the list
  // was only read when the page was drawn, so a conversation that had ended in the header went
  // on as "작업 중" in its row (and in the 작업 중 count) for as long as the box was being typed
  // in. What the server last said about a session is written onto its row here, wherever the
  // row is: the open project's sessions and the other projects' rows. True when a row changed.
  // `turn` is one of them: left out, a row of the open project kept the my-turn mark it had when
  // the page was drawn for as long as the box was typed in, though the session had long gone on.
  const ROW_KEYS = ["state", "busy", "last", "title", "unread", "turn"];
  function syncRow(all, rooms, id, st) {
    if (!id || !st || !st.state) return false;
    let ch = false;
    const s = (all || []).find((x) => x.id === id);
    if (s) {
      ROW_KEYS.forEach((k) => { if (k in st && s[k] !== st[k]) { s[k] = st[k]; if (k !== "busy") ch = true; } });
      if (!!s.cut !== !!st.cut) { s.cut = !!st.cut; ch = true; }
    }
    (rooms || []).forEach((r) => {
      if (r.sid === id && r.state !== st.state) { r.state = st.state; ch = true; }
      if (r.sid === id && "turn" in st && !!r.turn !== !!st.turn) { r.turn = !!st.turn; ch = true; }
      (r.more || []).forEach((m) => { if (m.sid === id && m.state !== st.state) { m.state = st.state; ch = true; }
        if (m.sid === id && "turn" in st && !!m.turn !== !!st.turn) { m.turn = !!st.turn; ch = true; } });
    });
    return ch;
  }
  // A session the person has just answered is not theirs to answer, whatever the list last heard:
  // the rows are read every few seconds and the session takes a moment to take the line up, so the
  // row left behind turned orange again. It counts as answered until the session does something
  // after the answer (`at`, its last activity, is newer than `sent`), and for ANS_MS at most.
  const ANS_MS = 10 * 60000;
  const answered = (sent, at, now) => { if (!sent || now < sent || now - sent > ANS_MS) return false;
    const t = at ? Date.parse(at) : NaN; return !(isFinite(t) && t > sent); };
  // A line sent to Codex that its record never took, with nothing running any more: not "보냄".
  const LOST_MS = 15000;
  const lostLine = (p, st, now) => !!(p && !p.busy && !p.failed && p.sentAt && st && st.found !== false && !st.busy && now - p.sentAt > LOST_MS);
  // row-sync:end
  let rowSync = null, listTimer = 0;
  // When each session was last answered from here ({sid: ms}), kept on this device so a reload
  // does not bring the my-turn mark back. PjAnswered is the same question for the other screens.
  const ANS_KEY = "rl-pj-answered";
  let ansAt = (() => { try { return JSON.parse(localStorage.getItem(ANS_KEY) || "{}") || {}; } catch (e) { return {}; } })();
  const isAnswered = (sid, at) => answered(ansAt[sid], at, Date.now());
  window.PjAnswered = isAnswered;
  // `on` false: the answer did not get through, so it is the person's turn as before.
  function ansMark(sid, on) {
    const now = Date.now(); Object.keys(ansAt).forEach((k) => { if (now - ansAt[k] > ANS_MS) delete ansAt[k]; });
    if (on) ansAt[sid] = now; else delete ansAt[sid];
    try { localStorage.setItem(ANS_KEY, JSON.stringify(ansAt)); } catch (e) { /* storage off: this visit only */ }
    if (on && typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.turn = false; });
    if (typeof drawChrome === "function") drawChrome();
    if (railNow) railNow();
  }
  const LIST_EVERY = 10000;
  // The room list read quietly (no dialog): the timer below must never put a question up.
  async function quietRooms() {
    const t0 = performance.now(), r = await get("/api/project/rooms");
    if (r && r.rooms && !r.declined && !r.need_consent) { topPins = new Set(r.top_pins || []); roomsSeen = roomsCache = r.rooms; groupsSeen = r.groups || []; oldInfo = {only: r.old_only || 0}; unlinkedSeen = r.unlinked || []; roomsAt = Date.now();
      if (r.order && ordFresh(t0)) listOrd = r.order; }
  }
  async function loadRooms() {
    const t0 = performance.now(), r = await readOrAsk("/api/project/rooms");
    if (!r.declined) { topPins = new Set(r.top_pins || []); roomsSeen = roomsCache = r.rooms || []; groupsSeen = r.groups || []; oldInfo = {only: r.old_only || 0}; unlinkedSeen = r.unlinked || []; roomsAt = Date.now();
      if (r.order && ordFresh(t0)) listOrd = r.order; }
    return r;
  }
  const loadOld = () => get("/api/project/rooms?old=1").then((r) => {
    const have = new Set((roomsCache || roomsSeen || []).map((x) => x.name));
    oldRooms = (r.rooms || []).filter((x) => !have.has(x.name));
  }).catch(() => { oldRooms = []; });
  const bundlesOf = () => get("/api/room-bundles").then((b) => b.bundles || []).catch(() => []);
  const goMulti = (ids) => nav("project/" + MULTI + "/" + ids.map(enc).join(","));

  function roomCard(r, cls) {
    const st = r.state || "ended";
    const said = r.sid ? (r.who === "user" ? `<b>${tl("room.me")}</b> ` : "") + esc(Redact.show(flat1(unnote(r.last))) || tl("room.noLine")) : esc((darkRoom(r) && backLine(r.back)) || tl("room.noSession"));
    return `<button class="pj-card press${cls ? " " + cls : ""}" data-p="${esc(r.name)}"${cls === "cur" ? ` aria-current="true"` : ""}>
      <div class="r1">${em(r.emoji, r.color, r.icon)}<div class="t">${esc(unEm(pname(r.name), r.emoji || icoHtml(r.icon)))}</div>
        ${r.unread ? `<span class="pj-badge" aria-label="${esc(tl("room.unread", {n: r.unread}))}">${r.unread > 99 ? "99+" : r.unread}</span>` : ""}</div>
      <div class="pj-last">${said}</div>
      <div class="r2">${r.sid ? mark(st, r.at) : ""}${agentTag(r.agent)}${r.pinned ? `<span class="pj-pinmk" title="${esc(tl("room.pinned"))}">${ic("tack")}</span>` : ""}${r.copies ? `<span>${esc(tl("room.copies", {n: r.copies}))}</span>` : ""}${ctxRow(r.context)}<span class="sp"></span>${darkRoom(r) ? onBtnHtml(r.name, "span") : `<span>${r.at ? ago(r.at) : ""}</span>`}</div></button>`;
  }
  // 켜기 on a card: it is a button inside the card's own, so the press stays with it.
  const wireOn = (box, redraw) => box.querySelectorAll(".pj-card [data-on]").forEach((b) => {
    const go = (e) => { e.preventDefault(); e.stopPropagation(); if (b.getAttribute("aria-disabled") !== "true") askOn(b, b.dataset.on, redraw); };
    b.onclick = go; b.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") go(e); };
  });

  async function drawPick(el, my, all) {
    // A wide window does not stop at the list: the most recent conversation opens with the list
    // beside it, ready to type in. The list alone is #project/~all (and every narrow window).
    // Which one: the conversation that was open last in this run of the app, else the row the list
    // shows first as it is sorted and narrowed now (it used to be the newest project's own session,
    // which in 세션 view is not the top row, and could be one that ended long ago).
    const jump = (list) => {
      // A phone does the same with its one pane: 대화 is the list of every session (the same list,
      // as a page), with the chat last looked at under it; a row opens its chat over the list.
      if (!all && phoneList()) { const r = list.find((x) => x.sid && x.name === lastChat.name) || list.find((x) => x.sid); if (!r) return false;
        listAt = true; drawProject(el, r.name, r.name === lastChat.name ? lastChat.sid : "", my); return true; }
      if (all || !wide()) return false;
      const was = lastOpen && list.some((x) => x.name === lastOpen.name) ? lastOpen : null;
      const any = list.find((x) => x.sid);             // every row narrowed away: the first project, as before
      const r = was || topRow(list) || (any ? {name: any.name} : null);
      if (r) location.replace("#project/" + enc(r.name) + (r.sid ? "/" + enc(r.sid) : ""));
      return !!r;
    };
    if (roomsSeen && jump(roomsSeen)) return;
    // What we showed last time goes up at once (the list is the same nine times out of ten);
    // the fresh answer replaces it when it lands. Only the very first open waits, and says why.
    if (roomsSeen) pickPaint(el, {}, bundSeen, roomsSeen, true);
    else el.innerHTML = `${chatTabs("project")}${loadingHtml(tl("room.loading"), {fill: true})}`;
    let d, bund;
    try { [d, bund] = await Promise.all([loadRooms(), bundlesOf()]); }
    catch (e) { if (live(my)) { if (roomsSeen) toast(e.message); else failed(el, e); } return; }
    if (!live(my) || jump(roomsCache || [])) return;
    bundSeen = bund;
    const q = el.querySelector("[data-q]"), typing = q && document.activeElement === q, at = typing ? q.selectionStart : 0;
    pickPaint(el, d, bund, roomsCache || [], false);
    if (typing) { const n = el.querySelector("[data-q]"); if (n) { n.focus(); try { n.setSelectionRange(at, at); } catch (e) { /* not a text field */ } } }
  }
  // Write html into a part of the list only when it is not what stands there: the list is read
  // again on every refresh round, and rebuilding the same rows moved the page under the finger.
  // still:begin
  const put = (el, html) => { if (el._was === html && el.firstChild) return; el.innerHTML = html; el._was = html; };
  // still:end
  function pickPaint(el, d, bund, list, stale) {
    // A phone: newest first, and nothing that opens several chats side by side.
    const ph = phoneList();
    if (ph) { list = list.slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || ""))); bund = []; }
    const unread = list.reduce((n, r) => n + (r.unread || 0), 0);
    const shell = `${chatTabs("project")}<div class="pj-top">
        ${list.length > 6 ? `<input class="pj-search" type="search" data-q placeholder="${esc(tl("room.search"))}" aria-label="${esc(tl("room.search"))}" value="${esc(roomQ)}">` : `<span class="sp"></span>`}
        ${ph || list.length < 2 ? "" : `<button class="pj-text press" data-multi>${tl("room.multi")}</button>`}
        <button class="pj-text press" data-fixed>${tl("room.fixed.new")}</button>
        <button class="pj-btn light press" data-new>${ic("plus")}<span>${tl("room.newSess")}</span></button></div>
      ${d.need_consent || d.declined ? `<div class="pj-empty">${tl("room.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("room.askAgain")}</button></div>` : ""}
      ${bund.length ? `<div class="pj-lab">${tl("room.bundles")}</div><div class="pj-chips">${bund.map((b, i) => `<button class="pj-chip press" data-bund="${i}">${esc(b.name)}<em>${b.ids.length}</em></button>`).join("")}</div>` : ""}
      <div class="pj-lab" data-rl></div>
      <div id="pj-rg"></div>
      <div id="pj-old"></div>${unlinkRows()}
      <button class="pj-fold press" data-bg aria-expanded="${bgOpen}">${ic("chev", "i")}<span>${tl("room.bg")}</span></button>
      <div id="pj-bgl"></div>`;
    if (el._was !== shell || !el.querySelector(":scope>#pj-rg")) { el.innerHTML = shell; el._was = shell; }
    // The count and the unread number change on their own; they are not a reason to build the page again.
    put(el.querySelector("[data-rl]"), `${tl("room.rooms")} <span class="n">${list.length}</span>${unread ? `<span class="pj-badge">${unread > 99 ? "99+" : unread}</span>` : ""}`);
    const rg = el.querySelector("#pj-rg");
    const grid = () => {
      const q = foldQ(roomQ);
      const shown = q ? list.filter((r) => (hay(r) + foldQ(r.last)).includes(q)) : list;
      put(rg, shown.length ? `<div class="pj-grid">${shown.map(roomCard).join("")}</div>`
        : `<div class="pj-empty">${list.length ? tl("room.noMatch") : tl("room.none")}</div>`);
      rg.querySelectorAll("[data-p]").forEach((b) => b.onclick = () => nav("project/" + enc(b.dataset.p)));
      wireOn(rg, () => { if (rg.isConnected) draw(el); });
    };
    grid();
    const q = el.querySelector("[data-q]");
    if (q) q.oninput = () => { roomQ = q.value; grid(); };
    el.querySelector("[data-new]").onclick = () => newTalk();
    el.querySelector("[data-fixed]").onclick = (e) => newStanding(e.currentTarget);
    drawOld(el.querySelector("#pj-old"));
    const mb = el.querySelector("[data-multi]");
    if (mb) mb.onclick = () => pickPanes([], goMulti);
    el.querySelectorAll("[data-bund]").forEach((b) => b.onclick = () => goMulti(bund[+b.dataset.bund].ids));
    const rt = el.querySelector("[data-retry]");
    if (rt) rt.onclick = () => draw(el);
    const bl = el.querySelector("#pj-bgl"), bf = el.querySelector("[data-bg]");
    bf.onclick = () => { bgOpen = !bgOpen; bf.setAttribute("aria-expanded", bgOpen); drawBg(bl); };
    if (!stale) drawBg(bl);
  }

  // Folders that hold only sessions made outside this app, all ended: one folded row under the
  // list, opened in place. Nothing is deleted; a session in them opens like any other.
  function drawOld(box) {
    if (!box) return;
    const n = oldInfo.only;
    put(box, n ? `<button class="pj-fold press" data-old aria-expanded="${showOld}">${ic("chev", "i")}<span>${showOld ? tl("room.oldHide") : tl("room.oldShow", {n})}</span></button>`
      + (showOld ? `<div class="pj-grid pj-olds pj-anim">${oldRooms ? oldRooms.map((r) => roomCard(r)).join("") : `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`}</div>` : "") : "");
    const b = box.querySelector("[data-old]"); if (!b) return;
    b.onclick = () => { showOld = !showOld; if (showOld) oldRooms = null; drawOld(box); };
    box.querySelectorAll("[data-p]").forEach((c) => c.onclick = () => nav("project/" + enc(c.dataset.p)));
    if (showOld && !oldRooms) loadOld().then(() => { if (box.isConnected) drawOld(box); });
  }

  // Every session Claude Code keeps in the background, whatever department it belongs to.
  async function drawBg(box) {
    if (!bgOpen) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="pj-empty">${loadingHtml(tl("room.loading"))}</div>`;
    let d;
    try { d = await readOrAsk("/api/project/background"); } catch (e) { box.innerHTML = `<div class="pj-empty">${esc(e.message)}</div>`; return; }
    if (!box.isConnected) return;
    if (d.declined || d.need_consent) { box.innerHTML = ""; return; }
    const rows = d.rows || [];
    box.innerHTML = rows.length ? `<div class="pj-anim">${rows.map((r, i) => `<button class="pj-item press" data-bgi="${i}">
        ${em(r.emoji)}
        <span class="tx"><div class="t">${esc(pname(r.dept || "") || r.name || r.id || "")}</div><div class="s">${esc(r.name || "")}${r.id ? " · " + esc(r.id) : ""}${r.agent === "codex" ? " · Codex" : ""}</div></span>
        ${r.pinned ? `<span class="pj-pinmk">${ic("tack")}</span>` : ""}
        <span class="pj-tag ${r.busy ? "on" : ""}">${esc(r.busy ? tl("room.bgBusy") : tl("room.bgIdle"))}</span></button>`).join("")}</div>`
      : `<div class="pj-empty" style="text-align:left;padding:6px 2px">${tl("room.bgNone")}</div>`;
    box.querySelectorAll("[data-bgi]").forEach((b) => b.onclick = () => bgSheet(rows[+b.dataset.bgi], () => drawBg(box)));
  }
  async function bgSheet(r, again) {
    let log = "";
    if (r.id) {
      const l = await readOrAsk("/api/project/agent-log?id=" + enc(r.id)).catch((e) => ({error: e.message}));
      if (l.declined) return;
      log = l.text || l.error || "";
    }
    sheet(`<div class="pj-dlg"><h3>${esc(pname(r.dept || "") || r.name || "")}</h3>
      <pre class="pj-log">${esc(log || tl("room.bgNoScreen"))}</pre>
      ${r.id ? `<div class="pj-hint">${esc(tl("room.bgAttach"))} <code>claude attach ${esc(r.id)}</code></div>` : ""}
      <div class="acts">${r.sid && r.dept ? `<button class="pj-btn light full press" data-go>${tl("room.openChat")}</button>` : ""}
        <button class="pj-btn full press" data-stop>${tl("room.stop")}</button></div></div>`, (box) => {
      const g = box.querySelector("[data-go]");
      if (g) g.onclick = () => { closeSheet(); nav("project/" + enc(r.dept) + "/" + enc(r.sid)); };
      box.querySelector("[data-stop]").onclick = async () => {
        closeSheet();
        try {
          const x = r.agent === "codex" ? await act("/api/session/stop", {sid: r.sid}) : await act("/api/session/bg-stop", {id: r.id});
          toast(x.message || tl("room.stopped")); again();
        } catch (e) { if (e.message !== "cancelled") toast(e.message); }
      };
    });
  }

