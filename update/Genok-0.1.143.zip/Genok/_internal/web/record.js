// Genok web UI, 결과물 › 세션별: every result ever pushed, approved or put away, as one large
// card per conversation that made it; a card opens that conversation's results as a grid.
// Approving a result takes it off the review queue, not out of sight: the old cuts stay here.
// A classic script in the page's shared scope; v2.html loads it after v2-results.js, which draws
// the other tab ("검토할 것") and calls recDraw() when this one is chosen.
//
// Data: /api/projects gives each project's counts (live + archived); every project with results is
// read once: /api/items?p=X (live) and &archived=1, each carrying `vers`, its versions
// (web/../index.py). A conversation is named from the open rooms when they know it, else by
// department and day.
const resTab = (v) => { try { if (v) localStorage.setItem("genok-res-tab", v); else return localStorage.getItem("genok-res-tab") === "record" ? "record" : "review"; } catch { /* storage blocked */ } return v || "review"; };
let recProj = null, recProjAt = 0, recProjP = null, recSess = null;
const recItems = new Map(), recFail = new Set();

// The page header both tabs share: title, one sub line, the two tabs.
// 검토할 것 | 기록 beside the results title: the list as it was, or every cut by project and conversation.
const resSeg = (tab) => `<div class="g-seg rv-seg" role="tablist" aria-label="${esc(tl("lib.tab"))}">${[["review", tl("lib.tab.review")], ["record", tl("lib.tab.record")]].map(([k, n]) =>
    `<button type="button" class="press${k === tab ? " on" : ""}" role="tab" aria-selected="${k === tab}" data-rvtab="${k}">${esc(n)}</button>`).join("")}</div>`;
const recTotal = () => (recProj || []).reduce((a, p) => a + p.items + p.archived, 0);
function recProjects() {
  if (recProj && Date.now() - recProjAt < 30000) return Promise.resolve(recProj);
  return recProjP ||= get("/api/projects").then((l) => {
    recProj = l.filter((p) => p.items + p.archived > 0).sort((a, b) => (b.updated || "").localeCompare(a.updated || ""));
    recProjAt = Date.now(); return recProj;
  }).finally(() => { recProjP = null; });
}
// sid -> the name the conversation goes by, from the rooms the app already holds.
function recNames() {
  const m = new Map();
  attL("rooms").forEach((r) => {
    if (r.sid) m.set(r.sid, r.named || r.label || r.title || "");
    [r.back, ...(r.back?.past || [])].forEach((b) => { if (b?.sid) m.set(b.sid, b.title || b.label || ""); });
  });
  return m;
}
const recDay = (t) => t ? new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "short", day: "numeric"}) : "";
const recWord = (s) => s === "approved" ? tl("STATUS_T.4") + " ✓" : s === "changes" ? tl("STATUS_T.2") : s === "hold" ? tl("STATUS_T.3") : tl("lib.rec.pending");

// One cluster per conversation that pushed; versions with no conversation id cluster by
// department and day. Newest cluster first; inside, the versions in time order.
function recClusters(items) {
  const m = new Map();
  for (const x of items) for (const w of x.vers || []) {
    const k = w.sid ? "s:" + w.sid : "d:" + (w.dept || "") + "|" + (w.at || "").slice(0, 10);
    let c = m.get(k); if (!c) m.set(k, c = {k, sid: w.sid || "", dept: w.dept || "", vs: []});
    c.vs.push({x, w});
  }
  const L = [...m.values()];
  L.forEach((c) => c.vs.sort((a, b) => (a.w.at || "").localeCompare(b.w.at || "")));
  return L.sort((a, b) => (b.vs.at(-1).w.at || "").localeCompare(a.vs.at(-1).w.at || ""));
}
function recTile({x, w}) {
  const id = iid(x), latest = x.vers.at(-1).v, can = w.v !== latest;
  return `<li class="rv-t"><a class="rv-tb press" href="#item/${esc(id)}" data-hv="${esc(id)}" data-v="${esc(w.v)}" data-latest="${esc(latest)}" aria-label="${esc(tl("lib.rec.open", {t: x.title, v: vShort(w.v)}))}">
      <span class="rv-th">${ic((KIND[w.kind] || ["doc"])[0])}${w.thumb ? imgTag(w.thumb) : ""}</span>
      <span class="rv-tt">${esc(x.title)}</span><span class="rv-tm${w.s === "approved" ? " ok" : ""}">${esc(vShort(w.v))} · ${esc(recWord(w.s))} · ${esc(recDay(w.at))}</span></a>
    ${can ? `<a class="rv-cmp press" href="#item/${esc(id)}" data-hc="${esc(id)}" data-v="${esc(w.v)}" data-latest="${esc(latest)}" aria-label="${esc(tl("lib.rec.cmp.a", {t: x.title, v: vShort(w.v)}))}">${esc(tl("lib.rec.cmp"))}</a>` : ""}</li>`;
}
// A conversation's name, its place (project), days and counts - what a card and the opened view show.
function recInfo(c, names) {
  const a = recDay(c.vs[0].w.at), b = recDay(c.vs.at(-1).w.at), proj = pname(gname(c.vs[0].x));
  const named = names.get(c.sid);
  return {title: named || `${pname(c.dept || gname(c.vs[0].x))} · ${a}`, place: named ? proj : "", days: a === b ? a : a + " – " + b,
    res: new Set(c.vs.map((o) => iid(o.x))).size, ok: c.vs.filter((o) => o.w.s === "approved").length};
}
const recMeta = (f, c) => [f.place, f.days, tl("lib.rec.res", {n: f.res}), tl("lib.rec.vers", {n: c.vs.length}), f.ok ? tl("lib.rec.ok", {n: f.ok}) : ""].filter(Boolean).map(esc).join(" · ");
// Up to four pictures, newest first, one per result.
function recPics(c) {
  const seen = new Set(), out = [];
  for (const {x, w} of [...c.vs].reverse()) { if (out.length >= 4) break; if (!w.thumb || seen.has(iid(x))) continue; seen.add(iid(x)); out.push(w.thumb); }
  return out;
}
function recCard(c, names) {
  const f = recInfo(c, names), pics = recPics(c), kind = (KIND[c.vs.at(-1).w.kind] || ["doc"])[0];
  return `<li><button type="button" class="rv-sc press" data-rs="${esc(c.k)}">
    <span class="rv-sp n${Math.max(1, pics.length)}">${pics.length ? pics.map((u) => `<span>${imgTag(u)}</span>`).join("") : `<span>${ic(kind)}</span>`}</span>
    <span class="rv-sb"><span class="rv-cn">${esc(f.title)}</span><span class="rv-cs">${recMeta(f, c)}</span></span></button></li>`;
}
const recAll = () => recProj.flatMap((p) => recItems.get(p.name) || []);
const recErr = () => recProj.some((p) => recFail.has(p.name)) ? `<p class="rv-none">${esc(tl("lib.rec.err"))} <button type="button" class="g-btn quiet press" data-rvretry="">${esc(tl("netBar.2"))}</button></p>` : "";
function recPaint() {
  const host = document.getElementById("rvl"); if (!host || resTab() !== "record") return;
  const cl = recClusters(recAll()), names = recNames(), open = recSess && cl.find((c) => c.k === recSess);
  document.getElementById("rvsub").textContent = tl("lib.sub.record", {s: cl.length, n: recTotal()});
  if (!open) {
    recSess = null;
    host.innerHTML = recErr() + (cl.length ? `<ul class="rv-sg">${cl.map((c) => recCard(c, names)).join("")}</ul>` : `<p class="rv-none">${esc(tl("lib.rec.none"))}</p>`);
  } else {
    const f = recInfo(open, names);
    host.innerHTML = `<div class="rv-sv"><button type="button" class="g-btn quiet press rv-bk" data-rsback>${ic("back")}${esc(tl("lib.rec.back"))}</button>
      <div class="rv-ct"><span class="rv-cn">${esc(f.title)}</span><span class="rv-cs">${recMeta(f, open)}</span></div>
      <ul class="rv-g">${[...open.vs].reverse().map(recTile).join("")}</ul></div>`;
  }
  host.classList.remove("in"); void host.offsetWidth; host.classList.add("in");
}
async function recLoad(name) {
  if (recItems.has(name)) return;
  try {
    const q = "/api/items?p=" + encodeURIComponent(name);
    const [live, arch] = await Promise.all([get(q), get(q + "&archived=1")]);
    recItems.set(name, [...live, ...arch]); recFail.delete(name);
  } catch { recFail.add(name); }
}
function recDraw() {
  V().innerHTML = `<div class="tab-view-container k3lib rv rv-rec"><div class="glass-card content-table-card"><div class="content-table-header"><div class="content-header-left"><h3 class="section-title same">${esc(tl("TABS.3"))}</h3>${resSeg("record")}</div></div><p class="g-sub rv-sub" id="rvsub"></p><div class="rv-list" id="rvl"><div class="rv-ld">${loadingHtml("", {size: 20})}</div></div></div></div>`;
  recProjects().then((l) => Promise.all(l.map((p) => recLoad(p.name)))).then(recPaint, () => { const h = document.getElementById("rvl"); if (h) h.innerHTML = `<p class="rv-none">${esc(tl("lib.rec.err"))} <button type="button" class="g-btn quiet press" data-rvretry="">${esc(tl("netBar.2"))}</button></p>`; });
  return {};
}

document.addEventListener("click", (e) => {
  const t = e.target.closest?.("[data-rvtab],[data-rs],[data-rsback],[data-rvretry],a[data-hv],a[data-hc]"); if (!t || cur !== "lib" || detail) return;
  if (t.dataset.rvtab) { if (resTab() !== t.dataset.rvtab) { resTab(t.dataset.rvtab); libSel = null; SCREENS.lib(); } return; }
  if (t.dataset.rs !== undefined || t.dataset.rsback !== undefined) {
    // Back lands on the card it came from; opening lands on the back button.
    const from = recSess; recSess = t.dataset.rs || null; recPaint();
    const host = document.getElementById("rvl"), to = recSess ? host?.querySelector("[data-rsback]") : host?.querySelector(`[data-rs="${CSS.escape(from || "")}"]`);
    to?.focus({preventScroll: true}); (recSess ? host : to)?.scrollIntoView({block: "nearest"});
    return;
  }
  if (t.dataset.rvretry !== undefined) { recFail.clear(); recDraw(); return; }
  e.preventDefault();
  const id = t.dataset.hv || t.dataset.hc, v = t.dataset.v, latest = t.dataset.latest;
  // A version opens the item on that version; the compare puts it against the newest.
  if (t.dataset.hc) return nav(cmpHashStr(id, latest, v, cmpMode()).slice(1));
  if (v === latest) delete verPick[id]; else verPick[id] = v;
  nav("item/" + id);
});
