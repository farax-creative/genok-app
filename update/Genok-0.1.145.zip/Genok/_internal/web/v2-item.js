// Genok web UI, cut from v2.js: the item page: one result, its versions, compare and comments.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// The item's review detail (rev, directives) for a decision made from a list row.
const itemDetail = (p, i) => get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`).catch(() => null);
const itemRev = (p, i) => itemDetail(p, i).then((d) => d?.rev ?? d?.review?.rev);
function approveMany(xs, ms = 5000) {
  if (!xs.length) return;
  sendMany(); triSend();
  libSel = null; xs.forEach((x) => libHide.add(iid(x))); libNow(); redrawTurn(); redrawDept();
  // Board rows carry no review rev, and an approval without one is refused: read it during the
  // five seconds, so the approval names the revision that was there when the reader said yes.
  xs.forEach((x) => { if (x.rev == null) x.revP = itemRev(x.project, x.id).then((r) => { x.rev = r; }); });
  const o = manyLater = {xs};               // sent when the toast's time is up (it waits while the toast is held)
  toastAct(tl("approveMany.1", {n: xs.length}), tl("toggleFav.3"), () => {
    if (!manyLater) return toast(tl("approveMany.2"));
    clearTimeout(manyLater.timer); const back = manyLater.xs; manyLater = null;
    toast(tl("approveMany.3"), 2200, "undo"); gactFlip(() => { back.forEach((x) => libHide.delete(iid(x))); gactDraw(); }); redrawTurn(); }, ms, "approve", () => { if (manyLater === o) sendMany(); });
}
function sendMany() {
  const o = manyLater; if (!o) return; manyLater = null; clearTimeout(o.timer);
  Promise.all(o.xs.map((x) => (x.rev == null && x.revP || Promise.resolve()).then(() => fetch("/api/status", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: x.project, i: x.id, v: x.v, status: "approved", rev: x.rev})})).then((r) => r.ok ? null : x, () => x)))
    .then(async (bad) => { bad = bad.filter(Boolean); await load(); o.xs.forEach((x) => libHide.delete(iid(x)));
      if (bad.length) toast(tl("sendMany.1", {n: bad.length}), 4000);
      if (!document.activeElement?.matches?.("input,textarea,gk-select")) { if (cur === "lib" && !detail) libDraw(); redrawTurn(); } });
}
addEventListener("pagehide", () => { sendMany(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) sendMany(); });

// One version's picture: its first file that has one.
const shotOf = (v) => { const f = (v.files || []).find((f) => f.thumb || f.kind === "image") || (v.files || [])[0];
  return f ? {img: f.kind === "image" ? f.play || f.url : f.thumb, video: f.kind === "video" ? (f.play || f.url) : null, kind: f.kind, url: f.url} : {}; };
// What the viewer can show full screen: pictures and videos. The rest open as links.
const viewable = (f) => f.kind === "image" || f.kind === "video";
// The item on screen, for the decide buttons. Kept off the DOM: a data-item on #view would
// make every click inside it read as "open this item".
let openItem = null;
// The result page. The file being looked at stays on screen (swipe or arrows between
// files, videos play in place); below it one card with tabs, because usually only one of
// 질문 / 코멘트 is used. The version is a small chip, since the latest is what is checked.
let stageAt = 0, stageOf = null, stageGo = null, stageFit = null, stageZoom = null, stageRefit = null;
// A window resized puts a stage the person sized back to that size, as far as it still fits.
addEventListener("resize", () => stageRefit?.());
const verPick = {}, tabPick = {}, cmpPick = {};
// Version timeline: the 비교 toggle and which versions are picked while it is on (transient,
// reset when the open item changes). pendingCmp/cmpSeek carry a compare state read from the
// address (#item/<id>?cmp=..&m=..&t=..) into the first draw of that item.
let cmpToggle = false, tlSel = [], tlItem = null, pendingCmp = null, cmpSeek = null;
// A request of the last version ticked off as fixed: this browser's own note, kept by comment.
const fxMem = {};
const isFixed = (id) => { if (id in fxMem) return fxMem[id]; try { return localStorage.getItem("fx:" + id) === "1"; } catch { return false; } };
const setFixed = (id, on) => { fxMem[id] = on; try { on ? localStorage.setItem("fx:" + id, "1") : localStorage.removeItem("fx:" + id); } catch {} };
// A pushed link (/i/<p>/<i>/<v>) arrives as /?v=<v>#item/<p>/<i>: open that version.
{ const q = new URLSearchParams(location.search).get("v"), m = location.hash.match(/^#item\/(.+)$/);
  if (q && m) verPick[decodeURIComponent(m[1])] = q;
  if (location.search) history.replaceState(null, "", "/" + (IN_APP ? "?app=1" : FLOAT ? "?float=1" : "") + location.hash); }
let dockOpenOf = "";              // the item whose comment tools are out (a report's stay folded until the box is used)
let dirsOpenOf = "";              // the item whose 요청 fold is open; closed unless asked for
let xtraOpenOf = "";              // the item whose 기록과 정리 fold is open
let imMoreOf = "";                // the item whose 더 보기 (meta chips) is open
let pageW = "pc"; try { pageW = localStorage.getItem("pageW") || "pc"; } catch {}
// The zoom of a shown HTML result (PC): the report inside the frame, apart from the app's screen size.
const PAGE_Z = [0.5, 0.67, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2];
let pageZ = 1; try { const z = +localStorage.getItem("pageZ"); if (PAGE_Z.includes(z)) pageZ = z; } catch {}
// The same four buttons on a picture and on a page: out, the size now (press: 100%), in, fit.
const zoomCtl = (cls, label) => `<div class="zctl ${cls}" role="group" aria-label="${label}"><button class="press" data-z="-1" aria-label="${tl("zoom.out")}" title="${tl("zoom.out")}">${ic("minus")}</button><button class="press zpct num" data-z="100" aria-label="${tl("zoom.actual")}" title="${tl("zoom.actual")}"></button><button class="press" data-z="1" aria-label="${tl("zoom.in")}" title="${tl("zoom.in")}">${ic("plus")}</button><button class="press" data-z="0" aria-label="${tl("zoom.fit")}" title="${tl("zoom.fit")}">${ic("fit")}</button></div>`;
// The next thing waiting for a look, after the one open: so a run through the list
// is one tap each, and a line for it can go without leaving this one.
// Only 확인 필요 counts: a new version already answered in words is the department's move.
const toCheck = () => myTurn();
// The same department's pile comes first: its results are usually looked at together.
// The one before it in the same walk (Shift+N / ↑): the mirror of nextOf, wrapping the same way.
const prevOf = (id) => {
  const l = toCheck().reverse(), me = D.items.find((x) => iid(x) === id), who = (x) => gname(x);
  const same = me ? l.filter((x) => who(x) === who(me)) : [], at = same.findIndex((x) => iid(x) === id);
  return same[at + 1] || same.find((x) => iid(x) !== id) || l.find((x) => iid(x) !== id && (!me || who(x) !== who(me))) || l.find((x) => iid(x) !== id);
};
const nextOf = (id) => {
  const l = toCheck(), me = D.items.find((x) => iid(x) === id), who = (x) => gname(x);
  const same = me ? l.filter((x) => who(x) === who(me)) : [], at = same.findIndex((x) => iid(x) === id);
  return same[at + 1] || same.find((x) => iid(x) !== id) || l.find((x) => iid(x) !== id && (!me || who(x) !== who(me))) || l.find((x) => iid(x) !== id);
};
function nextCard(id) {
  const x = nextOf(id); if (!x) return "";
  const me = D.items.find((y) => iid(y) === id);
  const who = (y) => gname(y), rest = toCheck().filter((y) => iid(y) !== id), mine = rest.filter((y) => who(y) === who(x)).length;
  return `<div class="card nextrev" id="nextrev" data-nx="${esc(iid(x))}">
    <button class="nxgo press" data-item="${esc(iid(x))}" aria-label="${tl("nextCard.4", {esc: esc(x.title)})}">
      <span class="nxth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.thumb && x.kind === "video" ? `<span class="play">${ic("play", "i f")}</span>` : ""}</span>
      <span class="tx"><div class="s"><b>${tl("nextCard.3")}</b> · <span class="num">${tl("nextCard.2", {n: rest.length})}</span></div><div class="t">${me && gname(me) === gname(x) ? "" : esc(pname(gname(x))) + " · "}${esc(x.title)}</div></span>${ic("chev", "i go")}</button>
  </div>`;
}
// `mount`: an element to draw into instead of the page (the workroom's stage, the phone's
// result sheet). The header and the page-only bars are left out; everything else is the same code.
// A line typed here: its words, then the pictures its 📎 paths point at (kept under the hub's
// item/_attach, so the last three parts of the path are its /f/ address).
function attOf(text) {
  const urls = [], words = String(text).split("\n").filter((l) => {
    const m = l.match(/^📎 .*[\\/]([^\\/]+)[\\/]([^\\/]+)[\\/]_attach[\\/]([^\\/]+)$/);
    if (m) urls.push(`/f/${encodeURIComponent(m[1])}/${encodeURIComponent(m[2])}/_attach/${encodeURIComponent(m[3])}`);
    return !m;
  }).join("\n");
  return {words, urls};
}
// pgquote:begin
// A comment on a passage of a shown HTML report carries the passage as its first line, a markdown
// quote ("> words"): the session reads where it is meant, and the reader's log can go back to it.
const PGQ_MAX = 160;
function quoteLine(sel) {
  const q = String(sel || "").replace(/\s+/g, " ").trim();
  return q.length > PGQ_MAX ? q.slice(0, PGQ_MAX).trimEnd() + "…" : q;
}
function quoteOf(words) {
  const m = /^> ([^\n]+)(?:\n|$)/.exec(String(words || ""));
  if (!m || !m[1].trim()) return null;
  // A second line "→ words" is what the reader wants there instead.
  const rest = words.slice(m[0].length), to = /^→ ([^\n]+)(?:\n|$)/.exec(rest);
  return to && to[1].trim() ? {q: m[1].trim(), to: to[1].trim(), rest: rest.slice(to[0].length)} : {q: m[1].trim(), rest};
}
// Which of several equal passages a line's words are: how often they come up in the lines before
// it, spacing left out the way the page finds them (server.KEY_BRIDGE).
function nthBefore(lines, at, words) {
  const bare = (s) => String(s).replace(/[\s·]/g, ""), t = bare(words), hay = bare(lines.slice(0, at).join(""));
  let n = 0;
  if (t) for (let p = hay.indexOf(t); p >= 0; p = hay.indexOf(t, p + 1)) n++;
  return n;
}
// What changed in a report's words from one version to the next, in reading order: lineDiff rows
// (vdiff.js) folded into {was, now} pairs. A line only taken out has no `now`, one only put in no `was`.
// `at` is the new line's place in the report (0 = its first line), for going to it.
function pageChanges(rows) {
  const out = []; let del = [], add = [];
  const flush = () => { for (let k = 0; k < Math.max(del.length, add.length); k++) out.push({was: del[k] ?? null, now: add[k]?.text ?? null, at: add[k] ? add[k].b - 1 : null}); del = []; add = []; };
  for (const r of rows) { if (r.type === "same") flush(); else if (r.type === "del") del.push(r.text); else add.push(r); }
  flush();
  return out;
}
// pgquote:end
// The words of a pushed page, one line per block (a table row is one line), scripts and styles left
// out. The page is only parsed, never run, so a report that builds itself in script reads as empty.
const PG_BLOCK = "p,li,h1,h2,h3,h4,h5,h6,td,th,pre,blockquote,dt,dd,figcaption,summary,caption,div,section,article,header,footer,main,aside,nav,label,button";
function pageLines(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("script,style,noscript,template,svg").forEach((n) => n.remove());
  const out = [], w = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT); let row = null, blk = null, el = null;
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const t = n.nodeValue.replace(/\s+/g, " "); if (!t.trim()) continue;
    const b = n.parentElement.closest(PG_BLOCK) || doc.body, r = b.closest("tr") || b;
    // Two elements of one block (a figure and its label) are usually laid out apart: a space, not one word.
    if (r === row) out[out.length - 1] += (b !== blk ? " · " : n.parentElement !== el ? " " : "") + t; else out.push(t);
    row = r; blk = b; el = n.parentElement;
  }
  return out.map((s) => s.replace(/\s+/g, " ").trim());
}
// The report on screen against the version before: both pages' words, diffed once per pair.
const pgDiffMemo = new Map();
function pgDiff(aUrl, bUrl) {
  const key = aUrl + "\n" + bUrl;
  if (!pgDiffMemo.has(key)) pgDiffMemo.set(key, Promise.all([aUrl, bUrl].map((u) => fetch(u).then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.text(); })))
    .then(([a, b]) => { const la = pageLines(a), lb = pageLines(b);
      if (la.length > 4000 || lb.length > 4000) return null;
      const changes = pageChanges(lineDiff(la.join("\n"), lb.join("\n")));
      // Where a press on a changed line goes: its first cell, and which of the equal ones it is.
      for (const c of changes) if (c.now) { c.go = c.now.split(" · ")[0]; c.n = nthBefore(lb, c.at, c.go); }
      return {same: a === b, changes}; })
    .catch(() => null));
  return pgDiffMemo.get(key);
}
// A push that put requests off (--later <id,...>) stored their ids; the reader sees the requests'
// own words, or how many there were when a request is no longer on file. Never the raw id.
function laterText(s, dirs) {
  const ids = String(s || "").match(/#[0-9a-f]{6,16}(?![0-9a-z])/gi);
  if (!ids) return s || "";
  const words = ids.map((h) => (dirs || []).find((x) => String(x.id || "").startsWith(h.slice(1)))?.text).filter(Boolean)
    .map((t) => { t = attOf(t).words.split(/\s+/).join(" ").trim(); return t.length > 40 ? t.slice(0, 40) + "…" : t; }).filter(Boolean);
  return words.length ? words.join(" · ") + (ids.length > words.length ? " · " + tl("itemView.later_n", {n: ids.length - words.length}) : "") : tl("itemView.later_n", {n: ids.length});
}
// askpin:begin
// Where the question card must stop when 답하기 scrolls to it: below the pinned media when the card
// sits under it in the same column, else "" (the stylesheet's own margin, under the title bar).
const askPinned = (pos, top, h, medBottom, tabTop) => pos === "sticky" && h > 0 && tabTop >= medBottom - 1 ? `${Math.round((top || 0) + h + 8)}px` : "";
// askpin:end
// The frame a video is on, as a picture: a redraw makes a new <video>, and this stands in it until its own frame is back.
function stillOf(v) {
  if (v.readyState < 2 || !v.videoWidth) return "";
  const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  return c.toDataURL("image/jpeg", 0.9);
}
// What the open result showed last: the 5s check below (at `again`) redraws when this no longer holds.
let itemSig = "";
const itemSigOf = (id, d) => id + "|" + d.versions.length + "|" + d.log.length;
async function itemView(id, mount = null) {
  const box = mount || V();
  if (mount) mount.dataset.iid = id;
  // The 비교 toggle and its picks belong to the item on screen; a move to another item drops them.
  if (tlItem !== id) { tlItem = id; cmpToggle = false; tlSel = []; }
  // A compare state carried in from the address applies to the primary view only (not a stage/sheet
  // mount), and once: verPick/cmpPick become the pair, the mode and moment come along, 비교 opens.
  let restoredCmp = false;
  if (pendingCmp && pendingCmp.id === id && !mount) {
    const pc = pendingCmp; pendingCmp = null;
    verPick[id] = pc.a; if (pc.b) cmpPick[id] = pc.b;
    if (pc.m) cmpMode(pc.m);
    if (!isNaN(pc.thr)) cmpThr = pc.thr;
    cvAuto = id; cvScroll = scrollY; cmpSeek = isNaN(pc.t) ? null : pc.t;
  }
  // Redrawing the same item (a comment sent, the list refreshed) rebuilt the video at 0:00:
  // the moment just commented on was lost. Carry it over.
  const kv = openItem?.id === id ? stageVideo() : null, keep = kv && {v: openItem.v, t: kv.currentTime, play: !kv.paused, pic: stillOf(kv)};
  const x = D.items.find((i) => iid(i) === id);
  const [p, ...rest] = id.split("/"), i = rest.join("/");
  // A report's width and zoom tools sit in the top bar (PC); a redraw of the same item keeps them there.
  const hdT = esc(x?.title || i), hdMore = `${RD ? `<button class="jdopen press" data-judge-item title="${esc(tl("jd.open_t"))}">${esc(tl("jd.open"))}</button>` : ""}<button class="ib press" id="imore" aria-label="${tl("itemView.1")}">${ic("more")}</button>`;
  if (!mount) head(hdT, openItem?.id === id && head.last?.[1]?.includes("pgtop") ? head.last[1] : hdMore);
  if (!openItem || openItem.id !== id) box.innerHTML = loadingHtml(tl("syncAgo.1"), {fill: true});
  let d;
  try { d = await get(`/api/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`); }
  catch (e) {
    if (mount ? !mount.isConnected || mount.dataset.iid !== id : detail?.[1] !== id) return;   // moved on: the failure is not this screen's
    if (openItem?.id === id && (mount || box.querySelector(".detailcols"))) return;   // a redraw that failed keeps the page that is shown
    if (!mount) itemSig = id + "|";                    // the 5 s check draws it once the server answers
    box.innerHTML = `<div class="card plan none"><p>${esc(e.message)}</p><p><button class="btn weak press" data-go="lib">${tl("item.gone.go")}</button></p></div>`; return;
  }
  if (mount ? !mount.isConnected || mount.dataset.iid !== id : detail?.[1] !== id) return;   // moved on while it loaded
  if (!mount) itemSig = itemSigOf(id, d);
  if (x?.new && d.versions.length) {                         // opened = seen: its 새 버전 alert goes away
    x.new = false; post("/api/seen", {p, i, v: d.versions[d.versions.length - 1].v}).catch(() => {}); drawChrome();
  }
  const vs = d.versions.slice().reverse(), v = vs.find((w) => w.v === verPick[id]) || vs[0], latest = v === vs[0];
  if (drawing) endDraw(false);
  const prev = vs[vs.indexOf(v) + 1], s = shotOf(v);
  const files = v.files || [], pics = files.filter(viewable), other = files.filter((f) => !viewable(f))
    // Pushed with --url: a site or page to open, not a file. v2 used to drop these.
    .concat((v.links || []).filter((u) => /^https?:\/\/\S/i.test(u)).map((u) => ({url: u, name: u.replace(/^https?:\/\//, ""), kind: tl("itemView.2")})));
  if (stageOf !== id + v.v) { stageOf = id + v.v; stageAt = 0; pin = null; pinning = false; }
  stageAt = Math.min(stageAt, Math.max(pics.length - 1, 0));
  const allNotes = d.log.filter((e) => e.kind === "comment" || e.kind === "astra" || (e.kind === "message" && !/^\[(리뷰 허브|컨트롤룸) 코멘트\]/.test(e.text)));
  // 기록 filters: only the kinds this item has get a chip; a chosen one lists every match, not the last 12.
  const openIds = new Set((d.directives || []).filter((x) => x.state === "open").map((x) => x.id));
  const LF = [["all", tl("libDraw.1"), () => true], ["pic", tl("itemView.3"), (e) => attOf(e.text).urls.length > 0],
    ["when", tl("itemView.4"), (e) => !!whenTag(attOf(e.text).words)], ["reply", tl("itemView.5"), (e) => !!e.fixed_in],
    ["open", tl("itemView.6"), (e) => openIds.has(e.id)], ["ver", tl("lf.ver"), (e) => e.v === v.v]].map(([k, n, f]) => [k, n, allNotes.filter(f).length, f])
    .filter((c) => c[2] && (c[0] !== "ver" || c[2] < allNotes.length));     // 이 버전: only when older versions have notes too
  // No notes yet: every chip, "전체" too, was filtered out and LF[0] was undefined.
  const lf = LF.find((c) => c[0] === logF[id]) || LF[0] || ["all", tl("libDraw.1"), () => true, 0], lfOn = lf[0] !== "all";
  const notes = lfOn ? allNotes.filter(lf[3]) : allNotes.slice(logAll[id] ? 0 : -12), hidden = lfOn ? 0 : allNotes.length - notes.length;
  const unsent = d.log.filter((e) => e.kind === "comment" && !handed(e));
  const done = latest && v.status === "approved" && d.archived;
  // The shown version, read the way the lists read it: sent comments or answers make it the department's turn.
  const mine = d.log.filter((e) => e.kind === "comment" && e.v === v.v);
  const gave = d.log.filter((e) => (e.kind === "comment" || e.kind === "message") && e.v === v.v && handed(e));
  // The questions stay on the page after they are answered: each one folds to the answer on record
  // ([답] comments of this version), so "did I answer?" is read off the screen.
  const ask = v.ask || [], askAns = askAnswers(ask, d.log, v.v), askOpen = ask.filter((q, qi) => !askAns[qi]).length;
  const vx = {id: d.id, title: d.title, status: v.status, handed: gave.length > 0, answered: ask.length > 0 && !askOpen, spoke: gave.filter((e) => !(e.text || "").startsWith("[답]")).length,
    dept: x?.dept || v.dept, at: v.at, note: x?.note, asked: askOpen, comments: x?.comments, open: x?.open, led: x?.led,
    finished: d.finished, reach: x?.reach, said: x?.said, reopened: x?.reopened, moved_at: x?.moved_at, to_session: x?.to_session, sess: x?.sess, sess_since: x?.sess_since, handed_at: gave.map((e) => e.at || "").sort().pop() || null};
  // Two videos compare as videos, played in step: the file of the same name when the
  // other version has one, else each version's lead file. Any version can be the other side
  // (cmpPick); the one before is the default.
  const cmpWith = (w) => { const ws = shotOf(w);
    const cf = files.find((f) => f.kind === "video" && (w.files || []).some((x) => x.name === f.name && x.kind === "video"));
    const cv = cf ? [(w.files || []).find((x) => x.name === cf.name && x.kind === "video"), cf]
      : s.video && ws.video ? [w.files.find((f) => f.kind === "video"), v.files.find((f) => f.kind === "video")] : null;
    return {w, cv, ps: ws, ok: !!(cv || (s.img && ws.img))}; };
  const cmps = vs.filter((w) => w !== v).map(cmpWith).filter((c) => c.ok);
  const cmp = cmps.find((c) => c.w.v === cmpPick[id]) || cmps.find((c) => c.w === prev) || cmps[0];
  const pv = cmp?.w, cv = cmp?.cv, ps = cmp?.ps || {}, cmpOk = !!cmp;
  // flip:begin
  // The version 번갈아 보기 swaps in must hold something the stage can show in place: a report
  // (compared by its thumbnail) is no partner for a picture, so the nearest older version that
  // has a file of the same kind is offered instead, or no button at all.
  const flipPick = (pics, cands) => cands.find((w) => w && (w.files || []).some((x) => pics.some((f) => f.kind === x.kind)));
  // flip:end
  const flipV = flipPick(pics, [pv, prev, ...vs.slice(vs.indexOf(v) + 1)]);
  // What was asked of the version before, to tick off while looking at this one.
  const asked = latest && prev && !done ? d.log.filter((e) => e.kind === "comment" && e.v === prev.v && !/^\[(답|확정)\]/.test(e.text)) : [];
  // 지시 tracker: the reader's asks and how far each got. Newest first; claimed ones (a
  // version says it fixed them) need a 통과/다시 verdict, ok ones fold away.
  const dirs = (d.directives || []).slice().reverse();
  const dClaim = dirs.filter((x) => x.state === "claimed"), dOpen = dirs.filter((x) => x.state === "open" && !x.snoozed), dOk = dirs.filter((x) => x.state === "ok" || x.state === "passed");
  const dZz = dirs.filter((x) => x.state === "open" && x.snoozed);        // 다음에: put off to the next version
  // The asks already tracked as directives (below) are not repeated as a second checklist: only
  // asks that never became a directive stay in the 이전 요청 fold, so 지시 lives in one place.
  const vfx = fixedInVersion(v, d.directives);
  const askedO = asked.filter((e) => !dirs.some((x) => x.id === e.id));
  // A one-line summary: markdown marks (**bold**, `code`, list bullets) are dropped, not shown raw.
  // The spot/box tag reads as the chip below, not as raw percent; a time in the same tag stays.
  const dtxt = (x) => esc((quoteOf(attOf(x.text || "").words)?.rest ?? attOf(x.text || "").words).replace(/위치\([^)]*\)\s*/, "").replace(/^\[\s*\]\s*/, "").replace(/\*\*([^*\n]+)\*\*/g, "$1").replace(/`([^`\n]+)`/g, "$1").replace(/^\s*(?:[-*+]|\d+[.)])\s+/gm, "").split(/\s+/).join(" ").slice(0, 90));
  const dRgn = (x) => x.v === v.v && regionOf({rect: x.rect, text: x.text}) ? `<button class="lchip press" data-loc="${esc(x.id)}" title="${tl("loc.region_t")}">${ic("pin")}<span>${tl("loc.region")}</span></button> ` : "";
  const dQt = (x) => { const q = !pics.length && quoteOf(attOf(x.text || "").words); return q ? `<button class="qj press" data-qj="${esc(q.q)}" data-qn="${x.quote_n | 0}" title="${tl("pgq.jump_t")}"><span>${tl("pgq.part")}</span></button> ` : ""; };
  const dRow = (x) => `<div class="row note dir ${x.state}" data-did="${esc(x.id)}"><span class="tx"><div class="nt">${dRgn(x)}${dQt(x)}${dtxt(x)}</div><div class="s">${x.cycle > 1 ? `<em class="dcy num">${tl("fixv.cycle", {n: x.cycle})}</em> ` : ""}${x.state === "claimed" ? `<b class="dc">${tl("itemView.7", {esc: esc(x.fixed_in)})}</b>` : x.state === "ok" ? tl("itemView.8") : x.state === "passed" ? tl("itemView.9") : `${esc(x.v || "")} · ${ago(x.at)}`}</div>${x.fixed_note && x.state !== "open" ? `<div class="dsaid">${esc(x.fixed_note)}</div>` : ""}</span>${x.state === "open" && latest && !done ? `<span class="dbtns"><button class="btn sm weak press dzz" data-dz="${esc(x.id)}">${x.snoozed ? tl("dz.back") : tl("dz.later")}</button></span>` : ""}${x.state === "claimed" ? `<span class="dbtns"><button class="btn sm press dfv" data-fv="${esc(x.id)}" title="${tl("fixv.open_t")}">${ic("swap")}<span>${tl("fixv.open")}</span></button><button class="btn sm fill press dyes" data-dv="${esc(x.id)}">${tl("itemView.10")}</button><button class="btn sm weak press dno" data-dv="${esc(x.id)}">${tl("itemView.11")}</button></span>` : ""}</div>`;
  const dirCard = (dClaim.length || dOpen.length || dZz.length) ? `<details class="card dirs" id="dirsfold" data-panel="directives"${dirsOpenOf === id ? " open" : ""}><summary class="ch"><h2>${tl("itemView.17")}</h2><span class="dcnts">${[dOpen.length && `<button class="dcnt press num" data-dj="open">${tl("itemView.12", {n: dOpen.length})}</button>`, dClaim.length && `<button class="dcnt press num wait" data-dj="claimed">${tl("itemView.13", {n: dClaim.length})}</button>`].filter(Boolean).join("<i>·</i>")}</span><span class="sp"></span>${ic("chev", "i dn")}</summary>
    ${dClaim.map(dRow).join("")}${dClaim.length > 1 ? `<div class="clall"><button class="btn sm press dall">${tl("itemView.14", {n: dClaim.length})}</button></div>` : ""}${dOpen.slice(0, 3).map(dRow).join("")}
    ${dOpen.length > 3 ? `<p class="hint2" style="padding:2px 16px 12px;margin:0">${tl("itemView.15", {p0: dOpen.length - 3})}</p>` : ""}
    ${dZz.length ? `<details class="dok"><summary>${tl("dz.n", {n: dZz.length})}</summary>${dZz.map(dRow).join("")}<div style="height:6px"></div></details>` : ""}
    ${dOk.length ? `<details class="dok"><summary>${tl("itemView.16", {n: dOk.length})}</summary>${dOk.map(dRow).join("")}<div style="height:6px"></div></details>` : "<div style='height:8px'></div>"}</details>` : "";
  const tabs = [ask.length && ["ask", tl("itemView.18") + (askOpen ? "" : `<em class="tdone" role="img" aria-label="${tl("ask.done")}" title="${tl("ask.done")}">${ic("check")}</em>`), askOpen], ["cm", tl("itemView.19"), allNotes.length], !mount && window.LOOP_ITEM_CHAT && window.pjEmbed && ["chat", tl("itemView.chat"), 0]].filter(Boolean);   // comparing has one entry: 비교 on the version strip
  const tab = tabs.some((t) => t[0] === tabPick[id]) ? tabPick[id] : ask.length && !askOpen ? "cm" : tabs[0][0];
  const slide = (f, n) => `<div class="sl">${goneOf(f) ? goneHtml(f) : f.kind === "video"
    ? `<video src="${esc(f.play || f.url)}" loop playsinline preload="metadata" ${sound() ? "" : "muted"} ${f.thumb ? `poster="${esc(f.thumb)}"` : ""}></video><div class="sspin" hidden>${loadingHtml("", {tight: true})}</div>`
    : imgTag(f.play || f.url, {alt: f.name, lazy: !!n, drag: false, keep: true})}</div>`;
  // A file whose name and size match the version before is "그대로": looked at already, most likely.
  d.viewed = d.viewed || {};
  const before = (w) => vs[vs.indexOf(w) + 1];
  const sameF = (w, f) => { const b = before(w), o = b && (b.files || []).find((q) => q.name === f.name);
    return !!o && f.size != null && o.size === f.size; };
  const seenF = (w, f) => { const x = (d.viewed[w.v] || {})[f.name];
    return x !== undefined ? x : sameF(w, f) && seenF(before(w), f); };
  // 바뀐 것만: offered when some files of this version are as they were and some are not.
  const sgChg = ((n) => n < pics.length ? n : 0)(pics.filter((f) => !sameF(v, f)).length);
  // A lone still image needs none of the video/multi-file chrome (frame stepper, scrub track,
  // resize grip): those left an empty band and a stray handle under the picture. Flag it so the
  // stage shows just the image cleanly.
  const oneStill = pics.length === 1 && !pics.some((f) => f.kind === "video");
  // An HTML report has nothing to put on the stage, so it used to show a bare icon and
  // the reader had to find the small open-link row. Show the page itself instead.
  const page = !pics.length && files.find((f) => f.kind === "html");
  // The same report in the version before (by name, else its lead page): what the words are compared with.
  // Every passage a comment quotes: kept quietly marked in the report (the pen above it turns that off).
  const pgMarks = page ? d.log.filter((e) => e.kind === "comment").map((e) => ({text: quoteOf(attOf(e.text || "").words)?.q, n: e.quote_n | 0}))
    .filter((m, k, all) => m.text && all.findIndex((o) => o.text === m.text && o.n === m.n) === k) : [];
  const pageWas = page && prev ? (prev.files || []).find((f) => f.kind === "html" && f.name === page.name) || (prev.files || []).find((f) => f.kind === "html") : null;
  const otherF = page ? other.filter((f) => f !== page) : other;   // the framed page opens from 더 보기, not from a second row
  const pgTools = page ? `<div class="pgtop"><div class="seg pgsz pc-only" role="group" aria-label="${tl("itemView.22")}"><button data-pw="pc" class="${pageW === "phone" ? "" : "on"}">${tl("itemView.23")}</button><button data-pw="phone" class="${pageW === "phone" ? "on" : ""}">${tl("itemView.24")}</button></div>${zoomCtl("pgzoom", tl("zoom.page"))}</div>` : "";
  if (page && !mount) head(hdT, pgTools + hdMore);
  // Numbered stills pushed one by one (shot_0001.png ...) fold into one tile per run, with a
  // count and a scrub bar, instead of hundreds of tiles (web/seqgroup.js). Nothing stored changes.
  const seqs = SeqGroup.runs(pics);
  const sqTile = (r) => { const fs = pics.slice(r.start, r.end + 1), f = fs[0];
    const on = fs.every((q) => seenF(v, q)), same = fs.every((q) => sameF(v, q));
    return `<div class="sg sq${on ? " seen" : ""}${same ? " same" : ""}" data-sg="${r.start}" data-sge="${r.end}"><button class="sqb press" type="button" aria-label="${tl("seq.tile", {a: f.name, b: fs[fs.length - 1].name, n: r.count})}"><img src="${esc(f.thumb || f.url)}" alt="" loading="lazy" draggable="false"><span class="sgn">${esc(f.name.replace(/\.[^.]+$/, ""))}</span></button><em class="sqc num">${tl("seq.n", {n: r.count})}</em><input class="sqr" type="range" min="${r.start}" max="${r.end}" value="${r.start}" aria-label="${tl("seq.scrub")}"></div>`; };
  const mtV = RD && !mount && vs.length > 1, mtF = RD && !mount && !page && pics.length > 2;
  const mtB = (k, icon, label, val, n, open) => `<button class="mtb press${open ? " on" : ""}" data-mt="${k}" aria-expanded="${open}" aria-controls="${k === "v" ? "vtl" : "sgw"}">${ic(icon)}<span>${label}</span><b class="num">${val}</b>${n ? `<em class="num">${n}</em>` : ""}${ic("chev", "i dn")}</button>`;
  const tray = mtV || mtF ? `<div class="mtray">${mtV ? mtB("v", "stack", tl("itemView.mtv"), v.v, vs.length, mtOpen("v") || cmpToggle) : ""}${mtF ? mtB("f", "grid", tl("itemView.36"), pics.length, 0, mtOpen("f")) : ""}</div>` : "";
  const media = page
    ? `<div class="pgw${pageW === "phone" ? " phone" : ""}" id="pgw" style="--pgz:${pageZ}">${mount ? pgTools : ""}${pageWas || pgMarks.length ? `<div class="pgchg">${pageWas ? `<div class="pgc" id="pgchg"></div>` : ""}${pgMarks.length ? `<button class="pgmk press${pgMarksOn ? " on" : ""}" id="pgmk" aria-pressed="${pgMarksOn}" title="${tl("pgq.marks_t")}">${ic("pen")}<span class="num">${pgMarks.length}</span></button><button class="pgmk press" id="pgnx" aria-label="${tl("pgq.next_t")}" title="${tl("pgq.next_t")}">${ic("chev")}</button>` : ""}</div>` : ""}
        <div class="pgframe"><iframe src="${esc(keyUrl(page.url))}&bar=1" title="${esc(page.name)}" sandbox="allow-scripts allow-popups"></iframe>
        <button class="pgfull press" id="pgfull" aria-pressed="false" aria-label="${tl("itemView.25")}">${ic("full")}<span>${tl("itemView.26")}</span></button></div></div>`
    : pics.length
    ? `<div class="stage" id="stage" data-bg="${stageBg}"><div class="strk">${pics.map(slide).join("")}</div>
        ${pics.length > 1 ? `<button class="snav l press" aria-label="${tl("itemView.27")}">${ic("chev")}</button><button class="snav r press" aria-label="${tl("itemView.28")}">${ic("chev")}</button>` : ""}
        ${zoomCtl("szoom", tl("zoom.result"))}<button class="sfull press" aria-label="${tl("itemView.38")}">${ic("full")}</button></div>
       <div class="sbar"><span class="sname"></span>${flipV ? `<span class="sfgrp"><button class="sflip press" aria-pressed="false" title="${tl("itemView.29", {v: flipV.v})}" aria-label="${tl("itemView.29", {v: flipV.v})}">${ic("swap")}<span>${tl("flipBadge.0", {v: flipV.v})}</span></button><button class="sside press" data-side-v="${esc(flipV.v)}" title="${tl("sside.t", {v: flipV.v})}" aria-label="${tl("sside.t", {v: flipV.v})}">${ic("cols")}</button></span>` : ""}<span class="fstep" hidden><button class="press fplay" aria-label="${tl("itemView.39")}" title="${tl("itemView.40")}">${ic("play")}</button><button class="press" data-fs="-1" aria-label="${tl("itemView.41")}" title="${tl("itemView.42")}">${ic("chev")}</button><button class="press fnow num" aria-label="${tl("itemView.43")}" title="${tl("itemView.44")}"></button><button class="press" data-fs="1" aria-label="${tl("itemView.45")}" title="${tl("itemView.46")}">${ic("chev")}</button><button class="press frate num" aria-label="${tl("itemView.47")}" title="${tl("itemView.48")}">1×</button><button class="press fscn" aria-label="${tl("itemView.49")}" aria-pressed="false" title="${tl("itemView.49")}">${ic("image")}</button></span><span class="smute" hidden title="${tl("stageBg.7")}" aria-label="${tl("stageBg.7")}">${ic("mute")}<span>${tl("stageBg.6")}</span></span><button class="press sbgb" title="${tl("stageBg.5")}" aria-label="${tl("stageBg.5")}"><i class="bgsw"></i><span></span></button><button class="press sguide num" aria-pressed="false" title="${tl("itemView.50")}" aria-label="${tl("itemView.50")}">${ic("rect")}<span>${tl("itemView.51")}</span></button><span class="scount num"></span></div>
       <div class="cmk" id="cmk" hidden aria-label="${tl("itemView.52")}"></div>
       <div class="fstrip" id="fstrip" hidden></div>
       <div class="sgrip" id="sgrip" role="separator" aria-label="${tl("itemView.53")}" title="${tl("itemView.54")}"><i></i></div>
       ${tray}${pics.length > 2 ? `<div class="sgw${sgOpen() ? " open" : ""}" id="sgw"><button class="sgt press" id="sgt" aria-expanded="${sgOpen()}" aria-label="${tl("itemView.35", {n: pics.length})}"><span>${tl("itemView.36")} <b class="num">${pics.length}</b>${tl("itemView.37")} <b class="num" id="vwn">${pics.filter((f) => seenF(v, f)).length}</b></span><em>${sgOpen() ? tl("itemView.30") : tl("itemView.31")}</em>${ic("chev")}</button><div class="sgrid${sgOnly && sgChg ? " only" : ""}" id="sgrid">${sgChg ? `<button class="sgf press${sgOnly ? " on" : ""}" id="sgf" aria-pressed="${sgOnly}">${tl("fgrid.chg", {n: sgChg})}</button>` : ""}${pics.map((f, n) => {
         // Every file of the version at a glance: tap one to put it on the stage above.
         const run = SeqGroup.at(seqs, n); if (run) return n === run.start ? sqTile(run) : "";
         const said = d.log.filter((e) => e.kind === "comment" && e.v === v.v && e.text.startsWith("[" + f.name)).length;
         const on = seenF(v, f), same = sameF(v, f);
         return `<button class="sg press${on ? " seen" : ""}${same ? " same" : ""}" data-sg="${n}" aria-label="${esc(f.name)}${same ? tl("itemView.32") : ""}">${f.kind === "video" && !f.thumb
           ? `<span class="sgv">${ic("play")}</span>` : `<img src="${esc(f.kind === "video" ? f.thumb : f.play || f.url)}" alt="" loading="lazy" draggable="false">`}
           <span class="sgn">${same ? tl("itemView.33") : ""}${esc(f.name.replace(/\.[^.]+$/, ""))}</span>${lostTag(f)}${said ? `<em class="num">${said}</em>` : ""}<span class="vwd" role="checkbox" tabindex="0" data-vw="${esc(f.name)}" aria-checked="${on}" aria-label="${tl("itemView.34")}" title="${tl("itemView.34")}">${ic("check")}</span></button>`; }).join("")}</div></div>` : ""}`
    : `<div class="hero">${ic((KIND[s.kind] || ["doc"])[0])}</div>`;
  // The decision sits in the composer dock, right above the box: approving and asking for a fix
  // are the two answers to a result, so they live in one place at every width.
  const talkB = v.dept ? `<button class="btn weak press" data-talk-dept="${esc(v.dept)}">${tl("dnote.1")}</button>` : "";
  const decideBtns = !latest
    ? `<button class="btn fill press tolatest">${tl("itemView.55")}</button>`
    : done
    ? `<button class="btn press" data-decide="reopen">${tl("itemView.56")}</button>${talkB}`
    : v.status === "approved" && !turnOf(vx)
    ? `${talkB}<button class="btn fill press" data-decide="done">${tl("itemView.57")}</button>`
    : RD   // Lab 4: the three verdicts of the cards, side by side (승인 · 고치기 · 보류)
    ? `${askOpen ? `<button class="btn fill press askgo" data-askgo>${tl("itemView.askgo")}<b class="num">${askOpen}</b></button>` : ""}<span class="rdv rdvd">${["approved", "changes", "hold"].map((k, n) => `<button class="rdvb press" data-decide="${k}" aria-pressed="${v.status === k}">${window.RdV.name(k)}<kbd class="rdk" aria-hidden="true">${n + 1}</kbd></button>`).join("")}</span>`
    : `${askOpen ? `<button class="btn fill press askgo" data-askgo>${tl("itemView.askgo")}<b class="num">${askOpen}</b></button>` : ""}<button class="btn fill press" data-decide="approved">${ic("check")}${tl("STATUS_T.4")}</button>`;
  // One line beside the buttons saying what they do here - the hub's decideNote (R15).
  const decideNote = !latest ? tl("dnote.2") : done ? tl("dnote.3") : v.status === "approved" && !turnOf(vx) ? tl("dnote.4") : "";
  const talkLink = v.dept && latest && !done && v.status !== "approved" ? `<button class="lnk press talkgo" data-talk-dept="${esc(v.dept)}">${ic("chat")}<span>${tl("dnote.1")}</span>${ic("chev")}</button>` : "";
  // The version is a plain label now: the timeline strip below is the picker (no second one).
  const vchip = `${v.v}${vs.length > 1 && !latest ? tl("itemView.63") : ""}`;
  // 버전 타임라인: every version left(oldest)→right(newest), the current kept in view, each with
  // its number, time, and 고침/지시 badges. Tap to view; the 비교 toggle then picks two.
  const verTL = vs.length > 1 ? (() => {
    let ovs = vs.slice().reverse(), bg = timelineBadges(ovs, d.directives);
    // Free keeps every version's DATA (nothing is ever deleted); the strip shows the recent
    // ones and folds the older ones behind a calm "Pro에서 보기" row. version_limit is null
    // on Pro/trial. The version currently in view is never folded away.
    let folded = 0;
    const lim = window.LOOP_PLAN && window.LOOP_PLAN.version_limit;
    if (lim && ovs.length > lim && window.planCan && !planCan("version_history")) {
      let cut = ovs.length - lim;
      const curIdx = ovs.findIndex((w) => w === v);
      if (curIdx >= 0 && curIdx < cut) cut = curIdx;
      if (cut > 0) { folded = cut; ovs = ovs.slice(cut); bg = bg.slice(cut); }
    }
    const proRow = folded ? `<button class="vtli vtlpro press" data-vpro title="${tl("license.pro_version_history")}"><span class="vth">${ic("star")}</span><span class="vtm"><b>${tl("license.older_pro", {n: folded})}</b></span></button>` : "";
    return `<div class="card vtl${cmpToggle ? " picking" : ""}" id="vtl" data-panel="versions"><div class="vtlbar">
      <div class="vtlstrip" id="vtlstrip" role="tablist" aria-label="${tl("itemView.70")}">${proRow}${ovs.map((w, n) => {
        const th = shotOf(w).img, b = bg[n], sel = tlSel.includes(w.v), isNow = w === v, oth = cmp && w === cmp.w;
        return `<button class="vtli press${isNow ? " on" : ""}${oth && !isNow ? " oth" : ""}${sel ? " sel" : ""}" data-vt="${w.v}" role="tab" aria-selected="${isNow}" aria-label="${w.v}${n === ovs.length - 1 ? tl("itemView.64") : ""}">
          <span class="vth${isNow ? " on" : ""}">${th ? imgTag(th, {drag: false}) : `<em class="num">${w.v.replace(/^v0*/, "v")}</em>`}</span>
          <span class="vtm"><b class="num">${w.v}${n === ovs.length - 1 ? tl("itemView.64") : ""}</b><i>${w.final ? `<em class="rs-tag fin">${tl("res.final")}</em>` : w.removed ? `<em class="rs-tag">${tl("res.noFile")}</em>` : ago(w.at)}</i></span>
          ${(b.fixed || b.raised) ? `<span class="vtbg">${b.fixed ? `<em class="vf num" title="${tl("itemView.65")}">${ic("check")}${b.fixed}</em>` : ""}${b.raised ? `<em class="vo num" title="${tl("itemView.66")}">${tl("itemView.67", {raised: b.raised})}</em>` : ""}</span>` : ""}</button>`; }).join("")}</div>
      <button class="vtlcmp press${cmpToggle ? " on" : ""}" id="vtlcmp" aria-pressed="${cmpToggle}" title="${ovs.length === 2 ? tl("itemView.71two") : tl("itemView.71")}">${ic("swap")}<span>${tl("itemView.72")}</span></button></div>
      ${cmpToggle ? `<p class="vtlhint fun">${tlSel.length ? `<b>${tlSel[0]}</b> ${tl("itemView.68")}` : tl("itemView.69")}</p>` : ""}</div>`;
  })() : "";
  const dueI = dueInfo(d.meta?.due);
  // The panel opens on what is needed at first sight (state, the questions, the decision). The
  // item's upkeep - who has it, a due date, finishing, the conversation that pushed it, the page
  // in its own tab - waits behind one 더 보기. A name or a date already set stays in sight.
  const imChip = {
    assignee: `<button class="ichip press" data-imeta="assignee">${ic("user", "i")}<span>${d.meta?.assignee ? esc(d.meta.assignee) : tl("itemView.166")}</span></button>`,
    due: `<button class="ichip press${dueI?.over ? " over" : ""}" data-imeta="due">${ic("cal", "i")}<span>${d.meta?.due ? dueI.label : tl("itemView.167")}</span></button>`,
    fin: latest ? `<button class="ichip ifin press" data-ifin="${d.finished ? 0 : 1}" title="${d.finished ? tl("fin.re.h") : tl("fin.do.h")}">${ic(d.finished ? "undo" : "flag", "i")}<span>${d.finished ? tl("fin.re") : tl("fin.do")}</span></button>` : "",
    made: v.session_id && itemFrom?.sid !== v.session_id ? `<button class="ichip press" data-made="${esc(v.session_id)}" title="${tl("itemView.made_h")}">${ic("chat", "i")}<span>${tl("itemView.made")}</span></button>` : "",
    tab: page ? `<a class="ichip press" href="${esc(page.url)}" target="_blank" rel="noopener" title="${esc(page.name)}">${ic("ext", "i")}<span>${tl("itemView.newtab")}</span></a>` : ""};
  const imTop = [d.meta?.assignee && imChip.assignee, d.meta?.due && imChip.due].filter(Boolean);
  // No name or date set: 더 보기 ends the status line instead of standing alone on a row of its own.
  const imRest = [!d.meta?.assignee && imChip.assignee, !d.meta?.due && imChip.due, imChip.fin, imChip.made, imChip.tab].filter(Boolean);
  const imMore = imRest.length ? `<button class="ichip imore press" data-imore aria-expanded="${imMoreOf === id}">${ic("more", "i")}<span>${imMoreOf === id ? tl("itemView.30") : tl("ui.more")}</span></button>` : "";
  // A redraw of the item on screen (a comment sent, a tick, a meta edit) rebuilt the framed page: the
  // report reloaded and jumped back to its first page. Same item, version and page: the live frame
  // stays in the document (a re-inserted iframe reloads, so it is never detached) and only what is
  // around it is replaced. The caret of a comment being typed comes back as well.
  // The conversation that pushed this version: a link to it, and a follow-up that opens its message
  // box with this item and version already named. Older pushes carry no session id: nothing shows.
  const madeBy = v.session_id ? ` · <button class="lnk press" data-made="${esc(v.session_id)}">${tl("itemView.made")}</button> · <button class="lnk press" data-made="${esc(v.session_id)}" data-follow>${tl("itemView.follow")}</button>` : "";
  const pgKey = page ? `${id}@${v.v}@${page.url}` : "";
  const oldCols = box.firstElementChild?.matches?.(".detailcols.item") ? box.firstElementChild : null;
  const oldMedia = pgKey && oldCols?.firstElementChild?.dataset.pg === pgKey && oldCols.querySelector(".media iframe") ? oldCols.firstElementChild : null;
  const oldPanel = openItem?.id === id ? oldCols?.lastElementChild : null, panelTop = oldPanel ? oldPanel.scrollTop : 0;
  const panelEnd = !!oldPanel && Math.abs(cmGap() ?? 99) <= 32;
  const fa = document.activeElement, typed = fa && fa.id === "cm" && box.contains(fa) ? [fa.selectionStart, fa.selectionEnd] : null;
  /* Lab layout: the version strip sits under the picture, as a filmstrip. */
  const vtlUnder = LAB3 && !mount && !isPhoneW(), vtlIn = LAB3 && !mount;
  const mtCls = `${mtV && !(mtOpen("v") || cmpToggle) ? " mt-v0" : ""}${mtF && !mtOpen("f") ? " mt-f0" : ""}`;
  const itemHtml = `<div class="detailcols item${vtlUnder ? " vtlu" : ""}${mount ? " mounted" : ""}" style="--ipw:${ipw()}px"><div class="media${oneStill ? " still" : ""}${mtCls}">${media}${page || !pics.length ? tray : ""}${vtlIn ? verTL : ""}</div><div class="cgrip igrip" id="igrip" role="separator" aria-orientation="vertical" aria-label="${tl("itemView.91")}" tabindex="0" title="${tl("itemView.92")}"></div><div>
    <div class="htitle"><h2>${esc(d.title)}</h2><p>${done || !stWhy(vx) ? `<span class="tag ${done ? v.status : stCls(vx)}">${done ? tl("hitRow.1") : stName(vx)}</span>` : `<button class="tag why press ${stCls(vx)}" data-stwhy="1" aria-expanded="false"${stTip(vx)}>${stName(vx)}</button>`}${[esc(pname(v.dept || "")), vs.length > 1 ? "" : vchip, ago(v.at)].filter(Boolean).join(" · ")}${lintTag(p + "/" + d.id + "@" + v.v, v.lint)}${imTop.length ? "" : imMore}</p>${done || !stWhy(vx) ? "" : `<p class="stwhy" hidden>${esc(stWhy(vx))}</p>`}
      <div class="imeta${imTop.length ? "" : " rest"}" id="imeta" title="${tl("itemView.175")}">${imTop.join("")}${imTop.length ? imMore : ""}${imRest.length ? `<span class="imrest"${imMoreOf === id ? "" : " hidden"}>${imRest.join("")}</span>` : ""}</div></div>
    ${vtlIn ? "" : verTL}
    ${d.archived && d.superseded_by ? `<a class="card row press" href="#item/${esc(p)}/${encodeURIComponent(d.superseded_by)}"><span class="tx"><div class="t" style="font-size:16px">${tl("itemView.73")}</div><div class="s">${tl("itemView.74", {esc: esc(D.items.find((x) => iid(x) === p + "/" + d.superseded_by)?.title || d.superseded_by)})}</div></span>${ic("chev","i go")}</a>` : ""}
    ${v.summary ? `<div class="card isumwrap"><div class="quote isum" title="${tl("itemView.75")}">${esc(v.summary)}</div><button class="lnk press isummore" aria-expanded="false">${tl("ui.more")}</button></div>` : ""}
    ${vfx ? (vfx.texts.length ? `<details class="card vfix"><summary class="vfixs"><span>${tl("vfix.t", {v: v.v, n: vfx.n})}</span>${ic("chev", "i dn")}</summary><ul>${vfx.texts.map((t) => `<li>${esc(t)}</li>`).join("")}</ul></details>` : `<div class="card vfix"><p class="vfixs">${tl("vfix.t", {v: v.v, n: vfx.n})}</p></div>`) : ""}
    ${v.later ? `<div class="card"><div class="quote" style="margin-top:18px"><span class="warn">${tl("itemView.76")}</span> · ${esc(laterText(v.later, d.directives))}</div></div>` : ""}
    ${dirCard}
    ${askedO.length ? `<details class="card prevask" data-panel="history" ${askedO.every((e) => isFixed(e.id)) ? "" : "open"}><summary class="ch"><h2>${tl("itemView.78", {v: prev.v})}</h2><span class="n num" id="pacount">${askedO.filter((e) => isFixed(e.id)).length} / ${askedO.length}</span><span class="sp"></span>${ic("chev", "i dn")}</summary>
      ${askedO.map((e) => `<div class="row note pa${isFixed(e.id) ? " ok" : ""}"><button class="ck press" data-fx="${esc(e.id)}" role="checkbox" aria-checked="${isFixed(e.id)}" aria-label="${tl("itemView.77")}">${CKM}</button><span class="tx"><div class="nt">${noteText(e, e.v, pics)}</div></span></div>`).join("")}
      <p class="hint2 pahint">${tl("itemView.79")}</p></details>` : ""}
    ${otherF.length ? `<div class="card">${otherF.map((f) => `<a class="row press" href="${esc(f.url)}" target="_blank" rel="noopener"><span class="ico sm c-grey">${ic((KIND[f.kind] || ["doc"])[0])}</span><span class="tx"><div class="t" style="font-size:16px">${esc(f.name)}${lostTag(f)}</div><div class="s">${esc(f.kind || tl("itemView.36"))}</div></span>${ic("ext","i go")}</a>`).join("")}</div>` : ""}
    <div class="card itab" data-panel="comments"><div class="seg wide" id="itabs" role="tablist">${tabs.map(([k, n, c]) => `<button role="tab" aria-selected="${k === tab}" class="${k === tab ? "on" : ""}" data-v="${k}">${n}${c ? ` <span class="num">${c}</span>` : ""}</button>`).join("")}</div><div id="tbody"></div></div>
    ${nextCard(id)}
    <details class="card ixtra" id="ixtra"${xtraOpenOf === id ? " open" : ""}><summary class="ch"><span class="xl">${tl("itemView.xtra")}</span><span class="sp"></span>${ic("chev", "i dn")}</summary></details>
    <div class="cdk${latest && askOpen && !done ? " asking" : ""}" id="cdk"><div class="card cdkc">
      <div class="decide cdkd"><p class="dnote">${decideNote}${talkLink}</p><div class="in">${decideBtns}${mount && nextOf(id) ? `<button class="btn press nextb" id="nextb" aria-label="${tl("nextCard.3")}" title="${tl("itemView.90")}">${ic("chev")}</button>` : ""}</div></div>
      ${pics.length > 1 ? `<div class="tgt"><button class="tg press" data-tgt="file"></button><button class="tg press" data-tgt="all">${tl("itemView.105")}</button></div>` : ""}
      <div class="cdock${pics.length ? "" : " quiet"}${dockOpenOf === id ? " open" : ""}" id="cdock"><div class="pinrow"><button class="opt press" id="cmimg" aria-label="${tl("cmImg.1")}" title="${tl("cmImg.2")}">${ic("image")}<span>${tl("cmImg.1")}</span></button><input type="file" id="cmfile" accept="image/*" multiple hidden>${pics.length ? `<button class="opt press" id="drawbtn" aria-label="${tl("itemView.107")}" title="${tl("itemView.107")} (D)">${ic("pen")}<span>${tl("itemView.107")}</span></button><button class="opt press" id="pinbtn" aria-label="${tl("itemView.106")}" title="${tl("itemView.106")} (P)">${ic("pin")}<span>${tl("itemView.106")}</span></button>` : ""}<button class="opt press" id="cmsplit" hidden aria-pressed="false" title="${tl("cmSplit.1")}">${ic("list")}<span></span></button><button class="opt press" id="cmpx">${ic("x")}<span>${tl("itemView.114")}</span></button></div>
        <div class="drawchip" id="drawchip" hidden></div>
        <div class="qchip" id="qchip" hidden></div>
        <div class="cmatt" id="cmatt" hidden></div>
        <div class="cbox"><textarea id="cm" rows="1" enterkeyhint="send" placeholder="${pics.length > 1 ? tl("itemView.109") : page ? tl("pgq.ph") : tl("itemView.110")}"></textarea><button class="btn fill press" id="cmadd" disabled title="${tl("itemView.112")}">${tl("nextCard.6")}</button></div>
        <div class="splitpv" id="splitpv" hidden aria-live="polite"></div></div>
      ${pics.some((f) => f.kind === "video") ? `<p class="fun" id="cmwhen">${tl("itemView.111") + tl("cmWhen.5")}</p>` : ""}</div></div>
  </div></div>
  ${keyBarHtml({video: pics.some((f) => f.kind === "video"), pics: pics.length, page: !!page, decide: latest && !done && v.status !== "approved", next: !!nextOf(id), vers: vs.length > 1, cmp: cmpOk, mount})}
  <div class="ctapad"></div>`;
  if (oldMedia) {
    const t = document.createElement("div"); innerSet.call(t, itemHtml);
    const nc = t.firstElementChild;
    oldCols.className = nc.className; oldCols.style.cssText = nc.style.cssText;
    while (oldMedia.nextSibling) oldMedia.nextSibling.remove();
    // The kept media column holds the version strip on a wide screen: the page stays, the strip is the new one.
    const nvtl = nc.firstElementChild.querySelector("#vtl"), ovtl = oldMedia.querySelector("#vtl");
    if (nvtl && ovtl) ovtl.replaceWith(nvtl);
    nc.firstElementChild.remove(); oldCols.append(...nc.childNodes);
    while (oldCols.nextSibling) oldCols.nextSibling.remove();
    nc.remove(); box.append(...t.childNodes);
  } else box.innerHTML = itemHtml;
  if (pgKey) { const m = box.querySelector(".detailcols.item > .media"); if (m) m.dataset.pg = pgKey; }
  wireItemGrip();
  if (pageWas) pgChgFill(box.querySelector("#pgchg"), pageWas.url, page.url, prev.v, v.v);
  box.querySelectorAll(".mtb").forEach((b) => b.onclick = () => mtSet(b.dataset.mt, !b.classList.contains("on")));
  box.querySelector("#sgf")?.addEventListener("click", (e) => { sgOnly = !sgOnly;
    e.currentTarget.classList.toggle("on", sgOnly); e.currentTarget.setAttribute("aria-pressed", sgOnly); box.querySelector("#sgrid").classList.toggle("only", sgOnly); });
  box.querySelector("#pgmk")?.addEventListener("click", (e) => { pgMarksOn = !pgMarksOn; lsSet("pg-marks-off", pgMarksOn ? "" : "1");
    e.currentTarget.classList.toggle("on", pgMarksOn); e.currentTarget.setAttribute("aria-pressed", pgMarksOn); pgMarksSend(); });
  // One press walks the quoted passages in turn, so a phone needs no trip to the comment list.
  box.querySelector("#pgnx")?.addEventListener("click", () => { const l = openItem.quotes, m = l[pgMarkAt++ % l.length]; if (m) pgFind(m.text, m.n); });
  box.querySelectorAll("[data-talk-dept]").forEach((b) => b.onclick = () => nav("project/" + encodeURIComponent(b.dataset.talkDept)));
  box.querySelectorAll("[data-made]").forEach((b) => b.onclick = async () => {
    const sid = b.dataset.made, s = await get("/api/project/session?id=" + encodeURIComponent(sid)).catch(() => null);
    if (!s || !s.found || !s.project) return toast(tl("itemView.madeGone"));
    if (b.hasAttribute("data-follow")) window.pjDraft?.(sid, tl("itemView.followDraft", {t: d.title, v: v.v, id: p + "/" + d.id}));
    nav("project/" + encodeURIComponent(s.project) + "/" + encodeURIComponent(sid));
  });
  box.querySelectorAll("[data-imeta]").forEach((b) => b.onclick = () => wireImetaEdit(box, b.dataset.imeta, p, i, d));
  box.querySelector("[data-imore]")?.addEventListener("click", (e) => { const b = e.currentTarget, r = box.querySelector(".imrest"), on = r.hidden;
    imMoreOf = on ? id : ""; r.hidden = !on; r.classList.toggle("in", on);     // in place, a short fade (v2.css .imrest.in)
    b.setAttribute("aria-expanded", String(on)); b.querySelector("span").textContent = on ? tl("itemView.30") : tl("ui.more"); });
  box.querySelectorAll("[data-ifin]").forEach((b) => b.onclick = () => itemFin(p, i, b.dataset.ifin === "1"));
  // 버전 타임라인: view a version, or (with 비교 on) pick two and open the comparison. The current
  // one is scrolled into sight within the strip, never moving the page.
  const latestV = vs[0].v;
  const tlStrip = box.querySelector("#vtlstrip");
  if (tlStrip) {
    const now = tlStrip.querySelector(".vtli.on");
    if (now) {
      const centre = (how) => tlStrip.scrollTo({left: tlStrip.scrollLeft + now.getBoundingClientRect().left - tlStrip.getBoundingClientRect().left - (tlStrip.clientWidth - now.offsetWidth) / 2, behavior: how});
      centre(RM() ? "auto" : "smooth");
      // The strip narrows once the row beside it is laid out; the scroll was already clamped
      // to the wider strip, which left the newest version cut off at the right edge.
      let w = tlStrip.clientWidth;
      new ResizeObserver(() => { if (tlStrip.clientWidth !== w) { w = tlStrip.clientWidth; centre("auto"); } }).observe(tlStrip);
    }
    tlStrip.querySelectorAll("[data-vt]").forEach((b) => b.onclick = () => {
      const vv = b.dataset.vt;
      if (!cmpToggle) { if (vv === latestV) delete verPick[id]; else verPick[id] = vv; again(); return; }
      if (tlSel.includes(vv)) { tlSel = tlSel.filter((x) => x !== vv); b.classList.remove("sel"); }
      else tlSel.push(vv);
      if (tlSel.length >= 2) {
        const [a, c2] = tlSel.slice(0, 2).sort();     // a = older, c2 = newer (zero-padded names sort right)
        verPick[id] = c2; cmpPick[id] = a; cmpToggle = false; tlSel = [];
        cvAuto = id; cvScroll = scrollY;      // picking the pair opens the compare workspace once the item has redrawn
        again();
      } else {
        b.classList.toggle("sel", tlSel.includes(vv));
        const h = box.querySelector(".vtlhint"); if (h) h.innerHTML = tlSel.length ? `<b>${esc(tlSel[0])}</b> ${tl("itemView.68")}` : tl("itemView.69");
      }
    });
    box.querySelector("#vtlcmp").onclick = () => {
      // Only two versions: there is no pair to pick, so 비교 opens them side by side straight away.
      const vs = [...tlStrip.querySelectorAll("[data-vt]")].map((b) => b.dataset.vt);
      if (!cmpToggle && vs.length === 2) { const [a, c2] = vs.sort(); verPick[id] = c2; cmpPick[id] = a; tlSel = []; cvAuto = id; cvScroll = scrollY; return again(); }
      cmpToggle = !cmpToggle; tlSel = []; again(); };
    tlStrip.querySelector("[data-vpro]")?.addEventListener("click", () => window.proSheet && proSheet("version_history"));
  }
  // 봤음 per file: a tap on the check (not the thumb) ticks it; kept on the item so the phone and
  // the PC agree. A file carried over unchanged shows its old tick until it is set here.
  const tickVw = async (el) => { const f = pics.find((q) => q.name === el.dataset.vw); if (!f) return;
    const on = !seenF(v, f), was = (d.viewed[v.v] || {})[f.name], put = (x) => { const m = d.viewed[v.v] ||= {};
      if (x === undefined) delete m[f.name]; else m[f.name] = x;
      el.setAttribute("aria-checked", seenF(v, f)); el.closest(".sg").classList.toggle("seen", seenF(v, f));
      document.getElementById("vwn").textContent = pics.filter((q) => seenF(v, q)).length; };
    put(on);
    try { await post("/api/viewed", {p, i, v: v.v, name: f.name, on}); } catch (e) { put(was); toast(e.message); } };
  box.querySelectorAll("[data-vw]").forEach((el) => { el.onclick = (e) => { e.stopPropagation(); tickVw(el); };
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); tickVw(el); } }; });
  // The phone's bottom bar: on to the next result without deciding, no scrolling down to the card.
  document.getElementById("ixtra")?.addEventListener("toggle", (e) => { xtraOpenOf = e.target.open ? id : ""; });
  document.getElementById("dirsfold")?.addEventListener("toggle", (e) => { dirsOpenOf = e.target.open ? id : ""; });
  document.getElementById("nextb")?.addEventListener("click", () => { const n = nextOf(id); if (n) { autoPlay = true; nav("item/" + iid(n)); } });
  // Comments on this version that name a moment: dots along the video, tap to go there. The
  // last version's requests not ticked off yet show too, hollow, to look at the same spot.
  const onV = d.log.filter((e) => e.kind === "comment" && e.v === v.v);
  const spots = () => { const open = asked.filter((e) => !isFixed(e.id));
    return {marks: onV.map((e) => ({...whenTag(e.text), text: e.text})).concat(open.map((e) => ({...whenTag(e.text), text: e.text, prev: true}))).filter((m) => m.tag),
      pins: onV.map(pinOfE).filter(Boolean).concat(open.map(pinOfE).filter(Boolean).map((q) => ({...q, prev: true})))}; };
  openItem = {id, p, i, v: v.v, rev: d.rev ?? d.review?.rev, log: d.log, latest, dept: v.dept, reject: v.reject || x?.reject || [], pics, status: v.status, archived: d.archived,
    page: !!page, owed: latest && !done ? dOpen.map(dtxt) : [], quotes: pgMarks,
    vers: vs.map((w) => w.v), alt: flipV && {v: flipV.v, files: flipV.files || []},
    olds: vs.filter((w) => w.v < v.v && w.v !== flipV?.v).reverse().map((w) => ({v: w.v, files: w.files || []})), ...spots()};
  const it = openItem;
  // Feature modules attach per-item UI here (see window.LOOP_SETTINGS for the settings slot).
  // tabs.js normalises the list (functions only, first wins); a block that throws is skipped and
  // never breaks the core item view.
  ((typeof loopItemView === "function" ? loopItemView() : (window.LOOP_ITEM_VIEW || []))).forEach((f) => { try { f(box, it, d); } catch (e) { console.error(e); } });
  document.querySelectorAll("[data-fx]").forEach((b) => b.onclick = () => { const on = b.getAttribute("aria-checked") !== "true";
    setFixed(b.dataset.fx, on); b.setAttribute("aria-checked", on); b.closest(".row").classList.toggle("ok", on);
    const n = asked.filter((e) => isFixed(e.id)).length; document.getElementById("pacount").textContent = `${n} / ${asked.length}`;
    if (on && n === asked.length) toast(tl("itemView.98"), 2200, "confirm");
    Object.assign(it, spots()); drawPins(); stageVideo()?.dispatchEvent(new Event("seeked")); });
  // The counts in the 지시 header go to the first row of their kind, lit up for a moment.
  box.querySelectorAll("[data-dj]").forEach((b) => b.onclick = () => {
    const r = box.querySelector(`.dirs .dir.${b.dataset.dj}`); if (!r) return;
    r.closest("details.dirs").open = true;
    r.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"});
    r.classList.remove("hl"); void r.offsetWidth; r.classList.add("hl"); setTimeout(() => r.classList.remove("hl"), 1200); });
  // 지시 verdicts: 통과 marks a claimed fix verified, 다시 reopens it and re-sends the ask.
  // The verdict is bound to the version in view (latestV): if a newer one arrived meanwhile,
  // the server answers 409 and the page reloads so the fix is judged against the new cut.
  // Each verdict carries the directive's revision as this screen read it (when the server gives
  // one): a fix re-claimed or re-worded in between answers 409 and the change is shown first.
  const dirOf = (id) => dirs.find((x) => x.id === id) || {};
  // v is the version that claimed the fix (fixed_in; the latest one for an unclaimed ask).
  // reason: the optional "what is still off" from the fix check, kept with the 아직.
  const sayDir = (id, ok, rev, reason) => post("/api/directive", {p, i, id, v: dirOf(id).fixed_in || latestV, ok, verdict: ok ? "ok" : "again", rev: rev ?? dirOf(id).rev,
    ...(!ok && reason ? {reason} : {})});
  // Deciding again on this screen only makes sense while the claim is the one shown here.
  const sameClaim = (id) => (b) => !b.stale && (b.fixed_in ?? null) === (dirOf(id).fixed_in ?? null);
  const dirConflict = (e, id, ok, b) => { if (!isConflict(e)) { toast(e.message); if (b) b.disabled = false; return; }
    conflictSheet(e.body, {v: latestV, log: d.log, can: sameClaim(id), again: ok ? tl("conflict.ok") : tl("conflict.again"),
      retry: async (cb) => { await sayDir(id, ok, cb.directive_rev); toast(ok ? tl("verdict.1") : tl("itemView.100")); await load(); again(); },
      reload: async () => { await load(); again(); }}); };
  box.querySelectorAll(".dir .dzz").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await post("/api/directive", {p, i, id: b.dataset.dz, snooze: !dirOf(b.dataset.dz).snoozed}); await load(); again(); }
    catch (e) { toast(e.message); b.disabled = false; } });
  box.querySelectorAll(".dir .dyes").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await sayDir(b.dataset.dv, true); again(); }
    catch (e) { dirConflict(e, b.dataset.dv, true, b); } });
  box.querySelector(".dall")?.addEventListener("click", async (e) => { e.currentTarget.disabled = true;
    try { for (const x of dClaim) await sayDir(x.id, true); toast(tl("itemView.99", {n: dClaim.length}), 2200, "confirm"); again(); }
    catch (err) { if (isConflict(err)) conflictSheet(err.body, {v: latestV, log: d.log, reload: async () => { await load(); again(); }}); else toast(err.message); } });
  box.querySelectorAll(".dir .dno").forEach((b) => b.onclick = async () => { b.disabled = true;
    try { await sayDir(b.dataset.dv, false); toast(tl("itemView.100"), 2200, "resent"); again(); }
    catch (e) { dirConflict(e, b.dataset.dv, false, b); } });
  // 고쳤다고 함 → the fix-check workspace: the version the ask was written on, left; the version
  // that says it fixed it, right; the ask, what changed, and 맞아/아직 underneath.
  box.querySelectorAll(".dir [data-fv]").forEach((b) => b.onclick = (e) => { e.stopPropagation();
    const x = dirOf(b.dataset.fv); if (x.id) openFixVerify(x, d, vs, {p, i, latestV, sayDir}); });
  // Feature scripts (wake.js) decorate each directive row with a delivery-state chip and actions.
  (window.LOOP_DIRECTIVE_DECOR || []).forEach((f) => { try { f(box, p, i, again); } catch (e) { console.error(e); } });
  document.querySelector(".sflip")?.addEventListener("click", flipStage);
  // 나란히: straight into the side-by-side workspace against the version the flip chip names.
  document.querySelector(".sside")?.addEventListener("click", (e) => openCmpWorkspace(x, vs, e.currentTarget.dataset.sideV, v.v, undefined, "side"));
  const body = document.getElementById("tbody");
  const draw = (k) => {
    tabPick[id] = k;
    // On a phone the comparison replaces the sticky picture (it would sit on top of the compare box).
    box.querySelector(".detailcols.item")?.classList.toggle("tab-cmp", k === "cmp");
    // 대화 has its own message box: the comment dock steps aside so one box, one 보내기 shows.
    box.querySelector(".detailcols.item")?.classList.toggle("tab-chat", k === "chat");
    // Open questions on screen: their 답 보내기 is the one send button; the comment box waits behind 코멘트.
    box.querySelector(".detailcols.item")?.classList.toggle("tab-ask", k === "ask" && askOpen > 0);
    if (!mount && k !== "cmp") setItemHash(id);   // leaving 비교 drops the ?cmp=… from the address
    document.querySelectorAll("#itabs button").forEach((b) => { b.classList.toggle("on", b.dataset.v === k); b.setAttribute("aria-selected", b.dataset.v === k); });
    if (k === "ask") {
      const ed = askEdit[id] || (askEdit[id] = new Set());
      body.innerHTML = `<div class="ask" id="ask">${ask.map((q, qi) => { const a = askAns[qi];
        // Answered: folded to the answer on record. 고치기 opens it again with the answer filled in.
        if (a && !ed.has(qi)) return `<div class="aq done" data-q="${qi}"><div class="qt">${esc(q.q)}</div><div class="adone"><span class="aa">${ic("check")}<b>${esc(a.text)}</b></span><span class="s">${tl("ask.done_at", {t: ago(a.at)})}</span><button class="lnk press" data-aedit="${qi}">${tl("ask.edit")}</button></div></div>`;
        // Not answered yet: the recommended choice is already picked, so taking the advice is one
        // press on 답 보내기 (data-new: nothing on record, so the pick itself is what gets sent).
        const oi0 = a ? (q.options || []).findIndex((o) => a.text === o || a.text.startsWith(o + " · ")) : Number.isInteger(q.rec) && (q.options || [])[q.rec] ? q.rec : -1, note0 = a ? (oi0 >= 0 ? a.text.slice(q.options[oi0].length).replace(/^ · /, "") : a.text) : "";
        return `<div class="aq" data-q="${qi}" data-pick="${oi0}"${a ? "" : " data-new"}><div class="qt">${esc(q.q)}</div>${(q.options || []).length ? `<div class="aopts">${q.options.map((o, oi) => `<button class="opt press${oi === oi0 ? " on" : ""}" data-a="${oi}">${esc(o)}${q.rec === oi ? `<em>${tl("itemView.101")}</em>` : ""}</button>`).join("")}</div>` : ""}
        <textarea class="anote" rows="1" placeholder="${(q.options || []).length ? tl("itemView.102") : tl("itemView.103")}">${esc(note0)}</textarea></div>`; }).join("")}
        ${askOpen || ed.size ? `<div style="padding:6px 16px 20px"><button class="btn xl fill press" id="asend" disabled style="width:100%">${tl("itemView.104")}</button></div>` : `<div style="height:10px"></div>`}</div>`;
      body.querySelectorAll("[data-aedit]").forEach((b) => b.onclick = () => { ed.add(+b.dataset.aedit); draw("ask"); });
      wireAsk(it, ask);
    } else if (k === "chat") {
      window.LOOP_ITEM_CHAT(body, it);      // the live chat with the session behind this result (custom.js)
    } else if (k === "cm") {
      const noteRow = (e) => e.kind === "astra"
        ? `<div class="row note astra"><span class="tx"><div class="nt"><span class="albl">${tl("itemView.115", {ic: ic("spark", "i")})}</span> ${noteText(e, v.v, pics)}</div><div class="s">${tl("itemView.116", {v: e.v, ago: ago(e.at)})}</div></span><span class="nbtns"><button class="ib press afwd" data-fwd="${esc(e.id)}" aria-label="${tl("itemView.117")}" title="${tl("itemView.118")}">${ic("up")}</button><button class="ib press ndel" data-del="${esc(e.id)}" aria-label="${tl("itemView.119")}" title="${tl("itemView.120")}">${ic("x")}</button></span></div>`
        : `<div class="row note" data-eid="${esc(e.id)}"><span class="tx"><div class="nt">${noteText(e, v.v, pics)}</div><div class="s">${e.kind === "message" ? tl("itemView.121") : e.ack ? tl("itemView.122") : e.delivered ? tl("itemView.123") : e.sent ? tl("itemView.124") : tl("itemView.125")} · ${esc(e.v)} · <time data-note-at="${esc(e.at)}">${ago(e.at)}</time>${e.fixed_in ? ` · <b class="dc">${tl("itemView.7", {esc: esc(e.fixed_in)})}</b>` : ""}${e.edited ? ` · <span class="ned" title="${esc(e.prev_text ? tl("cmEdit.9", {t: e.prev_text.slice(0, 200)}) : "")}">${e.reedited ? tl("cmEdit.4") : tl("cmEdit.3")}</span>` : ""}</div></span>${e.kind === "comment" ? `<span class="nbtns"><button class="ib press nedit" data-edit="${esc(e.id)}" aria-label="${tl("cmEdit.1")}" title="${e.delivered || e.ack ? tl("cmEdit.2") : tl("cmEdit.1")}">${ic("pen")}</button>${!e.delivered && !e.ack ? `<button class="ib press ndel" data-del="${esc(e.id)}" aria-label="${tl("itemView.126")}" title="${tl("itemView.127")}">${ic("x")}</button>` : ""}</span>` : ""}</div>`;
      // Oldest first, as a talk reads: a comment just sent lands at the end, right above the box.
      const fo = cmFold(allNotes, cmOpen() || lfOn, cmSeenOf(id, allNotes)), canFold = allNotes.length > 1 && !lfOn;
      const pk = fo.peek && attOf(fo.peek.text), pv = pk ? esc(pk.words.replace(/[*_`#>]+/g, "").replace(/\s+/g, " ").trim() || tl("itemView.3")) : fo.folded ? tl("cmFold.prev", {n: allNotes.length - fo.keep.length}) : "";
      const foldBtn = fo.folded ? `<button class="cmfold press${cmFade ? " in" : ""}" id="cmfold" aria-expanded="false" aria-label="${tl("cmFold.open", {n: allNotes.length})}">${fo.fresh ? `<em class="cmnew num">${tl("cmFold.new", {n: fo.fresh})}</em>` : ""}<span class="fpv">${pv}</span>${fo.peek ? `<span class="s">${ago(fo.peek.at)}</span>` : ""}${ic("chev", "i dn")}</button>`
        : canFold ? `<button class="cmfold open press" id="cmfold" aria-expanded="true"><span class="fpv">${tl("itemView.30")}</span>${ic("chev", "i dn")}</button>` : "";
      if (fo.folded) body.innerHTML = `${foldBtn}${fo.keep.map(noteRow).join("")}
        ${unsent.length ? `<div class="sendbar"><span>${tl("itemView.128")} <b class="num">${unsent.length}</b></span><button class="btn press" id="cmsend">${tl("itemView.129", {ic: ic("up")})}</button></div>` : `<div style="height:8px"></div>`}`;
      else body.innerHTML = `${foldBtn}<div class="cmlist${cmFade ? " in" : ""}">${LF.length > 1 ? `<div class="chips lfil" data-sk="cf" role="group" aria-label="${tl("itemView.130")}">${LF.map(([k, n, c]) => `<button class="chip press${k === lf[0] ? " on" : ""}" data-lf="${k}" aria-pressed="${k === lf[0]}">${n}${k === "all" ? "" : ` <em class="num">${c}</em>`}</button>`).join("")}</div>` : ""}
        ${notes.length ? (hidden ? `<button class="btn press lmore" id="lmore">${tl("itemView.131", {hidden})}</button>` : "") + notes.map(noteRow).join("") + `<div style="height:8px"></div>`
          : `<div class="fun cmnone">${ic("chat")}<span>${tl("itemView.132")}</span></div>`}
        </div>${unsent.length ? `<div class="sendbar"><span>${tl("itemView.128")} <b class="num">${unsent.length}</b></span><button class="btn press" id="cmsend">${tl("itemView.129", {ic: ic("up")})}</button></div>` : ""}`;
      cmFade = false;
      // Folding is the reader's own setting (this browser), not the item's: it holds from one result to the next.
      document.getElementById("cmfold")?.addEventListener("click", () => { lsSet("v2-cmopen", fo.folded ? "1" : ""); cmSeen.at = allNotes[allNotes.length - 1]?.at || cmSeen.at; cmFade = !RM(); draw("cm");
        document.getElementById("cmfold")?.focus({preventScroll: true}); });
      // A long comment shows three lines and a 더 보기; a picture or an edit box is never cut.
      body.querySelectorAll(".row.note .nt").forEach((nt) => { const row = nt.closest(".row"), eid = row.dataset.eid || row.querySelector("[data-fwd]")?.dataset.fwd;
        if (!eid || nt.querySelector(".npics")) return;
        const full = cmFull.has(eid); nt.classList.toggle("clamp", !full);
        if (!full && nt.scrollHeight <= nt.clientHeight + 4) return nt.classList.remove("clamp");
        const b = document.createElement("button"); b.className = "lnk press ntmore"; b.textContent = full ? tl("itemView.30") : tl("ui.more"); b.setAttribute("aria-expanded", String(full));
        b.onclick = () => { const on = !cmFull.has(eid); on ? cmFull.add(eid) : cmFull.delete(eid); nt.classList.toggle("clamp", !on); b.textContent = on ? tl("itemView.30") : tl("ui.more"); b.setAttribute("aria-expanded", String(on)); };
        nt.after(b); });
      document.getElementById("lmore")?.addEventListener("click", () => { logAll[id] = true; again(); });
      body.querySelectorAll("[data-lf]").forEach((b) => b.onclick = () => { logF[id] = b.dataset.lf; again(); });
      // 부서에 전달: the reader chooses to send Astra's opinion on as a comment (a directive).
      body.querySelectorAll("[data-fwd]").forEach((b) => b.onclick = async () => {
        const e = allNotes.find((x) => x.id === b.dataset.fwd); if (!e) return; b.disabled = true;
        try { await post("/api/comment", {p, i, v: v.v, text: tl("itemView.133") + e.text}); await sendNow(it); again(); toast(tl("itemView.134"), 2200, "delivered"); }
        catch (err) { toast(err.message); b.disabled = false; } });
      gitCard(body, p, i, v.v);
      // A comment no session has read yet can still be taken back (a typo, the wrong item).
      body.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => { b.disabled = true;
        try { const gone = (await post("/api/delete", {p: it.p, i: it.i, id: b.dataset.del})).entry; again();
          toastAct(tl("itemView.135"), tl("toggleFav.3"), async () => {
            try { await post("/api/restore", {p: it.p, i: it.i, entry: gone}); again(); } catch (e) { toast(e.message); } });
        } catch (e) { toast(e.message); b.disabled = false; } });
      // 고치기: the comment's words open in place. Before a session took it this is a quiet fix;
      // after, the corrected ask goes to the session again, labelled as a correction (C06).
      body.querySelectorAll("[data-edit]").forEach((b) => b.onclick = () => {
        const e = allNotes.find((x) => x.id === b.dataset.edit), row = b.closest(".row"); if (!e || !row || row.querySelector(".nedbox")) return;
        const nt = row.querySelector(".nt"), was = nt.innerHTML, taken = !!(e.delivered || e.ack);
        nt.classList.remove("clamp"); row.querySelector(".ntmore")?.remove();
        nt.innerHTML = `<div class="nedbox"><textarea class="nedta" rows="3" aria-label="${tl("cmEdit.1")}"></textarea><div class="nedrow"><span class="fun">${taken ? tl("cmEdit.5") : tl("cmEdit.6")}</span><button class="btn press" data-ecx>${tl("cmEdit.7")}</button><button class="btn fill press" data-eok>${tl("cmEdit.8")}</button></div></div>`;
        const ta = nt.querySelector("textarea"), ok = nt.querySelector("[data-eok]");
        ta.value = e.text; ta.style.height = Math.min(ta.scrollHeight + 2, 260) + "px"; ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
        const close = () => { nt.innerHTML = was; };
        const save = async () => { const text = ta.value.trim(); if (!text || text === e.text.trim()) return close(); ok.disabled = true;
          try { const r = await post("/api/edit", {p: it.p, i: it.i, id: e.id, text});
            if (r.entry?.reedited && !r.entry.delivered) { toast(tl("cmEdit.10"), 2200, "confirm"); await sendNow(it); } else toast(tl("cmEdit.11"), 2200, "confirm");
            again(); }
          catch (err) { toast(err.message); ok.disabled = false; } };
        nt.querySelector("[data-ecx]").onclick = close; ok.onclick = save;
        ta.addEventListener("keydown", (k) => { if (k.key === "Escape") { k.preventDefault(); close(); } else if (k.key === "Enter" && (k.ctrlKey || k.metaKey)) { k.preventDefault(); save(); } });
      });
      const send = document.getElementById("cmsend");
      if (send) send.onclick = async () => { send.disabled = true;
        try { await sendNow(it); again(); } catch (e) { toast(e.message); send.disabled = false; } };
    } else {
      const side = (f, img, k) => cv ? `<video class="${k}" src="${esc(f.play || f.url)}" muted loop playsinline preload="auto"></video>` : `<div class="${k}" style="background-image:url('${esc(img)}')"></div>`;
      // 차이(pixel diff) now covers two videos too: their current frames are diffed live, so it
      // joins the modes for both stills and videos.
      const isVid = !!cv, MODES = CMPM.concat([["diff", tl("itemView.136")]]);
      let eff = cmpMode(); if (!MODES.some((m) => m[0] === eff)) eff = "wipe";
      // 지시 위치 겹쳐 보기: the pins/moments the previous version's comments carried, to lay over
      // the newer frame with a toggle; each says whether a later version claimed it fixed.
      const ov = overlayFromPrev(d.log.filter((e) => e.kind === "comment" && e.v === pv.v && !/^\[(답|확정)\]/.test(e.text)), v.v);
      // What the newer version reports it changed, read beside the picture so a look explains itself.
      const chg = versionChanges(v, pv, d.directives);
      const chgHtml = (chg.summary || chg.fixed.length || chg.later) ? `<div class="vchg"><b>${tl("itemView.139", {esc: esc(chg.to)})}</b>${chg.summary ? `<p>${esc(chg.summary)}</p>` : ""}${chg.fixed.length ? `<ul>${chg.fixed.slice(0, 4).map((t) => `<li>${esc(t.slice(0, 80))}</li>`).join("")}${chg.fixed.length > 4 ? `<li class="more">${tl("itemView.137", {p0: chg.fixed.length - 4})}</li>` : ""}</ul>` : ""}${chg.later ? `<p class="lt">${tl("itemView.138", {esc: esc(laterText(chg.later, d.directives))})}</p>` : ""}</div>` : "";
      // The pair steps in place, one version at a time per side: on a phone the timeline that
      // also picks it sits a screen above this tab (user, 2026-09-29).
      const ordA = cmps.map((c) => c.w).reverse(), ordB = vs.slice().reverse().filter((w) => w !== pv);
      const stepOf = (ord, cur, dir) => ord[ord.indexOf(cur) + dir] || null;
      const sw = (k, ord, cur) => `<button class="ib press" data-cst="${k}" data-d="-1" aria-label="${k === "a" ? tl("cmpsw.1") : tl("cmpsw.2")}"${stepOf(ord, cur, -1) ? "" : " disabled"}>${ic("chev", "i lf")}</button><b class="num">${esc(cur.v)}</b><button class="ib press" data-cst="${k}" data-d="1" aria-label="${k === "a" ? tl("cmpsw.3") : tl("cmpsw.4")}"${stepOf(ord, cur, 1) ? "" : " disabled"}>${ic("chev")}</button>`;
      body.innerHTML = `<div class="cmptop"><span class="cmpsw" role="group" aria-label="${tl("cmpsw.5")}">${sw("a", ordA, pv)}<span class="ar">→</span>${sw("b", ordB, v)}</span><span class="grow"></span><span class="cmpres" id="cmpres" hidden></span><button class="btn sm fill press" id="cvopen" title="${tl("cv.open.t")}">${ic("full")}${tl("cv.open")}</button><button class="lnk press" id="cmpcopy" title="${tl("itemView.145")}">${tl("itemView.146", {ic: ic("link")})}</button></div>
        ${cmps.length > 1 ? `<button class="cmphint fun press" id="cmphint">${tl("itemView.140")} <b>${tl("itemView.72")}</b>${tl("itemView.141")}</button>` : ""}
        ${chgHtml}
        <div class="cmpm"><div class="seg" role="group" aria-label="${tl("itemView.147")}">${MODES.map(([k, n]) => `<button class="press${k === eff ? " on" : ""}" data-cm="${k}" aria-pressed="${k === eff}">${n}</button>`).join("")}</div>
          <label class="cmpo"${eff === "over" ? "" : " hidden"}><span class="num">${pv.v}</span><input type="range" id="cmpo" min="0" max="100" value="${cmpOp}" aria-label="${tl("itemView.148", {v: v.v})}"><span class="num">${v.v}</span></label>
          <label class="cmpthr"${eff === "diff" ? "" : " hidden"}><span>${tl("itemView.149")}</span><input type="range" id="cmpthr" min="4" max="80" value="${cmpThr}" aria-label="${tl("itemView.150")}"><span class="cmpdr num" id="cmpdr"></span></label>
          ${ov.length ? `<button class="opt press cmpovt" id="cmpovt" aria-pressed="false" title="${tl("itemView.142")}">${ic("pin")}<span>${tl("itemView.143")}</span></button>` : ""}</div>
        <div class="cmp m-${eff}${cv ? " vid" : ""}" id="cmp" style="--o:${cmpOp / 100}">${side(cv?.[0], ps.img, "a")}${side(cv?.[1], s.img, "b")}<canvas class="cdiff" aria-label="${tl("itemView.151")}"></canvas><div class="cmpov" aria-hidden="true"></div><div class="h"></div><span class="lb l">${pv.v}</span><span class="lb r">${v.v}</span></div>
        ${cv ? `<div class="cmpbar"><button class="press" id="cmpplay" aria-label="${tl("itemView.39")}">${ic("play")}</button><button class="press" data-cs="-1" aria-label="${tl("itemView.41")}">${ic("chev")}</button><button class="press" data-cs="1" aria-label="${tl("itemView.45")}">${ic("chev")}</button><span class="num" id="cmpnow"></span><span class="grow"></span><span class="sub">${esc(cv[1].name)}</span></div>
        <div class="cmprail" id="cmprail" tabindex="0" role="slider" aria-label="${tl("itemView.144")}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="cmptk"><i class="fill"></i><div class="ticks" aria-hidden="true"></div><span class="ph"></span></div><div class="cmpdur"><span class="da num"></span><span class="db num"></span></div></div>` : ""}
        <div style="height:14px"></div>`;
      // The chip row is gone; this points to the one picker and turns 비교 on so a pair can be chosen.
      document.getElementById("cmphint")?.addEventListener("click", () => {
        const vtl = document.getElementById("vtl"); if (!vtl) return;
        mtSet("v", true);
        vtl.scrollIntoView({block: wide() ? "nearest" : "center", behavior: RM() ? "auto" : "smooth"});
        if (!cmpToggle) document.getElementById("vtlcmp")?.click();
      });
      body.querySelectorAll("[data-cst]").forEach((b) => b.onclick = () => { const d = +b.dataset.d;
        if (b.dataset.cst === "a") { const w = stepOf(ordA, pv, d); if (w) cmpPick[id] = w.v; }
        else { const w = stepOf(ordB, v, d); if (!w) return; cmpPick[id] = pv.v; if (w.v === vs[0].v) delete verPick[id]; else verPick[id] = w.v; }
        tabPick[id] = "cmp"; again(); });
      const c = document.getElementById("cmp");
      // Different resolutions between the two versions: say so and keep 밀기 from scaling the
      // smaller up to cover the box (nearby CSS switches .mism to contain). Videos read their size
      // once metadata is in; images are loaded once for their natural size.
      const resEl = document.getElementById("cmpres");
      const showRes = (a, b) => { const lab = resMismatch(a, b); if (!resEl) return;
        c.classList.toggle("mism", !!lab);
        if (lab) { resEl.textContent = tl("itemView.162", {r: lab}); resEl.hidden = false; } else resEl.hidden = true; };
      if (cv) { const [va, vb] = c.querySelectorAll("video");
        const chk = () => { if (va?.videoWidth && vb?.videoWidth) showRes({w: va.videoWidth, h: va.videoHeight}, {w: vb.videoWidth, h: vb.videoHeight}); };
        [va, vb].forEach((m) => m && (m.readyState >= 1 ? chk() : m.addEventListener("loadedmetadata", chk, {once: true}))); }
      else if (ps.img && s.img) Promise.all([loadImg(ps.img), loadImg(s.img)])
        .then(([ia, ib]) => c.isConnected && showRes({w: ia.naturalWidth, h: ia.naturalHeight}, {w: ib.naturalWidth, h: ib.naturalHeight})).catch(() => {});
      // The compare state rides in the address so a reload, Back, or a shared link restores this
      // exact pair, mode, threshold, and moment. `curMode` tracks the mode as it switches in place.
      const cvid = cv ? c.querySelectorAll("video")[1] : null;
      let curMode = eff;
      const syncUrl = () => { if (!mount) setCmpHash(id, v.v, pv.v, curMode, cvid ? cvid.currentTime : 0, cmpThr); };
      // The pixel diff is drawn once per (pair, 기준); the readout under 기준 says how much moved.
      const dr = document.getElementById("cmpdr");
      const setRatio = (r) => { if (dr) dr.textContent = r == null ? tl("itemView.152") : tl("itemView.153", {p0: Math.round(r * 100)}); };
      // 지시 겹쳐 보기: redrawn on demand, on every frame while a video plays, and on resize.
      const drawOv = () => renderCmpOverlay(c, ov, cv ? cv[1].fps || 0 : 0);
      // 차이: two stills diff by URL once per (pair, 기준); two videos diff their current frames live.
      const vdiff = cv ? wireCmpVideoDiff(c, () => cmpThr, () => c.classList.contains("m-diff"), setRatio) : null;
      const showDiff = () => cv ? vdiff() : renderCmpDiff(c, ps.img, s.img, cmpThr, setRatio);
      if (cv) { wireCmpVideo(c, cv[1].fps, drawOv);
        wireCmpRail(c, cv, cmpRailMarks(d, cv, pv), cv[1].fps, {a: pv.v, b: v.v}); }
      if (eff === "diff") showDiff();
      // 밀기 · 나란히 · 겹치기 · 차이 switch in place: the videos keep playing where they are.
      body.querySelectorAll("[data-cm]").forEach((b) => b.onclick = () => { cmpMode(b.dataset.cm); curMode = b.dataset.cm;
        body.querySelectorAll("[data-cm]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        MODES.forEach(([k]) => c.classList.toggle("m-" + k, k === b.dataset.cm));
        body.querySelector(".cmpo").hidden = b.dataset.cm !== "over"; body.querySelector(".cmpthr").hidden = b.dataset.cm !== "diff";
        drawOv();
        if (b.dataset.cm === "diff") showDiff(); syncUrl(); });
      document.getElementById("cmpo").oninput = (e) => { cmpOp = +e.target.value; c.style.setProperty("--o", cmpOp / 100); drawOv(); };
      document.getElementById("cmpthr").oninput = (e) => { cmpThr = +e.target.value; clearTimeout(cmpThrT); cmpThrT = setTimeout(() => { showDiff(); syncUrl(); }, 90); };
      const ovt = document.getElementById("cmpovt");
      if (ovt) ovt.onclick = () => { const on = c.classList.toggle("ov-on"); ovt.classList.toggle("on", on); ovt.setAttribute("aria-pressed", String(on)); drawOv(); };
      // An image compare needs the newer picture's natural size to place a pin; load it once.
      if (ov.length && !cv && s.img) loadImg(s.img).then((im) => { const lay = c.querySelector(".cmpov"); if (lay && c.isConnected) { lay._nw = im.naturalWidth; lay._nh = im.naturalHeight; drawOv(); } }).catch(() => {});
      new ResizeObserver(() => drawOv()).observe(c);
      // Restore a moment from the address, then keep the address in step as the video moves.
      if (cvid && cmpSeek != null) { const t = cmpSeek; cmpSeek = null;
        const go = () => { try { cvid.currentTime = t; } catch (e) {} }; cvid.readyState >= 1 ? go() : cvid.addEventListener("loadedmetadata", go, {once: true}); }
      if (cvid && !mount) { cvid.addEventListener("seeked", syncUrl); cvid.addEventListener("pause", syncUrl); }
      syncUrl();
      document.getElementById("cmpcopy").onclick = async () => {
        const ok = await copyText(location.href.split("#")[0] + cmpHashStr(id, v.v, pv.v, curMode, cvid ? cvid.currentTime : 0, cmpThr));
        toast(ok ? tl("itemView.154") : tl("itemView.155"), 2200, ok ? "copied" : "failed"); };
      document.getElementById("cvopen").onclick = () => openCmpWorkspace(x, vs, pv.v, v.v);
      c.addEventListener("pointerdown", (e) => { if (!c.classList.contains("m-wipe")) return; c.setPointerCapture(e.pointerId);
        const mv = (ev) => { const r = c.getBoundingClientRect(); c.style.setProperty("--x", Math.min(100, Math.max(0, (ev.clientX - r.left) / r.width * 100)) + "%"); };
        mv(e); c.onpointermove = mv; c.onpointerup = c.onpointercancel = () => { c.onpointermove = null; }; });
    }
    tgtLabel();
  };
  document.querySelectorAll("#itabs button").forEach((b) => b.onclick = () => {
    draw(b.dataset.v);
    // On a phone the tab body can sit under the decision bar: bring the whole card up to the header.
    const card = b.closest(".itab");
    if (!wide() && card.getBoundingClientRect().bottom > innerHeight - 90) {
      // The picture stays pinned at the top (.media is sticky): stop the card under it, as 답하기 does.
      const med = document.querySelector(".media"), ms = med && getComputedStyle(med);
      card.style.scrollMarginTop = askPinned(ms?.position, parseFloat(ms?.top), med?.offsetHeight, med?.getBoundingClientRect().bottom, card.getBoundingClientRect().top);
      card.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"});
    }
  });
  // An HTML report is checked at both widths: PC fills the column, 폰 shows it at 390px.
  document.querySelectorAll(".pgtop [data-pw]").forEach((b) => b.onclick = () => { pageW = b.dataset.pw; try { localStorage.setItem("pageW", pageW); } catch {}
    document.getElementById("pgw").classList.toggle("phone", pageW === "phone");
    document.querySelectorAll(".pgtop [data-pw]").forEach((x) => x.classList.toggle("on", x === b)); });
  pageZoom(null);
  document.querySelectorAll(".pgtop .pgzoom [data-z]").forEach((b) => b.onclick = () => { const d = +b.dataset.z; pageZoom(Math.abs(d) === 1 ? d : 0); });
  // An HTML report used to fill the phone screen; scrolling inside the iframe trapped the page
  // so the questions/comments below were out of reach. The frame is capped and this opens it full.
  const pgfull = document.getElementById("pgfull");
  if (pgfull && !oldMedia) { const onEsc = (e) => { if (e.key === "Escape") pgfull.click(); };
    pgfull.onclick = () => { const pgw = document.getElementById("pgw"), on = pgw.classList.toggle("full");
      pgfull.setAttribute("aria-pressed", String(on)); pgfull.querySelector("span").textContent = on ? tl("itemView.114") : tl("itemView.26");
      document.body.classList.toggle("pgfullon", on);
      if (on) addEventListener("keydown", onEsc); else removeEventListener("keydown", onEsc); }; }
  stageGo = wireStage(pics, pics.filter((f) => f.kind === "video").length === 1 ? v.shots : null); wireGrip();
  const summary = box.querySelector(".isumwrap"), summaryMore = summary?.querySelector(".isummore");
  if (summaryMore) { const text = summary.querySelector(".isum"); summaryMore.hidden = text.scrollHeight <= text.clientHeight + 2;
    summaryMore.onclick = () => { const on = summary.classList.toggle("open"); summaryMore.setAttribute("aria-expanded", String(on)); summaryMore.textContent = on ? tl("itemView.30") : tl("ui.more"); }; }
  const kd = keep?.v === v.v && keep.t > 0 && stageVideo();
  if (kd && keep.pic) kd.poster = keep.pic;
  if (kd) { const seek = () => { kd.currentTime = keep.t; if (keep.play) playNow(kd); }; kd.readyState >= 1 ? seek() : kd.addEventListener("loadedmetadata", seek, {once: true}); }
  if (autoPlay) { autoPlay = false; playNow(stageVideo()); }
  wireComments(it);
  draw(tab);
  // A report has no picture to mark, so its comment tools (사진, 선택지 보기) wait on a PC until
  // the box is used; with an image they are the review tools and stay out (v2.css .cdock.quiet).
  document.getElementById("cm")?.addEventListener("focus", () => { dockOpenOf = id; document.getElementById("cdock")?.classList.add("open"); });
  // C puts the caret in the box; Esc hands the keys back to the page (the draft stays), as in the viewer's box.
  document.getElementById("cm")?.addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.defaultPrevented) e.target.blur(); });
  // 답하기 n in the dock (phone): the questions sit under the report, so the one press that is
  // always on screen opens their tab and brings the card up.
  box.querySelector("[data-askgo]")?.addEventListener("click", () => { draw("ask");
    // A picture or video stays pinned at the top while the page scrolls (.media is sticky), so the
    // card stops under it, not under the title bar - or the questions end up behind the picture.
    const tab = box.querySelector(".itab"), med = document.querySelector(".media"), ms = med && getComputedStyle(med);
    if (!tab) return;
    tab.style.scrollMarginTop = askPinned(ms?.position, parseFloat(ms?.top), med?.offsetHeight, med?.getBoundingClientRect().bottom, tab.getBoundingClientRect().top);
    tab.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); });
  // A redraw rebuilt the side panel: put its scroll back, and keep the end of the list in sight
  // when it was (or when a comment was just sent, so it shows right above the box).
  const newPanel = box.querySelector(".detailcols.item > div:last-child");
  if (newPanel && panelTop) newPanel.scrollTop = panelTop;
  // A phone measures against the page, and the picture above the list is still settling its height.
  if (Date.now() < cmJump || panelEnd) { cmEnd(); if (!wide()) setTimeout(() => { if (openItem?.id === id) cmEnd(); }, 350); }
  if (typed) { const t = document.getElementById("cm");
    if (t && document.activeElement !== t) { try { t.focus({preventScroll: true}); t.setSelectionRange(typed[0], typed[1]); } catch {} } }
  if (cvAuto === id && !mount) { cvAuto = null; if (pv) openCmpWorkspace(x, vs, pv.v, v.v, cvScroll); }
  // A compare link opened on a phone lands above the sticky media; bring the comparison into view.
  if (restoredCmp && !wide()) { const el = box.querySelector("#cmp") || box.querySelector(".itab");
    el?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}); }
  document.querySelectorAll(".tolatest").forEach((b) => b.addEventListener("click", () => { delete verPick[id]; again(); }));
  const more = mount ? null : document.getElementById("imore");
  if (more) more.onclick = () => {
    const f = pics[stageAt] || files[0];
    const row = (k, icon, t, sub = "") => `<button class="row press" data-m="${k}"><span class="ico sm c-grey">${ic(icon)}</span><span class="tx"><div class="t" style="font-size:16px">${t}</div>${sub ? `<div class="s">${sub}</div>` : ""}</span></button>`;
    sheet(`<h3>${esc(d.title)}</h3>
      ${f ? `<a class="row press" href="${esc(f.url)}" target="_blank" rel="noopener"><span class="ico sm c-grey">${ic("ext")}</span><span class="tx"><div class="t" style="font-size:16px">${tl("itemView.156")}</div><div class="s">${esc(f.name)}</div></span></a>` : ""}
      ${row("copy", "link", tl("itemView.157"), tl("itemView.158"))}
      ${latest && v.status === "approved" && !done ? row("unapprove", "back", tl("itemView.159")) : ""}
      ${latest && !done ? row("done", "check", tl("itemView.57"), tl("itemView.160")) : ""}
      ${wide() ? row("keys", "kbd", pref("keys") ? tl("keybar.menu.off") : tl("keybar.menu.on"), tl("keybar.menu.d")) : ""}`, (el) => {
      el.querySelectorAll("[data-m]").forEach((b) => b.onclick = async (e) => { e.stopPropagation(); const m = b.dataset.m;
        if (m === "copy") { const ok = await copyText(location.href.split("#")[0] + "#item/" + id); closeSheet(); return toast(ok ? tl("itemView.161") : tl("itemView.155"), 2200, ok ? "copied" : "failed"); }
        closeSheet();
        if (m === "keys") keyBarToggle();
        else if (m === "unapprove") decide("pending");
        else if (m === "done") setTimeout(() => decide("done"), 280); });
    });
  };
}
// The comment tab's "this file" chip follows the file on screen.
function tgtLabel() {
  const b = document.querySelector('.tg[data-tgt="file"]'), f = openItem?.pics[stageAt];
  if (!b || !f) return;
  b.innerHTML = `${tl("tgtLabel.1")} <b>${esc(f.name)}</b>`;
  const t = document.querySelector(".tgt")?.dataset.on || "file";
  document.querySelectorAll(".tg").forEach((x) => x.classList.toggle("on", x.dataset.tgt === t));
}
// Files on the result page: one at a time, following the finger, springing to the next.
// The grip under the stage sizes it: 1:1 with the finger, carried on by the flick and eased
// back inside the limits on release, kept for next time. A double tap goes back to the default.
// A portrait video in the default 16:10 box is small on a phone, so this is the way to see it big.
function wireGrip() {
  const g = document.getElementById("sgrip"), st = document.getElementById("stage");
  if (!g || !st) return;
  // On wide screens the stage may grow only as far as the column keeps the bars under it in
  // sight (above the key bar); a size saved on a taller window is cut down to that.
  const room = () => { const m = st.parentElement, cap = parseFloat(getComputedStyle(m).maxHeight);
    return wide() && cap ? cap - (m.scrollHeight - st.getBoundingClientRect().height) : innerHeight - 170; };
  const lo = () => 140, hi = () => Math.max(lo() + 40, room());
  const put = (h) => { st.style.height = h + "px"; st.style.maxHeight = "none"; st.style.aspectRatio = "auto"; };
  const fit = (h) => Math.max(lo(), Math.min(hi(), h));
  let saved = 0; try { saved = +localStorage.getItem("stageH") || 0; } catch {}
  if (saved) put(fit(saved));
  stageRefit = () => { if (st.isConnected && st.style.height) put(fit(saved || st.getBoundingClientRect().height)); };
  // No size of the user's own yet: a portrait file on a phone opens tall enough to read,
  // instead of a sliver in the middle of a 16:10 box.
  stageFit = saved || wide() ? null : () => {
    const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video");
    const w = m?.videoWidth || m?.naturalWidth, hh = m?.videoHeight || m?.naturalHeight;
    if (!w || !hh) return m?.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", () => stageFit?.(), {once: true});
    if (hh > w * 1.05) put(Math.round(Math.min(innerHeight * 0.56, st.clientWidth * hh / w)));
    else { st.style.height = st.style.maxHeight = st.style.aspectRatio = ""; }
  };
  stageFit?.();
  let d = null, h = 0, stop = null;
  g.addEventListener("pointerdown", (e) => {
    if (e.button) return;
    stop && stop(); h = st.getBoundingClientRect().height;
    d = {id: e.pointerId, y0: e.clientY, h0: h, hist: [[e.clientY, e.timeStamp]]};
    g.setPointerCapture(e.pointerId); g.classList.add("on"); e.preventDefault();
  });
  g.addEventListener("pointermove", (e) => {
    if (!d || e.pointerId !== d.id) return;
    h = d.h0 + e.clientY - d.y0;
    if (h < lo()) h = lo() + rubber(h - lo(), innerHeight); else if (h > hi()) h = hi() + rubber(h - hi(), innerHeight);
    put(h); d.hist.push([e.clientY, e.timeStamp]); if (d.hist.length > 5) d.hist.shift();
  });
  const end = (e) => {
    if (!d || e.pointerId !== d.id) return;
    const a = d.hist[0], b = d.hist[d.hist.length - 1], v = b[1] > a[1] ? (b[0] - a[0]) / (b[1] - a[1]) * 1000 : 0;
    d = null; g.classList.remove("on");
    const to = fit(h + project(v, 0.99));
    saved = Math.round(to); try { localStorage.setItem("stageH", saved); } catch {}
    stageFit = null;
    if (RM()) return put(to);
    stop = springTo(() => h, (x) => { h = x; put(x); }, to, v, null, 0.36, 1);
  };
  g.addEventListener("pointerup", end); g.addEventListener("pointercancel", end);
  g.addEventListener("dblclick", () => { stop && stop(); st.style.height = st.style.maxHeight = st.style.aspectRatio = "";
    saved = 0; try { localStorage.removeItem("stageH"); } catch {} });
}
