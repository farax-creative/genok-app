// Genok web UI, cut from project.js: one session's conversation: its lines, finds, kept lines, results, pictures, turns, runs.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- one session: conversation | results + open comments --------------------------------------
  let holds = 0; const HOLD = 3;                      // answers being waited for (tail), and how many may be at once
  // chat-draft:begin
  const CHAT_DRAFT = "genok.chat-draft:", CHAT_DRAFT_AGE = 30 * 86400e3;
  function readDraft(sid) {
    try {
      const value = JSON.parse(localStorage.getItem(CHAT_DRAFT + sid));
      if (value && typeof value.text === "string" && Number.isFinite(value.at)
          && Date.now() - value.at <= CHAT_DRAFT_AGE) return value.text;
      localStorage.removeItem(CHAT_DRAFT + sid);
    } catch (e) { /* unavailable or damaged storage: keep typing */ }
    return "";
  }
  function writeDraft(sid, text) {
    try {
      if (text) localStorage.setItem(CHAT_DRAFT + sid, JSON.stringify({text, at: Date.now()}));
      else localStorage.removeItem(CHAT_DRAFT + sid);
    } catch (e) { /* quota or private mode: the in-memory draft still works */ }
  }
  // chat-draft:end
  // chat-outbox:begin
  // Lines that were still going or had failed outlive a reload, so what happened to them can be
  // checked. One that was mid-send comes back as "not confirmed": it is never sent again by itself.
  const CHAT_OUT = "genok.chat-out:", CHAT_OUT_AGE = 86400e3;
  function readOut(sid, unknown) {
    try {
      const rows = JSON.parse(localStorage.getItem(CHAT_OUT + sid));
      if (Array.isArray(rows)) return rows.filter((r) => r && typeof r.text === "string" && Number.isFinite(r.at) && Date.now() - r.at <= CHAT_OUT_AGE)
        .map((r) => ({text: r.text, said: r.text, imgs: [], at: r.at, busy: false, kept: true, uncertain: !r.failed || !!r.uncertain, failed: r.failed && !r.uncertain ? r.failed : unknown}));
    } catch (e) { /* unavailable or damaged storage: nothing to bring back */ }
    return [];
  }
  function writeOut(sid, pend) {
    try {
      const rows = pend.filter((p) => p.text && (p.busy || p.failed)).map((p) => ({text: p.text, at: p.at, failed: p.busy ? "" : p.failed, uncertain: !!p.uncertain}));
      if (rows.length) localStorage.setItem(CHAT_OUT + sid, JSON.stringify(rows));
      else localStorage.removeItem(CHAT_OUT + sid);
    } catch (e) { /* quota or private mode: the line is still in this page */ }
  }
  // chat-outbox:end
  function C(sid) {
    return convs[sid] || (convs[sid] = {out: sid, entries: [], offset: null, results: [], queued: [], draft: readDraft(sid), pend: readOut(sid, tl("pj.delivery.unknown")), state: null, loaded: false,
      imgs: [], divTs: undefined, divSeen: false, readSent: null, stick: true, pos: null, unseen: 0, offline: false, waiting: false, stateHtml: "", noteHtml: null, kick: null});
  }
  // Where the person stopped reading, kept across a reload (sessionStorage) so the chat comes back
  // to the same place instead of the top; a chat left at the bottom just lands on the newest.
  const POS = "rl-chat-pos:", TIP = "rl-chat-tip";
  const readPos = (sid) => { try { return JSON.parse(sessionStorage.getItem(POS + sid)); } catch (e) { return null; } };
  const writePos = (sid, p) => { try { sessionStorage.setItem(POS + sid, JSON.stringify(p)); } catch (e) { /* private window: fine */ } };
  const tipOn = () => { try { return localStorage.getItem(TIP) !== "1"; } catch (e) { return true; } };
  const tipOff = () => { try { localStorage.setItem(TIP, "1"); } catch (e) { /* shown again next time */ } };
  const nearEnd = (box) => box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  // Where the reading stands, in a form that survives the log being built again: at the end, or on
  // a line (which one, and how far its top is from the box's top edge). `top` is the old fallback.
  const lines = (box) => box.querySelectorAll(":scope>.pj-msg:not([data-pend])");
  function spot(box, stick) {
    const p = {top: box.scrollTop, stick};
    if (stick) return p;
    const t = box.getBoundingClientRect().top, ls = lines(box);
    for (let i = 0; i < ls.length; i++) {
      const r = ls[i].getBoundingClientRect();
      if (r.height && r.bottom > t + 1) { p.k = i; p.at = ls[i].dataset.at || ""; p.off = Math.round(r.top - t); break; }
    }
    return p;
  }
  function seat(box, p) {
    if (!p || p.stick) { box.scrollTop = box.scrollHeight; return; }
    const ls = lines(box);
    let n = p.k != null && ls[p.k];
    if (p.at && !(n && n.dataset.at === p.at)) n = [...ls].find((x) => x.dataset.at === p.at) || n;
    if (n) box.scrollTop += n.getBoundingClientRect().top - box.getBoundingClientRect().top - p.off;
    else box.scrollTop = p.top || 0;
  }
  // After the log is built again the page around it is still finding its size (the columns are
  // fitted, pictures and fonts come in). Until the person touches the chat, or a moment passes,
  // the spot is held: every change of size seats the log on it again.
  function letGo(box, c) {
    if (!c.hold) return;
    clearTimeout(c.holdT); c.hold = null;
    if (box.isConnected && box.clientHeight) { c.stick = nearEnd(box); endBtn(box, c); }
  }
  function hold(box, c, p) {
    clearTimeout(c.holdT); c.hold = p; c.stick = !!p.stick;
    c.holdT = setTimeout(() => letGo(box, c), 1500);
  }
  // One control for the way down. It shows once the end is more than a third of the box away, or
  // when lines arrived out of sight - then it carries their count.
  function endBtn(box, c) {
    const pill = box.parentNode && box.parentNode.querySelector(".pj-newpill"); if (!pill) return;
    const far = box.scrollHeight - box.scrollTop - box.clientHeight;
    const on = !box._end && !c.stick && (c.unseen > 0 || far > box.clientHeight / 3);
    const n = on ? c.unseen : 0, t = n ? tl("pj.newMsg", {n}) : tl("pj.toEnd"), b = pill.querySelector("b"), nt = n ? (n > 99 ? "99+" : String(n)) : "";
    pill.classList.toggle("on", on);
    if (b && b.textContent !== nt) b.textContent = nt;
    if (pill.title !== t) { pill.title = t; pill.setAttribute("aria-label", t); }
  }
  // Never a long ride: from far away the log lands a box and a half short of the end first and
  // only that last stretch is eased (200ms). Touching the log takes it back at once.
  function endStop(box, c) {
    if (!box._end) return;
    cancelAnimationFrame(box._end); box._end = 0;
    c.stick = nearEnd(box); endBtn(box, c);
  }
  function toEnd(box, c) {
    const max = () => box.scrollHeight - box.clientHeight;
    cancelAnimationFrame(box._end); box._end = 0;
    clearTimeout(c.holdT); c.hold = null; c.stick = true; c.unseen = 0;
    if (RM() || max() - box.scrollTop < 2) { box.scrollTop = max(); endBtn(box, c); return; }
    const from = Math.max(box.scrollTop, max() - box.clientHeight * 1.5), t0 = performance.now();
    const step = (now) => {
      const k = Math.max(0, Math.min(1, (now - t0) / 200));
      box.scrollTop = Math.max(box.scrollTop, k < 1 ? from + (max() - from) * (1 - Math.pow(1 - k, 3)) : max());
      box._end = k < 1 && box.isConnected ? requestAnimationFrame(step) : 0;
    };
    box.scrollTop = from; box._end = requestAnimationFrame(step); endBtn(box, c);
  }
  // ---- from one line of mine to the next ----------------------------------------------------------
  // A long answer leaves the log at its end, and where it begins is right under my line. Alt+Up and
  // Alt+Down seat the log on the line of mine above or below its top edge (past the newest: the
  // end); `last` goes to my newest wherever the log stands. The line found shows itself once.
  function hop(box, c, d, last) {
    const mine = [...box.querySelectorAll(":scope>.pj-msg.user")], t = box.getBoundingClientRect().top + 12;
    const tops = mine.map((n) => n.getBoundingClientRect().top);
    const i = last ? mine.length - 1 : d < 0 ? tops.findLastIndex((y) => y < t - 2) : tops.findIndex((y) => y > t + 2);
    if (i < 0 || (d > 0 && !last && box.scrollHeight - box.scrollTop - box.clientHeight < 2)) { if (d > 0) toEnd(box, c); return; }
    cancelAnimationFrame(box._end); box._end = 0; letGo(box, c);
    box.scrollTop += tops[i] - t;
    c.stick = nearEnd(box); if (c.stick) c.unseen = 0; endBtn(box, c);
    mine[i].animate([{opacity: .35}, {opacity: 1}], {duration: 320, easing: "ease-out"});
  }
  // ---- what was said before the first look ----------------------------------------------------------
  // The first look reads the end of the record (c.start: the byte its oldest line begins at, 0 =
  // nothing before it). While there is more, the log's first child is the row that brings it; the
  // lines go in above and what is being read stays where it is.
  function olderRow(box, c) {
    const b = box.querySelector(":scope>.pj-older"), on = c.start > 0 && c.entries.length > 0;
    if (b && !on) { if (b === document.activeElement) box.focus({preventScroll: true}); b.remove(); }
    else if (!b && on) box.insertAdjacentHTML("afterbegin", `<button type="button" class="pj-older press"><span class="pj-spin" aria-hidden="true"></span>${tl("pj.older")}</button>`);
  }
  async function older(c, s, btn) {
    if (c.olderBusy) return;
    const from = c.start;
    c.olderBusy = true; btn.setAttribute("aria-busy", "true");
    try {
      const tx = await loopFetch("/api/sessions/transcript?id=" + enc(s.id) + "&agent=" + enc(s.agent) + "&before=" + from);
      if (c.start !== from || !tx.entries) return;         // the record was read again from its end meanwhile
      c.entries = tx.entries.concat(c.entries); c.start = tx.start || 0;
      const box = c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"); if (!box) return;
      const row = box.querySelector(":scope>.pj-older"), h = box.scrollHeight, top = box.scrollTop, held = box._selectionPaint;
      if (held && held.from != null) held.from += tx.entries.length;
      box.querySelectorAll(":scope>.pj-day").forEach((n) => n.remove());   // stamp() puts the day lines back where they belong now
      const html = tx.entries.map((e) => bubble(e)).join("");
      if (row) row.insertAdjacentHTML("afterend", html); else box.insertAdjacentHTML("afterbegin", html);
      letGo(box, c); paint(c.body, c, false, c.entries.length);
      box.scrollTop = top + box.scrollHeight - h;
      c.stick = nearEnd(box); c.pos = spot(box, c.stick); writePos(s.id, c.pos); endBtn(box, c);
      if (box._find) box._find();
    } catch (e) { toast(tl("pj.older.fail")); }
    finally { c.olderBusy = false; if (btn.isConnected) btn.removeAttribute("aria-busy"); }
  }
  // ---- find in this conversation ------------------------------------------------------------------
  // The app's window has no find of its own, and a browser's would miss folded lines' state. Matches
  // are marked with the CSS highlight API (the lines are not touched, so nothing is drawn again);
  // Enter / Shift+Enter step through them from the newest, Esc closes. Only what this chat has
  // loaded is searched, and only lines on screen (a folded tool run is opened first).
  const HL = window.CSS && window.CSS.highlights && typeof Highlight === "function" ? window.CSS.highlights : null;   // `CSS` here is this file's style text
  function findOpen(conv, seed) {
    const bar = conv && conv.querySelector("#pj-find"), box = conv && conv.querySelector("#pj-msgs");
    if (!bar || !box) return;
    if (!bar._f) {
      const inp = bar.querySelector("input"), n = bar.querySelector(".n"), bs = bar.querySelectorAll("[data-fd]");
      let hits = [], at = -1, back = null;
      const mark = () => { if (!HL) return; HL.set("pj-find", new Highlight(...hits)); HL.set("pj-find-on", new Highlight(...(at >= 0 ? [hits[at]] : []))); };
      const look = (keep) => {
        const q = inp.value.trim().toLowerCase(), was = at; hits = [];
        if (q) { const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {acceptNode: (t) => { const p = t.parentElement;
            return p && p.closest(".pj-msg") && !p.closest(".pj-tm,.tg,button") && p.getClientRects().length ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }});
          for (let t; (t = w.nextNode());) { const s = t.data.toLowerCase();
            for (let i = s.indexOf(q); i >= 0; i = s.indexOf(q, i + q.length)) { const r = new Range(); r.setStart(t, i); r.setEnd(t, i + q.length); hits.push(r); } } }
        at = keep && was >= 0 && was < hits.length ? was : hits.length - 1; show(!keep);
      };
      const show = (go) => {
        n.textContent = inp.value.trim() ? (hits.length ? `${at + 1}/${hits.length}` : tl("pj.find.none")) : "";
        bs.forEach((b) => { b.disabled = hits.length < 2; }); mark();
        if (!go || at < 0) return;
        const r = hits[at].getBoundingClientRect(), b = box.getBoundingClientRect(), c = box._c;
        if (r.top < b.top + 52 || r.bottom > b.bottom - 12) { box.scrollTop += r.top - b.top - box.clientHeight / 3; if (c) { letGo(box, c); c.stick = nearEnd(box); endBtn(box, c); } }
      };
      const step = (d) => { if (!hits.length) return; at = (at + d + hits.length) % hits.length; show(true); };
      const shut = () => { bar.classList.remove("on"); hits = []; at = -1; if (HL) { HL.delete("pj-find"); HL.delete("pj-find-on"); }
        box._find = null; const to = back && back.isConnected ? back : conv.querySelector("#pj-ta"); if (to && bar.contains(document.activeElement)) to.focus({preventScroll: true}); };
      let tm = 0;
      inp.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(() => { tm = 0; look(false); }, 120); });
      inp.addEventListener("keydown", (e) => { if (e.isComposing || e.keyCode === 229) return;
        if (e.key === "Enter") { e.preventDefault(); if (tm) { clearTimeout(tm); tm = 0; look(false); } else step(e.shiftKey ? 1 : -1); }
        else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); shut(); } });
      bar.addEventListener("mousedown", (e) => { if (e.target.closest("button")) e.preventDefault(); });   // the box keeps the caret
      bar.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; if (b.hasAttribute("data-fdx")) shut(); else step(+b.dataset.fd); });
      // With words given (a line found from the list's search) they are looked for as they are; a
      // finger's keyboard stays down, the line found is already on screen.
      bar._f = {open: (q) => { back = document.activeElement !== inp ? document.activeElement : back; bar.classList.add("on"); box._find = () => look(true);
        if (q != null) inp.value = q;
        if (q == null || !matchMedia("(pointer:coarse)").matches) { inp.focus({preventScroll: true}); inp.select(); }
        if (inp.value.trim()) look(q != null); }};
    }
    bar._f.open(seed);
  }
  // ---- a line of the log, by who said it and when --------------------------------------------------
  const lineAt = (box, side, at) => [...box.querySelectorAll(`:scope>.pj-msg.${side === "user" ? "user" : "claude"}[data-at]:not([data-pend])`)].find((n) => n.dataset.at === at);
  function goLine(box, c, n) {
    cancelAnimationFrame(box._end); box._end = 0; letGo(box, c);
    box.scrollTop += n.getBoundingClientRect().top - box.getBoundingClientRect().top - 12;
    c.stick = nearEnd(box); if (c.stick) c.unseen = 0; endBtn(box, c);
    n.animate([{opacity: .35}, {opacity: 1}], {duration: 320, easing: "ease-out"});
  }
  // A line said before what is loaded: the record is read further back, a few times at most, until
  // it is here. True when the log now stands on it.
  async function seekLine(box, c, s, side, at) {
    for (let k = 0; k < 8; k++) {
      const n = lineAt(box, side, at); if (n) { goLine(box, c, n); return true; }
      const b = box.querySelector(":scope>.pj-older"), was = c.start; if (!b || !(was > 0)) break;
      await older(c, s, b);
      if (c.start === was || !box.isConnected) break;
    }
    return false;
  }
  // The entry a drawn line shows (see nthOf).
  function entryOf(c, n) {
    const side = n.classList.contains("user") ? "user" : "claude", at = n.dataset.at;
    const same = [...n.parentNode.querySelectorAll(`:scope>.pj-msg.${side}[data-at]:not([data-pend])`)].filter((x) => x.dataset.at === at);
    // Only when the log shows as many lines for that moment as the record holds: else none is sure.
    return same.length === c.entries.filter((e) => e.at === at && LINE_SIDE(e) === side).length ? nthOf(c.entries, side, at, same.indexOf(n)) : null;
  }
  // ---- lines kept (고정) ---------------------------------------------------------------------------
  // A line the person wants to find again is kept on the server by who said it and when
  // (rooms.api_marks), so the phone and the PC show the same ones. It is marked where it stands
  // and listed first in 차례 목록.
  function markRows(box, c) {
    const on = new Set((c.marks || []).map((m) => m.kind + "|" + m.at));
    box.querySelectorAll(":scope>.pj-msg[data-at]>.pj-bk").forEach((b) => {
      const n = b.parentNode, is = on.has((n.classList.contains("user") ? "user" : "claude") + "|" + n.dataset.at);
      if (is === n.hasAttribute("data-mk") && b.title) return;
      const t = is ? tl("pj.mark.off") : tl("pj.mark.on");
      n.toggleAttribute("data-mk", is); b.title = t; b.setAttribute("aria-label", t); b.setAttribute("aria-pressed", is ? "true" : "false");
    });
  }
  async function markSet(c, side, at, text) {
    const sid = c.sid || (c.state && c.state.id), on = (c.marks || []).some((m) => m.kind === side && m.at === at);
    try {
      const r = await loopFetch("/api/session/marks", {method: "POST", json: on ? {sid, at, kind: side, off: 1} : {sid, at, kind: side, text}});
      c.marks = r.marks || []; toast(on ? tl("pj.mark.offDone") : tl("pj.mark.onDone"));
      const box = c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"); if (box) markRows(box, c);
    } catch (e) { toast(e.message); }
  }
  function markLine(c, n, words) {
    const e = entryOf(c, n), side = n.classList.contains("user") ? "user" : "claude";
    return markSet(c, side, n.dataset.at, words || (e ? (side === "user" ? parts(unnote(e.text)).words : e.text) : ""));
  }
  // ---- 차례 목록 -----------------------------------------------------------------------------------
  // A long conversation as a list: the lines kept, then every line of mine (newest first) with what
  // the session did after it. A row seats the log on that line. Alt+T, or the chat's menu.
  function turnsOpen(conv, c) {
    const box = conv.querySelector("#pj-msgs"), s = c.state || {}, now = Date.now();
    const ts = turnList(c.entries).filter((t) => t.at).reverse(), mk = (c.marks || []).slice().reverse();
    const when = (at) => { const ms = tmMs(at); return ms == null ? "" : tmDay(ms) === tmDay(now) ? tmText(ms, now).text : new Date(ms).toLocaleDateString(tmLoc(), {month: "short", day: "numeric"}); };
    const took = (t) => { const a = tmMs(t.at), b = tmMs(t.end); return a != null && b != null && b - a >= 1000 ? subDur(b - a) : ""; };
    const head = (t) => { const u = parts(unnote(t)); return (u.words.split("\n").find((l) => l.trim()) || (u.pics.length ? tl("pj.img.look") : "")).trim(); };
    const row = (t) => `<div class="tl-row"><button type="button" class="tl-go press" data-k="user" data-at="${esc(t.at)}"><span class="t">${esc(Redact.show(head(t.text) || ((c.entries[t.i].imgs || []).length ? tl("pj.img.look") : "")))}</span><span class="s">${esc([when(t.at), took(t),
      t.tools ? tl("pj.act.tool", {n: t.tools}) : "", t.files ? tl("pj.turns.files", {n: t.files}) : "", t.out ? tl("pj.sub.tok", {n: ctxTok(t.out)}) : ""].filter(Boolean).join(" · "))}</span></button></div>`;
    const kept = (m) => `<div class="tl-row"><button type="button" class="tl-go press" data-k="${esc(m.kind)}" data-at="${esc(m.at)}"><span class="t">${esc(Redact.show(m.text))}</span><span class="s">${esc([m.kind === "user" ? tl("pj.md.me") : s.agent === "codex" ? "Codex" : "Claude", when(m.at)].filter(Boolean).join(" · "))}</span></button>
      <button type="button" class="tl-x press" data-unmk="${esc(m.kind)}" data-at="${esc(m.at)}" aria-label="${esc(tl("pj.mark.off"))}" title="${esc(tl("pj.mark.off"))}">${ic("x")}</button></div>`;
    sheet(`<div class="pj-dlg pj-tl"><h3>${tl("pj.turns.h")}</h3>
      ${mk.length ? `<div class="pj-lab">${tl("pj.turns.kept")} <span class="n">${mk.length}</span></div><div class="tl-rows">${mk.map(kept).join("")}</div><div class="pj-lab">${tl("pj.turns.mine")} <span class="n">${ts.length}</span></div>` : ""}
      ${ts.length ? `<div class="tl-rows">${ts.map(row).join("")}</div>` : ""}
      ${!ts.length || c.start > 0 ? `<p class="tl-none">${ts.length ? tl("pj.turns.more") : tl("pj.turns.none")}</p>` : ""}</div>`, (bx) => {
      bx.querySelector(".pj-tl").onclick = async (e) => {
        const x = e.target.closest("[data-unmk]"), g = e.target.closest(".tl-go");
        if (x) { await markSet(c, x.dataset.unmk, x.dataset.at); if (document.getElementById("sheet").classList.contains("on")) turnsOpen(conv, c); return; }
        if (!g) return;
        closeSheet();
        if (box.isConnected && !(await seekLine(box, c, s, g.dataset.k, g.dataset.at))) toast(tl("pj.turns.gone"));
      };
    });
  }
  document.addEventListener("keydown", (e) => {
    if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.isComposing || e.code !== "KeyT") return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs"), sh = document.getElementById("sheet");
    if (!box || !box._c || !box.clientHeight || (sh && sh.classList.contains("on"))) return;
    e.preventDefault(); turnsOpen(box.closest(".pj-conv"), box._c);
  });
  // ---- 자주 쓰는 문구 ---------------------------------------------------------------------------------
  // Lines saved to send again (rooms.api_snippets; the same on the phone and the PC). One picked
  // goes into the box at the caret, to change or send; what is in the box now can be saved here.
  // Ctrl+/ in the box, or the chat's menu.
  async function snipOpen(conv) {
    const ta = conv.querySelector("#pj-ta"); let rows;
    try { rows = (await get("/api/snippets")).snippets || []; } catch (e) { return toast(e.message); }
    const draw = () => sheet(`<div class="pj-dlg pj-tl sn"><h3>${tl("pj.snip.h")}</h3>
      ${rows.length ? `<div class="tl-rows">${rows.map((r) => `<div class="tl-row"><button type="button" class="tl-go press" data-sn="${esc(r.id)}"><span class="t">${esc(r.text)}</span></button>
        <button type="button" class="tl-x press" data-snx="${esc(r.id)}" aria-label="${esc(tl("pj.snip.drop"))}" title="${esc(tl("pj.snip.drop"))}">${ic("x")}</button></div>`).join("")}</div>` : ""}
      ${ta.value.trim() ? `<button type="button" class="pj-btn light full press" data-snsave>${tl("pj.snip.save")}</button>` : `<p class="tl-none">${tl("pj.snip.how")}</p>`}</div>`, (bx) => {
      bx.querySelector(".pj-tl").onclick = async (e) => {
        const g = e.target.closest("[data-sn]"), x = e.target.closest("[data-snx]"), sv = e.target.closest("[data-snsave]");
        if (g) {
          const r = rows.find((q) => q.id === g.dataset.sn); closeSheet(); if (!r || !ta.isConnected) return;
          ta.setRangeText(r.text, ta.selectionStart, ta.selectionEnd, "end"); ta.dispatchEvent(new Event("input", {bubbles: true}));
          setTimeout(() => { if (ta.isConnected) ta.focus({preventScroll: true}); }, 60); return;
        }
        if (!x && !sv) return;
        try { rows = (await loopFetch("/api/snippets", {method: "POST", json: x ? {id: x.dataset.snx, off: 1} : {text: ta.value}})).snippets || []; if (sv) toast(tl("pj.snip.saved")); draw(); }
        catch (er) { toast(er.message); }
      };
    });
    draw();
  }
  // ---- said in a conversation: the list's search also looks inside the records ----------------------
  // Under the sessions found by name, the newest lines that hold every word typed (sessions_ctl.
  // search_talk: the end of the newest records). A row opens that conversation on the line, with
  // the words marked by its find bar. The rows are this file's own node, put back after the list
  // is drawn again.
  let pjTalkQ = "", talkT = 0, talkEl = null, talkAsk = 0;
  function talkPut(box) {
    const q = sessQ.trim();
    if (q.length < 2) { pjTalkQ = ""; talkAsk++; clearTimeout(talkT); if (talkEl) talkEl.remove(); talkEl = null; return; }
    if (talkEl && talkEl.parentNode !== box) box.appendChild(talkEl);
    if (q === pjTalkQ) return;
    pjTalkQ = q; clearTimeout(talkT); const ask = ++talkAsk;
    talkT = setTimeout(async () => {
      let r; try { r = await get("/api/project/search?q=" + enc(q)); } catch (e) { return; }
      if (ask !== talkAsk || !r.hits) return;
      const rail = document.querySelector(".pj-rail"), words = q.toLowerCase().split(/\s+/).filter(Boolean);
      if (talkEl) talkEl.remove(); talkEl = null;
      const rows = r.hits.map((h) => { const row = railRows.get(h.id), pn = row ? row.name : h.project || "", x = h.hits[0]; if (!pn || !x) return "";
        return `<button type="button" class="pj-tk press" data-tk="${esc(h.id)}" data-pn="${esc(pn)}" data-k="${esc(x.kind === "user" ? "user" : "claude")}" data-at="${esc(x.at || "")}"><span class="t"><span>${esc(Redact.show(row ? title(row.s) : h.title || pname(pn)))}</span>${h.n > 1 ? `<i>${tl("pj.talk.n", {n: h.n})}</i>` : ""}</span><span class="x">${markWords(Redact.show(x.text), words, esc)}</span></button>`; }).filter(Boolean);
      if (!rows.length || !rail) return;
      talkEl = document.createElement("div"); talkEl.className = "pj-talk";
      talkEl.innerHTML = `<div class="h">${tl("pj.talk.h")}</div>` + rows.slice(0, 20).join("");
      rail.appendChild(talkEl);
    }, 300);
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-tk"); if (!b) return;
    const c = C(b.dataset.tk), bx = c.loaded && c.body && c.body.isConnected && c.body.querySelector("#pj-msgs");
    // The find bar looks for one run of letters: of the words typed, the longest.
    const q = pjTalkQ.split(/\s+/).sort((x, y) => y.length - x.length)[0];
    // The conversation is already on screen: it goes to the line as it is.
    if (bx) { findOpen(bx.closest(".pj-conv"), q); return void seekLine(bx, c, c.state || {}, b.dataset.k, b.dataset.at); }
    c.seek = {side: b.dataset.k, at: b.dataset.at, q};
    nav("project/" + enc(b.dataset.pn) + "/" + enc(b.dataset.tk));
  });
  // ---- a result the session pushed, where it was pushed -------------------------------------------
  // The newest version of each result this session pushed stands in the log before the first line
  // said after it, and opens the result. A push made before what is loaded has no place yet.
  function resRows(box, c) {
    const res = (c.results || []).filter((r) => tmMs(r.at) != null), have = new Map();
    box.querySelectorAll(":scope>.pj-rc").forEach((n) => { if (res.some((r) => rkey(r) + "@" + r.v === n.dataset.rk)) have.set(n.dataset.rk, n); else n.remove(); });
    if (!res.length) return;
    const ls = [...box.querySelectorAll(":scope>.pj-msg.claude[data-at]:not([data-pend]),:scope>.pj-msg.user[data-at]:not([data-pend])")];
    const head = ls.length ? tmMs(ls[0].dataset.at) : null; if (head == null) return;
    res.forEach((r) => {
      const k = rkey(r) + "@" + r.v, t = tmMs(r.at); if (have.has(k) || (c.start > 0 && t < head)) return;
      const html = `<button type="button" class="pj-rc press" data-rk="${esc(k)}" data-go="${esc("item/" + r.project + "/" + r.item)}">${resThumb(r)}<span class="tx"><div class="t">${esc(r.title)}</div><div class="s">${esc(tl("pj.rc.sub", {v: vShort(r.v)}))}</div></span></button>`;
      let a = ls.find((n) => tmMs(n.dataset.at) > t);
      while (a && a.previousElementSibling && a.previousElementSibling.matches(".pj-unread,.pj-pics,.pj-day")) a = a.previousElementSibling;
      const end = a || box.querySelector(":scope>.pj-now");
      if (end) end.insertAdjacentHTML("beforebegin", html); else box.insertAdjacentHTML("beforeend", html);
    });
  }
  // The "새 글" line also says what came in from there on: answers, tool calls, files, results.
  function recap(box, c) {
    const n = box.querySelector(":scope>.pj-unread"), r = n && recapOf(c.entries, c.divTs); if (!n) return;
    const from = tmMs(c.divTs), res = r ? (c.results || []).filter((x) => tmMs(x.at) >= from).length : 0;
    const t = [tl("pj.unread"), r && r.said > 1 ? tl("pj.recap.said", {n: r.said}) : "", r && r.tools ? tl("pj.act.tool", {n: r.tools}) : "", r && r.files ? tl("pj.turns.files", {n: r.files}) : "", res ? tl("pj.recap.res", {n: res}) : ""].filter(Boolean).join(" · ");
    if (n.textContent !== t) n.textContent = t;
  }
  // A line of mine as it is drawn: a comment line's result is the way to that result, when the
  // app knows a result of that name in that project.
  function mineHtml(words) {
    const shown = Redact.show(words), r = shown === words ? commentRef(words) : null;
    let it = null;
    try { it = r && (D.items || []).find((x) => x.project === r.project && (x.title === r.title || x.id === r.title)); } catch (e) { /* items not loaded yet */ }
    return it ? esc(words.slice(0, r.a)) + `<button type="button" class="pj-lk" data-go="${esc("item/" + it.project + "/" + it.id)}">${esc(words.slice(r.a, r.b))}</button>` + plainLinks(words.slice(r.b)) : plainLinks(shown);
  }
  // Ctrl+F (Cmd+F) with a chat on screen opens its find bar (the focused pane's, side by side), but
  // only in the desktop app's own windows: a browser tab keeps Ctrl+F for the browser's find.
  const appWin = () => IN_APP || (FLOAT && !!window.pywebview);
  document.addEventListener("keydown", (e) => {
    if (!appWin()) return;
    if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.isComposing || (e.key !== "f" && e.key !== "F" && e.code !== "KeyF")) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box.clientHeight) return;
    e.preventDefault(); findOpen(box.closest(".pj-conv"));
  });
  // End (or Ctrl+End) with nothing focused goes down in the chat that is open (the focused pane).
  document.addEventListener("keydown", (e) => {
    if (e.key !== "End" || e.target !== document.body || e.altKey || e.shiftKey || e.metaKey) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box._c || !box.clientHeight) return;
    e.preventDefault(); toEnd(box, box._c);
  });
  // Alt+Up / Alt+Down with nothing focused: from one line of mine to the next (hop), in that chat.
  document.addEventListener("keydown", (e) => {
    if (!e.altKey || (e.key !== "ArrowUp" && e.key !== "ArrowDown") || e.target !== document.body || e.ctrlKey || e.shiftKey || e.metaKey) return;
    const box = document.querySelector(".pj-pane.focus .pj-conv .pj-msgs") || document.querySelector(".pj-conv .pj-msgs");
    if (!box || !box._c || !box.clientHeight) return;
    e.preventDefault(); hop(box, box._c, e.key === "ArrowUp" ? -1 : 1);
  });

  function drawSession(body, root, name, s, my) {
    const c = C(s.id); c.state = s; c.body = body; c.room = name;
    endRun(body);                                     // the box showed another conversation: its loops end here
    if (!c.pos) c.pos = readPos(s.id);
    c.unseen = 0; c.stateHtml = ""; c.noteHtml = null;
    body.innerHTML = `
      <div class="pj-seg seg"><button class="${tab === "conv" ? "on" : ""} press" data-t="conv" aria-pressed="${tab === "conv"}">${tl("pj.tab.conv")}</button>
        <button class="${tab === "side" ? "on" : ""} press" data-t="side" aria-pressed="${tab === "side"}">${tl("pj.tab.side")}</button></div>
      <div class="pj-conv" data-col="conv">
        <div id="pj-state"></div>
        <div class="pj-note" id="pj-note"></div>
        <details id="pj-feedback" class="pj-feedback" hidden><summary></summary><div></div></details>
        <div class="pj-tip" id="pj-tip" ${tipOn() ? "" : "hidden"}><span>${tl("pj.tip")}</span>
          <button class="press" data-tipx aria-label="${tl("pj.tipClose")}">${ic("x")}</button></div>
        <div class="pj-wrap"><div class="pj-msgs" id="pj-msgs" aria-live="polite" tabindex="-1"></div>
          <div class="pj-find" id="pj-find" role="search">${ic("search")}<input type="search" enterkeyhint="search" aria-label="${tl("pj.find")}" placeholder="${tl("pj.find")}"><span class="n" aria-live="polite"></span>
            <button class="press" data-fd="-1" aria-label="${tl("pj.find.prev")}" title="${tl("pj.find.prev")}">${ic("up")}</button><button class="press" data-fd="1" aria-label="${tl("pj.find.next")}" title="${tl("pj.find.next")}">${ic("up")}</button><button class="press" data-fdx aria-label="${tl("pj.find.close")}" title="${tl("pj.find.close")}">${ic("x")}</button></div>
          <button class="pj-newpill press" id="pj-pill" aria-label="${tl("pj.toEnd")}" title="${tl("pj.toEnd")}">${ic("up")}<b aria-hidden="true"></b></button></div>
        <div class="pj-att" id="pj-att" hidden></div>
        <div class="pj-todo" id="pj-todo" hidden></div>
        <div class="pj-rd" id="pj-rd"${Redact.on() ? "" : " hidden"}>${ic("eye")}<span>${tl("pj.mask.is")}</span><button type="button" data-unmask>${tl("pj.mask.show")}</button></div>
        <div class="pj-to" id="pj-to">${toLine({name, emoji: emoOf(name), conv: title(s), agent: s.agent || "claude"})}</div>
        <div class="pj-in">${sideHtml()}<div class="pj-box"><button class="pj-clip press" id="pj-clip" aria-label="${tl("pj.clip")}" title="${tl("pj.clip")}">${ic("image")}</button>
          <button class="pj-clip pj-bqb press" id="pj-bqb" aria-label="${tl("pj.sq")}" title="${tl("pj.sq")} (Ctrl+;)" aria-expanded="false" aria-controls="pj-bq">${ic("chat")}</button>
          <input type="file" id="pj-file" accept="image/png,image/jpeg,image/webp,image/gif,application/pdf,text/*,.md,.log,.json,.jsonl,.yaml,.yml,.toml,.ini,.py,.js,.ts,.tsx,.jsx,.css,.c,.h,.cpp,.cs,.java,.kt,.go,.rs,.rb,.php,.swift,.sh,.ps1,.sql,.diff,.patch" multiple hidden>
          <span class="pj-mwrap" id="pj-ml"></span>
          <textarea id="pj-ta" rows="1" placeholder="${tl("pj.ph")}" aria-label="${tl("pj.taLabel")}"></textarea>
          <span class="pj-pjn">${em(emoOf(name))}<span>${esc(unEm(pname(name), emoOf(name)))}</span></span><span class="pj-enter">${tl("room.enterSend")}</span>
          ${micHtml()}
          <button class="pj-go press" id="pj-send" aria-label="${tl("pj.send")}" title="${tl("pj.send")}" disabled>${ic("up")}<span class="pj-spin" aria-hidden="true"></span></button></div></div>
      </div>
      <div data-col="side" id="pj-side"></div>`;
    const again = () => draw(root);
    const ml = body.querySelector("#pj-ml");
    if (ml) modelChip(ml, {sid: s.id});
    // The lines kept in this conversation, asked once per visit; the log marks them when they land.
    get("/api/session/marks?id=" + enc(s.id)).then((r) => { c.marks = r.marks || []; const bx = body.isConnected && body.querySelector("#pj-msgs"); if (bx) markRows(bx, c); }).catch(() => {});
    body.addEventListener("click", body._pjClick = async (e) => { const b = e.target.closest("[data-cmenu]"); if (b) { e.stopPropagation(); menu(b, Object.assign({}, s, c.state), name, again); }
      const g = e.target.closest("[data-chg]"); if (g) showChanges(s.id);
      const l = e.target.closest("[data-bglog]"); if (l) showAgentLog(c.state.bg, l);
      const ab = e.target.closest("[data-act]"); if (ab) control(ab.dataset.act, Object.assign({}, s, c.state), name, again);
      const qp = e.target.closest("[data-qpick]"); if (qp) qPick(qp);
      const ap = e.target.closest("[data-approve]"), qb = ap && ap.closest(".pj-q");
      if (ap && !ap.disabled) { ap.parentNode.querySelectorAll("button").forEach((n) => { n.disabled = true; });
        // Answered (or already answered elsewhere): the bar goes at once, in place, and the state
        // loop asks every second for a while; the chat is not drawn again. Any other failure puts
        // the buttons back so the press can be tried again.
        const aid = ap.dataset.aid, done = () => { if (c.state && c.state.ask && String(c.state.ask.id) === aid) { c.state = Object.assign({}, c.state); delete c.state.ask; } };
        loopFetch("/api/session/approve", {method: "POST", json: {sid: s.id, id: aid, allow: ap.dataset.approve === "1", answers: qb ? qAnswers(qb) : undefined}})
          .then((j) => { done(); ansMark(s.id, true); toast(srvMsg(j.message || j.error || "")); })
          .catch((er) => { if ((er.raw || er.message) === SRV_ASK_GONE) done(); toast(srvMsg(er.message)); })
          .then(() => { c.noteHtml = ""; c.fastUntil = Date.now() + NOW_FAST; if (body.isConnected) paint(body, c, false, c.entries.length); if (c.kick) c.kick(); }); }
      const gn = e.target.closest("[data-gonew]"); if (gn) nav("project/" + enc(name) + "/" + enc(gn.dataset.gonew));
      const tx = e.target.closest("[data-tipx]"); if (tx) { tipOff(); body.querySelector("#pj-tip").hidden = true; }
      const x = e.target.closest("[data-imgrm]"); if (x) { c.imgs.splice(+x.dataset.imgrm, 1); chips(body, c); }
      // A line that did not get through: send it again from where it stands, or take it away.
      const rs = e.target.closest("[data-resend]"), un = e.target.closest("[data-unsend]");
      const pr = rs ? c.pend[+rs.dataset.resend] : un ? c.pend[+un.dataset.unsend] : null;
      if (rs && pr && pr.failed) {
        if (pr.uncertain && (await confirmDlg(tl("pj.delivery.confirm"), tl("pj.delivery.retry"))) !== "ok") return;
        pr.failed = ""; pr.busy = true; pr.at = Date.now(); paint(body, c, false, c.entries.length); queue(s, c, pr); }
      if (un && pr) { c.pend.splice(c.pend.indexOf(pr), 1); (pr.imgs || []).forEach((im) => URL.revokeObjectURL(im.url)); paint(body, c, false, c.entries.length); } });
    body.querySelectorAll("[data-t]").forEach((b) => b.onclick = () => { if (sideStep(b.dataset.t)) return; tab = b.dataset.t; if (!body.dataset.multi && wide()) setFold("tab", tab === "side"); body.querySelectorAll(".pj-seg [data-t]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); }); cols(body); side(body.querySelector("#pj-side"), name, c); });
    cols(body);
    const ta = body.querySelector("#pj-ta"); ta.value = c.draft;
    // A follow-up asked from a result (pjDraft): the box is ready to type in, caret at the end.
    if (c.focusDraft) { c.focusDraft = false; setTimeout(() => { if (ta.isConnected) { ta.focus({preventScroll: true}); ta.setSelectionRange(ta.value.length, ta.value.length); } }, 60); }
    // The box grows with what is typed up to six lines (four over a phone's keyboard), then scrolls. Send is live only when there
    // is something to send; while a line is on its way and the box is empty it shows the ring.
    const go = body.querySelector("#pj-send");
    const grow = () => {
      const cs = getComputedStyle(ta), lines = document.body.classList.contains("pj-kb") ? 4 : 6, cap = Math.round((parseFloat(cs.lineHeight) || 22) * lines + parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom));
      if (!ta.value || !ta.scrollHeight) { ta.style.height = ""; return; }   // empty or not laid out: the CSS height (see the room box above)
      ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, cap) + "px";
    };
    c.sync = () => { go.disabled = !(ta.value.trim() || c.imgs.length); go.classList.toggle("busy", !!c.sending); grow(); };
    ta.addEventListener("input", () => { c.recall = null; c.draft = ta.value; writeDraft(s.id, c.draft); c.sync(); });
    // A line of mine put back in the box (mineAll's i-th, -1 = the empty box), caret at its end.
    const recall = (i, all) => { const t = i < 0 ? "" : all[i]; c.recall = i < 0 ? null : {i, text: t};
      ta.value = c.draft = t; writeDraft(s.id, t); c.sync(); ta.setSelectionRange(t.length, t.length); };
    const box0 = body.querySelector(".pj-box");
    box0.addEventListener("click", (e) => { if (e.target === box0) ta.focus(); });
    // Send while it listens: what was heard so far goes at once.
    const send = () => { Dictate.cut(); sendLine(body, s, name, root); };
    micWire(body, ta);
    sideWire(body, s, c, ta);
    seenReport(s.id);
    const conv = body.querySelector(".pj-conv"), fileIn = body.querySelector("#pj-file");
    body.querySelector("#pj-clip").onclick = () => fileIn.click();
    fileIn.onchange = () => { addFiles(body, c, fileIn.files); fileIn.value = ""; };
    ta.addEventListener("paste", (e) => {
      const fs = [...((e.clipboardData && e.clipboardData.files) || [])].filter((f) => f.type.startsWith("image/"));
      if (fs.length) { e.preventDefault(); addFiles(body, c, fs); }
    });
    ["dragenter", "dragover"].forEach((t) => conv.addEventListener(t, (e) => { if ([...(e.dataTransfer ? e.dataTransfer.types : [])].includes("Files")) { e.preventDefault(); conv.classList.add("drop"); } }));
    conv.addEventListener("dragleave", (e) => { if (!conv.contains(e.relatedTarget)) conv.classList.remove("drop"); });
    conv.addEventListener("drop", (e) => { e.preventDefault(); conv.classList.remove("drop"); addFiles(body, c, e.dataTransfer.files); });
    chips(body, c);
    go.onclick = send;
    // Pressing send or the picture button leaves the caret in the box: the keyboard stays up.
    [go, body.querySelector("#pj-clip")].forEach((b) => b.addEventListener("mousedown", (e) => e.preventDefault()));
    // Enter sends, Shift+Enter breaks the line. The Enter that commits a Korean/Japanese/Chinese
    // composition must not send: isComposing (Chrome), keyCode 229 (Safari/IME) and our own flag.
    let composing = false;
    ta.addEventListener("compositionstart", () => { composing = true; });
    ta.addEventListener("compositionend", () => setTimeout(() => { composing = false; }, 0));
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && Dictate.on()) { e.preventDefault(); e.stopPropagation(); Dictate.drop(); return; }
      if (e.code === "Slash" && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) { e.preventDefault(); snipOpen(conv); return; }
      // Up in an empty box brings my last line back to change and send again (as the CLIs do).
      if (e.key === "ArrowUp" && !ta.value && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && !e.isComposing && !composing) {
        const last = lastMine(c), all = mineAll(c);
        if (last) { e.preventDefault(); recall(Math.max(0, all.indexOf(last)), all); }
        return;
      }
      // That line still as it came: Up on its first row steps to the one I sent before it, Down on
      // its last row to the one after (past the newest: the empty box). Changed, the keys are the box's.
      const rc = c.recall;
      if (rc && ta.value === rc.text && (e.key === "ArrowUp" || e.key === "ArrowDown") && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && !e.isComposing && !composing) {
        const up = e.key === "ArrowUp", all = mineAll(c), i = rc.i + (up ? 1 : -1);
        if (i < all.length && !(up ? ta.value.slice(0, ta.selectionStart) : ta.value.slice(ta.selectionEnd)).includes("\n")) { e.preventDefault(); recall(i, all); }
        return;
      }
      // PageUp / PageDown read the log from the box, while the box has nothing of its own to scroll.
      if ((e.key === "PageUp" || e.key === "PageDown") && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && ta.scrollHeight <= ta.clientHeight + 1) {
        e.preventDefault(); endStop(box, c); box.scrollTop += (e.key === "PageUp" ? -.85 : .85) * box.clientHeight; return;
      }
      if (e.key !== "Enter" || e.shiftKey || e.isComposing || e.keyCode === 229 || composing) return;
      e.preventDefault(); send();
    });
    // Scroll: remember where the person is; stay glued to the newest while they are at the end.
    const box = body.querySelector("#pj-msgs"), pill = body.querySelector("#pj-pill");
    let saveT = 0;
    box._c = c;
    box.addEventListener("scroll", () => {
      if (!box.isConnected || !box.clientHeight) return;        // a log that left the page says nothing about where they read
      if (!c.hold && !box._end) { c.stick = nearEnd(box); if (c.stick) c.unseen = 0; }
      endBtn(box, c);
      clearTimeout(saveT);
      saveT = setTimeout(() => { if (!box.isConnected || !box.clientHeight || c.hold) return; c.pos = spot(box, c.stick); writePos(s.id, c.pos); }, 120);
    }, {passive: true});
    box.addEventListener("load", (e) => { if (c.stick && e.target.tagName === "IMG") box.scrollTop = box.scrollHeight; }, true);
    box.addEventListener("click", (e) => { const cp = e.target.closest("[data-copy]"), ol = e.target.closest(".pj-older"), bk = e.target.closest(".pj-bk");
      if (ol) { older(c, s, ol); return; }
      if (bk) { e.preventDefault(); markLine(c, bk.parentNode); return; }
      if (cp) { e.preventDefault(); if (cp.dataset.copy === "code") { const pre = cp.parentNode.querySelector("pre"); copyText(selectedText(pre) || (pre ? pre.textContent.replace(/\n$/, "") : "")); } else copyLine(cp.closest(".pj-msg")); return; }
      const b = e.target.closest(".pj-pic,.pj-md img"), im = b && (b.tagName === "IMG" ? b : b.querySelector("img")); if (im) { e.preventDefault(); picView(box, im); } });
    ["wheel", "touchstart", "pointerdown", "keydown"].forEach((t) => conv.addEventListener(t, () => letGo(box, c), {passive: true}));
    ["wheel", "touchstart", "pointerdown"].forEach((t) => box.addEventListener(t, () => endStop(box, c), {passive: true}));
    conv.addEventListener("keydown", (e) => {
      // The floating stack has Alt+Up / Alt+Down for its own cards.
      if (!FLOAT && e.altKey && (e.key === "ArrowUp" || e.key === "ArrowDown") && !e.ctrlKey && !e.shiftKey && !e.metaKey) { e.preventDefault(); hop(box, c, e.key === "ArrowUp" ? -1 : 1); return; }
      if (e.key !== "End" || e.altKey || e.shiftKey || e.metaKey || e.target.closest("input,textarea,select,[contenteditable]")) return;
      e.preventDefault(); toEnd(box, c);
    });
    pill.onmousedown = (e) => e.preventDefault();               // the composer keeps the keyboard
    pill.onclick = () => { const mine = document.activeElement === pill; toEnd(box, c); if (mine) ta.focus({preventScroll: true}); };
    // Copy buttons preserve the browser selection; a long press uses the native text menu.
    box.addEventListener("mousedown", (e) => { if (e.target.closest("[data-copy],.pj-bk")) e.preventDefault(); });
    const copyText = (text) => {
      const no = () => toast(tl("pj.copyFail"));
      try { navigator.clipboard.writeText(text).then(() => toast(tl("pj.copied")), no); } catch (e) { no(); }
    };
    const copyLine = (m) => {
      const selected = selectedText(m); if (selected) return copyText(selected);
      // An answer is copied as the session wrote it (Markdown: its tables, lists and code fences).
      const src = m.classList.contains("claude") ? entryOf(c, m) : null;
      const tm = m.querySelector(".pj-tm"); if (tm) tm.style.display = "none";   // the words, not when they were said
      const tg = m.querySelector(".tg"), all = m.innerText;        // innerText keeps the line breaks as drawn
      if (tm) tm.style.display = "";
      const text = src ? Redact.show(src.text).trim() : (tg && all.endsWith(tg.innerText) ? all.slice(0, -tg.innerText.length) : all).trim();
      const sp = window.Motion && Motion.SPRINGS && Motion.SPRINGS.snap;
      if (!RM()) m.animate([{transform: "scale(.97)"}, {transform: "none"}], {duration: sp ? sp.ms : 320, easing: sp ? sp.ease : "ease-out"});
      copyText(text);
    };
    // The room for the log changes (the keyboard comes up, the box grows a line): what was at
    // the bottom edge stays at the bottom edge, so the line being answered is not pushed under.
    if (typeof ResizeObserver === "function") {
      // The same watch covers the lines (paint() adds them): one that grows late - a picture, a
      // font, a code block - must not push the newest out of sight while the log is at the end.
      let h0 = box.clientHeight;
      box._ro = new ResizeObserver((es) => {
        const mine = es.some((e) => e.target === box), was = h0, h = box.clientHeight, d = was - h;
        if (mine) h0 = h;
        if (!h) return;
        if (c.hold) seat(box, c.hold);
        else if (c.stick) { if (!box._end) box.scrollTop = box.scrollHeight; }
        else if (mine && d) { if (was) box.scrollTop += d; else seat(box, c.pos); }   // back from hidden: where they were
        endBtn(box, c);
      });
      box._ro.observe(box);
    }
    if (body.dataset.multi) body.querySelector("#pj-side").remove();   // a pane is only the chat
    paint(body, c, true); side(sideOf(body), name, c);
    start(body, s, name, my);
  }
  // chat-recall:begin
  // The words of the newest line I sent in this chat ("" when there is none): one still on its
  // way first, else the newest of mine in the record. Pictures stay where they were.
  function lastMine(c) {
    const p = c.pend[c.pend.length - 1];
    if (p) return parts(p.text).words;
    for (let i = c.entries.length - 1; i >= 0; i--) if (c.entries[i].kind === "user") return parts(unnote(c.entries[i].text)).words;
    return "";
  }
  // Every line I sent in this chat, newest first, for stepping further back with Up; one said
  // twice in a row is one step.
  function mineAll(c) {
    const all = c.pend.map((p) => p.text).reverse().concat(c.entries.filter((e) => e.kind === "user").map((e) => unnote(e.text)).reverse());
    return all.map((t) => parts(t).words).filter((t, i, a) => t && t !== a[i - 1]);
  }
  // chat-recall:end
  // chat-export:begin (pure; tests/chatexport.test.js runs this block on its own)
  // The newest answer whole: everything the session said after my last line that it answered (one
  // answer is several lines here when tools ran in between), as it wrote it - Markdown and all.
  function lastAnswer(entries) {
    const out = [];
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i];
      if (e.kind === "user" && out.length) break;
      if ((e.kind === "claude" || e.kind === "files") && e.text) out.unshift(e.text.trim());
    }
    return out.join("\n\n");
  }
  // The conversation as loaded, as a Markdown document: who speaks and when
  // over each turn (not a heading: answers bring their own), tool lines left out.
  function convMarkdown(entries, o) {
    const out = ["# " + o.title];
    let who = "";
    entries.forEach((e) => {
      const mine = e.kind === "user", text = mine ? o.words(e.text) : e.kind === "claude" || e.kind === "files" ? (e.text || "").trim() : "";
      if (!text) return;
      const w = mine ? o.me : o.agent;
      if (w !== who) { out.push("**" + w + "**" + (e.at ? " · " + o.when(e.at) : "")); who = w; }
      out.push(text);
    });
    return out.join("\n\n") + "\n";
  }
  // chat-export:end
  // chat-turns:begin (pure; tests/chatturns.test.js runs this block on its own)
  // One row per line of mine, in the order said: where it is, when, and what the session did before
  // my next one - when it last wrote, how many lines it said, how many tool calls, how many files it
  // changed, and what the record says its answers cost to write (an answer is several lines here,
  // each with the same count, so a count is taken once per answer id).
  function turnList(entries) {
    const out = []; let t = null, ids = null, files = null;
    entries.forEach((e, i) => {
      if (e.kind === "user") { ids = new Set(); files = new Set(); out.push(t = {i, at: e.at || "", text: e.text || "", end: "", said: 0, tools: 0, files: 0, out: 0}); return; }
      if (!t) return;
      if (e.at && e.kind !== "res") t.end = e.at;
      if (e.kind === "claude") t.said++;
      if (e.kind === "tool") { t.tools++; if (e.cat === "edit" && e.what) { files.add(e.what); t.files = files.size; } }
      if (e.mid && !ids.has(e.mid)) { ids.add(e.mid); t.out += e.out || 0; }
    });
    return out;
  }
  // What came in from one line of the session's on (the line the "새 글" mark stands over).
  function recapOf(entries, at) {
    const i = at ? entries.findIndex((e) => e.kind === "claude" && e.at === at) : -1; if (i < 0) return null;
    const files = new Set(), r = {said: 0, tools: 0, files: 0};
    entries.slice(i).forEach((e) => { if (e.kind === "claude") r.said++; else if (e.kind === "tool") { r.tools++; if (e.cat === "edit" && e.what) files.add(e.what); } });
    r.files = files.size; return r;
  }
  // The n-th line said at `at` on one side, as the log draws them: a line of mine, or one the
  // session wrote (whatever is not mine, a tool call, thinking, or a part of another line).
  const LINE_SIDE = (e) => e.kind === "user" ? "user" : e.kind === "tool" || e.kind === "think" || e.kind === "sub" || e.kind === "res" || e.kind === "files" || e.sub ? "" : "claude";
  const nthOf = (entries, side, at, n) => entries.filter((e) => e.at === at && LINE_SIDE(e) === side)[n] || null;
  // "[Genok 코멘트] 프로젝트 / 결과물 · v002 · 1건": which result a comment line is about, and
  // where its name stands in the line (`a`..`b`).
  function commentRef(text) {
    const m = /^\[Genok 코멘트\] (.+?) \/ (.+?) · v\d+ · /.exec(String(text || "")); if (!m) return null;
    const a = m[0].indexOf("] ") + 2;
    return {project: m[1], title: m[2], a, b: a + m[1].length + 3 + m[2].length};
  }
  // Words found in a line, marked. `words` are lower case; the line keeps its own letters.
  function markWords(text, words, esc) {
    const low = text.toLowerCase(), cuts = [];
    words.forEach((w) => { for (let i = low.indexOf(w); w && i >= 0; i = low.indexOf(w, i + w.length)) cuts.push([i, i + w.length]); });
    cuts.sort((x, y) => x[0] - y[0]);
    let out = "", at = 0;
    cuts.forEach(([x, y]) => { if (x < at) return; out += esc(text.slice(at, x)) + "<mark>" + esc(text.slice(x, y)) + "</mark>"; at = y; });
    return out + esc(text.slice(at));
  }
  // chat-turns:end
  // Phone: 결과물 is one step of history over the chat, so Back (the browser's, Android's) returns to
  // the chat and not to the list. The 대화 tab takes the same step back. True when Back will do the rest.
  let sideTok = 0;
  function sideStep(to) {
    if (wide()) return false;
    try {
      if (to === "side") { if (tab !== "side") history.pushState({pjside: sideTok = Date.now()}, ""); }
      else if (tab === "side" && history.state && history.state.pjside === sideTok) { history.back(); return true; }
    } catch (e) { /* no history here: the tab still switches */ }
    return false;
  }
  addEventListener("popstate", () => {
    if (tab !== "side" || wide() || (history.state && history.state.pjside === sideTok)) return;
    sideTok = 0;
    const t = document.querySelector('#view .pj-seg [data-t="conv"]'); if (t) t.click();
  });
  function cols(body) {
    body.querySelectorAll("[data-col]").forEach((c) => c.style.display = (threeCols() || c.dataset.col === tab) ? "" : "none");
    phoneChat();
  }

  // The row above the chat: what the session is doing (the orb moves while it works or when we
  // wait for its answer), then its actions.
  function pjState(c) {
    const st = (c.state && c.state.state) || "ended", s = c.state || {}, ch = s.changes;
    const n = ch ? (ch.files || 0) + (ch.untracked || 0) : 0;
    const k = pjKindOf(st, s.last), doing = busy[s.id];
    let mk, label;
    // A plain mark, the same family as the list's dots: a ring that turns while something is on its way.
    if (doing) { mk = `<span class="pj-spin" aria-hidden="true"></span>`; label = doing; }
    else if (st === "live") { mk = dot("live"); label = LABEL.live; }
    else if (c.waiting && st !== "ended") { mk = `<span class="pj-spin" aria-hidden="true"></span>`; label = tl("pj.st.waiting"); }
    else { mk = dot(k); label = LABEL[k] || k; }
    // The session's own actions sit in the open under its state, each with what it does to the
    // conversation; the menu keeps the full list with a line of explanation per row.
    const d = doing ? "disabled" : "";
    const btn = (a, pri) => { const o = what(a, s); return o.off ? "" : `<button class="pj-act press${pri ? " pri" : ""}" data-act="${a}" ${d} title="${esc(o.sub || "")}">${esc(o.label)}</button>`; };
    // One that ended keeps a single small 이어서 하기 beside its state (typing below wakes it too);
    // 새로 켜기 and 목록에서 숨기기 are in the menu at the end of the row.
    const acts = st === "ended" ? "" : btn("fresh") + btn("lighten") + btn("stop"), wake = st === "ended" ? btn("open", true) : "";
    return `<div class="pj-state">${mk}<span class="pj-stl ${doing ? "" : k}">${esc(label)}</span><span class="pj-stx">${c.room ? `<span class="pj-stp">${esc(" · " + pname(c.room))}</span>` : ""} · <span class="pj-agw ${s.agent === "codex" ? "cx" : "cl"}">${s.agent === "codex" ? "Codex" : "Claude Code"}</span></span>${c.offline ? `<span class="off">${tl("pj.offline")}</span>` : ""}${s.bg ? `<span class="pj-bg">${tl("pj.bg")}</span>` : ""}${s.moved ? `<span class="pj-bg">${tl("pj.moved")}</span>` : ""}<span class="sp"></span>
      ${n ? `<button class="pj-chg press" data-chg title="${tl("pj.chg.t")}">${tl("pj.chg", {n})}${ch.ins ? ` <span class="a">+${ch.ins}</span>` : ""}${ch.del ? ` <span class="d">-${ch.del}</span>` : ""}</button>` : ""}
      ${s.bg ? `<button class="pj-text press" data-bglog>${tl("pj.bglog")}</button>` : ""}
      ${wake}<button class="pj-more press" data-cmenu aria-label="${tl("pj.menu")}" title="${tl("pj.menu")}" style="margin:-4px -6px -4px 0">${ic("more")}</button></div>
      ${acts ? `<div class="pj-acts">${acts}</div>` : ""}`;
  }
  const LIGHT = LT(() => ({writing: tl("pjx.lg.writing"), opened: tl("pjx.lg.opened"),
    timeout: tl("pjx.lg.timeout"), failed: tl("pjx.lg.failed")}));
  const span = (sec) => sec < 60 ? tl("pjx.sec", {n: Math.max(0, Math.round(sec))}) : tl("pjx.min", {n: Math.floor(sec / 60)});
  const permFor = (iso) => { const sec = iso ? (Date.now() - Date.parse(iso)) / 1000 : 0; return !(sec > 0) ? "" : sec >= 3600 ? tl("pjx.hr", {n: Math.floor(sec / 3600)}) : span(sec); };
  // codex-question:begin
  // A question Codex asks mid-turn (request_user_input): each one with its options, one of which
  // may be pressed, and a line for the person's own words where the question takes them.
  const qHtml = (a) => `<div class="pj-q"><b>${tl("room.codexAskQ")}</b>${a.questions.map((q) => `<div class="pj-qq" data-qid="${esc(q.id)}"><div>${q.header ? `<b>${esc(q.header)}</b> · ` : ""}${esc(q.question)}</div>${
    q.options.map((o) => `<div><button class="press" data-qpick="${esc(o.label)}" aria-pressed="false">${esc(o.label)}</button>${esc(o.description)}</div>`).join("")}${
    q.other ? `<input type="${q.secret ? "password" : "text"}" autocomplete="off" placeholder="${tl("room.codexQNote")}" aria-label="${tl("room.codexQNote")}">` : ""}</div>`).join("")
    }<div class="pj-qa"><button class="press" data-approve="1" data-aid="${esc(a.id)}">${tl("room.codexQSend")}</button><button class="press" data-approve="0" data-aid="${esc(a.id)}">${tl("room.codexQSkip")}</button></div></div>`;
  const qPick = (b) => { const on = b.getAttribute("aria-pressed") === "true";
    b.closest("[data-qid]").querySelectorAll("[data-qpick]").forEach((n) => n.setAttribute("aria-pressed", "false"));
    b.setAttribute("aria-pressed", on ? "false" : "true"); };
  const qAnswers = (box) => { const out = {};
    box.querySelectorAll("[data-qid]").forEach((q) => { const p = q.querySelector('[data-qpick][aria-pressed="true"]'), n = q.querySelector("input");
      out[q.dataset.qid] = {pick: p ? p.dataset.qpick : "", note: n ? n.value : ""}; });
    return out; };
  // codex-question:end
  // The plain sentence under it: how a line will travel, or what is wrong.
  function note(c) {
    const st = (c.state && c.state.state) || "ended", s = c.state || {};
    let line, bad = false, tail = "";
    // Claude Code's own permission dialog is up: words typed here queue behind it and do not answer it.
    const perm = s.agent !== "codex" && attL("rooms").find((r) => r.key === c.out && r.job === "blocked" && r.needs === "permission prompt");
    if (st === "stuck") { line = s.stuck_hint || tl("pj.note.stuck"); bad = true; }
    else if (s.agent === "codex") { line = s.cut ? tl("room.codexCut") : tl("room.codexNote"); bad = !!s.cut;
      tail = (s.cut ? "" : tl("room.codexNoteMore") + " ") + (s.in_app === false ? tl("room.codexOnlyHere") : ""); }
    else if (st === "ended") line = "";      // the box's own placeholder already says a line continues it
    else if (perm) { line = tl("pj.note.perm", {t: permFor(perm.active)}).replace("  ", " "); }
    else if (s.reachable) line = tl("pj.note.live");
    else line = tl("pj.note.later");
    // 새로 옮기기 always ends in words: how long it has been writing and when it gives up, the
    // way to the new session once it is open, or why it stopped.
    const L = s.lighten, lg = L && LIGHT[L.state];
    let more = "";
    if (lg) {
      const txt = L.state === "writing" && L.at ? (L.limit ? tl("pjx.lg.forLim", {lg, t: span(Date.now() / 1000 - L.at), lim: span(L.limit)}) : tl("pjx.lg.for", {lg, t: span(Date.now() / 1000 - L.at)})) : (L.why || lg);
      more = `<div class="${L.state === "timeout" || L.state === "failed" ? "bad" : ""}"><b>${tl("pjx.move")}</b> · ${esc(txt)}${L.state === "opened" && L.new ? `<button class="press" data-gonew="${esc(L.new)}">${tl("pjx.lg.go")}</button>` : ""}</div>`;
    } else if (s.ask && s.ask.kind === "question") more = qHtml(s.ask);
    else if (s.ask) {
      // Codex is waiting to be allowed something: said in full, answered here, never on its own.
      const a = s.ask, what = (a.command || a.reason || "") + (a.cwd ? " (" + a.cwd + ")" : "");
      more = `<div style="overflow-wrap:anywhere"><b>${a.kind === "patch" ? tl("room.codexAskFile") : tl("room.codexAskCmd")}</b> · ${esc(what)}<div class="pj-qa"><button class="press" data-approve="1" data-aid="${esc(a.id)}">${tl("room.codexAllow")}</button><button class="press" data-approve="0" data-aid="${esc(a.id)}">${tl("room.codexDeny")}</button></div></div>`;
    } else if (s.moved) more = `<div><b>${tl("pjx.moved")}</b> · ${tl("pjx.moved.d")}</div>`;
    // The Codex app shows a conversation only under a folder it has as a project, so this opens it there by its link.
    const cx = s.agent === "codex" && s.in_app === false ? ` · ${tl("room.codexNotInApp")}` : "";
    return `${line ? `<div class="${bad ? "bad" : line === tl("pj.note.live") ? "nl" : ""}">${more1(esc(line), esc(tail.trim()), "pjnote")}${cx}</div>` : ""}${more}`;
  }

  // ---- pictures in the chat -----------------------------------------------------------------------
  // A file that is not a picture goes by its name (the server keeps the same list: text, code, PDF);
  // the session gets the saved path and reads it itself. Text is 1 MB at most, a PDF 20 MB.
  const IMG_MAX = 4, IMG_BYTES = 20 * 1024 * 1024, DOC_MAX = 4, TEXT_BYTES = 1024 * 1024;
  const DOC_EXT = /\.(pdf|txt|md|markdown|log|csv|tsv|json|jsonl|ya?ml|toml|ini|cfg|conf|env|pyi?|[mc]?js|tsx?|jsx|s?css|[ch]|cc|[ch]pp|cs|java|kt|go|rs|rb|php|swift|sh|bash|zsh|ps1|bat|cmd|sql|diff|patch|tex|rst|lua|r|dart|vue)$/i;
  function addFiles(body, c, files) {
    for (const f of files) {
      const pic = f.type.startsWith("image/");
      if (!pic && !DOC_EXT.test(f.name)) { toast(tl("pj.file.kind")); continue; }
      if (f.size > (pic || /\.pdf$/i.test(f.name) ? IMG_BYTES : TEXT_BYTES)) { toast(pic ? tl("pj.img.size") : tl("pj.file.size")); continue; }
      if (pic && c.imgs.filter((im) => im.url).length >= IMG_MAX) { toast(tl("pj.img.max", {n: IMG_MAX})); continue; }
      if (!pic && c.imgs.filter((im) => !im.url).length >= DOC_MAX) { toast(tl("pj.file.max", {n: DOC_MAX})); continue; }
      c.imgs.push(pic ? {blob: f, url: URL.createObjectURL(f)} : {blob: f, name: f.name});
    }
    chips(body, c);
  }
  function chips(body, c) {
    const box = body.querySelector("#pj-att"); if (!box) return;
    box.hidden = !c.imgs.length;
    box.innerHTML = c.imgs.map((im, i) => `<div class="th${im.url ? "" : " doc"}">${im.url ? `<img src="${im.url}" alt="">` : ic("doc") + `<span>${esc(im.name)}</span>`}<button data-imgrm="${i}" aria-label="${tl("pj.img.rm")}">${ic("x")}</button></div>`).join("");
    if (c.sync && c.body === body) c.sync();
  }
  async function uploadImgs(imgs, sid) {
    if (!imgs.length) return [];
    const t = await act("/api/session/attach-target", {sid}), out = [];
    for (const im of imgs) {
      const r = await fetch(`/api/attach?p=${enc(t.p)}&i=${enc(t.i)}` + (im.name ? "&n=" + enc(im.name) : ""), {method: "POST", headers: {"Content-Type": im.blob.type || (im.name ? "application/octet-stream" : "image/png")}, body: im.blob});
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || tl("pj.img.fail"));
      out.push(j.path);
    }
    return out;
  }
  // A picture travels as a "clip <path>" line (like a comment); the chat shows it as a picture.
  const CLIP = "📎 ";
  function picUrl(path) {
    const seg = String(path).split(/[\\/]/), k = seg.lastIndexOf("_attach");
    return k >= 2 && seg[k + 1] ? "/f/" + enc(seg[k - 2]) + "/" + enc(seg[k - 1]) + "/_attach/" + enc(seg[k + 1]) : "";
  }
  function parts(t) {
    const pics = [], words = [];
    // A clipped file that is no picture stays in the words, by its name alone.
    String(t || "").split("\n").forEach((ln) => { const l = ln.trim(); if (!l.startsWith(CLIP)) words.push(ln); else if (PIC_EXT.test(l)) pics.push(picUrl(l.slice(CLIP.length))); else words.push(CLIP + l.split(/[\\/]/).pop()); });
    return {words: words.join("\n").trim(), pics: pics.filter(Boolean)};
  }
  const rich = (t) => esc(parts(t).words);
  // The pictures of one line: their own block above its words, each opening in the viewer.
  const picRow = (urls, cls) => !urls.length ? "" : `<div class="pj-pics${urls.length === 1 ? " one" : ""}${cls || ""}">${urls.map((u) =>
    `<button type="button" class="pj-pic press" aria-label="${esc(tl("pj.pic.open"))}"><img src="${esc(u)}" alt="" loading="lazy" draggable="false"></button>`).join("")}</div>`;
  // The app's own viewer (v2.js) over the chat: every picture of this conversation, this one first.
  function picView(box, img) {
    if (typeof viewer !== "function") return;
    const all = [...box.querySelectorAll(".pj-pic img, .pj-md img")], back = img.closest("button") || document.activeElement;
    viewer(all.map((n) => ({url: n.currentSrc || n.src, name: n.alt || "", kind: "image"})), Math.max(0, all.indexOf(img)), null);
    const vw = [...document.querySelectorAll(".vw")].pop(); if (!vw) return;
    const ext = vw.querySelector(".vtop a"); if (ext) ext.style.display = "none";   // nothing here opens another window
    new MutationObserver((_, mo) => { if (vw.isConnected) return; mo.disconnect(); if (back && back.isConnected) back.focus({preventScroll: true}); }).observe(document.body, {childList: true});
  }

  // ---- sheets: changes list, background screen ----------------------------------------------------------
  // A path wraps after a folder, not in the middle of a name.
  const pathHtml = (p) => esc(p).replace(/([\\/])/g, "$1<wbr>");
  async function showChanges(sid) {
    // What the session itself wrote, from its record (no git needed): each file's lines in and out,
    // opening on the edits as the record has them. Only Edit and Write calls leave such a record.
    const rec = (convs[sid] && convs[sid].work && convs[sid].work.files) || [];
    const r = await readOrAsk("/api/project/changes?id=" + enc(sid)).catch((e) => { if (!rec.length) toast(tl("pjx.chg.fail") + " " + (e.message || "")); return rec.length ? {} : null; });
    if (!r || r.declined) return;
    const files = (r.files || []).map((f) => `<div><span class="p">${pathHtml(f.path)}</span><span class="n">${f.ins ? "+" + f.ins : ""} ${f.del ? "-" + f.del : ""}</span></div>`);
    const un = (r.untracked || []).map((f) => `<div><span class="p">${pathHtml(f)}</span><span class="n">${tl("pjx.chg.new")}</span></div>`);
    const mine = rec.map((f, i) => `<div class="rw"><button type="button" data-df="${i}" aria-expanded="false"><span class="p">${pathHtml(Redact.show(f.path))}</span><span class="n"><i class="da">+${f.add}</i> <i class="dd">−${f.del}</i></span></button></div>`);
    sheet(`<div class="pj-dlg"><h3>${tl("pjx.chg.rec")}</h3><div class="pj-dnone">${tl("pjx.chg.rec.d")}</div>
      <div class="pj-files pj-chgs">${mine.join("") || `<div><span class="p">${tl("pjx.chg.rec.none")}</span></div>`}</div>
      <div class="pj-lab">${tl("pjx.chg.h")}</div><div class="pj-files">${files.concat(un).join("") || `<div><span class="p">${tl("pjx.chg.none")}</span></div>`}</div></div>`, (box) => {
      box.querySelectorAll("[data-df]").forEach((b) => b.onclick = async () => {
        const row = b.parentNode, was = row.querySelector(".dv"); b.setAttribute("aria-expanded", was ? "false" : "true");
        if (was) return was.remove();
        row.insertAdjacentHTML("beforeend", `<div class="dv"><div class="pj-dnone">${tl("pj.diff.wait")}</div></div>`);
        const ds = await loopFetch("/api/sessions/diff?id=" + enc(sid) + "&path=" + enc(rec[+b.dataset.df].path)).then((d) => d.diffs || [], () => []);
        const dv = row.querySelector(".dv"); if (dv) dv.innerHTML = diffHtml(ds);
      });
    });
  }
  // The record takes about a second to read: the button says so at once, a second press waits, and an
  // answer that comes after the screen was left opens nothing over the next one.
  async function showAgentLog(bg, btn) {
    if (!bg || !bg.id || (btn && btn.getAttribute("aria-busy"))) return;
    const at = location.hash;
    if (btn) btn.setAttribute("aria-busy", "true");
    const r = await readOrAsk("/api/project/agent-log?id=" + enc(bg.id)).catch((e) => ({error: e.message}));
    if (btn) btn.removeAttribute("aria-busy");
    if (r.declined || location.hash !== at) return;
    sheet(`<div class="pj-dlg"><h3>${tl("pjx.bg.h")}</h3><pre class="pj-log">${esc(r.text || r.error || tl("pjx.bg.none"))}</pre></div>`, () => {});
  }

  // `held`: a line still waiting (drawn again on every paint), with the class it carries.
  const PIC_EXT = /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/i;
  function sentHtml(e) {
    const fs = (e.files || []).filter((f) => f && f.url), pics = fs.filter((f) => PIC_EXT.test(f.name)), rest = fs.filter((f) => !PIC_EXT.test(f.name));
    return picRow(pics.map((f) => f.url), " sent")
      + (rest.length ? `<div class="pj-sent">${rest.map((f) => `<a class="pj-file press" href="${esc(f.url)}" target="_blank" rel="noopener noreferrer">${ic("doc")}<span>${esc(f.name)}</span></a>`).join("")}</div>` : "")
      + (e.text ? `<div class="pj-msg claude"${e.at ? ` data-at="${esc(e.at)}"` : ""}>${marked(e.text)}</div>` + pvHtml(e.text) : "");
  }
  function bubble(e, pending, held) {
    if (e.kind === "files") return sentHtml(e);
    if (e.kind === "sub" || e.kind === "res") return "";  // a part of another line: subs() and acts() fold it into that line
    if (e.kind === "think" || (e.kind === "tool" && e.id && !e.sub)) return actRow(e);
    if (e.sub) return `<div class="pj-sub" data-sub="${esc(e.sub.id)}"${e.at ? ` data-at="${esc(e.at)}"` : ""}><button type="button" class="pj-subh" aria-expanded="false"><span class="smk" aria-hidden="true"></span><span class="stx"></span>${ic("chev")}</button></div>`;
    const k = e.kind === "user" ? "user" : e.kind === "tool" ? "tool" : "claude";
    const tag = pending ? `<span class="tg">${esc(pending)}</span>` : e._recv ? `<span class="tg ok">${tl("pj.recv")}</span>` : "";
    const u = k === "user" ? parts(unnote(e.text)) : null, pd = held == null ? "" : "data-pend ";
    // Pictures put in from an official app with no words: the line this app writes for its own.
    if (u && !u.words && (e.imgs || []).length) u.words = tl("pj.img.look");
    // A long line of mine shows its first lines; the button under it opens the rest in place.
    const lk = u && !pending && (u.words.length > UL_CHARS || u.words.split("\n").length > UL_LINES) ? (e.at || "") + ":" + u.words.length : "";
    // e.imgs: pictures put in from an official app, read out of the record (the server's addresses).
    return (u ? picRow((e.imgs || []).concat(u.pics), pending ? " pending" : "").replace("<div ", "<div " + pd) : "")
      + `<div ${pd}class="pj-msg ${k}${pending ? " pending" : ""}${held || ""}${lk && !ulOpen.has(lk) ? " clip" : ""}"${e.at ? ` data-at="${esc(e.at)}"` : ""}>${u ? (lk ? `<span class="ut">${mineHtml(u.words)}</span><button type="button" class="um" data-ul="${esc(lk)}">${ulOpen.has(lk) ? tl("pj.act.less") : tl("pj.act.more")}</button>` : mineHtml(u.words)) : k === "claude" ? marked(e.text) : esc(Redact.show(e.text))}${k === "tool" || pending ? "" : tmHtml(e.at) + cpBtn() + (e.at ? bkBtn() : "")}${tag}</div>` + (k === "claude" && !pending ? pvHtml(e.text) : "");
  }
  const ulOpen = new Set(), UL_CHARS = 1200, UL_LINES = 12;
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-msg.user>.um"); if (!b) return;
    const k = b.dataset.ul, open = !ulOpen.has(k), box = b.closest(".pj-msgs"), y = b.getBoundingClientRect().top;
    if (open) ulOpen.add(k); else ulOpen.delete(k);
    b.parentNode.classList.toggle("clip", !open); b.textContent = open ? tl("pj.act.less") : tl("pj.act.more");
    if (box && !open) box.scrollTop += b.getBoundingClientRect().top - y;
  });
  // ---- quote what is selected into the reply ---------------------------------------------------------
  // Words selected in the log get one small button under them; it puts them in the box as a quote
  // ("> " lines) with the caret after, ready for the reply.
  let qBtn = null, pBtn = null;
  document.addEventListener("selectionchange", () => {
    const sel = document.getSelection(), a = sel && !sel.isCollapsed && sel.toString().trim() ? sel.anchorNode : null;
    const box = a && (a.nodeType === 1 ? a : a.parentElement).closest(".pj-msgs"), wrap = box && box.contains(sel.focusNode) && box.closest(".pj-conv .pj-wrap");
    if (!wrap) { if (qBtn) { qBtn.remove(); qBtn = null; } if (pBtn) { pBtn.remove(); pBtn = null; } return; }
    if (!qBtn || qBtn.parentNode !== wrap) {
      if (qBtn) qBtn.remove();
      wrap.insertAdjacentHTML("beforeend", `<button type="button" class="pj-quote press">${tl("pj.quote")}</button>`); qBtn = wrap.lastChild;
      if (!RM()) qBtn.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
      qBtn.onmousedown = (e) => e.preventDefault();          // the selection and the caret stay as they are
      qBtn.onclick = () => {
        const ta = wrap.closest(".pj-conv").querySelector("#pj-ta"), q = document.getSelection().toString().trim().split("\n").map((l) => "> " + l).join("\n");
        ta.value = (ta.value.trim() ? ta.value.replace(/\s*$/, "\n\n") : "") + q + "\n\n";
        document.getSelection().removeAllRanges(); ta.dispatchEvent(new Event("input", {bubbles: true})); ta.focus();
      };
    }
    const r = sel.getRangeAt(0).getBoundingClientRect(), w = wrap.getBoundingClientRect();
    // 고정 stands beside 인용 while the words are inside one line that can be kept: it keeps that
    // line, named by the words selected (a finger has no button beside the line).
    const an = a.nodeType === 1 ? a : a.parentElement, fo = sel.focusNode.nodeType === 1 ? sel.focusNode : sel.focusNode.parentElement;
    const ln = an.closest(".pj-msg"), can = ln && ln === fo.closest(".pj-msg") && ln.querySelector(":scope>.pj-bk") && box._c;
    if (!can && pBtn) { pBtn.remove(); pBtn = null; }
    if (can && (!pBtn || pBtn.parentNode !== wrap)) {
      if (pBtn) pBtn.remove();
      wrap.insertAdjacentHTML("beforeend", `<button type="button" class="pj-quote press"></button>`); pBtn = wrap.lastChild;
      if (!RM()) pBtn.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"});
      pBtn.onmousedown = (e) => e.preventDefault();
    }
    if (pBtn) {
      pBtn.textContent = ln.hasAttribute("data-mk") ? tl("pj.mark.off") : tl("pj.mark.on");
      pBtn.onclick = () => { const words = document.getSelection().toString().trim(); document.getSelection().removeAllRanges(); markLine(box._c, ln, words); };
    }
    const both = qBtn.offsetWidth + (pBtn ? pBtn.offsetWidth + 6 : 0), top = Math.max(4, Math.min(r.bottom - w.top + 6, w.height - qBtn.offsetHeight - 4)) + "px";
    const left = Math.max(8, Math.min(r.left - w.left, w.width - both - 8));
    qBtn.style.top = top; qBtn.style.left = left + "px";
    if (pBtn) { pBtn.style.top = top; pBtn.style.left = left + qBtn.offsetWidth + 6 + "px"; }
  });
  // ---- when each line was said ---------------------------------------------------------------------
  // The time is the transcript's own (a record without one shows nothing). Today, within the hour:
  // "방금", "3분 전"; after that the clock; another day: the clock under a line naming the day.
  const tmMs = (at) => { const t = at ? Date.parse(at) : NaN; return isFinite(t) ? t : null; };
  const tmDay = (ms) => { const d = new Date(ms); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
  const tmLoc = () => LANG() === "ko" ? "ko-KR" : "en-US";
  // Speaking into the box (web/dictate.js): the mic is drawn only where the browser can listen.
  const SPEECH = window.Dictate && Dictate.SPEECH;
  // Discard, level, mic: the three that go before send in a message box (this chat's and a new one's).
  const micHtml = () => SPEECH ? `<button class="pj-clip pj-vx press" id="pj-vx" aria-label="${tl("pj.mic.drop")}" title="${tl("pj.mic.drop")}">${ic("x")}</button><span class="pj-wave" aria-hidden="true"></span>
          <button class="pj-clip pj-mic press" id="pj-mic" aria-pressed="false" aria-label="${tl("pj.mic")}" title="${tl("pj.mic")}">${ic("mic")}${ic("stopfill")}</button>` : "";
  const micWire = (body, ta) => { const mic = body.querySelector("#pj-mic");
    if (mic) { mic.onclick = () => Dictate.listen(ta, mic, mic.closest(".pj-box"), "pj-rec"); body.querySelector("#pj-vx").onclick = Dictate.drop; } };
  function tmText(ms, now) {
    const m = Math.floor((now - ms) / 6e4);
    if (m > -2 && m < 60 && tmDay(ms) === tmDay(now)) return {rel: true, text: m < 1 ? tl("ago.2") : tl("ago.3", {p0: m})};
    return {rel: false, text: new Date(ms).toLocaleTimeString(tmLoc(), {hour: "numeric", minute: "2-digit"})};
  }
  function tmHtml(at) {
    const ms = tmMs(at); if (ms == null) return "";
    const d = new Date(ms), t = tmText(ms, Date.now());
    // aria-live off: the log announces new lines, not a time that counts up.
    return `<time class="pj-tm" datetime="${d.toISOString()}" title="${esc(d.toLocaleString(tmLoc(), {dateStyle: "full", timeStyle: "short"}))}" aria-live="off"${t.rel ? " data-rel" : ""}>${esc(t.text)}</time>`;
  }
  // ---- what a turn did, folded -------------------------------------------------------------------------
  // A run of tool lines (and thinking the record kept in words) is one quiet row that says what kinds
  // of work it was: "명령 3 · 파일 5 · 검색 2". The row opens and closes the lines where they stand;
  // which runs are open is remembered by the run's first line for as long as the page lives. With
  // "대화에 작업 과정 보기" on they start open. Painting again only corrects the row's words and which
  // lines hide, so a line arriving in a live run moves nothing else.
  const tfOpen = new Set();
  function foldText(r) {
    const n = {}; r.forEach((x) => { const c = x.dataset.cat || "tool", k = c === "read" || c === "edit" ? "file" : c; n[k] = (n[k] || 0) + 1; });
    return [n.think ? tl("pj.act.think") : "", n.run ? tl("pj.act.run", {n: n.run}) : "", n.file ? tl("pj.act.file", {n: n.file}) : "",
      n.search ? tl("pj.act.search", {n: n.search}) : "", n.web ? tl("pj.act.web", {n: n.web}) : "", n.tool ? tl("pj.act.tool", {n: n.tool}) : ""].filter(Boolean).join(" · ");
  }
  function fold(box) {
    const runs = []; let cur = null;
    for (const n of box.children) {
      if (n.classList.contains("pj-tfold")) continue;
      if (n.classList.contains("tool")) { if (!cur) runs.push(cur = []); cur.push(n); } else cur = null;
    }
    const keep = new Set();
    runs.forEach((r) => {
      let b = r[0].previousElementSibling;
      if (!(b && b.classList.contains("pj-tfold"))) { r[0].insertAdjacentHTML("beforebegin", `<button type="button" class="pj-tfold"><span></span>${ic("chev")}</button>`); b = r[0].previousElementSibling; }
      keep.add(b);
      const k = r[0].dataset.tid || r[0].dataset.at || "", open = tfOpen.has(k) !== document.body.classList.contains("steps"), txt = foldText(r);
      b.dataset.k = k; b.setAttribute("aria-expanded", open ? "true" : "false");
      if (b.firstChild.textContent !== txt) b.firstChild.textContent = txt;
      r.forEach((x) => x.classList.toggle("fd", !open));
    });
    box.querySelectorAll(":scope>.pj-tfold").forEach((b) => { if (!keep.has(b)) b.remove(); });
  }
  // The row stays where it is under the pointer: whatever the log does with its height, it does below.
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".pj-tfold"), box = b && b.parentNode; if (!box) return;
    const y = b.getBoundingClientRect().top, k = b.dataset.k;
    if (tfOpen.has(k)) tfOpen.delete(k); else tfOpen.add(k);
    fold(box); if (box._actC) acts(box, box._actC); box.scrollTop += b.getBoundingClientRect().top - y;
  });
  // ---- one line of a run: a tool call or a thought ----------------------------------------------------
  // The line names the tool and what it was given; acts() adds what the record says came back (an
  // error, an edit's +/-). It opens in place on the whole command and the output, cut to a few
  // lines until asked for more; the server sends only the head of a long output and says how much
  // it left out. An edit opens on its diff, read once from the record by the call's id.
  const actOpen = new Set(), actFull = new Set(), actDiff = new Map(), ACT_LINES = 12;
  const thinkId = (e) => "think:" + (e.at || "") + ":" + (e.text || "").length;
  function actRow(e) {
    const think = e.kind === "think", file = e.cat === "read" || e.cat === "edit";
    const what = Redact.show(think ? e.text : file ? (e.what || "").split(/[\\/]/).slice(-2).join("/") : e.what || "").replace(/\s+/g, " ").slice(0, 200);
    return `<div class="pj-msg tool act" data-tid="${esc(think ? thinkId(e) : e.id)}" data-cat="${think ? "think" : esc(e.cat || "tool")}"${e.at ? ` data-at="${esc(e.at)}"` : ""}><button type="button" class="ah" aria-expanded="false"><b>${think ? tl("pj.act.think") : esc(e.name || "")}</b><span class="aw">${esc(what)}</span><span class="am"></span></button></div>`;
  }
  function diffHtml(ds) {
    if (!ds || !ds.length) return `<div class="pj-dnone">${tl("pj.diff.none")}</div>`;
    return ds.map((d) => `<div class="pj-diff">` + d.hunks.map((h) => `<div class="dh">@@ -${h.a} +${h.b} @@</div>`
      + h.lines.map((l) => `<div class="${l[0] === "+" ? "da" : l[0] === "-" ? "dd" : "dn"}">${esc(Redact.show(l)) || " "}</div>`).join("")).join("")
      + (d.cut ? `<div class="dh">${tl("pj.diff.cut")}</div>` : "") + `</div>`).join("");
  }
  function actBody(e, r, full, diff) {
    if (e.kind === "think") return `<div class="at">${plainLinks(Redact.show(e.text))}</div>`;
    const lines = r ? Redact.show(r.text).split("\n") : [], long = lines.length > ACT_LINES;
    return (e.what ? `<pre class="ac">${esc(Redact.show(e.what))}</pre>` : "")
      + (!r ? `<div class="an">${tl("pj.act.wait")}</div>`
        : r.add != null ? (diff ? diffHtml(diff) : `<div class="an">${tl("pj.diff.wait")}</div>`)
        : !r.text ? `<div class="an">${tl("pj.act.empty")}</div>`
        : `<pre class="ar${r.err ? " bad" : ""}">${esc((full ? lines : lines.slice(0, ACT_LINES)).join("\n"))}</pre>`
          + (long || r.more ? `<div class="an">${full && r.more ? `<span>${tl("pj.act.cut", {n: r.more.toLocaleString()})}</span>` : ""}`
            + `<button type="button" data-actmore>${full ? tl("pj.act.less") : tl("pj.act.more")}</button></div>` : ""));
  }
  function acts(box, c) {
    box._actC = c;
    const rows = box.querySelectorAll(":scope>.pj-msg.act"); if (!rows.length) return;
    const res = new Map(), src = new Map();
    c.entries.forEach((e) => { if (e.kind === "res") res.set(e.id, e); else if (e.kind === "think") src.set(thinkId(e), e); else if (e.kind === "tool" && e.id) src.set(e.id, e); });
    rows.forEach((n) => {
      const id = n.dataset.tid, r = res.get(id), head = n.firstChild, mk = head.lastChild, open = actOpen.has(id) && !n.classList.contains("fd");
      const m = !r ? "" : (r.err ? `<i class="bad">${tl("pj.act.err")}</i>` : "") + (r.add != null ? `<i class="da">+${r.add}</i><i class="dd">−${r.del}</i>` : "");
      if (mk._h !== m) { mk._h = m; mk.innerHTML = m; }
      head.setAttribute("aria-expanded", open ? "true" : "false");
      let b = n.querySelector(":scope>.ab");
      if (!open) { if (b) b.remove(); return; }
      const full = actFull.has(id), diff = actDiff.get(id), key = [r && r.text, full, !!diff, Redact.on()].join("\n");
      if (!b) { n.insertAdjacentHTML("beforeend", `<div class="ab"></div>`); b = n.lastChild; if (!RM()) b.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
      if (b._k !== key) { b._k = key; b.innerHTML = actBody(src.get(id) || {}, r, full, diff); }
      if (r && r.add != null && !actDiff.has(id) && c.sid) {
        actDiff.set(id, null);
        loopFetch("/api/sessions/diff?id=" + enc(c.sid) + "&call=" + enc(id)).then((d) => d.diffs || [], () => []).then((ds) => { actDiff.set(id, ds); if (box.isConnected) acts(box, box._actC); });
      }
    });
  }
  document.addEventListener("click", (e) => {
    const t = e.target.closest && e.target.closest(".pj-msg.act>.ah,[data-actmore]"), box = t && t.closest(".pj-msgs"); if (!box || !box._actC) return;
    const set = t.matches(".ah") ? actOpen : actFull, k = t.closest(".pj-msg.act").dataset.tid, y = t.getBoundingClientRect().top;
    if (set.has(k)) set.delete(k); else set.add(k);
    acts(box, box._actC); if (t.isConnected) box.scrollTop += t.getBoundingClientRect().top - y;
  });
  // ---- the session's task list ---------------------------------------------------------------------
  // The record's own list (TodoWrite, or the task tools), shown while something on it is still to
  // do: "2/5" and the item in hand, opening on every item with its state. Whether it is open is
  // the page's to remember, per session.
  const todoOpen = new Set();
  function todoStrip(body, c) {
    const el = body.querySelector("#pj-todo"); if (!el) return;
    const ts = (c.work && c.work.todos) || [], done = ts.filter((t) => t.state === "completed").length;
    el.hidden = !ts.length || done === ts.length; if (el.hidden) return;
    const now = ts.find((t) => t.state === "in_progress") || ts.find((t) => t.state !== "completed"), open = todoOpen.has(c.sid);
    const h = `<button type="button" aria-expanded="${open}"><b>${tl("pj.todo.n", {done, all: ts.length})}</b><span>${esc(Redact.show(now.text))}</span>${ic("chev")}</button>`
      + (open ? `<ul>${ts.map((t) => `<li class="${esc(t.state)}">${esc(Redact.show(t.text))}</li>`).join("")}</ul>` : "");
    if (el._h !== h) { el._h = h; el.innerHTML = h; }
    el.onclick = (e) => { if (!e.target.closest("button")) return; if (open) todoOpen.delete(c.sid); else todoOpen.add(c.sid); todoStrip(body, c); };
  }
  // ---- a subagent's run, one line -----------------------------------------------------------------
  // The call is the row (a tool line that carries `sub`, see session_view). What the record says
  // about the run later (the "sub" entries: started, ended, its report) is folded into that row
  // by the call's id, or by the agent's id where a line names only that. The row opens in place
  // on the brief and the report. Several runs in one turn get a line that adds them up and can
  // put the finished ones away. What is open or put away is remembered while the page lives.
  const subOpen = new Set(), subHid = new Set();
  const SUB_END = {completed: () => tl("pj.sub.done"), failed: () => tl("pj.sub.failed"), killed: () => tl("pj.sub.stopped"), stopped: () => tl("pj.sub.stopped")};
  // "claude-haiku-4-5-20251001" -> "Haiku 4.5": the family and its version as the id has them.
  const subModel = (id) => { const m = /^(?:claude-)?([a-z]+)((?:-\d{1,2}(?!\d))*)/.exec(id || "");
    return m ? m[1][0].toUpperCase() + m[1].slice(1) + (m[2] ? " " + m[2].slice(1).replace(/-/g, ".") : "") : id || ""; };
  const subDur = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? tl("pj.now.sec", {n: s}) : tl("pj.now.min", {m: Math.floor(s / 60), n: s % 60}); };
  function subRuns(c) {
    const by = new Map(), call = new Map();
    c.entries.forEach((e) => { if (e.sub) by.set(e.sub.id, Object.assign({at: e.at}, e.sub)); else if (e.kind === "sub" && e.id && e.aid) call.set(e.aid, e.id); });
    c.entries.forEach((e) => {
      const r = e.kind === "sub" && by.get(e.id || call.get(e.aid)); if (!r) return;
      ["model", "state", "end", "tokens", "uses", "ms", "report"].forEach((k) => { if (e[k] != null && e[k] !== "") r[k] = e[k]; });
    });
    return by;
  }
  function subs(box, c) {
    box._subC = c;
    const groups = []; let g = null;
    for (const n of box.children) {
      if (n.classList.contains("pj-sub")) { if (!g) groups.push(g = []); g.push(n); }
      else if (n.matches(".pj-msg.user:not([data-pend])")) g = null;
    }
    const keep = new Set();
    if (groups.length) {
      const runs = subRuns(c), off = ((c.state && c.state.state) || "ended") === "ended", now = Date.now();
      groups.forEach((rows) => {
        const vs = rows.map((n) => {
          // Ended: the record said how, or its report is here; a run of a session that is off is not running either.
          const r = runs.get(n.dataset.sub) || {}, st = r.state || (r.report ? "completed" : off ? "stopped" : ""), t0 = tmMs(r.at), t1 = tmMs(r.end);
          const ms = r.ms != null ? r.ms : t0 == null ? null : !st ? now - t0 : t1 != null ? t1 - t0 : null;
          const head = n.firstChild, mk = head.firstChild, tx = mk.nextSibling, id = n.dataset.sub, open = subOpen.has(id);
          const bits = st ? [r.uses != null ? tl("pj.sub.uses", {n: r.uses}) : "", r.tokens != null ? tl("pj.sub.tok", {n: ctxTok(r.tokens)}) : "", subModel(r.model), ms != null ? subDur(ms) : ""]
            : [ms != null ? subDur(ms) : "", subModel(r.model)];
          const html = `<b>${esc(r.name || tl("pj.sub.agent"))}</b>${r.desc ? ` <span class="sds">${esc(Redact.show(r.desc))}</span>` : ""} <span class="sdt">· <span class="sst">${esc(st ? (SUB_END[st] || SUB_END.completed)() : tl("pj.sub.run"))}</span>${esc(bits.filter(Boolean).map((b) => " · " + b).join(""))}</span>`;
          if (tx._h !== html) { tx._h = html; tx.innerHTML = html; }
          const k = st === "failed" ? "bad" : st === "completed" ? "ok" : st ? "off" : "run";
          if (n.dataset.st !== k) { n.dataset.st = k; mk.innerHTML = k === "run" ? `<span class="pj-spin"></span>` : ic(k === "bad" ? "warn" : k === "ok" ? "check" : "x"); }
          head.setAttribute("aria-expanded", open ? "true" : "false");
          let b = n.querySelector(":scope>.pj-subb");
          if (!open) { if (b) b.remove(); }
          else {
            const key = [r.brief, r.report, Redact.on()].join("\n");
            if (!b) { n.insertAdjacentHTML("beforeend", `<div class="pj-subb"></div>`); b = n.lastChild; if (!RM()) b.animate([{opacity: 0}, {opacity: 1}], {duration: 160, easing: "ease-out"}); }
            if (b._k !== key) { b._k = key; b.innerHTML = `<h5>${tl("pj.sub.brief")}</h5><div class="bf">${plainLinks(Redact.show(r.brief))}</div><h5>${tl("pj.sub.report")}</h5><div class="rp">${r.report ? marked(r.report) : `<span class="no">${st ? tl("pj.sub.none") : tl("pj.sub.wait")}</span>`}</div>`; }
          }
          return {n, r, st, t0, t1, open};
        });
        const done = vs.filter((v) => v.st), k = rows[0].dataset.sub, hid = subHid.has(k);
        vs.forEach((v) => v.n.classList.toggle("fd", rows.length > 1 && hid && !!v.st && !v.open));
        if (rows.length < 2) return;
        let b = rows[0].previousElementSibling;
        if (!(b && b.classList.contains("pj-subsum"))) { rows[0].insertAdjacentHTML("beforebegin", `<div class="pj-subsum"><span></span><button type="button"></button></div>`); b = rows[0].previousElementSibling; }
        keep.add(b); b.dataset.k = k;
        // The time on the wall is from the first start to the last end, said once all have ended;
        // against the sum of what each took it says how much ran side by side.
        const all = done.length === rows.length && vs.every((v) => v.t0 != null && v.t1 != null);
        const wall = all ? Math.max(...vs.map((v) => v.t1)) - Math.min(...vs.map((v) => v.t0)) : 0;
        const sum = (f) => done.reduce((a, v) => a + (v.r[f] || 0), 0), work = sum("ms"), uses = sum("uses"), toks = sum("tokens");
        const txt = [tl("pj.sub.sum.n", {n: rows.length}), wall ? subDur(wall) : done.length < rows.length ? tl("pj.sub.sum.left", {n: rows.length - done.length}) : "",
          work ? tl("pj.sub.sum.time", {t: subDur(work)}) + (wall && work / wall >= 1.15 ? " (" + tl("pj.sub.sum.par", {x: (work / wall).toFixed(1)}) + ")" : "") : "",
          uses ? tl("pj.sub.uses", {n: uses}) : "", toks ? tl("pj.sub.tok", {n: ctxTok(toks)}) : ""].filter(Boolean).join(" · ");
        if (b.firstChild.textContent !== txt) b.firstChild.textContent = txt;
        const say = done.length ? (hid ? tl("pj.sub.show", {n: done.length}) : tl("pj.sub.hide", {n: done.length})) : "";
        b.lastChild.hidden = !say; b.lastChild.setAttribute("aria-pressed", hid ? "true" : "false");
        if (b.lastChild.textContent !== say) b.lastChild.textContent = say;
      });
    }
    box.querySelectorAll(":scope>.pj-subsum").forEach((b) => { if (!keep.has(b)) b.remove(); });
  }
  document.addEventListener("click", (e) => {
    const t = e.target.closest && e.target.closest(".pj-subh,.pj-subsum>button"), box = t && t.closest(".pj-msgs"); if (!box || !box._subC) return;
    const row = t.matches(".pj-subh"), set = row ? subOpen : subHid, k = row ? t.parentNode.dataset.sub : t.parentNode.dataset.k, y = t.getBoundingClientRect().top;
    if (set.has(k)) set.delete(k); else set.add(k);
    subs(box, box._subC); box.scrollTop += t.getBoundingClientRect().top - y;
  });
  // After a paint: one time per run (same side, same minute - on its last line) and a line where
  // the day changes. Only what is missing is added, so painting again changes nothing.
  function stamp(box) {
    const today = tmDay(Date.now());
    let day = "", prev = null;
    box.querySelectorAll(":scope>.pj-msg[data-at]").forEach((n) => {
      const ms = tmMs(n.dataset.at); if (ms == null) return;
      const k = tmDay(ms);
      if (k !== day && (day || k !== today)) {
        let a = n; while (a.previousElementSibling && a.previousElementSibling.matches(".pj-unread,.pj-tfold,.pj-pics,[data-pend]")) a = a.previousElementSibling;
        if (!(a.previousElementSibling && a.previousElementSibling.classList.contains("pj-day"))) {
          const d = new Date(ms), o = {month: "long", day: "numeric", weekday: "long"};
          if (d.getFullYear() !== new Date().getFullYear()) o.year = "numeric";
          a.insertAdjacentHTML("beforebegin", `<div class="pj-day" role="separator">${esc(d.toLocaleDateString(tmLoc(), o))}</div>`);
        }
      }
      day = k;
      const t = n.querySelector(":scope>.pj-tm"); if (!t) return;
      const side = n.classList.contains("user"), min = Math.floor(ms / 6e4);
      if (prev && prev.side === side && prev.min === min && prev.day === k) prev.t.hidden = true;
      t.hidden = false; prev = {t, side, min, day: k};
    });
    tmStart();
  }
  // One timer for every chat on the page: it rewrites the words of the times still counting
  // ("3분 전" -> "4분 전"), nothing else, and rests while the page is hidden.
  let tmTimer = 0;
  function tmTick() {
    const now = Date.now(), rel = document.querySelectorAll("time.pj-tm[data-rel]");
    rel.forEach((n) => { const t = tmText(Date.parse(n.dateTime), now);
      if (!t.rel) n.removeAttribute("data-rel");
      if (n.textContent !== t.text) n.textContent = t.text; });
    if (!rel.length) tmStop();
  }
  const tmStop = () => { clearInterval(tmTimer); tmTimer = 0; };
  const tmStart = () => { if (!tmTimer && !document.hidden && document.querySelector("time.pj-tm[data-rel]")) tmTimer = setInterval(tmTick, 30000); };
  document.addEventListener("visibilitychange", () => { if (document.hidden) tmStop(); else { tmTick(); tmStart(); } });
  // What the session wrote, with its bold, inline code and lists read as such. markdown.js builds
  // nodes (never innerHTML), so the text stays escaped; a plain line stays a plain line.
  // The copy button of a line (and of a code block: data-copy="code").
  const cpBtn = (what) => `<button type="button" class="pj-cp press" data-copy="${what || "line"}" aria-label="${esc(tl("pj.copy"))}" title="${esc(tl("pj.copy"))}">${ic("copy")}</button>`;
  // The mark of a line kept; markRows() says which way it goes.
  const bkBtn = () => `<button type="button" class="pj-bk press" aria-pressed="false">${ic("tack")}</button>`;
  // A code block sits in a frame of its own: a head (its language, else "코드") with the copy button.
  const marked = (t) => {
    t = Redact.show(t);
    if (!(typeof looksMarkdown === "function" && looksMarkdown(t))) return plainLinks(t);
    const n = renderMarkdown(String(t).trim(), "md pj-md");
    n.querySelectorAll("pre").forEach((pre) => { const w = document.createElement("div"); w.className = "pj-prew"; w.dataset.l = ((pre.querySelector("code") || pre).className.match(/language-([\w+#.-]+)/) || [])[1] || tl("pj.code"); pre.replaceWith(w); w.appendChild(pre); w.insertAdjacentHTML("beforeend", cpBtn("code")); });
    return n.outerHTML;
  };
  // ---- a Genok result linked in a message, shown under it ------------------------------------------
  // A video plays there, a picture shows as a thumbnail, anything else is a small card. Each is
  // asked for only when it scrolls near (the item's own files, never a re-encoded copy).
  const pvCache = new Map();
  const pvHtml = (text) => typeof genokLinks !== "function" ? "" : genokLinks(text, 3).map((l) =>
    `<div class="pj-pv" data-p="${esc(l.project)}" data-i="${esc(l.item)}" data-v="${esc(l.v)}"></div>`).join("");
  function pvDetail(p, i) {
    const k = p + "/" + i;
    if (!pvCache.has(k)) pvCache.set(k, loopFetch("/api/item?p=" + enc(p) + "&i=" + enc(i)).catch(() => { pvCache.delete(k); return null; }));
    return pvCache.get(k);
  }
  async function pvFill(n) {
    const p = n.dataset.p, i = n.dataset.i, d = await pvDetail(p, i);
    if (!n.isConnected) return;
    const vs = (d && d.versions) || [], ver = vs.find((w) => w.v === n.dataset.v) || vs[vs.length - 1];
    if (!ver) return void n.remove();
    const files = ver.files || [], f = files.find((x) => x.kind === "video") || files.find((x) => x.kind === "image") || files[0];
    const title = (d.title || i), go = esc("item/" + p + "/" + i);
    const kind = f ? f.kind : "doc", k = (typeof KIND !== "undefined" && KIND[kind]) || ["doc"];
    const cap = `<button type="button" class="cap press" data-go="${go}"><span class="t">${esc(title)}</span><span class="s">${esc(ver.v || "")}</span></button>`;
    let media;
    if (f && kind === "video") media = `<video class="m" controls playsinline preload="none"${f.thumb ? ` poster="${esc(f.thumb)}"` : ""} src="${esc(f.play || f.url)}"></video>`;
    else if (f && kind === "image") media = `<button type="button" class="m img press" data-go="${go}" aria-label="${esc(title)}"><img src="${esc(f.thumb || f.url)}" alt="" loading="lazy"></button>`;
    else media = `<button type="button" class="m card press" data-go="${go}"><span class="th">${ic(k[0])}${f && f.thumb ? `<img src="${esc(f.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : ""}</span><span class="tx"><span class="t">${esc(title)}</span><span class="s">${esc(ver.v || "")}</span></span></button>`;
    const box = n.closest("#pj-msgs"), stick = !!box && nearEnd(box);   // a bottom-stuck chat stays at the bottom
    n.dataset.kind = f && (kind === "video" || kind === "image") ? kind : "card";
    n.innerHTML = media + (n.dataset.kind === "card" ? "" : cap);
    if (stick) box.scrollTop = box.scrollHeight;
  }
  const pvIO = typeof IntersectionObserver === "function" ? new IntersectionObserver((es) => es.forEach((e) => {
    if (!e.isIntersecting) return;
    pvIO.unobserve(e.target); pvFill(e.target);
  }), {rootMargin: "300px 0px"}) : null;
  const pvSeen = (n) => { if (n.nodeType === 1) (n.matches(".pj-pv") ? [n] : n.querySelectorAll(".pj-pv")).forEach((x) => { if (!x.dataset.ld) { x.dataset.ld = "1"; if (pvIO) pvIO.observe(x); else pvFill(x); } }); };
  new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach(pvSeen))).observe(document.body, {childList: true, subtree: true});
  // A link to such a result opens it here, not in the browser.
  const pvOpen = (a) => typeof genokLinks === "function" ? genokLinks(a.getAttribute("href"), 1)[0] : null;
  document.addEventListener("click", (e) => {
    const a = e.target.closest && e.target.closest(".pj-msg.claude a[href]"), l = a && pvOpen(a);
    if (!l || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
    e.preventDefault(); nav("item/" + l.project + "/" + l.item);
  });
  // chat-selection:begin
  function selectedText(root) {
    const sel = window.getSelection();
    return root && sel && !sel.isCollapsed && root.contains(sel.anchorNode) && root.contains(sel.focusNode) ? sel.toString() : "";
  }
  // chat-selection:end
  // Plain messages retain their whitespace and markup characters, with only web addresses linked.
  const plainLinks = (t) => {
    const text = String(t || ""), re = /https?:\/\/[^\s<>"'`]*[^\s<>"'`.,;:!?)\]]/g;
    let out = "", at = 0, m;
    while ((m = re.exec(text))) {
      out += esc(text.slice(at, m.index)) + `<a href="${esc(m[0])}" target="_blank" rel="noopener noreferrer">${esc(m[0])}</a>`;
      at = re.lastIndex;
    }
    return out + esc(text.slice(at));
  };
  // Why a line did not go, on the line itself: the reason when one is known, else the plain words.
  const failWhy = (why) => why && why !== "cancelled" ? String(why) : tl("room.failed");
  // A line of mine that is not in the transcript yet: on its way, sent, or not delivered.
  function pendRow(p, i) {
    const u = parts(p.text), mine = (p.imgs || []).filter((im) => im.url).map((im) => im.url);
    const tag = p.failed
      ? `<span class="tg bad" role="alert">${ic("warn")}<span>${esc(failWhy(p.failed))}</span><button class="press" data-resend="${i}">${esc(p.uncertain ? tl("pj.delivery.retry") : tl("room.retry"))}</button><button class="press" data-unsend="${i}">${esc(tl("room.drop"))}</button></span>`
      : `<span class="tg">${p.busy ? `<span class="pj-spin" aria-hidden="true"></span>` : ""}${esc(p.tag || "")}</span>`;
    return picRow(mine.concat(u.pics), p.busy ? " pending" : "").replace("<div ", "<div data-pend ")
      + `<div data-pend class="pj-msg user${p.busy ? " pending" : ""}${p.failed ? " failed" : ""}">${plainLinks(Redact.show(u.words) || (mine.length ? tl("pj.img.look") : ""))}${tag}</div>`;
  }

  // ---- 곁가지 질문 (Ctrl+;): a quick question to a throwaway fork of this conversation -----------
  // The server answers from a copy that is not kept (side.py), so the question never enters the
  // conversation or its next turn. One question and its answer at a time, kept per conversation.
  const sideHtml = () => `<div class="pj-bq" id="pj-bq" role="region" aria-label="${tl("pj.sq")}" hidden>
      <div class="pj-bqh"><b>${tl("pj.sq")}</b><span>${tl("pj.sq.d")}</span><button class="press" data-sqx aria-label="${tl("pj.sq.close")}" title="${tl("pj.sq.close")}">${ic("x")}</button></div>
      <div class="pj-bqa" id="pj-bqa" aria-live="polite" hidden></div>
      <form class="pj-bqf"><input id="pj-bqi" type="text" enterkeyhint="send" autocomplete="off" maxlength="2000" placeholder="${tl("pj.sq.ph")}" aria-label="${tl("pj.sq.ph")}">
        <button class="pj-go press" type="submit" disabled aria-label="${tl("pj.sq.ask")}" title="${tl("pj.sq.ask")}">${ic("up")}<span class="pj-spin" aria-hidden="true"></span></button></form></div>`;
  function sideWire(body, s, c, ta) {
    const box = body.querySelector("#pj-bq"), btn = body.querySelector("#pj-bqb"), inp = box.querySelector("#pj-bqi"), out = box.querySelector("#pj-bqa"), go = box.querySelector(".pj-go");
    const show = () => {
      const q = c.sq;
      out.hidden = !q;
      if (!q) return;
      const a = q.busy ? `<div class="pj-bqw">${loadingHtml(tl("pj.sq.wait"), {size: 16})}</div>`
        : q.err ? `<p class="pj-bqe" role="alert">${esc(q.err)}</p>`
        : typeof looksMarkdown === "function" && looksMarkdown(q.a) ? renderMarkdown(q.a.trim(), "md nmd").outerHTML : `<p>${esc(q.a)}</p>`;
      out.innerHTML = `<p class="pj-bqq">${esc(q.q)}</p>${a}`;
      go.classList.toggle("busy", !!q.busy); inp.disabled = !!q.busy; go.disabled = !!q.busy || !inp.value.trim();
    };
    inp.addEventListener("input", () => { if (!(c.sq && c.sq.busy)) go.disabled = !inp.value.trim(); });
    const open = (on) => {
      box.hidden = !on; btn.setAttribute("aria-expanded", String(on)); btn.classList.toggle("on", on);
      if (on) { box.classList.remove("in"); void box.offsetWidth; box.classList.add("in"); inp.focus({preventScroll: true}); }
      else ta.focus({preventScroll: true});
    };
    btn.onclick = () => open(box.hidden);
    box.querySelector("[data-sqx]").onclick = () => open(false);
    inp.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); open(false); } });
    box.querySelector("form").onsubmit = (e) => {
      e.preventDefault();
      const q = inp.value.trim(); if (!q || (c.sq && c.sq.busy)) return;
      const mine = c.sq = {q, busy: true}; inp.value = ""; show();
      loopFetch("/api/side", {method: "POST", json: {sid: s.id, q}})
        .then((j) => { mine.a = j.answer || ""; if (j.declined) mine.err = tl("pj.sq.fail"); })
        .catch((er) => { mine.err = srvMsg(er.message) || tl("pj.sq.fail"); })
        .then(() => { mine.busy = false; if (c.sq === mine && box.isConnected) { show(); if (!box.hidden) inp.focus({preventScroll: true}); } });
    };
    if (c.sq) { show(); }
  }
  // Ctrl+; opens (or closes) the side question of the conversation in front.
  document.addEventListener("keydown", (e) => {
    if (!e.ctrlKey || e.altKey || e.shiftKey || e.metaKey || (e.key !== ";" && e.code !== "Semicolon")) return;
    const b = document.querySelector(".pj-pane.focus #pj-bqb") || document.querySelector("#pj-bqb");
    if (!b || !b.offsetParent) return;
    e.preventDefault(); b.click();
  });

  // ---- what is on screen: the server keeps a PC notice back for the conversation being looked at (turn_toast.py)
  let seenSid = "", seenSent = "", seenSentAt = 0;
  function seenReport(sid) {
    if (sid !== undefined) seenSid = sid;
    const c = seenSid && C(seenSid);
    const on = !!(c && c.body && c.body.isConnected && cur === "project");
    const msg = (on ? seenSid : "") + "|" + (on && document.hasFocus() && !document.hidden);
    if (msg === seenSent && Date.now() - seenSentAt < 55e3) return;
    seenSent = msg; seenSentAt = Date.now();
    post("/api/viewing", {sid: on ? seenSid : "", focused: on && document.hasFocus() && !document.hidden}).catch(() => {});
  }
  ["focus", "blur", "hashchange"].forEach((k) => window.addEventListener(k, () => setTimeout(() => seenReport(), 0)));
  document.addEventListener("visibilitychange", () => seenReport());
  setInterval(() => { if (document.hasFocus()) seenReport(); }, 60e3);
