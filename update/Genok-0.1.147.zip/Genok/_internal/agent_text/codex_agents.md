<!-- genok:start -->
## Genok

사용자가 볼 결과물(렌더·영상·HTML 리포트·문서·링크)이 나오면 Genok에 올린다.
사용자는 PC와 폰에서 버전을 비교하고 코멘트를 남기며, 그 코멘트는 다음 턴에 돌아온다.

- 올리기: `{loop} push <파일|폴더> --item <항목> --note "한 줄" --summary "결론 한 줄"`
  - 같은 결과물의 수정본은 **같은 `--item`** (v002, v003으로 쌓인다).
  - 역할(서브에이전트)로 일할 땐 `--role "<역할 이름>"`. 피드백은 메인 세션이 받는다.
  - `--summary`는 결론 한 줄(120자 이내). `--note`는 짧게.
  - 사용자가 고를 게 있으면 `--ask "질문: 가 | 나*"` (`*`=추천). 번호로 묻지 않는다.
- 올린 뒤 답변에는 출력의 '답변에 붙일 내용'을 그대로 붙인다(작은 그림·파일은 채팅에서 바로, 큰 것은 `[Genok에서 보기](<링크>)`). 파일 경로나 주소를 글자로 풀어 쓰지 않는다.
- 눈으로 보면 끝나는 결과(화면·디자인 전후, 렌더 한 장)는 HTML로 싸지 말고 그림 파일 그대로 올린다. 채팅에 바로 뜨고 Genok에서도 열린다. HTML은 표·선택지가 필요할 때만.
- 새 버전 전에 열린 지시 확인: `{loop} todo --item <항목>`
  - 반영한 지시는 다음 push에 `--fixed <id,...>`(전부면 `all`), 못 한 건 `--later <id,...>`(이유 글이 아니라 id).
  - 열린 지시가 있는데 둘 다 없으면 올리기가 거절된다.
- 피드백 읽기: `{loop} feedback --project "<프로젝트>"` → 반영 후 `--ack`.

턴을 시작할 때 방금 올린 항목에 열린 지시가 있으면 `{loop} todo`로 먼저 확인한다.

3D 렌더(Blender·Houdini·Cinema 4D)는 GUI 없이 `loop render`로 한다. 끝나면 새 버전으로 자동으로 올라간다.
- `{loop} render blender <scene.blend> --item <항목> --frames 1-48 --format mp4`
- `{loop} render houdini <scene.hip> --rop /out/karma1 --item <항목> --frames 1001-1024`
- `{loop} render c4d <scene.c4d> --item <항목> --frames 0-90 --format mp4` (장면 파일 필수, 이미지 형식은 장면 설정 그대로)
- `{loop} render --mode`가 `live`면 사용자가 "열어 둔 창과 같이 다듬기"를 켠 것이다. 이미 연결된 MCP로 열린 장면을 함께 다듬어도 되고, 렌더는 그대로 `loop render`. `cli`(기본)면 창·MCP를 쓰지 않는다. MCP 설치는 권하지 않는다.
- 앱 버전은 사용자가 Genok 설정 > 3D 앱에서 정한 기본 버전을 자동으로 쓴다. 다른 버전이 꼭 필요할 때만 `--version 4.5`.
- 결과는 `renders/<항목>/v###/`. 코멘트를 반영하면 같은 `--item`에 `--fixed <id,...>`.
- 사용자의 .blend·.hip·.c4d를 덮어쓰지 않는다. 고친 장면은 `<이름>_rl_v###.<ext>`로 따로 저장한다.
<!-- genok:end -->
