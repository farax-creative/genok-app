// The board view of results: one project's (deptView in v2.js, "목록 | 보드") or every project's
// (the 보드 tab of 결과물, SCREENS.board in v2.js).
//
// Every item is a row of version cards joined by lines; a line carries how many directives the
// next version answered, and an item with open directives ends in a dashed "next" card. A card
// opens its detail in place: the result itself (the picture, the video, the page), why that
// version was made and, on the newest one, a comment that
// goes to the session exactly as a comment on the item page does (POST /api/comment, sendNow).
//
// Data: GET /api/boardview?p=<project> (boardview.py), asked again only when the items on screen change.
// Nothing about the board is stored on the server: a card dragged somewhere keeps its place in
// this browser ("v2-bdpos", per project screen), and 정렬 puts every card back on the grid.
// A phone opens the same data as version rows ("v2-bdmode" remembers the pick per device).
//
// Camera: the board follows the pointer 1:1, a release keeps its speed, buttons spring, and
// anything in flight can be grabbed. With reduced motion every move lands at once.
// Pure parts (layout, snap, bounds, fit) are tested in tests/boardview.test.js.
(function () {
  "use strict";
  const CW = 208, CH = 150, GX = 104, GY = 36, NEXT_W = 148, NEXT_H = 56, TOL = 8, ZMAX = 4, SHARP = 1.3;
  const nid = (it, v) => `${it.project}/${it.id}/${v}`;

  // items: [{project, id, title, versions: [{v, why, ...}], open: [text]}]; saved: {id: [x, y]}.
  function layout(items, saved) {
    const nodes = [], links = [];
    items.forEach((it, row) => {
      let prev = null;
      it.versions.forEach((v, i) => {
        const id = nid(it, v.v), at = saved && saved[id];
        const n = {id, type: "ver", it, v, last: i === it.versions.length - 1, w: CW, h: CH,
          x: at ? at[0] : i * (CW + GX), y: at ? at[1] : row * (CH + GY)};
        nodes.push(n);
        if (prev) links.push({a: prev, b: n, n: (v.why || []).length});
        prev = n;
      });
      if (prev && it.open && it.open.length) {
        const g = {id: nid(it, "next"), type: "next", it, of: prev, w: NEXT_W, h: NEXT_H, x: 0, y: 0};
        follow(g); nodes.push(g); links.push({a: prev, b: g, next: true, n: 0});
      }
    });
    return {nodes, links};
  }
  // The "next" card has no place of its own: it stays beside the newest version.
  function follow(g) { g.x = g.of.x + g.of.w + GX; g.y = g.of.y + (g.of.h - g.h) / 2; }

  // A dragged card lines up with another's edge or middle, or sits one gap beside it, when within
  // tol. {x, y, gx, gy}: where it lands and the guide lines to show (null: none on that axis).
  function snap(n, others, tol) {
    let x = n.x, y = n.y, gx = null, gy = null, bx = tol, by = tol;
    for (const o of others) {
      for (const f of [0, .5, 1]) {
        const dx = o.x + o.w * f - (n.x + n.w * f), dy = o.y + o.h * f - (n.y + n.h * f);
        if (Math.abs(dx) < bx) { bx = Math.abs(dx); x = n.x + dx; gx = o.x + o.w * f; }
        if (Math.abs(dy) < by) { by = Math.abs(dy); y = n.y + dy; gy = o.y + o.h * f; }
      }
      for (const dx of [o.x + o.w + GX - n.x, o.x - GX - n.w - n.x]) if (Math.abs(dx) < bx) { bx = Math.abs(dx); x = n.x + dx; gx = null; }
    }
    return {x, y, gx, gy};
  }
  function bounds(nodes) {
    let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
    nodes.forEach((n) => { a = Math.min(a, n.x); b = Math.min(b, n.y); c = Math.max(c, n.x + n.w); d = Math.max(d, n.y + n.h); });
    return nodes.length ? {x: a, y: b, w: c - a, h: d - b} : {x: 0, y: 0, w: 1, h: 1};
  }
  // The camera that shows the board: fitted to the width and never enlarged; one too wide to read
  // when whole (a phone) opens at its top-left at a readable size and is panned from there.
  const PAD = {l: 24, r: 24, t: 56, b: 24}, READ = .62;
  function fit(b, vw, vh) {
    const fw = vw - PAD.l - PAD.r, fh = vh - PAD.t - PAD.b, k = Math.min(1, fw / b.w);
    if (k < READ) return {k: READ, x: PAD.l - b.x * READ, y: PAD.t - b.y * READ};
    return {k, x: PAD.l + (fw - b.w * k) / 2 - b.x * k, y: PAD.t + Math.max(0, (fh - b.h * k) / 2) - b.y * k};
  }

  const api = {CW, CH, GX, GY, layout, snap, bounds, fit};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;

  const calm = () => matchMedia("(prefers-reduced-motion:reduce)").matches;
  const small = () => matchMedia("(max-width:720px)").matches;
  const mode = (v) => { try { if (v === undefined) return localStorage.getItem("v2-bdmode") || (small() ? "rail" : "board"); localStorage.setItem("v2-bdmode", v); } catch { return "board"; } };
  const places = () => { try { return JSON.parse(localStorage.getItem("v2-bdpos") || "{}"); } catch { return {}; } };
  const keep = (key, m) => { try { const a = places(); if (m && Object.keys(m).length) a[key] = m; else delete a[key]; localStorage.setItem("v2-bdpos", JSON.stringify(a)); } catch { /* this page only */ } };

  const mem = {};           // per project screen: {data, sig, cam, sel, draft}
  let raf = 0, live = null; // the running animation and the board on screen
  let zt = null;            // a wheel zoom in flight: the scale it heads for and the screen point it holds still
  const stop = () => { cancelAnimationFrame(raf); raf = 0; zt = null; };

  const sigOf = (its) => its.map((x) => `${iid(x)}:${x.v}:${x.rev}:${x.open}:${x.comments}`).join("|");
  const stamp = (key, sig) => `${key}|${mode()}|${sig}`;
  // A refresh with nothing new for a board already on screen: it stays as it is, with its camera,
  // open card and half-written comment (it was rebuilt node by node on every round).
  const same = (host, key, its) => !!host && !!host.firstElementChild && host.dataset.bdsig === stamp(key, sigOf(its)) && mem[key]?.sig === sigOf(its);
  function draw(host, key, its) {
    stop(); live = null;
    const m = mem[key] || (mem[key] = {data: null, sig: "", cam: null, sel: null, draft: ""});
    const sig = sigOf(its);
    const paint = () => {
      host.dataset.bdsig = stamp(key, sig);
      const by = new Map(m.data.map((d) => [iid(d), d]));
      const items = its.map((x) => by.has(iid(x)) && {...by.get(iid(x)), sum: x}).filter((it) => it && it.versions.length);
      (mode() === "rail" ? rail : canvas)(host, key, items, m, () => { m.sig = ""; draw(host, key, its); });
    };
    if (m.data) paint(); else host.innerHTML = `<div class="bd-wait">${loadingHtml("", {quiet: true})}</div>`;
    if (m.sig === sig) return;
    const asked = m.asked = (m.asked || 0) + 1;   // an older answer that comes late is dropped
    Promise.all([...new Set(its.map((x) => x.project))].map((p) => get("/api/boardview?p=" + encodeURIComponent(p)))).then((rs) => {
      if (asked !== m.asked) return;
      m.data = rs.flatMap((r) => r.items); m.sig = sig;
      if (host.isConnected) paint();
    }).catch(() => { if (host.isConnected && !m.data) host.innerHTML = `<div class="card plan none"><p>${tl("board.fail")}</p></div>`; });
  }

  const thumbOf = (v) => `<div class="th">${ic((KIND[v.kind] || ["doc"])[0])}${v.thumb && !v.removed ? imgTag(v.thumb, {drag: false}) : ""}</div>`;
  // The item screen opens on the version pressed (verPick, web/v2.js); the newest needs no pick.
  const open = (it, v) => { const id = iid(it.sum); if (v && v !== it.versions[it.versions.length - 1].v) verPick[id] = v; else delete verPick[id];
    nav("item/" + encodeURIComponent(it.project) + "/" + encodeURIComponent(it.id)); };
  const swap = (host, to, again) => host.querySelectorAll("[data-bdmode]").forEach((b) => b.onclick = () => { mode(to); again(); });

  // The result itself: a picture whole, a video that plays, a page live. Empty for a removed file or a kind with no view.
  const preview = (v, title) => { const src = !v.removed && v.play; return !src ? ""
    : v.kind === "image" ? `<div class="bd-pv">${imgTag(src, {lazy: false, drag: false})}</div>`
    : v.kind === "video" ? `<div class="bd-pv"><video src="${esc(src)}"${v.thumb ? ` poster="${esc(v.thumb)}"` : ""} controls playsinline preload="metadata"></video></div>`
    : v.kind === "html" ? `<div class="bd-pv page"><iframe src="${esc(keyUrl(src))}" title="${esc(title)}" sandbox="allow-scripts allow-popups"></iframe></div>` : ""; };

  // ---- version rows: the same data top to bottom, the first view on a phone
  function rail(host, key, items, m, again) {
    host.innerHTML = `<div class="bd-rail"><div class="bd-rh"><button class="ib press" data-bdmode aria-label="${tl("board.asboard")}" title="${tl("board.asboard")}">${ic("stack")}</button></div>`
      + items.map((it, n) => `<section class="bd-lane"><h3>${esc(it.title)}</h3><div class="bd-steps">`
        + it.versions.map((v, i) => (v.why.length ? `<span class="bd-fb">${esc(v.why.join(" · "))}</span>` : "")
          + `<button class="bd-step press${i === it.versions.length - 1 ? " last" : ""}" data-bdopen="${n}" data-bdv="${esc(v.v)}">${thumbOf(v)}<span class="bd-meta"><b>${vShort(v.v)}</b><span>${esc(v.summary)}</span></span></button>`).join("")
        + (it.open.length ? `<span class="bd-fb open">${tl("board.open", {n: it.open.length})}</span>` : "")
        + `</div></section>`).join("") + `</div>`;
    host.style.height = "";
    swap(host, "board", again);
    // A row opens its result under its own lane; a second tap folds it, a file with nothing to show goes to the item.
    host.querySelectorAll("[data-bdopen]").forEach((b) => b.onclick = () => {
      const it = items[+b.dataset.bdopen], v = it.versions.find((x) => x.v === b.dataset.bdv), was = b.classList.contains("on"), pv = preview(v, it.title);
      host.querySelectorAll(".bd-in").forEach((e) => e.remove());
      host.querySelectorAll(".bd-step.on").forEach((e) => e.classList.remove("on"));
      if (was) return;
      if (!pv) return open(it, v.v);
      b.classList.add("on");
      b.closest(".bd-lane").insertAdjacentHTML("beforeend", `<div class="bd-in">${pv}<button class="btn weak press">${vShort(v.v)} · ${tl("board.openitem")}</button></div>`);
      b.closest(".bd-lane").querySelector(".bd-in .btn").onclick = () => open(it, v.v);
    });
  }

  // ---- the board
  function canvas(host, key, items, m, again) {
    const saved = places()[key] || {};
    const {nodes, links} = layout(items, saved);
    host.innerHTML = `<div class="bd" tabindex="0"><div class="bd-world"><svg class="bd-edges"></svg><i class="bd-g v"></i><i class="bd-g h"></i></div>
      <div class="bd-tools">${[["data-bdz", "fit", tl("board.fit")], ["data-bdtidy", "grid", tl("board.tidy")], ["data-bdmode", "list", tl("board.rail")]].map(([a, i, n]) => `<button class="press" ${a} aria-label="${n}" title="${n}">${ic(i)}</button>`).join("")}</div>
      <div class="bd-mini" aria-hidden="true"></div><aside class="bd-det" aria-live="polite" inert></aside></div>`;
    const vp = host.firstElementChild, world = vp.querySelector(".bd-world"), edges = vp.querySelector(".bd-edges"),
      mini = vp.querySelector(".bd-mini"), det = vp.querySelector(".bd-det"), gv = vp.querySelector(".bd-g.v"), gh = vp.querySelector(".bd-g.h");
    // The phone's tab bar lies over the foot of the page: the board ends above it.
    const size = () => { host.style.height = Math.max(360, innerHeight - host.getBoundingClientRect().top - 16 - document.getElementById("tabbar").offsetHeight) + "px"; };
    size();
    const place = (n) => { n.el.style.transform = `translate(${n.x}px,${n.y}px)`; };
    nodes.forEach((n) => {
      const d = n.el = document.createElement("div");
      if (n.type === "next") { d.className = "bd-node next"; d.textContent = tl("board.open", {n: n.it.open.length}); }
      else {
        d.className = "bd-node ver" + (n.last ? " last" : ""); d.setAttribute("role", "button"); d.tabIndex = 0;
        d.innerHTML = `${thumbOf(n.v)}<span class="bd-meta"><b><span>${esc(n.it.title)}</span><em>${vShort(n.v.v)}</em></b><span>${esc(n.v.summary)}</span></span>`;
        // A video plays under the pointer, silent and looping, and leaves with it.
        if (n.v.kind === "video" && n.v.play && !n.v.removed) {
          d.onpointerenter = (e) => { if (e.pointerType !== "mouse" || d.querySelector("video")) return;
            d.querySelector(".th").insertAdjacentHTML("beforeend", `<video src="${esc(n.v.play)}" muted loop playsinline autoplay></video>`); };
          d.onpointerleave = () => d.querySelector("video")?.remove();
        }
      }
      d.style.width = n.w + "px"; d.style.height = n.h + "px"; world.appendChild(d); place(n);
    });
    const chips = links.map((l) => { if (!l.n) return null; const c = document.createElement("span"); c.className = "bd-chip"; c.textContent = tl("board.fixed", {n: l.n}); world.appendChild(c); return c; });
    const cam = m.cam || (m.cam = fit(bounds(nodes), vp.clientWidth, vp.clientHeight));
    function wires() {
      edges.innerHTML = links.map((l, i) => {
        const x1 = l.a.x + l.a.w, y1 = l.a.y + l.a.h / 2, x2 = l.b.x, y2 = l.b.y + l.b.h / 2, c = Math.max(24, Math.abs(x2 - x1) / 2);
        if (chips[i]) chips[i].style.cssText = `left:${(x1 + x2) / 2}px;top:${(y1 + y2) / 2}px`;
        return `<path${l.next ? ' class="next"' : ""} d="M${x1},${y1} C${x1 + c},${y1} ${x2 - c},${y2} ${x2},${y2}"/>`;
      }).join("");
      chart(); map();
    }
    // The map's cards are drawn when a card moves; a camera move only moves the frame over them.
    let mapT = 0, mb = null;
    function chart() {
      mb = bounds(nodes); const s = Math.min(120 / mb.w, 72 / mb.h), ox = 6 - mb.x * s, oy = 6 - mb.y * s;
      mini.innerHTML = nodes.map((n) => `<i style="left:${ox + n.x * s}px;top:${oy + n.y * s}px;width:${n.w * s}px;height:${n.h * s}px"></i>`).join("") + "<u></u>";
    }
    function map(byHand) {
      if (!mb) chart();
      const b = mb, s = Math.min(120 / b.w, 72 / b.h), ox = 6 - b.x * s, oy = 6 - b.y * s;
      // The map is for finding what is off the screen: it shows while the user moves the view and for a
      // moment after, then gets out of the way of the cards under it; with every card in view it stays away.
      if (byHand) { mini.classList.add("live"); clearTimeout(mapT); mapT = setTimeout(() => mini.classList.remove("live"), 1500); }
      mini.classList.toggle("off", cam.x + b.x * cam.k >= 0 && cam.y + b.y * cam.k >= 0 && cam.x + (b.x + b.w) * cam.k <= vp.clientWidth && cam.y + (b.y + b.h) * cam.k <= vp.clientHeight);
      mini.lastChild.style.cssText = `left:${ox - cam.x / cam.k * s}px;top:${oy - cam.y / cam.k * s}px;width:${vp.clientWidth / cam.k * s}px;height:${vp.clientHeight / cam.k * s}px`;
    }
    // Zoomed in, a picture card shows the picture itself in place of its small thumbnail (asked for once).
    const sharpen = () => { if (cam.k < SHARP) return; nodes.forEach((n) => { if (n.sharp || n.type !== "ver" || n.v.kind !== "image" || !n.v.play || n.v.removed) return;
      const x = cam.x + n.x * cam.k, y = cam.y + n.y * cam.k; if (x > vp.clientWidth || y > vp.clientHeight || x + n.w * cam.k < 0 || y + n.h * cam.k < 0) return;
      n.sharp = true; const im = n.el.querySelector(".th img"); if (im) im.src = n.v.play; }); };
    const apply = (byHand) => { world.style.transform = `translate(${cam.x}px,${cam.y}px) scale(${cam.k})`; map(byHand); sharpen(); };
    // One spring for the camera and for cards going back to the grid: `step` moves everything a
    // tick toward its target and says whether it has arrived.
    function spring(parts, after) {
      stop();
      if (calm()) { parts.forEach(([o, t]) => Object.assign(o, t)); return after(); }
      const vel = parts.map(([, t]) => Object.fromEntries(Object.keys(t).map((p) => [p, 0])));
      let last = performance.now();
      const tick = (now) => {
        const dt = Math.min(.032, (now - last) / 1000); last = now; let rest = true;
        parts.forEach(([o, t], i) => { for (const p in t) {
          vel[i][p] += ((t[p] - o[p]) * 170 - vel[i][p] * 26) * dt; o[p] += vel[i][p] * dt;
          if (Math.abs(t[p] - o[p]) > (p === "k" ? .001 : .3) || Math.abs(vel[i][p]) > (p === "k" ? .01 : 4)) rest = false; } });
        if (rest) parts.forEach(([o, t]) => Object.assign(o, t));
        after(); raf = rest ? 0 : requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }
    const camTo = (t) => spring([[cam, t]], apply);
    function zoomAt(k, cx, cy) {
      k = Math.max(.25, Math.min(ZMAX, k));
      const t = {k, x: cx - (cx - cam.x) * k / cam.k, y: cy - (cy - cam.y) * k / cam.k};
      Object.assign(cam, t); apply(true);
    }
    // The wheel: each notch moves the target, and the view eases to it around the pointer, so a
    // spin reads as one move in place of a row of jumps. A pinch on a trackpad (ctrl) is already smooth.
    function wheel(f, cx, cy, direct) {
      const k = Math.max(.25, Math.min(ZMAX, (zt ? zt.k : cam.k) * f));
      if (direct || calm()) { stop(); return zoomAt(k, cx, cy); }
      if (zt) { zt = {k, cx, cy}; return; }
      stop(); zt = {k, cx, cy}; let last = performance.now();
      const tick = (now) => {
        const dt = Math.min(.032, (now - last) / 1000); last = now;
        const near = Math.abs(Math.log(zt.k / cam.k)) < .002, to = near ? zt.k : cam.k * Math.pow(zt.k / cam.k, 1 - Math.exp(-16 * dt));
        zoomAt(to, zt.cx, zt.cy);
        if (near) { zt = null; raf = 0; } else raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }
    function glide(vx, vy) {
      if (calm() || Math.hypot(vx, vy) < 60) return;
      let last = performance.now();
      const tick = (now) => { const dt = (now - last) / 1000; last = now; cam.x += vx * dt; cam.y += vy * dt; const f = Math.exp(-5 * dt); vx *= f; vy *= f; apply(true); raf = Math.hypot(vx, vy) > 12 ? requestAnimationFrame(tick) : 0; };
      raf = requestAnimationFrame(tick);
    }
    // Bring a picked card clear of the detail panel (beside it on a PC, above it on a phone).
    function reveal(n) {
      const w = vp.clientWidth, h = vp.clientHeight, phone = w < 600, gap = 16;
      const right = phone ? w : det.offsetLeft, bottom = phone ? det.offsetTop : h;
      const x = cam.x + n.x * cam.k, y = cam.y + n.y * cam.k, nw = n.w * cam.k, nh = n.h * cam.k;
      const dx = x + nw > right - gap ? right - gap - nw - x : x < gap ? gap - x : 0, dy = y + nh > bottom - gap ? bottom - gap - nh - y : y < PAD.t ? PAD.t - y : 0;
      if (dx || dy) camTo({k: cam.k, x: cam.x + dx, y: cam.y + dy});
    }

    // ---- a card's detail, and a comment on the newest version
    let cur = null;
    function hide() { det.classList.remove("on"); det.inert = true; vp.classList.remove("sel"); if (cur) cur.el.classList.remove("on"); cur = null; m.sel = null; }
    function show(n, quiet) {
      if (cur) cur.el.classList.remove("on");
      if (m.sel !== n.id) m.draft = "";
      cur = n; m.sel = n.id; n.el.classList.add("on");
      const why = n.v.why, still = n.last ? n.it.open : [];
      const list = (title, xs) => (xs.length ? `<p class="k">${title}</p><ul>${xs.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>` : "");
      // The result itself, so a look does not need the item screen: a picture whole, a video that plays, a page live.
      const pv = preview(n.v, n.it.title);
      det.classList.toggle("wide", !!pv);
      det.innerHTML = `<button class="ib press x" aria-label="${tl("ui.close")}">${ic("x")}</button>${pv}<h3>${esc(n.it.title)} · ${vShort(n.v.v)}</h3><p class="s">${esc([n.v.summary, ago(n.v.at)].filter(Boolean).join(" · "))}</p>`
        + list(tl("board.why"), why) + list(tl("board.open", {n: still.length}), still)
        + (n.last ? `<textarea placeholder="${tl("board.ph")}" aria-label="${tl("board.ph")}">${esc(m.draft)}</textarea><button class="btn fill press send">${tl("board.send")}</button>` : `<p class="s">${tl("board.newest")}</p>`)
        + `<button class="btn weak press go">${tl("board.openitem")}</button>`;
      det.classList.add("on"); det.inert = false; vp.classList.add("sel");
      if (!quiet) reveal(n);
      det.querySelector(".x").onclick = () => { hide(); n.el.focus(); };
      det.querySelector(".go").onclick = () => open(n.it, n.v.v);
      const ta = det.querySelector("textarea"), send = det.querySelector(".send");
      if (!ta) return;
      ta.oninput = () => { m.draft = ta.value; };
      send.onclick = async () => {
        const text = ta.value.trim(); if (!text) return ta.focus();
        send.disabled = true;
        const it = {p: n.it.project, i: n.it.id, v: n.v.v, dept: n.it.sum.dept};
        try { await post("/api/comment", {...it, text}); m.draft = ""; await sendNow(it); again(); }
        catch (e) { send.disabled = false; toast(e.message); }
      };
    }

    // ---- pointers: one finger pans or drags a card, two pinch
    const pts = new Map(); let drag = null, pinch = null;
    const local = (e) => { const r = vp.getBoundingClientRect(); return {x: e.clientX - r.left, y: e.clientY - r.top}; };
    const guide = (s) => {
      const b = bounds(nodes);
      gv.style.cssText = s && s.gx != null ? `display:block;left:${s.gx}px;top:${b.y - 40}px;height:${b.h + 80}px` : "";
      gh.style.cssText = s && s.gy != null ? `display:block;top:${s.gy}px;left:${b.x - 40}px;width:${b.w + 80}px` : "";
    };
    vp.addEventListener("pointerdown", (e) => {
      // The wheel button drags the board from anywhere, a card included; the right button is not ours.
      const mid = e.pointerType === "mouse" && e.button === 1;
      if (e.target.closest(".bd-tools,.bd-det") || (e.pointerType === "mouse" && e.button && !mid)) return;
      if (mid) e.preventDefault();
      stop(); vp.setPointerCapture(e.pointerId); pts.set(e.pointerId, local(e));
      if (pts.size === 2) { const [a, b] = [...pts.values()]; const cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2; pinch = {d: Math.hypot(a.x - b.x, a.y - b.y) || 1, k: cam.k, wx: (cx - cam.x) / cam.k, wy: (cy - cam.y) / cam.k}; drag = null; guide(); return; }
      const hit = !mid && e.target.closest(".bd-node.ver"), n = hit && nodes.find((x) => x.el === hit), p = local(e);
      drag = {n, mid, sx: p.x, sy: p.y, ox: n ? n.x : cam.x, oy: n ? n.y : cam.y, moved: false, t: e.timeStamp, lx: p.x, ly: p.y, vx: 0, vy: 0};
    });
    vp.addEventListener("pointermove", (e) => {
      if (!pts.has(e.pointerId)) return;
      const p = local(e); pts.set(e.pointerId, p);
      // Two fingers: the board point that was between them stays between them, so they zoom and carry it at once.
      if (pinch && pts.size === 2) { const [a, b] = [...pts.values()];
        cam.k = Math.max(.25, Math.min(ZMAX, pinch.k * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d)); cam.x = (a.x + b.x) / 2 - pinch.wx * cam.k; cam.y = (a.y + b.y) / 2 - pinch.wy * cam.k; return apply(true); }
      if (!drag) return;
      // Past the slop the drag starts from where the pointer is, so nothing jumps to catch up.
      if (!drag.moved) { if (Math.hypot(p.x - drag.sx, p.y - drag.sy) < 5) return; drag.moved = true; drag.sx = p.x; drag.sy = p.y; drag.lx = p.x; drag.ly = p.y; drag.t = e.timeStamp; }
      const dx = p.x - drag.sx, dy = p.y - drag.sy;
      if (drag.n) {
        const n = drag.n; n.x = drag.ox + dx / cam.k; n.y = drag.oy + dy / cam.k;
        const s = snap(n, nodes.filter((o) => o !== n && o.type === "ver"), TOL / cam.k);
        n.x = s.x; n.y = s.y; place(n); guide(s);
        nodes.forEach((g) => { if (g.of === n) { follow(g); place(g); } });
        vp.classList.add("drag"); wires();
      } else {
        vp.classList.add("pan"); cam.x = drag.ox + dx; cam.y = drag.oy + dy; apply(true);
        const dt = Math.max(1, e.timeStamp - drag.t) / 1000; drag.vx = drag.vx * .3 + (p.x - drag.lx) / dt * .7; drag.vy = drag.vy * .3 + (p.y - drag.ly) / dt * .7; drag.t = e.timeStamp; drag.lx = p.x; drag.ly = p.y;
      }
    });
    const up = (e) => {
      if (!pts.delete(e.pointerId)) return;
      // One finger left of two goes on moving the board from where it is.
      if (pinch && pts.size === 1) { const [p] = [...pts.values()]; pinch = null; drag = {n: null, sx: p.x, sy: p.y, ox: cam.x, oy: cam.y, moved: true, t: e.timeStamp, lx: p.x, ly: p.y, vx: 0, vy: 0}; return; }
      vp.classList.remove("pan", "drag"); guide();
      const d = drag; drag = null; if (!d) return;
      if (!d.moved) { if (d.mid) return; if (d.n) show(d.n); else hide(); }
      else if (d.n) { saved[d.n.id] = [Math.round(d.n.x), Math.round(d.n.y)]; keep(key, saved); }
      else if (e.timeStamp - d.t < 80) glide(d.vx, d.vy);
    };
    vp.addEventListener("pointerup", up); vp.addEventListener("pointercancel", up);
    vp.addEventListener("wheel", (e) => { if (e.target.closest(".bd-det")) return; e.preventDefault(); const p = local(e); wheel(Math.exp(-e.deltaY * (e.deltaMode === 1 ? 33 : 1) * (e.ctrlKey ? .01 : .0018)), p.x, p.y, e.ctrlKey); }, {passive: false});
    // The wheel button is the board's hand: no autoscroll compass, no paste or new tab from a card under it.
    vp.addEventListener("mousedown", (e) => { if (e.button === 1 && !e.target.closest(".bd-det")) e.preventDefault(); });
    vp.addEventListener("auxclick", (e) => { if (e.button === 1) e.preventDefault(); });
    vp.addEventListener("keydown", (e) => {
      const n = e.target.closest(".bd-node.ver") && nodes.find((x) => x.el === e.target);
      if (n && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); show(n); }
    });
    // Zoom is the wheel or a pinch; the one button brings the whole board back into view.
    vp.querySelector("[data-bdz]").onclick = () => camTo(fit(bounds(nodes), vp.clientWidth, vp.clientHeight));
    // 정렬: every card back to its place on the grid, and the view back to the whole board.
    vp.querySelector("[data-bdtidy]").onclick = () => {
      for (const k in saved) delete saved[k];
      keep(key, saved); guide();
      const grid = layout(items, null).nodes, vers = nodes.filter((n) => n.type === "ver");
      const parts = vers.map((n) => { const g = grid.find((x) => x.id === n.id); return [n, {x: g.x, y: g.y}]; });
      parts.push([cam, fit(bounds(grid), vp.clientWidth, vp.clientHeight)]);
      spring(parts, () => { nodes.forEach((n) => { if (n.of) follow(n); place(n); }); wires(); apply(); });
    };
    swap(host, "rail", again);

    // Escape shuts the panel wherever the focus is (it sits on the page after a comment is sent).
    const esc1 = () => { if (!cur) return false; const el = cur.el; hide(); el.focus({preventScroll: true}); return true; };
    live = {size, map, vp, esc: esc1};
    wires(); apply();
    const was = m.sel && nodes.find((n) => n.id === m.sel);
    if (was) show(was, true); else m.sel = null;
  }
  addEventListener("resize", () => { if (live && live.vp.isConnected) { live.size(); live.map(); } });
  addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.defaultPrevented && live && live.vp.isConnected && live.esc()) e.preventDefault(); });

  api.draw = draw; api.same = same;
  window.BoardView = api;
})();
