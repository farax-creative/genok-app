// Compare workspace: while two versions are compared, the whole screen becomes a compare-only
// view (side by side, a wipe, or an A/B flip) with each side labelled by what it shows. Loaded
// before v2.js; the math lives in vcompare.js. It draws over the app and touches nothing under
// it, so closing puts the reader back exactly where they were.
const cvModes = () => [["side", tl("cv.m.side"), "1"], ["wipe", tl("cv.m.wipe"), "2"], ["flip", tl("cv.m.flip"), "3"]];
const cvEsc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
const cvMode = (v) => { try { if (v === undefined) { const m = localStorage.getItem("v2-cvm"); return cvModes().some((c) => c[0] === m) ? m : null; } localStorage.setItem("v2-cvm", v); } catch { return null; } };
const CV_ICON = {back: "back", pause: "pause", play: "play", prev: "back", next: "chev"};
const cvIc = (k) => ic(CV_ICON[k]);
let cvOpen = null;

// versions: [{v, at, summary, files}] newest first. a/b: the versions on the two sides (a = left/top).
// verify (optional) turns it into the fix check for one directive: a = the version the ask was
// written on, b = the version that says it fixed it. {text, note, cycle, file, region (0..1),
// at (seconds), where (label), decide(ok) -> Promise<true | {html, retry?, again?}>, reload()}.
// mode (optional) opens in that way without changing the kept choice. post ({p, i}, optional) adds a
// comment line under the pair: it goes on the version of the side picked there, like Frame.io's
// compare; onClose(true) then tells the caller something was written.
function openCompareView({title, versions, a, b, onClose, verify, mode: mode0, post: target}) {
  if (cvOpen) cvOpen.close(true, "keep");   // swapping pairs keeps the one history entry below
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const phone = () => innerWidth < 720;
  const usable = versions.filter((w) => pickCompareFile(w, ""));
  const latestV = versions[0] && versions[0].v;
  const st = {a, b, mode: mode0 || cvMode() || "side", cside: "b", posted: false, view: {s: 1, fx: 0, fy: 0}, wipe: 50, flip: "b", t: verify && verify.at || 0, playing: false};
  const restoreFocus = document.activeElement;

  const root = document.createElement("div");
  root.className = "cmpv";
  root.setAttribute("role", "dialog"); root.setAttribute("aria-modal", "true"); root.setAttribute("aria-label", tl("cv.aria"));
  root.innerHTML = `<header class="cvbar"><button class="cvend press" id="cvend" aria-label="${tl("cv.end.a")}">${cvIc("back")}<span>${tl("cv.end")}</span></button>
      <span class="cvtitle">${cvEsc(title || "")}</span>
      <div class="seg cvseg" role="group" aria-label="${tl("cv.modes")}">${cvModes().map(([k, n, key]) => `<button class="press" data-cm="${k}" aria-pressed="false" title="${n} (${key})">${n}</button>`).join("")}</div>
      <span class="cvzoom"><output id="cvz" class="num">100%</output><button class="press" id="cvzr" aria-label="${tl("cv.zoomreset.a")}">${tl("cv.zoomreset")}</button></span></header>
    <div class="cvstage" id="cvstage"></div>
    <div class="cvfoot" id="cvfoot"></div>${verify ? `<section class="cvfv" id="cvfv" aria-label="${tl("fixv.aria")}"></section>` : ""}`;
  if (verify) root.classList.add("fixv");
  const stage = root.querySelector("#cvstage"), foot = root.querySelector("#cvfoot");
  const $ = (q, el = root) => el.querySelector(q);

  const ver = (v) => versions.find((w) => w.v === v) || {v};
  const fileOf = (side) => pickCompareFile(ver(st[side]), st.pref);
  // The kind of the pair decides what works: video plays in step, image zooms and wipes.
  const kind = () => compareKind(fileOf("a"), fileOf("b"));
  const modes = () => kind() === "other" ? ["side"] : cvModes().map((m) => m[0]);
  const mode = () => modes().includes(st.mode) ? st.mode : "side";

  const label = (side, alt) => {
    const w = ver(st[side]), o = ver(st[side === "a" ? "b" : "a"]), f = fileOf(side);
    const role = pairRoles(w.v, o.v)[0];
    // In the fix check the sides say what they are: where the ask was written, and the fix.
    const txt = verify && w.v === a ? tl("fixv.src") : verify && w.v === b ? tl("fixv.fix") : {older: tl("cv.older"), newer: tl("cv.newer"), same: tl("cv.same")}[role];
    const note = (w.summary || "").split(/\s+/).join(" ").trim();
    return `<div class="cvl ${side} r-${role}${alt ? " alt" : ""}"><div class="cvl1"><b class="cvrole">${txt}</b><span class="cvv num">${cvEsc(w.v)}</span>${w.v === latestV ? `<i class="cvlat">${tl("cv.latest")}</i>` : ""}
        <label class="cvpick"><span class="sr">${side === "a" ? tl("cv.left") : tl("cv.right")} ${tl("cv.ver")}</span><gk-select data-pick="${side}" aria-label="${side === "a" ? tl("cv.left") : tl("cv.right")} ${tl("cv.ver")}">${usable.map((x) => `<option value="${cvEsc(x.v)}"${x.v === st[side] ? " selected" : ""}>${cvEsc(x.v)}</option>`).join("")}</gk-select></label></div>
      <div class="cvl2 num">${cvEsc(whenLabel(w.at, null, typeof LANG === "function" ? LANG() : ""))}${f ? `<span class="cvfn"> · ${cvEsc(f.name)}</span>` : ""}${f && f.past_lost ? ` <em class="plost" title="${tl("pastLost.t")}">${tl("pastLost.1")}</em>` : ""}</div>
      ${note ? `<p class="cvl3" title="${cvEsc(note)}">${cvEsc(note)}</p>` : ""}</div>`;
  };
  // Bytes that are not there (overwritten later: 410; referenced original missing: 404) get a
  // calm note in place of a broken picture or a black player.
  const media = (f, side) => !f ? `<div class="cvnone">${tl("cv.nofile")}</div>`
    : f.past_lost ? `<div class="cvnone cvgone" role="note"><b>${tl("pastLost.1")}</b><span>${tl("pastLost.t")}</span></div>`
    : f.ref_state === "missing" ? `<div class="cvnone cvgone" role="note"><b>${tl("refMissing.1")}</b><span>${tl("refMissing.t")}</span></div>`
    : f.kind === "video" ? `<video data-vid="${side}" src="${cvEsc(f.play || f.url)}" muted playsinline preload="auto"${f.thumb ? ` poster="${cvEsc(f.thumb)}"` : ""}></video>`
    : f.kind === "html" ? `<iframe data-html="${side}" src="${cvEsc(f.url)}" title="${cvEsc(f.name)}" sandbox="allow-scripts allow-popups"></iframe>`
    : `<img src="${cvEsc(f.url)}" alt="${cvEsc(f.name)}" draggable="false">`;
  // The box the ask was left on: solid on the side it was written on, dashed on the fix - the
  // same spot is not assumed to be the same thing in a new cut, so it only says "look here".
  const rgn = (side) => verify && verify.region && (fileOf(side) || {}).kind === "image" && !fileOf(side).past_lost && fileOf(side).ref_state !== "missing" ?`<i class="cvrg ${side === "a" ? "src" : "fix"}" aria-hidden="true"></i>` : "";
  const pane = (side, extra = "") => `<div class="cvp p-${side}${extra}" data-side="${side}"><div class="cvm">${media(fileOf(side), side)}${rgn(side)}</div></div>`;
  const placeRegions = () => stage.querySelectorAll(".cvrg").forEach((el) => {
    const m = el.parentNode, img = m.querySelector("img"), r = verify.region;
    if (!img || !img.naturalWidth) { if (img) img.addEventListener("load", placeRegions, {once: true}); return; }
    const W = m.offsetWidth, H = m.offsetHeight, s = Math.min(W / img.naturalWidth, H / img.naturalHeight), w = img.naturalWidth * s, h = img.naturalHeight * s;
    Object.assign(el.style, {left: `${(W - w) / 2 + w * r.x}px`, top: `${(H - h) / 2 + h * r.y}px`, width: `${w * r.w}px`, height: `${h * r.h}px`}); });

  const applyView = () => {
    const {s, fx, fy} = st.view;
    stage.querySelectorAll(".cvm").forEach((m) => { m.style.transform = s === 1 ? "" : `translate(${fx * 100}%,${fy * 100}%) scale(${s})`; });
    $("#cvz").textContent = Math.round(s * 100) + "%";
    root.classList.toggle("zoomed", s > 1);
  };

  // ---- the stage for the current mode ----
  const build = () => {
    const m = mode(), k = kind();
    root.dataset.mode = m; root.dataset.kind = k;
    root.querySelectorAll("[data-cm]").forEach((b) => { const on = b.dataset.cm === m; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); b.disabled = !modes().includes(b.dataset.cm); });
    if (m === "side") stage.innerHTML = `${pane("a")}${pane("b")}${label("a")}${label("b")}`;
    else if (m === "wipe") stage.innerHTML = `<div class="cvw" style="--x:${st.wipe}%">${pane("a")}<div class="cvbwrap">${pane("b")}</div><div class="cvh" role="slider" tabindex="0" aria-label="${tl("cv.wipeedge")}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(st.wipe)}"></div></div>${label("a")}${label("b")}`;
    else stage.innerHTML = `<div class="cvflipw">${pane("a", st.flip === "a" ? " on" : "")}${pane("b", st.flip === "b" ? " on" : "")}</div>${label(st.flip)}`;
    applyView();
    wireStage(); wireVideo(); buildFoot();
    if (verify) placeRegions();
  };
  // Changing a side keeps the mode, zoom, wipe and moment; only the media under it is swapped.
  const flipTo = (side) => { st.flip = side; stage.querySelectorAll(".cvp").forEach((p) => p.classList.toggle("on", p.dataset.side === side));
    const l = $(".cvl", stage); if (l) l.outerHTML = label(side); wirePick(); buildFoot(); };

  const buildFoot = () => {
    const k = kind(), m = mode();
    const flipBar = m === "flip" ? `<div class="cvflipbar seg" role="group" aria-label="${tl("cv.m.flip")}">${["a", "b"].map((s) => { const w = ver(st[s]), r = pairRoles(w.v, ver(st[s === "a" ? "b" : "a"]).v)[0];
      return `<button class="press${st.flip === s ? " on" : ""}" data-fl="${s}" aria-pressed="${st.flip === s}">${{older: tl("cv.older"), newer: tl("cv.newer"), same: s === "a" ? tl("cv.left") : tl("cv.right")}[r]} <span class="num">${cvEsc(w.v)}</span></button>`; }).join("")}<em>${tl("cv.spacehint")}</em></div>` : "";
    const vidBar = k === "video" ? `<div class="cvvid"><button class="press" id="cvplay" aria-label="${tl("cv.play")}"></button><button class="press" data-cs="-1" aria-label="${tl("cv.prevf")}">${cvIc("prev")}</button><button class="press" data-cs="1" aria-label="${tl("cv.nextf")}">${cvIc("next")}</button>
      <input type="range" id="cvscrub" min="0" max="1000" value="0" aria-label="${tl("cv.scrub")}"><span class="num" id="cvnow">0:00</span></div>` : "";
    // The comment line: which side it goes on (the flip follows the side in view), then the words.
    if (m === "flip") st.cside = st.flip;
    const cm = target && !verify ? `<form class="cvcm"><div class="seg cvcms" role="group" aria-label="${tl("cv.cm.side")}">${["a", "b"].map((s) => { const w = ver(st[s]), r = pairRoles(w.v, ver(st[s === "a" ? "b" : "a"]).v)[0];
      return `<button type="button" class="press${st.cside === s ? " on" : ""}" data-cms="${s}" aria-pressed="${st.cside === s}">${{older: tl("cv.older"), newer: tl("cv.newer"), same: s === "a" ? tl("cv.left") : tl("cv.right")}[r]} <span class="num">${cvEsc(w.v)}</span></button>`; }).join("")}</div>
      <input id="cvcmin" type="text" maxlength="2000" enterkeyhint="send" autocomplete="off" placeholder="${tl("cv.cm.ph", {v: cvEsc(st[st.cside])})}" aria-label="${tl("cv.cm.ph", {v: cvEsc(st[st.cside])})}"><button class="press cvcmgo" aria-label="${tl("cv.cm.send")}">${ic("up")}</button></form>` : "";
    const draft = ($("#cvcmin") || {}).value || "";
    foot.innerHTML = flipBar + vidBar + cm;
    if (draft && $("#cvcmin")) $("#cvcmin").value = draft;
    foot.hidden = !foot.innerHTML;
    root.dataset.foot = foot.hidden ? "0" : "1";
    foot.querySelectorAll("[data-fl]").forEach((b) => b.onclick = () => flipTo(b.dataset.fl));
    if (k === "video") wireVidBar();
    if (cm) wireComment();
  };
  // The tag says which file and moment of that side it is about, as the full-screen viewer's line does.
  function wireComment() {
    const form = $(".cvcm", foot), inp = $("#cvcmin", foot);
    form.querySelectorAll("[data-cms]").forEach((b) => b.onclick = () => { st.cside = b.dataset.cms; if (mode() === "flip") flipTo(st.cside); else buildFoot(); $("#cvcmin", foot)?.focus({preventScroll: true}); });
    inp.onfocus = () => play(false);
    form.onsubmit = async (e) => { e.preventDefault(); const text = inp.value.trim(); if (!text) return;
      const side = st.cside, f = fileOf(side), at = f && f.kind === "video" ? whenOf(vids()[side], f) : "";
      const tag = [f && f.name, at].filter(Boolean).join(" "), it = {p: target.p, i: target.i, v: st[side]};
      inp.disabled = true;
      try { await post("/api/comment", {...it, text: tag ? `[${tag}] ${text}` : text}); inp.value = ""; st.posted = true; await sendNow(it); }
      catch (err) { typeof toast === "function" && toast(err.message); }
      inp.disabled = false; inp.focus({preventScroll: true}); };
  }

  const wirePick = () => root.querySelectorAll("[data-pick]").forEach((sel) => { sel.onchange = () => {
    const side = sel.dataset.pick; st[side] = sel.value;
    if (side === "b" || !st.pref) st.pref = (fileOf("b") || fileOf("a") || {}).name;
    const keep = st.t; build(); if (kind() === "video") seekAll(keep); }; });

  // ---- pointer work: wipe divider 1:1, zoom by wheel / pinch / double tap, pan when zoomed ----
  function wireStage() {
    wirePick();
    const k = kind(), m = mode();
    const zoomable = k !== "other";
    const rect = () => { const p = $(".cvp", stage); return p.getBoundingClientRect(); };
    const frac = (e) => { const r = rect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
    const setView = (v) => { st.view = v; applyView(); };
    const pts = new Map();
    let pan = null, pinch0 = null, lastTap = 0, movedTap = false;
    const wipeFromEvent = (e) => { const w = $(".cvw", stage), r = w.getBoundingClientRect();
      st.wipe = wipePct(e.clientX, r.left, r.width); w.style.setProperty("--x", st.wipe + "%"); const h = $(".cvh", w); h.setAttribute("aria-valuenow", Math.round(st.wipe)); };
    let wiping = false;
    stage.onpointerdown = (e) => {
      if (e.target.closest("gk-select,label,.cvl")) return;
      stage.setPointerCapture(e.pointerId); pts.set(e.pointerId, {x: e.clientX, y: e.clientY}); movedTap = false;
      if (pts.size === 2) { const [p, q] = [...pts.values()]; pinch0 = {d: Math.hypot(p.x - q.x, p.y - q.y), view: st.view}; pan = null; wiping = false; return; }
      // The wipe divider follows the pointer from the first touch (at 1x, or when grabbing the handle).
      if (m === "wipe" && (st.view.s === 1 || e.target.closest(".cvh"))) { wiping = true; wipeFromEvent(e); return; }
      if (zoomable && st.view.s > 1) pan = {x: e.clientX, y: e.clientY};
    };
    stage.onpointermove = (e) => {
      if (!pts.has(e.pointerId)) return;
      const prev = pts.get(e.pointerId); pts.set(e.pointerId, {x: e.clientX, y: e.clientY});
      if (Math.abs(e.clientX - prev.x) + Math.abs(e.clientY - prev.y) > 2) movedTap = true;
      if (pinch0 && pts.size === 2) { const [p, q] = [...pts.values()], r = rect();
        const cx = ((p.x + q.x) / 2 - r.left) / r.width, cy = ((p.y + q.y) / 2 - r.top) / r.height;
        setView(zoomAt(pinch0.view, Math.hypot(p.x - q.x, p.y - q.y) / (pinch0.d || 1), cx, cy)); return; }
      if (wiping) { wipeFromEvent(e); return; }
      if (pan) { const r = rect(); setView(panBy(st.view, e.clientX - pan.x, e.clientY - pan.y, r.width, r.height)); pan = {x: e.clientX, y: e.clientY}; }
    };
    const up = (e) => {
      const was = pts.size; pts.delete(e.pointerId); if (pts.size < 2) pinch0 = null; if (!pts.size) { pan = null; wiping = false; }
      // A double tap zooms in on the spot, or back out; a single tap flips in the A/B view.
      if (e.type === "pointerup" && was === 1 && !movedTap && !e.target.closest("gk-select,label,.cvl,.cvh")) {
        const now = performance.now();
        if (now - lastTap < 320 && zoomable) { const [cx, cy] = frac(e); setView(st.view.s > 1 ? {s: 1, fx: 0, fy: 0} : zoomAt(st.view, 2.5, cx, cy)); lastTap = 0; }
        else { lastTap = now; if (m === "flip") flipTo(st.flip === "a" ? "b" : "a"); }
      }
    };
    stage.onpointerup = up; stage.onpointercancel = up;
    stage.onwheel = (e) => { if (!zoomable) return; e.preventDefault(); const [cx, cy] = frac(e); setView(zoomAt(st.view, Math.exp(-e.deltaY * (e.ctrlKey ? 0.01 : 0.0022)), cx, cy)); };
    const h = $(".cvh", stage);
    if (h) h.onkeydown = (e) => { const d = { ArrowLeft: -2, ArrowRight: 2 }[e.key]; if (!d) return; e.preventDefault(); e.stopPropagation();
      st.wipe = Math.min(100, Math.max(0, st.wipe + d * (e.shiftKey ? 5 : 1))); $(".cvw", stage).style.setProperty("--x", st.wipe + "%"); h.setAttribute("aria-valuenow", Math.round(st.wipe)); };
  }

  // ---- two videos, played in step ----
  const vids = () => ({a: $('video[data-vid="a"]', stage), b: $('video[data-vid="b"]', stage)});
  const span = () => { const {a: x, b: y} = vids(); return Math.max(x && x.duration || 0, y && y.duration || 0); };
  const fpsOf = () => (fileOf("b") || {}).fps || (fileOf("a") || {}).fps || 0;
  const seekAll = (t) => { const {a: x, b: y} = vids(); if (!x || !y) return; st.t = t;
    for (const v of [x, y]) { const al = alignTime(t, v.duration); const go = () => { try { v.currentTime = al.t; } catch (e) {} }; v.readyState >= 1 ? go() : v.addEventListener("loadedmetadata", go, {once: true}); }
    tick(); };
  let raf = 0;
  const fmtT = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
  function tick() {
    const {a: x, b: y} = vids(); if (!x || !y) return;
    // The longer clip leads; the other is pulled back in step if it drifts, and holds its last frame.
    const lead = (x.duration || 0) >= (y.duration || 0) ? x : y, other = lead === x ? y : x;
    if (st.playing) {
      st.t = lead.currentTime;
      const al = alignTime(st.t, other.duration);
      if (!al.past && Math.abs(other.currentTime - al.t) > 0.12) { try { other.currentTime = al.t; } catch (e) {} }
      if (al.past && !other.paused) other.pause(); else if (!al.past && other.paused && !lead.paused) other.play().catch(() => {});
      if (lead.ended) { seekAll(0); play(true); }
    }
    const total = span(), sc = $("#cvscrub"), nw = $("#cvnow");
    if (sc && !sc.matches(":active")) sc.value = total ? Math.round(st.t / total * 1000) : 0;
    if (nw) nw.textContent = `${fmtT(st.t)} / ${fmtT(total)}`;
    if (st.playing) raf = requestAnimationFrame(tick);
  }
  function play(on) {
    const {a: x, b: y} = vids(); if (!x || !y) return;
    st.playing = on; cancelAnimationFrame(raf);
    const btn = $("#cvplay"); if (btn) { btn.innerHTML = cvIc(on ? "pause" : "play"); btn.setAttribute("aria-label", on ? tl("cv.pause") : tl("cv.play")); }
    if (on) { for (const v of [x, y]) { const al = alignTime(st.t, v.duration); if (!al.past) { try { v.currentTime = al.t; } catch (e) {} v.play().catch(() => {}); } }
      raf = requestAnimationFrame(tick); }
    else { x.pause(); y.pause(); tick(); }
  }
  function wireVideo() {
    const {a: x, b: y} = vids(); if (!x || !y) { st.playing = false; return; }
    for (const v of [x, y]) v.addEventListener("loadedmetadata", () => tick());
    const wasPlaying = st.playing; st.playing = false;
    seekAll(st.t); if (wasPlaying) play(true);
  }
  function wireVidBar() {
    const btn = $("#cvplay"); btn.innerHTML = cvIc(st.playing ? "pause" : "play"); btn.onclick = () => play(!st.playing);
    foot.querySelectorAll("[data-cs]").forEach((b) => b.onclick = () => { play(false); seekAll(stepTime(st.t, fpsOf(), +b.dataset.cs, span())); });
    $("#cvscrub").oninput = (e) => seekAll(+e.target.value / 1000 * span());
    tick();
  }

  // ---- the fix check: the ask, what the fix says changed, and 맞아 / 아직 ----
  // 맞아 records a verdict on this ask's revision in the fixed version (not a version approval).
  // 아직 sends the ask back as the same directive; the ask and earlier rounds stay as they were.
  const fv = $("#cvfv");
  const drawVerify = (cf, why) => {
    const cyc = verify.cycle > 1 ? `<em class="cvfvcy num">${tl("fixv.cycle", {n: verify.cycle})}</em>` : "";
    fv.innerHTML = `<div class="cvfvtx"><div class="cvfvq"><b>${tl("fixv.ask")}</b>${cyc}<p>${cvEsc(verify.text || "")}</p></div>
        <div class="cvfvn"><b>${tl("fixv.note")}</b><p${verify.note ? "" : ' class="none"'}>${verify.note ? cvEsc(verify.note) : tl("fixv.nonote")}</p></div>
        ${verify.where ? `<p class="cvfvw">${cvEsc(verify.where)}</p>` : ""}</div>
      <div class="cvfvact">${cf ? `<div class="cvfvcf">${cf.html}<div class="cvfvrow"><button class="press cvfvbtn" data-fva="reload">${tl("conflict.reload")}</button>${cf.retry ? `<button class="press cvfvbtn fill" data-fva="retry">${cvEsc(cf.again || "")}</button>` : ""}</div></div>`
        : why ? `<div class="cvfvwhy"><input id="cvfvwhy" type="text" maxlength="300" enterkeyhint="send" autocomplete="off" placeholder="${tl("fixv.why")}" aria-label="${tl("fixv.why")}"></div>
          <div class="cvfvrow"><button class="press cvfvbtn" data-fva="back">${tl("fixv.back")}</button><button class="press cvfvbtn fill" data-fva="send">${tl("fixv.send")}</button></div>`
        : `<div class="cvfvrow"><button class="press cvfvbtn" data-fva="no">${tl("fixv.no")}</button><button class="press cvfvbtn fill" data-fva="ok">${tl("fixv.yes")}</button></div>`}</div>`;
    fv.querySelectorAll("[data-fva]").forEach((btn) => btn.onclick = () => act(btn.dataset.fva, btn, cf));
    const inp = $("#cvfvwhy");
    if (inp) inp.focus({preventScroll: true});   // Enter sends: see onKey
  };
  const settle = async (p, btn) => { fv.querySelectorAll("button").forEach((x) => { x.disabled = true; });
    try { const r = await p; if (r === true) { close(); return; } drawVerify(r); }
    catch (e) { fv.querySelectorAll("button").forEach((x) => { x.disabled = false; }); typeof toast === "function" && toast(e.message); } };
  const act = (k, btn, cf) => {
    if (k === "reload") { verify.reload && verify.reload(); close(); return; }
    if (k === "retry") return settle(cf.retry(), btn);
    // 아직 opens an optional "what is still off" line; Enter or the button sends it. The server
    // keeps the reason on the directive's history and in the re-ask (cycle +1).
    if (k === "no") return drawVerify(null, true);
    if (k === "back") return drawVerify(null);
    if (k === "send") return settle(verify.decide(false, (($("#cvfvwhy") || {}).value || "").trim()), btn);
    return settle(verify.decide(true), btn);
  };
  if (verify) drawVerify(null);

  // ---- keys: everything is swallowed while the workspace is open, so the item's own shortcuts
  // (approve, next version...) cannot fire underneath ----
  const onKey = (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    // A version picker handles its own keys (web/sel.js). This listener runs first (capture), so it
    // only steps aside: stopping the key here would keep it from the picker. Esc and Tab are the
    // picker's while its list is open, and this view's once it is closed.
    const pick = e.target.closest && e.target.closest("gk-select");
    if (pick && (pick.getAttribute("aria-expanded") === "true" || (e.key !== "Escape" && e.key !== "Tab"))) return;
    // typing the 아직 reason: letters stay in the box (mode keys, space, J/K must not fire)
    // (this listener is on the window's capture phase, so Enter is handled here: the box's own
    // listener never sees a key stopped above it)
    if (e.target.matches && e.target.matches("input[type=text]") && e.key !== "Escape" && e.key !== "Tab") {
      e.stopPropagation();
      if (e.target.id === "cvcmin" && e.key === "Enter" && !e.isComposing) { e.preventDefault(); e.target.form.requestSubmit(); }
      if (e.key === "Enter" && !e.isComposing && e.target.id === "cvfvwhy") { e.preventDefault(); const s = root.querySelector("[data-fva=send]"); if (s && !s.disabled) s.click(); }
      return; }
    e.stopImmediatePropagation();
    const k = e.key;
    if (k === "Escape") { e.preventDefault(); if (e.target.id === "cvcmin") { e.target.blur(); root.focus({preventScroll: true}); return; } close(); return; }
    if (k === "Tab") { const els = [...root.querySelectorAll("button:not([disabled]),gk-select,input,[tabindex='0']")].filter((n) => n.offsetParent); if (!els.length) return;
      const i = els.indexOf(document.activeElement), n = e.shiftKey ? (i <= 0 ? els.length - 1 : i - 1) : (i + 1) % els.length;
      e.preventDefault(); els[n].focus(); return; }
    const md = cvModes().find((m) => m[2] === k);
    if (md) { if (modes().includes(md[0])) { st.mode = md[0]; cvMode(md[0]); build(); } return; }
    if (k === " " || k === "Spacebar") {
      if (e.target.matches && e.target.matches("button,input")) { if (e.target.tagName === "BUTTON") return; }
      e.preventDefault();
      if (mode() === "flip") flipTo(st.flip === "a" ? "b" : "a"); else if (kind() === "video") play(!st.playing);
    } else if (k === "k" || k === "K") { if (kind() === "video") play(!st.playing); }
    else if (k === "0") { st.view = {s: 1, fx: 0, fy: 0}; applyView(); }
    else if (k === "+" || k === "=") { st.view = zoomAt(st.view, 1.25, 0.5, 0.5); applyView(); }
    else if (k === "-" || k === "_") { st.view = zoomAt(st.view, 0.8, 0.5, 0.5); applyView(); }
    else if (k === "ArrowLeft" || k === "ArrowRight") {
      if (mode() === "wipe" && document.activeElement === $(".cvh", stage)) return;
      if (kind() === "video") { e.preventDefault(); play(false); seekAll(stepTime(st.t, fpsOf(), k === "ArrowRight" ? 1 : -1, span())); }
      else if (mode() === "flip") flipTo(k === "ArrowLeft" ? "a" : "b");
    }
  };

  // ---- open / close ----
  const inertEls = [...document.body.children].filter((n) => n !== root);
  let closing = false;
  // popped: the phone's back already took our history entry ("keep": a new compare reuses it);
  // otherwise we take it back ourselves, like the full-screen viewer.
  function close(instant, popped) {
    if (closing) return; closing = true;
    cancelAnimationFrame(raf); play(false);
    removeEventListener("keydown", onKey, true); removeEventListener("resize", onResize);
    removeEventListener("popstate", onPop);
    if (!popped && history.state?.cv) history.back();
    inertEls.forEach((n) => n.removeAttribute("inert"));
    document.documentElement.classList.remove("cmpv-lock");
    cvOpen = null;
    const done = () => { root.remove(); try { restoreFocus && restoreFocus.isConnected && restoreFocus.focus({preventScroll: true}); } catch (e) {} onClose && onClose(st.posted); };
    if (instant === true) { done(); return; }
    root.classList.remove("in"); root.classList.add("out");
    let fin = false; const end = () => { if (!fin) { fin = true; done(); } };
    root.addEventListener("transitionend", (e) => { if (e.target === root) end(); }); setTimeout(end, reduce ? 260 : 460);
  }
  const onResize = () => { root.dataset.phone = phone() ? "1" : "0"; if (verify) placeRegions(); };
  cvOpen = {close};
  // Back on a phone closes compare and stays on the result (it used to leave the item for the list).
  const onPop = () => { if (!history.state?.cv) close(false, true); };
  try { if (!history.state?.cv) history.pushState({cv: 1}, ""); addEventListener("popstate", onPop); } catch (e) {}
  onResize();
  document.body.appendChild(root);
  inertEls.forEach((n) => n.setAttribute("inert", ""));
  document.documentElement.classList.add("cmpv-lock");
  addEventListener("keydown", onKey, true); addEventListener("resize", onResize);
  root.querySelectorAll("[data-cm]").forEach((b) => b.onclick = () => { if (!modes().includes(b.dataset.cm)) return; st.mode = b.dataset.cm; cvMode(b.dataset.cm); build(); });
  $("#cvend").onclick = () => close();
  $("#cvzr").onclick = () => { st.view = {s: 1, fx: 0, fy: 0}; applyView(); };
  st.pref = verify && verify.file || (fileOf("b") || fileOf("a") || {}).name;
  build();
  // On a phone the pair stacks; the A/B flip is one tap away. Enter from below with a spring-like
  // ease, or a plain fade when motion is reduced. The class flips on the next frame so it can be reversed.
  // Focus the dialog itself, not 비교 끝내기: Space (play) on a focused button would end the compare.
  root.tabIndex = -1;
  requestAnimationFrame(() => { root.classList.add("in"); root.focus({preventScroll: true}); });
  return close;
}
