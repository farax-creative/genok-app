// Handoff bundle ("인수인계 묶음"), as a Genok extension: a per-item panel in the item
// view's inspector column. Attached through window.LOOP_ITEM_VIEW (the per-item slot, the same
// hook parity.js / draw.js use). Globals used with safe fallbacks: get, post, toast, esc, ic.
//
// The panel is collapsed and loads nothing until first opened. Opened, it fetches the bundle
// (latest version + path, the source session's folder and git checkout, rejected reasons, open
// directives, a ready prompt) and offers three actions: copy the prompt, save it as an .md file
// in the item's folder, or send it to a session the person picks from the ones that worked this
// project. It never picks an account or a session on its own.

(function () {
  "use strict";
  // Inline copy in two languages (these extension files carry their own text, not i18n keys).
  const L = (ko, en) => (window.I18N_LANG === "en" ? en : ko);
  const _get = typeof get === "function" ? get : (p) => fetch(p, { cache: "no-store" }).then((r) => r.json());
  const _post = typeof post === "function" ? post : (p, b) => fetch(p, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b),
  }).then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || L("불러오지 못했어요", "Could not load")); return j; });
  const _toast = typeof toast === "function" ? toast : (m) => { try { console.log(m); } catch (e) {} };
  const _esc = typeof esc === "function" ? esc : (s) => String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  // What a project (or a group) is called on screen: the display name a person gave it (v2.js).
  const _pn = (n) => typeof pname === "function" ? pname(n) : n;
  const _ic = typeof ic === "function" ? ic : () => "";

  const STYLE = `
.ho{margin-top:12px;--h-line:var(--line,rgba(255,255,255,.08));--h-t1:var(--t1,#efe9dc);
  --h-t2:var(--t2,#b0b1b8);--h-t3:var(--t3,#8c8d95);--h-btn:var(--btn,#222327);--h-btn2:var(--btn-hi,#2a2b30);
  --h-blue:var(--blue,#5e6ad2);--h-green:var(--green,#1fc67a);--h-orange:var(--orange,#fe9800);
  --h-red:var(--red,#f04452);--h-bg:var(--bg,#0e0f11);--h-r:var(--r-btn,10px);}
.ho summary{list-style:none;cursor:pointer;user-select:none;padding:16px 16px;display:flex;align-items:center;gap:8px;}
.ho summary::-webkit-details-marker{display:none;}
.ho .hlbl{font-size:12px;font-weight:600;letter-spacing:.06em;color:var(--h-t3);text-transform:uppercase;flex:1;}
.ho summary .i.dn{width:20px;height:20px;color:var(--h-t3);transition:transform .25s var(--ease,ease);}
.ho[open] summary .i.dn{transform:rotate(-90deg);}
.ho-body{padding:2px 16px 16px;}
.ho-sec{margin:0 0 16px;}
.ho-sec h4{margin:0 0 6px;font-size:11.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--h-t3);}
.ho-kv{font-size:13px;color:var(--h-t2);line-height:1.5;word-break:break-all;}
.ho-kv b{color:var(--h-t1);font-weight:600;}
.ho-path{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:var(--h-t2);
  background:var(--h-bg);border:1px solid var(--h-line);border-radius:8px;padding:8px 8px;word-break:break-all;}
.ho-chip{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:600;
  background:var(--h-btn);border:1px solid var(--h-line);border-radius:8px;padding:4px 8px;color:var(--h-t2);margin-right:6px;}
.ho-chip b{color:var(--h-t1);}
.ho-li{font-size:13px;line-height:1.5;color:var(--h-t1);padding:4px 0;border-top:1px solid var(--h-line);}
.ho-li:first-child{border-top:0;}
.ho-li .tag{font-size:12px;font-weight:600;color:var(--h-orange);margin-right:6px;}
.ho-dim{font-size:12px;color:var(--h-t3);}
.ho-pre{white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.55;color:var(--h-t2);
  background:var(--h-bg);border:1px solid var(--h-line);border-radius:8px;padding:12px 12px;max-height:220px;overflow:auto;}
.ho-acts{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;}
.ho-acts button{height:38px;padding:0 16px;border-radius:var(--h-r);border:1px solid var(--h-line);
  background:var(--h-btn);color:var(--h-t1);font-size:13px;font-weight:600;cursor:pointer;
  transition:background .16s ease,transform .16s cubic-bezier(.34,1.4,.64,1);}
.ho-acts button:hover{background:var(--h-btn2);}
.ho-acts button:active{transform:scale(.96);}
.ho-acts button.primary{background:var(--h-blue);border-color:transparent;color:#fff;}
.ho-send{margin-top:12px;padding:12px;border:1px solid var(--h-line);border-radius:var(--h-r);background:var(--h-bg);}
.ho-send h4{margin:0 0 8px;}
.ho-send gk-select{display:flex;width:100%;margin-bottom:8px;}
.ho-send .note{font-size:11.5px;color:var(--h-t3);line-height:1.45;margin-top:8px;}
.ho-loading{padding:8px 0;font-size:13px;color:var(--h-t3);}
@media (max-width:420px){.ho-acts button{flex:1;}}`;

  let styled = false;
  function ensureStyle() {
    if (styled) return;
    const s = document.createElement("style");
    s.textContent = STYLE;
    document.head.appendChild(s);
    styled = true;
  }

  function sh(ms) { return new Date(ms).toLocaleDateString(window.I18N_LANG === "en" ? "en-US" : "ko-KR", { month: "numeric", day: "numeric" }); }
  function when(iso) {
    const t = Date.parse((iso || "").replace(" ", "T"));
    return t ? sh(t) : "";
  }

  function render(body, it, d) {
    const p = it.p, i = it.i;
    body.innerHTML = loadingHtml("");
    _get(`/api/handoff?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`)
      .then((b) => fill(body, b))
      .catch((e) => { body.innerHTML = `<div class="ho-loading">${_esc(e.message || L("불러오지 못했어요", "Could not load"))}</div>`; });
  }

  function fill(body, b) {
    const co = b.session && b.session.checkout;
    const chk = co
      ? `<span class="ho-chip">${L("브랜치", "Branch")} <b>${_esc(co.branch || "(detached)")}</b></span><span class="ho-chip">HEAD <b>${_esc(co.head || "")}</b></span>`
      : `<span class="ho-dim">${L("git 체크아웃 아님", "Not a git checkout")}</span>`;
    const rej = (b.rejected || []).length
      ? (b.rejected || []).map((r) => `<div class="ho-li"><span class="tag">${r.status === "hold" ? L("보류", "Hold") : L("수정 요청", "Changes requested")} ${_esc(r.v || "")}</span>${_esc(r.text || "")}</div>`).join("")
      : `<div class="ho-dim">${L("돌려보낸 이유 없음", "No reasons for sending back")}</div>`;
    const opn = (b.open_directives || []).length
      ? (b.open_directives || []).map((o) => `<div class="ho-li">${_esc(o.text || "")}</div>`).join("")
      : `<div class="ho-dim">${L("열린 요청 없음", "No open requests")}</div>`;
    const sessions = b.recent_sessions || [];
    const canSend = b.can_send && sessions.length;
    const sendBox = canSend ? `<div class="ho-send">
      <h4>${L("다른 대화에 보내기", "Send to another chat")}</h4>
      <gk-select id="ho-sel" aria-label="${L("다른 대화에 보내기", "Send to another chat")}">${sessions.map((s) =>
        `<option value="${_esc(s.session_id)}">${_esc(s.item)} ${_esc(s.v)} · ${_esc((s.cwd || "").split(/[\\/]/).pop() || s.session_id.slice(0, 8))}${s.config_dir ? " · " + _esc(String(s.config_dir).split(/[\\/]/).pop()) : ""} · ${_esc(when(s.at))}</option>`).join("")}</gk-select>
      <button class="primary" id="ho-send">${L("이 대화로 보내기", "Send to this chat")}</button>
      <div class="note">${L("고른 대화가 다음에 움직일 때 받아요.", "The chat gets it when it next runs.")}</div>
    </div>` : (b.can_send
      ? `<div class="ho-dim" style="margin-top:12px">${_esc(L(ut("이 {unit}에서 대화 기록이 있는 결과물이 없어요. 복사해서 붙여넣어 주세요."), "No result here has a chat record. Copy and paste it."))}</div>`
      : `<div class="ho-dim" style="margin-top:12px">${L("이 빌드에는 대화로 보내는 경로가 없어요. 복사해서 붙여넣어 주세요.", "This build cannot send to a chat. Copy and paste it.")}</div>`);

    body.innerHTML = `
      <div class="ho-sec"><h4>${L("최신 버전", "Latest version")}</h4>
        <div class="ho-kv"><b>${_esc(b.latest.v)}</b>${b.latest.dept ? " · " + _esc(_pn(b.latest.dept)) : ""}${b.latest.at ? " · " + _esc(when(b.latest.at)) : ""}${(b.latest.files || []).length ? " · " + b.latest.files.length + L("개 파일", " files") : ""}</div>
        <div class="ho-path" style="margin-top:6px">${_esc(b.latest.path)}</div>
      </div>
      <div class="ho-sec"><h4>${L("작업한 대화", "Working chat")}</h4>
        <div class="ho-path">${_esc(b.session.cwd || L("폴더 정보 없음", "No folder info"))}</div>
        <div style="margin-top:7px">${chk}</div>
      </div>
      <div class="ho-sec"><h4>${L("돌려보낸 이유", "Reasons sent back")}</h4>${rej}</div>
      <div class="ho-sec"><h4>${L("열린 요청", "Open requests")}</h4>${opn}</div>
      <div class="ho-sec"><h4>${L("보낼 프롬프트", "Prompt to send")}</h4><div class="ho-pre" id="ho-prompt">${_esc(b.prompt)}</div></div>
      <div class="ho-acts">
        <button id="ho-copy">${L("복사", "Copy")}</button>
        <button id="ho-save">${L(".md로 저장", "Save as .md")}</button>
      </div>
      ${sendBox}`;

    body.querySelector("#ho-copy").onclick = () => copyText(b.prompt);
    body.querySelector("#ho-save").onclick = (e) => saveMd(e.currentTarget, b);
    const sb = body.querySelector("#ho-send");
    if (sb) sb.onclick = (e) => sendTo(e.currentTarget, b, body.querySelector("#ho-sel").value);
  }

  function copyText(text) {
    const done = () => _toast(L("복사했어요", "Copied"));
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
    } else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    const ta = document.createElement("textarea");
    ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); done(); } catch (e) { _toast(L("복사하지 못했어요", "Could not copy")); }
    ta.remove();
  }

  async function saveMd(btn, b) {
    btn.disabled = true;
    try {
      const r = await _post("/api/handoff/save", { p: b.project, i: b.id });
      _toast(L(`저장했어요 · ${r.saved}`, `Saved · ${r.saved}`));
    } catch (e) { _toast(e.message || "실패"); }
    btn.disabled = false;
  }

  async function sendTo(btn, b, sessionId) {
    if (!sessionId) { _toast(L("보낼 대화를 골라 주세요", "Pick a chat to send to")); return; }
    btn.disabled = true;
    try {
      // loopFetch shows the in-app permission dialog first; nothing is sent until it is allowed.
      const r = typeof loopFetch === "function"
        ? await loopFetch("/api/handoff/send", { json: { p: b.project, i: b.id, session_id: sessionId } })
        : await _post("/api/handoff/send", { p: b.project, i: b.id, session_id: sessionId });
      if (r.declined) { _toast(L("보내지 않았어요", "Not sent")); btn.disabled = false; return; }
      _toast(r.current ? L("그 대화로 보냈어요 (곧 받아요)", "Sent to that chat") : L("그 대화 대기열에 넣었어요", "Queued for that chat"));
    } catch (e) { _toast(e.message || "실패"); }
    btn.disabled = false;
  }

  function attach(box, it, d) {
    if (!it || !it.p || !it.i) return;
    ensureStyle();
    // Sit in the inspector column with the other per-item sections (mirrors parity.js).
    const col = (box.querySelector(".htitle") && box.querySelector(".htitle").parentElement) || box;
    if (col.querySelector(".ho")) return;                    // already attached
    const det = document.createElement("details");
    det.className = "ho card";
    det.innerHTML = `<summary class="ch"><span class="hlbl">${L("인수인계 묶음", "Handoff bundle")}</span>${_ic("chev", "i dn") || ""}</summary><div class="ho-body"></div>`;
    const bodyEl = det.querySelector(".ho-body");
    let loaded = false;
    det.addEventListener("toggle", () => { if (det.open && !loaded) { loaded = true; render(bodyEl, it, d); } });
    (col.querySelector("#ixtra") || col).appendChild(det);
  }

  window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || [];
  window.LOOP_ITEM_VIEW.push(attach);
})();
