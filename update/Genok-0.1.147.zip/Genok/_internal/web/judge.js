// 판정 모드 (judge mode): one result fills the screen and a single thin bar answers it, after
// Frame.io's review mode and RV's player - the picture, a counter, three answers, nothing else.
//
// The three answers are the verdicts a result already has, under the names the user asked for:
//   보류 -> "hold"      (looked at, not decided; an untouched "pending" result shows no
//                             answer pressed, so unseen and held tell apart)
//   고치기 -> "changes"   (written only with its one-line note, which becomes an open directive -
//                             the same /api/comment entry `loop todo` lists - delivered at once)
//   승인 -> "approved"
// Nothing new is stored: the status values and the comment are the ones the cards already write.
//
// Keys: J / K next / previous result of the list it was opened on, ← / → one frame of a video
// (Shift: ten) or the previous / next picture of a version with several, 1 / 2 / 3 the answers,
// Space play / pause, Esc leaves (or closes the note line first). Phone: a swipe on the picture
// follows the finger 1:1 and moves on when flung or pulled past a third; the bar sits at the
// bottom within thumb reach.
// Loaded after v2.js, whose names (D, iid, tl, post, ...) it uses. The pure part is tested in
// tests/judge.test.js.
(function () {
  "use strict";

  // ---------- pure: answers, keys, swipe ----------
  const STATES = ["wait", "redo", "done"];
  const TO_STATUS = {wait: "hold", redo: "changes", done: "approved"};
  const stateOf = (status) => status === "approved" ? "done" : status === "changes" ? "redo" : "wait";
  const statusFor = (state) => TO_STATUS[state] || null;
  // The status to write for an answer, or null when the result already says so.
  const writeFor = (status, state) => status === statusFor(state) ? null : statusFor(state);
  // The answer the bar shows pressed: none on a result nobody has answered yet.
  const pressedOf = (status) => status === "hold" || status === "changes" || status === "approved" ? stateOf(status) : null;

  // ev: {key, shift, mod (ctrl / meta / alt), typing (focus in the note line)}
  // ctx: {video (the shown file is a video), files (pictures in the version), file (shown index)}
  function action(ev, ctx = {}) {
    if (ev.mod) return null;
    const k = ev.key;
    if (ev.typing) return k === "Escape" ? {t: "unline"} : null;
    if (k === "Escape") return {t: "exit"};
    if (k === "j" || k === "J") return {t: "result", d: 1};
    if (k === "k" || k === "K") return {t: "result", d: -1};
    if (k === "1" || k === "2" || k === "3") return {t: "state", s: STATES[+k - 1]};
    if (k === " " && ctx.video) return {t: "play"};
    if (k === "ArrowLeft" || k === "ArrowRight") {
      const d = k === "ArrowLeft" ? -1 : 1;
      if (ctx.video) return {t: "frame", d: ev.shift ? d * 10 : d};
      if ((ctx.files || 0) > 1) return to(ctx.file || 0, d, ctx.files) == null ? null : {t: "file", d};
      return null;
    }
    return null;
  }
  // The index d steps from i in a list of n, or null past either end (no wrap: the end is an end).
  const to = (i, d, n) => { const j = i + d; return j >= 0 && j < n ? j : null; };
  // A swipe of dx px over ms on a picture w px wide: 1 next, -1 previous, 0 back in place.
  function swipe(dx, ms, w) {
    const v = dx / Math.max(1, ms);
    if (Math.abs(dx) < 24) return 0;
    return Math.abs(dx) > w / 3 || Math.abs(v) > 0.5 ? (dx < 0 ? 1 : -1) : 0;
  }
  const pure = {STATES, stateOf, statusFor, writeFor, pressedOf, action, to, swipe};
  if (typeof module !== "undefined") module.exports = pure;
  if (typeof window === "undefined" || typeof document === "undefined") return;

  // ---------- the screen ----------
  // Its look comes after glass.css (added by v2.js, which runs first), on the redesign only.
  if (document.documentElement.classList.contains("rd")) {
    const l = document.createElement("link"); l.rel = "stylesheet"; l.href = "/ovh-judge.css"; document.head.appendChild(l);
  }
  const NAME = {wait: () => tl("jd.wait"), redo: () => tl("jd.redo"), done: () => tl("jd.done")};
  const RMq = () => typeof RM === "function" && RM();
  let J = null;           // {list, at, file, from, back, el, dirty, line, halt}
  const detailOf = new Map();       // iid|v -> Promise<files of that version>
  const posted = new Map();         // iid -> a note already posted whose status / delivery failed

  const here = () => J && D.items.find((y) => iid(y) === J.list[J.at]);
  function filesOf(x) {
    const k = iid(x) + "|" + x.v;
    if (!detailOf.has(k)) detailOf.set(k, itemDetail(x.project, x.id).then((d) => {
      const fs = (d?.versions || []).find((y) => y.v === x.v)?.files || [];
      const pics = fs.filter((f) => f.kind === "image" || f.kind === "video");
      return pics.length ? pics : fs.filter((f) => f.kind === "html").slice(0, 1);
    }));
    return detailOf.get(k);
  }

  function open(list, k, from) {
    if (J || !list.length) return;
    const ids = list.map((x) => typeof x === "string" ? x : iid(x));
    const o = document.createElement("div");
    o.className = "jd"; o.tabIndex = -1; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true"); o.setAttribute("aria-label", tl("jd.title"));
    o.innerHTML = `<div class="jdm" aria-live="off"></div>
      <div class="jdline" hidden><input class="jdin" maxlength="500" enterkeyhint="send" autocomplete="off" placeholder="${esc(tl("jd.line"))}" aria-label="${esc(tl("jd.line"))}"><button type="button" class="jdsend press" disabled>${esc(tl("rv.go"))}</button></div>
      <div class="jdbar">
        <div class="jdnav"><button type="button" class="jdst press" data-jds="-1" aria-label="${esc(tl("rv.prev"))}" title="${esc(tl("rv.prev"))} (K)">${ic("back")}</button><span class="jdn num"></span><button type="button" class="jdst press" data-jds="1" aria-label="${esc(tl("rv.next"))}" title="${esc(tl("rv.next"))} (J)">${ic("chev")}</button></div>
        <div class="jdt"><b></b><span class="jdver num"></span><span class="jdf num"></span></div>
        <div class="jdv" role="group" aria-label="${esc(tl("jd.title"))}">${STATES.map((s, n) => `<button type="button" class="jdb press" data-jdv="${s}" aria-pressed="false">${esc(NAME[s]())}<kbd aria-hidden="true">${n + 1}</kbd></button>`).join("")}</div>
        <button type="button" class="jdx press" aria-label="${esc(tl("rv.close"))}" title="${esc(tl("rv.close"))} (Esc)">${ic("x")}</button>
      </div>`;
    document.body.appendChild(o);
    J = {list: ids, at: Math.max(0, ids.indexOf(k)), file: 0, from: document.activeElement, back: from || "lib", el: o, dirty: false};
    wire(o);
    draw();
    requestAnimationFrame(() => o.classList.add("on"));
    o.focus({preventScroll: true});
  }

  function close() {
    if (!J) return;
    const {el, from, back, dirty} = J, x = here();
    J = null;
    removeEventListener("keydown", onKey, true);
    removeEventListener("blur", onBlur);
    el.classList.remove("on"); el.classList.add("out");
    setTimeout(() => el.remove(), RMq() ? 150 : 220);
    const k = x && iid(x);
    // Back where it was opened: the item's own page follows to the result looked at last, the
    // results screen brings that result's card into view.
    if (back === "item" && k && detail?.[1] !== k) { nav("item/" + k); return; }
    const after = () => {
      const c = k && document.querySelector(`#view [data-gk="${CSS.escape(k)}"],#view [data-item="${CSS.escape(k)}"]`);
      if (c) c.scrollIntoView({block: "nearest", behavior: RMq() ? "auto" : "smooth"});
      else if (from?.isConnected) from.focus({preventScroll: true});
    };
    if (!dirty) return after();
    load().then(() => { if (detail?.[0] === "item") itemView(detail[1]); else SCREENS[cur]?.(); after(); }).catch(after);
  }

  // ---------- drawing one result ----------
  function draw(fade = true) {
    const x = here(); if (!x) return close();
    J.halt?.();
    const o = J.el, m = o.querySelector(".jdm"), k = iid(x);
    J.file = 0;
    o.querySelector(".jdn").textContent = `${J.at + 1} / ${J.list.length}`;
    o.querySelector(".jdt b").textContent = x.title;
    o.querySelector(".jdver").textContent = x.v || "";
    o.querySelectorAll("[data-jds]").forEach((b) => { b.disabled = to(J.at, +b.dataset.jds, J.list.length) == null; });
    paint(x);
    line(false);
    m.dataset.gk = k;
    if (fade) m.classList.add("fade");
    m.innerHTML = x.thumb ? `<img src="${esc(x.thumb)}" alt="" draggable="false" class="jdthumb">` : `<span class="jdi">${ic((KIND[x.kind] || ["doc"])[0])}</span>`;
    meta("");
    void m.offsetWidth; m.classList.remove("fade");
    filesOf(x).then((fs) => { if (J && m.dataset.gk === k) { J.files = fs; show(m, x, fs, 0); } });
  }
  function show(m, x, fs, n) {
    J.file = n;
    const f = fs[n];
    if (!f) { if (!x.thumb) m.innerHTML = `<p class="jdnone">${esc(tl("jd.none"))}</p>`; meta(""); return; }
    const many = fs.length > 1 ? `${n + 1} / ${fs.length}` : "";
    if (f.kind === "html") {
      m.innerHTML = `<iframe src="${esc(keyUrl(f.url))}" title="${esc(f.name)}" sandbox="allow-scripts allow-popups"></iframe>`;
      return meta(f.name);
    }
    if (f.kind === "video") {
      const vd = document.createElement("video");
      Object.assign(vd, {src: f.play || f.url, controls: true, playsInline: true, loop: true, preload: "auto"});
      vd.muted = typeof sound === "function" ? !sound() : false;
      if (f.thumb || x.thumb) vd.poster = f.thumb || x.thumb;
      const tick = () => meta([many, frameTxt(vd, f)].filter(Boolean).join(" · "));
      vd.addEventListener("timeupdate", tick); vd.addEventListener("seeked", tick); vd.addEventListener("loadedmetadata", tick);
      m.replaceChildren(vd);
      return meta(many);
    }
    const im = new Image(); im.alt = f.name || ""; im.decoding = "async"; im.draggable = false;
    im.onload = () => { if (J && m.dataset.gk === iid(x) && J.file === n) m.replaceChildren(im); };
    im.src = f.url;
    if (!x.thumb || n) m.replaceChildren(im);
    meta([many, typeof SeqGroup !== "undefined" && fs.length >= SeqGroup.MIN ? SeqGroup.num(f.name) : ""].filter(Boolean).join(" · "));
  }
  const frameTxt = (vd, f) => typeof clock !== "function" ? "" : clock(vd.currentTime) + (f.fps && typeof frameOf === "function" ? ` · f${frameOf(vd.currentTime, f.fps)}` : "");
  const meta = (s) => { const el = J?.el.querySelector(".jdf"); if (el) el.textContent = s; };
  function paint(x) {
    const s = stateOf(x.status), p = pressedOf(x.status);
    J.el.querySelectorAll("[data-jdv]").forEach((b) => { b.setAttribute("aria-pressed", String(b.dataset.jdv === p)); b.disabled = !!x.finished; });
    J.el.dataset.state = s;
  }

  // ---------- moving ----------
  function result(d) {
    const n = to(J.at, d, J.list.length);
    if (n == null) { if (d > 0) toast(tl("jd.end"), 2200); return false; }
    J.at = n; draw(); return true;
  }
  function file(d) {
    const x = here(), fs = J.files || [], n = to(J.file, d, fs.length);
    if (!x || n == null) return;
    show(J.el.querySelector(".jdm"), x, fs, n);
  }
  const video = () => J?.el.querySelector(".jdm video");

  // ---------- answering ----------
  async function answer(s) {
    const x = here(); if (!x || x.finished) return;
    // 고치기 writes its status together with the note (send), so Esc on the line leaves nothing.
    if (s === "redo") return line(true);
    const k = iid(x), was = x.status, w = writeFor(was, s);
    if (w) {
      x.status = w; paint(x); J.dirty = true;
      try {
        await post("/api/status", {p: x.project, i: x.id, v: x.v, status: w,
          ...(w === "approved" ? {rev: x.rev ?? await itemRev(x.project, x.id)} : {})});
      } catch (e) {
        x.status = was; if (J && here() === x) paint(x);
        toast(typeof isConflict === "function" && isConflict(e) ? tl("rv.conflict", {n: 1}) : e.message, 4000);
        return;
      }
    }
    if (!J || iid(here() || {}) !== k) return;
    // A settled answer moves on, after a beat so the pressed state is seen.
    setTimeout(() => { if (J && iid(here() || {}) === k) result(1); }, RMq() ? 0 : 220);
  }
  // The one-line note under 고치기, kept as the result's draft (the cards' drafts) until sent.
  function line(on) {
    const L = J.el.querySelector(".jdline"), inp = L.querySelector(".jdin"), x = here();
    L.hidden = !on; J.line = on;
    if (!on) { if (L.contains(document.activeElement)) J.el.focus({preventScroll: true}); return; }
    inp.value = (x && (cmDraft[iid(x)] || posted.get(iid(x)))) || "";
    L.querySelector(".jdsend").disabled = !inp.value.trim();
    inp.focus({preventScroll: true});
  }
  async function send() {
    const x = here(), inp = J.el.querySelector(".jdin"), text = inp.value.trim();
    if (!x || !text) return;
    const b = J.el.querySelector(".jdsend"), k = iid(x); b.disabled = true;
    try {
      // A retry after a failed status / delivery only redoes those: the note is already there.
      if (posted.get(k) !== text) {
        await post("/api/comment", {p: x.project, i: x.id, v: x.v, text});
        posted.set(k, text); delete cmDraft[k]; saveDraft(); if (J) J.dirty = true;
      }
      if (x.status !== "changes") { await post("/api/status", {p: x.project, i: x.id, v: x.v, status: "changes"}); x.status = "changes"; if (J && here() === x) paint(x); }
      await post("/api/comments/send", {p: x.project, i: x.id, v: x.v});
    } catch (e) { toast(e.message, 4000); b.disabled = false; return; }
    posted.delete(k); if (J) J.dirty = true;
    toast(tl("rv.sent", {n: 1}), 2200, "send");
    if (J && iid(here() || {}) === k) { line(false); result(1); }
  }

  // ---------- input ----------
  function onKey(e) {
    if (!J) return;
    const typing = !!e.target.closest?.(".jdline");
    if (typing && e.key === "Enter" && !e.isComposing) { e.preventDefault(); e.stopImmediatePropagation(); return send(); }
    if (e.key === "Tab") { trap(e); return; }
    const vd = video();
    const a = action({key: e.key, shift: e.shiftKey, mod: e.ctrlKey || e.metaKey || e.altKey, typing},
      {video: !!vd, files: (J.files || []).length, file: J.file});
    if (!a) { if (!typing && !e.ctrlKey && !e.metaKey) e.stopImmediatePropagation(); return; }
    e.preventDefault(); e.stopImmediatePropagation();
    if (a.t === "exit") return J.line ? line(false) : close();
    if (a.t === "unline") return line(false);
    if (a.t === "result") return result(a.d);
    if (a.t === "state") return answer(a.s);
    if (a.t === "file") return file(a.d);
    if (a.t === "play") return vd.paused ? vd.play().catch(() => {}) : vd.pause();
    if (a.t === "frame") return stepVideo(vd, (J.files || [])[J.file], a.d);
  }
  // A click in an HTML result takes the keyboard into its frame, where J / K / 1-3 / Esc never
  // reach this page. Hand focus back as soon as the click has landed; the pointer still scrolls
  // and clicks inside the frame.
  function onBlur() {
    setTimeout(() => {
      const a = document.activeElement;
      if (J && a?.tagName === "IFRAME" && J.el.contains(a)) J.el.focus({preventScroll: true});
    }, 0);
  }
  function trap(e) {
    const f = [...J.el.querySelectorAll("button:not([disabled]),input:not([hidden]),video,iframe")].filter((n) => n.offsetParent);
    if (!f.length) return;
    const i = f.indexOf(document.activeElement), n = e.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : (i + 1) % f.length;
    e.preventDefault(); e.stopImmediatePropagation(); f[n].focus();
  }
  function wire(o) {
    addEventListener("keydown", onKey, true);
    addEventListener("blur", onBlur);
    o.addEventListener("click", (e) => {
      const v = e.target.closest("[data-jdv]"); if (v) return answer(v.dataset.jdv);
      const s = e.target.closest("[data-jds]"); if (s) return result(+s.dataset.jds);
      if (e.target.closest(".jdx")) return close();
      if (e.target.closest(".jdsend")) return send();
    });
    o.addEventListener("input", (e) => {
      if (!e.target.matches(".jdin")) return;
      const x = here(); if (x) { cmDraft[iid(x)] = e.target.value; saveDraft(); }
      o.querySelector(".jdsend").disabled = !e.target.value.trim();
    });
    // A swipe on the picture follows the finger 1:1. Let go past the threshold (or flung) and the
    // picture keeps going out that way at the release velocity, then the next one fades in; short
    // of it, it springs back from where it is. A touch mid-flight catches it. Reduced motion: no
    // slide, the next one just fades in.
    const m = o.querySelector(".jdm");
    let sw = null, off = 0, stop = null;
    const put = (x) => { off = x; m.style.transform = x ? `translateX(${x}px)` : ""; };
    const rest = () => { stop = null; m.style.transition = "none"; put(0); void m.offsetWidth; m.style.transition = ""; };
    // A step by key or button while the picture is still moving lands it first.
    J.halt = () => { if (stop) { stop(); rest(); } };
    m.addEventListener("pointerdown", (e) => {
      if (e.pointerType === "mouse" || e.target.closest("iframe")) return;
      // The bottom of a video is its own scrub bar.
      if (e.target.tagName === "VIDEO" && e.clientY > e.target.getBoundingClientRect().bottom - 56) return;
      const caught = !!stop; if (stop) { stop(); stop = null; try { m.setPointerCapture(e.pointerId); } catch (er) { /* gone */ } }
      sw = {id: e.pointerId, x: e.clientX - off, y: e.clientY, t: performance.now(), dx: off, on: caught, px: e.clientX, pt: performance.now(), v: 0};
    });
    m.addEventListener("pointermove", (e) => {
      if (!sw || e.pointerId !== sw.id) return;
      sw.dx = e.clientX - sw.x;
      const now = performance.now(), dt = now - sw.pt;
      if (dt > 0) { sw.v = 0.8 * ((e.clientX - sw.px) / dt * 1000) + 0.2 * sw.v; sw.px = e.clientX; sw.pt = now; }
      if (!sw.on && Math.abs(sw.dx) > 8 && Math.abs(sw.dx) > Math.abs(e.clientY - sw.y)) { sw.on = true; try { m.setPointerCapture(e.pointerId); } catch (er) { /* gone */ } }
      if (sw.on) { m.style.transition = "none"; put(sw.dx); }
    });
    const up = (e) => {
      if (!sw || e.pointerId !== sw.id) return;
      const g = sw; sw = null;
      if (!g.on) return;
      // A finger held still before letting go has no velocity left to hand over.
      const v = performance.now() - g.pt > 80 ? 0 : g.v;
      let d = e.type === "pointercancel" ? 0 : swipe(g.dx, performance.now() - g.t, m.clientWidth);
      if (d && to(J.at, d, J.list.length) == null) { result(d); d = 0; }    // the end of the list: it springs back
      if (RMq() || typeof springTo !== "function") { rest(); if (d) result(d); return; }
      m.style.transition = "none";
      if (!d) { stop = springTo(() => off, put, 0, v, rest, 0.36, 1); return; }
      const W = m.clientWidth + 24;
      const out = () => { if (!stop) return; stop(); rest(); result(d); };
      // Aimed past the edge so it leaves at speed; it hands over as soon as it is out of sight.
      stop = springTo(() => off, (x) => { put(x); if (Math.abs(x) >= W) out(); }, -d * W * 1.5, v, out, 0.3, 1);
    };
    m.addEventListener("pointerup", up); m.addEventListener("pointercancel", up);
  }

  // The results screen keeps the list it shows in jdRows (v2.js libKit): 판정 opens there at the
  // first result that waits on an answer, and an item opens on it when it is in it.
  const ids = () => (typeof jdRows !== "undefined" ? jdRows : []).map(iid);
  function fromItem(k) {
    if (ids().includes(k)) return open(ids(), k, "item");
    const L = D.items.filter((x) => !x.finished).sort(byAt).map(iid);
    open(L.includes(k) ? L : [k], k, "item");
  }
  function fromLib() {
    const L = typeof jdRows !== "undefined" ? jdRows : [];
    const x = L.find((y) => stateOf(y.status) === "wait" && !y.finished) || L[0];
    if (x) open(L, iid(x), "lib");
  }
  document.addEventListener("click", (e) => {
    if (e.target.closest?.("#view [data-judge]")) { e.stopPropagation(); return fromLib(); }
    const b = e.target.closest?.("[data-judge-item]"); if (!b) return;
    const k = b.closest("[data-iid]")?.dataset.iid || (detail?.[0] === "item" ? detail[1] : null);
    if (k) { e.stopPropagation(); fromItem(k); }
  }, true);
  window.Judge = {...pure, open, close, fromItem, fromLib, on: () => !!J};
})();
