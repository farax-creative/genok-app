// 수정 요청 추적판 (ledger) — Genok extension screen, home card and per-item block.
//
// It surfaces directives the core silently closes: an approval or a later comment marks
// unverified fixes done, any new version counts as proof, auto-archive hides open ones. This
// view reads the same data and shows what got lost, with the evidence behind each verdict.
//
// Attaches through the extension hooks the app's loader consumes (each guarded with `|| []`):
//   window.LOOP_ITEM_VIEW.push(fn(box, item, d))   — the per-item block (feature 2)
//   window.LOOP_TABS.push({id,label,icon,draw})     — the "추적" screen (feature 3)
//   window.LOOP_HOME_CARDS.push({id,title,draw})    — the "빠진 수정 요청" home card (feature 3)
//
// Writes: 맞아/아직 on a claimed fix use the app's EXISTING verify API (POST /api/directive),
// the exact request the directive panel sends. Re-opening an auto-passed directive uses
// POST /api/ledger/reopen, which calls the core's own 아직 path — no new write semantics.

(function () {
  "use strict";
  // Inline copy in two languages (these extension files carry their own text, not i18n keys).
  const L = (ko, en) => (window.I18N_LANG === "en" ? en : ko);
  if (window.__ledgerExt) return;
  window.__ledgerExt = true;

  // App globals, with safe fallbacks so a stray load order in a test harness cannot throw.
  const _get = typeof get === "function" ? get : (p) => fetch(p, { cache: "no-store" }).then((r) => r.json());
  const _post = typeof post === "function" ? post : (p, b) => fetch(p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) }).then((r) => r.json().then((j) => { if (!r.ok) throw Object.assign(new Error(j.error || L("오류", "Error")), { status: r.status, body: j }); return j; }));
  const _esc = typeof esc === "function" ? esc : (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const _ic = typeof ic === "function" ? ic : () => "";
  const _toast = typeof toast === "function" ? toast : (m) => console.log(m);

  // ---- relative time (self-contained; the contract does not expose the app's `ago`) --------
  function ago(iso) {
    if (!iso) return "";
    const t = +(window.hostDate ? window.hostDate(iso) : Date.parse(iso));
    if (isNaN(t)) return "";
    const s = (Date.now() - t) / 1000;
    if (s < 60) return L("방금", "Just now");
    if (s < 3600) return L(`${Math.floor(s / 60)}분 전`, `${Math.floor(s / 60)}m ago`);
    if (s < 86400) return L(`${Math.floor(s / 3600)}시간 전`, `${Math.floor(s / 3600)}h ago`);
    if (s < 7 * 86400) return L(`${Math.floor(s / 86400)}일 전`, `${Math.floor(s / 86400)}d ago`);
    const d = new Date(t);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }

  // ---- status vocabulary -------------------------------------------------------------------
  // Worst (never reached the session) to best (a person said 맞아).
  const ST = {
    undelivered: { get label() { return L("미전달", "Not sent"); }, cls: "bad", get hint() { return L("대화에 전달된 적이 없어요", "Never reached the chat"); } },
    await_fix: { get label() { return L("수정 대기", "Awaiting fix"); }, cls: "warn", get hint() { return L("전달됐지만 고쳤다는 보고가 아직 없어요", "Sent, but not reported fixed yet"); } },
    await_verify: { get label() { return L("확인 대기", "To confirm"); }, cls: "wait", get hint() { return L("고쳤다고 했지만 아직 직접 확인하지 않았어요", "Marked fixed, not confirmed by you yet"); } },
    redo: { get label() { return L("다시 요청", "Redo"); }, cls: "redo", get hint() { return L("[다시]로 돌려보냈어요 · 새 수정 대기", "Sent back with [Redo] · awaiting a new fix"); } },
    confirmed: { get label() { return L("확인됨", "Confirmed"); }, cls: "ok", get hint() { return L("직접 [확인]을 눌렀어요", "You pressed [OK]"); } },
  };
  const ORDER = ["undelivered", "await_fix", "await_verify", "redo"];

  // ---- CSS: namespaced under .lz, from the app's own tokens (with fallbacks) ----------------
  const STYLE = `
.lz{--l-ok:#1fc67a;--l-warn:#fe9800;--l-wait:#ffc342;--l-bad:#f04452;--l-redo:#9085e9;
  --l-card:var(--card,#16171a);--l-card2:var(--card-hi,#1d1e22);--l-btn:var(--btn,#222327);
  --l-btn2:var(--btn-hi,#2a2b30);--l-line:var(--line,rgba(255,255,255,.08));
  --l-t1:var(--t1,#efe9dc);--l-t2:var(--t2,#b0b1b8);--l-t3:var(--t3,#8c8d95);--l-t4:var(--t4,#63646b);
  --l-blue:var(--blue,#5e6ad2);--l-r:var(--r-card,12px);--l-spring:cubic-bezier(.34,1.4,.64,1);
  color:var(--l-t1);font-variant-numeric:tabular-nums;}
.lz *{box-sizing:border-box;}
.lz-card{background:var(--l-card);border:1px solid var(--l-line);border-radius:var(--l-r);
  margin-bottom:16px;overflow:hidden;animation:lz-in .16s ease-out both;}
@keyframes lz-in{from{opacity:0;transform:translateY(4px);}}
.lz-ch{display:flex;align-items:center;gap:8px;padding:16px 16px;flex-wrap:wrap;row-gap:8px;}
.lz-ch h2{margin:0;font-size:16px;font-weight:700;letter-spacing:-.02em;}
.lz-ch .sp{flex:1;}
.lz-fold>summary{flex-wrap:nowrap;min-height:52px;padding:0 16px;cursor:pointer;list-style:none;}
.lz-fold>summary::-webkit-details-marker{display:none;}
.lz-fold .lz-left{font-size:14px;color:var(--l-t3);white-space:nowrap;}
.lz-fold .lz-left .k{color:var(--l-bad);font-weight:700;}
.lz-fold>summary .chev{flex:none;display:grid;color:var(--l-t4);transform:rotate(90deg);transition:transform .2s var(--l-spring);}
.lz-fold[open]>summary .chev{transform:rotate(-90deg);}
@media (prefers-reduced-motion:reduce){.lz-fold>summary .chev{transition:none;}}
.lz-sum{display:flex;align-items:baseline;gap:6px 16px;flex-wrap:wrap;padding:0 16px 12px;
  font-size:14px;color:var(--l-t2);}
.lz-sum b{color:var(--l-t1);font-weight:700;}
.lz-sum .k{color:var(--l-bad);font-weight:700;}
.lz-top{padding-top:16px;}
.lz-split{display:flex;flex-wrap:wrap;gap:6px;padding:0 16px 12px;}
.lz-chip{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 12px;border-radius:99px;
  font-size:12px;font-weight:600;background:var(--l-btn);color:var(--l-t2);cursor:default;}
.lz-chip .dot{width:8px;height:8px;min-height:0;padding:0;border-radius:50%;flex:none;}
.lz-chip.on{background:var(--l-btn2);}
.dot.bad,.tg.bad{background:var(--l-bad);}.dot.warn,.tg.warn{background:var(--l-warn);}
.dot.wait,.tg.wait{background:var(--l-wait);}.dot.redo,.tg.redo{background:var(--l-redo);}
.dot.ok,.tg.ok{background:var(--l-ok);}
.lz-list{border-top:1px solid var(--l-line);}
.lz-d{border-bottom:1px solid var(--l-line);padding:12px 16px;animation:lz-in .16s ease-out both;}
.lz-d:last-child{border-bottom:0;}
.lz-dh{display:flex;align-items:flex-start;gap:8px;}
.lz-dh .tx{flex:1;min-width:0;}
.lz-dt{font-size:14px;line-height:1.45;color:var(--l-t1);word-break:break-word;}
.lz-dm{font-size:12px;color:var(--l-t3);margin-top:4px;}
.lz-tag{display:inline-flex;align-items:center;gap:6px;height:24px;padding:0 8px;border-radius:8px;
  font-size:12px;font-weight:700;background:var(--l-btn);color:var(--l-t1);white-space:nowrap;flex:none;}
.lz-tag .tg{width:8px;height:8px;min-height:0;max-width:none;padding:0;border-radius:50%;flex:none;}
.lz-auto{display:flex;align-items:center;gap:8px;margin-top:8px;padding:8px 12px;border-radius:8px;
  background:rgba(254,152,0,.07);color:var(--l-t2);font-size:12px;line-height:1.4;}
.lz-auto b{color:var(--l-warn);font-weight:700;}
.lz-ev{margin-top:4px;font-size:12px;color:var(--l-t3);word-break:break-word;}
.lz-ev .warnx{color:var(--l-warn);font-weight:600;}
.lz-ver{font:inherit;background:none;border:0;font-weight:600;color:var(--l-t1);padding:6px 2px;margin:-6px -2px;cursor:pointer;text-decoration:underline;text-underline-offset:3px;text-decoration-color:var(--l-line);}
.lz-ver:hover{text-decoration-color:currentColor;}
.lz-btns{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;}
.lz-btn{height:34px;padding:0 16px;border-radius:8px;border:1px solid var(--l-line);
  background:var(--l-btn);color:var(--l-t1);font-size:13px;font-weight:600;cursor:pointer;
  transition:transform .12s var(--l-spring),background .15s ease;}
.lz-btn:hover{background:var(--l-btn2);}
.lz-btn:active{transform:scale(.96);}
.lz-btn.fill{background:var(--l-ok);border-color:transparent;color:#03210f;}
.lz-btn.redo{background:transparent;color:var(--l-redo);border-color:var(--l-redo);}
.lz-btn:disabled{opacity:.5;cursor:default;}
.lz-item{border-bottom:1px solid var(--l-line);}
.lz-item:last-child{border-bottom:0;}
.lz-ihead{display:flex;align-items:center;gap:8px;padding:12px 16px;cursor:pointer;
  background:none;border:0;width:100%;text-align:left;color:inherit;}
.lz-ihead:hover{background:var(--l-card2);}
.lz-ihead .tx{flex:1;min-width:0;}
.lz-ihead .t{font-size:14.5px;font-weight:600;color:var(--l-t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.lz-ihead .s{font-size:12px;color:var(--l-t3);margin-top:2px;display:flex;flex-wrap:wrap;gap:2px 8px;}
.lz-ihead .kbig{font-size:15px;font-weight:700;color:var(--l-bad);flex:none;}
.lz-ihead .chev{flex:none;color:var(--l-t4);transition:transform .2s var(--l-spring);}
.lz-item.open .chev{transform:rotate(90deg);}
.lz-badge{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:600;
  padding:1px 8px;border-radius:6px;background:var(--l-btn);color:var(--l-t2);}
.lz-badge.arc{color:var(--l-t4);}
.lz-filters{display:flex;gap:8px;flex-wrap:wrap;padding:0 16px 12px;}
.lz-filters gk-select{flex:0 1 220px;}
.lz-empty{padding:24px 16px;color:var(--l-t3);font-size:13px;line-height:1.5;text-align:center;}
.lz-home{padding:2px 0;}
.lz-home .big{display:flex;align-items:baseline;gap:8px;padding:2px 0 6px;}
.lz-home .n{font-size:42px;font-weight:700;letter-spacing:-.03em;line-height:.95;}
.lz-home .n.zero{color:var(--l-ok);}
.lz-home .n.some{color:var(--l-bad);}
.lz-home .u{font-size:16px;font-weight:600;color:var(--l-t3);}
.lz-home .sub{font-size:12px;color:var(--l-t3);margin-top:2px;}
.lz-home .mini{list-style:none;margin:12px 0 0;padding:0;display:flex;flex-direction:column;gap:8px;}
.lz-home .mini li{display:flex;align-items:center;gap:8px;font-size:12px;}
.lz-home .mini .mt{flex:1;color:var(--l-t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.lz-home .mini .mk{color:var(--l-bad);font-weight:700;flex:none;}
@media (max-width:420px){.lz-home .n{font-size:36px;}}
@media (prefers-reduced-motion:reduce){
  .lz-card,.lz-d{animation:lz-fade .3s ease both;}
  .lz-item.open .chev{transition:none;}
  @keyframes lz-fade{from{opacity:0;}}
}`;

  // A drawing rides on a comment as a "📎 <file path>" line; that path is for the session, not the reader.
  function _noClip(t) { return String(t || "").split("\n").filter((l) => !l.startsWith("📎 ")).join("\n").trim(); }
  function injectCss() {
    if (document.getElementById("lz-style")) return;
    const s = document.createElement("style");
    s.id = "lz-style"; s.textContent = STYLE;
    document.head.appendChild(s);
  }

  // ---- shared rendering --------------------------------------------------------------------

  function evidence(d, ctx) {
    // One line, in the order it happened. A session is named by an id nobody reads: the line
    // says when, and flags a mismatch, not which id.
    const rows = [];
    if (ago(d.at)) rows.push(L(`${ago(d.at)} 요청`, `Asked ${ago(d.at)}`));
    if (!d.delivered_at) rows.push(L("아직 전달 안 됨", "Not sent yet"));
    if (d.claimed_version) {
      const mism = d.session_mismatch ? ` <span class="warnx">(${L("다른 대화가 처리", "handled by another chat")} ⚠)</span>` : "";
      // The version named is the one to check, so it opens that version (not the latest).
      const ver = ctx ? `<button class="lz-ver" data-ver="${_esc(d.claimed_version)}">${_esc(d.claimed_version)}</button>` : _esc(d.claimed_version);
      rows.push(L(`${ver}에서 고쳤다고 함`, `Reported fixed in ${ver}`) + mism);
    }
    if (d.verdict === "ok") rows.push(L("직접 확인함", "Confirmed by you"));
    else if (d.verdict === "redo") rows.push(`${L("다시 요청함", "Sent back")}${d.verdict_at ? ` ${ago(d.verdict_at)}` : ""}`);
    // Prior rounds kept as evidence by the core's history[] (each 아직 pushes one). Shown so a
    // reopened ask reads as "돌아온 것", not a fresh miss.
    const hist = d.history || [];
    if (hist.length) {
      const last = hist[hist.length - 1];
      rows.push(L(`${hist.length}번 돌려보냄`, `Sent back ${hist.length}×`) + (last && last.fixed_in ? L(` (마지막 ${_esc(last.fixed_in)})`, ` (last ${_esc(last.fixed_in)})`) : ""));
    }
    return `<div class="lz-ev">${rows.join(" · ")}</div>`;
  }

  // One directive row with its status tag, auto-pass flag, evidence and action buttons.
  // `ctx` carries {p, i, latest, redraw} so the buttons can call the right API and refresh.
  function directiveRow(d, ctx) {
    const st = ST[d.status] || ST.undelivered;
    const auto = d.auto_passed
      ? `<div class="lz-auto">${_ic("warn")}<span><b>${L("확인 없이 자동 통과됨", "Passed without your check")}</b></span></div>` : "";
    let btns = "";
    if (d.status === "await_verify") {
      // The verdict is on this row's claim: its version (fixed_in) and the directive's rev ride along.
      const claim = `data-v="${_esc(d.claimed_version || "")}" data-rev="${d.rev == null ? "" : _esc(String(d.rev))}"`;
      btns = `<div class="lz-btns"><button class="lz-btn fill" data-yes="${_esc(d.id)}" ${claim}>${L("확인", "OK")}</button><button class="lz-btn" data-no="${_esc(d.id)}" ${claim}>${L("다시", "Redo")}</button></div>`;
    } else if (d.auto_passed) {
      btns = `<div class="lz-btns"><button class="lz-btn redo" data-reopen="${_esc(d.id)}">${L("다시 요청", "Request again")}</button></div>`;
    }
    return `<div class="lz-d" data-drow="${_esc(d.id)}">
      <div class="lz-dh"><span class="tx"><div class="lz-dt">${_esc(_noClip(d.text))}</div>
        ${d.cycle > 1 ? `<div class="lz-dm">${L(`${d.cycle}번째 요청`, `request no. ${d.cycle}`)}</div>` : ""}</span>
        <span class="lz-tag" title="${_esc(st.hint)}"><span class="tg ${st.cls}"></span>${st.label}</span></div>
      ${auto}${evidence(d, ctx)}${btns}</div>`;
  }

  // Wire 맞아/아직 (existing /api/directive) and 다시 요청 (/api/ledger/reopen) inside `root`.
  function wireRows(root, ctx) {
    const run = async (btn, fn) => {
      btn.disabled = true;
      try { await fn(); ctx.redraw(); }
      catch (e) {
        // 409: the directive moved on (a newer claim, another verdict) while this was on screen.
        if (e && e.status === 409) { _toast(L("그 사이 바뀌었어요 · 다시 불러와요", "It changed in the meantime · reloading")); ctx.redraw(); return; }
        _toast((e && e.message) || L("오류", "Error")); btn.disabled = false;
      }
    };
    const verdict = (b, id, v) => {
      const body = { p: ctx.p, i: ctx.i, id, v: b.dataset.v || ctx.latest, verdict: v };
      if (b.dataset.rev !== undefined && b.dataset.rev !== "") body.rev = Number(b.dataset.rev);
      return _post("/api/directive", body);
    };
    root.querySelectorAll("[data-ver]").forEach((b) => b.onclick = () => {
      const id = ctx.p + "/" + ctx.i, h = "#item/" + id;
      if (typeof verPick !== "undefined") { if (b.dataset.ver === ctx.latest) delete verPick[id]; else verPick[id] = b.dataset.ver; }
      if (location.hash === h) dispatchEvent(new HashChangeEvent("hashchange")); else location.hash = h;
    });
    root.querySelectorAll("[data-yes]").forEach((b) => b.onclick = () => run(b, async () => {
      await verdict(b, b.dataset.yes, "ok");
      _toast(L("확인됨으로 표시했어요", "Marked confirmed"));
    }));
    root.querySelectorAll("[data-no]").forEach((b) => b.onclick = () => run(b, async () => {
      await verdict(b, b.dataset.no, "again");
      _toast(L("다시 요청으로 돌려보냈어요", "Sent back to redo"));
    }));
    root.querySelectorAll("[data-reopen]").forEach((b) => b.onclick = () => run(b, async () => {
      await _post("/api/ledger/reopen", { p: ctx.p, i: ctx.i, id: b.dataset.reopen });
      _toast(L("자동 통과를 되돌려 다시 요청했어요", "Automatic pass undone · requested again"));
    }));
  }

  function summaryLine(s) {
    const parts = ORDER.filter((k) => s.buckets[k]).map((k) =>
      `<span class="lz-chip"><span class="dot ${ST[k].cls}"></span>${ST[k].label} ${s.buckets[k]}</span>`);
    return `<div class="lz-sum">${L(`요청 <b>${s.n}</b>개 중 확인 <b>${s.confirmed}</b>개 · 남은 것 <span class="k">${s.missing}</span>개`, `<b>${s.confirmed}</b> of <b>${s.n}</b> requests confirmed · <span class="k">${s.missing}</span> left`)}</div>
      ${parts.length > 1 ? `<div class="lz-split">${parts.join("")}</div>` : ""}`;
  }

  // ---- per-item block (feature 2) ----------------------------------------------------------
  function itemBlock(box, item, d) {
    injectCss();
    const wrap = document.createElement("div");
    wrap.className = "lz";
    // With the page's own fold of records there, the block is one of its lines; else it stands
    // before the shortcut bar (which stays last, or it stops sticking to the foot).
    const fold = box.querySelector("#ixtra");
    if (fold) fold.appendChild(wrap); else box.insertBefore(wrap, box.querySelector(":scope > .kbar"));
    const p = item.p, i = item.i;
    let open = false;

    const redraw = () => _get(`/api/ledger/item?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}`)
      .then((r) => render(r)).catch(() => { wrap.innerHTML = ""; });

    function render(r) {
      const dirs = r.directives || [], s = r.summary;
      if (!dirs.length) { wrap.innerHTML = ""; return; }   // no directives: show nothing
      const missing = dirs.filter((x) => x.status !== "confirmed");
      const done = dirs.filter((x) => x.status === "confirmed");
      const ctx = { p, i, latest: r.latest, redraw };
      // Shut by default: the page already lists the open requests above, so this block is one line
      // (how many are left) until it is opened. It stays as it was left across its own redraws.
      wrap.innerHTML = `<details class="lz-card lz-fold"${open ? " open" : ""}>
        <summary class="lz-ch"><h2>${L("요청 추적", "Request tracking")}</h2><span class="lz-left">${missing.length ? L(`남은 것 <span class="k">${missing.length}</span>개`, `<span class="k">${missing.length}</span> left`) : L("전부 확인", "All confirmed")}</span><span class="sp"></span><span class="chev">${_ic("chev")}</span></summary>
        ${summaryLine(s)}
        ${missing.length ? `<div class="lz-list">${missing.map((x) => directiveRow(x, ctx)).join("")}</div>` : `<div class="lz-empty">${L("남은 요청이 없어요 · 전부 확인했어요", "No requests left · all confirmed")}</div>`}
        ${done.length ? `<details><summary style="padding:12px 16px;cursor:pointer;color:var(--l-t3);font-size:13px">${L(`확인됨 ${done.length}개`, `Confirmed ${done.length}`)}</summary><div class="lz-list">${done.map((x) => directiveRow(x, ctx)).join("")}</div></details>` : ""}
      </details>`;
      wrap.firstElementChild.addEventListener("toggle", (e) => { if (e.target === wrap.firstElementChild) open = e.target.open; });
      wireRows(wrap, ctx);
    }
    redraw();
  }

  // ---- "추적" screen (feature 3) -----------------------------------------------------------
  let _data = null, _fProj = "", _open = {};

  function drawTab(el) {
    injectCss();
    el.innerHTML = `<div class="lz">${loadingHtml("", {fill: true})}</div>`;
    // The area is shared with every other screen: an answer that arrives after a move away must not paint over it.
    const mine = el.firstElementChild, here = () => el.firstElementChild === mine;
    _get("/api/ledger").then((r) => { if (!here()) return; _data = r; renderTab(el); })
      .catch((e) => { if (!here()) return; el.innerHTML = `<div class="lz"><div class="lz-card"><div class="lz-empty">${_esc((e && e.message) || L("불러오지 못했어요", "Could not load"))}</div></div></div>`; });
  }

  function matchFilter(it) {
    return !_fProj || it.project === _fProj;
  }

  function renderTab(el) {
    const r = _data;
    const items = (r.items || []).filter(matchFilter);
    const opt = (v, cur, label) => `<option value="${_esc(v)}"${v === cur ? " selected" : ""}>${_esc(label)}</option>`;
    const filters = `<div class="lz-filters">
      <gk-select data-fproj aria-label="${_esc(tl("lib.1", {u: unitWord()}))}"><option value="">${tl("lib.1", {u: unitWord()})} (${r.projects.length})</option>${r.projects.map((p) => opt(p, _fProj, p)).join("")}</gk-select>
    </div>`;
    const ctxOf = (it) => ({ p: it.project, i: it.item, latest: it.latest, redraw: () => drawTab(el) });
    const itemHtml = (it) => {
      const open = _open[it.project + "/" + it.item];
      const split = ORDER.filter((k) => it.buckets[k]).map((k) => `${ST[k].label} ${it.buckets[k]}`).join(" · ");
      return `<div class="lz-item${open ? " open" : ""}" data-key="${_esc(it.project + "/" + it.item)}">
        <button class="lz-ihead" data-toggle="${_esc(it.project + "/" + it.item)}">
          <span class="kbig">${it.missing}</span>
          <span class="tx"><div class="t">${_esc(it.title)}</div>
            <div class="s"><span>${_esc(typeof pname === "function" ? pname(it.project) : it.project)}</span>${it.archived ? `<span class="lz-badge arc">${L("정리됨", "Archived")}</span>` : ""}${it.hidden ? `<span class="lz-badge arc">${L("대화", "Chat")}</span>` : ""}<span>${split}</span>${it.oldest_unresolved ? `<span>${L("가장 오래됨", "Oldest")} ${ago(it.oldest_unresolved)}</span>` : ""}</div></span>
          <span class="chev">${_ic("chev")}</span></button>
        ${open ? `<div class="lz-list">${(it.directives || []).filter((x) => x.status !== "confirmed").map((x) => directiveRow(x, ctxOf(it))).join("")}</div>` : ""}
      </div>`;
    };
    // Nothing left anywhere: one line, no counts of zero and no filters over an empty list.
    if (!(r.items || []).length) { el.innerHTML = `<div class="lz"><div class="lz-card"><div class="lz-empty">${L("남은 요청이 없어요", "No requests left")}</div></div></div>`; return; }
    el.innerHTML = `<div class="lz">
      <div class="lz-card">
        <div class="lz-sum lz-top">${L(`결과물 <b>${r.totals.items}</b>개 · 남은 것 <span class="k">${r.totals.missing}</span>개${r.totals.auto_passed ? ` · 자동 통과 <b>${r.totals.auto_passed}</b>개` : ""}`, `<b>${r.totals.items}</b> results · <span class="k">${r.totals.missing}</span> left${r.totals.auto_passed ? ` · <b>${r.totals.auto_passed}</b> passed automatically` : ""}`)}</div>
        ${filters}
      </div>
      <div class="lz-card">
        ${items.length ? `<div class="lz-list">${items.map(itemHtml).join("")}</div>` : `<div class="lz-empty">${L("이 조건에 남은 요청이 없어요", "No requests left for this filter")}</div>`}
      </div>
    </div>`;
    el.querySelector("[data-fproj]").onchange = (e) => { _fProj = e.target.value; renderTab(el); };
    el.querySelectorAll("[data-toggle]").forEach((b) => b.onclick = () => {
      const k = b.dataset.toggle; _open[k] = !_open[k]; renderTab(el);
    });
    items.forEach((it) => {
      const node = el.querySelector(`.lz-item[data-key="${CSS.escape(it.project + "/" + it.item)}"]`);
      if (node && _open[it.project + "/" + it.item]) wireRows(node, ctxOf(it));
    });
  }

  // ---- home card (feature 3) ---------------------------------------------------------------
  // The card needs totals and three lines, so it asks for the summary (not every directive), and
  // a home drawn twice in a row during boot shares one request instead of sending two.
  let _homeReq = null, _homeAt = 0;
  function homeSummary() {
    if (!_homeReq || Date.now() - _homeAt > 5000) {
      _homeAt = Date.now();
      _homeReq = _get("/api/ledger?summary=1");
      _homeReq.catch(() => { _homeReq = null; });
    }
    return _homeReq;
  }
  function drawHome(el) {
    injectCss();
    el.innerHTML = `<div class="lz lz-home">${loadingHtml("", {quiet: true})}</div>`;
    homeSummary().then((r) => {
      const t = r.totals, top = (r.top || []).slice(0, 3);
      const zero = t.missing === 0;
      el.innerHTML = `<div class="lz lz-home">
        <div class="big"><span class="n ${zero ? "zero" : "some"}">${t.missing}</span><span class="u">${L("개", "")}</span></div>
        <div class="sub">${zero ? L("전부 확인했어요", "All confirmed") : L(`결과물 ${t.items}개에 확인 안 된 요청${t.auto_passed ? ` · 자동 통과 ${t.auto_passed}개` : ""}`, `unconfirmed requests on ${t.items} results${t.auto_passed ? ` · ${t.auto_passed} passed automatically` : ""}`)}</div>
        ${top.length ? `<ul class="mini">${top.map((it) => `<li><span class="mk">${it.missing}</span><span class="mt">${_esc(it.title)}</span><span style="color:var(--l-t4);font-size:11.5px">${ago(it.oldest_unresolved)}</span></li>`).join("")}</ul>` : ""}
      </div>`;
    }).catch(() => { el.innerHTML = ""; });
  }

  // ---- register through the app's extension hooks (contract) -------------------------------
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(itemBlock);
  (window.LOOP_TABS = window.LOOP_TABS || []).push({ id: "ledger", get label() { return typeof tl === "function" ? tl("tab.ledger") : "추적"; }, icon: "track", draw: drawTab });
  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({ id: "ledger", get title() { return L("남은 요청", "Open requests"); }, draw: drawHome });
})();
