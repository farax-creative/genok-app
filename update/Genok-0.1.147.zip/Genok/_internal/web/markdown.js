// Markdown documents pushed to the hub, shown as a readable page instead of raw text.
// A small subset - headings, paragraphs, lists, tables, code, quotes, rules, **bold**,
// `code`, http(s) links and pictures - built as DOM nodes, never innerHTML, so a pushed
// file cannot run script here. Plain script loaded before app.js; the parser exports for
// node tests. The session pane draws Claude's own messages through it too, which is why
// renderMarkdown takes a class: the same blocks, laid out for a page or for a bubble.

const GENOK_HOST = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(?=\/f\/)/;
const GENOK_PIC = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/f\/[^?#]+\.(png|jpe?g|gif|webp)$/i;

function inlineRuns(text) {
  const out = [];
  // A picture is a link with a bang in front, so it has to be tried first. Its address is
  // held to the two shapes a link already is: somewhere on the web, or a file on the hub.
  // A bare address is a link too (sessions paste them as is); a trailing stop or bracket stays text.
  const re = /!\[([^\]\n]*)\]\((https?:\/\/[^)\s]+|\/[mf]\/[^)\s]+)\)|\*\*([^*\n]+)\*\*|`([^`\n]+)`|\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)|(https?:\/\/[^\s<>"'`]*[^\s<>"'`.,;:!?)\]])/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ t: "text", v: text.slice(last, m.index) });
    // A file on this PC's Genok is asked for by path, so the same line draws on the phone too.
    if (m[2] != null) out.push({ t: "img", v: m[1], href: m[2].replace(GENOK_HOST, "") });
    else if (m[3] != null) out.push({ t: "b", v: m[3] });
    else if (m[4] != null) out.push({ t: "code", v: m[4] });
    else if (m[7] != null) out.push({ t: "link", v: m[7], href: m[7] });
    // A named link to a picture on this PC's Genok: other chats show the name, this one draws it.
    else if (GENOK_PIC.test(m[6])) out.push({ t: "img", v: m[5], href: m[6].replace(GENOK_HOST, "") });
    else out.push({ t: "link", v: m[5], href: m[6] });
    last = re.lastIndex;
  }
  if (last < text.length) out.push({ t: "text", v: text.slice(last) });
  return out;
}

const LIST_RE = /^\s*([-*+]|\d+[.)])\s+(.*)$/;
const listType = (marker) => (/\d/.test(marker) ? "ol" : "ul");

function parseMarkdown(src) {
  const lines = src.replace(/\r\n?/g, "\n").split("\n");
  const blocks = [];
  let para = [];
  const flush = () => { if (para.length) { blocks.push({ type: "p", text: para.join(" ") }); para = []; } };
  const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  for (let n = 0; n < lines.length; n++) {
    const l = lines[n];
    let m;
    if (/^```/.test(l.trim())) {
      flush();
      const code = [], lang = (/^```\s*([\w+#.-]+)/.exec(l.trim()) || [])[1] || "";
      while (++n < lines.length && !/^```/.test(lines[n].trim())) code.push(lines[n]);
      // open: the closing fence has not arrived yet (an answer still being written).
      blocks.push({ type: "code", text: code.join("\n"), lang, open: n >= lines.length });
    } else if (!l.trim()) {
      flush();
    } else if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) {
      flush();
      blocks.push({ type: "h", level: m[1].length, text: m[2].trim() });
    } else if (/^\s*([-*_])\s*(\1\s*){2,}$/.test(l)) {
      flush();
      blocks.push({ type: "hr" });
    } else if (/^\s*\|/.test(l) && /^\s*\|?\s*:?-{2,}/.test(lines[n + 1] || "")) {
      flush();
      const head = cells(l), rows = [];
      n += 1;
      while (/^\s*\|/.test(lines[n + 1] || "")) rows.push(cells(lines[++n]));
      blocks.push({ type: "table", head, rows });
    } else if ((m = /^\s*>\s?(.*)$/.exec(l))) {
      flush();
      const q = [m[1]];
      while ((m = /^\s*>\s?(.*)$/.exec(lines[n + 1] || ""))) { q.push(m[1]); n++; }
      blocks.push({ type: "quote", text: q.join(" ").trim() });
    } else if ((m = LIST_RE.exec(l))) {
      flush();
      const type = listType(m[1]), items = [m[2]];
      for (;;) {
        const next = lines[n + 1] || "";
        const nx = LIST_RE.exec(next);
        if (nx && listType(nx[1]) === type) { items.push(nx[2]); n++; }
        else if (next.trim() && /^\s{2,}\S/.test(next) && !nx) { items[items.length - 1] += ` ${next.trim()}`; n++; }
        else break;
      }
      blocks.push({ type, items });
    } else {
      para.push(l.trim());
    }
  }
  flush();
  return blocks;
}

function renderMarkdown(text, cls) {
  const runs = (s) => inlineRuns(s).map((r) => (r.t === "b" ? h("strong", {}, r.v)
    : r.t === "code" ? h("code", {}, r.v)
    : r.t === "img" ? h("img", { src: r.href, alt: r.v, loading: "lazy" })
    : r.t === "link" ? h("a", { href: r.href, target: "_blank", rel: "noopener" }, r.v)
    : r.v));
  return h("article", { class: cls || "doc" }, parseMarkdown(text).map((b) => {
    if (b.type === "h") return h(`h${Math.min(b.level + 1, 4)}`, {}, runs(b.text));   // the page title sits above
    if (b.type === "p") return h("p", {}, runs(b.text));
    if (b.type === "ul" || b.type === "ol") return h(b.type, {}, b.items.map((it) => h("li", {}, runs(it))));
    if (b.type === "table") {
      return h("div", { class: "doc-table" }, h("table", {},
        h("thead", {}, h("tr", {}, b.head.map((c) => h("th", {}, runs(c))))),
        h("tbody", {}, b.rows.map((r) => h("tr", {}, r.map((c) => h("td", {}, runs(c))))))));
    }
    if (b.type === "code") {
      const pre = h("pre", {}, h("code", { class: b.lang && `language-${b.lang}` }, b.text));
      // A finished mermaid block is marked for mermaid-view.js, which draws it in place.
      return b.lang === "mermaid" && !b.open ? h("div", { class: "mmd" }, pre) : pre;
    }
    if (b.type === "quote") return h("blockquote", {}, runs(b.text));
    return h("hr");
  }));
}

// Whether a short note is written in markdown at all: plain comments stay plain text, so a
// stray "-" or "#1" in a sentence is not turned into a list or a heading.
function looksMarkdown(text) {
  const s = String(text == null ? "" : text);
  return /\*\*[^*\n]+\*\*|`[^`\n]+`|\[[^\]\n]+\]\(https?:\/\/|https?:\/\/\S/.test(s)
    || /^(#{1,6}\s|```|>\s|\|.*\|\s*$)/m.test(s)
    || (s.match(/^\s*(?:[-*+]|\d+[.)])\s+\S/gm) || []).length >= 2;
}

// The Genok results a message links to: http://localhost:8777/i/<project>/<item>[/<version>], the
// tailnet form of the same, or a bare /i/... path. At most `max`, each result once, in order.
const GENOK_ITEM = /(?:^|[\s(\["'])(?:https?:\/\/(?:localhost|127\.0\.0\.1|desktop-calars\.tail73335e\.ts\.net)(?::\d+)?)?\/i\/([^\/\s?#<>"'`)\]]+)\/([^\/\s?#<>"'`)\]]+)(?:\/([^\/\s?#<>"'`)\]]+))?/g;
function genokLinks(text, max = 3) {
  const out = [], seen = new Set(), un = (s) => { try { return decodeURIComponent(s); } catch (e) { return s; } };
  for (const m of String(text == null ? "" : text).matchAll(GENOK_ITEM)) {
    const end = (x) => x.replace(/[.,;:!?]+$/, ""), l = { project: un(m[1]), item: un(m[3] ? m[2] : end(m[2])), v: m[3] ? un(end(m[3])) : "" }, k = `${l.project}/${l.item}/${l.v}`;
    if (seen.has(k)) continue;
    seen.add(k); out.push(l);
    if (out.length >= max) break;
  }
  return out;
}

if (typeof module !== "undefined") module.exports = { parseMarkdown, inlineRuns, looksMarkdown, genokLinks };
