/* The notice card window (noticewin.py): a result just landed. Newest card on top, the newest one in
   full (picture, 승인, 피드백) and older ones folded to a line. A press on the picture enlarges it in
   place. Cards go away after a while unless the pointer is over them or an answer is being typed.

   The page paints only its cards; it tells the app which boxes are visible (api.layout) and the app
   cuts the window to them. Cards come in from the right edge and leave the same way on a spring
   (interruptible, velocity kept); with reduced motion they only fade. */
(function () {
  "use strict";
  const PAD = 12, SHOW = 3, LIFE = 10000, TICK = 200, RADIUS = 14;
  const SPRING = {k: 260, c: 30};                              // stiffness, damping: a touch under critical
  const FAR = 460;                                             // off the right edge (px)
  const RM = matchMedia("(prefers-reduced-motion: reduce)");
  const tl = (key, vars) => String(window.I18N?.[key] ?? window.I18N_ALL?.ko?.[key] ?? key).replace(/\{(\w+)\}/g, (m, k) => (vars && k in vars ? vars[k] : m));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
  const enc = encodeURIComponent;
  const root = document.getElementById("nt");
  const X = '<svg viewBox="0 0 12 12"><path d="M2 2l8 8M10 2l-8 8"/></svg>';
  const MARK = '<span class="nt-mark"><img src="/mark-sm.svg" alt=""></span>';

  const cards = [];                                            // newest first; local state rides on each card
  const nodes = new Map();                                     // id -> wrapper element
  let active = null, big = null, bigNode = null, moving = 0, lastTick = performance.now();

  async function call(path, body) {
    const r = await fetch(path, body === undefined ? undefined : {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || r.statusText);
    return d;
  }

  // ---------------------------------------------------------------- springs
  // Moves `el` to translate(tx, ty) from wherever it is, with the speed it has. Asked again while it is
  // moving, it only changes its target, so a card can be grabbed back mid-flight.
  function spring(el, tx, ty, done) {
    const s = el._s || (el._s = {x: 0, y: 0, vx: 0, vy: 0, run: false});
    s.tx = tx; s.ty = ty; s.done = done;
    if (RM.matches) { s.x = tx; s.y = ty; s.vx = s.vy = 0; el.style.transform = ""; if (done) done(); return; }
    if (s.run) return;
    s.run = true; moving++;
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      for (const a of ["x", "y"]) {
        s["v" + a] += (-SPRING.k * (s[a] - s["t" + a]) - SPRING.c * s["v" + a]) * dt;
        s[a] += s["v" + a] * dt;
      }
      const rest = Math.abs(s.x - s.tx) < .3 && Math.abs(s.y - s.ty) < .3 && Math.abs(s.vx) < 4 && Math.abs(s.vy) < 4;
      if (rest) { s.x = s.tx; s.y = s.ty; s.vx = s.vy = 0; s.run = false; moving--; }
      el.style.transform = rest && !s.tx && !s.ty ? "" : `translate(${s.x.toFixed(2)}px,${s.y.toFixed(2)}px)`;
      report();
      if (!rest) requestAnimationFrame(step); else if (s.done) s.done();
    };
    requestAnimationFrame(step);
  }

  // ---------------------------------------------------------------- the window's cut
  let queued = false;
  function report() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      const api = window.pywebview && window.pywebview.api;
      if (!api || !api.layout) return;
      const rr = root.getBoundingClientRect();
      let rects = [...root.children].filter((n) => n.offsetHeight)
        .map((n) => ({x: rr.left + n.offsetLeft, y: rr.top + n.offsetTop, w: n.offsetWidth, h: n.offsetHeight, r: RADIUS, s: PAD}));
      if (moving && rects.length) {                            // something is in flight: let the stack's whole room through
        const l = Math.min(...rects.map((q) => q.x)), t = Math.max(0, Math.min(...rects.map((q) => q.y)) - 260);
        const b = Math.max(...rects.map((q) => q.y + q.h));
        rects = [{x: l, y: t, w: innerWidth - l, h: b - t, r: RADIUS, s: PAD}];
      }
      api.layout({rects, dpr: devicePixelRatio, vw: innerWidth, vh: innerHeight});
    });
  }
  addEventListener("pywebviewready", report);
  addEventListener("resize", report);

  // ---------------------------------------------------------------- drawing
  function ago(c) {
    const m = Math.max(0, Math.floor((Date.now() - Date.parse(c.at)) / 60000));
    return m < 1 ? tl("nt.now") : m < 60 ? tl("nt.min", {n: m}) : tl("nt.hour", {n: Math.floor(m / 60)});
  }
  const close = () => `<button class="nt-x" data-act="x" aria-label="${esc(tl("nt.close"))}">${X}</button>`;
  const full = (c) => `<article class="nt-card">
    <div class="nt-head">${MARK}<span class="nt-proj"><b>${esc(c.p)}</b> · ${esc(c.v)}</span><span class="nt-at">${esc(ago(c))}</span>${close()}</div>
    <div class="nt-title" title="${esc(c.title)}">${esc(c.title)}</div>${c.note ? `<div class="nt-note">${esc(c.note)}</div>` : ""}
    ${c.thumb ? `<button class="nt-img" data-act="zoom" aria-label="${esc(tl("nt.zoom"))}"><img src="${esc(c.thumb)}" alt=""></button>` : ""}
    <div class="nt-acts">${VERDICTS.map((s, n) => `<button class="nt-b nt-v" data-act="v" data-v="${s}"><span>${esc(LABEL[s]())}</span><kbd>${n + 1}</kbd></button>`).join("")}</div>
    <div class="nt-fb"><input class="nt-in" maxlength="300" placeholder="${esc(tl("nt.ph"))}" aria-label="${esc(tl("nt.ph"))}"><button class="nt-b ok" data-act="send">${esc(tl("nt.send"))}</button></div>
    <div class="nt-done" hidden></div></article>`;
  const folded = (c) => `<div class="nt-row" role="button" tabindex="0" data-act="pick">${MARK}<span class="nt-proj"><b>${esc(c.p)}</b> · ${esc(c.title)}</span><span class="nt-at">${esc(ago(c))}</span>${close()}</div>`;
  const enlarged = (c) => `<article class="nt-big">
    <div class="nt-head">${MARK}<span class="nt-title">${esc(c.title)}</span><button class="nt-lnk" data-act="open">${esc(tl("nt.open"))}</button>${close()}</div>
    <button class="nt-full" data-act="unzoom" aria-label="${esc(tl("nt.back"))}"><img src="${esc(c.full || c.thumb)}" alt=""></button></article>`;

  const VERDICTS = ["approved", "changes", "hold"];
  const LABEL = {approved: () => tl("nt.approve"), changes: () => tl("nt.fix"), hold: () => tl("nt.hold")};
  const held = (c) => c.busy || c.typed || c.doneAt;
  function paint(c, w) {
    const mode = c.id === active ? "full" : "folded";
    if (w.dataset.mode === mode) return;
    w.dataset.mode = mode;
    w.innerHTML = mode === "full" ? full(c) : folded(c);
  }

  // Bring the DOM in line with `cards`. Cards already on show glide to their new place (FLIP on a spring);
  // a new card comes in from the right edge.
  function sync() {
    if (!cards.some((c) => c.id === active)) active = cards[0]?.id ?? null;
    const shown = cards.slice(0, SHOW), before = new Map();
    for (const [id, w] of nodes) before.set(id, w.getBoundingClientRect().top);
    for (const [id, w] of [...nodes]) if (!shown.some((c) => c.id === id) && !w.classList.contains("gone")) { w.remove(); nodes.delete(id); }
    const fresh = [];
    for (const c of shown) {
      let w = nodes.get(c.id);
      if (!w) { w = document.createElement("div"); w.className = "nt-w"; w.dataset.id = c.id; nodes.set(c.id, w); fresh.push(w); }
      paint(c, w);
      root.appendChild(w);                                     // appending in order re-sorts the stack
    }
    let more = root.querySelector(".nt-more");
    const rest = cards.length - SHOW;
    if (rest > 0) { if (!more) { more = document.createElement("div"); more.className = "nt-more"; } more.textContent = tl("nt.more", {n: rest}); root.appendChild(more); }
    else if (more) more.remove();
    if (big) { root.dataset.big = "1"; if (!bigNode) { bigNode = document.createElement("div"); bigNode.className = "nt-bigw"; root.appendChild(bigNode); } bigNode.innerHTML = enlarged(big); }
    else { delete root.dataset.big; if (bigNode) { bigNode.remove(); bigNode = null; } }
    const rr = root.getBoundingClientRect();
    for (const w of fresh) {
      const s = w._s || (w._s = {x: 0, y: 0, vx: 0, vy: 0});
      s.x = FAR; s.y = 0; s.vx = 0;
      if (RM.matches) w.style.opacity = 0; else w.style.transform = `translate(${FAR}px,0)`;
      requestAnimationFrame(() => { w.style.opacity = ""; spring(w, 0, 0); });
    }
    for (const [id, w] of nodes) {
      if (fresh.includes(w) || !before.has(id) || w.classList.contains("gone")) continue;
      const dy = before.get(id) - (rr.top + w.offsetTop);
      if (Math.abs(dy) > .5) { (w._s || (w._s = {x: 0, y: 0, vx: 0, vy: 0})).y = dy; spring(w, w._s.tx || 0, 0); }
    }
    report();
  }

  // ---------------------------------------------------------------- data
  async function refresh() {
    let d;
    try { d = await call("/api/notice"); } catch (e) { return; }
    try { const u = await call("/api/custom"); document.documentElement.dataset.theme = u.ui?.theme === "light" ? "light" : "dark"; } catch (e) { /* the cached theme stays */ }
    const have = new Map(cards.map((c) => [c.id, c]));
    const next = d.cards.map((c) => have.get(c.id) || Object.assign(c, {left: LIFE}));
    const dropped = cards.filter((c) => !next.includes(c)), added = next.filter((c) => !have.has(c.id));
    cards.splice(0, cards.length, ...next);
    for (const c of dropped) leave(c, true);
    if (added.length && !cards.some((c) => c.id === active && held(c))) active = added[0].id;
    sync();
  }
  window.__ntRefresh = refresh;

  // A card goes: off the right edge, then out of the list (and the app is told, so the window can go with the last).
  function leave(c, already) {
    const w = nodes.get(c.id);
    if (c === big) big = null;
    c.gone = true;
    if (!already) { const i = cards.indexOf(c); if (i >= 0) cards.splice(i, 1); }
    const finish = () => {
      if (w) { w.remove(); nodes.delete(c.id); }
      if (!already) call("/api/notice/dismiss", {id: c.id}).catch(() => {});
      sync();
    };
    if (!w) return finish();
    w.classList.add("gone");
    w.style.cssText += `position:absolute;right:0;top:${w.offsetTop}px`;   // out of the flow: the others close up while it flies
    if (!cards.some((x) => x.id === active)) active = cards[0]?.id ?? null;
    sync();
    if (RM.matches) setTimeout(finish, 200); else spring(w, FAR, 0, finish);
  }

  // ---------------------------------------------------------------- actions
  const cardOf = (el) => cards.find((c) => c.id === el.closest("[data-id]")?.dataset.id);
  function say(c, w, text, ok) {
    const d = w.querySelector(".nt-done");
    d.classList.toggle("ok", !!ok);
    d.textContent = text; d.hidden = false;
    w.querySelector(".nt-acts").hidden = true; w.querySelector(".nt-fb").hidden = true;
    report();
  }

  // The three verdicts and the feedback line are the app's own calls: the status of the version
  // (as the review page's verdict cards give it, web/verdict.js), and a comment handed to its session.
  // 고치기 asks for a note: it waits on the feedback line instead of going.
  async function verdict(c, w, s) {
    if (c.busy) return;
    if (s === "changes") {
      c.fix = true;
      w.querySelectorAll(".nt-v").forEach((b) => b.classList.toggle("on", b.dataset.v === s));
      w.querySelector(".nt-in").focus();
      report();
      return;
    }
    c.busy = true;
    try {
      const rev = s === "approved" ? {rev: (await call(`/api/item?p=${enc(c.p)}&i=${enc(c.i)}`)).rev} : {};
      await call("/api/status", {p: c.p, i: c.i, v: c.v, status: s, ...rev});
      say(c, w, s === "approved" ? tl("nt.approved") : tl("nt.held"), true);
      setTimeout(() => leave(c), 1200);
    } catch (e) { say(c, w, e.message || tl("nt.fail")); setTimeout(() => leave(c), 2600); }
    c.busy = false; c.doneAt = Date.now();
  }
  async function send(c, w) {
    const text = w.querySelector(".nt-in").value.trim();
    if (!text || c.busy) return;
    c.busy = true;
    try {
      await call("/api/comment", {p: c.p, i: c.i, v: c.v, text});
      if (c.fix) await call("/api/status", {p: c.p, i: c.i, v: c.v, status: "changes"});
      await call("/api/comments/send", {p: c.p, i: c.i, v: c.v});
      say(c, w, tl("nt.sent"), true);
      c.doneAt = Date.now();
      setTimeout(() => leave(c), 1400);
    } catch (e) {
      say(c, w, e.message || tl("nt.fail"));
      setTimeout(() => { w.querySelector(".nt-done").hidden = true; w.querySelector(".nt-acts").hidden = false; w.querySelector(".nt-fb").hidden = false; report(); }, 2200);
    }
    c.busy = false;
  }
  function openApp(c) {
    const hash = `#item/${enc(c.p)}/${enc(c.i)}`, api = window.pywebview && window.pywebview.api;
    if (api && api.show_main) api.show_main(hash); else window.open("/" + hash, "_blank");
    leave(c);
  }

  root.addEventListener("click", (e) => {
    const b = e.target.closest("[data-act]");
    if (!b) return;
    const c = b.closest(".nt-bigw") ? big : cardOf(b), w = b.closest(".nt-w"), act = b.dataset.act;
    if (!c) return;
    if (act === "x") { e.stopPropagation(); leave(c); }
    else if (act === "pick") { active = c.id; sync(); }
    else if (act === "zoom") { big = c; sync(); }
    else if (act === "unzoom") { big = null; sync(); }
    else if (act === "open") openApp(c);
    else if (act === "v") verdict(c, w, b.dataset.v);
    else if (act === "send") send(c, w);
  });
  root.addEventListener("keydown", (e) => {
    // 1 / 2 / 3 give the open card its verdict once the window has the keyboard (never while typing).
    const n = "123".indexOf(e.key);
    if (n >= 0 && !e.target.closest("input") && !e.ctrlKey && !e.altKey && !e.metaKey) {
      const w = root.querySelector(".nt-card")?.closest(".nt-w"), c = w && cardOf(w);
      if (c) verdict(c, w, VERDICTS[n]);
      return;
    }
    if (e.key !== "Enter" || e.isComposing || e.keyCode === 229) return;
    if (e.target.classList.contains("nt-in")) { e.preventDefault(); const w = e.target.closest(".nt-w"); send(cardOf(w), w); }
    else if (e.target.dataset.act === "pick") { active = cardOf(e.target).id; sync(); }
  });
  root.addEventListener("input", (e) => { const c = cardOf(e.target); if (c) c.typed = e.target.value.trim() !== ""; });
  addEventListener("keydown", (e) => { if (e.key === "Escape" && big) { big = null; sync(); } });

  // Cards leave after LIFE, except while the pointer is over them, a picture is enlarged, or an answer is in progress.
  setInterval(() => {
    const now = performance.now(), dt = now - lastTick;
    lastTick = now;
    const hold = root.matches(":hover") || big || cards.some(held);
    for (const c of [...cards]) {
      if (!hold) c.left -= dt;
      if (c.left <= 0 && !c.gone) leave(c);
    }
    for (const [id, w] of nodes) { const c = cards.find((x) => x.id === id), t = w.querySelector(".nt-at"); if (c && t) t.textContent = ago(c); }
  }, TICK);

  refresh();
})();
