(() => {
  const root = document.documentElement;
  if (root.dataset.skin !== "astra") return;
  // [route, Korean, English]; the order is the order of the contents.
  const PAGES = [["home", "홈", "Home"], ["project", "대화", "Chat"], ["lib", "결과물", "Results"], ["inbox", "알림", "Inbox"], ["depts", "부서", "Departments"],
    ["usage", "사용량", "Usage"], ["all", "전체", "Everything"], ["settings", "설정", "Settings"]];
  const TITLES = {home: ["하나씩, 차분하게.", "One thing at a time.", "지금 이어갈 작업", "What to pick up now"],
    storage: ["용량", "Storage", "", ""], sessions: ["대화 기록", "Sessions", "", ""], retro: ["회고", "Retro", "", ""]};
  const en = () => root.lang.startsWith("en");
  const text = (ko, e) => en() ? e : ko;

  const shell = document.createElement("header");
  shell.id = "astra-shell";
  const title = document.createElement("div");
  title.id = "astra-title";
  title.innerHTML = `<h1></h1><p></p><ul class="astra-facts"></ul>`;
  // A wide window is a spread (skin-astra.css): an open conversation keeps its left page too.
  const spread = matchMedia("(min-width:1100px)");
  const nav = () => shell.querySelector("nav");
  const menu = () => shell.querySelector(".astra-menu");

  // The start page's command line: a screen or a conversation name goes there on Enter;
  // any other text is carried into the newest conversation as a draft.
  const cmd = document.createElement("form");
  cmd.id = "astra-cmd";
  cmd.setAttribute("role", "search");
  title.append(cmd);
  let rooms = [], draft = "";
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
  const roomHref = (r) => "#project/" + encodeURIComponent(r.name) + "/" + r.sid;
  function matches() {
    const q = cmd.querySelector("input").value.trim().toLowerCase();
    const chats = rooms.map((r) => ({href: roomHref(r), name: r.named || r.title || r.name, kind: text("대화", "Chat")}));
    if (!q) return chats.slice(0, 8);
    const pages = PAGES.map(([key, ko, e]) => ({href: `#${key}`, name: text(ko, e), kind: text("화면", "Screen")}));
    return [...pages, ...chats].filter((m) => m.name.toLowerCase().includes(q)).slice(0, 6);
  }
  function suggest() {
    cmd.querySelector("ol").innerHTML = matches().map((m) => `<li><a href="${esc(m.href)}"${m.href === location.hash ? ' aria-current="page"' : ""}><span>${esc(m.name)}</span><small>${m.kind}</small></a></li>`).join("");
  }
  // Offline or mid-restart the list keeps what it showed last.
  function loadRooms() {
    fetch("/api/project/rooms").then((r) => r.json()).then((d) => {
      rooms = (d.rooms || []).filter((r) => r.sid && r.at).sort((a, b) => a.at < b.at ? 1 : -1);
      suggest();
    }).catch(() => {});
  }
  cmd.addEventListener("input", suggest);
  cmd.addEventListener("submit", (event) => {
    event.preventDefault();
    const input = cmd.querySelector("input"), q = input.value.trim(), first = matches()[0];
    if (!q) return;
    if (!first) draft = q;
    input.value = "";
    suggest();
    location.hash = first ? first.href : rooms[0] ? roomHref(rooms[0]) : "#project";
  });

  function draw() {
    shell.innerHTML = `<a class="astra-brand" href="#home">Genok</a>`
      + `<button class="astra-list" hidden aria-expanded="false">${text("대화 목록", "Conversations")}</button>`
      + `<button class="astra-menu" aria-expanded="false" aria-controls="astra-directory">${text("목차", "Contents")}</button>`
      + `<nav id="astra-directory" hidden aria-label="${text("목차", "Contents")}">`
      + PAGES.map(([key, ko, e]) => `<a href="#${key}">${text(ko, e)}</a>`).join("")
      + `<button data-go="search">${text("검색", "Search")}</button>`   // the app's own click handler opens the palette
      + `<button data-astra-update>${text("업데이트 확인", "Check for updates")}</button></nav>`;
    const ask = text("화면이나 대화 이름, 또는 맡길 일", "A screen, a chat, or a task");
    cmd.innerHTML = `<input type="text" autocomplete="off" enterkeyhint="go" aria-label="${ask}" placeholder="${ask}"><ol></ol>`;
    suggest();
    apply();
  }
  // On a spread a result's details are the left page, so the splitter between the pages widens them when dragged right.
  // The rest is the app's own splitter (v2.js wireItemGrip).
  function wireGrip() {
    const grip = document.getElementById("igrip");
    if (!grip || grip.dataset.astra) return;
    grip.dataset.astra = "1";
    const box = grip.parentElement;
    wireColGrip(grip, {range: [IPW[0], defIpw(), IPW[2]], get dir() { return spread.matches ? 1 : -1; }, width: () => box.lastElementChild.getBoundingClientRect().width,
      apply: (w) => { w = clampIpw(w); box.style.setProperty("--ipw", w + "px"); return w; }, save: ipw});
  }
  function toggle(open) {
    nav().hidden = !open;
    menu().setAttribute("aria-expanded", String(open));
  }
  function list(open) {
    root.classList.toggle("astra-list-open", open);
    shell.querySelector(".astra-list").setAttribute("aria-expanded", String(open));
  }
  function apply() {
    const route = (location.hash.slice(1) || "home").split("?")[0].split("/")[0];
    const room = !!document.querySelector(".pj-conv")?.getClientRects().length;
    root.dataset.astraPage = route;
    shell.querySelector(".astra-list").hidden = !room;
    // A result, a department page and an open conversation carry their own name.
    title.hidden = (room && !spread.matches) || document.body.classList.contains("push");
    title.classList.toggle("room", room);
    const page = PAGES.find(([key]) => key === route);
    const own = TITLES[route];
    const say = (el, s) => { if (el.textContent !== s) el.textContent = s; };
    const words = (sel) => [...document.querySelectorAll(sel)].map((el) => el.textContent.replace(/^[\s·]+|\s+$/g, "")).filter(Boolean).join(" · ");
    // An open conversation's left page: its name, its state in words, and its counts as words that press the app's own buttons.
    say(title.children[0], room ? words(".pj-conv .pj-nth .t") : own ? text(own[0], own[1]) : page ? text(page[1], page[2]) : document.querySelector("#top h1")?.textContent || "");
    say(title.children[1], room ? words(".pj-state :is(.pj-stl,.pj-stx)") : own ? text(own[2], own[3]) : "");
    const facts = !room ? "" : [[".pj-state .pj-chg", (el) => el.textContent.trim()], ["#pj-side .pj-strip", (el) => el.getAttribute("aria-label")]]
      .map(([sel, name]) => { const el = document.querySelector(sel); return el ? `<li><button type="button" data-astra-press="${esc(sel)}">${esc(name(el))}</button></li>` : ""; }).join("");
    if (title.children[2].dataset.sig !== facts) { title.children[2].dataset.sig = facts; title.children[2].innerHTML = facts; }
    cmd.hidden = route !== "home" && !room;
    wireGrip();
    const ta = draft && room && document.querySelector("#pj-ta");
    if (ta) {
      ta.value = draft;
      draft = "";
      ta.dispatchEvent(new Event("input", {bubbles: true}));
      ta.focus();
    }
    for (const link of nav().querySelectorAll("a")) {
      if (link.hash === `#${route}`) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    }
  }

  shell.addEventListener("click", (event) => {
    if (event.target.closest(".astra-menu")) {
      toggle(nav().hidden);
      if (!nav().hidden) nav().querySelector("[aria-current]")?.focus();
    } else if (event.target.closest(".astra-list")) list(!root.classList.contains("astra-list-open"));
    else if (event.target.closest("[data-astra-update]")) {
      toggle(false);
      document.querySelector("#status [data-stupd]")?.click();
    } else if (event.target.closest("nav :is(a,button)")) toggle(false);
  });
  document.addEventListener("click", (event) => {
    if (shell.contains(event.target)) return;
    toggle(false);
    const press = event.target.closest("[data-astra-press]");
    if (press) document.querySelector(press.dataset.astraPress)?.click();
    // Settings is one scrolling page here: a section opens from its top, not from where the menu was scrolled.
    if (event.target.closest(".setmenu [data-setp], .setnavb button")) scrollTo(0, 0);
    // The dropped list goes away on a click outside it, or once a conversation is picked from it.
    if (!event.target.closest(".pj-rail") || event.target.closest(".pj-srow")) list(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || nav().hidden) return;
    toggle(false);
    menu().focus();
  });
  spread.addEventListener("change", apply);
  addEventListener("hashchange", () => { toggle(false); list(false); suggest(); apply(); if (root.dataset.astraPage === "home") loadRooms(); });
  addEventListener("loop-lang", draw);

  document.body.prepend(shell);
  document.getElementById("top").after(title);
  draw();
  loadRooms();
  // The app marks a detail page on <body> and draws a conversation after the address has changed.
  let queued = false;
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; apply(); });
  }).observe(document.getElementById("view"), {childList: true, subtree: true});
})();
