// Comment tags on the result page: the moment (or stretch) of a video a comment is about,
// written in front of the words as plain text - "[file 0:05 f120]" or, for an A-B loop,
// "[file 0:01–0:05 f24–f120]". Plain on purpose: feedback.py and the live-session hook pass
// it through untouched, so a department reads it with no new field anywhere.
// A plain script loaded before v2.js; the pure helpers also export for tests/player.test.js.

// The picture on screen at time t. The float nudge keeps 21.3333 x 24 from flooring to 511.
const frameOf = (t, fps) => Math.floor(t * fps + 1e-4);
const clock = (t, tenth) => { const s = Math.floor(t); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}${tenth ? "." + Math.floor((t - s) * 10) : ""}`; };
// A spot on the picture, carried in the same tag: "위치(가로42%,세로60%)". A box adds its size,
// "위치(가로10%,세로20%,폭30%,높이15%)" - then 가로/세로 are its top-left corner.
const PIN_W = /^위치\(가로\d{1,3}%,세로\d{1,3}%(?:,폭\d{1,3}%,높이\d{1,3}%)?\)$/;
// The box in a tag, as 0..1 of the picture; null for a plain spot or no tag.
function boxOf(w) {
  const m = /^위치\(가로(\d{1,3})%,세로(\d{1,3})%,폭(\d{1,3})%,높이(\d{1,3})%\)$/.exec(w || ""); if (!m) return null;
  const [x, y, bw, bh] = m.slice(1).map((n) => Math.min(100, +n) / 100);
  return bw > 0 && bh > 0 ? {x, y, w: Math.min(bw, 1 - x), h: Math.min(bh, 1 - y)} : null;
}
// The tag for a box given in 0..1 (whole percent, at least 1% wide and high).
const boxTag = (r) => { const p = (n) => Math.round(n * 100), x = p(r.x), y = p(r.y);
  return `위치(가로${x}%,세로${y}%,폭${Math.max(1, Math.min(100 - x, p(r.w)))}%,높이${Math.max(1, Math.min(100 - y, p(r.h)))}%)`; };

const CLOCK = "(\\d+):(\\d{2}(?:\\.\\d)?)";
const ONE_CLOCK = new RegExp(`^${CLOCK}$`), TWO_CLOCK = new RegExp(`^${CLOCK}[–-]${CLOCK}$`);
const secsOf = (m, i) => +m[i] * 60 + +m[i + 1];

// The words for an I-O stretch: frames when the file knows its rate (a two-second loop
// would read "0:00–0:01" in whole seconds), tenths of a second when it does not.
function spanWhen(a, b, fps) {
  return fps ? `${clock(a)}–${clock(b)} f${frameOf(a, fps)}–f${frameOf(b, fps)}` : `${clock(a, true)}–${clock(b, true)}`;
}

// Reading a comment's tag back: "[file 0:05 f120]", "[0:01 f13]", "[0:01–0:05 f24–f120]" or
// the old page's "[#7 · f512 · 21.33s]". Null when it names no moment. t2/frame2 are the end
// of a stretch, null for a single moment.
function whenTag(text) {
  const m = /^\[([^\]]{1,200})\]\s*/.exec(text || ""); if (!m) return null;
  const words = m[1].split(/\s+/).filter((w) => w && w !== "·");
  let t = null, frame = null, t2 = null, frame2 = null, r;
  while (words.length) { const w = words[words.length - 1];
    if (/^f\d+$/.test(w)) frame = +w.slice(1);
    else if ((r = /^f(\d+)[–-]f?(\d+)$/.exec(w))) { frame = +r[1]; frame2 = +r[2]; }
    else if ((r = ONE_CLOCK.exec(w))) t = secsOf(r, 1);
    else if ((r = TWO_CLOCK.exec(w))) { t = secsOf(r, 1); t2 = secsOf(r, 3); }
    else if (/^\d+(\.\d+)?s$/.test(w)) t = parseFloat(w); else break;
    words.pop(); }
  if (t == null && frame == null) return null;
  // A stretch that ends before it starts is read as the single moment it starts at.
  if (t2 != null && !(t2 > t)) t2 = null;
  if (frame2 != null && !(frame2 > frame)) frame2 = null;
  return {tag: m[0], name: words.filter((w) => !/^#\d+$/.test(w) && !PIN_W.test(w)).join(" "), t: t || 0, frame, t2, frame2};
}

if (typeof module !== "undefined") module.exports = { frameOf, clock, spanWhen, whenTag, PIN_W, boxOf, boxTag };
