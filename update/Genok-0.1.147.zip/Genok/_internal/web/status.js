// Where a result stands, from the reader's side: one classifier for the 결과물 tabs, the card
// chips, the project page, 내 차례 and the saved views' smart filters. Pure (no DOM), so the node
// tests and the read-only audit of a real pile (tools/status_audit.js) run the same code.
//
// Once the reader has said their piece there are only two honest states: a session has it, or
// none does. "멈춤" used to be everything that was not being worked on this very minute (and the
// session list it needed was never loaded, so it was everything); it is now the one narrow case
// that needs a nudge.
//
//   check        새로 온 것 / 답할 것   a new version waits for me: 새로 온 것 until I open it (`new`), 답할 것 after
//   ask          답할 차례   it still has a question of its own unanswered, or its session waits on a
//                            question that names it: my move, filed like `check`
//   undelivered  기다리는 중 no session has read what I sent yet (nobody took it, or its session rests / is gone)
//   queued       기다리는 중 a session that is up has it but is busy with something it took later
//   work         작업 중     a session is answering right now and this is what it took last
//   stalled      멈춤        a session read it, then rested or left with no new version
//   done         멈춤        only a picked answer to its question, read by the session: nothing more is owed
//   old          멈춤        nothing moved for over a day (read or not)
//   hold         멈춤        put on hold by the reader
//   work (go)    작업 중     approved, and the session that read the approval is still at it (stGo)
//   approved     끝난 작업   approved and nothing is going on - but a comment sent after the approval (`reopened`) takes the
//                            result back into the flow above until it is approved again
//   finished     끝난 작업   the reader ended it (작업 끝내기): wins over everything, until reopened
//                            by hand or by a new version
//
// 멈춤 is told apart by who stopped it (`mine`): the reader (보류, or a session they stopped) or
// nobody (it just ended). Every result is in exactly one list, so the lists add up to 전체.
//
// Thresholds, from the pile measured on 2026-10-01 (docs/feedback-evidence/X21-status.md):
const ST_STALL_MIN = 10;   // rests this long after reading: its turn is over. Real fixes landed 1-6 min after the comment; resting sessions had rested 52-105 min.
const ST_OLD_H = 24;       // 멈춤 this long is 오래됨. Ages fell in two clumps: under 9 h, and 26-30 h (their session long gone).
const ST_LIVE_H = 3;       // a session that is up has several results on its hands and works on one: one it read this long ago with no new version is not being worked on.
const ST_MIN = 6e4, ST_HOUR = 36e5;

const ST_BATCH_MIN = 1;    // an inbox is read whole: what a session read within this of its newest read is the same batch.

// The list each kind is filed under (the tab keys; "pending"/"changes" are stored statuses and
// "undelivered"/"stalled"/"finished" the older list names, kept so links like #lib?f=pending
// still open a list that holds the same results).
const ST_TAB = {check: "pending", ask: "pending", undelivered: "undelivered", queued: "undelivered", work: "changes",
  stalled: "stalled", done: "stalled", old: "stalled", hold: "stalled", approved: "finished", finished: "finished"};
// Fixed order, the way a result travels: mine (new, then opened), a session's (waiting, worked on,
// stopped), over. Always on the strip, even at 0. 전체 is not a list of its own kind: it is the
// sum of these, a quiet control at the end of the row.
const ST_MAIN = ["fresh", "pending", "undelivered", "changes", "stalled", "finished"];
const ST_SIDE = [];
const ST_DONE = "finished";
// The reader's own two lists: what 내 차례 and the approve-several mode cover.
const ST_MINE = ["fresh", "pending"];

const stMs = (t) => { const n = t ? new Date(t).getTime() : 0; return isNaN(n) ? 0 : n; };
// The next move is a session's, not the reader's: sent back for changes, or answered in words.
// So is a result approved and then commented on: saying something after approving reopens it.
// Every fact here is about the newest version, so a new version hands the move back by itself.
// While a question is still open (`asked` counts the unanswered ones) only the reader's own words
// pass the turn (`spoke`: handed-over lines that are not an answer card), so answering one of two
// leaves the result with the reader. A summary from before `spoke` existed counted `asked` as 0
// once anything was answered, so "handed with a question open" there can only be words.
function stTurn(x) {
  if (x.status === "changes") return true;
  if (x.status === "pending") return x.asked > 0 ? !!x.handed && (x.spoke == null || x.spoke > 0) : !!(x.answered || x.handed);
  return x.status === "approved" && x.reopened > 0;
}

// asking: the sessions that wait on a question and what each last said (stWaits, from the
// attention.py rooms). Null when none waits or sessions are not read.
//
// Returns {kind, why, since}: `why` names the fact that decided it and `since` is the time that
// fact dates from (0 = unknown), so a list can say "read 12 minutes ago, no new version" on demand.
// Rules a reader can rely on:
//   - 작업 중 needs proof that a session can be working: a summary from before `reach` existed,
//     a session that is gone, or a hand-over with no time on it never says 작업 중.
//   - With the facts unchanged, time only moves a result forward (작업 중 -> 멈춤 -> 오래됨), so
//     nothing flips back and forth around a threshold.
//   - A clock ahead of ours (another machine's stamp) counts as "now", never as the future.
function stBase(x, now, lead) {
  // Ended by hand: no status, comment or session state brings it back (the server clears the
  // mark on a new version). Summaries from before the field existed have none.
  if (x.finished) return {kind: "finished", why: "finished", since: Math.min(stMs(x.finished), now)};
  const again = x.status === "approved" && x.reopened > 0;
  const J = (kind, why, since) => again ? {kind, why, since: since || 0, again: true} : {kind, why, since: since || 0};
  const at = (t) => Math.min(stMs(t), now);
  if (x.status === "approved" && !again) return stGo(x, now, lead) || J("approved", "approved");
  if (!stTurn(x)) return x.status === "hold" ? {...J("hold", "hold"), mine: true} : x.asked > 0 ? J("ask", "asked") : J("check", x.new === true ? "new" : "seen", at(x.at));
  // Summaries from before `reach` existed only say whether the newest comment was read.
  const known = x.reach != null;
  const reach = x.reach || (x.note === "ack" ? "ack" : x.note === "unsent" ? "sent" : "delivered");
  const handed = at(x.handed_at || x.at), moved = Math.max(handed, at(x.moved_at));
  const day = moved > 0 && now - moved < ST_OLD_H * ST_HOUR;
  // Stopped by the reader: the session it went to was stopped by hand (session_view.stopped).
  const M = (kind, why, since) => { const j = J(kind, why, since); if (x.sess_stop) j.mine = true; return j; };
  if (reach !== "ack") {
    // Unread for a day: nobody is coming for it by itself any more.
    if (moved > 0 && !day) return M("old", "unread_old", handed);
    // In the inbox of a session that is mid-answer on something else: it waits its turn.
    if (known && x.sess === "live" && reach === "delivered" && day) return J("queued", "has", moved);
    return J("undelivered", reach === "sent" ? "nosess" : x.sess === "ended" ? "unread_gone" : "unread", handed);
  }
  // Nothing more is owed, whatever the session is doing now: only a picked answer was handed
  // over and it was read, or every comment on it is settled.
  const owed = !(x.status === "pending" && x.answered && !(x.said > 0))
    && !(!again && x.comments > 0 && x.open === 0 && !(x.led && x.led.awaiting_fix > 0));
  // A session works on one thing at a time: of everything it read, only what it read last (the
  // same inbox read counts as one) can be what it is on. Without the list to compare against
  // (`lead` not given) the result is judged alone.
  const top = lead && x.to_session ? lead[x.to_session] || 0 : 0;
  const last = !top || moved >= top - ST_BATCH_MIN * ST_MIN;
  if (owed && known && x.sess === "live" && moved > 0 && now - moved < ST_LIVE_H * ST_HOUR) return last ? J("work", "read", moved) : J("queued", "later", moved);
  // Up but resting (or no record to ask, as with Codex): it works only while the read is fresh.
  const rested = Math.max(moved, x.sess === "idle" ? at(x.sess_since) : 0);
  if (owed && last && known && x.sess !== "ended" && x.sess !== "live" && rested > 0 && now - rested < ST_STALL_MIN * ST_MIN) return J("work", rested > moved ? "resting" : "fresh", rested);
  // All that was handed over was a picked answer to its own question, and it was read. Words
  // added to the answer (`said`) are a request like any other, so those can still stall.
  if (x.status === "pending" && x.answered && !(x.said > 0)) return J("done", "answer", moved);
  // Every comment on it is settled (fixed and verified elsewhere): nothing left to stall on.
  // Not after a reopening: the approval itself settled what was asked before it, so "nothing
  // open" there only says the new comment is not a tracked directive, not that it was dealt with.
  if (!again && x.comments > 0 && x.open === 0 && !(x.led && x.led.awaiting_fix > 0)) return J("done", "settled", moved);
  if (!moved) return M("stalled", x.sess_stop ? "mine" : "noclock");
  if (!day) return M("old", "old", moved);
  return M("stalled", x.sess_stop ? "mine" : x.sess === "ended" ? "gone" : x.sess === "live" || x.sess === "idle" ? "rested" : "quiet", moved);
}
// Approved is not the same as over: "go ahead" is an approval too. While the session that read
// the approval is still at it - up and busy with nothing it read later, or resting for less than
// the grace minutes - the result is 작업 중 (why "go"). Once nothing is going on it rests under
// 끝난 작업, told apart from one ended by hand by its 승인 chip. It never stalls: nothing is owed.
function stGo(x, now, lead) {
  if (x.reach !== "ack" || !x.to_session) return null;
  const at = (t) => Math.min(stMs(t), now), moved = Math.max(at(x.handed_at || x.at), at(x.moved_at));
  if (!moved || moved < (lead && lead[x.to_session] || 0) - ST_BATCH_MIN * ST_MIN) return null;
  if (x.sess === "live" && now - moved < ST_LIVE_H * ST_HOUR) return {kind: "work", why: "go", since: moved};
  const rested = Math.max(moved, x.sess === "idle" ? at(x.sess_since) : 0);
  if (x.sess !== "ended" && x.sess !== "live" && now - rested < ST_STALL_MIN * ST_MIN) return {kind: "work", why: "go", since: rested};
  return null;
}
// {session id: when it last read something that is still its move}, over the whole list: what
// stBase compares a result against to tell the one a busy session is on from the ones behind it.
function stLeads(items, now) {
  const lead = {};
  (items || []).forEach((x) => {
    if (x.finished || !x.to_session || x.reach !== "ack" || !stTurn(x)) return;
    const m = Math.max(Math.min(stMs(x.handed_at || x.at), now), Math.min(stMs(x.moved_at), now));
    if (m > (lead[x.to_session] || 0)) lead[x.to_session] = m;
  });
  return lead;
}
// A session that waits on a question hands the move back on the result its question is about,
// and on no other. The only tie there is to read is the question itself: the result's id or title
// in the last thing that session said (attention.py `said`), on a result that went to that very
// session. With no such tie the wait stays on the session (its own card on 내 차례, its row in the
// session list): a result the reader has answered is not theirs again because its session asks
// about something else. This used to flip every result the session, or any session of the same
// department, was handed within ST_LIVE_H - one the reader had just answered went straight back
// to 답할 차례.
//
// Only a question counts as waiting on the reader. A permission prompt does not: a session that
// took the answer and then stops to ask leave for a command is working on it.
//
// One that is finished (끝난 작업 · 답 전달됨 · 오래됨 · 승인 · 보류) never comes back this way.
function stWaits(rooms) {
  const rs = (rooms || []).filter((r) => r.job === "blocked" && r.needs === "input needed" && r.key);
  if (!rs.length) return null;
  const said = {};
  rs.forEach((r) => { said[r.key] = String(r.said || ""); });
  return {ids: new Set(rs.map((r) => r.key)), said};
}
// Does that session's question name this result? Its id, or a title long enough to mean it.
function stNamed(x, text) {
  const t = String(text || "").toLowerCase();
  if (!t) return false;
  return [x.id, x.title].some((n) => { n = String(n || "").trim().toLowerCase(); return n.length >= 4 && t.indexOf(n) !== -1; });
}
function stJudge(x, now, asking, lead) {
  const j = stBase(x, now, lead);
  if (!asking || !stTurn(x) || ["work", "queued", "undelivered", "stalled"].indexOf(j.kind) === -1) return j;
  const hit = !!x.to_session && !!asking.ids && asking.ids.has(x.to_session) && stNamed(x, asking.said && asking.said[x.to_session]);
  return hit ? (j.again ? {kind: "ask", why: "blocked", since: 0, again: true} : {kind: "ask", why: "blocked", since: 0}) : j;
}
function stKind(x, now, asking, lead) { return stJudge(x, now, asking, lead).kind; }
// The list a kind is filed under. A result that waits for the reader is 새로 온 것 only while its
// newest version was never opened (`new`, hub_store._is_new); a summary from before that field
// existed has none and counts as opened: nothing is called new without proof.
function stTab(kind, x) {
  const t = ST_TAB[kind] || "pending";
  return t === "pending" && x && x.new === true ? "fresh" : t;
}
// {tab: count} over a list, every tab present (0 when empty) so the strip never changes shape.
// `all` is the sum of the lists: each result is counted in exactly one.
function stCounts(items, now, asking) {
  const n = {all: 0}, lead = stLeads(items, now);
  ST_MAIN.forEach((k) => { n[k] = 0; });
  items.forEach((x) => { n[stTab(stKind(x, now, asking, lead), x)]++; n.all++; });
  return n;
}
// Old links and saved filters named the retired lists.
const ST_WAS = {waiting: "stalled", old: "stalled", tidy: "stalled", hold: "stalled", approved: "finished"};
function stTabKey(k) { return ST_WAS[k] || (ST_MAIN.indexOf(k) !== -1 ? k : "all"); }

if (typeof module !== "undefined") module.exports = {
  ST_STALL_MIN, ST_OLD_H, ST_LIVE_H, ST_BATCH_MIN, ST_TAB, ST_MAIN, ST_SIDE, ST_DONE, ST_MINE, stTurn, stWaits, stLeads, stJudge, stKind, stTab, stCounts, stTabKey,
};
