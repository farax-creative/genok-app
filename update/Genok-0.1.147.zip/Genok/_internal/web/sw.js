// Service worker: shows the hub's push notifications and opens the page they point at, and
// shows web/offline.html when a page cannot be loaded because the PC is not reached. Nothing
// else is cached - the hub is always read fresh from the PC.

// Bump OFFLINE_CACHE when offline.html changes: the new worker caches it again and drops the old.
const OFFLINE_CACHE = "genok-offline-v1";
const OFFLINE_URL = "/offline.html";

// The offline page is cached on install. A failure there (the PC went away mid-install) must not
// keep the new worker out: notifications matter more, and the next install tries again.
self.addEventListener("install", (event) => event.waitUntil(
  caches.open(OFFLINE_CACHE).then((c) => c.add(new Request(OFFLINE_URL, { cache: "reload" }))).catch(() => {})
    .then(() => self.skipWaiting())));
self.addEventListener("activate", (event) => event.waitUntil(Promise.all([
  caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith("genok-offline-") && k !== OFFLINE_CACHE).map((k) => caches.delete(k)))).catch(() => {}),
  // A page load starts its request while the worker wakes, so the fallback costs no time online.
  self.registration.navigationPreload ? self.registration.navigationPreload.enable().catch(() => {}) : null,
]).then(() => self.clients.claim())));

// Only a page load (a GET navigation) is ever answered here; every other request goes to the
// network untouched. The network's answer always wins, an error page included; offline.html
// stands in only when there is no answer at all (the PC or Tailscale is off).
const isPageLoad = (req) => !!req && req.mode === "navigate" && req.method === "GET";
function pageOrOffline(req, preload, net, cached) {
  return Promise.resolve(preload).then((r) => r || net(req))
    .catch(() => cached(OFFLINE_URL).then((r) => r || Response.error()));
}
self.addEventListener("fetch", (event) => {
  if (!isPageLoad(event.request)) return;
  event.respondWith(pageOrOffline(event.request, event.preloadResponse, (r) => fetch(r),
    (u) => caches.match(u, { cacheName: OFFLINE_CACHE })));
});

// A new result's notice points at /i/<project>/<item>/<version>: that one gets a [승인]
// button, which does what the page's 승인 does without opening it. There is no "open" button:
// tapping the notice itself opens the page, and a button that only repeats that is clutter.
const ITEM_RE = /^\/i\/([^/]+)\/([^/]+)\/(v\d{3,})$/;
function itemOf(url) {
  const m = ITEM_RE.exec(url || "");
  if (!m) return null;
  try { return { p: decodeURIComponent(m[1]), i: decodeURIComponent(m[2]), v: m[3] }; }
  catch { return null; }
}
// One notice per item: the tag leaves the version out, so v003 takes v002's place on the lock
// screen instead of piling under it - and renotify makes the replacement sound again. The
// button label and the "approved" line come with the push (msg.say), in the app's language.
const itemTag = (item) => `/i/${encodeURIComponent(item.p)}/${encodeURIComponent(item.i)}`;
function noticeOf(msg) {
  const item = itemOf(msg.url), say = msg.say || {};
  if (item && Number.isInteger(msg.rev)) item.rev = msg.rev;
  return {
    body: msg.body || "",
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    tag: item ? itemTag(item) : msg.url || "hub",
    renotify: true,
    data: { url: msg.url || "/", item, approved: say.approved || "{v} 승인했어요" },
    ...(item ? { actions: [{ action: "approve", title: say.approve || "승인" }] } : {}),
  };
}

self.addEventListener("push", (event) => {
  let msg;
  try { msg = event.data ? event.data.json() : {}; }
  catch { msg = { body: event.data ? event.data.text() : "" }; }
  event.waitUntil(self.registration.showNotification(msg.title || "Genok", noticeOf(msg)));
});

// Keep a click on our own origin: an absolute url in the push payload (e.g. "https://evil/")
// would otherwise win over the base and openWindow/navigate would leave the hub entirely.
function sameOriginUrl(raw) {
  try {
    const u = new URL(raw || "/", self.location.origin);
    if (u.origin === self.location.origin && (u.protocol === "https:" || u.protocol === "http:")) {
      return u.href;
    }
  } catch {}
  return self.location.origin + "/";
}

// Tap: bring the hub forward on that page, or open it.
function openHub(url) {
  return self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((wins) => {
    const win = wins.find((w) => "focus" in w);
    if (!win) return self.clients.openWindow(url);
    // Safari may not offer navigate() on an open window: the page moves itself instead.
    if ("navigate" in win) {
      return win.navigate(url).then((w) => (w || win).focus()).catch(() => self.clients.openWindow(url));
    }
    win.postMessage({ open: url });
    return win.focus();
  });
}

// [승인] from the notification: the same POST the page's button sends. A fetch from here
// carries this origin, which the server accepts like the page's own. Anything short of a
// clean answer opens the page instead, so the press is never silently lost.
// An approval must name the review rev: the one the notice announced, so a comment added
// since makes the server refuse (409) and the page opens. An older notice without one reads
// the current rev first.
function approve(item, title, said) {
  const revP = Number.isInteger(item.rev) ? Promise.resolve({ rev: item.rev })
    : fetch(`/api/item?p=${encodeURIComponent(item.p)}&i=${encodeURIComponent(item.i)}`)
      .then((r) => (r.ok ? r.json() : {}));
  return revP.then((d) => fetch("/api/status", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ p: item.p, i: item.i, v: item.v, status: "approved", rev: d.rev }),
  })).then((r) => {
    if (!r.ok) throw new Error(String(r.status));
    // The same notice, now saying what happened: it replaces itself (same tag), without a sound.
    return self.registration.showNotification(title || "Genok", {
      body: said.replace("{v}", item.v), icon: "/icon-192.png", badge: "/icon-192.png",
      tag: itemTag(item), data: { url: `${itemTag(item)}/${item.v}` },
    });
  });
}

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  const url = sameOriginUrl(data.url);
  if (event.action === "approve" && data.item) {
    event.waitUntil(approve(data.item, event.notification.title, data.approved).catch(() => openHub(url)));
    return;
  }
  event.waitUntil(openHub(url));
});

// The push service replaced or expired this device's subscription: subscribe again with the same
// options and hand the new one to the PC, so notices keep arriving with the app closed. (The page
// does the same on its next load, for browsers that never fire this.)
self.addEventListener("pushsubscriptionchange", (event) => {
  const options = event.oldSubscription && event.oldSubscription.options;
  if (!options) return;
  event.waitUntil(self.registration.pushManager.subscribe(options).then((sub) => fetch("/api/push/subscribe", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ subscription: sub.toJSON() }),
  })).catch(() => {}));
});

// The service worker's helpers are checked by node (tests/sw.test.js); a browser never sees this.
if (typeof module !== "undefined") module.exports = { itemOf, noticeOf, sameOriginUrl, isPageLoad, pageOrOffline, OFFLINE_CACHE, OFFLINE_URL };
