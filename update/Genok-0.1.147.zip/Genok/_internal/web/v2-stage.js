// Genok web UI, cut from v2.js: the item page's stage: frames, pins, crop guides, the scene strip, compare swap, drawing.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---- frames: seeking to the middle of a frame so the decoder settles on it
// (frameOf and clock live in stamp.js with the comment tags).
// Play what was just brought up; where the browser refuses sound without a tap, play it muted.
const playNow = (vd) => vd?.play().catch(() => { if (vd.muted) return; vd.muted = true; vd.play().catch(() => {}); });
// The bar's play button follows the video; redrawn only on a change, so a press is never cut under the finger.
const showPlay = (fs, vd) => { const b = fs.querySelector(".fplay"), on = !!vd && !vd.paused;
  if (b.dataset.on === String(on)) return; b.dataset.on = on; b.innerHTML = ic(on ? "pause" : "play"); b.setAttribute("aria-label", on ? tl("showPlay.1") : tl("itemView.39")); };
// Set by 다음 (N, or after 승인): the next result starts playing as it opens.
let autoPlay = false;
const stageVideo = () => document.querySelectorAll("#stage .sl")[stageAt]?.querySelector("video") || null;
const stepFrame = (n) => stepVideo(stageVideo(), openItem?.pics[stageAt], n);
function stepVideo(vd, f, n) {
  if (!vd || !f) return;
  vd.pause();
  const end = Number.isFinite(vd.duration) ? vd.duration : Infinity;
  if (!f.fps) { vd.currentTime = Math.max(0, Math.min(end, vd.currentTime + n * 0.1)); return; }
  const last = f.frames ? f.frames - 1 : Math.max(0, Math.round(end * f.fps) - 1);
  vd.currentTime = (Math.max(0, Math.min(last, frameOf(vd.currentTime, f.fps) + n)) + 0.5) / f.fps;
}
// Press-and-hold a step button: one step on press, then repeat with acceleration until release.
// Pointer capture keeps it running if the finger slides off; releasing lands on the frame reached.
function holdStep(b, dir) {
  b.addEventListener("pointerdown", (e) => {
    if (e.button) return;
    e.preventDefault(); b.setPointerCapture?.(e.pointerId);
    const mult = e.shiftKey ? 10 : 1;
    stepFrame(dir * mult);
    let held = 0, t = null;
    const tick = () => { held++; stepFrame(dir * mult); t = setTimeout(tick, held < 6 ? 110 : held < 14 ? 60 : 30); };
    const first = setTimeout(tick, 320);        // a tap is one frame; a hold starts repeating after this
    const stop = () => { clearTimeout(first); clearTimeout(t);
      b.removeEventListener("pointerup", stop); b.removeEventListener("pointercancel", stop); b.removeEventListener("lostpointercapture", stop); };
    b.addEventListener("pointerup", stop); b.addEventListener("pointercancel", stop); b.addEventListener("lostpointercapture", stop);
  });
  // Keyboard focus on the button: Enter/Space steps once (arrows step from anywhere on the page).
  b.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); stepFrame(dir * (e.shiftKey ? 10 : 1)); } });
}
// A frame/time typed into the readout: "120" or "f120" is a frame (seconds when the file has no fps),
// "1:23" a clock, "3.5s" seconds. Returns seconds to seek to, or null when it makes no sense.
function parseSeek(s, f) {
  s = String(s).trim(); if (!s) return null; let m;
  if ((m = /^(\d+):([0-5]?\d(?:\.\d+)?)$/.exec(s))) return +m[1] * 60 + +m[2];
  if ((m = /^(\d+(?:\.\d+)?)\s*s$/i.exec(s))) return +m[1];
  if ((m = /^f?\s*(\d+(?:\.\d+)?)$/i.exec(s))) { const n = +m[1]; return f?.fps ? (n + 0.5) / f.fps : n; }
  return null;
}
// Tap the readout to type a moment to jump to; readout() redraws it once the input closes.
function fnowJump(el, pic, redraw) {
  el.onclick = () => {
    const vd = stageVideo(), f = pic(); if (!vd || el.querySelector("input")) return;
    const cur = f.fps ? String(frameOf(vd.currentTime, f.fps)) : clock(vd.currentTime, true);
    el.innerHTML = `<input class="fjump num" value="${esc(cur)}" inputmode="decimal" aria-label="${tl("fnowJump.1")}">`;
    const inp = el.querySelector("input"); inp.focus(); inp.select();
    const close = () => { inp.onblur = null; inp.remove(); redraw(); };
    const commit = (hint) => { const t = parseSeek(inp.value, f);
      if (t != null && Number.isFinite(vd.duration)) vd.currentTime = Math.max(0, Math.min(vd.duration - 0.001, t));
      else if (t == null && hint) toast(tl("fnowJump.2"));
      close(); };
    inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); commit(true); } else if (e.key === "Escape") { e.preventDefault(); close(); } };
    inp.onblur = () => commit(false);
  };
}
// M (Shift+M back): jump to the next comment mark on the file on screen.
function jumpMark(dir) {
  const vd = stageVideo(), f = openItem?.pics[stageAt]; if (!vd || !f) return;
  const single = openItem.pics.filter((g) => g.kind === "video").length === 1;
  const ts = (openItem.marks || []).filter((m) => m.name ? m.name === f.name : single)
    .map((m) => f.fps && m.frame != null ? (m.frame + 0.5) / f.fps : m.t).sort((a, b) => a - b);
  if (!ts.length) return toast(tl("jumpMark.1"));
  const now = vd.currentTime, t = dir > 0 ? ts.find((x) => x > now + 0.05) : ts.filter((x) => x < now - 0.05).pop();
  if (t == null) return toast(dir > 0 ? tl("jumpMark.2") : tl("jumpMark.3"));
  vd.currentTime = t;                           // a playing video keeps playing from the mark
}
// Slow motion for checking a move: 1x, 0.5x, 0.25x, round again. One speed for every video on the stage.
let rate = 1;
function nextRate() { setRate(rate === 1 ? 0.5 : rate === 0.5 ? 0.25 : 1); }
// J K L as in every editor: K stops, L plays and each further L goes faster (1 1.5 2),
// J slows a playing video down, or on a stopped one goes back a second.
const RATES = [0.25, 0.5, 1, 1.5, 2];
function jkl(k, vd) {
  if (k === "k") return vd.pause();
  const i = RATES.indexOf(rate);
  if (k === "l") { if (vd.paused) { setRate(1); return playNow(vd); } return setRate(RATES[Math.min(RATES.length - 1, i + 1)]); }
  if (vd.paused) { vd.currentTime = Math.max(0, vd.currentTime - 1); return; }
  setRate(RATES[Math.max(0, i - 1)]);
}
function setRate(r) {
  rate = r;
  document.querySelectorAll("#stage video, .vw video, #cmp video").forEach((vd) => { vd.playbackRate = rate; });
  const b = document.querySelector(".fstep .frate"); if (b) { b.textContent = `${rate}×`; b.classList.toggle("on", rate !== 1); }
}
// The before/after wipe with two videos: the new one leads, the old one follows it
// (play, pause, seek, and a nudge back whenever they drift more than a frame apart).
function wireCmpVideo(c, fps, onFrame) {
  const [a, b] = c.querySelectorAll("video"), play = document.getElementById("cmpplay"), now = document.getElementById("cmpnow");
  const f = fps || 30;
  // The older cut follows the driving (newer) time by absolute time (alignTime); past its end its
  // last frame is held instead of re-seeking every tick.
  const sync = () => { const {t, past} = alignTime(b.currentTime, a.duration);
    if (past) { if (!a.paused) a.pause(); return; }
    if (a.paused && !b.paused) a.play().catch(() => {});
    if (Math.abs(a.currentTime - t) > 1 / f) a.currentTime = t; };
  const show = () => { now.textContent = fps ? `f${frameOf(b.currentTime, fps)}` : clock(b.currentTime, true); play.innerHTML = ic(b.paused ? "play" : "pause"); play.setAttribute("aria-label", b.paused ? tl("itemView.39") : tl("SESS_T.2")); onFrame && onFrame(); };
  b.addEventListener("play", () => { sync(); a.play().catch(() => {}); show(); });
  b.addEventListener("pause", () => { a.pause(); sync(); show(); });
  b.addEventListener("seeked", () => { sync(); show(); });
  b.addEventListener("timeupdate", () => { if (!b.paused) sync(); show(); });
  play.onclick = () => b.paused ? b.play().catch(() => {}) : b.pause();
  document.querySelectorAll("[data-cs]").forEach((x) => x.onclick = () => { b.pause();
    b.currentTime = stepTime(b.currentTime, fps, +x.dataset.cs, b.duration); });
  show();
}
// The pixel diff for two videos: their current frames are drawn onto one grid (the newer's aspect,
// capped at 1024 wide) and diffed. While a video plays it redraws per displayed frame, throttled to
// spare the CPU; paused or scrubbing, it redraws on every seek. Returns a function that forces a
// redraw (mode switch, threshold change). The last frame's cost is left on window.__cmpDiffMs.
function wireCmpVideoDiff(c, getThr, isDiff, onRatio) {
  const [a, b] = c.querySelectorAll("video");
  const oa = document.createElement("canvas"), ob = document.createElement("canvas");
  const ga = oa.getContext("2d", {willReadFrequently: true}), gb = ob.getContext("2d", {willReadFrequently: true});
  let raf = 0, last = 0;
  const draw = () => {
    const out = c.querySelector(".cdiff"); if (!out || !a || !b) return;
    const bw = b.videoWidth, bh = b.videoHeight; if (!bw || !bh) return onRatio(null);
    const {w, h} = diffSize(bw, bh, 1024);
    const t0 = performance.now();
    try {
      oa.width = ob.width = out.width = w; oa.height = ob.height = out.height = h;
      ga.drawImage(a, 0, 0, w, h); gb.drawImage(b, 0, 0, w, h);
      const r = diffPixels(ga.getImageData(0, 0, w, h).data, gb.getImageData(0, 0, w, h).data, w, h, {threshold: getThr()});
      out.getContext("2d").putImageData(new ImageData(r.data, w, h), 0, 0);
      onRatio(r.ratio);
      try { window.__cmpDiffMs = Math.round((performance.now() - t0) * 10) / 10; } catch {}
    } catch { onRatio(null); }
  };
  const rVFC = "requestVideoFrameCallback" in HTMLVideoElement.prototype;
  const schedule = () => { raf = rVFC ? b.requestVideoFrameCallback(loop) : requestAnimationFrame(loop); };
  function loop() { raf = 0; if (!isDiff()) return;
    const now = performance.now(); if (now - last > 80) { last = now; draw(); }   // ~12/s is plenty to read
    if (!b.paused) schedule(); }
  b.addEventListener("play", () => { if (isDiff() && !raf) schedule(); });
  b.addEventListener("seeked", () => { if (isDiff()) draw(); });
  b.addEventListener("pause", () => { if (isDiff()) draw(); });
  // Opened straight into 차이 before the frames decode: redraw once each side is ready.
  const ready = () => { if (isDiff() && a.readyState >= 2 && b.readyState >= 2) draw(); };
  a.addEventListener("loadeddata", ready); b.addEventListener("loadeddata", ready);
  return () => { draw(); if (!b.paused && isDiff() && !raf) schedule(); };
}
// The time-tagged comments that sit on the compared file, for the scrub rail's ticks. A mark's
// time is read at the newer video's rate; ones left on the previous version are dimmer.
function cmpRailMarks(d, cv, pv) {
  const names = [cv[1]?.name, cv[0]?.name].filter(Boolean);
  return (d.log || []).filter((e) => e.kind === "comment").map((e) => { const w = whenTag(e.text);
    if (!w || (w.name && !names.includes(w.name))) return null;
    return {t: w.frame != null && cv[1].fps ? (w.frame + 0.5) / cv[1].fps : w.t, prev: e.v === pv.v}; }).filter(Boolean);
}
// The dedicated scrub rail for two videos: drag it and both seek together, 1:1 with the finger
// (a direct seek, no glide, so the frame follows the pointer exactly); ← → step one frame (Shift
// ten), Space plays. It shows both cuts' lengths and a tick per time-tagged comment.
function wireCmpRail(c, cv, marks, fps, vers) {
  const rail = document.getElementById("cmprail"); if (!rail) return;
  const [a, b] = c.querySelectorAll("video");
  const track = rail.querySelector(".cmptk"), fill = rail.querySelector(".fill"), ph = rail.querySelector(".ph");
  const ticks = rail.querySelector(".ticks"), da = rail.querySelector(".da"), db = rail.querySelector(".db");
  const dur = () => Number.isFinite(b.duration) && b.duration > 0 ? b.duration : 1;
  const put = () => { const f = Math.min(1, Math.max(0, b.currentTime / dur())) * 100;
    fill.style.width = f + "%"; ph.style.left = f + "%"; rail.setAttribute("aria-valuenow", Math.round(f)); };
  const meta = () => {
    if (db) db.textContent = `${vers.b} ${clock(dur(), true)}`;
    if (da) da.textContent = `${vers.a} ${Number.isFinite(a.duration) ? clock(a.duration, true) : "…"}`;
    ticks.innerHTML = marks.map((m) => `<i class="${m.prev ? "prev" : ""}" style="left:${(Math.min(1, Math.max(0, m.t / dur())) * 100).toFixed(2)}%"></i>`).join("");
    put();
  };
  b.readyState >= 1 ? meta() : b.addEventListener("loadedmetadata", meta, {once: true});
  a.readyState >= 1 || a.addEventListener("loadedmetadata", meta, {once: true});
  b.addEventListener("timeupdate", put); b.addEventListener("seeked", put);
  let scrub = false, wasPlaying = false;
  const seek = (x) => { const r = track.getBoundingClientRect(); b.currentTime = Math.min(1, Math.max(0, (x - r.left) / r.width)) * dur(); };
  track.addEventListener("pointerdown", (e) => { e.preventDefault(); track.setPointerCapture(e.pointerId);
    scrub = true; wasPlaying = !b.paused; b.pause(); seek(e.clientX); });
  track.addEventListener("pointermove", (e) => { if (scrub) seek(e.clientX); });
  const end = (e) => { if (!scrub) return; scrub = false; try { track.releasePointerCapture(e.pointerId); } catch {} if (wasPlaying) b.play().catch(() => {}); };
  track.addEventListener("pointerup", end); track.addEventListener("pointercancel", end);
  rail.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); b.pause();
      b.currentTime = stepTime(b.currentTime, fps, (e.key === "ArrowRight" ? 1 : -1) * (e.shiftKey ? 10 : 1), b.duration); }
    else if (e.key === " " || e.key === "Enter") { e.preventDefault(); b.paused ? b.play().catch(() => {}) : b.pause(); }
  });
}
// 지시 위치 겹쳐 보기: the previous version's pins over the newer frame in compare. Positioned in
// the newer element's contain-box (video or image), so a pin lands where it was left. On a video,
// only the pins around the current moment show. Green check = a later version claims it fixed.
function renderCmpOverlay(c, ov, fps) {
  const lay = c.querySelector(".cmpov"); if (!lay) return;
  if (!c.classList.contains("ov-on") || c.classList.contains("m-diff") || !ov.length) { lay.innerHTML = ""; return; }
  const bEl = c.querySelector(".b"), cr = c.getBoundingClientRect(), r = bEl.getBoundingClientRect();
  const vd = bEl.tagName === "VIDEO" ? bEl : null;
  const nw = vd ? vd.videoWidth : lay._nw, nh = vd ? vd.videoHeight : lay._nh;
  if (!nw || !nh || !r.width) { lay.innerHTML = ""; return; }
  const s = Math.min(r.width / nw, r.height / nh), w = nw * s, h = nh * s;
  const bx = r.left - cr.left + (r.width - w) / 2, by = r.top - cr.top + (r.height - h) / 2;
  const at = (o) => o.frame != null && fps ? (o.frame + 0.5) / fps : o.t;
  const near = (o) => !vd || o.t == null || Math.abs(at(o) - vd.currentTime) < 0.6;
  const pins = ov.filter((o) => o.x != null && near(o));
  // A region comment (w/h) shows its box, with the same tappable pin on its top-left corner.
  const px = (v, n) => (v * n / 100).toFixed(1);
  lay.innerHTML = pins.map((o, i) => (o.w != null ? `<i class="cmpbox ${o.fixed ? "fx" : "op"}" aria-hidden="true" style="left:${(bx + w * o.x / 100).toFixed(1)}px;top:${(by + h * o.y / 100).toFixed(1)}px;width:${px(o.w, w)}px;height:${px(o.h, h)}px"></i>` : "") + `<button class="cmpin ${o.fixed ? "fx" : "op"}" data-ov="${i}" style="left:${(bx + w * o.x / 100).toFixed(1)}px;top:${(by + h * o.y / 100).toFixed(1)}px" aria-label="${o.fixed ? tl("renderCmpOverlay.1") : tl("renderCmpOverlay.2")}">${o.fixed ? ic("check") : ""}</button>`).join("");
  lay.querySelectorAll("[data-ov]").forEach((el) => el.onclick = (e) => { e.stopPropagation();
    const o = pins[+el.dataset.ov]; toast((o.fixed ? tl("renderCmpOverlay.3") : "") + attOf(o.text).words, 4500); });
}
// A comment on the version on screen gets its moment as a button: tap to see that frame.
function noteText(e, shown, pics) {
  const {words, urls} = attOf(e.text), w = e.v === shown && whenTag(words);
  const att = urls.length ? `<span class="npics">${urls.map((u) => `<a href="${esc(u)}" target="_blank" rel="noopener"><img src="${esc(u)}" alt="${tl("noteText.1")}" loading="lazy"></a>`).join("")}</span>` : "";
  // A comment written in markdown (bold, code, a list) reads as it was meant; plain words stay
  // plain text. renderMarkdown builds DOM nodes, never parsing HTML, so this stays safe (C06).
  const md = (s) => typeof looksMarkdown === "function" && looksMarkdown(s) ? renderMarkdown(s.trim(), "md nmd").outerHTML : esc(s);
  // A box left on the picture: a chip that lights the box on the stage (hover/focus) and goes to it (tap).
  const rg = e.v === shown && regionOf(e) ? `<button class="lchip press" data-loc="${esc(e.id)}" title="${tl("loc.region_t")}">${ic("pin")}<span>${tl("loc.region")}</span></button> ` : "";
  // A quoted passage of the report: its own block above the words, a way back to that place.
  const qo = quoteOf(words);
  if (qo) return `<button class="qjump press" data-qj="${esc(qo.q)}" data-qn="${e.quote_n | 0}" title="${tl("pgq.jump_t")}">${esc(qo.q)}</button>` + (qo.to ? `<span class="qto">${esc(qo.to)}</span>` : "") + md(qo.rest) + att;
  if (!w || !pics.some((f) => f.kind === "video")) return rg + md(words) + att;
  const span = w.t2 != null || w.frame2 != null;
  return `<button class="tjump press num${span ? " span" : ""}" data-jn="${esc(w.name)}" data-jt="${w.t}" data-jf="${w.frame ?? ""}"${span ? tl("noteText.2", {p0: w.t2 ?? "", p1: w.frame2 ?? ""}) : ""}>${span ? ic("loop") : ""}${esc(w.tag.trim())}</button> ${md(words.slice(w.tag.length))}` + att;
}
document.addEventListener("click", (e) => { const b = e.target.closest?.(".tjump"); if (!b || !openItem || !stageGo) return;
  const pics = openItem.pics, byName = pics.findIndex((f) => f.name === b.dataset.jn && f.kind === "video");
  const at = byName >= 0 ? byName : pics[stageAt]?.kind === "video" ? stageAt : pics.findIndex((f) => f.kind === "video"); if (at < 0) return;
  stageGo(at); const vd = stageVideo(), f = pics[at]; if (!vd) return;
  const a = f.fps && b.dataset.jf !== "" ? (+b.dataset.jf + 0.5) / f.fps : +b.dataset.jt;
  // A range chip goes round its stretch, as I and O would have set it; a single moment just stops there.
  const e2 = b.dataset.jf2 ?? "", t2 = b.dataset.jt2 ?? "", end = f.fps && e2 !== "" ? (+e2 + 1) / f.fps : t2 !== "" ? +t2 : null;
  vd.pause(); vd.currentTime = a;
  if (end != null && end > a) { loops[abKey()] = {a, b: end}; toast(tl("noteText.3", {abTxt: abTxt(loops[abKey()], f)})); playNow(vd); }
  const st = document.getElementById("stage"); if (st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); });
// A comment with a box: hovering or focusing its row lights the box on the stage; a tap on the
// chip keeps it lit and brings the stage (and the right file) into view.
document.addEventListener("click", (e) => { const b = e.target.closest?.(".lchip"); if (!b || !openItem) return;
  e.stopPropagation(); lightLoc(locHl === b.dataset.loc && locHlKeep ? null : b.dataset.loc, true); });
const locRow = (e) => e.target.closest?.(".row.note")?.querySelector(".lchip");
document.addEventListener("pointerover", (e) => { const c = locRow(e); if (c && !locHlKeep && locHl !== c.dataset.loc) lightLoc(c.dataset.loc); });
document.addEventListener("pointerout", (e) => { const c = locRow(e); if (c && !locHlKeep && !c.closest(".row").contains(e.relatedTarget)) lightLoc(null); });
document.addEventListener("focusin", (e) => { const c = locRow(e); if (c && !locHlKeep) lightLoc(c.dataset.loc); });
// ---- pin: a spot on the picture or frame, carried in the comment's tag as "위치(가로42%,세로60%)" (from the
// top left of the picture itself, not the black bars around it). Pins already left on the file
// on screen show as orange dots - on a video, only around the moment they were left at.
let pin = null, pinning = false, pinLabel = () => {};
function pinOf(text) {
  const m = /^\[([^\]]{1,200})\]/.exec(text || ""), w = m && m[1].split(/\s+/).find((x) => PIN_W.test(x)); if (!w) return null;
  const at = whenTag(text), r = boxOf(w);
  // A box's dot (compare overlay, old readers) sits at its middle, not its top-left corner.
  const [x, y] = r ? [Math.round((r.x + r.w / 2) * 100), Math.round((r.y + r.h / 2) * 100)] : w.match(/\d+/g).map(Number);
  return {x, y, r, name: at ? at.name : m[1].split(/\s+/).filter((q) => q && !PIN_W.test(q)).join(" "), t: at ? at.t : null, frame: at?.frame ?? null, text};
}
// A comment's box on the picture (0..1): the stored rect when the server kept one, else the
// box in its "위치(가로…,폭…,높이…)" tag. A plain spot (old pin) has none and stays a dot.
const okRect = (r) => r && [r.x, r.y, r.w, r.h].every(Number.isFinite) && r.w > 0 && r.h > 0 ? r : null;
const regionOf = (e) => e && (okRect(e.rect) || pinOf(e.text)?.r) || null;
// A box fitted inside the picture at 4 decimals, so x + w and y + h never pass 1.
function fitRect(r) {
  const q = (n) => Math.round(Math.min(1, Math.max(0, n)) * 1e4) / 1e4, x = q(r.x), y = q(r.y);
  const fit = (o, n) => { let s = Math.max(1e-4, Math.min(q(n), q(1 - o))); while (o + s > 1 && s > 1e-4) s = q(s - 1e-4); return s; };
  return {x, y, w: fit(x, r.w), h: fit(y, r.h)};
}
function pinOfE(e) {
  const q = pinOf(e.text); if (!q) return null;
  return {...q, id: e.id, r: okRect(e.rect) || q.r};
}
// The comment whose spot is lit on the stage (hover/focus on its row, or a tap on its chip).
let locHl = null, locHlKeep = false;
function lightLoc(id, keep) {
  locHl = id; locHlKeep = !!keep; drawPins();
  if (keep) { const q = (openItem?.pins || []).find((x) => x.id === id), at = q && q.name ? openItem.pics.findIndex((f) => f.name === q.name) : -1;
    if (at >= 0 && at !== stageAt && stageGo) stageGo(at);
    const st = document.getElementById("stage"); if (st && st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"}); }
}
function mediaBox(m) {
  const r = m.getBoundingClientRect(), nw = m.videoWidth || m.naturalWidth, nh = m.videoHeight || m.naturalHeight;
  if (!nw || !nh) return null;
  const s = Math.min(r.width / nw, r.height / nh), w = nw * s, h = nh * s;
  return {left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, w, h};
}
function drawPins() {
  const st = document.getElementById("stage"); if (!st || !openItem) return;
  let lay = st.querySelector(".pins");
  if (!lay) { lay = document.createElement("div"); lay.className = "pins"; st.appendChild(lay);
    // In pin mode a tap leaves a spot; on a still picture a drag draws a box instead (region
    // comment). The box follows the pointer 1:1 and is kept in 0..1 of the picture itself.
    let rg = null;
    const frac = (e, b) => [Math.min(1, Math.max(0, (e.clientX - b.left) / b.w)), Math.min(1, Math.max(0, (e.clientY - b.top) / b.h))];
    lay.addEventListener("pointermove", (e) => { if (!rg || e.pointerId !== rg.id) return;
      const [fx, fy] = frac(e, rg.b); rg.r = {x: Math.min(rg.x0, fx), y: Math.min(rg.y0, fy), w: Math.abs(fx - rg.x0), h: Math.abs(fy - rg.y0)};
      if (!rg.moved && Math.hypot(e.clientX - rg.cx, e.clientY - rg.cy) > 6) rg.moved = true;
      if (rg.moved) { pin = {x: Math.round((rg.r.x + rg.r.w / 2) * 100), y: Math.round((rg.r.y + rg.r.h / 2) * 100), at: stageAt, r: rg.r, live: true}; drawPins(); } });
    const rgEnd = (e) => { if (!rg || e.pointerId !== rg.id) return; const g = rg; rg = null;
      if (e.type === "pointercancel") { pin = null; drawPins(); pinLabel(); return; }
      if (g.moved && g.r && g.r.w * g.b.w >= 8 && g.r.h * g.b.h >= 8) { const r = g.r, q = (n) => Math.round(n * 10000) / 10000;
        pin = {x: Math.round((r.x + r.w / 2) * 100), y: Math.round((r.y + r.h / 2) * 100), at: stageAt, r: {x: q(r.x), y: q(r.y), w: q(r.w), h: q(r.h)}}; }
      else pin = {x: Math.round(g.x0 * 100), y: Math.round(g.y0 * 100), at: stageAt};
      pinning = false; drawPins(); pinLabel(); pinPlaced(); };
    lay.addEventListener("pointerup", rgEnd); lay.addEventListener("pointercancel", rgEnd);
    lay.addEventListener("pointerdown", (e) => {
      if (!pinning) { const p = e.target.closest?.(".pin.old,.rgn.old"); if (p) { e.stopPropagation(); toast(p.dataset.t, 4500); } return; }
      e.stopPropagation(); e.preventDefault();
      const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = m && mediaBox(m); if (!b) return;
      const x = Math.round((e.clientX - b.left) / b.w * 100), y = Math.round((e.clientY - b.top) / b.h * 100);
      if (x < 0 || x > 100 || y < 0 || y > 100) return toast(tl("drawPins.1"));
      if (m.tagName === "IMG") { rg = {id: e.pointerId, b, x0: x / 100, y0: y / 100, cx: e.clientX, cy: e.clientY, moved: false};
        try { lay.setPointerCapture(e.pointerId); } catch {} return; }
      pin = {x, y, at: stageAt}; pinning = false; drawPins(); pinLabel(); pinPlaced(); });
    new ResizeObserver(() => drawPins()).observe(st); }
  st.classList.toggle("pinning", pinning);
  const f = openItem.pics[stageAt], m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = m && mediaBox(m);
  if (!b) { lay.innerHTML = ""; m?.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", drawPins, {once: true}); return; }
  const sr = st.getBoundingClientRect(), vd = m.tagName === "VIDEO" ? m : null;
  const when = (q) => f.fps && q.frame != null ? (q.frame + 0.5) / f.fps : q.t;
  const near = (q) => !vd || when(q) == null || Math.abs(when(q) - vd.currentTime) < 0.6;
  const mine = (openItem.pins || []).filter((q) => (q.name ? q.name === f.name : openItem.pics.length === 1) && near(q));
  const L = (x) => (b.left - sr.left + b.w * x).toFixed(1), T = (y) => (b.top - sr.top + b.h * y).toFixed(1);
  const tip = (title) => title ? ` title="${esc(title)}" data-t="${esc(title.replace(/^\[[^\]]*\]\s*/, ""))}"` : "";
  const dot = (x, y, cls, title = "") => `<span class="pin ${cls}" style="left:${L(x / 100)}px;top:${T(y / 100)}px"${tip(title)}></span>`;
  const box = (r, cls, title = "") => `<span class="rgn ${cls}" style="left:${L(r.x)}px;top:${T(r.y)}px;width:${(b.w * r.w).toFixed(1)}px;height:${(b.h * r.h).toFixed(1)}px"${tip(title)}></span>`;
  drawGuide();
  lay.classList.toggle("lit", !!locHl && mine.some((q) => q.id === locHl));
  lay.innerHTML = mine.map((q) => { const c = (q.prev ? "old prev" : "old") + (q.id && q.id === locHl ? " hl" : "");
      return q.r ? box(q.r, c, q.text) : dot(q.x, q.y, c, q.text); }).join("")
    + (pin && pin.at === stageAt ? (pin.r ? box(pin.r, "new" + (pin.live ? " live" : "")) : dot(pin.x, pin.y, "new")) : "");
}
// After a spot or box is placed: open the composer so the note can be written and sent.
function pinPlaced() {
  // A pin belongs to a comment: opening it from the stage (composer still closed) opens the
  // composer so the note can be written and sent, then focuses/scrolls to it as usual.
  cmShow();
  // PC: straight into the box. Phone: bring the box back up without raising the keyboard.
  if (wide()) document.getElementById("cm")?.focus({preventScroll: true});
  else if (document.querySelector(".cbox")?.closest(".mounted")) setTimeout(() => document.querySelector(".cbox")?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}), 250);
}
// The phone bar's … sheet. Each row presses the bar's own (hidden) button, so the keys, the saved
// choices and the labels stay in one place; a setting row stays open to show its new value.
function stageMore(bar) {
  const q = (s) => bar.querySelector(s), on = (b) => b?.getAttribute("aria-pressed") === "true" ? tl("smore.on") : tl("smore.off");
  const vid = q(".fstep") && !q(".fstep").hidden, side = q(".sside");
  const rows = [
    vid && ["rate", "gauge", tl("itemView.47"), () => q(".frate").textContent, ".frate"],
    vid && ["scn", "image", tl("itemView.49"), () => on(q(".fscn")), ".fscn"],
    ["bg", "moon", tl("smore.bg"), () => q(".sbgb span").textContent.replace(tl("smore.bg"), "").trim(), ".sbgb"],
    ["guide", "rect", tl("smore.guide"), () => guide || tl("smore.off"), ".sguide"],
    side && ["side", "cols", side.getAttribute("aria-label"), () => "", ".sside", true],
  ].filter(Boolean);
  const mute = q(".smute") && !q(".smute").hidden ? `<p class="hint2 smnote">${ic("mute")}<span>${tl("stageBg.7")}</span></p>` : "";
  sheet(`<h3>${tl("smore")}</h3>${rows.map(([k, icon, t, val]) => `<button class="row press" data-sm="${k}"><span class="ico sm c-grey">${ic(icon)}</span><span class="tx"><div class="t" style="font-size:16px">${esc(t)}</div></span><span class="smv num">${esc(val())}</span></button>`).join("")}${mute}`, (el) => {
    el.querySelectorAll("[data-sm]").forEach((b) => b.onclick = (e) => { e.stopPropagation();
      const [, , , val, sel, leave] = rows.find((r) => r[0] === b.dataset.sm);
      if (leave) { closeSheet(); setTimeout(() => q(sel)?.click(), 280); return; }
      q(sel)?.click(); b.querySelector(".smv").textContent = val(); });
  });
}
// ---- F (or 비율): where a 9:16, 4:5 or 1:1 cut of the picture would fall, the rest dimmed.
// The stage's backdrop: black by default, or graphite / white / a checkerboard to judge edges and
// transparency against (the hub's viewer backgrounds, R10). Remembered on this device.
const STAGE_BGS = ["black", "graphite", "white", "checker"];
let stageBg = "black"; try { stageBg = STAGE_BGS.includes(localStorage.getItem("v2-stagebg")) ? localStorage.getItem("v2-stagebg") : "black"; } catch {}
function stageBgLabel() { const b = document.querySelector(".sbar .sbgb"); if (!b) return;
  b.querySelector("span").textContent = [tl("stageBg.1"), tl("stageBg.2"), tl("stageBg.3"), tl("stageBg.4")][STAGE_BGS.indexOf(stageBg)]; b.dataset.bg = stageBg; }
function nextStageBg() { stageBg = STAGE_BGS[(STAGE_BGS.indexOf(stageBg) + 1) % STAGE_BGS.length];
  try { localStorage.setItem("v2-stagebg", stageBg); } catch {}
  const st = document.getElementById("stage"); if (st) st.dataset.bg = stageBg; stageBgLabel(); }
// On 9:16 a dashed line also marks what the Shorts / Reels buttons and caption cover.
const GUIDES = ["", "9:16", "4:5", "1:1"];
let guide = ""; try { guide = localStorage.getItem("v2-guide") || ""; } catch {}
function nextGuide() { guide = GUIDES[(GUIDES.indexOf(guide) + 1) % GUIDES.length];
  try { localStorage.setItem("v2-guide", guide); } catch {}
  drawGuide(); toast(guide ? tl("nextGuide.1", {guide}) : tl("nextGuide.2")); }
function drawGuide() {
  const st = document.getElementById("stage"); if (!st) return;
  const btn = document.querySelector(".sbar .sguide"); if (btn) { btn.querySelector("span").textContent = guide || tl("itemView.51"); btn.classList.toggle("on", !!guide); btn.setAttribute("aria-pressed", String(!!guide)); }
  let lay = st.querySelector(".guide"); const m = st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video"), b = guide && m && mediaBox(m);
  if (!b) { lay?.remove(); return; }
  if (!lay) { lay = document.createElement("div"); lay.className = "guide"; lay.setAttribute("aria-hidden", "true"); st.appendChild(lay); }
  const [aw, ah] = guide.split(":").map(Number), sr = st.getBoundingClientRect();
  const h = Math.min(b.h, b.w * ah / aw), w = h * aw / ah;
  Object.assign(lay.style, {left: `${b.left - sr.left}px`, top: `${b.top - sr.top}px`, width: `${b.w}px`, height: `${b.h}px`});
  lay.innerHTML = `<i style="left:${(b.w - w) / 2}px;top:${(b.h - h) / 2}px;width:${w}px;height:${h}px">${guide === "9:16" ? "<u></u>" : ""}<b class="num">${guide}</b></i>`;
}
// The line under the comment box says which moment goes with the words, as it moves.
function cmWhen() {
  const el = document.getElementById("cmwhen"), vd = stageVideo(); if (!el || !vd) return;
  const r = abOf(vd), w = momentOf(vd, openItem?.pics[stageAt]);
  el.innerHTML = (w ? `<b class="num">${w}</b> ${tl("cmWhen.3", {p1: r ? tl("cmWhen.1") : tl("cmWhen.2")})}` : tl("cmWhen.4")) + (r ? "" : tl("cmWhen.5"));
}
// With an I-O loop set, a comment is about the whole stretch (Frame.io's range comment), not one frame.
const momentOf = (vd, f) => { const r = abOf(vd); return r ? spanWhen(r.a, r.b, f?.fps) : whenOf(vd, f); };
// "[file 0:05 f120]": where a video comment points, in words the department can read.
// Before anything is shown there is no moment; once a frame is up, 0:00 is one (a black first frame).
const whenOf = (vd, f) => !vd || (vd.currentTime <= 0 && vd.readyState < 2) ? "" : [clock(vd.currentTime), f?.fps ? `f${frameOf(vd.currentTime, f.fps)}` : ""].filter(Boolean).join(" ");
// ---- scene strip: stills pulled from the video in the browser (nothing is stored), one per
// shot when the version has a cut list, else ten across the length. Tap one to go there.
const stripCache = new Map();
let stripOn = false; try { stripOn = localStorage.getItem("strip") === "1"; } catch {}
async function stills(src, times) {
  const key = src + "|" + times.join(); if (stripCache.has(key)) return stripCache.get(key);
  const vd = Object.assign(document.createElement("video"), {muted: true, preload: "auto", src});
  const out = [];
  try {
    await new Promise((ok, no) => { vd.onloadeddata = ok; vd.onerror = no; });
    for (const t of times) {
      await new Promise((ok) => { vd.onseeked = ok; vd.currentTime = Math.min(t, vd.duration - 0.01); });
      const c = document.createElement("canvas"), w = 192; c.width = w; c.height = Math.round(w * vd.videoHeight / vd.videoWidth) || 108;
      c.getContext("2d").drawImage(vd, 0, 0, c.width, c.height); out.push(c.toDataURL("image/jpeg", 0.8));
    }
  } catch { return []; } finally { vd.removeAttribute("src"); vd.load(); }
  stripCache.set(key, out); return out;
}
// A file of a past version whose bytes were not kept when the file changed later: what shows
// may be the newer file, so it says so (short label, the why in the tooltip).
// A file whose bytes are not there - overwritten after this version (the server answers 410) or a
// referenced original that is missing (404) - shows a calm note instead of a broken picture.
const goneOf = (f) => f && (f.removed ? "removed" : f.past_lost ? "lost" : f.ref_state === "missing" ? "missing" : "");
const goneHtml = (f) => goneOf(f) === "removed"
  ? `<div class="sgone" role="note"><b>${tl("res.goneT")}</b><span>${tl("res.goneD")}</span></div>`
  : goneOf(f) === "lost"
  ? `<div class="sgone" role="note"><b>${tl("pastLost.1")}</b><span>${tl("pastLost.t")}</span></div>`
  : `<div class="sgone" role="note"><b>${tl("refMissing.1")}</b><span>${tl("refMissing.t")}</span></div>`;
const lostTag = (f) => f && f.past_lost ?`<em class="plost" title="${tl("pastLost.t")}">${tl("pastLost.1")}</em>` : "";
function wireStage(pics, shots) {
  const st = document.getElementById("stage");
  stageZoom = null;
  if (!st) return null;
  const tr = st.querySelector(".strk"), W = () => st.clientWidth, bar = st.nextElementSibling;
  let x = 0, stop = null, drag = null;
  const put = (v) => { x = v; tr.style.transform = `translate3d(${v}px,0,0)`; };
  const label = () => { bar.querySelector(".sname").innerHTML = esc(pics[stageAt].name) + lostTag(pics[stageAt]); bar.querySelector(".scount").textContent = pics.length > 1 ? `${stageAt + 1} / ${pics.length}` : "";
    // A video pushed with no sound track says so, so a silent cut is not mistaken for a muted player.
    bar.querySelector(".smute").hidden = !(pics[stageAt].kind === "video" && pics[stageAt].audio === false);
    document.querySelectorAll("#sgrid .sg").forEach((g) => { const a = +g.dataset.sg, b = g.dataset.sge ? +g.dataset.sge : a, on = stageAt >= a && stageAt <= b;
      g.classList.toggle("on", on);
      // A sequence tile follows the frame on the stage: its picture, number and scrub bar.
      if (on && b > a) { const f = pics[stageAt], r = g.querySelector(".sqr"); if (+r.value !== stageAt) r.value = stageAt;
        g.querySelector("img").src = f.thumb || f.url; g.querySelector(".sgn").textContent = f.name.replace(/\.[^.]+$/, ""); } }); sgShow();
    st.querySelector(".snav.l")?.classList.toggle("off", stageAt === 0); st.querySelector(".snav.r")?.classList.toggle("off", stageAt === pics.length - 1); tgtLabel(); stageFit?.(); readout(); flipBadge(); };
  // Frame stepping, the old review page's player the user asked to keep: the readout
  // follows the video on the stage, the buttons (and ← →) move one frame.
  const fs = bar.querySelector(".fstep");
  const readout = () => { const vd = stageVideo(), f = pics[stageAt]; fs.hidden = !vd;
    drawStrip(); drawMarks(); cmWhen(); drawPins(); showPlay(fs, vd);
    // Leave the readout alone while a frame is being typed into it (an open input lives here).
    if (vd && !fs.querySelector(".fnow input")) fs.querySelector(".fnow").textContent = (f.fps ? `f${frameOf(vd.currentTime, f.fps)}${f.frames ? " / " + (f.frames - 1) : ""}` : clock(vd.currentTime, true))
      + (abOf(vd) ? tl("wireStage.1", {abTxt: abTxt(abOf(vd), f)}) : ""); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked", "loadedmetadata"].forEach((ev) => vd.addEventListener(ev, readout)));
  // Buffering spinner, same pattern as the viewer's .vspin.
  tr.querySelectorAll("video").forEach((vd) => { const sp = vd.nextElementSibling;
    ["waiting", "stalled"].forEach((ev) => vd.addEventListener(ev, () => { sp.hidden = false; }));
    ["playing", "canplay", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { sp.hidden = true; }));
    // A file the browser cannot read as a video (cut off, still being written): say so instead of a black box.
    const bad = () => { if (!vd.error || vd.parentElement.querySelector(".sverr")) return; sp.hidden = true;
      const p = document.createElement("p"); p.className = "sverr"; p.setAttribute("role", "alert"); p.textContent = tl("vid.broken"); vd.after(p); };
    vd.addEventListener("error", bad); bad(); });
  // I and O set a stretch to go round while checking one move; X lets the whole run again.
  tr.querySelectorAll("video").forEach((vd) => vd.addEventListener("timeupdate", () => { const r = abOf(vd);
    if (r && !vd.paused && (vd.currentTime >= r.b || vd.currentTime < r.a - 0.05)) vd.currentTime = r.a; }));
  // Press and hold the step buttons to run through frames, faster the longer it is held; a tap is
  // one frame, and letting go stops on whatever frame it reached (stepFrame always lands on one).
  fs.querySelectorAll("[data-fs]").forEach((b) => holdStep(b, +b.dataset.fs));
  // The readout doubles as a jump box: tap it, type a frame (120 / f120), a clock (1:23) or 3.5s.
  fnowJump(fs.querySelector(".fnow"), () => pics[stageAt], readout);
  fs.querySelector(".frate").onclick = nextRate;
  bar.querySelector(".sguide").onclick = nextGuide;
  bar.querySelector(".sbgb").onclick = nextStageBg; stageBgLabel();
  // A big play button beside the frame steps: on a phone the video's own is two taps and small.
  const fp = fs.querySelector(".fplay"), playState = () => showPlay(fs, stageVideo());
  fp.onclick = () => { const vd = stageVideo(); if (!vd) return; vd.paused ? playNow(vd) : vd.pause(); };
  tr.querySelectorAll("video").forEach((vd) => ["play", "pause"].forEach((ev) => vd.addEventListener(ev, playState)));
  const strip = document.getElementById("fstrip"), scn = fs.querySelector(".fscn");
  let stripFor = null, marks = [];
  const drawStrip = async () => { const vd = stageVideo(), f = pics[stageAt];
    scn.classList.toggle("on", stripOn); scn.setAttribute("aria-pressed", String(stripOn));
    strip.hidden = !stripOn || !vd; if (strip.hidden || stripFor === f.url) return;
    stripFor = f.url; strip.innerHTML = loadingHtml(tl("wireStage.2"));
    if (!(vd.duration > 0)) await new Promise((ok) => vd.addEventListener("loadedmetadata", ok, {once: true}));
    marks = shots?.length ? shots.slice(0, 40).map((x) => x.start) : Array.from({length: 10}, (_, i) => vd.duration * (i + 0.05) / 10);
    const pics2 = await stills(f.play || f.url, marks);
    if (stripFor !== f.url) return;
    strip.innerHTML = pics2.length ? pics2.map((u, i) => `<button class="press" data-at="${i}" aria-label="${tl("wireStage.3", {clock: clock(marks[i])})}"><img src="${u}" alt=""><span class="num">${shots?.length ? "#" + shots[i].n : f.fps ? "f" + frameOf(marks[i], f.fps) : clock(marks[i], vd.duration < 20)}</span></button>`).join("")
      : `<span class="sub">${tl("wireStage.4")}</span>`;
    strip.querySelectorAll("[data-at]").forEach((b) => b.onclick = () => { const v2 = stageVideo(); if (!v2) return; v2.currentTime = marks[+b.dataset.at] + 0.001; });
    markStrip(); };
  // The scrub bar under the video: a hairline track with a played fill, the A-B loop range, a dot
  // per comment, and a playhead. Drag it (mouse or finger) to scrub 1:1, or grab a dot to a comment.
  const rail = document.getElementById("cmk");
  let railFor = null, tip = null;
  const seekTo = (clientX) => { const vd = stageVideo(); if (!vd || !(vd.duration > 0)) return;
    const r = rail.getBoundingClientRect(), p = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    vd.pause(); vd.currentTime = p * vd.duration; };
  const showTip = (clientX) => { const vd = stageVideo(), f = pics[stageAt]; if (!vd || !(vd.duration > 0)) return;
    if (!tip) { tip = document.createElement("div"); tip.className = "cmktip num"; document.body.appendChild(tip); }
    const r = rail.getBoundingClientRect(), p = Math.min(1, Math.max(0, (clientX - r.left) / r.width)), t = p * vd.duration;
    tip.textContent = f.fps ? `f${frameOf(t, f.fps)}` : clock(t, true);
    tip.style.left = Math.min(r.right, Math.max(r.left, clientX)) + "px"; tip.style.top = r.top + "px"; tip.hidden = false; };
  const hideTip = () => { if (tip) tip.hidden = true; };
  let scrub = null, wasPlaying = false;
  const hoverPC = matchMedia("(hover: hover)").matches;
  rail.addEventListener("pointerdown", (e) => { if (e.button || e.target.closest("button")) return;
    const vd = stageVideo(); if (!vd || !(vd.duration > 0)) return;
    e.preventDefault(); rail.setPointerCapture(e.pointerId); scrub = e.pointerId; wasPlaying = !vd.paused;
    seekTo(e.clientX); showTip(e.clientX); });
  rail.addEventListener("pointermove", (e) => { if (scrub === e.pointerId) { seekTo(e.clientX); showTip(e.clientX); }
    else if (scrub == null && hoverPC) showTip(e.clientX); });
  const endScrub = (e) => { if (scrub !== e.pointerId) return; scrub = null; hideTip();
    try { rail.releasePointerCapture(e.pointerId); } catch {}
    if (wasPlaying) { const vd = stageVideo(); if (vd) playNow(vd); } };
  rail.addEventListener("pointerup", endScrub);
  rail.addEventListener("pointercancel", endScrub);
  rail.addEventListener("pointerleave", () => { if (scrub == null) hideTip(); });
  const drawMarks = () => { const vd = stageVideo(), f = pics[stageAt];
    if (!vd) { rail.hidden = true; railFor = null; hideTip(); return; }
    const ms = (openItem?.marks || []).filter((m) => m.name ? m.name === f.name : pics.filter((g) => g.kind === "video").length === 1);
    rail.hidden = false;
    if (!(vd.duration > 0)) return vd.addEventListener("loadedmetadata", drawMarks, {once: true});
    const key = f.url + "|" + ms.length;
    if (railFor !== key) { railFor = key;
      // Marks on the same moment share one dot: two dots on one spot left the lower one unreachable.
      const spots = new Map();
      ms.forEach((m) => { const t = f.fps && m.frame != null ? (m.frame + 0.5) / f.fps : m.t, k = Math.min(100, t / vd.duration * 100).toFixed(2);
        const s = spots.get(k) || {t, k, prev: true, texts: []}; s.prev = s.prev && !!m.prev; s.texts.push(attOf(m.text).words.slice(m.tag.length, 120).trim() || tl("itemView.107")); spots.set(k, s); });
      rail.innerHTML = `<u class="cmkfill"></u><b class="cmkab" hidden></b>` + [...spots.values()].map((s) =>
        `<button class="press${s.prev ? " prev" : ""}" style="left:${s.k}%" data-mt="${s.t}" title="${esc(s.texts.join(" · "))}" aria-label="${tl("wireStage.5", {clock: clock(s.t)})}"></button>`).join("") + `<i></i>`;
      rail.querySelectorAll("[data-mt]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const v2 = stageVideo(); if (!v2) return; v2.currentTime = +b.dataset.mt; if (b.title) toast(b.title, 4500); }); }
    const pct = Math.min(100, vd.currentTime / vd.duration * 100);
    rail.querySelector("i").style.left = pct + "%"; rail.querySelector(".cmkfill").style.width = pct + "%";
    const r = abOf(vd), abEl = rail.querySelector(".cmkab");
    if (r) { abEl.hidden = false; abEl.style.left = (r.a / vd.duration * 100) + "%"; abEl.style.width = ((r.b - r.a) / vd.duration * 100) + "%"; }
    else abEl.hidden = true; };
  // The still for the moment on screen is outlined, so the strip doubles as a map.
  const markStrip = () => { const vd = stageVideo(); if (!vd || strip.hidden) return; let on = -1; marks.forEach((t, i) => { if (vd.currentTime + 0.01 >= t) on = i; });
    strip.querySelectorAll("[data-at]").forEach((b) => b.classList.toggle("on", +b.dataset.at === on)); };
  scn.onclick = () => { stripOn = !stripOn; try { localStorage.setItem("strip", stripOn ? "1" : "0"); } catch {} drawStrip(); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, markStrip)));
  // Buttons, keys and the grid cut straight to the other result - "슬라이드 빼줘, 바로바로 비교하게".
  // Only a finger that let go mid-drag springs the rest of the way, carrying its speed.
  // ---- zoom of the result on the stage (mouse): its own scale, apart from the app's screen size.
  // Same model as the full-screen viewer: scale and offset from the resting centre, the spot under
  // the pointer stays put, a drag pans 1:1 and keeps its speed on release. s = 1 is "fit"; the
  // number shown is the picture's real size (100% = one picture pixel per screen pixel).
  const zc = st.querySelector(".szoom"), zmouse = matchMedia("(hover:hover) and (pointer:fine)").matches;
  let z = {s: 1, tx: 0, ty: 0}, stopZ = null, pan = null, tapT = 0, lastUp = 0;
  const zm = () => st.querySelectorAll(".sl")[stageAt]?.querySelector("img,video") || null;
  const zfit = () => { const m = zm(), nw = m && (m.videoWidth || m.naturalWidth), nh = m && (m.videoHeight || m.naturalHeight);
    if (!nw || !nh) return null; const f = Math.min(W() / nw, st.clientHeight / nh); return {w: nw * f, h: nh * f, f}; };
  const zmax = () => { const b = zfit(); return Math.max(8, b ? 4 / b.f : 8); };
  const zb = (s) => { const b = zfit(); return b ? {x: Math.max(0, (b.w * s - W()) / 2), y: Math.max(0, (b.h * s - st.clientHeight) / 2)} : {x: 0, y: 0}; };
  const zon = () => z.s > 1.005;
  const zpaint = () => { const m = zm(), b = zfit();
    if (m) m.style.transform = zon() || z.tx || z.ty ? `translate3d(${z.tx}px,${z.ty}px,0) scale(${z.s})` : "";
    st.classList.toggle("zoomed", zon());
    if (!b && m) m.addEventListener(m.tagName === "VIDEO" ? "loadedmetadata" : "load", zpaint, {once: true});
    zc.querySelector(".zpct").textContent = b ? `${Math.round(z.s * b.f * 100)}%` : "";
    zc.querySelector('[data-z="-1"]').disabled = zc.querySelector('[data-z="0"]').disabled = !zon();
    zc.querySelector('[data-z="1"]').disabled = z.s >= zmax() - 0.001;
    if (zon() || st.querySelector(".pins,.guide")) { drawPins(); drawGuide(); } };
  const zto = (s, tx, ty, now) => { stopZ && stopZ(); stopZ = null; s = Math.max(1, Math.min(zmax(), s));
    const b = zb(s), to = s <= 1.005 ? {s: 1, tx: 0, ty: 0} : {s, tx: Math.max(-b.x, Math.min(b.x, tx)), ty: Math.max(-b.y, Math.min(b.y, ty))}, from = {...z};
    if (now || RM()) { z = to; return zpaint(); }
    let t = 0; stopZ = springTo(() => t, (v) => { t = v; z = {s: from.s + (to.s - from.s) * v, tx: from.tx + (to.tx - from.tx) * v, ty: from.ty + (to.ty - from.ty) * v}; zpaint(); }, 1, 0, () => { z = to; zpaint(); }, 0.3, 1); };
  // Zoom about a screen point (default: the middle of the stage).
  const zat = (s, px, py, now) => { const r = st.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    s = Math.max(1, Math.min(zmax(), s)); if (px == null) { px = cx; py = cy; }
    zto(s, (px - cx) - ((px - cx) - z.tx) / z.s * s, (py - cy) - ((py - cy) - z.ty) / z.s * s, now); };
  const zreset = () => { stopZ && stopZ(); stopZ = null; const m = zm(); if (m) m.style.transform = ""; z = {s: 1, tx: 0, ty: 0}; };
  // Fit <-> the real size at that spot (a picture already shown at its real size or bigger goes to 2.5x).
  const ztoggle = (px, py) => { const b = zfit(); if (!b) return; zon() ? zto(1, 0, 0) : zat(b.f < 0.98 ? 1 / b.f : 2.5, px, py); };
  stageZoom = {step: (d) => zat(z.s * (d > 0 ? 1.25 : 0.8)), fit: (now) => zto(1, 0, 0, now)};
  zc.querySelectorAll("[data-z]").forEach((b) => b.onclick = () => { const d = +b.dataset.z, f = zfit();
    if (d === 100) { if (f) zat(Math.max(1, 1 / f.f)); } else if (d) stageZoom.step(d); else stageZoom.fit(); });
  st.addEventListener("wheel", (e) => { if (!e.altKey || e.ctrlKey || !zfit() || drawing) return; e.preventDefault();
    zat(z.s * Math.exp(-e.deltaY * 0.0015), e.clientX, e.clientY, true); }, {passive: false});
  st.addEventListener("pointerdown", (e) => {
    if (!zon() || e.button || e.target.closest("button,.pins") || drawing) return;
    stopZ && stopZ(); stopZ = null;
    pan = {id: e.pointerId, x0: e.clientX, y0: e.clientY, z0: {...z}, moved: false, h: [[e.clientX, e.clientY, e.timeStamp]]};
  });
  st.addEventListener("pointermove", (e) => {
    if (!pan || e.pointerId !== pan.id) return;
    const dx = e.clientX - pan.x0, dy = e.clientY - pan.y0;
    if (!pan.moved) { if (Math.hypot(dx, dy) < 4) return; pan.moved = true; st.setPointerCapture(e.pointerId); st.classList.add("panning"); }
    const b = zb(z.s), H = st.clientHeight; let tx = pan.z0.tx + dx, ty = pan.z0.ty + dy;
    if (tx > b.x) tx = b.x + rubber(tx - b.x, W()); else if (tx < -b.x) tx = -b.x - rubber(-b.x - tx, W());
    if (ty > b.y) ty = b.y + rubber(ty - b.y, H); else if (ty < -b.y) ty = -b.y - rubber(-b.y - ty, H);
    z = {...z, tx, ty}; zpaint();
    pan.h.push([e.clientX, e.clientY, e.timeStamp]); if (pan.h.length > 5) pan.h.shift();
  });
  const panEnd = (e) => {
    if (!pan || e.pointerId !== pan.id) return; const p = pan; pan = null; st.classList.remove("panning");
    if (!p.moved) {                                         // a click while zoomed: twice goes back to fit
      if (e.type === "pointerup" && e.timeStamp - lastUp < 350) { lastUp = 0; zto(1, 0, 0); } else lastUp = e.timeStamp;
      return; }
    const a = p.h[0], c = p.h[p.h.length - 1], dt = Math.max(1, c[2] - a[2]), t = 0.35;
    zto(z.s, z.tx + (c[0] - a[0]) / dt * 1000 * t / 2, z.ty + (c[1] - a[1]) / dt * 1000 * t / 2);
  };
  st.addEventListener("pointerup", panEnd); st.addEventListener("pointercancel", panEnd);
  const go = (n, v0 = 0, now = false, glide = false) => {
    n = Math.max(0, Math.min(pics.length - 1, n));
    const moved = n !== stageAt;
    if (moved || now) zreset();              // another file, or the stage changed size: back to fit
    if (moved) tr.querySelectorAll("video").forEach((vd) => vd.pause());
    stageAt = n; label(); zpaint(); stop && stop();
    if (moved) playNow(stageVideo());      // going through several results: each one starts on arrival
    if (now || RM() || !glide) return put(-n * W());
    stop = springTo(() => x, put, -n * W(), v0, null, 0.36, 1);
  };
  tr.querySelectorAll("video").forEach((vd) => { vd.playbackRate = rate; });
  fs.querySelector(".frate").textContent = `${rate}×`; fs.querySelector(".frate").classList.toggle("on", rate !== 1);
  put(-stageAt * W()); label(); zpaint();
  st.querySelector(".snav.l")?.addEventListener("click", () => go(stageAt - 1));
  st.querySelector(".snav.r")?.addEventListener("click", () => go(stageAt + 1));
  const sw = document.getElementById("sgw");
  if (sw) document.getElementById("sgt").onclick = () => {
    const o = !sw.classList.contains("open");
    sw.classList.toggle("open", o); sgOpen(o);
    const t = document.getElementById("sgt"); t.setAttribute("aria-expanded", o); t.querySelector("em").textContent = o ? tl("itemView.30") : tl("itemView.31");
    sgShow();
  };
  document.querySelectorAll("#sgrid .sqr").forEach((r) => { r.oninput = () => go(+r.value); r.onclick = (e) => e.stopPropagation(); });
  document.querySelectorAll("#sgrid .sg").forEach((g) => g.onclick = () => {
    const a = +g.dataset.sg, b = g.dataset.sge ? +g.dataset.sge : a;
    go(stageAt >= a && stageAt <= b ? stageAt : a);
    if (st.getBoundingClientRect().top < 0) st.scrollIntoView({block: "start", behavior: RM() ? "auto" : "smooth"});
  });
  // Full screen picks the video up where the stage has it (moment and playing or not) and hands both back on close.
  st.querySelector(".sfull").onclick = () => { const sv = stageVideo(), at = stageAt;
    const from = sv ? {t: sv.currentTime, play: !sv.paused, back: (t, play) => { const v = stageAt === at && stageVideo(); if (!v) return; v.currentTime = t; if (play) playNow(v); }} : null;
    tr.querySelectorAll("video").forEach((vd) => vd.pause()); viewer(pics, stageAt, openItem, from); };
  // On a phone nothing sits on the picture: full screen joins the bar under it.
  if (!wide()) bar.querySelector(".sguide")?.after(st.querySelector(".sfull"));
  // ...and the bar is one row: play, the frame steps and readout, the flip chip, full screen, and a
  // … that holds the rest (speed, scenes, backdrop, aspect guide, 나란히) in a sheet.
  if (!wide()) { const mb = document.createElement("button"); mb.className = "smore press"; mb.title = tl("smore");
    mb.setAttribute("aria-label", tl("smore")); mb.setAttribute("aria-haspopup", "dialog"); mb.innerHTML = ic("more");
    bar.querySelector(".sfull")?.after(mb); mb.onclick = () => stageMore(bar); }
  // Pulling on past the first or last file steps a version: right to the older one, left to the
  // newer one, the same order as the compare bar (v010 → v011). A label says where it will land.
  const verTo = (over) => { const vs = openItem?.vers || [], i = vs.indexOf(openItem?.v); return over > 0 ? vs[i + 1] : i > 0 ? vs[i - 1] : null; };
  let hint = null;
  const pullHint = (over) => { const to = over && verTo(over), on = !!to && Math.abs(over) > W() * 0.3;
    if (!to) { hint?.remove(); hint = null; return; }
    if (!hint) { hint = document.createElement("div"); st.appendChild(hint); }
    hint.className = `vpull ${over > 0 ? "l" : "r"}${on ? " on" : ""}`; hint.textContent = on ? tl("vpull.1", {v: to}) : to; };
  st.addEventListener("pointerdown", (e) => {
    if (zon() || e.button || e.target.closest("button") || onControls(e) || (pics.length === 1 && e.target.closest("video"))) return;
    stop && stop();
    drag = {id: e.pointerId, x0: e.clientX, y0: e.clientY, s: x, dir: null, hist: [[e.clientX, e.timeStamp]], video: !!e.target.closest("video")};
  });
  st.addEventListener("pointermove", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
    if (!drag.dir) { if (Math.hypot(dx, dy) < 10) return; drag.dir = Math.abs(dx) > Math.abs(dy) ? "x" : "y"; if (drag.dir === "x") st.setPointerCapture(e.pointerId); }
    if (drag.dir !== "x") return;
    const min = -(pics.length - 1) * W();
    let nx = drag.s + dx;
    drag.over = nx > 0 ? nx : nx < min ? nx - min : 0; pullHint(drag.over);
    if (nx > 0) nx = rubber(nx, W()); else if (nx < min) nx = min + rubber(nx - min, W());
    put(nx); drag.hist.push([e.clientX, e.timeStamp]); if (drag.hist.length > 5) drag.hist.shift();
  });
  st.addEventListener("pointerup", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const d = drag; drag = null; pullHint(0);
    const to = d.dir === "x" && Math.abs(d.over || 0) > W() * 0.3 && verTo(d.over);
    if (to && openItem) { if (to === openItem.vers[0]) delete verPick[openItem.id]; else verPick[openItem.id] = to;
      stageAt = 0; toast(tl("vpull.2", {v: to})); again(); return; }
    if (d.dir === "x") { const a = d.hist[0], b = d.hist[d.hist.length - 1], v = b[1] > a[1] ? (b[0] - a[0]) / (b[1] - a[1]) * 1000 : 0;
      const n = Math.round(-(x + project(v)) / W());
      return go(Math.max(stageAt - 1, Math.min(stageAt + 1, n)), v, false, true); }
    // A tap on a picture opens it big. With a mouse a second click may follow (double-click =
    // fit <-> real size), so the first one waits a moment for it; a finger opens at once.
    if (!d.dir && !d.video) { const open = () => { tapT = 0; if (st.isConnected) viewer(pics, stageAt); };
      if (e.pointerType !== "mouse" || !zmouse) open();
      else if (tapT) { clearTimeout(tapT); tapT = 0; ztoggle(e.clientX, e.clientY); }
      else tapT = setTimeout(open, 240); }
    else if (d.dir === "y") go(stageAt, 0, false, true);
  });
  st.addEventListener("pointercancel", () => { pullHint(0); if (drag) { drag = null; go(stageAt, 0, false, true); } });
  return go;
}
// While a box is being typed in on a phone, the 승인/수정 요청 bar steps aside: with the
// keyboard up it otherwise covers most of what is left of the result.
// A box that is removed or hidden while it has the focus (the chat's back button, a list redrawn
// under the search field) sends no focusout, which left the tab bar hidden on the next screen:
// the class is read again from what has the focus (and is still drawn) on every screen change,
// when a chat closes (project.js phoneChat) and whenever the keyboard moves.
// The keyboard itself is measured too: a list redrawn under its search field drops the focus
// while the keys are still up, and the bar then sat on top of the keyboard, mid-screen.
const TYPES = "textarea, input, [contenteditable]:not([contenteditable=false])";
let kbFull = 0, kbWide = 0;
const kbUp = () => { const v = window.visualViewport; if (!v) return false;
  if (v.width !== kbWide) { kbWide = v.width; kbFull = 0; }
  kbFull = Math.max(kbFull, v.height);
  return kbFull - v.height > 150; };
const typingSync = () => { const a = document.activeElement;
  document.body.classList.toggle("typing", kbUp() || (!!a?.matches?.(TYPES) && a.getClientRects().length > 0)); };
addEventListener("focusin", (e) => { if (e.target.matches?.(TYPES)) document.body.classList.add("typing"); });
addEventListener("focusout", () => setTimeout(typingSync, 60));
addEventListener("hashchange", () => { setTimeout(typingSync, 0); setTimeout(typingSync, 400); });
addEventListener("pageshow", typingSync);
document.addEventListener("visibilitychange", typingSync);
visualViewport?.addEventListener("resize", () => setTimeout(typingSync, 60));
// A zoomed page must stay pinchable so it can be brought back (v2.css turns pinch off on app screens).
visualViewport?.addEventListener("resize", () => document.documentElement.classList.toggle("zoomed", visualViewport.scale > 1.01));
addEventListener("resize", () => { if ((detail?.[0] === "item" || wrLive()) && document.getElementById("stage")) stageGo?.(stageAt, 0, true); });
// Reading down a result on a phone, the decision bar steps out of the way; any move back up,
// the top or the end of the page brings it back.
{ let lastY = scrollY;
  addEventListener("scroll", () => {
    const y = scrollY, d = y - lastY;
    if (Math.abs(d) < 8) return; lastY = y;
    const hide = !wide() && detail?.[0] === "item" && d > 0 && y > 80 && y + innerHeight < document.documentElement.scrollHeight - 40;
    document.body.classList.toggle("ctahide", hide);
  }, {passive: true}); }
// Rows that scroll sideways (chips, tabs, strips) fade at the edge that has more, so a cut-off
// chip reads as "swipe for more" rather than as a clipped screen (user, 2026-09-29).
const EDGE_ROWS = ".chips,.settabs,.mtabs,.fstrip,.vtlstrip,.pinstrip,.tpics,.sgrid,.qpick,.uz-seg,.category-pill-group";
const edgeFade = (el) => { const max = el.scrollWidth - el.clientWidth;
  el.classList.toggle("efl", max > 2 && el.scrollLeft > 2); el.classList.toggle("efr", max > 2 && el.scrollLeft < max - 2); };
// A chip strip (filters, kinds, the received tabs) is rebuilt whole whenever its screen re-renders.
// Changing one filter should not throw the strip back to the start, so its scroll is kept per
// data-sk and restored when the new strip lands; and if the chosen chip ends up past the edge it is
// nudged just into view. Only horizontal scroll is touched, so the page never jumps.
const chipScroll = {}, chipSel = {};
const keepChip = (el) => { const k = el.dataset.sk; if (!k) return;
  const on = el.querySelector('.on,[aria-pressed="true"],[aria-selected="true"]');
  const idx = on ? [...el.children].indexOf(on) : -1, moved = chipSel[k] !== idx;
  if (chipScroll[k] != null) el.scrollLeft = chipScroll[k];   // keep where the reader left it
  // Only when a different chip was chosen do we pull it into view — an unrelated re-render
  // (zoom, a fresh push) must not drag the strip back to the selected chip.
  if (moved && on) { const er = el.getBoundingClientRect(), cr = on.getBoundingClientRect();
    if (cr.left < er.left + 8) el.scrollLeft -= er.left + 8 - cr.left;
    else if (cr.right > er.right - 8) el.scrollLeft += cr.right - er.right + 8; }
  chipSel[k] = idx; chipScroll[k] = el.scrollLeft; edgeFade(el); };
{ let raf = 0; const all = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => document.querySelectorAll(EDGE_ROWS).forEach(edgeFade)); };
  addEventListener("scroll", (e) => { const t = e.target; if (!t.matches?.(EDGE_ROWS)) return; edgeFade(t); if (t.dataset?.sk) chipScroll[t.dataset.sk] = t.scrollLeft; }, {capture: true, passive: true});
  addEventListener("resize", all);
  new MutationObserver((muts) => { all();
    for (const m of muts) for (const n of m.addedNodes) { if (n.nodeType !== 1) continue;
      if (n.dataset?.sk) keepChip(n); n.querySelectorAll?.("[data-sk]").forEach(keepChip); } }).observe(document.body, {childList: true, subtree: true}); }
// cmfold:begin
// The comment history starts folded: one line (the latest words) until the reader opens it.
// An opinion nobody has acted on yet (Astra's, last in the list) stays in sight, and `fresh`
// counts the ones that arrived since the last look. A single entry is never folded.
function cmFold(notes, open, seen) {
  const last = notes[notes.length - 1] || null, folded = !open && notes.length > 1;
  const keep = folded && last.kind === "astra" ? [last] : [];
  return {folded, keep, peek: folded && !keep.length ? last : null,
    fresh: folded && seen ? notes.filter((e) => e.kind === "astra" && e.at > seen).length : 0};
}
// cmfold:end
const cmOpen = () => lsGet("v2-cmopen") === "1";
const cmFull = new Set();                  // comments opened past three lines
let cmSeen = {id: "", at: ""}, cmFade = false;   // when this item's comments were last looked at; a fold just toggled
// Read once per visit to an item, then moved up to the newest entry, so "new" means since the last look.
function cmSeenOf(id, notes) {
  if (cmSeen.id === id) return cmSeen.at;
  let m = {}; try { m = JSON.parse(lsGet("v2-cmseen") || "{}") || {}; } catch {}
  cmSeen = {id, at: m[id] || ""};
  const last = notes[notes.length - 1];
  if (last) { delete m[id]; m[id] = last.at; const ks = Object.keys(m); ks.slice(0, Math.max(0, ks.length - 200)).forEach((k) => delete m[k]); lsSet("v2-cmseen", JSON.stringify(m)); }
  return cmSeen.at;
}
const logAll = {};                         // items whose whole comment log is open
const logF = {};                           // the 기록 filter chosen per item
// 버전 비교: the wipe, the two side by side, or the new one laid over the old (SyncSketch's
// ghosting) at a chosen strength. The way is kept per browser, the strength for the visit.
const CMPM = LT(() => ([["wipe", tl("CMPM.1")], ["side", tl("CMPM.2")], ["over", tl("CMPM.3")]]));
// "diff" is a fourth way, added only for two stills (see the cmp tab); it may sit in storage.
const cmpMode = (v) => { try { if (v === undefined) { const m = localStorage.getItem("v2-cmpm"); return (CMPM.some((c) => c[0] === m) || m === "diff") ? m : "wipe"; } localStorage.setItem("v2-cmpm", v); } catch { return "wipe"; } };
let cmpOp = 50, cmpThr = 24, cmpThrT = null;
// The compare workspace (cmpview.js): a compare-only screen over the app. `cvAuto` is the item whose
// timeline pick should open it as soon as the item has redrawn.
let cvAuto = null, cvScroll = 0;
// A comment left from the workspace goes on the version of the side it names; closing then redraws the item.
function openCmpWorkspace(item, vs, a, b, backTo, mode) {
  const [lo, hi] = [a, b].sort(), y = backTo == null ? scrollY : backTo;
  const it = openItem && {p: openItem.p, i: openItem.i};
  openCompareView({title: item?.title || "", a: lo, b: hi, mode, post: it,
    onClose: async (posted) => { scrollTo(0, y); if (posted) { await load(); again(); } },
    versions: vs.map((w) => ({v: w.v, at: w.at, summary: w.summary, files: w.files || []}))});
}
// 고쳤다고 함 → check the fix: the version the ask was written on (left/top) against the version
// that claims the fix (right/bottom), opened at the ask's spot or moment, with the ask, what the
// fix says changed, and 맞아/아직 bound to this directive's revision and the fixed version.
function openFixVerify(x, d, vs, ctx) {
  const has = (v) => vs.some((w) => w.v === v);
  if (!has(x.v) || !has(x.fixed_in)) return toast(tl("fixv.nover"));
  const e0 = (d.log || []).find((q) => q.id === x.id) || {text: x.text};
  const e = {...e0, rect: x.rect || e0.rect, file: x.file || e0.file};   // the directive row carries both now
  const region = regionOf(e), w = whenTag(e.text), p = pinOf(e.text);
  const src = vs.find((q) => q.v === x.v), fixV = vs.find((q) => q.v === x.fixed_in);
  const file = e.file || (p && p.name) || (w && w.name) || "";
  const fps = ((src.files || []).find((f) => f.name === file) || {}).fps || e.fps;
  const at = w ? (fps && w.frame != null ? (w.frame + 0.5) / fps : w.t) : 0;
  const where = region ? tl("fixv.where_box") : w ? tl("fixv.where_at", {t: w.tag.replace(/^\[|\]\s*$/g, "").replace(/위치\([^)]*\)/, "").trim()}) : p ? tl("fixv.where_pin") : tl("fixv.where_none");
  // The change note is whatever the fix carried; the fixed version's summary otherwise.
  const note = x.fix_note || x.claim?.note || x.claim_note || fixV.summary || "";
  const text = attOf((e.text || x.text || "").replace(/^\[[^\]]*\]\s*/, "")).words.trim();
  let changed = false;
  const after = (ok) => { changed = true; toast(ok ? tl("verdict.1") : tl("itemView.100")); return true; };
  const conflict = (err, ok, why) => { if (!isConflict(err)) throw err;
    // Only the same claim may be decided again here; a re-claim in another version needs a reload.
    const b = err.body || {}, can = !!(b.conflict && !b.stale && (b.fixed_in ?? null) === (x.fixed_in ?? null));
    changed = true;
    return {html: conflictHtml(b, ctx.latestV, d.log), again: ok ? tl("conflict.ok") : tl("conflict.again"),
      retry: can ? () => ctx.sayDir(x.id, ok, b.directive_rev, why).then(() => after(ok), (e2) => conflict(e2, ok, why)) : null}; };
  openCompareView({title: d.title || "", a: x.v, b: x.fixed_in,
    versions: vs.map((q) => ({v: q.v, at: q.at, summary: q.summary, files: q.files || []})),
    onClose: async () => { if (changed) { await load(); again(); } },
    verify: {text, note, cycle: x.cycle, file, region, at, where,
      decide: (ok, why) => ctx.sayDir(x.id, ok, undefined, why).then(() => after(ok), (err) => conflict(err, ok, why)),
      reload: () => { changed = true; }}});
}
// The compare state as an address: cmp=<viewed>,<other>&m=<mode>[&t=<seconds>]. The id may hold
// spaces or Korean, so it is used raw (as the 링크 복사 row does) — the query rides after the first
// "?", which a name never contains. `t` is dropped near zero so a still-frame link stays clean.
function cmpHashStr(id, viewed, other, mode, t, thr) {
  let s = "#item/" + id + "?cmp=" + viewed + "," + other + "&m=" + mode;
  if (mode === "diff" && thr != null) s += "&thr=" + thr;
  if (t != null && t > 0.05) s += "&t=" + Math.round(t * 10) / 10;
  return s;
}
function setCmpHash(id, viewed, other, mode, t, thr) {
  const s = cmpHashStr(id, viewed, other, mode, t, thr);
  if (location.hash !== s) history.replaceState(null, "", s);
}
// Back to a plain item address when leaving compare: drop the ?cmp=… query the item hash carries.
function setItemHash(id) {
  if (location.hash.startsWith("#item/") && location.hash.includes("?")) history.replaceState(null, "", "#item/" + id);
}
const loadImg = (src) => new Promise((ok, no) => { const im = new Image(); im.crossOrigin = "anonymous"; im.onload = () => ok(im); im.onerror = no; im.src = src; });
// 차이 mode: draw both stills onto one grid, mark every pixel that moved. Same-origin media, so
// the canvas stays untainted; if a picture will not load (or taints), the readout says so and the
// other modes still work. onRatio gets the changed fraction, or null when it could not be computed.
async function renderCmpDiff(c, aUrl, bUrl, threshold, onRatio) {
  const cv = c?.querySelector(".cdiff"); if (!cv || !aUrl || !bUrl) return onRatio?.(null);
  try {
    const [ia, ib] = await Promise.all([loadImg(aUrl), loadImg(bUrl)]);
    if (!c.isConnected) return;
    const tw = Math.min(ib.naturalWidth || 1024, 1024) || 1024;
    const th = Math.max(1, Math.round(tw * (ib.naturalHeight || 1) / (ib.naturalWidth || 1)));
    const grab = (img) => { const o = document.createElement("canvas"); o.width = tw; o.height = th;
      const g = o.getContext("2d"); g.drawImage(img, 0, 0, tw, th); return g.getImageData(0, 0, tw, th).data; };
    const r = diffPixels(grab(ia), grab(ib), tw, th, {threshold});
    cv.width = tw; cv.height = th;
    cv.getContext("2d").putImageData(new ImageData(r.data, tw, th), 0, 0);
    onRatio?.(r.ratio);
  } catch { onRatio?.(null); }
}
// Every key on one sheet: the line under the result only fits the common few.
function keysSheet() {
  const K = [["← →", tl("keysSheet.1")], [", .", tl("keysSheet.2")], ["↑ ↓", tl("keysSheet.3")], ["PgUp PgDn", tl("itemView.84")], ["[", tl("keyHelp.2")], ["]", tl("keysSheet.23")], ["Space", tl("keysSheet.4")],
    ["Home End", tl("keysSheet.5")], ["0 – 9", tl("keysSheet.6")], ["Alt+1 ~ 5", tl("keysSheet.7")], ["M", tl("keysSheet.8")], ["I O", tl("keysSheet.9")], ["X", tl("keysSheet.10")], ["S", tl("itemView.47")], ["J K L", tl("keysSheet.11")], ["F", tl("keybar.focus")], ["T", tl("keysSheet.12")], ["H", tl("keysSheet.13")],
    ["C", tl("itemView.88")], ["P", tl("itemView.106")], ["Esc", tl("keysSheet.14")], ["D", tl("keysSheet.15")],
    ["\\", tl("keysSheet.16")], ["V", tl("keysSheet.17")], ["A", tl("keysSheet.18")], ["R", tl("cmt.1")],
    ["N", tl("nextCard.3")], ["Shift+N", tl("keybar.prev")], ["↑ ↓", tl("keysSheet.24")], ["1 2 3", tl("keysSheet.21")], ["Enter", tl("itemView.38")], ["+ − 0", tl("keysSheet.19")],
    ["W", tl("keybar.width")], ["B", tl("keybar.cmp")], ["Esc", tl("keybar.back")], ["?", tl("keybar.toggle")]];
  sheet(`<h3>${tl("keysSheet.20")}</h3><dl class="keysall">${K.map(([a, b]) => `<dt>${a.split(" ").map((x) => `<b>${x}</b>`).join(" ")}</dt><dd>${b}</dd>`).join("")}</dl>`, () => {});
}
// A result mounted somewhere other than its own page (the workroom's stage, the phone's result
// sheet): {el, id, key}. Redraws go there; leaving the room or closing the sheet drops it.
let stageMount = null;
const wrLive = () => !!(stageMount && stageMount.el.isConnected);
// A redraw of the open item is the same page: no entry animation (it would carry the docked box off with it).
// An open result asks after itself every 5s, so a new version or a session's answer shows without leaving
// the page. Not while a comment is being written, a drawing is on, a sheet is up or the video plays.
setInterval(async () => {
  if (document.hidden || FLOAT || detail?.[0] !== "item" || !itemSig.startsWith(detail[1] + "|")) return;
  const id = detail[1], [p, ...r] = id.split("/"), d = await itemDetail(p, r.join("/"));
  if (!d || detail?.[1] !== id || itemSigOf(id, d) === itemSig) return;
  const el = document.activeElement, v = stageVideo();
  if ((el?.matches?.("input,textarea") && el.value) || drawing || (v && !v.paused) || document.getElementById("sheet").classList.contains("on")) return;
  await load(); if (detail?.[1] === id) again();
}, 5000);
const again = () => { V().classList.add("still"); if (wrLive()) itemView(stageMount.id, stageMount.el); else if (detail?.[0] === "item") itemView(detail[1]); };
// 담당자/마감일 칩을 눌렀을 때 그 자리에서 입력창으로 바뀌는 편집 UI (§4.15). cmEdit의
// "클릭하면 그 자리가 입력창" 패턴을 그대로 따름 - 저장/취소는 again()으로 다시 그려서 닫음.
function wireImetaEdit(box, field, p, i, d) {
  const wrap = box.querySelector("#imeta");
  if (!wrap) return;
  const cur = field === "due" ? (d.meta?.due || "") : (d.meta?.assignee || "");
  const flabel = field === "due" ? tl("itemView.169") : tl("itemView.168");
  wrap.innerHTML = `<div class="imedbox">
    <input class="imedin" type="${field === "due" ? "date" : "text"}" value="${esc(cur)}"
      ${field === "assignee" ? `maxlength="80" placeholder="${flabel}"` : ""}
      aria-label="${flabel}">
    ${cur ? `<button class="btn sm weak press" data-imclear type="button">${tl("itemView.174")}</button>` : ""}
    <button class="btn sm press" data-imcx type="button">${tl("cmEdit.7")}</button>
    <button class="btn sm fill press" data-imok type="button">${tl("cmEdit.8")}</button></div>`;
  const inp = wrap.querySelector(".imedin");
  inp.focus();
  const save = async (clear) => {
    const body = {p, i, [field]: clear ? "" : (field === "due" ? inp.value : inp.value.trim())};
    try { const r = await post("/api/meta", body); d.meta = r.meta || {}; again(); }
    catch (e) { toast(e.message || tl("get.1")); }
  };
  wrap.querySelector("[data-imok]").onclick = () => save(false);
  wrap.querySelector("[data-imclear]")?.addEventListener("click", () => save(true));
  wrap.querySelector("[data-imcx]").onclick = () => again();
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") save(false);
    else if (e.key === "Escape") again(); });
}
// ---- \ (or the ⇄ button): the file on the stage swaps with the same file of the compared
// version, at the same moment, and back. The button says which version is showing.
function flipStage() {
  const it = openItem, sl = document.querySelectorAll("#stage .sl")[stageAt], m = sl?.querySelector("img,video"), f = it?.pics[stageAt];
  if (!m || !it.alt) return;
  const same = (w) => w.files.find((x) => x.name === f.name && x.kind === f.kind);
  // A file new in the chosen version's successor: fall back to the nearest older one that has it.
  let src0 = same(it.alt) ? it.alt : (it.olds || []).find(same), o = src0 && same(src0);
  if (!o && it.pics.length === 1) { src0 = it.alt; o = it.alt.files.find((x) => x.kind === f.kind); }
  if (!o && !sl.dataset.alt) return toast(tl("flipStage.1"));
  const on = !sl.dataset.alt, g = on ? o : f, src = f.kind === "video" ? g.play || g.url : g.url;
  if (on) sl.dataset.alt = src0.v; else delete sl.dataset.alt;
  if (m.tagName === "VIDEO") { const t = m.currentTime, play = !m.paused;
    m.addEventListener("loadedmetadata", () => { m.playbackRate = rate; m.currentTime = Math.min(t, m.duration || t); if (play) playNow(m); }, {once: true});
    m.src = src; }
  else m.src = src;
  flipBadge();
}
function flipBadge() {
  const b = document.querySelector(".sbar .sflip"); if (!b) return;
  const alt = document.querySelectorAll("#stage .sl")[stageAt]?.dataset.alt;
  b.classList.toggle("on", !!alt); b.setAttribute("aria-pressed", String(!!alt));
  b.querySelector("span").textContent = alt ? tl("flipBadge.1", {alt}) : openItem?.alt?.v ? tl("flipBadge.0", {v: openItem.alt.v}) : "";
}
// ---- drawing: pen, arrow and box over the picture or the paused frame, kept in the picture's
// own 0-1 space, then burnt into the full-size picture and sent with the comment. D starts it,
// Enter (or D) finishes, Esc drops it.
let drawing = null, drawPic = null;
const INK = ["#ff3b30", "#ffd60a", "#32d7ff"];
function inkStroke(g, s, b) {
  const P2 = (p) => [b.x + p[0] * b.w, b.y + p[1] * b.h], lw = Math.max(3, b.w * 0.005);
  g.strokeStyle = g.fillStyle = s.c; g.lineWidth = lw; g.lineCap = g.lineJoin = "round"; g.beginPath();
  if (s.t === "pen") { s.p.forEach((p, n) => { const [x, y] = P2(p); n ? g.lineTo(x, y) : g.moveTo(x, y); });
    if (s.p.length === 1) { const [x, y] = P2(s.p[0]); g.lineTo(x + 0.1, y); } g.stroke(); return; }
  const [x0, y0] = P2(s.p[0]), [x1, y1] = P2(s.p[s.p.length - 1]);
  if (s.t === "rect") { g.strokeRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)); return; }
  if (s.t === "ellipse") { g.ellipse((x0 + x1) / 2, (y0 + y1) / 2, Math.abs(x1 - x0) / 2, Math.abs(y1 - y0) / 2, 0, 0, 2 * Math.PI); g.stroke(); return; }
  const a = Math.atan2(y1 - y0, x1 - x0), hl = Math.max(lw * 4, 14);
  g.moveTo(x0, y0); g.lineTo(x1 - hl * 0.6 * Math.cos(a), y1 - hl * 0.6 * Math.sin(a)); g.stroke();
  g.beginPath(); g.moveTo(x1, y1); g.lineTo(x1 - hl * Math.cos(a - 0.45), y1 - hl * Math.sin(a - 0.45)); g.lineTo(x1 - hl * Math.cos(a + 0.45), y1 - hl * Math.sin(a + 0.45)); g.closePath(); g.fill();
}
function startDraw() {
  const st = document.getElementById("stage"), m = st?.querySelectorAll(".sl")[stageAt]?.querySelector("img,video");
  if (!m || drawing) return;
  stageZoom?.fit(true);                      // the drawing layer is laid over the picture at rest
  if (m.tagName === "VIDEO") { m.pause(); if (m.readyState < 2) return toast(tl("startDraw.1")); }
  else if (!m.naturalWidth) return toast(tl("startDraw.2"));
  if (pinning) { pinning = false; drawPins(); pinLabel(); }
  const lay = document.createElement("div"); lay.className = "drawl";
  lay.innerHTML = `<canvas aria-label="${tl("startDraw.9")}"></canvas><div class="dtools" role="toolbar" aria-label="${tl("startDraw.10")}">
    ${[["pen", tl("startDraw.3")], ["arrow", tl("startDraw.4")], ["rect", tl("startDraw.5")], ["ellipse", tl("draw.tool.ellipse")]].map(([k, n]) => `<button class="press" data-dt="${k}" aria-label="${n}" title="${n}">${ic(k)}</button>`).join("")}<i></i>
    ${INK.map((c, n) => `<button class="press ink" data-dc="${c}" style="--c:${c}" aria-label="${[tl("startDraw.6"), tl("startDraw.7"), tl("startDraw.8")][n]}"></button>`).join("")}<i></i>
    <button class="press" data-dz aria-label="${tl("toggleFav.3")}" title="${tl("startDraw.11")}">${ic("undo")}</button>
    <button class="press" data-dclr aria-label="${tl("draw.clear")}" title="${tl("draw.clear")}">${ic("eraser")}</button><span class="grow"></span>
    <button class="press dq" data-dq>${tl("libDraw.22")}</button><button class="press dok" data-dk>${tl("startDraw.12")}</button></div>`;
  st.appendChild(lay); st.classList.add("drawing");
  const cv = lay.querySelector("canvas"), g = cv.getContext("2d");
  const box = () => { const r = st.getBoundingClientRect(), b = mediaBox(m); return b && {x: b.left - r.left, y: b.top - r.top, w: b.w, h: b.h}; };
  const d = drawing = {m, at: stageAt, t: "pen", c: INK[0], strokes: [], lay};
  const paint = () => { const k = devicePixelRatio || 1, w = st.clientWidth, h = st.clientHeight;
    if (cv.width !== Math.round(w * k) || cv.height !== Math.round(h * k)) { cv.width = Math.round(w * k); cv.height = Math.round(h * k); }
    g.setTransform(k, 0, 0, k, 0, 0); g.clearRect(0, 0, w, h); const b = box(); if (b) d.strokes.forEach((s) => inkStroke(g, s, b)); };
  const tools = () => { lay.querySelectorAll("[data-dt]").forEach((b) => b.classList.toggle("on", b.dataset.dt === d.t));
    lay.querySelectorAll("[data-dc]").forEach((b) => b.classList.toggle("on", b.dataset.dc === d.c));
    lay.querySelector("[data-dz]").disabled = lay.querySelector("[data-dclr]").disabled = !d.strokes.length; };
  const undo = () => { d.strokes.pop(); paint(); tools(); };
  const clearAll = () => { if (!d.strokes.length) return; d.strokes = []; paint(); tools(); };
  // The finger draws 1:1: every coalesced point goes in, not only the ones a frame gets to.
  let now = null;
  const at = (e, b) => { const r = st.getBoundingClientRect(); return [(e.clientX - r.left - b.x) / b.w, (e.clientY - r.top - b.y) / b.h]; };
  cv.addEventListener("pointerdown", (e) => { e.stopPropagation(); e.preventDefault(); const b = box(); if (!b || now) return;
    cv.setPointerCapture(e.pointerId); now = {t: d.t, c: d.c, p: [at(e, b)], id: e.pointerId, b}; d.strokes.push(now); paint(); });
  cv.addEventListener("pointermove", (e) => { if (!now || e.pointerId !== now.id) return; e.stopPropagation();
    if (now.t === "pen") (e.getCoalescedEvents?.() || [e]).forEach((q) => now.p.push(at(q, now.b))); else now.p[1] = at(e, now.b); paint(); });
  const up = (e) => { if (!now || e.pointerId !== now.id) return; e.stopPropagation();
    const s = now; now = null;
    // A tap with the arrow or the box draws nothing: drop it rather than leave a dot.
    if (s.t !== "pen" && (!s.p[1] || Math.hypot((s.p[1][0] - s.p[0][0]) * s.b.w, (s.p[1][1] - s.p[0][1]) * s.b.h) < 6)) d.strokes.pop();
    paint(); tools(); };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
  lay.querySelector(".dtools").addEventListener("pointerdown", (e) => e.stopPropagation());
  lay.querySelectorAll("[data-dt]").forEach((b) => b.onclick = () => { d.t = b.dataset.dt; tools(); });
  lay.querySelectorAll("[data-dc]").forEach((b) => b.onclick = () => { d.c = b.dataset.dc; tools(); });
  lay.querySelector("[data-dz]").onclick = undo;
  lay.querySelector("[data-dclr]").onclick = clearAll;
  lay.querySelector("[data-dq]").onclick = () => endDraw(false);
  lay.querySelector("[data-dk]").onclick = () => endDraw(true);
  d.key = (e) => { if (e.target.closest?.("input,textarea")) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); endDraw(false); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); undo(); }
    else if (e.key === "Enter" || (e.key.toLowerCase() === "d" && !e.ctrlKey && !e.metaKey)) { e.preventDefault(); e.stopPropagation(); endDraw(true); } };   // stopped: the page's own Enter (viewer) and D (draw again) must not fire on the same press
  addEventListener("keydown", d.key, true);
  d.ro = new ResizeObserver(paint); d.ro.observe(st);
  tools(); paint();
  if (!wide()) st.scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"});
}
async function endDraw(keep) {
  const d = drawing; if (!d) return; drawing = null;
  removeEventListener("keydown", d.key, true); d.ro.disconnect(); d.lay.remove(); document.getElementById("stage")?.classList.remove("drawing");
  if (!keep || !d.strokes.length) return;
  // A picture is burnt in at its own full size (PNG, capped high only to guard memory); a video
  // frame at its display resolution. The vector below replays crisply at any size regardless.
  const m = d.m, isImg = m.tagName !== "VIDEO", nw = m.videoWidth || m.naturalWidth, nh = m.videoHeight || m.naturalHeight;
  const k = Math.min(1, (isImg ? 8192 : 2560) / Math.max(nw, nh));
  const c = document.createElement("canvas"); c.width = Math.round(nw * k); c.height = Math.round(nh * k);
  const g = c.getContext("2d");
  let blob;
  try { g.drawImage(m, 0, 0, c.width, c.height); d.strokes.forEach((s) => inkStroke(g, s, {x: 0, y: 0, w: c.width, h: c.height}));
    blob = await new Promise((ok, no) => c.toBlob((b) => b ? ok(b) : no(new Error()), "image/png")); }
  catch { return toast(tl("endDraw.1")); }
  if (drawPic) URL.revokeObjectURL(drawPic.url);
  // Keep the strokes (in the picture's 0-1 space) and which file they were drawn on, so the
  // comment can store the vector and the viewer can replay it on the media (see draw.js).
  drawPic = {blob, url: URL.createObjectURL(blob), id: openItem?.id,
    strokes: d.strokes.map((s) => ({t: s.t, c: s.c, p: s.p})), file: openItem?.pics?.[d.at]?.name || null};
  cmShow();
  showDrawPic();
  if (wide()) document.getElementById("cm")?.focus({preventScroll: true});
  else if (document.querySelector(".cbox")?.closest(".mounted")) setTimeout(() => document.querySelector(".cbox")?.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"}), 250);
}
// The finished drawing sits over the comment box until it is sent or taken off.
function showDrawPic() {
  const el = document.getElementById("drawchip"), t = document.getElementById("cm"), add = document.getElementById("cmadd"); if (!el) return;
  const on = drawPic && drawPic.id === openItem?.id; el.hidden = !on;
  el.innerHTML = on ? `<a href="${drawPic.url}" target="_blank" rel="noopener"><img src="${drawPic.url}" alt="${tl("showDrawPic.1")}"></a><span class="tx">${tl("showDrawPic.2")}</span><button class="ib press" id="drawx" aria-label="${tl("showDrawPic.3")}">${ic("x")}</button>` : "";
  if (add && t) { add.disabled = !t.value.trim() && !on && !(cmImgs[openItem?.id] || []).length; document.getElementById("cdk")?.classList.toggle("has", !add.disabled); }
  document.getElementById("drawx")?.addEventListener("click", () => { URL.revokeObjectURL(drawPic.url); drawPic = null; showDrawPic(); });
}
// The I-O stretch of the file on the stage, kept by item and file so a redraw keeps it.
const loops = {};
const abKey = () => openItem && `${openItem.id}#${stageAt}`;
// Frames when the file knows its rate: a two-second clip read "0:00–0:01" in seconds.
const abTxt = (r, f) => f?.fps ? `f${frameOf(r.a, f.fps)}–f${frameOf(r.b, f.fps)}` : `${clock(r.a, true)}–${clock(r.b, true)}`;
const abOf = (vd) => { const r = vd && vd === stageVideo() && loops[abKey()]; return r && r.b > r.a ? r : null; };
function setAB(k, vd) {
  const key = abKey(), r = loops[key] || {a: 0, b: vd.duration || 0};
  if (k === "x") { delete loops[key]; toast(tl("setAB.1")); }
  else { r[k === "i" ? "a" : "b"] = vd.currentTime; if (!Number.isFinite(r.b) || r.b <= r.a) r.b = Number.isFinite(vd.duration) ? vd.duration : r.a;
    loops[key] = r; toast(r.b > r.a ? tl("noteText.3", {abTxt: abTxt(r, openItem.pics[stageAt])}) : tl("setAB.2")); }
  vd.dispatchEvent(new Event("seeked"));
}
// Real text fields keep the keys; everything else is fair game for the item shortcuts.
const typingIn = (el) => !!(el && el.closest && el.closest("input,textarea,gk-select,[contenteditable]"));
// A pointer press leaves focus on the control it hit - a <video> or a button would then swallow
// the next Space / arrow. After a genuine click inside the result, hand focus back to the page so
// the shortcuts keep working (a keyboard-driven click, detail 0, keeps its focus for a11y).
addEventListener("click", (e) => { if (e.detail <= 0) return; const a = document.activeElement;
  if (a && a !== document.body && !typingIn(a) && a.closest?.("#stage,.detailcols")) a.blur(); }, true);
addEventListener("keydown", (e) => {
  if (!(detail?.[0] === "item" || wrLive()) || !openItem || drawing || e.ctrlKey || e.metaKey || e.altKey || (e.repeat && !/^arrow/i.test(e.key) && e.key !== "," && e.key !== ".")) return;
  if (typingIn(e.target) || document.querySelector(".vw,.viewmenu.on") || document.getElementById("sheet")?.classList.contains("on")) return;
  const k = e.key.toLowerCase(), vd = stageVideo();
  if (k === "escape" && pinning) { pinning = false; drawPins(); pinLabel(); return; }
  // Space and Enter on a focused button or link are that button's press, not the page's.
  if ((k === " " || k === "enter") && e.target.closest?.("button,a,summary,[role=switch]")) return;
  // 1/2/3 (·4) switch the compare mode while a comparison is open. It claims the number keys
  // ahead of the video's 0–9 jump, so the two versions on screen answer 밀기·나란히·겹치기·차이.
  const cmBtns = document.querySelectorAll("#tbody [data-cm]");
  if (cmBtns.length && /^[1-4]$/.test(k)) { const b = cmBtns[+k - 1]; if (b) { e.preventDefault(); b.click(); } return; }
  // On a video the arrows step frames, as on the old review page; PgUp / PgDn still change files.
  if (vd && (k === "arrowleft" || k === "arrowright")) { e.preventDefault(); stepFrame((k === "arrowright" ? 1 : -1) * (e.shiftKey ? 10 : 1)); }
  else if (vd && (k === "home" || k === "end")) { e.preventDefault(); if (k === "home") vd.currentTime = 0; else if (Number.isFinite(vd.duration)) vd.currentTime = Math.max(0, vd.duration - 0.001); }
  else if (vd && k === "s") nextRate();
  else if (vd && (k === "j" || k === "k" || k === "l")) jkl(k, vd);
  // , and . step one frame (YouTube's keys); ↑ ↓ jump a second; 0–9 jump to 0%–90%; M walks the comments.
  else if (vd && (k === "," || k === ".")) { e.preventDefault(); stepFrame(k === "." ? 1 : -1); }
  else if (vd && (k === "arrowup" || k === "arrowdown")) { e.preventDefault();
    const end = Number.isFinite(vd.duration) ? vd.duration - 0.001 : Infinity; vd.currentTime = Math.max(0, Math.min(end, vd.currentTime + (k === "arrowup" ? 1 : -1))); }
  else if (vd && /^[0-9]$/.test(k) && Number.isFinite(vd.duration)) { e.preventDefault(); vd.currentTime = vd.duration * (+k) / 10; }
  else if (vd && k === "m") jumpMark(e.shiftKey ? -1 : 1);
  // T: the aspect guide. F belongs to focus mode alone (web/custom.js) - one key, one thing.
  else if (k === "t" && openItem.pics.length) nextGuide();
  else if (k === "h") snoozeSheet(openItem.id);
  else if (vd && (k === "i" || k === "o" || k === "x")) setAB(k, vd);
  else if (vd && k === " ") { e.preventDefault(); vd.paused ? vd.play().catch(() => {}) : vd.pause(); }
  // Files step on the arrows (a still) and PgUp / PgDn (also on a video, whose arrows are frames).
  // [ and ] are not file keys: they fold the left menu and the right panel on every page.
  else if (k === "arrowleft" || k === "arrowright" || k === "pageup" || k === "pagedown") { if (!stageGo) return; e.preventDefault(); stageGo(stageAt + (k === "arrowright" || k === "pagedown" ? 1 : -1)); }
  // ↓ moves to the next item (same as N) and ↑ to the one before (Shift+N) when the stage is not
  // a video — a video keeps ↑ ↓ for the one-second jump above.
  else if ((k === "arrowdown" || k === "arrowup") && !vd) { if (wrLive()) return; const n = (k === "arrowup" ? prevOf : nextOf)(openItem.id); if (n) { e.preventDefault(); autoPlay = true; nav("item/" + iid(n)); } }
  // A and R decide what the buttons decide: the newest version, not a finished one.
  else if ((k === "a" || k === "r") && (!openItem.latest || (openItem.archived && openItem.status === "approved"))) return;
  else if (k === "a" && openItem.status !== "approved") decide("approved");
  else if (k === "r") decide("changes");
  // N the next result waiting, Shift+N the one before (as V / Shift+V walk versions).
  else if (k === "n") { if (wrLive()) return; const n = (e.shiftKey ? prevOf : nextOf)(openItem.id); if (n) { autoPlay = true; nav("item/" + iid(n)); } }
  else if (k === "p" && openItem.pics.length) { cmShow(); document.getElementById("pinbtn")?.click(); }
  else if (k === "d" && openItem.pics.length) { e.preventDefault(); cmShow(); startDraw(); }
  else if (e.key === "\\" && openItem.alt && openItem.pics.length) flipStage();
  // V goes back a version, Shift+V forward, without the version sheet.
  else if (k === "v") { const vs = openItem.vers, n = vs.indexOf(openItem.v) + (e.shiftKey ? -1 : 1); if (n < 0 || n >= vs.length) return toast(n < 0 ? tl("setAB.3") : tl("setAB.4"));
    if (n) verPick[openItem.id] = vs[n]; else delete verPick[openItem.id]; again(); }
  else if (k === "c") { e.preventDefault(); cmShow(); document.getElementById("cm")?.focus(); }
  else if ((k === " " || k === "enter") && openItem.pics.length) { e.preventDefault(); viewer(openItem.pics, stageAt); }
  else if (e.key === "?") keyBarToggle();
  else return;
});
