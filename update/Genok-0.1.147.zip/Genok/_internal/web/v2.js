// Genok: see what an agent made, compare versions, and say what to change.
// Four tabs - 내 차례, 프로젝트, 결과물, 설정. Plain script, no build; it reads /api.

let D = {sessions: [], board: [], usage: {}, items: [], ins: {ready: false}, codex: [], places: [], agents: [], pins: [], hidden: [], favs: null, keys: {}, room_read: {}, at: null};

// UI text lives in web/i18n/ko.json (served as /i18n.js). tl(key, {name}) fills in each {name};
// a missing key shows the key itself, so a gap is visible rather than blank.
// The unit of work is one word everywhere, "폴더". Text never spells the word: ko.json and the
// code say {unit}, and a particle that depends on how the word ends is a token too - {unit}{을}
// reads 폴더를.
//   {unit}                the word            {units} {Unit} {Units}: English plural / capital
//   {을} {이} {은} {와} {로} {예요} {라} {나} {랑} {든}   (either form of a pair: {을} = {를})
// unitname.py holds the same rules for server text; tests/unit.test.js keeps the two in step and
// fails when a new string spells the default word instead of {unit}.
// unit:begin
const UNIT_DEF = {ko: "폴더", en: "folder"};
const JOSA_PAIRS = [["을", "를"], ["이", "가"], ["은", "는"], ["과", "와"], ["으로", "로"], ["이에요", "예요"],
  ["이라", "라"], ["이나", "나"], ["이랑", "랑"], ["이든", "든"]];
const JOSA = JOSA_PAIRS.reduce((o, p) => (o[p[0]] = o[p[1]] = p, o), {});
const JOSA_RE = /\{(이에요|예요|으로|이라|이나|이랑|이든|을|를|이|가|은|는|과|와|로|라|나|랑|든)\}/g;
const DIGIT_END = {0: 1, 1: 2, 2: 0, 3: 1, 4: 0, 5: 0, 6: 1, 7: 2, 8: 2, 9: 0};   // 영 일 이 삼 사 오 육 칠 팔 구
// How a text ends, by its last letter or digit: 0 a vowel, 1 a final consonant, 2 the consonant ㄹ
// (로, not 으로). Hangul is read off the syllable, a digit by its Korean reading, a Latin letter by
// a guess: l is ㄹ, m / n / ng a consonant, anything else a vowel (Team 팀, Folder 폴더).
const endSound = (text) => {
  const s = String(text || "");
  let i = s.length - 1;
  while (i >= 0 && !/[\p{L}\p{N}]/u.test(s[i])) i--;
  if (i < 0) return 0;
  const ch = s[i], c = ch.charCodeAt(0);
  if (c >= 0xAC00 && c <= 0xD7A3) { const j = (c - 0xAC00) % 28; return j === 0 ? 0 : j === 8 ? 2 : 1; }
  if (ch in DIGIT_END) return DIGIT_END[ch];
  const low = ch.toLowerCase();
  if (low === "l") return 2;
  if (low === "m" || low === "n") return 1;
  if (low === "g" && i > 0 && s[i - 1].toLowerCase() === "n") return 1;
  return 0;
};
const josa = (text, token) => {
  const p = JOSA[token]; if (!p) return token;
  const f = endSound(text);
  return p[0] === "으로" ? (f === 1 ? "으로" : "로") : (f ? p[0] : p[1]);
};
// The word the person picked ("" while it is the default). names.unit is where it lived before.
const unitCustom = () => "";
const unitPlural = (w) => !/[a-z]$/i.test(w) ? w : /(s|x|z|ch|sh)$/i.test(w) ? w + "es" : /[^aeiou]y$/i.test(w) ? w.slice(0, -1) + "ies" : w + "s";
const unitCap = (w) => w.charAt(0).toUpperCase() + w.slice(1);
// `as` fills with a given word instead of the saved one (the preview in 설정 › 화면).
const unitFill = (t, lang, as) => {
  if (t.indexOf("{") < 0 && t.indexOf("부서") < 0) return t;
  const w = as || unitCustom() || UNIT_DEF[lang] || UNIT_DEF.ko;
  // A stray "부서" (an extension's text, an old server message) is still the unit, particle and all.
  let s = t.replace(/부서(를|가|는|와|로)?/g, (m, j) => w + (j ? "{" + j + "}" : ""))
    .replace(/\{(unit|units|Unit|Units)\}/g, (m, k) => k === "unit" ? w : k === "units" ? unitPlural(w) : k === "Unit" ? unitCap(w) : unitCap(unitPlural(w)));
  if (s.indexOf("{") < 0) return s;
  let out = "", last = 0, m;
  JOSA_RE.lastIndex = 0;
  while ((m = JOSA_RE.exec(s))) { out += s.slice(last, m.index); out += josa(out, m[1]); last = m.index + m[0].length; }
  return out + s.slice(last);
};
const tl = (key, vars, as) => {
  const own = window.I18N?.[key];
  const t = String(own ?? window.I18N_ALL?.ko?.[key] ?? key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? vars[k] : m);
  return unitFill(t, own != null ? (window.I18N_LANG || "ko") : "ko", typeof as === "string" ? as : "");
};
// Text written in the code itself (no ko.json key) says {unit} too and goes through this.
const ut = (t) => unitFill(String(t), "ko");
// The server speaks Korean. A line it sends (an error, a toast, a confirm) is looked up by its
// Korean words among the srv.* keys and shown in the page's language; an unknown line stays as sent.
// {a}, {name} in a srv.* text stand for what the server filled in.
let srvIx = null;
const srvT = (t) => {
  if (typeof t !== "string" || LANG() === "ko" || !/[가-힣]/.test(t)) return t;
  const ko = (window.I18N_ALL && window.I18N_ALL.ko) || {};
  if (!srvIx) {
    srvIx = {exact: {}, pat: []};
    for (const k in ko) {
      if (k.slice(0, 4) !== "srv.") continue;
      const v = ko[k];
      if (v.indexOf("{") < 0) { srvIx.exact[v] = k; srvIx.exact[v.replace(/\.$/, "")] = k; continue; }
      const names = [];
      const re = v.replace(/[.*+?^$()|[\]\\]/g, "\\$&").replace(/\\?\{(\w+)\\?\}|\{(\w+)\}/g, (m, a, b) => { names.push(a || b); return "(.+?)"; });
      srvIx.pat.push([new RegExp("^" + re + "\\.?$"), k, names]);
    }
  }
  const s = t.trim(), k = srvIx.exact[s];
  if (k) return tl(k);
  for (const [re, key, names] of srvIx.pat) {
    const m = re.exec(s); if (!m) continue;
    const vars = {}; names.forEach((n, i) => { if (!/^units?$/i.test(n)) vars[n] = m[i + 1]; });   // the unit word is each language's own
    return tl(key, vars);
  }
  return t;
};
// unit:end
// The UI language. /i18n.js ships both dictionaries and picks one (the saved setting, else the
// OS/browser locale: ko -> Korean, anything else -> English). setLang swaps it in place. en.json
// may hold only some keys: tl falls back to the Korean text, never to the bare key.
const LANG = () => window.I18N_LANG || "ko";
// A constant label table that follows the language: rebuilt from `make` on every read (they are
// tiny), so a language switch needs no reload. Methods are bound to the fresh copy.
const LT = (make) => new Proxy(Array.isArray(make()) ? [] : {}, {
  get: (_, k) => { const o = make(), v = o[k]; return typeof v === "function" ? v.bind(o) : v; },
  has: (_, k) => k in make(),
  ownKeys: () => Reflect.ownKeys(make()),
  getOwnPropertyDescriptor: (_, k) => Object.getOwnPropertyDescriptor(make(), k),
});
async function setLang(lang) {
  const all = window.I18N_ALL || {}, eff = lang || (/^ko/i.test((navigator.languages && navigator.languages[0]) || navigator.language || "") ? "ko" : "en");
  if (!all[eff]) return;
  window.I18N_PICK = lang; window.I18N_LANG = eff; window.I18N = all[eff];
  document.documentElement.lang = eff;
  try { await post("/api/custom/prefs", {lang}); } catch (e) { toast(e.message); }
  try { window.dispatchEvent(new CustomEvent("loop-lang", {detail: eff})); } catch (e) {}
  // Settings redraws in place (render() would send a phone back to the settings menu).
  if (cur === "settings" && !detail) SCREENS.settings(); else render();
  drawChrome();
}
// The compact 한국어 / English switch, shared by the first-run header and 설정 > 일반.
const LANG_NAMES = [["ko", "한국어"], ["en", "English"]];
const langSeg = (cls = "") => `<div class="seg langseg ${cls}" role="group" aria-label="${tl("lang.label")}">`
  + LANG_NAMES.map(([k, n]) => `<button class="press ${LANG() === k ? "on" : ""}" data-lang="${k}" aria-pressed="${LANG() === k}" lang="${k}">${n}</button>`).join("")
  + `</div>`;
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-lang]"); if (b && b.dataset.lang !== LANG()) setLang(b.dataset.lang); });
// Scrollbar auto-hide (desktop only, mouse+hover devices — v2.css .scrolling rules): the thumb is
// transparent at rest and only fades in on hover OR while actively scrolling. Capture-phase listener
// on document catches "scroll" on any descendant even though the event itself doesn't bubble.
{
  const scrollHideT = new WeakMap();
  document.addEventListener("scroll", (e) => {
    const el = e.target === document ? document.documentElement : e.target;
    if (!el || !el.classList) return;
    el.classList.add("scrolling");
    clearTimeout(scrollHideT.get(el));
    scrollHideT.set(el, setTimeout(() => el.classList.remove("scrolling"), 700));
  }, true);
}
// Inside the app's own window (Genok.exe opens /?app=1): offer the same page in the browser.
// The address loses its query further down (and a reload keeps the stripped one), so the window
// remembers it for its own lifetime: without this a reload dropped the window controls and the drag.
// The floating window (/?float=1, web/float.js) is this same page showing only pinned conversations:
// the screens, their shortcuts, the heartbeat and the update check stay with the main window.
// v2.html marks it on <html> before the first paint and keeps that note for the window's lifetime,
// so an address that lost ?float=1 still is the floating window, never the app's screens.
const FLOAT = document.documentElement.classList.contains("float") || new URLSearchParams(location.search).has("float");
// The glass design (kit-d2 + kit-app + the lab layers) is the app; 설정 → 테마 can still pick the
// earlier one, kept as "0" under genok-lab. Read once at start.
const LAB3 = (() => { try { return localStorage.getItem("genok-lab") !== "0"; } catch (e) { return true; } })();
// The redesign round (web/glass.css, verdict cards and the review bar) is the glass design's own
// layer since 0.1.137: it loads wherever the glass design does. An old ?lab=3|4 address is ignored.
const RD = LAB3;
if (LAB3) { document.documentElement.classList.add("lab", "lab2", "lab3"); if (RD) document.documentElement.classList.add("rd");
  const k = document.createElement("link"); k.rel = "stylesheet"; k.href = "/glass.css"; document.head.appendChild(k); }
const IN_APP = (() => {
  if (FLOAT) return false;
  let v = new URLSearchParams(location.search).has("app");
  try { if (v) sessionStorage.setItem("v2-inapp", "1"); else v = sessionStorage.getItem("v2-inapp") === "1"; } catch (e) { /* private window */ }
  return v;
})();
// Which OS the app window runs on, read from the user agent for the first paint (js_api.env() is the
// authoritative copy). Only Windows is frameless and draws its own min/max/close chrome; macOS keeps
// its native title bar (with the traffic lights), so it never draws those buttons. .os-win / .os-mac
// on <html> let the CSS switch, and WINCHROME gates the window controls and the top-row drag.
const OS_MAC = /Mac/i.test(navigator.userAgent);
const OS_WIN = !OS_MAC && /Windows/i.test(navigator.userAgent);
// Last resort: the app's bridge is here but the page does not know it is the app window (the
// address and the note were both lost). Load once more as the app window, so there is always a
// way to move and close it.
if (!IN_APP && !FLOAT) {
  const asApp = () => {
    // The floating window's bridge (floatwin.Api: layout, no set_zoom) is not the app window's:
    // that window goes back to its own page, never to the app's screens.
    const a = window.pywebview && window.pywebview.api;
    if (a && a.layout && !a.set_zoom) return location.replace("/?float=1");
    try { sessionStorage.setItem("v2-inapp", "1"); } catch (e) { return; } location.replace("/?app=1" + location.hash); };
  if (window.pywebview) asApp(); else addEventListener("pywebviewready", asApp, {once: true});
}
if (IN_APP) {
  document.documentElement.classList.add(OS_MAC ? "os-mac" : OS_WIN ? "os-win" : "os-other");
  document.body.classList.add("inapp");
}

// ---------- icons: Phosphor Icons (MIT, regular weight, 256 grid, filled outlines; licenses/phosphor.md) ----------
// Only the glyphs the UI uses are inlined. Keys are ours; the star carries a filled twin (.pg) for the on state.
const P = {
  sync:'<path d="M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z"/>',
  home:'<path d="M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z"/>',
  lib:'<path d="M216,40H72A16,16,0,0,0,56,56V72H40A16,16,0,0,0,24,88V200a16,16,0,0,0,16,16H184a16,16,0,0,0,16-16V184h16a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM72,56H216v62.75l-10.07-10.06a16,16,0,0,0-22.63,0l-20,20-44-44a16,16,0,0,0-22.62,0L72,109.37ZM184,200H40V88H56v80a16,16,0,0,0,16,16H184Zm32-32H72V132l36-36,49.66,49.66a8,8,0,0,0,11.31,0L194.63,120,216,141.38V168ZM160,84a12,12,0,1,1,12,12A12,12,0,0,1,160,84Z"/>',
  people:'<path d="M117.25,157.92a60,60,0,1,0-66.5,0A95.83,95.83,0,0,0,3.53,195.63a8,8,0,1,0,13.4,8.74,80,80,0,0,1,134.14,0,8,8,0,0,0,13.4-8.74A95.83,95.83,0,0,0,117.25,157.92ZM40,108a44,44,0,1,1,44,44A44.05,44.05,0,0,1,40,108Zm210.14,98.7a8,8,0,0,1-11.07-2.33A79.83,79.83,0,0,0,172,168a8,8,0,0,1,0-16,44,44,0,1,0-16.34-84.87,8,8,0,1,1-5.94-14.85,60,60,0,0,1,55.53,105.64,95.83,95.83,0,0,1,47.22,37.71A8,8,0,0,1,250.14,206.7Z"/>',
  chart:'<path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160ZM104,96h40V200H104ZM56,144H88v56H56Z"/>',
  menu:'<path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"/>',
  grid:'<path d="M104,40H56A16,16,0,0,0,40,56v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V56A16,16,0,0,0,104,40Zm0,64H56V56h48v48Zm96-64H152a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V56A16,16,0,0,0,200,40Zm0,64H152V56h48v48Zm-96,32H56a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V152A16,16,0,0,0,104,136Zm0,64H56V152h48v48Zm96-64H152a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V152A16,16,0,0,0,200,136Zm0,64H152V152h48v48Z"/>',
  grip:'<path d="M104,60A12,12,0,1,1,92,48,12,12,0,0,1,104,60Zm60,12a12,12,0,1,0-12-12A12,12,0,0,0,164,72ZM92,116a12,12,0,1,0,12,12A12,12,0,0,0,92,116Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,116ZM92,184a12,12,0,1,0,12,12A12,12,0,0,0,92,184Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,184Z"/>',
  zoomin:'<path d="M152,112a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z"/>',
  zoomout:'<path d="M152,112a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z"/>',
  search:'<path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"/>',
  bell:'<path d="M221.8,175.94C216.25,166.38,208,139.33,208,104a80,80,0,1,0-160,0c0,35.34-8.26,62.38-13.81,71.94A16,16,0,0,0,48,200H88.81a40,40,0,0,0,78.38,0H208a16,16,0,0,0,13.8-24.06ZM128,216a24,24,0,0,1-22.62-16h45.24A24,24,0,0,1,128,216ZM48,184c7.7-13.24,16-43.92,16-80a64,64,0,1,1,128,0c0,36.05,8.28,66.73,16,80Z"/>',
  chev:'<path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z"/>',
  back:'<path d="M165.66,202.34a8,8,0,0,1-11.32,11.32l-80-80a8,8,0,0,1,0-11.32l80-80a8,8,0,0,1,11.32,11.32L91.31,128Z"/>',
  x:'<path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"/>',
  play:'<path d="M232.4,114.49,88.32,26.35a16,16,0,0,0-16.2-.3A15.86,15.86,0,0,0,64,39.87V216.13A15.94,15.94,0,0,0,80,232a16.07,16.07,0,0,0,8.36-2.35L232.4,141.51a15.81,15.81,0,0,0,0-27ZM80,215.94V40l143.83,88Z"/>',
  pause:'<path d="M200,32H160a16,16,0,0,0-16,16V208a16,16,0,0,0,16,16h40a16,16,0,0,0,16-16V48A16,16,0,0,0,200,32Zm0,176H160V48h40ZM96,32H56A16,16,0,0,0,40,48V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V48A16,16,0,0,0,96,32Zm0,176H56V48H96Z"/>',
  pin:'<path d="M128,64a40,40,0,1,0,40,40A40,40,0,0,0,128,64Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,128,128Zm0-112a88.1,88.1,0,0,0-88,88c0,31.4,14.51,64.68,42,96.25a254.19,254.19,0,0,0,41.45,38.3,8,8,0,0,0,9.18,0A254.19,254.19,0,0,0,174,200.25c27.45-31.57,42-64.85,42-96.25A88.1,88.1,0,0,0,128,16Zm0,206c-16.53-13-72-60.75-72-118a72,72,0,0,1,144,0C200,161.23,144.53,209,128,222Z"/>',
  video:'<path d="M251.77,73a8,8,0,0,0-8.21.39L208,97.05V72a16,16,0,0,0-16-16H32A16,16,0,0,0,16,72V184a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V159l35.56,23.71A8,8,0,0,0,248,184a8,8,0,0,0,8-8V80A8,8,0,0,0,251.77,73ZM192,184H32V72H192V184Zm48-22.95-32-21.33V116.28L240,95Z"/>',
  image:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V158.75l-26.07-26.06a16,16,0,0,0-22.63,0l-20,20-44-44a16,16,0,0,0-22.62,0L40,149.37V56ZM40,172l52-52,80,80H40Zm176,28H194.63l-36-36,20-20L216,181.38V200ZM144,100a12,12,0,1,1,12,12A12,12,0,0,1,144,100Z"/>',
  code:'<path d="M69.12,94.15,28.5,128l40.62,33.85a8,8,0,1,1-10.24,12.29l-48-40a8,8,0,0,1,0-12.29l48-40a8,8,0,0,1,10.24,12.3Zm176,27.7-48-40a8,8,0,1,0-10.24,12.3L227.5,128l-40.62,33.85a8,8,0,1,0,10.24,12.29l48-40a8,8,0,0,0,0-12.29ZM162.73,32.48a8,8,0,0,0-10.25,4.79l-64,176a8,8,0,0,0,4.79,10.26A8.14,8.14,0,0,0,96,224a8,8,0,0,0,7.52-5.27l64-176A8,8,0,0,0,162.73,32.48Z"/>',
  doc:'<path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Zm-32-80a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,136Zm0,32a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,168Z"/>',
  link:'<path d="M240,88.23a54.43,54.43,0,0,1-16,37L189.25,160a54.27,54.27,0,0,1-38.63,16h-.05A54.63,54.63,0,0,1,96,119.84a8,8,0,0,1,16,.45A38.62,38.62,0,0,0,150.58,160h0a38.39,38.39,0,0,0,27.31-11.31l34.75-34.75a38.63,38.63,0,0,0-54.63-54.63l-11,11A8,8,0,0,1,135.7,59l11-11A54.65,54.65,0,0,1,224,48,54.86,54.86,0,0,1,240,88.23ZM109,185.66l-11,11A38.41,38.41,0,0,1,70.6,208h0a38.63,38.63,0,0,1-27.29-65.94L78,107.31A38.63,38.63,0,0,1,144,135.71a8,8,0,0,0,16,.45A54.86,54.86,0,0,0,144,96a54.65,54.65,0,0,0-77.27,0L32,130.75A54.62,54.62,0,0,0,70.56,224h0a54.28,54.28,0,0,0,38.64-16l11-11A8,8,0,0,0,109,185.66Z"/>',
  megaphone:'<path d="M248,120a48.05,48.05,0,0,0-48-48H160.2c-2.91-.17-53.62-3.74-101.91-44.24A16,16,0,0,0,32,40V200a16,16,0,0,0,26.29,12.25c37.77-31.68,77-40.76,93.71-43.3v31.72A16,16,0,0,0,159.12,214l11,7.33A16,16,0,0,0,194.5,212l11.77-44.36A48.07,48.07,0,0,0,248,120ZM48,199.93V40h0c42.81,35.91,86.63,45,104,47.24v65.48C134.65,155,90.84,164.07,48,199.93Zm131,8,0,.11-11-7.33V168h21.6ZM200,152H168V88h32a32,32,0,1,1,0,64Z"/>',
  chat:'<path d="M116,128a12,12,0,1,1,12,12A12,12,0,0,1,116,128ZM84,140a12,12,0,1,0-12-12A12,12,0,0,0,84,140Zm88,0a12,12,0,1,0-12-12A12,12,0,0,0,172,140Zm60-76V192a16,16,0,0,1-16,16H83l-32.6,28.16-.09.07A15.89,15.89,0,0,1,40,240a16.13,16.13,0,0,1-6.8-1.52A15.85,15.85,0,0,1,24,224V64A16,16,0,0,1,40,48H216A16,16,0,0,1,232,64ZM40,224h0ZM216,64H40V224l34.77-30A8,8,0,0,1,80,192H216Z"/>',
  rooms:'<path d="M216,80H184V48a16,16,0,0,0-16-16H40A16,16,0,0,0,24,48V176a8,8,0,0,0,13,6.22L72,154V184a16,16,0,0,0,16,16h93.59L219,230.22a8,8,0,0,0,5,1.78,8,8,0,0,0,8-8V96A16,16,0,0,0,216,80ZM66.55,137.78,40,159.25V48H168v88H71.58A8,8,0,0,0,66.55,137.78ZM216,207.25l-26.55-21.47a8,8,0,0,0-5-1.78H88V152h80a16,16,0,0,0,16-16V96h32Z"/>',
  check:'<path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"/>',
  list:'<path d="M80,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H88A8,8,0,0,1,80,64Zm136,56H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Zm0,64H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16ZM44,52A12,12,0,1,0,56,64,12,12,0,0,0,44,52Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,116Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,180Z"/>',
  folder:'<path d="M216,72H131.31L104,44.69A15.86,15.86,0,0,0,92.69,40H40A16,16,0,0,0,24,56V200.62A15.4,15.4,0,0,0,39.38,216H216.89A15.13,15.13,0,0,0,232,200.89V88A16,16,0,0,0,216,72ZM40,56H92.69l16,16H40ZM216,200H40V88H216Z"/>',
  flag:'<path d="M42.76,50A8,8,0,0,0,40,56V224a8,8,0,0,0,16,0V179.77c26.79-21.16,49.87-9.75,76.45,3.41,16.4,8.11,34.06,16.85,53,16.85,13.93,0,28.54-4.75,43.82-18a8,8,0,0,0,2.76-6V56A8,8,0,0,0,218.76,50c-28,24.23-51.72,12.49-79.21-1.12C111.07,34.76,78.78,18.79,42.76,50ZM216,172.25c-26.79,21.16-49.87,9.74-76.45-3.41-25-12.35-52.81-26.13-83.55-8.4V59.79c26.79-21.16,49.87-9.75,76.45,3.4,25,12.35,52.82,26.13,83.55,8.4Z"/>',
  loop:'<path d="M24,128A72.08,72.08,0,0,1,96,56H204.69L194.34,45.66a8,8,0,0,1,11.32-11.32l24,24a8,8,0,0,1,0,11.32l-24,24a8,8,0,0,1-11.32-11.32L204.69,72H96a56.06,56.06,0,0,0-56,56,8,8,0,0,1-16,0Zm200-8a8,8,0,0,0-8,8,56.06,56.06,0,0,1-56,56H51.31l10.35-10.34a8,8,0,0,0-11.32-11.32l-24,24a8,8,0,0,0,0,11.32l24,24a8,8,0,0,0,11.32-11.32L51.31,200H160a72.08,72.08,0,0,0,72-72A8,8,0,0,0,224,120Z"/>',
  gauge:'<path d="M207.06,72.67A111.24,111.24,0,0,0,128,40h-.4C66.07,40.21,16,91,16,153.13V176a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V152A111.25,111.25,0,0,0,207.06,72.67ZM224,176H119.71l54.76-75.3a8,8,0,0,0-12.94-9.42L99.92,176H32V153.13c0-3.08.15-6.12.43-9.13H56a8,8,0,0,0,0-16H35.27c10.32-38.86,44-68.24,84.73-71.66V80a8,8,0,0,0,16,0V56.33A96.14,96.14,0,0,1,221,128H200a8,8,0,0,0,0,16h23.67c.21,2.65.33,5.31.33,8Z"/>',
  server:'<path d="M208,136H48a16,16,0,0,0-16,16v48a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,64H48V152H208v48Zm0-160H48A16,16,0,0,0,32,56v48a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V56A16,16,0,0,0,208,40Zm0,64H48V56H208v48ZM192,80a12,12,0,1,1-12-12A12,12,0,0,1,192,80Zm0,96a12,12,0,1,1-12-12A12,12,0,0,1,192,176Z"/>',
  clock:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"/>',
  brain:'<path d="M248,124a56.11,56.11,0,0,0-32-50.61V72a48,48,0,0,0-88-26.49A48,48,0,0,0,40,72v1.39a56,56,0,0,0,0,101.2V176a48,48,0,0,0,88,26.49A48,48,0,0,0,216,176v-1.41A56.09,56.09,0,0,0,248,124ZM88,208a32,32,0,0,1-31.81-28.56A55.87,55.87,0,0,0,64,180h8a8,8,0,0,0,0-16H64A40,40,0,0,1,50.67,86.27,8,8,0,0,0,56,78.73V72a32,32,0,0,1,64,0v68.26A47.8,47.8,0,0,0,88,128a8,8,0,0,0,0,16,32,32,0,0,1,0,64Zm104-44h-8a8,8,0,0,0,0,16h8a55.87,55.87,0,0,0,7.81-.56A32,32,0,1,1,168,144a8,8,0,0,0,0-16,47.8,47.8,0,0,0-32,12.26V72a32,32,0,0,1,64,0v6.73a8,8,0,0,0,5.33,7.54A40,40,0,0,1,192,164Zm16-52a8,8,0,0,1-8,8h-4a36,36,0,0,1-36-36V80a8,8,0,0,1,16,0v4a20,20,0,0,0,20,20h4A8,8,0,0,1,208,112ZM60,120H56a8,8,0,0,1,0-16h4A20,20,0,0,0,80,84V80a8,8,0,0,1,16,0v4A36,36,0,0,1,60,120Z"/>',
  spark:'<path d="M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"/>',
  plug:'<path d="M200,48H136V16a8,8,0,0,0-16,0V48H56A32,32,0,0,0,24,80V192a32,32,0,0,0,32,32H200a32,32,0,0,0,32-32V80A32,32,0,0,0,200,48Zm16,144a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V80A16,16,0,0,1,56,64H200a16,16,0,0,1,16,16Zm-52-56H92a28,28,0,0,0,0,56h72a28,28,0,0,0,0-56Zm-24,16v24H116V152ZM80,164a12,12,0,0,1,12-12h8v24H92A12,12,0,0,1,80,164Zm84,12h-8V152h8a12,12,0,0,1,0,24ZM72,108a12,12,0,1,1,12,12A12,12,0,0,1,72,108Zm88,0a12,12,0,1,1,12,12A12,12,0,0,1,160,108Z"/>',
  book:'<path d="M232,48H160a40,40,0,0,0-32,16A40,40,0,0,0,96,48H24a8,8,0,0,0-8,8V200a8,8,0,0,0,8,8H96a24,24,0,0,1,24,24,8,8,0,0,0,16,0,24,24,0,0,1,24-24h72a8,8,0,0,0,8-8V56A8,8,0,0,0,232,48ZM96,192H32V64H96a24,24,0,0,1,24,24V200A39.81,39.81,0,0,0,96,192Zm128,0H160a39.81,39.81,0,0,0-24,8V88a24,24,0,0,1,24-24h64Z"/>',
  dice:'<path d="M192,32H64A32,32,0,0,0,32,64V192a32,32,0,0,0,32,32H192a32,32,0,0,0,32-32V64A32,32,0,0,0,192,32Zm16,160a16,16,0,0,1-16,16H64a16,16,0,0,1-16-16V64A16,16,0,0,1,64,48H192a16,16,0,0,1,16,16ZM104,92A12,12,0,1,1,92,80,12,12,0,0,1,104,92Zm72,0a12,12,0,1,1-12-12A12,12,0,0,1,176,92Zm-72,72a12,12,0,1,1-12-12A12,12,0,0,1,104,164Zm36-36a12,12,0,1,1-12-12A12,12,0,0,1,140,128Zm36,36a12,12,0,1,1-12-12A12,12,0,0,1,176,164Z"/>',
  mute:'<path d="M128,48V208L76,160H40a8,8,0,0,1-8-8V104a8,8,0,0,1,8-8H76Z"/><path d="M52.6,40.9,224.6,208.9l-11.2,11.5L41.4,52.4Z"/>',
  cols:'<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM48,48h72V208H48ZM208,208H136V48h72V208Z"/>',
  swap:'<path d="M213.66,181.66l-32,32a8,8,0,0,1-11.32-11.32L188.69,184H48a8,8,0,0,1,0-16H188.69l-18.35-18.34a8,8,0,0,1,11.32-11.32l32,32A8,8,0,0,1,213.66,181.66Zm-139.32-64a8,8,0,0,0,11.32-11.32L67.31,88H208a8,8,0,0,0,0-16H67.31L85.66,53.66A8,8,0,0,0,74.34,42.34l-32,32a8,8,0,0,0,0,11.32Z"/>',
  pen:'<path d="M227.31,73.37,182.63,28.68a16,16,0,0,0-22.63,0L36.69,152A15.86,15.86,0,0,0,32,163.31V208a16,16,0,0,0,16,16H92.69A15.86,15.86,0,0,0,104,219.31L227.31,96a16,16,0,0,0,0-22.63ZM92.69,208H48V163.31l88-88L180.69,120ZM192,108.68,147.31,64l24-24L216,84.68Z"/>',
  arrow:'<path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/>',
  rect:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,160H40V56H216V200Z"/>',
  ellipse:'<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Z"/>',
  eraser:'<path d="M225,80.4,183.6,39a24,24,0,0,0-33.94,0L31,157.66a24,24,0,0,0,0,33.94l30.06,30.06A8,8,0,0,0,66.74,224H216a8,8,0,0,0,0-16h-84.7L225,114.34A24,24,0,0,0,225,80.4ZM108.68,208H70.05L42.33,180.28a8,8,0,0,1,0-11.31L96,115.31,148.69,168Zm105-105L160,156.69,107.31,104,161,50.34a8,8,0,0,1,11.32,0l41.38,41.38a8,8,0,0,1,0,11.31Z"/>',
  gear:'<path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm88-29.84q.06-2.16,0-4.32l14.92-18.64a8,8,0,0,0,1.48-7.06,107.21,107.21,0,0,0-10.88-26.25,8,8,0,0,0-6-3.93l-23.72-2.64q-1.48-1.56-3-3L186,40.54a8,8,0,0,0-3.94-6,107.71,107.71,0,0,0-26.25-10.87,8,8,0,0,0-7.06,1.49L130.16,40Q128,40,125.84,40L107.2,25.11a8,8,0,0,0-7.06-1.48A107.6,107.6,0,0,0,73.89,34.51a8,8,0,0,0-3.93,6L67.32,64.27q-1.56,1.49-3,3L40.54,70a8,8,0,0,0-6,3.94,107.71,107.71,0,0,0-10.87,26.25,8,8,0,0,0,1.49,7.06L40,125.84Q40,128,40,130.16L25.11,148.8a8,8,0,0,0-1.48,7.06,107.21,107.21,0,0,0,10.88,26.25,8,8,0,0,0,6,3.93l23.72,2.64q1.49,1.56,3,3L70,215.46a8,8,0,0,0,3.94,6,107.71,107.71,0,0,0,26.25,10.87,8,8,0,0,0,7.06-1.49L125.84,216q2.16.06,4.32,0l18.64,14.92a8,8,0,0,0,7.06,1.48,107.21,107.21,0,0,0,26.25-10.88,8,8,0,0,0,3.93-6l2.64-23.72q1.56-1.48,3-3L215.46,186a8,8,0,0,0,6-3.94,107.71,107.71,0,0,0,10.87-26.25,8,8,0,0,0-1.49-7.06Zm-16.1-6.5a73.93,73.93,0,0,1,0,8.68,8,8,0,0,0,1.74,5.48l14.19,17.73a91.57,91.57,0,0,1-6.23,15L187,173.11a8,8,0,0,0-5.1,2.64,74.11,74.11,0,0,1-6.14,6.14,8,8,0,0,0-2.64,5.1l-2.51,22.58a91.32,91.32,0,0,1-15,6.23l-17.74-14.19a8,8,0,0,0-5-1.75h-.48a73.93,73.93,0,0,1-8.68,0,8,8,0,0,0-5.48,1.74L100.45,215.8a91.57,91.57,0,0,1-15-6.23L82.89,187a8,8,0,0,0-2.64-5.1,74.11,74.11,0,0,1-6.14-6.14,8,8,0,0,0-5.1-2.64L46.43,170.6a91.32,91.32,0,0,1-6.23-15l14.19-17.74a8,8,0,0,0,1.74-5.48,73.93,73.93,0,0,1,0-8.68,8,8,0,0,0-1.74-5.48L40.2,100.45a91.57,91.57,0,0,1,6.23-15L69,82.89a8,8,0,0,0,5.1-2.64,74.11,74.11,0,0,1,6.14-6.14A8,8,0,0,0,82.89,69L85.4,46.43a91.32,91.32,0,0,1,15-6.23l17.74,14.19a8,8,0,0,0,5.48,1.74,73.93,73.93,0,0,1,8.68,0,8,8,0,0,0,5.48-1.74L155.55,40.2a91.57,91.57,0,0,1,15,6.23L173.11,69a8,8,0,0,0,2.64,5.1,74.11,74.11,0,0,1,6.14,6.14,8,8,0,0,0,5.1,2.64l22.58,2.51a91.32,91.32,0,0,1,6.23,15l-14.19,17.74A8,8,0,0,0,199.87,123.66Z"/>',
  warn:'<path d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"/>',
  hub:'<path d="M223.68,66.15,135.68,18h0a15.88,15.88,0,0,0-15.36,0l-88,48.17a16,16,0,0,0-8.32,14v95.64a16,16,0,0,0,8.32,14l88,48.17a15.88,15.88,0,0,0,15.36,0l88-48.17a16,16,0,0,0,8.32-14V80.18A16,16,0,0,0,223.68,66.15ZM128,32h0l80.34,44L128,120,47.66,76ZM40,90l80,43.78v85.79L40,175.82Zm96,129.57V133.82L216,90v85.78Z"/>',
  archive:'<path d="M224,48H32A16,16,0,0,0,16,64V88a16,16,0,0,0,16,16v88a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V104a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM208,192H48V104H208ZM224,88H32V64H224V88ZM96,136a8,8,0,0,1,8-8h48a8,8,0,0,1,0,16H104A8,8,0,0,1,96,136Z"/>',
  minus:'<path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128Z"/>',
  fit:'<path d="M200,80v32a8,8,0,0,1-16,0V88H160a8,8,0,0,1,0-16h32A8,8,0,0,1,200,80ZM96,168H72V144a8,8,0,0,0-16,0v32a8,8,0,0,0,8,8H96a8,8,0,0,0,0-16ZM232,56V200a16,16,0,0,1-16,16H40a16,16,0,0,1-16-16V56A16,16,0,0,1,40,40H216A16,16,0,0,1,232,56ZM216,200V56H40V200H216Z"/>',
  plus:'<path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>',
  stop:'<path d="M200,40H56A16,16,0,0,0,40,56V200a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V56A16,16,0,0,0,200,40Zm0,160H56V56H200V200Z"/>',
  up:'<path d="M205.66,117.66a8,8,0,0,1-11.32,0L136,59.31V216a8,8,0,0,1-16,0V59.31L61.66,117.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,205.66,117.66Z"/>',
  dl:'<path d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"/>',
  ext:'<path d="M224,104a8,8,0,0,1-16,0V59.32l-66.33,66.34a8,8,0,0,1-11.32-11.32L196.68,48H152a8,8,0,0,1,0-16h64a8,8,0,0,1,8,8Zm-40,24a8,8,0,0,0-8,8v72H48V80h72a8,8,0,0,0,0-16H48A16,16,0,0,0,32,80V208a16,16,0,0,0,16,16H176a16,16,0,0,0,16-16V136A8,8,0,0,0,184,128Z"/>',
  more:'<path d="M140,128a12,12,0,1,1-12-12A12,12,0,0,1,140,128Zm56-12a12,12,0,1,0,12,12A12,12,0,0,0,196,116ZM60,116a12,12,0,1,0,12,12A12,12,0,0,0,60,116Z"/>',
  full:'<path d="M216,48V88a8,8,0,0,1-16,0V56H168a8,8,0,0,1,0-16h40A8,8,0,0,1,216,48ZM88,200H56V168a8,8,0,0,0-16,0v40a8,8,0,0,0,8,8H88a8,8,0,0,0,0-16Zm120-40a8,8,0,0,0-8,8v32H168a8,8,0,0,0,0,16h40a8,8,0,0,0,8-8V168A8,8,0,0,0,208,160ZM88,40H48a8,8,0,0,0-8,8V88a8,8,0,0,0,16,0V56H88a8,8,0,0,0,0-16Z"/>',
  star:'<path class="pr" d="M239.18,97.26A16.38,16.38,0,0,0,224.92,86l-59-4.76L143.14,26.15a16.36,16.36,0,0,0-30.27,0L90.11,81.23,31.08,86a16.46,16.46,0,0,0-9.37,28.86l45,38.83L53,211.75a16.38,16.38,0,0,0,24.5,17.82L128,198.49l50.53,31.08A16.4,16.4,0,0,0,203,211.75l-13.76-58.07,45-38.83A16.43,16.43,0,0,0,239.18,97.26Zm-15.34,5.47-48.7,42a8,8,0,0,0-2.56,7.91l14.88,62.8a.37.37,0,0,1-.17.48c-.18.14-.23.11-.38,0l-54.72-33.65a8,8,0,0,0-8.38,0L69.09,215.94c-.15.09-.19.12-.38,0a.37.37,0,0,1-.17-.48l14.88-62.8a8,8,0,0,0-2.56-7.91l-48.7-42c-.12-.1-.23-.19-.13-.5s.18-.27.33-.29l63.92-5.16A8,8,0,0,0,103,91.86l24.62-59.61c.08-.17.11-.25.35-.25s.27.08.35.25L153,91.86a8,8,0,0,0,6.75,4.92l63.92,5.16c.15,0,.24,0,.33.29S224,102.63,223.84,102.73Z"/><path class="pg" d="M234.29,114.85l-45,38.83L203,211.75a16.4,16.4,0,0,1-24.5,17.82L128,198.49,77.47,229.57A16.4,16.4,0,0,1,53,211.75l13.76-58.07-45-38.83A16.46,16.46,0,0,1,31.08,86l59-4.76,22.76-55.08a16.36,16.36,0,0,1,30.27,0l22.75,55.08,59,4.76a16.46,16.46,0,0,1,9.37,28.86Z"/>',
  tool:'<path d="M226.76,69a8,8,0,0,0-12.84-2.88l-40.3,37.19-17.23-3.7-3.7-17.23,37.19-40.3A8,8,0,0,0,187,29.24,72,72,0,0,0,88,96,72.34,72.34,0,0,0,94,124.94L33.79,177c-.15.12-.29.26-.43.39a32,32,0,0,0,45.26,45.26c.13-.13.27-.28.39-.42L131.06,162A72,72,0,0,0,232,96,71.56,71.56,0,0,0,226.76,69ZM160,152a56.14,56.14,0,0,1-27.07-7,8,8,0,0,0-9.92,1.77L67.11,211.51a16,16,0,0,1-22.62-22.62L109.18,133a8,8,0,0,0,1.77-9.93,56,56,0,0,1,58.36-82.31l-31.2,33.81a8,8,0,0,0-1.94,7.1L141.83,108a8,8,0,0,0,6.14,6.14l26.35,5.66a8,8,0,0,0,7.1-1.94l33.81-31.2A56.06,56.06,0,0,1,160,152Z"/>',
  cube:'<path d="M223.68,66.15,135.68,18h0a15.88,15.88,0,0,0-15.36,0l-88,48.17a16,16,0,0,0-8.32,14v95.64a16,16,0,0,0,8.32,14l88,48.17a15.88,15.88,0,0,0,15.36,0l88-48.17a16,16,0,0,0,8.32-14V80.18A16,16,0,0,0,223.68,66.15ZM128,32h0l80.34,44L128,120,47.66,76ZM40,90l80,43.78v85.79L40,175.82Zm96,129.57V133.82L216,90v85.78Z"/>',
  tray:'<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,16V152h-28.7A15.86,15.86,0,0,0,168,156.69L148.69,176H107.31L88,156.69A15.86,15.86,0,0,0,76.69,152H48V48Zm0,160H48V168H76.69L96,187.31A15.86,15.86,0,0,0,107.31,192h41.38A15.86,15.86,0,0,0,160,187.31L179.31,168H208v40Z"/>',
  track:'<path d="M224,128a8,8,0,0,1-8,8H128a8,8,0,0,1,0-16h88A8,8,0,0,1,224,128ZM128,72h88a8,8,0,0,0,0-16H128a8,8,0,0,0,0,16Zm88,112H128a8,8,0,0,0,0,16h88a8,8,0,0,0,0-16ZM82.34,42.34,56,68.69,45.66,58.34A8,8,0,0,0,34.34,69.66l16,16a8,8,0,0,0,11.32,0l32-32A8,8,0,0,0,82.34,42.34Zm0,64L56,132.69,45.66,122.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32,0l32-32a8,8,0,0,0-11.32-11.32Zm0,64L56,196.69,45.66,186.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32,0l32-32a8,8,0,0,0-11.32-11.32Z"/>',
  sidebar:'<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM40,56H80V200H40ZM216,200H96V56H216V200Z"/>',
  moon:'<path d="M233.54,142.23a8,8,0,0,0-8-2,88.08,88.08,0,0,1-109.8-109.8,8,8,0,0,0-10-10,104.84,104.84,0,0,0-52.91,37A104,104,0,0,0,136,224a103.09,103.09,0,0,0,62.52-20.88,104.84,104.84,0,0,0,37-52.91A8,8,0,0,0,233.54,142.23ZM188.9,190.34A88,88,0,0,1,65.66,67.11a89,89,0,0,1,31.4-26A106,106,0,0,0,96,56,104.11,104.11,0,0,0,200,160a106,106,0,0,0,14.92-1.06A89,89,0,0,1,188.9,190.34Z"/>',
  lock:'<path d="M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"/>',
  shieldCheck:'<path d="M208,40H48A16,16,0,0,0,32,56v56c0,52.72,25.52,84.67,46.93,102.19,23.06,18.86,46,25.26,47,25.53a8,8,0,0,0,4.2,0c1-.27,23.91-6.67,47-25.53C198.48,196.67,224,164.72,224,112V56A16,16,0,0,0,208,40Zm0,72c0,37.07-13.66,67.16-40.6,89.42A129.3,129.3,0,0,1,128,223.62a128.25,128.25,0,0,1-38.92-21.81C61.82,179.51,48,149.3,48,112l0-56,160,0ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"/>',
  bulb:'<path d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Zm-16,0a72,72,0,0,0-73.74-72c-39,.92-70.47,33.39-70.26,72.39a71.65,71.65,0,0,0,27.64,56.3A32,32,0,0,1,96,186v6h64v-6a32.15,32.15,0,0,1,12.47-25.35A71.65,71.65,0,0,0,200,104Zm-16.11-9.34a57.6,57.6,0,0,0-46.56-46.55,8,8,0,0,0-2.66,15.78c16.57,2.79,30.63,16.85,33.44,33.45A8,8,0,0,0,176,104a9,9,0,0,0,1.35-.11A8,8,0,0,0,183.89,94.66Z"/>',
};
const ic = (k, c = "i") => `<svg class="${c}" data-ic="${k}" viewBox="0 0 256 256" aria-hidden="true">${P[k] || P.cube}</svg>`;
// A few Lucide glyphs (ISC, licenses/lucide.md), path data unmodified, drawn as 24-unit strokes.
// Used where an outline reads better than Phosphor's filled shapes: the phone row swipe actions
// and the menu beside [새 세션] (play, folder-plus, pin).
const LU = {
  resume:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/>',
  read:'<path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/>',
  unread:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="1"/>',
  hide:'<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
  end:'<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.77.04"/>',
  play:'<polygon points="6 3 20 12 6 21 6 3"/>',
};
const icl = (k, w = 1.75) => `<svg class="lu" data-ic="${k}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LU[k] || ""}</svg>`;
// Empty-state art from web/motion.js (Fluent Emoji); nothing if that script is missing.
const mEmpty = (m) => window.Motion ? Motion.empty(m) : "";
// The lower part of a video is its own controls (timeline, volume). A drag that starts there
// scrubs the video; paging from there moved the whole stage under the finger instead.
const onControls = (e) => { const v = e.target.closest?.("video"); if (!v) return false;
  const r = v.getBoundingClientRect(); return e.clientY > r.bottom - Math.max(110, r.height * 0.35); };
// Korean particle after a name: jo("여행", "와", "과") -> "여행과". Names end in Hangul, digits
// (v001 reads 일) or Latin; a closing syllable, a digit read with one, or l/m/n takes the second form.
const jo = (w, open, closed) => {
  const c = String(w ?? "").trim().slice(-1), k = c.charCodeAt(0) - 0xAC00;
  const shut = k >= 0 && k < 11172 ? k % 28 !== 0 && !(closed === "으로" && k % 28 === 8)
    : /[013678]/.test(c) ? !(closed === "으로" && /[178]/.test(c)) : /[lmn]/i.test(c) && !(closed === "으로" && /l/i.test(c));
  return LANG() !== "ko" ? w : w + (shut ? closed : open);
};
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
// One line now, the rest on a press: the rest fades in where it stands (no slide). A key keeps it
// open across repaints of the same spot.
const more1Open = new Set();
const more1 = (first, rest, key) => !rest ? first : key && more1Open.has(key) ? `${first} ${rest}`
  : `${first} <button type="button" class="more1 press" aria-expanded="false"${key ? ` data-more1="${esc(key)}"` : ""}>${tl("ui.more1")}</button><span class="more1x" hidden> ${rest}</span>`;
document.addEventListener("click", (e) => {
  const b = e.target.closest && e.target.closest(".more1");
  if (!b) return;
  e.preventDefault(); e.stopPropagation();
  if (b.dataset.more1) more1Open.add(b.dataset.more1);
  const x = b.nextElementSibling, had = document.activeElement === b;
  if (x) x.hidden = false;
  b.hidden = true;
  // Pressed by keyboard, the button took the focus away with it: it goes to the words it opened.
  if (had && x) { x.tabIndex = -1; x.focus({preventScroll: true}); }
}, true);
// The agent's key-colour dot that goes before its name in a label (.agdot in v2.css).
const agDot = (agent) => `<i class="agdot${agent === "codex" ? " cx" : ""}" aria-hidden="true"></i>`;
window.agDot = agDot;
// Legacy wall-clock timestamps belong to the host PC, not the phone's timezone.
const hostDate = (iso) => { const value = String(iso || "");
  if (/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d(?:\.\d+)?)?$/.test(value) && Number.isFinite(window.LOOP_SERVER_OFFSET))
    return new Date(Date.parse(value + "Z") - window.LOOP_SERVER_OFFSET * 6e4);
  return new Date(iso); };
window.hostDate = hostDate;
const ago = (iso) => { if (!iso) return tl("ago.1"); const d = hostDate(iso), m = (Date.now() - d) / 6e4;
  if (!Number.isFinite(m)) return tl("ago.1");
  return m < 1 ? tl("ago.2") : m < 60 ? tl("ago.3", {p0: Math.round(m)}) : m < 1440 ? tl("ago.4", {p0: Math.round(m/60)}) : m < 1440*30 ? tl("ago.5", {p0: Math.round(m/1440)}) : d.toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR",{month:"long",day:"numeric"}); };
// Refresh timestamps without repainting the comment text or disrupting text selection.
setInterval(() => document.querySelectorAll("[data-note-at]").forEach((el) => {
  const text = ago(el.dataset.noteAt); if (el.textContent !== text) el.textContent = text;
}), 20000);
const day = (iso) => { const d = hostDate(iso), t = new Date(); const diff = Math.floor((new Date(t.toDateString()) - new Date(d.toDateString())) / 864e5);
  return diff <= 0 ? tl("day.1") : diff === 1 ? tl("day.2") : d.toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR",{month:"long",day:"numeric"}); };
const hm = (iso) => iso ? hostDate(iso).toLocaleTimeString(LANG() === "en" ? "en-US" : "ko-KR", {hour:"numeric", minute:"2-digit"}) : "";
// Item-level due date (Frame.io식 마감일 필드, §4.15): "YYYY-MM-DD" -> {days, label, over}.
const dueInfo = (due) => { if (!due) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(due + "T00:00:00"); if (isNaN(d)) return null;
  const days = Math.round((d - today) / 864e5);
  const label = days === 0 ? tl("itemView.170") : days === 1 ? tl("itemView.171")
    : days > 1 ? tl("itemView.172", {n: days}) : tl("itemView.173", {n: -days});
  return {days, label, over: days < 0}; };
const base = (p) => String(p || "").split(/[\\/]/).filter(Boolean).pop() || p || "";

// markdown.js builds DOM with h(); this is the same small helper the classic page has.
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) el.append(k.nodeType ? k : String(k));
  return el;
}

const STATUS_T = LT(() => ({pending:tl("STATUS_T.1"), changes:tl("STATUS_T.2"), hold:tl("STATUS_T.3"), approved:tl("STATUS_T.4")}));
// A background job says what it is doing; only a terminal session is judged by how fresh
// its file is. "Linked to the desktop app" used to count as working, so every connected
// session read 작업 중 for ever.
const JOB_S = {working: "work", blocked: "ask", done: "idle", idle: "idle", stopped: "idle"};
const state = (r) => r.stuck ? "stuck" : !r.active ? "off" : r.job && JOB_S[r.job] ? JOB_S[r.job]
  : (Date.now() - new Date(r.active)) < 3*60e3 ? "work" : "idle";
const KIND = {video:["video","purple"], image:["image","blue"], html:["code","teal"], text:["doc","grey"], link:["link","green"], code:["code","teal"], diff:["code","green"], doc:["doc","grey"], sheet:["list","green"]};
// An <img> with a loading state: pulses until it loads, fades in, and falls back quietly on error.
// A picture this page has already shown is drawn again without the pulse and the fade: a list
// that redraws itself (the 30s round, the live watch) would otherwise blink every thumbnail.
const imgSeen = new Set();
function imgIn(im) { const k = im.getAttribute("src"), was = imgSeen.has(k); imgSeen.add(k); im.classList.remove("loading"); if (!was) im.classList.add("imgin"); }
const imgTag = (url, {alt = "", lazy = true, drag = true, keep = false} = {}) =>
  `<img class="${imgSeen.has(url) ? "" : "loading"}" src="${esc(url)}" alt="${esc(alt)}"${lazy ? ` loading="lazy"` : ""}${drag ? "" : ` draggable="false"`} onload="imgIn(this)" onerror="${keep ? "this.classList.remove('loading');this.classList.add('bad')" : "this.remove()"}">`;
const thumb = (it, cls = "ico") => {
  const [k, c] = KIND[it.kind] || ["doc","grey"];
  return `<span class="${cls} c-${c}">${ic(k)}${it.thumb ? imgTag(it.thumb) : ""}${it.thumb && it.kind === "video" ? `<span class="play">${ic("play","i f")}</span>` : ""}</span>`;
};
const deptIco = (r, cls = "ico") => `<span class="${cls}">${r.icon ? esc(r.icon) : ic("folder")}</span>`;
const justIn = (x) => x.at && Date.now() - new Date(x.at) < 15 * 6e4;
const byAt = (a, b) => (b.at || "").localeCompare(a.at || "");
// Answered questions hand the item back to its department, so it leaves 확인 필요.
// Sent comments do the same: the person has said their piece, whether or not the session took it yet.
// Which of 전달 대기 / 작업 중 / 멈춤 the session's turn is on is told in status.js.
const turnOf = (x) => stTurn(x);
// Where each result stands is decided in one place (status.js stKind); this only keeps the answer
// per loaded list, per minute (a kind can turn on the clock alone), and feeds it which sessions
// are waiting on the reader (attention rooms).
let flowMemo = {of: null, m: new Map()};
const stAsking = () => stWaits(attL("rooms"));
function stJ(x) {
  const of = D.items, at = Math.floor(Date.now() / 6e4), sig = JSON.stringify(stAsking()?.said || {});
  if (flowMemo.of !== of || flowMemo.at !== at || flowMemo.sig !== sig) flowMemo = {of, at, sig, m: new Map(), lead: stLeads(of, Date.now())};
  if (!flowMemo.m.has(x)) flowMemo.m.set(x, stJudge(x, Date.now(), stAsking(), flowMemo.lead));
  return flowMemo.m.get(x);
}
const stK = (x) => stJ(x).kind;
// The saved views' smart filters (views.js) still read the older names.
const flowOf = (x) => ({work: "work", ask: "ask", undelivered: "unread", queued: "unread", stalled: "quiet", old: "old", done: "done"})[stK(x)] || "";
const ST_NAME = LT(() => ({check: tl("st.reply"), ask: tl("st.ask"), undelivered: tl("st.undelivered"), queued: tl("st.undelivered"), work: tl("st.work"), stalled: tl("SESS_T.2"),
  done: tl("st.done"), old: tl("st.old"), hold: tl("STATUS_T.3"), approved: tl("STATUS_T.4"), finished: tl("st.finished")}));
const ST_TABN = LT(() => ({all: tl("libDraw.1"), fresh: tl("st.fresh"), pending: tl("st.reply"), undelivered: tl("st.undelivered"), changes: tl("st.work"), stalled: tl("SESS_T.2"),
  finished: tl("st.finished")}));
const ST_NONE = LT(() => ({all: tl("libDraw.19"), fresh: tl("st.none.fresh"), pending: tl("st.none.pending"), undelivered: tl("st.none.undelivered"), changes: tl("st.none.work"), stalled: tl("st.none.stalled"),
  finished: tl("st.none.finished")}));
// What each list holds, in one line: shown under the strip, so it never hides behind a hover.
const ST_HINT = LT(() => ({fresh: tl("st.hint.fresh"), pending: tl("st.hint.pending"), undelivered: tl("st.hint.undelivered"), changes: tl("st.hint.work"), stalled: tl("st.hint.stalled"),
  finished: tl("st.hint.finished")}));
// No list has come yet (and no saved copy): an empty screen would read as "nothing to do", so it
// says the lists could not be read and offers another try.
const neverLoaded = () => loadLost && !D.at;
const notLoadedHtml = () => `<b>${tl("load.none")}</b><button class="btn sm press" data-reload>${tl("netBar.2")}</button>`;
addEventListener("click", async (e) => { const b = e.target.closest?.("[data-reload]"); if (!b || b.disabled) return;
  b.disabled = true; await load(); render(); });
const stNone = (k) => neverLoaded() ? `<div class="notload">${notLoadedHtml()}</div>` : `<p>${ST_NONE[k]}</p>`;
// An empty list still offers the next step: the sample while there are no results at all, the
// whole list when only this tab is empty.
const stNext = (k) => { const n = k === "fresh" ? D.items.filter((x) => stOf(x) === "pending" && !libHide.has(iid(x))).length : 0;
  return !D.items.length ? `<p class="act"><button class="btn press" data-ob-sample="add">${tl("onboard.sampleadd")}</button></p>`
  : n ? `<p class="act"><button class="btn press" data-lib="pending">${tl("st.next.reply", {n})}</button></p>`
  : k !== "all" ? `<p class="act"><button class="btn press" data-lib="all">${tl("keybar.all")}</button></p>` : ""; };
// Why a result is where it is, in one line, from the fact the classifier decided on: the chip's
// tooltip on a PC, and the line a tap on the item's chip opens on a phone.
const ST_Y = LT(() => ({new: tl("st.y.new"), seen: tl("st.y.seen"), asked: tl("st.y.asked"), blocked: tl("st.y.blocked"), nosess: tl("st.y.nosess"), unread: tl("st.y.unread"),
  unread_gone: tl("st.y.unread_gone"), unread_old: tl("st.y.unread_old"), has: tl("st.y.has"), later: tl("st.y.later"), read: tl("st.y.read"), fresh: tl("st.y.fresh"), resting: tl("st.y.resting"),
  rested: tl("st.y.rested"), gone: tl("st.y.gone"), quiet: tl("st.y.quiet"), mine: tl("st.y.mine"), noclock: tl("st.y.noclock"), answer: tl("st.y.answer"), go: tl("st.y.go"),
  settled: tl("st.y.settled"), old: tl("st.y.old"), hold: tl("st.y.hold"), finished: tl("st.y.finished")}));
const stSpan = (ms) => { const m = Math.max(1, Math.round(ms / 6e4)); return m < 60 ? tl("st.span.m", {n: m}) : m < 1440 ? tl("st.span.h", {n: Math.round(m / 60)}) : tl("st.span.d", {n: Math.round(m / 1440)}); };
const stWhy = (x) => { const j = stJ(x), s = (j.again ? tl("st.y.again") + " · " : "") + (ST_Y[j.why] || ""); return s.split(" · ").filter((part) => j.since || !part.includes("{t}")).join(" · ").replace("{t}", j.since ? stSpan(Date.now() - j.since) : "").replace("{n}", x.asked || ""); };
const stTip = (x) => { const w = stWhy(x); return w ? ` title="${esc(w)}"` : ""; };
// The list a result is filed under (the tab key), its chip words, and the chip's colour: blue when
// the move is mine, orange for 멈춤 alone (the one that needs a nudge), plain for everything else.
const stOf = (x) => stTab(stK(x), x);
// Mine to answer: the two lists 내 차례 is made of (새로 온 것 + 답할 것).
const stMine = (x) => ST_MINE.includes(stOf(x));
const stName = (x) => stOf(x) === "fresh" && stK(x) === "check" ? tl("st.fresh") : ST_NAME[stK(x)] || "";
const stCls = (x) => { const k = stK(x); return k === "check" || k === "ask" ? "pending" : k === "stalled" ? "changes" : k === "approved" ? "approved" : "quiet"; };
// The status strip of the lists: every list always there, in one order, with its count (an empty
// one only dims), so "is there anything for me" is answered by a 0 and not by a missing tab.
// A thin rule sets apart whose move it is: mine | a session's | over. 전체 is the sum of them and
// sits at the end as a quiet control, not as a list among the lists. An empty list drops its hint line:
// its empty card says it in one line (신규가 없어요), not two. The counts come from the
// same memoised judge the cards use (stOf), so a count and its list can never disagree.
function stTabs(xs, sel, attr) {
  const n = {all: xs.length}; ST_MAIN.forEach((k) => { n[k] = 0; }); xs.forEach((x) => { n[stOf(x)]++; });
  const one = (k, c = "") => `<button class="press${c}${sel === k ? " on" : ""}${n[k] ? "" : " zero"}" role="tab" aria-selected="${sel === k}" data-${attr}="${k}">${ST_TABN[k]} <em class="num">${n[k]}</em></button>`;
  return `<div class="lstatw"><div class="lstat" data-sk="${attr}f" role="tablist">${ST_MAIN.map((k) => one(k, k === "undelivered" || k === ST_DONE ? " fin" : "")).join("")}${one("all", " all")}</div></div>${ST_HINT[sel] && n[sel] ? `<p class="lsub">${ST_HINT[sel]}</p>` : ""}`;
}
// The strip scrolls sideways on a narrow screen: a fade on the side that has more, the open tab in
// view, and the scroll kept where it was across a redraw.
const stScroll = {};
function stStrip(root) {
  const el = root && root.querySelector(".lstat"); if (!el) return;
  const k = el.dataset.sk, w = el.parentNode;
  const fade = () => { w.classList.toggle("fl", el.scrollLeft > 2); w.classList.toggle("fr", el.scrollLeft + el.clientWidth < el.scrollWidth - 2); stScroll[k] = el.scrollLeft; };
  el.scrollLeft = stScroll[k] || 0;
  const on = el.querySelector(".on");
  if (on && (on.offsetLeft < el.scrollLeft || on.offsetLeft + on.offsetWidth > el.scrollLeft + el.clientWidth)) el.scrollLeft = Math.max(0, on.offsetLeft - 24);
  el.addEventListener("scroll", fade, {passive: true}); fade();
}
const handed = (e) => !!(e.sent || e.delivered || e.ack);
const NOTE_T = LT(() => ({ack: [tl("NOTE_T.1"), "var(--green)"], sent: [tl("NOTE_T.2"), ""], unsent: [tl("NOTE_T.3"), "var(--orange)"]}));
const noteTag = (x) => { const n = NOTE_T[x.note]; return n ? ` · <span style="white-space:nowrap${n[1] ? `;color:${n[1]}` : ""}">${n[0]}</span>` : ""; };
// 나중에 (Linear's snooze): a result put aside leaves 내 차례 until its time, or sooner when a
// version other than the one it was put aside at arrives.
const snoozeOf = (x) => { const e = (D.snooze || {})[iid(x)]; return e && e.until * 1000 > Date.now() && (!e.v || e.v === x.v) ? e : null; };
// 내 차례 is exactly 새로 온 것 + 답할 것 (one rule, stMine): a version handed on unopened is not mine again.
// 나중에 보기 has no time: the row is put aside until something new happens on it. A result
// comes back with its next version (e.v); any other row of 할 일 with the mark it stood on (e.mark:
// the tool call a session waits on, a routine's last run). Same store as the timed snooze.
const SNZ_OPEN = 4102444800;              // 2100-01-01: "no time" in the store's epoch seconds
const asideOf = (key, mark) => { const e = (D.snooze || {})[key]; return e && e.until * 1000 > Date.now() && (e.mark == null || e.mark === mark) ? e : null; };
const myTurn = () => D.items.filter((x) => stMine(x) && !snoozeOf(x) && !libHide.has(iid(x))).sort(byAt);
const iid = (x) => x.project + "/" + x.id;
// The one name an item is filed and shown under (views.js groupName). "부서" is a team-mode idea
// only (user rule), so a folder's items never scatter across dept names outside 팀 모드. Used by
// the rail, the project/부서 page, the chips, the lib grouping and the compare column alike.
const teamMode = () => document.documentElement.dataset.unit === "dept";
const gname = (x) => groupName(x, teamMode());
// What a project is called on screen: the display name a person gave it, else its real name.
// The real name stays the key everywhere (routes, data-dept, pins), so a rename breaks no link.
// Results pushed from a group's rooms are filed under the group's name, so that name follows the
// group's display name too.
// A project's mark: the styled icon it was given (web/icons.js), else its emoji.
const identFace = (n, emoji) => (window.LOOP_ICONS ? LOOP_ICONS.face(D.ident?.[n]?.icon, emoji) : esc(emoji || ""));
// The sample's folder is named 샘플 on disk (onboard.py SAMPLE_PROJECT); it reads in the page's language.
const pname = (n) => { const i = D.ident?.[n]?.name, r = (i && i !== n ? i : D.gident?.[n]?.name) || i; return r && r !== n ? r : n === "샘플" ? tl("onboard.sampleProj") : n; };
// The same for a group (묶음): the register keeps its own name, the screens show this one.
const gpname = (g) => D.gident?.[g]?.name || g;
// The 사용 방식 knobs (web/custom.js LOOP_PREF; undefined until the options load): the sidebar
// titles the person renamed, and the word for what results are filed under (프로젝트 / 부서).
const knob = (k) => window.LOOP_PREF?.(k);
const prefName = (k) => (knob("names") || {})[k] || "";
const unitWord = () => unitCustom() || tl("ui.projects");
// ---------- menus: every one of the 21 stays reachable from 전체 ----------
// Tabs are what gets done most: see what's new, check results, talk, look at departments.
// 대화 took 알림's place on the phone (2026-10): what waits on me is the bell's, as on a PC.
const TABS = LT(() => ([["home",tl("ui.nav.home"),"home"],["project",tl("menu.chat"),"chat"],["lib",tl("TABS.3"),"lib"],["all",tl("all.tab"),"menu"]]));
// 알림 (#inbox: 할 일 · 소식 · 기록) has no menu row and no phone tab: the bell in the top bar is its
// one way in on every width. Its address, G I and old favourites/links still open it.
const MENUS = LT(() => ([
  {g:tl("MENUS.1"), k:"home", n:tl("ui.nav.home"), i:"home", c:"blue", d:tl("ui.nav.home.d")},
  {g:tl("MENUS.1"), k:"lib", n:tl("TABS.3"), i:"lib", c:"purple", d:tl("MENUS.4")},
  {g:tl("MENUS.1"), k:"project", n:tl("menu.chat"), i:"chat", c:"green", d:tl("menu.chat.d")},
  {g:tl("MENUS.1"), k:"depts", n:unitWord(), i:"folders", c:"teal", d:tl("menu.depts.d")},
  {g:tl("MENUS.1"), k:"routines", n:tl("routines.nav"), i:"clock", c:"orange", d:tl("routines.d")},
  {g:tl("MENUS.1"), k:"retro", n:tl("retro.nav"), i:"flag", c:"purple", d:tl("retro.d")},
  {g:tl("MENUS.1"), k:"search", n:tl("MENUS.5"), i:"search", c:"grey", d:tl("MENUS.6")},
  {g:tl("MENUS.1"), k:"settings", n:tl("TABS.4"), i:"gear", c:"grey", d:tl("MENUS.7")},
]));
// What to look at on each page, in one line; shown under 설정 as the manual.
const MANUAL = LT(() => ({
  home: tl("ui.nav.home.d"),
  inbox: tl("MANUAL.1"),
  dept: tl("MANUAL.2", {u: unitWord()}),
  lib: tl("MANUAL.3"),
  project: tl("menu.chat.d"),
  routines: tl("routines.d"),
  retro: tl("retro.d"),
  depts: tl("MANUAL.depts"),
  search: tl("MANUAL.4"),
  settings: tl("MANUAL.5"),
}));
// Pages folded into 받은함 keep working: old links, G keys, favourites and number keys that
// still name them land on the matching section.
const ALIAS = {mission: "inbox", alerts: "inbox/news", tasks: "inbox/log"};
// Four menus became two (2026-10): 모든 대화 is a tab of 대화, and the project list page gave its
// row to 프로젝트. The addresses #sessions and #dept still open their own screens; only the menu
// key moved, so a saved favourite, a number key or the sidebar highlight lands on the new row.
// 용량 (#storage) is a tab of 결과물 the same way: its own address, no row of its own.
const MOVED = {sessions: "project", dept: "depts", storage: "lib", board: "lib"};
const menuKey = (k) => { const a = (ALIAS[k] || k).split("/")[0]; return MOVED[a] || a; };
// The two tabs of 대화: 프로젝트별 (#project) and 최근 순 (#sessions). Drawn by both screens.
const chatTabs = (at) => `<div class="seg chtabs" role="tablist" aria-label="${esc(tl("menu.chat"))}">${[["project", tl("menu.chat.rooms")], ["sessions", tl("menu.sessions")]].map(([k, n]) =>
  `<button class="press ${k === at ? "on" : ""}" role="tab" aria-selected="${k === at}" data-go="${k}">${esc(n)}</button>`).join("")}</div>`;
const M = (k) => MENUS.find((m) => m.k === menuKey(k));
const menuIco = (m, cls = "ico") => `<span class="${cls} c-${m.c}">${ic(m.i)}</span>`;

// ---------- data ----------
// A dropped link (Tailscale asleep, Wi-Fi gone) read as the browser's English "Failed to fetch".
const netErr = () => Object.assign(new Error(tl("netErr.1")), {net: true});
// A server error in the page's language; `raw` keeps the server's own words for code that compares them.
// The server's own sentences are Korean. Anything else in its error (an exception's name, a
// proxy's words) says nothing to a person: the plain line is shown, the raw text is kept on .raw.
const srvSaid = (t) => typeof t === "string" && /[가-힣]/.test(t);
const srvErr = (t) => Object.assign(new Error((srvSaid(t) && srvT(t)) || tl("get.1")), {raw: t || ""});
const get = (p) => fetch(p, {cache:"no-store"}).catch(() => { throw netErr(); }).then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) throw srvErr(j.error); return j; });
const post = (p, body) => fetch(p, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)})
  .catch(() => { throw netErr(); }).then(async (r) => { const j = await r.json().catch(() => ({}));
    // The status and body ride on the error so a 409 {conflict} can be shown, not just toasted.
    if (!r.ok) throw Object.assign(srvErr(j.error), {status: r.status, body: j}); return j; });
// A 409 from an approval or a 맞아/아직: the review moved on while the reader was looking.
// What changed is listed in a calm sheet (or inline, inside the compare workspace) and the
// reader decides again - nothing is retried behind their back.
const isConflict = (e) => e && e.status === 409;
// changed: [{id, kind, v}] - the log entries written after the rev the screen read. With the
// item's log at hand each one shows its own words; without it, a short kind label.
function conflictHtml(body, v, log) {
  const b = body || {}, ch = Array.isArray(b.changed) ? b.changed : [];
  const said = (id) => { const e = id && (log || []).find((x) => x.id === id);
    return e?.text ? e.text.replace(/^\[[^\]]*\]\s*/, "") : ""; };
  const line = (c) => typeof c === "string" ? esc(c)
    : esc([c.v, c.text || c.summary || c.label || said(c.id) || (c.kind === "comment" ? tl("conflict.k_comment") : tl("conflict.k_other"))]
      .filter(Boolean).join(" · ").split(/\s+/).join(" ").slice(0, 120));
  const newer = b.latest && v && b.latest !== v;
  const rows = [newer && `<li class="cfnew">${tl("conflict.newer", {v: esc(b.latest)})}</li>`].concat(ch.slice(0, 6).map((c) => `<li>${line(c)}</li>`)).filter(Boolean);
  if (ch.length > 6) rows.push(`<li class="cfmore">${tl("conflict.more", {n: ch.length - 6})}</li>`);
  return `<div class="cfx" role="alert"><b class="cft">${tl("conflict.title")}</b><p class="cfs">${b.conflict ? esc(b.error || "") || tl("conflict.sub") : tl("conflict.norev")}</p>${rows.length ? `<ul class="cfl">${rows.join("")}</ul>` : ""}</div>`;
}
// opts: {v, log?, again: label of the re-decide button or null, retry(body) => Promise, reload(),
// can?(body): whether deciding again on the same screen still makes sense (default: no newer version)}
function conflictSheet(body, opts) {
  const b = body || {}, can = !!(b.conflict && opts.retry && (opts.can ? opts.can(b) : !b.stale && (!b.latest || b.latest === opts.v)));
  sheet(`<h3>${tl("conflict.h")}</h3>${conflictHtml(b, opts.v, opts.log)}
    <button class="btn xl fill press" id="cfre">${tl("conflict.reload")}</button>${can ? `<button class="btn xl press" id="cfgo" style="margin-top:8px">${esc(opts.again)}</button>` : ""}`, (el) => {
    el.querySelector("#cfre").onclick = () => { closeSheet(); opts.reload(); };
    const g = el.querySelector("#cfgo");
    if (g) g.onclick = async () => { g.disabled = true;
      try { await opts.retry(b); closeSheet(); }
      catch (e) { if (isConflict(e)) conflictSheet(e.body, opts); else { toast(e.message); g.disabled = false; } } };
  });
}
// A press by keyboard that redraws the screen (a chip, a tab, a fold, "more") removed the very button that was pressed,
// and focus fell to <body>: the next Tab started from the top of the page. For two seconds after Enter or Space the
// button's twin in the new drawing takes the focus back, unless focus has gone somewhere of its own accord.
let kfStop = null;
addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const a = document.activeElement, view = document.getElementById("view");
  if (!a || !view || !view.contains(a) || !a.matches("button,[role=button],[role=tab],[role=radio],[role=switch]")) return;
  if (kfStop) kfStop();
  const tag = a.tagName, id = a.id, ds = JSON.stringify(a.dataset), tx = (a.textContent || "").trim();
  const same = (x) => (id ? x.id === id : ds !== "{}" ? JSON.stringify(x.dataset) === ds : (x.textContent || "").trim() === tx);
  const nth = [...view.querySelectorAll(tag)].filter(same).indexOf(a);
  const back = () => {
    if (a.isConnected || document.activeElement !== document.body) return;
    const twins = [...view.querySelectorAll(tag)].filter(same), t = twins[nth] || twins[0];
    if (t) t.focus({preventScroll: true});
  };
  const mo = new MutationObserver(back); mo.observe(view, {childList: true, subtree: true});
  const tm = setTimeout(() => kfStop && kfStop(), 2000);
  const stop = () => { mo.disconnect(); clearTimeout(tm); removeEventListener("pointerdown", stop, true); kfStop = null; };
  kfStop = stop; addEventListener("pointerdown", stop, true);
}, true);

// Offline, the screen kept showing the last lists as if they were live. Say so, with a way back.
let lostMsg = "";
function netBar(on, srv) {
  let b = document.getElementById("netbar");
  if (!on) { b?.remove(); return; }
  lostMsg = srv ? tl("netBar.4") : tl("netBar.1");
  if (b) { b.firstElementChild.textContent = lostMsg; return; }
  b = document.createElement("div"); b.id = "netbar"; b.className = "netbar"; b.setAttribute("role", "status");
  b.innerHTML = `<span>${esc(lostMsg)}</span><button class="press">${tl("netBar.2")}</button>`;
  document.body.appendChild(b);
  const btn = b.querySelector("button");
  btn.onclick = async () => { btn.disabled = true; await load();
    if (!document.getElementById("netbar")) { toast(tl("netBar.3")); render(); } else btn.disabled = false; };
}
let loadLost = false;                       // the last load brought nothing: the top bar says so
async function load() {
  let lost = false, down = false;
  // A 500 on the two lists is as stale as no network: an old copy must not pass for a fresh sync.
  // A 200 that is not a list (a proxy's page, a half-written answer) is no answer either.
  const core = (p, d) => get(p).then((j) => { if (!Array.isArray(j)) throw srvErr(); return j; }).catch((e) => { lost = true; if (!e.net) down = true; return d; });
  const soft = (p, d) => get(p).catch((e) => { if (e.net) lost = true; return d; });
  // The identity map (a person's own display name for a project) rides along; it is optional, so
  // a miss keeps the last copy and never marks the load as lost.
  const [board, items, pf, cu] = await Promise.all([
    core("/api/board", D.board), core("/api/items", D.items), soft("/api/prefs", {}),
    get("/api/custom").catch(() => null)]);
  netBar(lost, down);
  // Nothing came: keep the old time, so "n분 전 동기화" does not claim a fresh copy.
  loadLost = lost;
  // One list of the two came: it is kept (the other stays as it was), the time is not moved.
  if (lost) { D = {...D, board, items}; return false; }
  D = {...D, board, items, ident: cu?.identity || D.ident || {}, gident: cu?.group_names || D.gident || {}, pins: pf.pins || D.pins || [], hidden: pf.hidden_projects || D.hidden || [], shelved: pf.shelved || D.shelved || [], placeNums: pf.place_nums || D.placeNums || {}, favs: pf.favs !== undefined ? pf.favs : D.favs, keys: pf.keys || D.keys || {}, snooze: pf.snooze || D.snooze || {}, room_read: pf.room_read || D.room_read || {}, seen_at: pf.seen_at || D.seen_at || "", profile_name: pf.profile_name !== undefined ? pf.profile_name : D.profile_name, fb: pf.feedback_url !== undefined ? pf.feedback_url : D.fb, fbEn: pf.feedback_url_en !== undefined ? pf.feedback_url_en : D.fbEn, fbImg: pf.feedback_images !== undefined ? !!pf.feedback_images : !!D.fbImg, at: new Date().toISOString()};
  if ((pf.alerts_seen || "") > alertsSeen) seeAlerts(pf.alerts_seen, false);   // read on the other device
  if (pf.news_read?.some((k) => !newsRead.has(k))) readNews(pf.news_read, false);
  try { localStorage.setItem("v2-cache", JSON.stringify({board, items, pins: D.pins, favs: D.favs, keys: D.keys, fb: D.fb, fbEn: D.fbEn, at: D.at})); } catch {}
  return true;
}

// ---------- routing: the hash is the page, so reload and the phone's back button both work ----------
// #inbox · #lib · #item/<p/i> · #dept/<key> · #settings
let cur = "inbox", detail = null, libF = "", libFAuto = true, libD = "", libQ = "", libK = "", libSel = null, ovT = "sum", ovR = "all", dayP = 0, acctSel = "a", dismissed = false, retroWk = 0;
const V = () => document.getElementById("view");
// One result to the next (다음, after 승인, N, a link inside a result) takes the place of the one on
// screen instead of stacking on it, so back leaves to the list it was opened from - not to the
// result before.
const nav = (hash) => { if (location.hash.slice(1) === hash) return render();
  if (hash.startsWith("item/") && location.hash.startsWith("#item/")) { history.replaceState(null, "", "#" + hash); return void dispatchEvent(new HashChangeEvent("hashchange")); }
  location.hash = hash; };
// Which layout: by device, not by width alone (as Slack, Linear and VS Code do - a narrow window on a
// PC keeps its menu and title bar, it does not become a phone). Phone layout: 720px and under, or a
// touch screen under 1024px. A mouse from 721px gets the desktop layout; under 1024px that is the
// compact one (menu folded to its icons, panels folded). The CSS reads the same condition.
const WIDE_Q = "(min-width:1024px),(min-width:721px) and (pointer:fine)";
const layoutOf = (w, fine) => w >= 1024 ? "wide" : w >= 721 && fine ? "compact" : "phone";
const wide = () => { try { return matchMedia(WIDE_Q).matches; } catch (e) { return layoutOf(innerWidth, false) !== "phone"; } };
const compact = () => wide() && layoutOf(innerWidth, true) === "compact";
// Many files under the stage pushed the comment box off a phone screen: the thumbs fold into
// one scrolling strip, open by default only on a PC, and the last choice is kept.
function sgOpen(set) {
  try { if (set !== undefined) localStorage.setItem("sgOpen", set ? "1" : "0"); const v = localStorage.getItem("sgOpen"); if (v) return v === "1"; } catch (e) {}
  return wide();
}
// Lab 4: the version strip and the file thumbs wait behind two buttons under the stage, folded
// until opened; the last choice is kept per strip ("v" versions, "f" files).
function mtOpen(k, set) {
  try { if (set !== undefined) localStorage.setItem("v2-mt-" + k, set ? "1" : "0"); return localStorage.getItem("v2-mt-" + k) === "1"; } catch (e) { return false; }
}
function mtSet(k, o) {
  const m = document.querySelector(".detailcols.item > .media"), b = m?.querySelector(`.mtb[data-mt="${k}"]`);
  if (!b) return;
  mtOpen(k, o); m.classList.toggle("mt-" + k + "0", !o);
  b.classList.toggle("on", o); b.setAttribute("aria-expanded", o);
  if (k === "v") document.querySelectorAll("#top [data-hver]").forEach((h) => { h.classList.toggle("on", o); h.setAttribute("aria-expanded", o); });
  if (o && k === "f") sgShow();
}
// Keep the thumb on the stage in sight inside the folded strip, without moving the page.
function sgShow() {
  const g = document.querySelector("#sgrid .sg.on"), r = g?.parentElement;
  if (!g || document.getElementById("sgw")?.classList.contains("open")) return;
  r.scrollTo({left: g.offsetLeft - (r.clientWidth - g.offsetWidth) / 2, behavior: RM() ? "auto" : "smooth"});
}

