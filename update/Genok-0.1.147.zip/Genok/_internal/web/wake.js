// Wake channel UI (design §6.3 B, §7): a 자동 깨우기 switch in settings, and a delivery-state
// chip on each directive with [다시 깨우기] / [다음 작업 때 전달] when a wake failed or its outcome
// is unknown (확인 필요). State comes from
// the server (it owns it); this file only shows it. Globals from v2.js: tl, post, toast, esc.
(function () {
  "use strict";

  // One small stylesheet, injected once.
  if (!document.getElementById("wake-css")) {
    const st = document.createElement("style");
    st.id = "wake-css";
    st.textContent = `
      .dir .wchip{display:inline-flex;align-items:center;gap:4px;margin-left:8px;padding:1px 8px;
        border-radius:8px;font-size:12px;font-weight:600;max-width:calc(100% - 8px);
        background:var(--chip,#eceef2);color:var(--chipf,#5b616e)}
      .dir .wchip.provided{--chip:#e6f0ff;--chipf:#2563c9}
      .dir .wchip.acked{--chip:#e7f6ec;--chipf:#1f8a4c}
      .dir .wchip.needs_check{--chip:#fff4e0;--chipf:#a35a00}
      .dir .wchip.reversioned{--chip:#eef0ff;--chipf:#5b52d6}
      .dir .wchip.confirmed{--chip:#e9f7ef;--chipf:#127a3d}
      .dir .wchip.failed{--chip:#fdecec;--chipf:#c0392b}
      .dir .wact{display:inline-flex;gap:6px;margin-left:8px}
      .dir .s:has(>.wchip){white-space:normal}
      /* two more buttons do not fit beside the comment: they take a line of their own under it */
      .row.note.dir:has(.wact){flex-wrap:wrap}
      .row.note.dir:has(.wact)>.tx{flex:1 1 60%}
      .row.note.dir:has(.wact) .dbtns{flex-wrap:wrap;justify-content:flex-end}
      .dir>.wact,.dir .dbtns>.wact{flex:1 0 100%;justify-content:flex-end;margin-left:0}
      #kwseg button{padding:0 2px;min-width:0;white-space:nowrap;font-size:13px}
      @media (prefers-color-scheme:dark){
        .dir .wchip{--chip:#2a2f3a;--chipf:#aab3c2}
        .dir .wchip.provided{--chip:#1d3352;--chipf:#8fbaff}
        .dir .wchip.acked{--chip:#173a29;--chipf:#79d7a1}
        .dir .wchip.needs_check{--chip:#43321a;--chipf:#ffc777}
        .dir .wchip.reversioned{--chip:#2a2960;--chipf:#b7b1ff}
        .dir .wchip.failed{--chip:#4a2320;--chipf:#ff9e94}}`;
    document.head.appendChild(st);
  }

  // ---- settings: 자동 깨우기 toggle (also carries {page,title} for the menu-page layout) ----
  function drawWake(el) {
    el.insertAdjacentHTML("beforeend", `<h2 class="seth">${tl("wake.title")}</h2>`);   // same page title as the sibling pages
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<div class="row"><span class="tx">
      <div class="t" style="font-size:16px">${tl("wake.auto")}</div>
      <div class="s">${tl("wake.autoDesc")}</div></span>
      <button class="sw" role="switch" aria-checked="false" id="wauto" aria-label="${tl("wake.auto")}"></button>
      </div><div style="height:6px"></div>`;
    el.appendChild(card);
    const b = card.querySelector("#wauto");
    const show = (v) => { b.classList.toggle("on", !!v); b.setAttribute("aria-checked", !!v); };
    fetch("/api/wakeauto").then((r) => r.json()).then((d) => show(d.on)).catch(() => {});
    b.onclick = async () => {
      const v = b.getAttribute("aria-checked") !== "true";
      show(v);
      try { show((await post("/api/wakeauto", {on: v})).on); }
      catch (e) { show(!v); toast(e.message); }
    };
    drawKeepWarm(el);
  }

  // ---- 세션 살려두기: how long a background session the app retired is brought back (0 = off) ----
  function drawKeepWarm(el) {
    const card = document.createElement("div");
    card.className = "card"; card.style.marginTop = "16px";   // it sat flush under the card above
    card.innerHTML = `<div class="row"><span class="tx">
      <div class="t" style="font-size:16px">${tl("wake.keepWarm")}</div>
      <div class="s">${tl("wake.keepWarmDesc")}</div></span></div>
      <div class="seg" id="kwseg" role="radiogroup" aria-label="${tl("wake.keepWarm")}"
        style="margin:8px 16px 14px;display:grid;grid-template-columns:repeat(6,minmax(0,1fr))"></div>`;
    el.appendChild(card);
    const seg = card.querySelector("#kwseg");
    const label = (h) => h ? tl("wake.hours", {n: h}) : tl("wake.off");
    const show = (d) => {
      seg.innerHTML = (d.choices || []).map((h) => `<button class="press ${h === d.hours ? "on" : ""}" role="radio"
        aria-checked="${h === d.hours}" data-h="${h}">${label(h)}</button>`).join("");
      seg.querySelectorAll("[data-h]").forEach((b) => b.onclick = async () => {
        const prev = d.hours, h = +b.dataset.h;
        if (h === prev) return;
        show(Object.assign({}, d, {hours: h}));
        try { show(await post("/api/keepwarm", {hours: h})); toast(h ? tl("wake.keepWarmSet", {n: h}) : tl("wake.keepWarmOff")); }
        catch (e) { show(Object.assign({}, d, {hours: prev})); toast(e.message); }
      });
    };
    fetch("/api/keepwarm").then((r) => r.json()).then(show).catch(() => {});
  }
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || [])
    .push(Object.defineProperty(Object.assign(drawWake, {page: "wake"}), "title", {get: () => tl("wake.title")}));   // read on every draw: follows the language

  // ---- per-directive delivery-state chip ----
  // Labels say only what the evidence shows (spec §5): 문맥 제공됨 is the hook's printed context,
  // not understanding; AI 수신 확인 needs the session to name the id back. The server no longer
  // sends "received"/"working" here; if an older server does, they read as 문맥 제공됨.
  function stateLabel(s) {
    switch (s) {
      case "provided": case "received": case "working": return tl("wake.provided");
      case "acked": return tl("wake.acked");
      case "dropped": return tl("att.lost.dropped.state");
      case "needs_check": return tl("wake.needsCheck");
      case "reversioned": return tl("wake.reversioned");
      case "confirmed": return tl("wake.confirmed");
      case "failed": return tl("wake.failed");
      default: return tl("wake.waiting");
    }
  }

  // The server writes its reason in Korean into the record. The fixed ones are said in the
  // screen's language here; anything else (a CLI's own last line) is shown as it came.
  function reasonText(r) {
    if (!r || typeof LANG !== "function" || LANG() === "ko") return r;
    const m = [
      [/^보낼 (세션을|대화를) 알 수 없어요/, tl("wake.r.noSession")],
      [/^(세션|대화) 기록을 찾을 수 없어 Claude\/Codex/, tl("wake.r.noProvider")],
      [/^(세션|대화) 기록을 찾을 수 없어요/, tl("wake.r.noRecord")],
      [/^시간당 깨우기 한도/, tl("wake.r.limit")],
      [/^앱에서 보관한 (세션|대화)/, tl("wake.r.archived")],
      [/^받았는지 확인 못 함/, tl("wake.r.unsure")],
      [/^(세션|대화) id 불완전/, tl("wake.r.badId")],
      [/^claude 없음/, tl("wake.r.noClaude")],
      [/^codex 없음/, tl("wake.r.noCodex")],
      [/^복사본/, tl("wake.r.copy")],
    ].find((x) => x[0].test(r));
    if (m) return m[1];
    const f = /^깨우기 실패(.*)$/.exec(r);
    return f ? tl("wake.failed") + f[1] : r;
  }

  function paint(el, st, ctx) {
    if (!st) return;
    el.querySelector(".wchip")?.remove();
    el.querySelector(".wact")?.remove();
    // A claimed row already reads "v00N에서 고쳤다고 함"; a "새 버전 옴" chip beside it said it twice.
    if (st.state === "reversioned" && el.classList.contains("claimed")) return;
    const tx = el.querySelector(".s") || el.querySelector(".tx");
    const chip = document.createElement("span");
    chip.className = "wchip " + st.state;
    const why = st.state === "failed" || st.state === "waiting" || st.state === "needs_check";
    chip.textContent = stateLabel(st.state) + (why && st.reason ? " · " + reasonText(st.reason) : "");
    // The delivery id rides along so a person can match it to what the session acked.
    if (st.dlv) chip.title = st.dlv;
    tx.appendChild(chip);
    // An unknown outcome is never re-run by itself: a person retries or leaves it for next time.
    if (st.state !== "failed" && st.state !== "needs_check") return;
    const act = document.createElement("span");
    act.className = "wact";
    act.innerHTML = `<button class="btn sm fill press" data-wr="retry">${tl("wake.retry")}</button>`
      + `<button class="btn sm weak press" data-wr="queue">${tl("wake.queue")}</button>`;
    (el.querySelector(".dbtns") || el).appendChild(act);
    act.querySelectorAll("[data-wr]").forEach((btn) => btn.onclick = async () => {
      btn.disabled = true;
      const action = btn.dataset.wr;
      try {
        await post("/api/wake", {p: ctx.p, i: ctx.i, id: el.dataset.did, action});
        toast(action === "retry" ? tl("wake.retried") : tl("wake.queued"));
        ctx.again();
      } catch (e) { toast(e.message); btn.disabled = false; }
    });
  }

  const cache = {};   // key -> {t, states}, a short TTL so one render shares one fetch
  function decorate(box, p, i, again) {
    const rows = box.querySelectorAll(".dir[data-did]");
    if (!rows.length) return;
    const key = p + "\u0000" + i, ctx = {p, i, again};
    const hit = cache[key];
    const apply = (states) => rows.forEach((el) => paint(el, states[el.dataset.did], ctx));
    if (hit && Date.now() - hit.t < 4000) { apply(hit.states); return; }
    fetch("/api/wake?p=" + encodeURIComponent(p) + "&i=" + encodeURIComponent(i))
      .then((r) => r.json())
      .then((d) => { cache[key] = {t: Date.now(), states: d.states || {}}; apply(cache[key].states); })
      .catch(() => {});
  }
  (window.LOOP_DIRECTIVE_DECOR = window.LOOP_DIRECTIVE_DECOR || []).push(decorate);
})();
