// Replay a comment's drawing on the media, at the frame it was drawn on - the viewing half of
// the Frame.io / SyncSketch feature. The drawing UI (pen, arrow, box, ellipse, colours, undo,
// clear) lives in v2.js beside the media player; on send the comment carries the flattened PNG
// (its thumbnail already shows in the note list) and the vector strokes in the picture's own 0-1
// space. Here, a "그림" chip on such a comment paints those strokes over the stage: hover on a
// PC, tap on a phone. Attached through window.LOOP_ITEM_VIEW (the per-item slot). Globals tl,
// esc, ic, openItem, stageAt, stageGo, mediaBox, whenTag come from v2.js and stamp.js.
//
// The pure geometry helpers are also exported for tests/draw.test.js.

(function () {
  "use strict";

  // ---- pure geometry (no DOM / no canvas), shared by the renderer and the tests ----
  const TOOLS = ["pen", "arrow", "rect", "ellipse"];
  const HEX = /^#[0-9a-fA-F]{3,8}$/;

  // The on-screen stroke width, matching the capture side in v2.js (inkStroke).
  function lineWidth(boxW) { return Math.max(3, boxW * 0.005); }

  // A 0-1 point into pixels inside the picture box {x, y, w, h}.
  function denorm(p, box) { return [box.x + p[0] * box.w, box.y + p[1] * box.h]; }

  // A shape (arrow / box / ellipse) is defined by its two ends; a pen keeps its whole path.
  function ends(stroke) { const p = stroke.p; return [p[0], p[p.length - 1]]; }

  // The three points of an arrowhead pointing from (x0,y0) to (x1,y1): the neck where the
  // shaft stops, and the two wing tips. Same geometry as the capture side.
  function arrowHead(x0, y0, x1, y1, lw) {
    const a = Math.atan2(y1 - y0, x1 - x0), hl = Math.max(lw * 4, 14);
    return {
      tip: [x1, y1],
      neck: [x1 - hl * 0.6 * Math.cos(a), y1 - hl * 0.6 * Math.sin(a)],
      wings: [[x1 - hl * Math.cos(a - 0.45), y1 - hl * Math.sin(a - 0.45)],
              [x1 - hl * Math.cos(a + 0.45), y1 - hl * Math.sin(a + 0.45)]],
    };
  }

  // The 0-1 bounding box over every point of every stroke, or null when there are none.
  function strokeBounds(strokes) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, any = false;
    (strokes || []).forEach((s) => (s && s.p || []).forEach((pt) => {
      any = true;
      minX = Math.min(minX, pt[0]); minY = Math.min(minY, pt[1]);
      maxX = Math.max(maxX, pt[0]); maxY = Math.max(maxY, pt[1]);
    }));
    return any ? { minX, minY, maxX, maxY } : null;
  }

  // Read-side validation, so a hand-edited review.json can never make the viewer throw.
  function validStroke(s) {
    return !!s && TOOLS.indexOf(s.t) >= 0 && typeof s.c === "string" && HEX.test(s.c)
      && Array.isArray(s.p) && s.p.length > 0
      && s.p.every((q) => Array.isArray(q) && q.length === 2 && Number.isFinite(q[0]) && Number.isFinite(q[1]));
  }
  function validDrawing(d) {
    return !!d && Array.isArray(d.strokes) && d.strokes.length > 0 && d.strokes.every(validStroke);
  }

  const HELPERS = { TOOLS, lineWidth, denorm, ends, arrowHead, strokeBounds, validStroke, validDrawing };
  if (typeof module !== "undefined" && module.exports) { module.exports = HELPERS; return; }

  // ---- browser: paint the strokes on an overlay over the stage ----
  function paintStroke(g, s, box) {
    const lw = lineWidth(box.w);
    g.strokeStyle = g.fillStyle = s.c; g.lineWidth = lw; g.lineCap = g.lineJoin = "round"; g.beginPath();
    if (s.t === "pen") {
      s.p.forEach((p, n) => { const xy = denorm(p, box); n ? g.lineTo(xy[0], xy[1]) : g.moveTo(xy[0], xy[1]); });
      if (s.p.length === 1) { const xy = denorm(s.p[0], box); g.lineTo(xy[0] + 0.1, xy[1]); }
      g.stroke(); return;
    }
    const e = ends(s), a = denorm(e[0], box), b = denorm(e[1], box), x0 = a[0], y0 = a[1], x1 = b[0], y1 = b[1];
    if (s.t === "rect") { g.strokeRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)); return; }
    if (s.t === "ellipse") { g.ellipse((x0 + x1) / 2, (y0 + y1) / 2, Math.abs(x1 - x0) / 2, Math.abs(y1 - y0) / 2, 0, 0, 2 * Math.PI); g.stroke(); return; }
    const h = arrowHead(x0, y0, x1, y1, lw);
    g.moveTo(x0, y0); g.lineTo(h.neck[0], h.neck[1]); g.stroke();
    g.beginPath(); g.moveTo(h.tip[0], h.tip[1]); g.lineTo(h.wings[0][0], h.wings[0][1]); g.lineTo(h.wings[1][0], h.wings[1][1]); g.closePath(); g.fill();
  }

  const STYLE = `
  .drawrp{position:absolute;inset:0;z-index:5;pointer-events:none;border-radius:inherit}
  .row.note .drawrep{display:inline-flex;align-items:center;gap:4px;margin-left:8px;vertical-align:middle;
    padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;color:var(--t2);
    background:rgba(127,127,127,.16);cursor:pointer}
  .row.note .drawrep svg{width:14px;height:14px}
  .row.note .drawrep:hover,.row.note .drawrep.on{color:var(--t1);background:rgba(127,127,127,.28)}`;

  let styled = false;
  function ensureStyle() {
    if (styled) return;
    const s = document.createElement("style"); s.textContent = STYLE; document.head.appendChild(s); styled = true;
  }

  const stage = () => document.getElementById("stage");
  function mediaEl() {
    const st = stage(); if (!st) return null;
    const sl = st.querySelectorAll(".sl")[stageAt];
    return sl ? sl.querySelector("img,video") : null;
  }

  let active = null, pinned = false, ro = null, chip = null;

  function clearOverlay() { const st = stage(), cv = st && st.querySelector(".drawrp"); if (cv) cv.remove(); }

  function paint() {
    if (!active) return;
    const st = stage(), m = mediaEl(); if (!st || !m) return;
    const b = mediaBox(m); if (!b) return;
    let cv = st.querySelector(".drawrp");
    if (!cv) { cv = document.createElement("canvas"); cv.className = "drawrp"; cv.setAttribute("aria-hidden", "true"); st.appendChild(cv); }
    const dpr = window.devicePixelRatio || 1, w = st.clientWidth, h = st.clientHeight;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    const sr = st.getBoundingClientRect(), box = { x: b.left - sr.left, y: b.top - sr.top, w: b.w, h: b.h };
    (active.draw.strokes || []).forEach((s) => { if (validStroke(s)) paintStroke(g, s, box); });
  }

  function listen(on) {
    const st = stage(), m = mediaEl();
    if (on && !ro && st) { ro = new ResizeObserver(paint); ro.observe(st); }
    else if (!on && ro) { ro.disconnect(); ro = null; }
    if (m) {
      const fn = on ? "addEventListener" : "removeEventListener";
      m[fn]("seeked", paint); m[fn]("loadedmetadata", paint);
    }
  }

  // Which file the drawing was left on: its own record, else the comment's tag, else the one on screen.
  function fileIndex(entry) {
    const pics = (openItem && openItem.pics) || [];
    const tag = whenTag(entry.text || "");
    const name = (entry.draw && entry.draw.file) || (tag && tag.name);
    const at = name ? pics.findIndex((f) => f.name === name) : -1;
    return at >= 0 ? at : stageAt;
  }

  function show(entry) {
    listen(false);
    active = entry;
    const at = fileIndex(entry);
    if (typeof stageGo === "function" && at !== stageAt) stageGo(at);
    const m = mediaEl(), pics = (openItem && openItem.pics) || [];
    if (m && m.tagName === "VIDEO") {
      const w = whenTag(entry.text || ""), f = pics[at];
      if (w) {
        const t = f && f.fps && w.frame != null ? frameAt(w.frame, f.fps, f.start) : w.t;
        if (Number.isFinite(t)) { try { m.pause(); m.currentTime = t; } catch (e) {} }
      }
    }
    // The slide may still be laying out (just switched) or the frame still seeking; a few
    // passes catch it without a permanent loop.
    requestAnimationFrame(paint); setTimeout(paint, 60); setTimeout(paint, 220);
    listen(true);
  }

  function hide(force) {
    if (pinned && !force) return;
    active = null; pinned = false;
    if (chip) { chip.classList.remove("on"); chip = null; }
    listen(false); clearOverlay();
  }

  function attach(box, it, detail) {
    if (!it || !it.p || !detail) return;
    hide(true);   // a fresh item render: drop any replay left from the previous one
    const draws = (detail.log || []).filter((e) => e.kind === "comment" && e.v === it.v && validDrawing(e.draw));
    if (!draws.length) return;
    ensureStyle();
    draws.forEach((e) => {
      const row = box.querySelector('.row.note[data-eid="' + e.id + '"]');
      if (!row || row.querySelector(".drawrep")) return;
      row.classList.add("has-draw");
      const nt = row.querySelector(".nt"); if (!nt) return;
      const btn = document.createElement("button");
      btn.type = "button"; btn.className = "drawrep press";
      btn.innerHTML = ic("eye") + "<span>" + esc(tl("draw.replay")) + "</span>";
      btn.setAttribute("aria-label", tl("draw.replay"));
      btn.addEventListener("pointerenter", (ev) => { if (ev.pointerType === "mouse" && !pinned) { chip = btn; btn.classList.add("on"); show(e); } });
      btn.addEventListener("pointerleave", (ev) => { if (ev.pointerType === "mouse" && !pinned) { btn.classList.remove("on"); hide(false); } });
      btn.addEventListener("click", (ev) => {
        ev.preventDefault();
        if (active === e && pinned) { btn.classList.remove("on"); hide(true); return; }
        hide(true); chip = btn; btn.classList.add("on"); show(e); pinned = true;
      });
      nt.appendChild(btn);
    });
  }

  window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || [];
  window.LOOP_ITEM_VIEW.push(attach);
})();
