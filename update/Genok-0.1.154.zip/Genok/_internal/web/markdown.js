// Markdown documents pushed to the hub, shown as a readable page instead of raw text.
// A small subset - headings, paragraphs, nested and task lists, tables, code, quotes, rules,
// **bold**, *italic*, ~~struck~~, `code`, http(s) links and pictures - built as DOM nodes, never innerHTML, so a pushed
// file cannot run script here. Plain script loaded before app.js; the parser exports for
// node tests. The session pane draws Claude's own messages through it too, which is why
// renderMarkdown takes a class: the same blocks, laid out for a page or for a bubble.

const GENOK_HOST = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(?=\/f\/)/;
const GENOK_PIC = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/f\/[^?#]+\.(png|jpe?g|gif|webp)$/i;

// A file a message names (src/app.py, C:\x\y.js, ./a.md) with an optional :line. Said in passing
// it counts only with a folder in it or a line after it, so "e.g." or `os.path` stays text.
const FILE_PATH = String.raw`((?:[A-Za-z]:[\\/]|\.{1,2}[\\/])?(?:[\w.@+-]+[\\/])*[\w@+-][\w.@+-]*\.[A-Za-z][A-Za-z0-9]{0,7})`;
const FILE_LINE = String.raw`(?::(\d+)(?:[:-]\d+)?)?`;
const FILE_ONLY = new RegExp(`^${FILE_PATH}${FILE_LINE}$`);
const FILE_IN_TEXT = String.raw`(?<![\w/\\:.@+-])${FILE_PATH}${FILE_LINE}(?![\w/\\])`;
// A first folder with a dot inside it is a host or prose (github.com/x.md, e.g./i.e.), not a
// folder; a dot folder (.github/) and ./ ../ stay files.
const DOTTED_HEAD = /^[^\\/.][^\\/]*\.[^\\/]*[\\/]/;
const fileRef = (path, line) => (!DOTTED_HEAD.test(path) && (/[\\/]/.test(path) || line) ? { path, line: line ? +line : 0 } : null);
// Text ending in an unfinished absolute path ("C:/Users/a ") means the path had a space and
// the match is only its tail, which would open the wrong file.
const SPLIT_PATH = /(?:^|\s)(?:[A-Za-z]:|~)?[\\/]\S*\s+$/;
const NAMED_FILE = /\.[A-Za-z][A-Za-z0-9]{0,7}(?::\d+)?\s+$/;
// The file a FILE_IN_TEXT match at `at` names, else null. Only the text just before it is looked at.
function fileAt(text, at, path, line) {
  const f = fileRef(path, line), before = text.slice(Math.max(0, at - 260), at);
  return f && !(SPLIT_PATH.test(before) && !NAMED_FILE.test(before)) ? f : null;
}
// The file a whole `code` run names, else null.
function codeFile(s) {
  const m = FILE_ONLY.exec(s);
  return m ? fileRef(m[1], m[2]) : null;
}

function inlineRuns(text) {
  const out = [];
  const say = (v) => { const p = out[out.length - 1]; if (p && p.t === "text") p.v += v; else out.push({ t: "text", v }); };
  // A picture is a link with a bang in front, so it has to be tried first. Its address is
  // held to the two shapes a link already is: somewhere on the web, or a file on the hub.
  // A bare address is a link too (sessions paste them as is); a trailing stop or bracket stays text.
  // Emphasis needs a letter right inside each mark, so "2 * 3 * 4" stays text, and an underscore
  // inside a word (snake_case) is not one.
  const re = new RegExp(/!\[([^\]\n]*)\]\((https?:\/\/[^)\s]+|\/[mf]\/[^)\s]+)\)|\*\*\*(?=\S)([^*\n]*?[^*\s])\*\*\*|\*\*([^*\n]+)\*\*|\*(?=\S)([^*\n]*?[^*\s])\*|(?<!\w)_(?=\S)([^_\n]*?[^_\s])_(?!\w)|~~(?=\S)([^~\n]*?[^~\s])~~|`([^`\n]+)`|\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)|(https?:\/\/[^\s<>"'`]*[^\s<>"'`.,;:!?)\]])/.source
    // A file: [name](src/a.py#L42) as the VS Code extension writes it, or a bare src/a.py:42.
    + String.raw`|\[([^\]\n]+)\]\(${FILE_PATH}(?:#L(\d+)[^)\s]*|:(\d+)[^)\s]*)?\)|${FILE_IN_TEXT}`
    // A backslash before a punctuation mark keeps the mark as text (\*not italic\*, 1\_000).
    // Nothing else starts at a backslash, so being last does not cost it a match.
    + /|\\([!-\/:-@\[-`{-~])/.source, "g");
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) say(text.slice(last, m.index));
    if (m[18] != null) { say(m[18]); last = re.lastIndex; continue; }
    // A file on this PC's Genok is asked for by path, so the same line draws on the phone too.
    if (m[2] != null) out.push({ t: "img", v: m[1], href: m[2].replace(GENOK_HOST, "") });
    else if (m[3] != null) out.push({ t: "bi", v: m[3] });
    else if (m[4] != null) out.push({ t: "b", v: m[4] });
    else if (m[5] != null || m[6] != null) out.push({ t: "em", v: m[5] != null ? m[5] : m[6] });
    else if (m[7] != null) out.push({ t: "del", v: m[7] });
    else if (m[8] != null) out.push({ t: "code", v: m[8], ...codeFile(m[8]) });
    else if (m[11] != null) out.push({ t: "link", v: m[11], href: m[11] });
    else if (m[13] != null) out.push({ t: "file", v: m[12], path: m[13], line: +(m[14] || m[15] || 0) });
    else if (m[16] != null) { const f = fileAt(text, m.index, m[16], m[17]); if (f) out.push({ t: "file", v: m[0], ...f }); else say(m[0]); }
    // A named link to a picture on this PC's Genok: other chats show the name, this one draws it.
    else if (GENOK_PIC.test(m[10])) out.push({ t: "img", v: m[9], href: m[10].replace(GENOK_HOST, "") });
    else out.push({ t: "link", v: m[9], href: m[10] });
    last = re.lastIndex;
  }
  if (last < text.length) say(text.slice(last));
  return out;
}

const LIST_RE = /^\s*([-*+]|\d+[.)])\s+(.*)$/;
const listType = (marker) => (/\d/.test(marker) ? "ol" : "ul");
const indentOf = (l) => /^\s*/.exec(l.replace(/\t/g, "    "))[0].length;

// One list from line n on, and the line it ended at. A list line indented past this list's own
// starts a list inside the last item; one at the same depth (of the same kind) is the next item.
// "[ ] " / "[x] " in front of an item makes it a task: checks[i] is false or true, null for none.
function parseList(lines, n) {
  const first = LIST_RE.exec(lines[n]), base = indentOf(lines[n]), type = listType(first[1]);
  const items = [], subs = [], checks = [];
  const add = (text) => {
    const t = /^\[([ xX])\]\s+(.*)$/.exec(text);
    items.push(t ? t[2] : text); checks.push(t ? t[1] !== " " : null); subs.push(null);
  };
  add(first[2]);
  for (;;) {
    const next = lines[n + 1] || "";
    const nx = LIST_RE.exec(next), ind = indentOf(next);
    if (nx && ind > base) {
      const child = parseList(lines, n + 1);
      (subs[subs.length - 1] = subs[subs.length - 1] || []).push(child.block);
      n = child.n;
    } else if (nx && ind === base && listType(nx[1]) === type) { add(nx[2]); n++; }
    else if (next.trim() && !nx && ind > base && ind >= 2) { items[items.length - 1] += ` ${next.trim()}`; n++; }
    else break;
  }
  const block = { type, items };
  // A numbered list split by a code block goes on from its own number (CommonMark <ol start>).
  const start = type === "ol" ? parseInt(first[1], 10) : 1;
  if (start !== 1) block.start = start;
  if (subs.some(Boolean)) block.subs = subs;
  if (checks.some((c) => c != null)) block.checks = checks;
  return { block, n };
}

function parseMarkdown(src) {
  const lines = src.replace(/\r\n?/g, "\n").split("\n");
  const blocks = [];
  let para = [];
  const flush = () => { if (para.length) { blocks.push({ type: "p", text: para.join(" ") }); para = []; } };
  // GFM: an escaped pipe (\|) is a literal pipe inside the cell, not a column break.
  const cells = (l) => l.trim().replace(/^\||(?<!\\)\|$/g, "").split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, "|"));
  for (let n = 0; n < lines.length; n++) {
    const l = lines[n];
    let m;
    if ((m = /^(`{3,}|~{3,})\s*([\w+#.-]*)/.exec(l.trim()))) {
      flush();
      // CommonMark: only a run of the same character, at least as long, closes the fence,
      // so a ````markdown block can quote a ```js block inside it.
      const fence = m[1], code = [], lang = m[2];
      const close = new RegExp("^" + fence[0] + "{" + fence.length + ",}$");
      while (++n < lines.length && !close.test(lines[n].trim())) code.push(lines[n]);
      // open: the closing fence has not arrived yet (an answer still being written).
      blocks.push({ type: "code", text: code.join("\n"), lang, open: n >= lines.length });
    } else if (!l.trim()) {
      flush();
    } else if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) {
      flush();
      blocks.push({ type: "h", level: m[1].length, text: m[2].trim() });
    } else if (/^\s*([-*_])\s*(\1\s*){2,}$/.test(l)) {
      flush();
      blocks.push({ type: "hr" });
    } else if (/^\s*\|/.test(l) && /^\s*\|?\s*:?-{2,}/.test(lines[n + 1] || "")) {
      flush();
      const head = cells(l), rows = [];
      // :-- / :-: / --: in the divider row set each column's alignment.
      const align = cells(lines[++n]).map((c) => (/^:-+:$/.test(c) ? "center" : /-:$/.test(c) ? "right" : /^:-/.test(c) ? "left" : null));
      while (/^\s*\|/.test(lines[n + 1] || "")) rows.push(cells(lines[++n]));
      const block = { type: "table", head, rows };
      if (align.some(Boolean)) block.align = align;
      blocks.push(block);
    } else if ((m = /^\s*>\s?(.*)$/.exec(l))) {
      flush();
      const q = [m[1]];
      while ((m = /^\s*>\s?(.*)$/.exec(lines[n + 1] || ""))) { q.push(m[1]); n++; }
      // A quote holds blocks of its own (lists, code, paragraphs), as in CommonMark.
      const text = q.join("\n").trim();
      blocks.push({ type: "quote", text, blocks: parseMarkdown(text) });
    } else if ((m = LIST_RE.exec(l))) {
      flush();
      const list = parseList(lines, n);
      blocks.push(list.block);
      n = list.n;
    } else {
      para.push(l.trim());
    }
  }
  flush();
  return blocks;
}

// Code block colours for the languages a session writes most: comments, strings, numbers and
// keywords (JSON keys apart), and the added/removed lines of a diff. Runs of {t, v}; t "" is
// plain text. Other languages, and very long blocks, stay one plain run.
const CODE_LANG = { js: "js", javascript: "js", jsx: "js", ts: "js", typescript: "js", tsx: "js", mjs: "js", cjs: "js",
  py: "py", python: "py", sh: "sh", bash: "sh", shell: "sh", zsh: "sh", console: "sh", json: "json", jsonc: "json",
  diff: "diff", patch: "diff" };
const CODE_KW = {
  js: "as async await break case catch class const continue default delete do else enum export extends false finally for from function if implements import in instanceof interface let new null of readonly return static super switch this throw true try type typeof undefined var void while yield",
  py: "and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return self True try while with yield",
  sh: "case cd do done echo elif else esac exit export fi for function if in local return set then until while",
  json: "false null true",
};
const CODE_STR = {
  js: String.raw`\x60(?:\\[\s\S]|[^\\\x60])*\x60?|'(?:\\.|[^\\'\n])*'?|"(?:\\.|[^\\"\n])*"?`,
  py: String.raw`[rRbBfFuU]{0,2}(?:'''[\s\S]*?(?:'''|$)|"""[\s\S]*?(?:"""|$)|'(?:\\.|[^\\'\n])*'?|"(?:\\.|[^\\"\n])*"?)`,
  sh: String.raw`'[^']*'?|"(?:\\[\s\S]|[^\\"])*"?`,
  json: String.raw`"(?:\\.|[^\\"\n])*"?`,
};
const C_COM = String.raw`\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$)`;
const CODE_COM = { js: C_COM, py: String.raw`#[^\n]*`, sh: String.raw`(?<!\S)#[^\n]*`, json: C_COM };
const CODE_RE = {};
function codeTokens(text, lang) {
  const k = CODE_LANG[String(lang || "").toLowerCase()];
  if (!k || text.length > 40000) return [{ t: "", v: text }];
  const out = [], put = (t, v) => { if (!v) return; const l = out[out.length - 1]; if (l && l.t === t) l.v += v; else out.push({ t, v }); };
  if (k === "diff") {
    text.split("\n").forEach((l, i) => {
      if (i) put("", "\n");
      put(/^(\+\+\+|---)( |$)/.test(l) ? "m" : l.startsWith("@@") ? "h" : l[0] === "+" ? "a" : l[0] === "-" ? "d" : "", l);
    });
    return out;
  }
  const re = CODE_RE[k] || (CODE_RE[k] = new RegExp(String.raw`(${CODE_COM[k]})|(${CODE_STR[k]})|(\b(?:0[xX][\da-fA-F_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?)\b)|(\b(?:${CODE_KW[k].replace(/ /g, "|")})\b)`, "g"));
  let at = 0, m;
  re.lastIndex = 0;
  while ((m = re.exec(text))) {
    if (!m[0]) { re.lastIndex++; continue; }
    put("", text.slice(at, m.index));
    // A JSON string followed by ":" is a key.
    put(m[1] ? "c" : m[2] ? (k === "json" && /^\s*:/.test(text.slice(re.lastIndex, re.lastIndex + 40)) ? "p" : "s") : m[3] ? "n" : "k", m[0]);
    at = re.lastIndex;
  }
  put("", text.slice(at));
  return out;
}

function renderMarkdown(text, cls) {
  // A file named in the text is only marked here (data-fp): the session chat makes it a button.
  // A link's own text ([`a.py`](a.py#L3), [**x**](url)) keeps its code and bold; inside it
  // (`bare`) nothing is a link or a file again, so a link never holds another.
  const runs = (s, bare) => inlineRuns(s).map((r) => (r.t === "b" ? h("strong", {}, runs(r.v, bare))
    : r.t === "bi" ? h("strong", {}, h("em", {}, runs(r.v, bare)))
    : r.t === "em" ? h("em", {}, runs(r.v, bare))
    : r.t === "del" ? h("del", {}, runs(r.v, bare))
    : r.t === "code" ? h("code", bare ? {} : { "data-fp": r.path, "data-ln": r.line || null }, r.v)
    : bare && (r.t === "file" || r.t === "link" || r.t === "img") ? r.v
    : r.t === "file" ? h("span", { "data-fp": r.path, "data-ln": r.line || null }, runs(r.v, true))
    : r.t === "img" ? h("img", { src: r.href, alt: r.v, loading: "lazy" })
    : r.t === "link" ? h("a", { href: r.href, target: "_blank", rel: "noopener" }, runs(r.v, true))
    : r.v));
  // A task shows a box that only reports its state: ticking it here would change nothing.
  const list = (b) => h(b.type, { start: b.start }, b.items.map((it, i) => {
    const c = b.checks && b.checks[i];
    return h("li", { class: c != null && "task" },
      c != null && h("input", { type: "checkbox", checked: c, disabled: true }), runs(it),
      b.subs && b.subs[i] && b.subs[i].map(list));
  }));
  const block = (b) => {
    if (b.type === "h") return h(`h${Math.min(b.level + 1, 4)}`, {}, runs(b.text));   // the page title sits above
    if (b.type === "p") return h("p", {}, runs(b.text));
    if (b.type === "ul" || b.type === "ol") return list(b);
    if (b.type === "table") {
      const al = (i) => b.align && b.align[i] && `text-align:${b.align[i]}`;
      return h("div", { class: "doc-table" }, h("table", {},
        h("thead", {}, h("tr", {}, b.head.map((c, i) => h("th", { style: al(i) }, runs(c))))),
        h("tbody", {}, b.rows.map((r) => h("tr", {}, r.map((c, i) => h("td", { style: al(i) }, runs(c))))))));
    }
    if (b.type === "code") {
      // Coloured once the block is finished: while it streams it stays plain text.
      const pre = h("pre", {}, h("code", { class: b.lang && `language-${b.lang}` },
        b.open ? b.text : codeTokens(b.text, b.lang).map((r) => (r.t ? h("span", { class: `tk-${r.t}` }, r.v) : r.v))));
      // A finished mermaid block is marked for mermaid-view.js, which draws it in place.
      return b.lang === "mermaid" && !b.open ? h("div", { class: "mmd" }, pre) : pre;
    }
    if (b.type === "quote") return h("blockquote", {}, b.blocks.map(block));
    return h("hr");
  };
  return h("article", { class: cls || "doc" }, parseMarkdown(text).map(block));
}

// Whether a short note is written in markdown at all: plain comments stay plain text, so a
// stray "-" or "#1" in a sentence is not turned into a list or a heading.
function looksMarkdown(text) {
  const s = String(text == null ? "" : text);
  return /\*\*[^*\n]+\*\*|\*(?=\S)[^*\n]*[^*\s]\*|~~(?=\S)[^~\n]*[^~\s]~~|`[^`\n]+`|\[[^\]\n]+\]\(https?:\/\/|https?:\/\/\S/.test(s)
    || /^(#{1,6}\s|```|>\s|\|.*\|\s*$)/m.test(s)
    || (s.match(/^\s*(?:[-*+]|\d+[.)])\s+\S/gm) || []).length >= 2;
}

// The Genok results a message links to: http://localhost:8777/i/<project>/<item>[/<version>], the
// tailnet form of the same, or a bare /i/... path. At most `max`, each result once, in order.
const GENOK_ITEM = /(?:^|[\s(\["'])(?:https?:\/\/(?:localhost|127\.0\.0\.1|desktop-calars\.tail73335e\.ts\.net)(?::\d+)?)?\/i\/([^\/\s?#<>"'`)\]]+)\/([^\/\s?#<>"'`)\]]+)(?:\/([^\/\s?#<>"'`)\]]+))?/g;
function genokLinks(text, max = 3) {
  const out = [], seen = new Set(), un = (s) => { try { return decodeURIComponent(s); } catch (e) { return s; } };
  for (const m of String(text == null ? "" : text).matchAll(GENOK_ITEM)) {
    const end = (x) => x.replace(/[.,;:!?]+$/, ""), l = { project: un(m[1]), item: un(m[3] ? m[2] : end(m[2])), v: m[3] ? un(end(m[3])) : "" }, k = `${l.project}/${l.item}/${l.v}`;
    if (seen.has(k)) continue;
    seen.add(k); out.push(l);
    if (out.length >= max) break;
  }
  return out;
}

if (typeof module !== "undefined") module.exports = { parseMarkdown, inlineRuns, looksMarkdown, genokLinks, codeTokens };
