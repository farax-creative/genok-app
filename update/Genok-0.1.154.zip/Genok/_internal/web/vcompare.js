// Pure helpers for version comparison, shared by v2.js (loaded as a browser global before it)
// and the node tests. No DOM here on purpose: the canvas/UI work stays in v2.js, the math and
// the "what changed" reading live here where they can be tested.

// Pixel difference between two equal-size RGBA buffers (a = older, b = newer). Returns a new
// RGBA buffer where unchanged areas fall back to a dim grayscale of the newer frame and pixels
// that moved are painted a warm highlight scaled by how far they moved. `threshold` is the
// average per-channel delta (0..255) below which a pixel counts as unchanged; `ratio` is the
// fraction of pixels that changed, for the "바뀐 부분 N%" readout.
function diffPixels(a, b, width, height, opts) {
  opts = opts || {};
  const thr = opts.threshold == null ? 24 : opts.threshold;
  const n = width * height;
  const Arr = typeof Uint8ClampedArray !== "undefined" ? Uint8ClampedArray : Array;
  const out = new Arr(n * 4);
  let changed = 0;
  for (let i = 0; i < n; i++) {
    const j = i * 4;
    const d = (Math.abs(a[j] - b[j]) + Math.abs(a[j + 1] - b[j + 1]) + Math.abs(a[j + 2] - b[j + 2])) / 3;
    if (d > thr) {
      changed++;
      const s = Math.min(1, d / 128);                 // stronger change -> hotter
      out[j] = 255; out[j + 1] = Math.round(200 - s * 160); out[j + 2] = Math.round(120 - s * 90); out[j + 3] = 255;
    } else {
      const g = Math.round((b[j] * 0.299 + b[j + 1] * 0.587 + b[j + 2] * 0.114) * 0.42);
      out[j] = out[j + 1] = out[j + 2] = g; out[j + 3] = 255;
    }
  }
  return {data: out, width, height, changed, ratio: n ? changed / n : 0};
}

// What the transition between two versions reports changing. `a` and `b` are version objects
// ({v, summary, later}); the earlier one is read as the "from", the later as the "to".
// `directives` are the item's asks; the ones a version claims to have fixed carry `fixed_in`.
// Returns only what is actually present, so the caller can skip an empty panel.
function versionChanges(a, b, directives) {
  a = a || {}; b = b || {};
  const [older, newer] = (a.v || "") <= (b.v || "") ? [a, b] : [b, a];
  const fixed = (directives || [])
    .filter((d) => d && d.fixed_in === newer.v)
    .map((d) => (d.text || "").split(/\s+/).join(" ").trim())
    .filter(Boolean);
  return {from: older.v || "", to: newer.v || "", summary: (newer.summary || "").trim(), later: (newer.later || "").trim(), fixed};
}

// What one version says it fixed: the asks marked fixed when it was pushed (`v.fixed.ids`, written by
// push --fixed) and any ask whose fix points at it (`fixed_in`). Returns null for a version that
// carries neither (older data), so the caller draws nothing. The ask's leading [file time] tag is dropped.
function fixedInVersion(v, directives) {
  if (!v || !v.v) return null;
  const ids = new Set((v.fixed && v.fixed.ids) || []);
  const rows = (directives || []).filter((d) => d && (d.fixed_in === v.v || ids.has(d.id)));
  const n = Math.max(rows.length, ids.size);
  if (!n) return null;
  const texts = rows.map((d) => (d.text || "").replace(/^\[[^\]]*\]\s*/, "").split(/\s+/).join(" ").trim()).filter(Boolean);
  return {n, texts};
}

// Per-version counts for the version timeline strip. `versions` are the item's versions in any
// order ({v, at}); `directives` are its asks. For each version it reports how many directives
// that version claims to have fixed (fixed_in) and how many were first raised on it (v). The
// result keeps the input order, so the caller renders it left-to-right as it likes.
function timelineBadges(versions, directives) {
  const dirs = directives || [];
  return (versions || []).map((w) => {
    const v = (w && w.v) || "";
    return {
      v,
      at: (w && w.at) || null,
      fixed: dirs.filter((d) => d && d.fixed_in === v).length,
      raised: dirs.filter((d) => d && d.v === v).length,
    };
  });
}

// stamp.js helpers: the browser loads stamp.js before this file, so whenTag/PIN_W are globals;
// node requires them. Reached only when the overlay code below runs, never at load time.
const _stamp = typeof module !== "undefined" ? require("./stamp.js") : null;
const _whenTag = (t) => (_stamp ? _stamp.whenTag : whenTag)(t);
const _PINRE = () => (_stamp ? _stamp.PIN_W : PIN_W);

// Downscale target for the video diff: cap the width (≤1024 keeps a per-frame diff cheap) while
// keeping the newer frame's aspect. Whole pixels, never below 1x1, so a canvas can size to it.
function diffSize(natW, natH, maxW) {
  maxW = maxW || 1024;
  const w = Math.max(1, Math.min(Math.round(natW) || maxW, maxW));
  const h = Math.max(1, Math.round(w * (natH || 1) / (natW || 1)));
  return {w, h};
}

// Two compared versions at different pixel sizes: return a short "W×H ↔ W×H" label so the reader
// is told, and never let a caller scale the smaller up to match. "" when the sizes agree or one
// is still unknown (a video before loadedmetadata, an image that failed to load).
function resMismatch(a, b) {
  if (!a || !b) return "";
  const aw = Math.round(a.w || 0), ah = Math.round(a.h || 0), bw = Math.round(b.w || 0), bh = Math.round(b.h || 0);
  if (!aw || !ah || !bw || !bh) return "";
  if (aw === bw && ah === bh) return "";
  return `${aw}×${ah} ↔ ${bw}×${bh}`;
}

// A comment box may hold several directives typed one per line. Split it into trimmed, non-empty
// lines so each line can be sent as its own directive; a single line or blank text yields ≤1.
// A pasted list keeps its words, not its bullets: "- a" / "1. a" / "• a" all become "a".
const LIST_MARK = /^(?:[-*+•·]|\d{1,3}[.)])\s+/;
function splitDirectives(text) {
  return String(text == null ? "" : text).split(/\r?\n/).map((s) => s.trim().replace(LIST_MARK, "").trim())
    .filter((s) => s && !/^[-*+•·]$/.test(s));      // an empty bullet is not a directive
}
// The comments a split sends, in order: each line with the same file/moment tag in front.
function splitPlan(text, tag) {
  return splitDirectives(text).map((ln) => (tag ? `[${tag}] ${ln}` : ln));
}

// Align the older video to the driving (newer) one's time. Two cuts are matched by absolute time;
// once the drive runs past the older cut's end, its last moment is held instead of re-seeking.
// Returns {t, past}: the time to seek the older video to, and whether the drive is past its end.
function alignTime(driveT, otherDuration) {
  const dur = Number.isFinite(otherDuration) ? otherDuration : Infinity;
  const past = driveT >= dur;
  const t = dur === Infinity ? Math.max(0, driveT) : Math.max(0, Math.min(driveT, Math.max(0, dur - 1e-3)));
  return {t, past};
}

// Frame-accurate step for the scrub rail arrows: move n frames from t and land in the middle of
// the target frame so the decoder settles there (matches frameOf's floor). No fps -> 0.1s steps.
// Clamps to [0, duration).
function stepTime(t, fps, n, duration) {
  const hasDur = Number.isFinite(duration);
  const cap = hasDur ? Math.max(0, duration - 1e-3) : Infinity;
  if (!fps) return Math.max(0, Math.min(cap, t + n * 0.1));
  const last = hasDur ? Math.max(0, Math.round(duration * fps) - 1) : Infinity;
  const fr = Math.max(0, Math.min(last, Math.floor(t * fps + 1e-4) + n));
  return (fr + 0.5) / fps;
}

// A pin's coordinates from a comment tag ("[... 위치(가로42%,세로60%) ...]"), pure so the overlay
// can be tested without the DOM. Null when the tag carries no pin. A region tag
// ("위치(가로10%,세로20%,폭30%,높이15%)") also gives w/h: x/y are then its top-left corner.
function pinCoords(text) {
  const m = /^\[([^\]]{1,200})\]/.exec(text || ""); if (!m) return null;
  const w = m[1].split(/\s+/).find((x) => _PINRE().test(x)); if (!w) return null;
  const nums = w.match(/\d+/g); if (!nums || nums.length < 2) return null;
  return nums.length >= 4 ? {x: +nums[0], y: +nums[1], w: +nums[2], h: +nums[3]} : {x: +nums[0], y: +nums[1]};
}

// 지시 위치 겹쳐 보기: the marks the previous version's comments carried (a pin, a moment, or a
// stretch), to lay over the newer frame in compare. `newerV` is the version on the stage; a mark
// counts as fixed when a department claimed it fixed in this version or an earlier one (fixed_in).
// Only comments that actually point somewhere (pin or time tag) come back, so the caller can hide
// an empty toggle. Order is preserved.
function overlayFromPrev(items, newerV) {
  const out = [];
  for (const e of items || []) {
    const text = e.text || "";
    const when = _whenTag(text), pin = pinCoords(text);
    if (!when && !pin) continue;
    out.push({
      id: e.id == null ? null : e.id,
      text,
      x: pin ? pin.x : null,
      y: pin ? pin.y : null,
      ...(pin && pin.w != null ? {w: pin.w, h: pin.h} : {}),   // a region: drawn as a box
      name: when ? when.name : "",
      t: when ? when.t : null,
      frame: when ? (when.frame == null ? null : when.frame) : null,
      t2: when ? (when.t2 == null ? null : when.t2) : null,
      frame2: when ? (when.frame2 == null ? null : when.frame2) : null,
      fixed: !!(e.fixed_in && String(e.fixed_in) <= String(newerV || "")),
    });
  }
  return out;
}

// ---- Compare workspace (cmpview.js): the pure parts ----

// The file of `ver` that a compare pane shows: the one named `prefName` when the version has it,
// else the same name once a version token is dropped (sh030_v002.mp4 finds sh030_v001.mp4, the way
// Blender and Nuke name their outputs), else its first video, image, then page. Null when nothing
// there can be laid side by side.
const unversioned = (n) => String(n || "").replace(/(^|[_.\- ])v\d+(?=[_.\- ]|$)/gi, "").toLowerCase();
function pickCompareFile(ver, prefName) {
  const fs = (ver && ver.files) || [];
  const shown = (f) => f.kind === "image" || f.kind === "video";
  const bare = prefName ? unversioned(prefName) : "";
  return fs.find((f) => shown(f) && f.name === prefName)
    || (bare && fs.find((f) => shown(f) && unversioned(f.name) === bare))
    || fs.find((f) => f.kind === "video") || fs.find((f) => f.kind === "image") || fs.find((f) => f.kind === "html") || null;
}

// What the pair can do: two videos play in step, two images wipe and zoom together, anything else
// (a page, a video against a picture) only sits side by side.
function compareKind(fa, fb) {
  if (fa && fb && fa.kind === "video" && fb.kind === "video") return "video";
  if (fa && fb && fa.kind === "image" && fb.kind === "image") return "image";
  return "other";
}

// Which way round two versions are read: the lower number is 이전, the higher 지금. The same
// version on both sides says so instead of naming one older.
function pairRoles(a, b) {
  if (a === b) return ["same", "same"];
  return a < b ? ["older", "newer"] : ["newer", "older"];
}

// Upload time as the labels show it: "9월 30일 오후 2:05" (the year only when it is not this one).
function whenLabel(iso, now, lang) {
  const d = new Date(iso); if (!iso || isNaN(d)) return "";
  const n = now ? new Date(now) : new Date();
  const h = d.getHours(), m = String(d.getMinutes()).padStart(2, "0");
  if (lang === "en") {
    const mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][d.getMonth()];
    return `${mon} ${d.getDate()}${d.getFullYear() === n.getFullYear() ? "" : ", " + d.getFullYear()}, ${h % 12 || 12}:${m} ${h < 12 ? "AM" : "PM"}`;
  }
  const part = h < 12 ? "오전" : "오후", h12 = h % 12 || 12;
  return `${d.getFullYear() === n.getFullYear() ? "" : d.getFullYear() + "년 "}${d.getMonth() + 1}월 ${d.getDate()}일 ${part} ${h12}:${m}`;
}

// Zoom and pan shared by every pane: a scale `s` and the offset of the picture's top-left as a
// fraction of the pane (fx, fy), so two panes of different sizes show the same part. Kept in range
// so the picture never leaves an empty edge: 1 - s <= f <= 0. `max` defaults to 8x of fit.
function clampView(view, min, max) {
  const s = Math.min(max || 8, Math.max(min || 1, view.s));
  const cl = (f) => s <= 1 ? 0 : Math.min(0, Math.max(1 - s, f));
  return {s, fx: cl(view.fx), fy: cl(view.fy)};
}
// Zoom by `factor` keeping the point (cx, cy), given as fractions of the pane, under the pointer.
function zoomAt(view, factor, cx, cy, min, max) {
  const s2 = Math.min(max || 8, Math.max(min || 1, view.s * factor)), k = s2 / view.s;
  return clampView({s: s2, fx: cx - (cx - view.fx) * k, fy: cy - (cy - view.fy) * k}, min, max);
}
// Drag by (dx, dy) pixels in a pane of w x h.
function panBy(view, dx, dy, w, h, max) {
  return clampView({s: view.s, fx: view.fx + dx / (w || 1), fy: view.fy + dy / (h || 1)}, 1, max);
}
// The wipe divider's place as a percent of the pane, held inside it.
function wipePct(clientX, left, width) {
  return width > 0 ? Math.min(100, Math.max(0, (clientX - left) / width * 100)) : 50;
}

if (typeof module !== "undefined") module.exports = {diffPixels, versionChanges, fixedInVersion, timelineBadges, diffSize, resMismatch, splitDirectives, splitPlan, alignTime, stepTime, pinCoords, overlayFromPrev,
  pickCompareFile, compareKind, pairRoles, whenLabel, clampView, zoomAt, panBy, wipePct};
