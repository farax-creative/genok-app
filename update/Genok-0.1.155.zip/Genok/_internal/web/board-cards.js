// 설정 → 베타 "board" (docs/beta-flags.md): what the board's cards gain from PAI's canvas, all
// behind the switch. web/boardview.js asks BoardView.beta() and calls in here at a few fixed
// points (a card drawn, the next card, a wire's chip, the detail panel, a rail step, the zoom);
// with the switch off this file returns at its top, window.BoardCards stays unset and the board
// is the one it was. The data comes as added fields on /api/boardview (boardview.py, beta only).
//
// Pure parts (badges, progress, change chip, file runs, zoom level) are tested in
// tests/board_cards.test.js; the DOM parts use v2.js globals (tl, esc, ic, vShort, post, toast).
(function () {
  "use strict";

  // ---- pure

  // The corner badges of a version card: comments on that version, open directives on the newest
  // one, and the approval - on the approved card itself, and named on the newest when it is older;
  // first a star on the version that holds the item's cover picture.
  // A version the user put up by hand says so. [{k: "cover"|"mine"|"c"|"o"|"ok", n?, v?, changed?}]
  function badges(it, v, last) {
    const out = [];
    if (it.cover && it.cover.v === v.v) out.push({k: "cover"});
    if (v.author === "user") out.push({k: "mine"});
    if (v.comments > 0) out.push({k: "c", n: v.comments});
    if (last && it.open && it.open.length) out.push({k: "o", n: it.open.length});
    const a = it.approved;
    if (a && a.v === v.v) out.push({k: "ok", changed: !!a.changed});
    else if (a && last) out.push({k: "ok", v: a.v, changed: true});
    return out;
  }

  // How far the open directives behind a next card got: wait (nothing has them yet), sent (a
  // session's inbox has them), work (a session is on it now), fail (a session stopped with no new
  // version). `kind` is the list classifier's answer for the item (status.js, stK in v2.js).
  function progress(x, kind) {
    if (kind === "work") return "work";
    if (kind === "stalled" || kind === "old") return "fail";
    if (x && (x.reach === "delivered" || x.reach === "ack" || kind === "queued" || kind === "done")) return "sent";
    return "wait";
  }

  // What a version changed against the one before it, for its wire (boardview.py change_kind):
  // {k, add, del} for files added or taken away (counted by vdiff.js over the sorted names), {k, dim}
  // otherwise - a reorder or new words only is drawn faint. Null: nothing to say.
  function change(a, b, diff) {
    const k = b.change_kind;
    if (!k || k === "first" || k === "same") return null;
    if (k !== "files") return {k, dim: k === "order" || k === "note"};
    const names = (v) => (v.files || []).map((f) => f.name).sort().join("\n");
    const s = diff.diffStat(diff.lineDiff(names(a), names(b)));
    return {k, add: s.add, del: s.del};
  }

  // The directives a version answered, as small nodes on its wire: the first few, and how many more.
  const DN_MAX = 3;
  const dnodes = (fixed) => ({shown: (fixed || []).slice(0, DN_MAX), more: Math.max(0, (fixed || []).length - DN_MAX)});

  // A version's files as a short strip: a run of numbered frames folds into one entry (seqgroup.js),
  // the first few are shown and `more` counts the files left out (of `total`, which can be more than
  // the list when the server sent only the first ones). [{i, f, run?: {count, from, to}}]
  const STRIP_MAX = 6;
  function strip(files, total, seq) {
    const rs = seq.runs(files), shown = [];
    let i = 0;
    while (i < files.length && shown.length < STRIP_MAX) {
      const r = seq.at(rs, i);
      shown.push(r ? {i, f: files[i], run: {count: r.count, from: seq.num(files[r.start].name), to: seq.num(files[r.end].name)}} : {i, f: files[i]});
      i = r ? r.end + 1 : i + 1;
    }
    return {shown, more: Math.max(0, (total || files.length) - i)};
  }

  // A model the 3D view can turn: a .glb or .gltf file the server can hand over.
  const is3d = (f) => !!f && !!f.play && /\.(glb|gltf)$/i.test(f.name);
  // A version whose thumb is that model's cube: it has no picture of its own.
  const cubeTh = (v) => !v.thumb && is3d((v.files || [])[0]);

  // How much a card shows at a zoom: far (under half size) the picture and the title, near (twice
  // the size and more) its files, its comment pins and a video under the pointer to scrub.
  const lod = (k) => (k < .5 ? "far" : k >= 2 ? "near" : "mid");

  // Where a picture of w x h lies inside a thumbnail of bw x bh shown whole (contain), in percent of
  // the thumbnail, so a pin at x%,y% of the picture lands on it. Null when the size is not known.
  function fitBox(w, h, bw, bh) {
    if (!(w > 0 && h > 0)) return null;
    const r = (w / h) / (bw / bh);
    return r > 1 ? {l: 0, t: (100 - 100 / r) / 2, w: 100, h: 100 / r} : {l: (100 - 100 * r) / 2, t: 0, w: 100 * r, h: 100};
  }

  const api = {badges, progress, change, dnodes, strip, is3d, cubeTh, lod, fitBox};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;
  if (!window.genokBeta?.("board")) return;

  // ---- on the page

  const ST = () => ({wait: tl("bc.st.wait"), sent: tl("bc.st.sent"), work: tl("bc.st.work"), fail: tl("bc.st.fail")});
  const kindOf = (x) => { try { return typeof stK === "function" && x ? stK(x) : ""; } catch (e) { return ""; } };

  function badgeHtml(b) {
    if (b.k === "mine") return `<span class="bd-badge mine">${ic("pen")}${esc(tl("bc.mine"))}</span>`;
    if (b.k === "cover") return `<span class="bd-badge cover" title="${esc(tl("bc.cover"))}">${ic("star")}</span>`;
    if (b.k === "c") return `<span class="bd-badge" title="${esc(tl("bc.comments", {n: b.n}))}">${ic("chat")}${b.n}</span>`;
    if (b.k === "o") return `<span class="bd-badge open" title="${esc(tl("board.open", {n: b.n}))}">${ic("flag")}${b.n}</span>`;
    const t = b.v ? tl("bc.okv", {v: vShort(b.v)}) : tl("bc.ok");
    return `<span class="bd-badge ok${b.changed ? " was" : ""}">${ic("check")}${esc(b.changed ? tl("bc.changed", {t}) : t)}</span>`;
  }
  const badgeRow = (it, v, last) => { const bs = badges(it, v, last); return bs.length ? `<span class="bd-badges">${bs.map(badgeHtml).join("")}</span>` : ""; };

  // The card holding the cover shows that file - a video at its moment - in place of its first one.
  function coverTh(th, n) {
    const c = n.it.cover, f = c && c.v === n.v.v && !n.v.removed && (n.v.files || []).find((x) => x.name === c.name);
    if (!f || (f === n.v.files[0] && c.t == null)) return;
    th.querySelector("img")?.remove();
    if (f.kind === "video" && f.play) th.insertAdjacentHTML("beforeend", `<video src="${esc(f.play)}#t=${c.t || 0}" muted playsinline preload="metadata"></video>`);
    else if (f.thumb) th.insertAdjacentHTML("beforeend", imgTag(f.thumb, {drag: false}));
  }

  // A card the board has not shown before is marked once, the first time it is drawn (per board
  // and browser, "v2-bdseen"). A board seen for the first time marks nothing.
  const SEEN = "v2-bdseen", SEEN_MAX = 2000;
  let seenNow = null;
  function fresh(key, id) {
    if (!seenNow || seenNow.key !== key) {
      let had = null;
      try { const a = JSON.parse(localStorage.getItem(SEEN) || "{}")[key]; had = Array.isArray(a) ? new Set(a) : null; } catch { /* this page only */ }
      seenNow = {key, had, all: new Set()};
      queueMicrotask(() => {
        const s = seenNow; seenNow = null;
        try { const a = JSON.parse(localStorage.getItem(SEEN) || "{}"); a[s.key] = [...new Set([...(s.had || []), ...s.all])].slice(-SEEN_MAX); localStorage.setItem(SEEN, JSON.stringify(a)); } catch { /* this page only */ }
      });
    }
    seenNow.all.add(id);
    return !!seenNow.had && !seenNow.had.has(id);
  }

  // Comment pins on the picture, shown up close (the picture is then shown whole, v2.css [data-lod=near]).
  const TH_H = 96;      // v2.css .bd .th height; the width is the card's
  function pins(th, v) {
    const f = (v.files || [])[0], box = v.kind === "image" && v.pins && v.pins.length && f && fitBox(f.w, f.h, BoardView.CW, TH_H);
    if (!box) return;
    th.insertAdjacentHTML("beforeend", `<span class="bd-pins" aria-hidden="true" style="left:${box.l}%;top:${box.t}%;width:${box.w}%;height:${box.h}%">`
      + v.pins.map((p) => `<i style="left:${p.x}%;top:${p.y}%"></i>`).join("") + `</span>`);
  }
  // Up close, the video playing under the pointer follows it across the card instead of running.
  function scrub(d) {
    d.addEventListener("pointermove", (e) => {
      const vid = d.querySelector(".th video");
      if (!vid || !vid.duration || !d.closest("[data-lod=near]")) return;
      const r = d.getBoundingClientRect();
      vid.pause(); vid.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * vid.duration;
    });
  }
  // The board's zoom changed (boardview.js apply()). Far out the title keeps a readable size on
  // screen: v2.css divides it by the scale (--bdk).
  function zoom(vp, k) {
    const l = lod(k); if (vp.dataset.lod !== l) vp.dataset.lod = l;
    const s = l === "far" ? k.toFixed(2) : ""; if (vp.style.getPropertyValue("--bdk") !== s) vp.style.setProperty("--bdk", s);
  }

  const fileTh = (f) => (f.thumb ? imgTag(f.thumb, {drag: false}) : ic((KIND[f.kind] || ["doc"])[0]));
  const runName = (run) => tl("bc.frames", {from: run.from, to: run.to, n: run.count});
  const stripOf = (v) => strip(v.files || [], v.files_n, window.SeqGroup);

  // A version card was just drawn (boardview.js canvas()). With more than one file it says how
  // many more, and a strip of them shows under it while it is pointed at, picked or zoomed in on.
  function card(d, n, key) {
    const th = d.querySelector(".th");
    if (fresh(key, n.id)) d.classList.add("bd-new");
    coverTh(th, n);
    if (cubeTh(n.v)) th.querySelector("svg.i").outerHTML = ic("cube");
    th.insertAdjacentHTML("beforeend", badgeRow(n.it, n.v, n.last));
    pins(th, n.v);
    if (n.v.kind === "video") scrub(d);
    if (!(n.v.files_n > 1)) return;
    const {shown, more} = stripOf(n.v);
    d.classList.add("bd-multi");
    th.insertAdjacentHTML("beforeend", `<span class="bd-plus">+${n.v.files_n - 1}</span>`);
    d.insertAdjacentHTML("beforeend", `<span class="bd-files" aria-hidden="true">${shown.map(({f, run}) => `<i>${fileTh(f)}${run ? `<b>${run.count}</b>` : ""}</i>`).join("")}${more ? `<em>+${more}</em>` : ""}</span>`);
  }

  // The dashed next card: its count, and how far the work on it got.
  function next(d, n) {
    const st = progress(n.it.sum, kindOf(n.it.sum));
    d.dataset.stage = st;
    d.innerHTML = `<span class="bd-nx"><b>${esc(tl("board.open", {n: n.it.open.length}))}</b>`
      + `<span class="bd-st"><i class="bd-steps3" aria-hidden="true"><u></u><u></u><u></u></i>${esc(ST()[st])}</span>`
      + (st === "fail" ? `<span class="bd-hint">${esc(tl("bc.st.keep"))}</span>` : "") + `</span>`;
    d.title = ST()[st];
  }

  // The chip on the line between two versions: what changed, and the directives it answered as
  // small nodes (each says the version it was asked on; pointing at one marks that card).
  const CK = () => ({replace: tl("bc.ck.replace"), order: tl("bc.ck.order"), note: tl("bc.ck.note")});
  function chip(l, nodes) {
    if (l.next) return null;
    const c = typeof lineDiff === "function" ? change(l.a.v, l.b.v, {lineDiff, diffStat}) : null;
    const {shown, more} = dnodes(l.b.v.fixed);
    if (!c && !shown.length) return null;
    const el = document.createElement("span");
    el.className = "bd-chip bd-wire";
    const ck = !c ? "" : c.k === "files"
      ? `<span class="bd-ck">${c.add ? `<b class="add">+${c.add}</b>` : ""}${c.del ? `<b class="del">−${c.del}</b>` : ""}</span>`
      : `<span class="bd-ck${c.dim ? " dim" : ""}">${esc(CK()[c.k] || "")}</span>`;
    el.innerHTML = ck + shown.map((x) => `<span class="bd-dn" data-from="${esc(x.from || "")}" title="${esc(x.text)}"><em>${esc(vShort(x.from || ""))}</em><span>${esc(x.text)}</span></span>`).join("")
      + (more ? `<span class="bd-dn more">${esc(tl("bc.more", {n: more}))}</span>` : "");
    // Pointing at a directive marks the card it was asked on.
    const born = (v) => nodes.find((o) => o.type === "ver" && o.it === l.b.it && o.v.v === v);
    el.querySelectorAll(".bd-dn[data-from]").forEach((b) => {
      b.onpointerenter = () => born(b.dataset.from)?.el.classList.add("bd-born");
      b.onpointerleave = () => born(b.dataset.from)?.el.classList.remove("bd-born");
    });
    return el;
  }

  // A rail step's badges (the phone's version rows), and the open directives that end a row.
  const step = (v, it, last) => badgeRow(it, v, last);
  // A rail step's thumb (boardview.js thumbOf): a model with no picture shows the cube, as its card does.
  const railThumb = (v, html) => (cubeTh(v) ? html.replace(/<svg class="i"[\s\S]*?<\/svg>/, ic("cube")) : html);
  function railNext(it) {
    const st = progress(it.sum, kindOf(it.sum));
    return `<span class="bd-fb open" data-stage="${st}">${esc(tl("board.open", {n: it.open.length}))}`
      + `<span class="bd-st"><i class="bd-steps3" aria-hidden="true"><u></u><u></u><u></u></i>${esc(ST()[st])}</span>`
      + (st === "fail" ? `<span class="bd-hint">${esc(tl("bc.st.keep"))}</span>` : "") + `</span>`;
  }

  // What a refresh must redraw for: the work state of the next card.
  const sig = (x) => progress(x, kindOf(x));

  // One file of a version, as the detail panel's preview (boardview.js preview() for the first).
  const pvOf = (f, title) => !f.play ? ""
    : f.kind === "image" ? `<div class="bd-pv">${imgTag(f.play, {lazy: false, drag: false})}</div>`
    : f.kind === "video" ? `<div class="bd-pv"><video src="${esc(f.play)}"${f.thumb ? ` poster="${esc(f.thumb)}"` : ""} controls playsinline preload="metadata"></video></div>`
    : f.kind === "html" ? `<div class="bd-pv page"><iframe src="${esc(keyUrl(f.play))}" title="${esc(title)}" sandbox="allow-scripts allow-popups"></iframe></div>` : "";

  // Put `html` in the preview's place (there may be none yet: the first file had nothing to show).
  function setPv(det, html) {
    const old = det.querySelector(".bd-pv");
    if (old && html) old.outerHTML = html;
    else if (old) old.remove();
    else if (html) det.querySelector(".x").insertAdjacentHTML("afterend", html);
    det.classList.toggle("wide", !!html);
    return det.querySelector(".bd-pv");
  }

  // The strip of a version's files under its summary: a press shows that file; a run of frames
  // shows its first one with a slider over the rest.
  function fileStrip(det, n, pick) {
    const v = n.v, {shown, more} = stripOf(v);
    det.querySelector(":scope > .s").insertAdjacentHTML("afterend", `<div class="bd-dfiles" role="group" aria-label="${esc(tl("bc.files"))}">`
      + shown.map(({i, f, run}) => `<button class="press${i ? "" : " on"}" data-bcf="${i}" aria-pressed="${!i}" title="${esc(run ? runName(run) : f.name)}">${fileTh(f)}${run ? `<b>${run.count}</b>` : ""}</button>`).join("")
      + (more ? `<span>${esc(tl("bc.more", {n: more}))}</span>` : "") + `</div>`);
    const row = det.querySelector(".bd-dfiles");
    row.querySelectorAll("[data-bcf]").forEach((b) => b.onclick = () => {
      row.querySelectorAll("[data-bcf]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", String(x === b)); });
      const i = +b.dataset.bcf, f = v.files[i], run = shown.find((s) => s.i === i).run, pv = setPv(det, pvOf(f, n.it.title));
      pick(f);
      if (!run || !pv) return;
      const end = i + run.count - 1, img = pv.querySelector("img");
      pv.insertAdjacentHTML("beforeend", `<input class="bd-scrub" type="range" min="${i}" max="${end}" value="${i}" aria-label="${esc(runName(run))}">`);
      pv.querySelector(".bd-scrub").oninput = (e) => { const g = v.files[+e.target.value]; img.src = g.play; pick(g); };
    });
  }

  // ---- 3D: a .glb/.gltf file turns in the detail panel (three.js r147, web/vendor/three/, fetched
  // the first time one is opened). It draws only while it moves; one view is alive at a time.
  const calm = () => matchMedia("(prefers-reduced-motion:reduce)").matches;
  let threeLib = null, live3d = null;
  const loadThree = () => threeLib || (threeLib = ["three.min.js", "GLTFLoader.js", "OrbitControls.js"].reduce((p, f) => p.then(() => new Promise((ok, no) => {
    const el = document.createElement("script"); el.src = "/vendor/three/" + f; el.onload = ok; el.onerror = no; document.head.appendChild(el);
  })), Promise.resolve()).catch((e) => { threeLib = null; throw e; }));

  // {shot(): {blob, pos, at}} once the model is up; rejects when the file or the library does not load.
  async function view3d(det, f) {
    live3d?.end();
    const pv = setPv(det, `<div class="bd-pv bd-3d"><canvas aria-label="${esc(f.name)}"></canvas><span class="bd-3dmsg">${esc(tl("bc.3dLoad"))}</span></div>`);
    const cv = pv.querySelector("canvas"), msg = pv.querySelector(".bd-3dmsg");
    try {
      await loadThree();
      const T = window.THREE, gltf = await new Promise((ok, no) => new T.GLTFLoader().load(f.play, ok, undefined, no));
      if (!cv.isConnected) return null;
      const r = new T.WebGLRenderer({canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true});
      r.setPixelRatio(Math.min(2, devicePixelRatio)); r.outputEncoding = T.sRGBEncoding;
      const scene = new T.Scene(), sun = new T.DirectionalLight(0xffffff, 1.4);
      sun.position.set(3, 5, 4); scene.add(new T.HemisphereLight(0xffffff, 0x445566, 1.1), sun, gltf.scene);
      const cam = new T.PerspectiveCamera(40, 1, .01, 1000), ctl = new T.OrbitControls(cam, cv);
      ctl.enableDamping = !calm(); ctl.dampingFactor = .12;
      // The whole model in view, from a little above and to the side: its bounding sphere (radius
      // size/2) fits the 40° view at size/2 / sin(20°), about 1.46 size.
      const box = new T.Box3().setFromObject(gltf.scene), size = box.getSize(new T.Vector3()).length() || 1, mid = box.getCenter(new T.Vector3());
      ctl.target.copy(mid); cam.near = size / 100; cam.far = size * 100;
      cam.position.copy(mid).add(new T.Vector3(.6, .45, .9).normalize().multiplyScalar(size * 1.5));
      let raf = 0;
      const fit = () => { r.setSize(cv.clientWidth, cv.clientHeight, false); cam.aspect = cv.clientWidth / Math.max(1, cv.clientHeight); cam.updateProjectionMatrix(); };
      const draw = () => { raf = 0; if (!cv.isConnected) return end(); const moving = ctl.update(); r.render(scene, cam); if (moving) ask(); };
      const ask = () => { if (!raf) raf = requestAnimationFrame(draw); };
      const ro = new ResizeObserver(() => { fit(); ask(); });
      const end = () => { cancelAnimationFrame(raf); ro.disconnect(); ctl.dispose(); r.dispose(); r.forceContextLoss(); if (live3d === me) live3d = null; };
      const me = {end};
      live3d = me; ro.observe(cv); ctl.addEventListener("change", ask); fit(); ask(); msg.remove();
      const three = (v) => v.toArray().map((x) => +x.toFixed(3)).join(", ");
      return {shot: () => new Promise((ok) => { r.render(scene, cam); cv.toBlob((blob) => ok({blob, pos: three(cam.position), at: three(ctl.target)}), "image/png"); })};
    } catch (e) {
      msg.textContent = tl("bc.3dFail");
      throw e;
    }
  }

  // ---- the detail panel (boardview.js show()): the files, and a row of actions above "항목 열기"
  function detail(det, n, again) {
    const go = det.querySelector(".go"), acts = [];
    let file = (n.v.files || [])[0];             // the file the preview shows
    let model = null;                            // the 3D view of `file`, when it is a model (a promise)
    const turn = () => { model = is3d(file) && !n.v.removed ? view3d(det, file) : null; model?.catch(() => {}); shotBtn(); };
    if (n.v.files_n > 1) fileStrip(det, n, (f) => { file = f; coverBtn(); turn(); });
    // 대표로: this file (a video at the moment it is paused on) stands for the item; again on the cover takes it off.
    const isCover = () => !!file && n.it.cover?.v === n.v.v && n.it.cover?.name === file.name;
    const coverBtn = () => { const b = det.querySelector("[data-bccover]"); if (!b) return;
      b.hidden = !file || n.v.removed || !["image", "video"].includes(file.kind);
      b.lastChild.textContent = isCover() ? tl("bc.coverOff") : tl("bc.coverSet"); };
    acts.push([`<button class="btn weak press" data-bccover>${ic("star")}<span></span></button>`, (b) => b.onclick = async () => {
      const it = {p: n.it.project, i: n.it.id}, off = isCover(), vid = det.querySelector(".bd-pv video");
      b.disabled = true;
      try {
        await post("/api/boardcover", off ? {...it, clear: true} : {...it, v: n.v.v, name: file.name, ...(file.kind === "video" && vid ? {t: vid.currentTime} : {})});
        toast(off ? tl("bc.coverGone") : tl("bc.coverDone")); again();
      } catch (e) { b.disabled = false; toast(e.message); }
    }]);
    // The conversation that made this version (as the item screen's 이 버전을 만든 대화).
    if (n.v.session_id) acts.push([`<button class="btn weak press" data-bcmade>${ic("chat")}${esc(tl("bc.made"))}</button>`, (b) => b.onclick = async () => {
      const sid = n.v.session_id, s = await get("/api/project/session?id=" + encodeURIComponent(sid)).catch(() => null);
      if (!s || !s.found || !s.project) return toast(tl("itemView.madeGone"));
      nav("project/" + encodeURIComponent(s.project) + "/" + encodeURIComponent(sid));
    }]);
    // 내 수정본 올리기 (newest card): the user's own fix goes up as the next version. When one came
    // up since this panel was drawn, it asks here first whether to add it after that one.
    if (n.last) acts.push([`<button class="btn weak press" data-bcup>${ic("up")}<span>${esc(tl("bc.up"))}</span></button><input type="file" hidden data-bcfile>`, (b) => {
      const pick = b.nextElementSibling, label = b.lastChild, q = (k) => encodeURIComponent(k);
      const send = async (f, force) => {
        b.disabled = true; label.textContent = tl("bc.upping");
        try {
          const now = force ? null : (await get(`/api/boardlatest?p=${q(n.it.project)}&i=${q(n.it.id)}`)).latest;
          if (now && now !== n.v.v) return ask(f, now);
          const r = await fetch(`/api/board/upload?p=${q(n.it.project)}&i=${q(n.it.id)}&base=${q(n.v.v)}&n=${q(f.name)}${force ? "&force=1" : ""}`,
            {method: "POST", headers: {"Content-Type": f.type || "application/octet-stream"}, body: f});
          const j = await r.json().catch(() => ({}));
          if (r.status === 409) return ask(f, j.latest);
          if (!r.ok) throw srvErr(j.error);
          toast(tl("bc.upDone", {v: vShort(j.v)})); again();
        } catch (e) { toast(e.message); }
        finally { b.disabled = false; label.textContent = tl("bc.up"); }
      };
      const ask = (f, v) => {
        det.querySelector(".bd-ask")?.remove();
        b.parentElement.insertAdjacentHTML("beforebegin", `<div class="bd-ask" role="alert"><p>${esc(tl("bc.upNewer", {v: vShort(v)}))}</p>`
          + `<div class="bd-acts"><button class="btn fill press" data-y>${esc(tl("bc.upAdd"))}</button><button class="btn weak press" data-n>${esc(tl("upd.cancel"))}</button></div></div>`);
        const box = det.querySelector(".bd-ask");
        box.querySelector("[data-y]").onclick = () => { box.remove(); send(f, true); };
        box.querySelector("[data-n]").onclick = () => box.remove();
      };
      b.onclick = () => pick.click();
      pick.onchange = () => { const f = pick.files[0]; pick.value = ""; if (f) send(f, false); };
    }]);
    // 이 각도로 코멘트 (newest card, a model on show): the comment typed below goes with a picture
    // of the model as it is turned now and the camera that shows it, so the session can see the same.
    const shotBtn = () => { const b = det.querySelector("[data-bcshot]"); if (b) b.hidden = !model; };
    if (n.last) acts.push([`<button class="btn weak press" data-bcshot hidden>${ic("cube")}<span>${esc(tl("bc.3dShot"))}</span></button>`, (b) => b.onclick = async () => {
      const ta = det.querySelector("textarea"), text = ta.value.trim();
      if (!text) { ta.focus(); return toast(tl("bc.3dSay")); }
      b.disabled = true;
      const q = (k) => encodeURIComponent(k), it = {p: n.it.project, i: n.it.id, v: n.v.v, dept: n.it.sum.dept};
      try {
        const s = await (await model).shot();
        const r = await fetch(`/api/attach?p=${q(it.p)}&i=${q(it.i)}`, {method: "POST", headers: {"Content-Type": "image/png"}, body: s.blob}), j = await r.json().catch(() => ({}));
        if (!r.ok) throw srvErr(j.error);
        await post("/api/comment", {...it, text: `${text}\n${tl("bc.3dCam", {pos: s.pos, at: s.at})}\n📎 ${j.path}`});
        ta.value = ""; ta.dispatchEvent(new Event("input"));
        await sendNow(it); again();
      } catch (e) { b.disabled = false; toast(e.message); }
    }]);
    if (!acts.length) return;
    go.insertAdjacentHTML("beforebegin", `<div class="bd-acts">${acts.map(([h]) => h).join("")}</div>`);
    const row = go.previousElementSibling;
    acts.forEach(([, wire], i) => wire(row.querySelectorAll(":scope > button")[i]));
    coverBtn(); turn();
  }

  window.BoardCards = {...api, card, next, chip, step, railThumb, railNext, sig, detail, zoom};
})();
