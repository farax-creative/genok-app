// The board's additions behind the beta switch "board" (설정 → 베타, docs/beta-flags.md): picking
// several cards and acting on them at once, frames that group the rows, the lines between items,
// and what happens when cards are let go over something. web/boardview.js draws the board and asks
// window.BoardSelect(ctx) for these parts each time it builds one; with the switch off it gets null
// and the board is exactly as before.
//
// Tools (top right): the hand pans and the arrow draws a box that picks every card it touches
// (shift draws one with either; the wheel button always pans); H and V switch between them.
// Picked cards move together and have a bar at the foot of the board: 비교, 코멘트, 받기, 승인.
// Cards let go over another card, a frame or one of the board's own cards are offered to it
// (BoardView.admit): it takes them, or the reason it does not shows at the top and it shakes once.
// Nothing let go anywhere deletes anything; the cards go back to where they were picked up.
(function () {
  "use strict";
  const phi = (n) => window.LOOP_ICONS.html("regular/" + n);
  const calm = () => matchMedia("(prefers-reduced-motion:reduce)").matches;
  const pref = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch { return null; } };
  const vid = (r) => `${r.p}/${r.i}/${r.v}`;
  const refOf = (n) => ({p: n.it.project, i: n.it.id, v: n.v.v});
  const within = (w, o) => w.x >= o.x && w.y >= o.y && w.x <= o.x + o.w && w.y <= o.y + o.h;
  const undo = (t, fn) => toastAct(t, tl("board.undo"), fn, 30000);
  const kindIcon = (k) => (KIND[k] || ["doc"])[0];
  const kindName = (k) => ({ref: tl("board.k.ref"), derived: tl("board.k.derived"), variation: tl("board.k.variation")})[k];

  // Per board type: kind (the list in groups.json), size(card) -> {w, h}, paint(n, d, X), tap(n).
  // The sections below fill it; a frame is the only one that is not stored.
  const CARD = {};
  const DECOR = [];         // (n, d, X): more on a result card
  const DETAIL = [];        // (n, X) -> [html, bind(det)]: more in a result card's panel
  const DROP = {};          // target type -> (target, cards, X)
  const MENU = [];          // the + menu's rows: (X) -> {icon, name, line, off, soon, run}
  const TOOLS = [];         // (X) -> html: buttons in the board's tool row, before its own
  const MOUNT = [];         // (X): more once a board is on screen
  const btn = (attr, icon, name, on) => `<button class="press${on ? " on" : ""}" ${attr} aria-pressed="${!!on}" aria-label="${name}" title="${name}">${phi(icon)}</button>`;
  let tool = pref("v2-bdtool") === "select" ? "select" : "hand";

  function make({key, items, m, again, redo}) {
    const X = {key, items, m, again, redo, ui: null};
    const framesOn = () => pref("v2-bdframe") !== "0";
    m.pick = m.pick || new Set();
    X.pkey = framesOn() ? key + "#f" : key;

    // ---- the server's half: groups.json through /api/boardgroups
    X.act = async (body, quiet) => {
      const r = await post("/api/boardgroups", {k: key, ...body}).catch((e) => { toast(e.message); return null; });
      if (!r) return null;
      m.board = r.board;
      if (!quiet) redo();
      return r;
    };
    X.say = (text) => {
      const el = X.ui.why; el.textContent = text; el.classList.add("on");
      clearTimeout(el.t); el.t = setTimeout(() => el.classList.remove("on"), 2400);
    };
    X.node = (r) => X.ui.nodes.find((n) => n.type === "ver" && n.id === vid(r));
    X.itemOf = (r) => items.find((it) => it.project === r.p && it.id === r.i);
    X.links = () => [...(m.links || []), ...((m.board && m.board.links) || [])];
    // Send a line to the session of the version it is about, as a comment there.
    X.tell = async (r, text) => {
      const it = X.itemOf(r), to = {p: r.p, i: r.i, v: r.v, dept: it && it.sum.dept};
      await post("/api/comment", {p: r.p, i: r.i, v: r.v, text});
      await sendNow(to);
    };
    // A short panel in the card detail's place (several cards' comment, a picker).
    X.panel = (html) => {
      const det = X.ui.det;
      det.classList.remove("wide");
      det.innerHTML = `<button class="ib press x" aria-label="${tl("ui.close")}">${ic("x")}</button>${html}`;
      det.classList.add("on"); det.inert = false; X.ui.vp.classList.add("sel");
      det.querySelector(".x").onclick = () => X.ui.hide();
      return det;
    };
    // Where a new card goes: the middle of what is in view, or the nearest place around it that no
    // card covers, always whole in view (clear of the tools, the open panel and the picking bar).
    X.center = (w, h) => {
      const {vp, cam, nodes, det} = X.ui, k = cam.k, phone = vp.clientWidth < 600, open = vp.classList.contains("sel");
      const bar = vp.querySelector(".bd-bar");
      const R = open && !phone ? det.offsetLeft : vp.clientWidth, B = Math.min(open && phone ? det.offsetTop : vp.clientHeight, bar && !open ? bar.offsetTop : Infinity);
      const x0 = (12 - cam.x) / k, y0 = (56 - cam.y) / k, x1 = Math.max(x0, (R - 12 - cam.x) / k - w), y1 = Math.max(y0, (B - 12 - cam.y) / k - h);
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      const busy = nodes.filter((n) => n.type !== "frame"), gap = 24;
      const free = (x, y) => !busy.some((o) => x < o.x + o.w + gap && x + w + gap > o.x && y < o.y + o.h + gap && y + h + gap > o.y);
      for (let r = 0; r <= 16; r++)
        for (let i = 0; i < Math.max(1, 8 * r); i++) {
          const a = (i / Math.max(1, 8 * r)) * 2 * Math.PI, x = cx + Math.cos(a) * r * 32, y = cy + Math.sin(a) * r * 32;
          if (x >= x0 && x <= x1 && y >= y0 && y <= y1 && free(x, y)) return {x: Math.round(x), y: Math.round(y)};
        }
      return {x: Math.round(cx), y: Math.round(cy)};
    };

    // ---- frames: by project on the board of every project, by where each stands on a project's
    const rank = new Map();
    items.forEach((it) => { if (!rank.has(it.project)) rank.set(it.project, rank.size); });
    const FR = () => [tl("board.f.mine"), tl("board.f.open"), tl("board.f.ok"), tl("board.f.rest")];
    const STAND = ["mine", "open", "ok", "rest"];
    const groupOf = key === "*" ? (it) => ({key: it.project, title: pname(it.project), rank: rank.get(it.project)})
      : (it) => { const s = it.sum, k = stMine(s) ? 0 : it.open.length ? 1 : stK(s) === "approved" ? 2 : 3; return {key: STAND[k], title: FR()[k], rank: k}; };
    const extra = () => Object.entries(CARD).filter(([, c]) => c.kind).flatMap(([type, c]) =>
      (c.list ? c.list(X) : ((m.board || {})[c.kind] || [])).map((o) => ({id: type + "/" + o.id, type, card: o, x: o.x, y: o.y, ...c.size(o)})));
    X.opts = (ratio) => ({group: framesOn() ? groupOf : null, ratio, extra: extra()});

    X.framesOn = framesOn;
    X.tools = TOOLS.map((f) => f(X)).join("");

    // ---- painting
    X.paint = (n, d) => {
      if (n.type === "ver") {
        d.classList.toggle("picked", m.pick.has(n.id));
        DECOR.forEach((f) => f(n, d, X));
        return;
      }
      d.className = "bd-node " + n.type;
      CARD[n.type].paint(n, d, X);
    };
    X.detail = (n, det) => {
      if (n.type !== "ver") return;
      const parts = DETAIL.map((f) => f(n, X)).filter(Boolean);
      det.querySelector(".go").insertAdjacentHTML("beforebegin", parts.map((p) => p[0]).join(""));
      parts.forEach((p) => p[1] && p[1](det));
    };
    // The lines between items (what a version was made from, and the ones drawn here), from the
    // notes to the cards they were linked to, and from a card to what was asked to be made from it.
    X.wires = (nodes) => {
      const by = new Map(nodes.map((n) => [n.id, n]));
      const edge = (a, b, cls) => (a && b ? `<path class="${cls}" d="${BoardView.wire(a, b)}"/>` : "");
      return `<defs><marker id="bd-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,1L10,5L0,9z"/></marker></defs>`
        + X.links().map((l) => edge(by.get(vid(l.a)), by.get(vid(l.b)), "k-" + l.kind)).join("")
        + nodes.flatMap((n) => (CARD[n.type] && CARD[n.type].wires ? CARD[n.type].wires(n, by, edge) : [])).join("");
    };

    // ---- picking
    const vers = () => X.ui.nodes.filter((n) => n.type === "ver");
    const picked = () => vers().filter((n) => m.pick.has(n.id));
    X.setPick = (ids) => {
      m.pick = new Set(ids);
      vers().forEach((n) => n.el.classList.toggle("picked", m.pick.has(n.id)));
      bar();
    };
    // The bar at the foot of the board while cards are picked. It is part of the board, so it stays
    // clear of the card panel: left of it on a PC, and on a phone it waits behind the open panel.
    function bar() {
      const xs = picked(), vp = X.ui.vp;
      let el = vp.querySelector(".bd-bar");
      if (!xs.length) { if (el) el.remove(); m.barOn = false; return; }
      if (!el) {
        vp.insertAdjacentHTML("beforeend", `<div class="bd-x bd-bar${m.barOn ? "" : " in"}" role="toolbar"></div>`);
        el = vp.lastElementChild;
      }
      m.barOn = true;
      // An approval is of an item's newest version: only items whose newest version is picked count.
      const ok = [...new Map(xs.filter((n) => n.last).map((n) => [iid(n.it.sum), n.it.sum])).values()];
      const acts = [[tl("board.cmp"), () => compare(xs), xs.length !== 2], [tl("board.many"), () => many(xs)], [tl("board.get"), () => fetchAll(xs)]];
      el.setAttribute("aria-label", tl("board.picked", {n: xs.length}));
      el.innerHTML = `<span class="bd-bk">${tl("board.picked", {n: xs.length})}</span>`
        + acts.map(([t, , off], i) => `<button class="btn press" data-ba="${i}"${off ? " disabled" : ""}>${esc(t)}</button>`).join("")
        + `<button class="btn fill press" data-bok${ok.length ? "" : ` disabled title="${tl("board.ok.none")}"`}>${ok.length ? tl("libDraw.20", {size: ok.length}) : tl("board.ok")}</button>`
        + `<button class="press bd-bx" aria-label="${tl("libDraw.22")}" title="${tl("libDraw.22")}">${ic("x")}</button>`;
      el.querySelectorAll("[data-ba]").forEach((b) => b.onclick = acts[+b.dataset.ba][1]);
      el.querySelector("[data-bok]").onclick = () => { X.setPick([]); approveMany(ok); };
      el.querySelector(".bd-bx").onclick = () => X.setPick([]);
    }
    // Two versions side by side: of one item as its own versions, of two items each as itself.
    function compare([a, b]) {
      const one = a.it === b.it, row = (n, v) => ({v: one ? v.v : `${n.it.title} ${vShort(v.v)}`, at: v.at, summary: v.summary, files: v.files});
      if (one) {
        const [o, n] = a.it.versions.indexOf(a.v) < a.it.versions.indexOf(b.v) ? [a, b] : [b, a];
        return openCompareView({title: a.it.title, versions: a.it.versions.slice().reverse().map((v) => row(a, v)), a: o.v.v, b: n.v.v});
      }
      openCompareView({title: `${a.it.title} · ${b.it.title}`, versions: [row(b, b.v), row(a, a.v)], a: row(a, a.v).v, b: row(b, b.v).v});
    }
    // One comment, left on each picked version and sent to its session.
    function many(xs) {
      const det = X.panel(`<h3>${tl("board.many.t", {n: xs.length})}</h3><p class="s">${esc(xs.map((n) => `${n.it.title} ${vShort(n.v.v)}`).join(" · "))}</p>
        <textarea placeholder="${tl("board.ph")}" aria-label="${tl("board.ph")}"></textarea><button class="btn fill press send">${tl("board.send")}</button>`);
      const ta = det.querySelector("textarea"), send = det.querySelector(".send");
      ta.focus({preventScroll: true});
      send.onclick = async () => {
        const text = ta.value.trim(); if (!text) return ta.focus();
        send.disabled = true;
        try { for (const n of xs) await X.tell(refOf(n), text); X.ui.hide(); X.setPick([]); again(); }
        catch (e) { send.disabled = false; toast(e.message); }
      };
    }
    // 받기: every file of every picked version, saved as the browser saves a download.
    function fetchAll(xs) {
      const files = xs.flatMap((n) => (n.v.removed ? [] : n.v.files || []).filter((f) => f.url));
      if (!files.length) return toast(tl("board.nofile"));
      files.forEach((f) => { const a = document.createElement("a"); a.href = f.url; a.download = f.name || ""; document.body.appendChild(a); a.click(); a.remove(); });
    }
    X.tool = () => tool;
    X.tap = (n, add) => {
      if (n.type !== "ver") { if (CARD[n.type].tap) CARD[n.type].tap(n, X); return false; }
      if (add) { const s = new Set(m.pick); if (s.has(n.id)) s.delete(n.id); else s.add(n.id); X.setPick(s); return false; }
      X.setPick(tool === "select" ? [n.id] : []);
      return true;
    };
    X.clear = () => { if (m.pick.size) X.setPick([]); };
    // The box picks every card it touches, added to what was picked before when shift held.
    let base = null;
    X.box = (r) => {
      const ui = X.ui;
      if (!r) { if (ui.mq) ui.mq.remove(); ui.mq = null; base = null; return; }
      if (!ui.mq) { ui.mq = document.createElement("i"); ui.mq.className = "bd-marquee"; ui.world.appendChild(ui.mq); base = r.add ? [...m.pick] : []; }
      const x = Math.min(r.a.x, r.b.x), y = Math.min(r.a.y, r.b.y), w = Math.abs(r.a.x - r.b.x), h = Math.abs(r.a.y - r.b.y);
      ui.mq.style.cssText = `left:${x}px;top:${y}px;width:${w}px;height:${h}px;border-width:${1.5 / ui.cam.k}px`;
      X.setPick([...base, ...vers().filter((n) => n.x < x + w && n.x + n.w > x && n.y < y + h && n.y + n.h > y).map((n) => n.id)]);
    };
    X.carry = (n) => (n.type === "ver" && m.pick.has(n.id) && m.pick.size > 1 ? picked() : [n]);

    // ---- letting go over something
    // What a target already holds, for admit: a card's linked cards, a note's, a 묶음 slot's picks.
    const holds = (t, w) => {
      if (t.type === "ver") return X.links().flatMap((l) => (vid(l.a) === t.id ? [vid(l.b)] : vid(l.b) === t.id ? [vid(l.a)] : []));
      return CARD[t.type] && CARD[t.type].holds ? CARD[t.type].holds(t, w) : [];
    };
    X.over = (w, set) => {
      const ui = X.ui;
      if (ui.drop) [ui.drop.el, ...ui.drop.el.querySelectorAll(".drop")].forEach((e) => e.classList.remove("drop"));
      ui.drop = null;
      if (!w) return null;
      const own = set[0].frame, mixed = set.some((c) => c.type !== "ver");
      const t = ui.nodes.slice().reverse().find((o) => !set.includes(o) && o.type !== "next" && within(w, o) && !(o.type === "frame" && (o === own || mixed)));
      if (!t) return null;
      t.holds = holds(t, w);
      t.el.classList.add("drop");
      return (ui.drop = t);
    };
    X.drop = (t, set) => DROP[t.type](t, set, X);
    const WHY = () => ({frame: tl("board.no.frame"), kind: tl("board.no.kind"), same: tl("board.no.same"), dup: tl("board.no.dup"), linked: tl("board.no.linked")});
    X.refuse = (t, reason) => {
      X.say(WHY()[reason]);
      t.el.classList.remove("no");
      if (calm()) return;
      void t.el.offsetWidth; t.el.classList.add("no");
      setTimeout(() => t.el.classList.remove("no"), 200);
    };
    X.moved = (o) => { const c = CARD[o.type]; return c.move ? c.move(o, X) : X.act({op: "move", kind: c.kind, id: o.card.id, x: Math.round(o.x), y: Math.round(o.y)}, true); };
    // A move can be taken back from its toast, or with Ctrl+Z while the board has the focus.
    X.undoMove = (n, fn) => {
      let done = false;
      const once = () => { if (done) return; done = true; m.moves = (m.moves || []).filter((f) => f !== once); fn(); };
      m.moves = [...(m.moves || []).slice(-19), once];
      undo(tl("board.moved", {n}), once);
    };
    X.esc = () => {
      const ui = X.ui;
      if (ui.esc.length) { ui.esc.pop()(); return true; }
      if (m.pick.size) { X.setPick([]); return true; }
      return false;
    };

    X.mount = (ui) => {
      X.ui = Object.assign(ui, {esc: [], drop: null, mq: null});
      // bdb: a box drawn over the board picks cards, never the words on the board and the panel.
      ui.vp.classList.add("bdb");
      ui.vp.classList.toggle("seltool", tool === "select");
      ui.vp.insertAdjacentHTML("beforeend", `<p class="bd-why" role="status"></p>`);
      ui.why = ui.vp.querySelector(".bd-why");
      const tb = ui.vp.querySelector("[data-bdtool]");
      const setTool = (t) => {
        tool = t; pref("v2-bdtool", t);
        const name = t === "select" ? tl("board.t.select") : tl("board.t.hand");
        tb.innerHTML = phi(t === "select" ? "cursor" : "hand"); tb.title = name; tb.setAttribute("aria-label", name);
        tb.classList.toggle("on", t === "select"); tb.setAttribute("aria-pressed", t === "select");
        ui.vp.classList.toggle("seltool", t === "select");
      };
      tb.onclick = () => setTool(tool === "select" ? "hand" : "select");
      ui.vp.querySelector("[data-bdframe]").onclick = () => { pref("v2-bdframe", framesOn() ? "0" : "1"); m.cam = null; redo(); };
      ui.vp.addEventListener("keydown", (e) => {
        if (e.target.closest("input,textarea")) return;
        const k = e.key.toLowerCase();
        if (k === "z" && (e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (m.moves || []).length) { e.preventDefault(); m.moves[m.moves.length - 1](); return; }
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (k === "v" || k === "h") { e.preventDefault(); setTool(k === "v" ? "select" : "hand"); }
      });
      MOUNT.forEach((f) => f(X));
      bar();
    };
    return X;
  }
  TOOLS.push(() => btn("data-bdtool", tool === "select" ? "cursor" : "hand", tool === "select" ? tl("board.t.select") : tl("board.t.hand"), tool === "select"));
  TOOLS.push((X) => btn("data-bdframe", "kanban", tl("board.t.frames"), X.framesOn()));

  // ---- a card let go on another card: a line between their items, of the kind picked here
  DROP.ver = (t, set, X) => {
    if (set[0].type !== "ver") return CARD[set[0].type].onto(set[0], t, X);
    const {vp, cam} = X.ui;
    const pop = document.createElement("div");
    pop.className = "bd-x bd-pop"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("board.k.ask"));
    pop.innerHTML = `<p>${tl("board.k.ask")}</p>${["ref", "derived", "variation"].map((k) => `<button class="press" data-k="${k}">${kindName(k)}</button>`).join("")}<button class="press weak" data-k="">${tl("libDraw.22")}</button>`;
    pop.style.left = Math.max(8, Math.min(vp.clientWidth - 248, cam.x + t.x * cam.k)) + "px";
    pop.style.top = Math.max(8, Math.min(vp.clientHeight - 64, cam.y + (t.y + t.h) * cam.k + 8)) + "px";
    vp.appendChild(pop);
    const close = () => { pop.remove(); X.ui.esc = X.ui.esc.filter((f) => f !== close); };
    X.ui.esc.push(close);
    pop.querySelector("button").focus({preventScroll: true});
    pop.querySelectorAll("[data-k]").forEach((b) => b.onclick = async () => {
      close();
      if (!b.dataset.k) return;
      const made = [];
      for (const c of set) { const r = await X.act({op: "link.add", a: refOf(c), b: refOf(t), kind: b.dataset.k}, true); if (r && r.made) made.push(r.made); }
      X.redo();
      if (made.length) undo(tl("board.k.done", {n: made.length}), async () => { for (const l of made) await X.act({op: "del", kind: "links", id: l.id}, true); X.redo(); });
    });
  };
  // The lines of the card in the panel: what it was made from and what was made from it.
  DETAIL.push((n, X) => {
    const rows = X.links().filter((l) => vid(l.a) === n.id || vid(l.b) === n.id);
    if (!rows.length) return null;
    const html = `<p class="k">${tl("board.links")}</p><ul class="bd-ll">${rows.map((l, i) => {
      const from = vid(l.b) === n.id, o = from ? l.a : l.b, it = X.itemOf(o);
      return `<li><button class="lnk press" data-ll="${i}">${from ? "←" : "→"} ${esc(it ? it.title : o.i)} ${vShort(o.v)} · ${kindName(l.kind)}</button>${l.id ? `<button class="ib press" data-lx="${i}" aria-label="${tl("board.k.del")}" title="${tl("board.k.del")}">${ic("x")}</button>` : ""}</li>`;
    }).join("")}</ul>`;
    return [html, (det) => {
      det.querySelectorAll("[data-ll]").forEach((b) => b.onclick = () => { const l = rows[+b.dataset.ll], o = X.node(vid(l.b) === n.id ? l.a : l.b); if (o) X.ui.show(o); });
      det.querySelectorAll("[data-lx]").forEach((b) => b.onclick = () => {
        // One more press confirms: the line goes, nothing else does.
        if (!b.classList.contains("sure")) { b.classList.add("sure"); b.innerHTML = `<span>${tl("board.k.sure")}</span>`; return; }
        const l = rows[+b.dataset.lx];
        X.act({op: "del", kind: "links", id: l.id}).then((r) => { if (r) undo(tl("board.k.gone"), () => X.act({op: "put", kind: "links", obj: l})); });
      });
    }];
  });

  // ---- inside the board's own cards: a name edited in place, a removal asked once
  const editIn = (el, value, max, save) => {
    const inp = document.createElement("input");
    inp.className = "bd-x bd-edit"; inp.value = value; inp.maxLength = max; inp.setAttribute("aria-label", el.getAttribute("aria-label") || value);
    el.replaceWith(inp); inp.focus({preventScroll: true}); inp.select();
    let done = false;
    const end = (ok) => { if (done) return; done = true; const v = inp.value.trim(); if (ok && v && v !== value) save(v); else inp.replaceWith(el); };
    inp.onkeydown = (e) => { if (e.key === "Enter") end(true); else if (e.key === "Escape") { e.preventDefault(); end(false); } };
    inp.onblur = () => end(true);
  };
  const confirmIn = (d, text, label, fn) => {
    d.querySelector(".bd-cf")?.remove();
    d.insertAdjacentHTML("beforeend", `<div class="bd-x bd-cf" role="alertdialog" aria-label="${esc(text)}"><p>${esc(text)}</p><div><button class="btn weak press" data-n>${tl("libDraw.22")}</button><button class="btn fill press" data-y>${esc(label)}</button></div></div>`);
    const cf = d.querySelector(".bd-cf");
    cf.querySelector("[data-y]").onclick = fn; cf.querySelector("[data-n]").onclick = () => cf.remove();
    cf.querySelector("[data-y]").focus({preventScroll: true});
  };
  // Off the board, with 되돌리기: the very card comes back (the fields the server works out left behind).
  const remove = (n, X) => {
    const kind = CARD[n.type].kind, {approval, row, done, ...obj} = n.card;
    X.act({op: "del", kind, id: n.card.id}).then((r) => { if (r) undo(tl("board.gone"), () => X.act({op: "put", kind, obj})); });
  };
  const offBoard = (n, d, X) => confirmIn(d, tl("board.out.q"), tl("board.out"), () => remove(n, X));

  // ---- the + menu: what can be put on the board
  TOOLS.push(() => `<button class="press" data-bdadd aria-haspopup="menu" aria-expanded="false" aria-label="${tl("board.add")}" title="${tl("board.add")}">${phi("plus")}</button>`);
  MOUNT.push((X) => {
    const vp = X.ui.vp, b = vp.querySelector("[data-bdadd]");
    const outside = (e) => { if (!e.target.closest(".bd-menu,[data-bdadd]")) close(); };
    function close() {
      vp.querySelector(".bd-menu")?.remove(); b.setAttribute("aria-expanded", "false");
      X.ui.esc = X.ui.esc.filter((f) => f !== close); document.removeEventListener("pointerdown", outside, true);
    }
    b.onclick = () => {
      if (vp.querySelector(".bd-menu")) return close();
      const rows = MENU.map((f) => f(X));
      vp.insertAdjacentHTML("beforeend", `<div class="bd-x bd-menu" role="menu" aria-label="${tl("board.add")}">${rows.map((r, i) => `<button class="press" role="menuitem" data-mi="${i}"${r.off ? " disabled" : ""}>${phi(r.icon)}<span><b>${esc(r.name)}${r.soon ? `<em>${tl("board.add.soon")}</em>` : ""}</b><small>${esc(r.line)}</small></span></button>`).join("")}</div>`);
      const menu = vp.querySelector(".bd-menu");
      b.setAttribute("aria-expanded", "true");
      menu.querySelectorAll("[data-mi]").forEach((mi) => mi.onclick = () => { close(); rows[+mi.dataset.mi].run(); });
      menu.querySelector("button:not([disabled])").focus({preventScroll: true});
      X.ui.esc.push(close);
      document.addEventListener("pointerdown", outside, true);
    };
  });

  // ---- a frame's head: its name, the directives still open in it and when anything in it last came in
  CARD.frame = {
    paint: (n, d) => {
      const bits = [n.n ? tl("board.open", {n: n.n}) : "", n.at ? ago(n.at) : ""].filter(Boolean).join(" · ");
      d.innerHTML = `<header><b>${esc(n.title)}</b><span>${esc(bits)}</span></header>`;
    },
  };

  // ---- 묶음: named slots, results put in each and one of them marked 사용; approved as a whole,
  // and dimmed once anything in it changes or a result it uses has a newer version.
  const GH = 48, SH = 64, GF = 52;
  const pickHtml = (X, r, i, j, use) => {
    const it = X.itemOf(r), v = it && it.versions.find((x) => x.v === r.v), name = `${it ? it.title : r.i} ${vShort(r.v)}`;
    return `<span class="bd-pk${use ? " use" : ""}"><button class="bd-x press" data-use="${i}/${j}" aria-pressed="${use}" aria-label="${esc(name)}" title="${esc(name)}">${v && v.thumb && !v.removed ? imgTag(v.thumb, {drag: false}) : ic(kindIcon(v && v.kind))}${use ? `<i>${tl("board.g.use")}</i>` : ""}</button>`
      + `<button class="bd-x bd-pkx press" data-pdel="${i}/${j}" aria-label="${tl("board.g.out")}" title="${tl("board.g.out")}">${ic("x")}</button></span>`;
  };
  CARD.group = {
    kind: "groups",
    size: (g) => ({w: 288, h: GH + Math.max(1, g.slots.length) * SH + GF}),
    // The slot under the pointer is the one cards go in.
    holds(t, w) {
      const s = t.card.slots;
      t.slot = Math.max(0, Math.min(s.length - 1, Math.floor((w.y - t.y - GH) / SH)));
      t.el.querySelectorAll("li[data-slot]").forEach((li) => li.classList.toggle("drop", +li.dataset.slot === t.slot));
      return s.length ? s[t.slot].picks.map(vid) : [];
    },
    paint(n, d, X) {
      const g = n.card, a = g.approval, used = g.slots.filter((s) => s.use);
      d.classList.toggle("faded", a === "changed");
      d.innerHTML = `<header><button class="bd-x bd-gt press" data-gt aria-label="${tl("board.g.name")}">${esc(g.title)}</button>${a === "ok" ? `<span class="bd-ok">${tl("board.g.ok")}</span>` : a === "changed" ? `<span class="bd-ok moved">${tl("board.g.moved")}</span>` : ""}`
        + `<button class="bd-x ib press bd-del" data-gx aria-label="${tl("board.out")}" title="${tl("board.out")}">${ic("x")}</button></header>`
        + `<ol>${g.slots.map((s, i) => `<li data-slot="${i}"><button class="bd-x bd-sn press" data-sn="${i}" aria-label="${tl("board.g.slotname")}">${esc(s.name)}</button><span class="bd-pks">${s.picks.map((r, j) => pickHtml(X, r, i, j, !!s.use && vid(s.use) === vid(r))).join("") || `<em>${tl("board.g.drop")}</em>`}</span></li>`).join("") || `<li><em>${tl("board.g.none")}</em></li>`}</ol>`
        + `<footer><button class="bd-x press" data-gs${g.slots.length >= 12 ? " disabled" : ""}>${ic("plus")}${tl("board.g.slot")}</button><button class="bd-x btn fill press" data-gok${a === "ok" || !used.length ? " disabled" : ""}>${a === "ok" ? tl("board.g.done") : a === "changed" ? tl("board.g.again") : tl("board.g.approve")}</button></footer>`;
      const at = (b) => b.split("/").map(Number);
      d.querySelector("[data-gt]").onclick = (e) => editIn(e.currentTarget, g.title, 60, (title) => X.act({op: "group.set", id: g.id, title}));
      d.querySelectorAll("[data-sn]").forEach((b) => b.onclick = () => editIn(b, g.slots[+b.dataset.sn].name, 40, (name) => X.act({op: "slot.set", id: g.id, slot: +b.dataset.sn, name})));
      d.querySelectorAll("[data-use]").forEach((b) => b.onclick = () => { const [i, j] = at(b.dataset.use); X.act({op: "pick.use", id: g.id, slot: i, pick: g.slots[i].picks[j]}); });
      d.querySelectorAll("[data-pdel]").forEach((b) => b.onclick = async () => {
        const [i, j] = at(b.dataset.pdel), pick = g.slots[i].picks[j];
        if (await X.act({op: "pick.del", id: g.id, slot: i, pick})) undo(tl("board.g.outd"), () => X.act({op: "pick.add", id: g.id, slot: i, picks: [pick]}));
      });
      d.querySelector("[data-gs]").onclick = () => X.act({op: "slot.add", id: g.id, name: tl("board.g.slotN", {n: g.slots.length + 1})});
      d.querySelector("[data-gx]").onclick = () => offBoard(n, d, X);
      d.querySelector("[data-gok]").onclick = async () => {
        if (!await X.act({op: "group.approve", id: g.id}, true)) return;
        // Each session whose result is used hears which one went where.
        const list = used.map((s) => `${s.name} = ${s.use.i} ${vShort(s.use.v)}`).join(" · ");
        try { for (const u of new Map(used.map((s) => [vid(s.use), s.use])).values()) await X.tell(u, tl("board.g.told", {t: g.title, list})); }
        catch (e) { toast(e.message); }
        X.redo();
      };
    },
  };
  DROP.group = async (t, set, X) => {
    const g = t.card, slot = t.slot;
    if (!g.slots.length) return X.say(tl("board.g.none"));
    const fresh = set.filter((c) => !t.holds.includes(c.id)).map(refOf);
    if (await X.act({op: "pick.add", id: g.id, slot, picks: fresh})) undo(tl("board.g.in", {n: fresh.length, s: g.slots[slot].name}), async () => {
      for (const pick of fresh) await X.act({op: "pick.del", id: g.id, slot, pick}, true);
      X.redo();
    });
  };
  MENU.push((X) => ({icon: "stack", name: tl("board.add.group"), line: tl("board.add.groupD"), run: () => {
    const {x, y} = X.center(288, GH + 2 * SH + GF);
    X.act({op: "group.add", title: tl("board.g.new"), slots: [tl("board.g.slotN", {n: 1}), tl("board.g.slotN", {n: 2})], x, y});
  }}));

  // A card just put on the board opens as if tapped (its words written in place).
  MOUNT.push((X) => {
    const id = X.m.open; X.m.open = null;
    const n = id && X.ui.nodes.find((o) => o.id === id);
    if (n) CARD[n.type].tap(n, X);
  });
  const putNew = async (type, body, X) => {
    const r = await X.act(body, true);
    if (!r) return;
    X.m.open = type + "/" + r.made.id;
    X.redo();
  };

  // ---- 메모: words of the user's own on the board; linked to a card, they go to its session as 참고 메모
  CARD.note = {
    kind: "notes",
    size: () => ({w: 216, h: 136}),
    holds: (t) => t.card.links.map(vid),
    paint(n, d, X) {
      const o = n.card;
      n.holds = o.links.map(vid);
      d.innerHTML = `<p class="bd-nt">${o.text ? esc(o.text) : `<em>${tl("board.note.ph")}</em>`}</p>`
        + `<footer><span>${o.links.length ? tl("board.note.n", {n: o.links.length}) : tl("board.note.drag")}</span><button class="bd-x ib press bd-del" data-nx aria-label="${tl("board.out")}" title="${tl("board.out")}">${ic("x")}</button></footer>`;
      d.querySelector("[data-nx]").onclick = () => offBoard(n, d, X);
    },
    tap(n, X) {
      const p = n.el.querySelector(".bd-nt"), ta = document.createElement("textarea");
      ta.className = "bd-x bd-nt"; ta.value = n.card.text; ta.maxLength = 2000; ta.placeholder = tl("board.note.ph"); ta.setAttribute("aria-label", tl("board.note.ph"));
      p.replaceWith(ta); ta.focus({preventScroll: true});
      let done = false;
      const end = (ok) => {
        if (done) return; done = true;
        const text = ta.value.trim();
        if (ok && text !== n.card.text) X.act({op: "note.set", id: n.card.id, text}); else ta.replaceWith(p);
      };
      ta.onkeydown = (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) end(true); else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); end(false); } };
      ta.onblur = () => end(true);
    },
    // Linked to a card: the note goes to that version's session, once per card.
    async onto(note, t, X) { await linkNote(note, [t], X); },
    wires: (n, by, edge) => n.card.links.map((r) => edge(n, by.get(vid(r)), "k-note")),
  };
  async function linkNote(note, cards, X) {
    const o = note.card;
    if (!o.text) return X.say(tl("board.note.empty"));
    const fresh = cards.filter((c) => !o.links.some((r) => vid(r) === c.id));
    try {
      for (const c of fresh) {
        if (!await X.act({op: "note.link", id: o.id, to: refOf(c)}, true)) return;
        await X.tell(refOf(c), tl("board.note.told", {text: o.text}));
      }
      toast(tl("board.note.sent", {n: fresh.length}));
    } catch (e) { toast(e.message); }
    X.redo();
  }
  DROP.note = (t, set, X) => linkNote(t, set, X);
  MENU.unshift((X) => ({icon: "note", name: tl("board.add.note"), line: tl("board.add.noteD"), run: () => putNew("note", {op: "note.add", text: "", ...X.center(216, 136)}, X)}));

  // ---- 업로드: a file from this computer becomes an item of the board's project, as loop push would make it
  MENU.push((X) => ({icon: "upload-simple", name: tl("board.add.up"), line: X.key === "*" ? tl("board.add.upAll") : tl("board.add.upD"), off: X.key === "*", run: () => {
    const inp = document.createElement("input");
    inp.type = "file"; inp.multiple = true;
    inp.onchange = async () => {
      for (const f of inp.files) {
        const r = await fetch(`/api/board/upload?p=${encodeURIComponent(X.key)}&n=${encodeURIComponent(f.name)}`, {method: "POST", headers: {"Content-Type": "application/octet-stream"}, body: f}).catch(() => null);
        const j = r ? await r.json().catch(() => ({})) : {};
        if (!r || !r.ok) { toast(j.error || tl("board.up.fail", {name: f.name})); return; }
        toast(tl("board.up.done", {name: j.i, v: vShort(j.v)}));
      }
      load();
    };
    inp.click();
  }}));

  // ---- 바로 가기: an item of another project, one tap from here
  CARD.short = {
    kind: "shorts",
    size: () => ({w: 232, h: 72}),
    paint(n, d, X) {
      const x = n.card.row;
      d.setAttribute("role", "link"); d.tabIndex = 0;
      d.innerHTML = `<span class="bd-st">${x && x.thumb ? imgTag(x.thumb, {drag: false}) : ic(kindIcon(x && x.kind))}</span>`
        + `<span class="bd-meta"><b><span>${x ? esc(x.title) : esc(n.card.to.i)}</span></b><span>${x ? `${esc(pname(x.project))} · ${vShort(x.v)}` : tl("board.short.gone")}</span></span>`
        + `<button class="bd-x ib press bd-del" data-sx aria-label="${tl("board.out")}" title="${tl("board.out")}">${ic("x")}</button>`;
      d.querySelector("[data-sx]").onclick = () => offBoard(n, d, X);
      d.onkeydown = (e) => { if (e.key === "Enter" && e.target === d) CARD.short.tap(n); };
    },
    tap(n) { const x = n.card.row; if (x) nav("item/" + encodeURIComponent(x.project) + "/" + encodeURIComponent(x.id)); },
  };
  MENU.push((X) => ({icon: "arrow-square-out", name: tl("board.add.short"), line: tl("board.add.shortD"), run: () => {
    const here = new Set(X.items.map((it) => it.project + "/" + it.id)), had = new Set(((X.m.board || {}).shorts || []).map((s) => s.to.p + "/" + s.to.i));
    const all = (D.items || []).filter((x) => !here.has(x.project + "/" + x.id) && !had.has(x.project + "/" + x.id));
    const det = X.panel(`<h3>${tl("board.add.short")}</h3><input class="bd-find" type="search" placeholder="${tl("board.short.find")}" aria-label="${tl("board.short.find")}"><ul class="bd-ll bd-picks"></ul>`);
    const inp = det.querySelector("input"), ul = det.querySelector("ul");
    const fill = () => {
      const q = inp.value.trim().toLowerCase(), xs = all.filter((x) => !q || (x.title + " " + pname(x.project)).toLowerCase().includes(q)).slice(0, 40);
      ul.innerHTML = xs.map((x, i) => `<li><button class="lnk press" data-sh="${i}">${esc(x.title)} <small>${esc(pname(x.project))}</small></button></li>`).join("") || `<li class="s">${tl("board.short.none")}</li>`;
      ul.querySelectorAll("[data-sh]").forEach((b) => b.onclick = () => { const x = xs[+b.dataset.sh]; X.ui.hide(); X.act({op: "short.add", to: {p: x.project, i: x.id}, ...X.center(232, 72)}); });
    };
    inp.oninput = fill; fill(); inp.focus({preventScroll: true});
  }}));
  // Not yet: shown so the menu says where it is going, and pressed by nothing.
  MENU.push(() => ({icon: "link-simple", name: tl("board.add.web"), line: tl("board.add.webD"), off: true, soon: true}));
  MENU.push(() => ({icon: "list-checks", name: tl("board.add.list"), line: tl("board.add.listD"), off: true, soon: true}));

  // ---- 그리기: a pen over the whole board; what is drawn over result cards goes to each one's session
  // as a comment carrying the card with the marks on it (a PNG, as the item screen's drawing does).
  const inkD = (s) => "M" + s.p.map((q) => q.join(",")).join(" L");
  const inkPath = (s) => `<path stroke="${s.c}" d="${inkD(s)}"/>`;
  const touched = (X) => X.ui.nodes.filter((n) => n.type === "ver" && (X.m.ink || []).some((s) => s.p.some((q) => within({x: q[0], y: q[1]}, n))));
  // The card as it looks on the board (its picture, its name and version) with the marks over it.
  async function cardPng(n, strokes) {
    const S = 2, W = n.w * S, H = n.h * S, th = n.el.querySelector(".th"), tH = th ? th.offsetHeight * S : 0;
    const c = document.createElement("canvas"); c.width = W; c.height = H;
    const g = c.getContext("2d"), css = getComputedStyle(n.el);
    g.fillStyle = css.backgroundColor; g.fillRect(0, 0, W, H);
    const src = !n.v.removed && (n.v.kind === "image" && n.v.play || n.v.thumb);
    if (src && tH) {
      const im = new Image(); im.src = src;
      if (await im.decode().then(() => true, () => false)) {
        const k = Math.max(W / im.naturalWidth, tH / im.naturalHeight), w = im.naturalWidth * k, h = im.naturalHeight * k;
        g.save(); g.beginPath(); g.rect(0, 0, W, tH); g.clip(); g.drawImage(im, (W - w) / 2, (tH - h) / 2, w, h); g.restore();
      }
    }
    g.fillStyle = css.color; g.font = `600 ${13 * S}px ${css.fontFamily}`; g.textBaseline = "top";
    g.fillText(`${n.it.title} ${vShort(n.v.v)}`, 12 * S, tH + 8 * S, W - 24 * S);
    strokes.forEach((s) => LoopDraw.paintStroke(g, {t: "pen", c: s.c, p: s.p.map((q) => [(q[0] - n.x) / n.w, (q[1] - n.y) / n.h])}, {x: 0, y: 0, w: W, h: H}));
    return new Promise((ok) => c.toBlob(ok, "image/png"));
  }
  TOOLS.push((X) => btn("data-bdpen", "pencil-simple", tl("board.t.pen"), X.m.sketch));
  MOUNT.push((X) => {
    const {vp, world} = X.ui, m = X.m, pen = vp.querySelector("[data-bdpen]");
    m.ink = m.ink || []; m.inkC = m.inkC || INK[0];
    world.insertAdjacentHTML("beforeend", `<svg class="bd-ink" aria-hidden="true">${m.ink.map(inkPath).join("")}</svg>`);
    const svg = world.querySelector(".bd-ink");
    let pad = null, bar = null;
    const count = () => {
      const n = touched(X).length, send = bar.querySelector("[data-sks]");
      send.textContent = tl("board.sk.send", {n}); send.disabled = !n;
      bar.querySelector("[data-sku]").disabled = bar.querySelector("[data-skc]").disabled = !m.ink.length;
    };
    function close() {
      m.sketch = false; pad.remove(); bar.remove(); pad = bar = null;
      pen.classList.remove("on"); pen.setAttribute("aria-pressed", "false"); vp.classList.remove("inking");
      X.ui.esc = X.ui.esc.filter((f) => f !== close);
    }
    function open() {
      m.sketch = true;
      pen.classList.add("on"); pen.setAttribute("aria-pressed", "true"); vp.classList.add("inking");
      vp.insertAdjacentHTML("beforeend", `<div class="bd-x bd-pad"></div><div class="bd-x bd-sk" role="toolbar" aria-label="${tl("board.t.pen")}">`
        + INK.map((c, i) => `<button class="press bd-sw${c === m.inkC ? " on" : ""}" data-skc-c="${c}" style="--c:${c}" aria-label="${[tl("board.sk.red"), tl("board.sk.yellow"), tl("board.sk.blue")][i]}" aria-pressed="${c === m.inkC}"></button>`).join("")
        + `<button class="press" data-sku aria-label="${tl("board.sk.undo")}" title="${tl("board.sk.undo")}">${phi("arrow-counter-clockwise")}</button>`
        + `<button class="press" data-skc aria-label="${tl("board.sk.clear")}" title="${tl("board.sk.clear")}">${phi("eraser")}</button>`
        + `<input data-skm maxlength="500" placeholder="${tl("board.sk.ph")}" aria-label="${tl("board.sk.ph")}">`
        + `<button class="btn fill press" data-sks></button><button class="press" data-skx aria-label="${tl("ui.close")}" title="${tl("ui.close")}">${ic("x")}</button></div>`);
      pad = vp.querySelector(".bd-pad"); bar = vp.querySelector(".bd-sk");
      X.ui.esc.push(close);
      bar.querySelectorAll("[data-skc-c]").forEach((b) => b.onclick = () => {
        m.inkC = b.dataset.skcC;
        bar.querySelectorAll("[data-skc-c]").forEach((o) => { o.classList.toggle("on", o === b); o.setAttribute("aria-pressed", o === b); });
      });
      const repaint = () => { svg.innerHTML = m.ink.map(inkPath).join(""); count(); };
      bar.querySelector("[data-sku]").onclick = () => { m.ink.pop(); repaint(); };
      bar.querySelector("[data-skc]").onclick = () => { m.ink = []; repaint(); };
      bar.querySelector("[data-skx]").onclick = close;
      bar.querySelector("[data-sks]").onclick = async (e) => {
        const b = e.currentTarget, text = bar.querySelector("[data-skm]").value.trim() || tl("board.sk.told"), cards = touched(X);
        b.disabled = true;
        try {
          for (const n of cards) {
            const r = refOf(n), png = await cardPng(n, m.ink);
            const res = await fetch(`/api/attach?p=${encodeURIComponent(r.p)}&i=${encodeURIComponent(r.i)}`, {method: "POST", headers: {"Content-Type": "image/png"}, body: png});
            const j = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(j.error || tl("wireComments.7"));
            await X.tell(r, `${text}\n📎 ${j.path}`);
          }
        } catch (err) { b.disabled = false; return toast(err.message); }
        toast(tl("board.sk.sent", {n: cards.length}));
        m.ink = []; close(); X.again();
      };
      // One finger or the pen draws; the wheel still zooms, and the marks stay where they were drawn on the board.
      let cur = null, line = null;
      pad.onpointerdown = (e) => {
        if (e.button) return;
        pad.setPointerCapture(e.pointerId);
        const w = X.ui.atW(X.ui.local(e));
        cur = {c: m.inkC, p: [[Math.round(w.x), Math.round(w.y)]]};
        svg.insertAdjacentHTML("beforeend", inkPath(cur));
        line = svg.lastElementChild;
      };
      pad.onpointermove = (e) => {
        if (!cur) return;
        const w = X.ui.atW(X.ui.local(e)), [lx, ly] = cur.p[cur.p.length - 1];
        if (Math.hypot(w.x - lx, w.y - ly) < 2 / X.ui.cam.k) return;
        cur.p.push([Math.round(w.x), Math.round(w.y)]);
        line.setAttribute("d", inkD(cur));
      };
      pad.onpointerup = pad.onpointercancel = () => { if (!cur) return; m.ink.push(cur); cur = null; count(); };
      count();
    }
    pen.onclick = () => (m.sketch ? close() : open());
    if (m.sketch) open();
  });

  // ---- 이 카드로 만들기: the handle on a card's right edge, pulled out, leaves an ask card where it is
  // let go. What is written there goes to the card's session with the push line that records the new
  // version as made from this one (push --from), so the board draws it as an 이어 만듦 line.
  const fromArg = (r) => `${r.i}@${r.v}`;
  const pushLine = (item, from) => `loop push <${tl("board.ask.file")}> --item ${item} --from ${from}`;
  const freeName = (X, r) => { let k = 2; while (X.items.some((it) => it.project === r.p && it.id === `${r.i}-${k}`)) k++; return `${r.i}-${k}`; };
  DECOR.push((n, d, X) => {
    d.insertAdjacentHTML("beforeend", `<button class="bd-x bd-handle press" aria-label="${tl("board.ask.make")}" title="${tl("board.ask.make")}">${phi("plus")}</button>`);
    const h = d.lastElementChild;
    let pull = null;
    const at = (e) => X.ui.atW(X.ui.local(e));
    h.onpointerdown = (e) => {
      if (e.button) return;
      e.stopPropagation(); h.setPointerCapture(e.pointerId);
      X.ui.world.insertAdjacentHTML("beforeend", `<svg class="bd-tmp" aria-hidden="true"><path/></svg>`);
      pull = {s: at(e), line: X.ui.world.lastElementChild};
    };
    h.onpointermove = (e) => {
      if (!pull) return;
      const w = at(e), x1 = n.x + n.w, y1 = n.y + n.h / 2, c = Math.max(32, Math.abs(w.x - x1) / 2);
      pull.line.firstChild.setAttribute("d", `M${x1},${y1} C${x1 + c},${y1} ${w.x - c},${w.y} ${w.x},${w.y}`);
    };
    h.onpointerup = h.onpointercancel = (e) => {
      if (!pull) return;
      const w = at(e), far = Math.hypot(w.x - pull.s.x, w.y - pull.s.y) > 12 / X.ui.cam.k;
      pull.line.remove(); pull = null;
      if (e.type === "pointercancel") return;
      const src = refOf(n);
      X.m.draftAsk = {id: "draft", draft: true, src, item: freeName(X, src), text: "",
        x: Math.round(far ? w.x : n.x + n.w + 64), y: Math.round(far ? w.y - 24 : n.y)};
      X.m.open = "ask/draft";
      X.redo();
    };
    h.onclick = (e) => e.stopPropagation();
  });
  CARD.ask = {
    kind: "asks",
    list: (X) => [...((X.m.board || {}).asks || []), ...(X.m.draftAsk ? [X.m.draftAsk] : [])],
    size: (a) => (a.draft ? {w: 312, h: 268} : {w: 248, h: 120}),
    paint(n, d, X) {
      const a = n.card, it = X.itemOf(a.src), name = `${it ? it.title : a.src.i} ${vShort(a.src.v)}`;
      if (a.draft) {
        d.classList.add("draft");
        d.innerHTML = `<header><b>${tl("board.ask.make")}</b><span>${esc(name)}</span></header>`
          + `<textarea class="bd-x" data-at maxlength="2000" placeholder="${tl("board.ask.ph")}" aria-label="${tl("board.ask.ph")}">${esc(a.text)}</textarea>`
          + `<label class="bd-x">${tl("board.ask.item")}<input data-ai maxlength="80" value="${esc(a.item)}"></label>`
          + `<code class="bd-x"></code>`
          + `<footer><button class="bd-x btn weak press" data-an>${tl("libDraw.22")}</button><button class="bd-x btn fill press" data-ay>${tl("board.ask.go")}</button></footer>`;
        const ta = d.querySelector("[data-at]"), inp = d.querySelector("[data-ai]"), code = d.querySelector("code");
        const line = () => { code.textContent = pushLine(inp.value.trim() || "…", fromArg(a.src)); };
        ta.oninput = () => { a.text = ta.value; };
        inp.oninput = () => { a.item = inp.value; line(); };
        line();
        d.querySelector("[data-an]").onclick = () => { X.m.draftAsk = null; X.redo(); };
        d.querySelector("[data-ay]").onclick = async (e) => {
          const text = ta.value.trim(), item = inp.value.trim();
          if (!text) return ta.focus();
          e.currentTarget.disabled = true;
          const r = await X.act({op: "ask.add", src: a.src, item, text, x: Math.round(n.x), y: Math.round(n.y)}, true);
          if (!r) { e.currentTarget.disabled = false; return; }
          try { await X.tell(a.src, `${text}\n\n${tl("board.ask.how")}\n${pushLine(r.made.item, fromArg(a.src))}`); toast(tl("board.ask.sent")); }
          catch (err) { toast(err.message); }
          X.m.draftAsk = null; X.redo();
        };
        return;
      }
      d.innerHTML = `<header><b>${tl("board.ask.asked")}</b><span>${esc(name)}</span><button class="bd-x ib press bd-del" data-ax aria-label="${tl("board.out")}" title="${tl("board.out")}">${ic("x")}</button></header>`
        + `<p class="bd-at">${esc(a.text)}</p>`
        + `<p class="bd-as${a.done ? " in" : ""}">${a.done ? tl("board.ask.in", {item: a.item, v: vShort(a.done)}) : tl("board.ask.wait", {item: a.item})}</p>`;
      d.querySelector("[data-ax]").onclick = () => offBoard(n, d, X);
    },
    tap(n) {
      const a = n.card;
      if (a.draft) return n.el.querySelector("[data-at]").focus({preventScroll: true});
      if (a.done) nav("item/" + encodeURIComponent(a.src.p) + "/" + encodeURIComponent(a.item));
    },
    move(o, X) {
      if (o.card.draft) { Object.assign(X.m.draftAsk, {x: Math.round(o.x), y: Math.round(o.y)}); return; }
      return X.act({op: "move", kind: "asks", id: o.card.id, x: Math.round(o.x), y: Math.round(o.y)}, true);
    },
    wires: (n, by, edge) => [edge(by.get(vid(n.card.src)), n, "k-derived")],
  };
  // Escape lets an unsent ask go.
  MOUNT.push((X) => { if (X.m.draftAsk) X.ui.esc.push(() => { X.m.draftAsk = null; X.redo(); }); });

  // ---- what a version was made from has moved on: a still dot on the card, and in its panel the
  // line that says so with a way to ask for it again from the newest (pressed twice).
  DECOR.push((n, d) => {
    if (!n.last || !(n.v.stale || []).length) return;
    d.insertAdjacentHTML("beforeend", `<i class="bd-stale" title="${esc(n.v.stale.map((s) => tl("board.st.moved", {a: s.title, v: vShort(s.now)})).join(" · "))}"></i>`);
  });
  DETAIL.push((n, X) => {
    const st = n.last ? n.v.stale || [] : [];
    if (!st.length) return null;
    const html = st.map((s, i) => `<div class="bd-stl"><p>${tl("board.st.moved", {a: esc(s.title), v: vShort(s.now)})}</p><button class="btn weak press" data-st="${i}">${tl("board.st.redo", {a: esc(s.title)})}</button></div>`).join("");
    return [html, (det) => det.querySelectorAll("[data-st]").forEach((b) => {
      const s = st[+b.dataset.st], label = b.textContent;
      let t = 0;
      b.onclick = async () => {
        if (!b.classList.contains("sure")) {
          b.classList.add("sure"); b.textContent = tl("board.st.sure");
          t = setTimeout(() => { b.classList.remove("sure"); b.textContent = label; }, 4000);
          return;
        }
        clearTimeout(t); b.disabled = true;
        const from = (s.p === n.it.project ? "" : s.p + "/") + `${s.i}@${s.now}`;
        try { await X.tell(refOf(n), `${tl("board.st.told", {a: s.title, v: vShort(s.now)})}\n${pushLine(n.it.id, from)}`); toast(tl("board.ask.sent")); }
        catch (e) { toast(e.message); }
        b.classList.remove("sure"); b.textContent = label; b.disabled = false;
      };
    })];
  });

  window.BoardSelect = (ctx) => (window.BoardView && BoardView.beta() ? make(ctx) : null);
})();
