// The board's extras behind the beta switch "board" (ideas taken from PAI's canvas). They plug
// into web/boardview.js through BoardView.ext; with the switch off nothing here attaches and the
// board is exactly what boardview.js draws.
//
// 필터·정렬·찾기: kind and status chips, a sort and a search; what does not match is dimmed, not
// hidden, so the board keeps its shape. The pick is kept per device ("v2-bdfilter", like v2-bdmode).
//
// 접기: one card per item with its version chips; an older chip peeks at that version ("v3 보는 중 ·
// 최신 아님") with a way back and a compare against the newest. The detail panel carries the same
// chips. 시간순: every version on one time axis in project lanes (BoardView.layoutByTime).
//
// Pure parts are tested in tests/boardview.test.js.
(function () {
  "use strict";
  const KINDS = ["image", "video", "html", "doc"];
  const kindOf = (k) => KINDS.includes(k) ? k : "doc";
  const newest = (it) => it.versions[it.versions.length - 1];

  // f: {kinds, smart, q}; test(k, it) says whether status k holds for the item.
  function matches(it, f, test) {
    const last = newest(it);
    if (f.kinds.length && !f.kinds.includes(kindOf(last.kind))) return false;
    if (f.smart.length && !f.smart.some((k) => test(k, it))) return false;
    const q = f.q.trim().toLowerCase();
    return !q || [it.title, it.id, it.project, last.summary, ...(it.open || [])].join(" ").toLowerCase().includes(q);
  }
  const atOf = (it) => String(newest(it).at || "");
  const waitOf = (it) => String((it.sum && it.sum.handed_at) || atOf(it));
  // 최근 / 이름 / 버전 많은 순 / 오래 기다린 순.
  const SORTS = {
    new: (a, b) => atOf(b).localeCompare(atOf(a)),
    name: (a, b) => String(a.title).localeCompare(String(b.title)),
    versions: (a, b) => b.versions.length - a.versions.length,
    waited: (a, b) => waitOf(a).localeCompare(waitOf(b)),
  };
  const order = (items, how) => items.slice().sort(SORTS[how] || SORTS.new);

  // 접기: the items as a grid of single cards, each showing the version picked in `peek`
  // ({"project/id": v}) or its newest. A dragged card keeps its place whichever version it shows.
  const FOLD_H = 34;
  function layoutFold(items, saved, peek, cols, B) {
    const nodes = items.map((it, i) => {
      const key = `${it.project}/${it.id}`, last = newest(it), v = it.versions.find((x) => x.v === peek[key]) || last;
      const at = saved && Object.entries(saved).find(([k]) => k.startsWith(key + "/"));
      return {id: `${key}/${v.v}`, type: "ver", it, v, last: v === last, peek: v !== last, w: B.CW, h: B.CH + FOLD_H,
        x: at ? at[1][0] : (i % cols) * (B.CW + B.GY), y: at ? at[1][1] : Math.floor(i / cols) * (B.CH + FOLD_H + B.GY)};
    });
    return {nodes, links: []};
  }

  // The all-projects board's collage: one entry per project, newest activity first, with its newest
  // four pictures, how many items it has and how many wait for a check (wait(it) says).
  function projectsOf(items, wait) {
    const by = new Map();
    for (const it of items) { if (!by.has(it.project)) by.set(it.project, []); by.get(it.project).push(it); }
    return [...by].map(([project, its]) => {
      const news = its.slice().sort(SORTS.new);
      return {project, items: its.length, wait: its.filter(wait).length, at: atOf(news[0]),
        thumbs: news.map((it) => newest(it)).filter((v) => v.thumb && !v.removed).slice(0, 4).map((v) => v.thumb)};
    }).sort((a, b) => b.at.localeCompare(a.at));
  }

  // 고르기: the newest version's question whose options match its files one for one (option i is
  // file i). {q, files, pick}: pick is the picked option's number, -1 while it is still open.
  function choiceOf(it) {
    const files = (newest(it).files || []).filter((f) => !f.removed);
    const q = files.length > 1 && (it.asks || []).find((a) => (a.options || []).length === files.length);
    if (!q) return null;
    const pick = (it.picked || {})[q.n];
    return {q, files, pick: pick == null ? -1 : q.options.indexOf(pick)};
  }
  // 빈 칸 요청: one is filled once its project has an item that first came after it was sent
  // (`since`: the newest time on the board then, in the board's own clock).
  const filled = (r, items) => items.some((it) => it.project === r.p && String(it.versions[0].at || "") > r.since);
  // A reel row carried from one place to another: the new order as row numbers.
  const reordered = (n, from, to) => { const o = [...Array(n).keys()]; o.splice(to, 0, o.splice(from, 1)[0]); return o; };

  // 이어 보기 plays a reel's pictures and clips in its order, each row's files in turn.
  const isClip = (f) => f.kind === "video" || /\.(mp4|webm|mov|m4v)$/i.test(f.play || "");
  const clipsOf = (rows) => rows.flatMap((r) => r.files.filter((f) => f.play && (isClip(f) || f.kind === "image")).map((f) => ({r, f, clip: isClip(f)})));
  const pure = {matches, order, layoutFold, projectsOf, choiceOf, filled, reordered, clipsOf};
  if (typeof module !== "undefined" && module.exports) module.exports = pure;
  if (typeof window === "undefined" || !window.genokBeta?.("board") || !window.BoardView) return;

  const BV = window.BoardView;
  const ls = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || "null"); localStorage.setItem(k, JSON.stringify(v)); } catch { return null; } };
  const ikey = (it) => `${it.project}/${it.id}`;

  // ---- 필터·정렬·찾기
  const filt = Object.assign({kinds: [], smart: [], q: "", sort: "new"}, ls("v2-bdfilter"));
  const KIND_N = () => ({image: tl("bdx.k.image"), video: tl("bdx.k.video"), html: tl("bdx.k.html"), doc: tl("bdx.k.doc")});
  const STATUS_N = () => ({need_check: tl("views.smart.need_check"), has_question: tl("views.smart.has_question"), fixing: tl("views.smart.fixing"), unread: tl("views.smart.unread")});
  const SORT_N = () => [["new", tl("bdx.s.new")], ["name", tl("bdx.s.name")], ["versions", tl("bdx.s.versions")], ["waited", tl("bdx.s.waited")]];
  const status = (k, it) => !!it.sum && SMART[k]({...it.sum, flow: flowOf(it.sum)}, Date.now());
  const filtering = () => filt.kinds.length + filt.smart.length > 0 || !!filt.q.trim();
  let popOpen = false, typing = null, qTimer = 0;
  const peeks = {};          // per board: {"project/id": the older version shown in 접기}
  const peekOf = (key) => peeks[key] || (peeks[key] = {});

  function bar(ctx) {
    const rail = ctx.mode === "rail", at = rail ? ctx.host.querySelector(".bd-rh") : ctx.live && ctx.live.vp;
    if (!at) return;
    const n = filt.kinds.length + filt.smart.length, hits = ctx.items.filter((it) => matches(it, filt, status)).length, logN = logCount(ctx);
    const views = [["board", tl("board.board")], ["fold", tl("bdx.v.fold")], ["time", tl("bdx.v.time")]];
    const chip = (group, k, t) => { const on = filt[group].includes(k); return `<button class="press bd-ch${on ? " on" : ""}" aria-pressed="${on}" data-bdf="${group}" data-k="${k}">${esc(t)}</button>`; };
    const el = document.createElement("div");
    el.className = "bd-filter"; el.dataset.bdx = "";
    el.innerHTML = (rail ? "" : `<div class="seg bd-seg" role="group" aria-label="${tl("board.view")}">${views.map(([k, t]) => `<button class="press${k === ctx.mode ? " on" : ""}" aria-pressed="${k === ctx.mode}" data-bdview="${k}">${t}</button>`).join("")}</div>`)
      + `<label class="bd-q">${ic("search")}<input type="search" value="${esc(filt.q)}" placeholder="${tl("bdx.q")}" aria-label="${tl("bdx.q")}"></label>`
      + `<button class="press bd-fbtn${n ? " on" : ""}" aria-expanded="${popOpen}" data-bdfp>${tl("bdx.filter")}${n ? ` <b class="num">${n}</b>` : ""}</button>`
      + (filtering() ? `<span class="bd-hits num">${tl("bdx.hits", {n: hits})}</span>` : "")
      + `<button class="press bd-fbtn${logN ? " on" : ""}" aria-expanded="${side === "log"}" data-bdlog>${tl("bdx.log")}${logN ? ` <b class="num">${logN}</b>` : ""}</button>`
      + (ctx.live ? `<button class="press bd-fbtn" aria-expanded="${side === "tree"}" data-bdtree>${tl("bdx.tree")}</button>` : "");
    const pop = document.createElement("div");
    pop.className = "bd-fpop" + (popOpen ? " on" : ""); pop.dataset.bdx = ""; pop.inert = !popOpen;
    pop.innerHTML = `<p class="k">${tl("bdx.kind")}</p><div class="bd-chips">${KINDS.map((k) => chip("kinds", k, KIND_N()[k])).join("")}</div>
      <p class="k">${tl("bdx.state")}</p><div class="bd-chips">${Object.entries(STATUS_N()).map(([k, t]) => chip("smart", k, t)).join("")}</div>
      <p class="k">${tl("bdx.sort")}</p><div class="bd-chips">${SORT_N().map(([k, t]) => `<button class="press bd-ch${filt.sort === k ? " on" : ""}" aria-pressed="${filt.sort === k}" data-bdsort="${k}">${t}</button>`).join("")}</div>
      ${filtering() ? `<button class="lnk press" data-bdclear>${tl("bdx.clear")}</button>` : ""}`;
    const pane = (cls, on, html) => { const p = document.createElement("div"); p.className = `bd-fpop ${cls}` + (on ? " on" : ""); p.dataset.bdx = ""; p.inert = !on; p.innerHTML = html; return p; };
    const log = pane("bd-log", side === "log", logPane(ctx)), tree = ctx.live ? pane("bd-tree", side === "tree", treePane(ctx)) : null;
    if (!tree && side === "tree") side = "";
    pathPill(ctx, el);
    if (rail) { at.prepend(el); at.after(pop, log); }
    else { at.append(el, pop, log, tree); el.style.setProperty("--bd-tools", (at.querySelector(".bd-tools").offsetWidth + 24) + "px"); }
    const save = () => { ls("v2-bdfilter", filt); ctx.redraw(); };
    el.querySelectorAll("[data-bdview]").forEach((b) => b.onclick = () => { if (b.dataset.bdview === ctx.mode) return; BV.mode(b.dataset.bdview); ctx.m.cam = null; ctx.m.sel = null; slotAt = -1; ctx.redraw(); });
    el.querySelector("[data-bdfp]").onclick = () => { popOpen = !popOpen; setSide(""); };
    el.querySelector("[data-bdlog]").onclick = () => setSide(side === "log" ? "" : "log");
    el.querySelector("[data-bdtree]")?.addEventListener("click", () => setSide(side === "tree" ? "" : "tree"));
    log.querySelectorAll("[data-bdloc]").forEach((b) => b.onclick = () => { setSide(""); locate(ctx, b.dataset.bdloc, b.dataset.v); });
    if (tree) wireTree(ctx, tree);
    [log, tree].forEach((p) => p?.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); setSide(""); el.querySelector(p === log ? "[data-bdlog]" : "[data-bdtree]").focus(); } }));
    pop.querySelectorAll("[data-bdf]").forEach((b) => b.onclick = () => { const l = filt[b.dataset.bdf], k = b.dataset.k; l.includes(k) ? l.splice(l.indexOf(k), 1) : l.push(k); save(); });
    pop.querySelectorAll("[data-bdsort]").forEach((b) => b.onclick = () => { filt.sort = b.dataset.bdsort; save(); });
    pop.querySelector("[data-bdclear]")?.addEventListener("click", () => { filt.kinds = []; filt.smart = []; filt.q = ""; save(); });
    pop.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); popOpen = false; ctx.redraw(); } });
    // Each letter dims the board again a moment after typing stops; the field keeps the caret.
    const q = el.querySelector("input");
    q.oninput = () => { filt.q = q.value; clearTimeout(qTimer); qTimer = setTimeout(() => { typing = q.selectionStart; save(); }, 160); };
    if (typing !== null) { q.focus({preventScroll: true}); q.setSelectionRange(typing, typing); typing = null; }
  }
  // ---- 접기: the version chips on each card, and the peek band on one showing an older version
  const thumbIn = (v) => v.thumb && !v.removed ? imgTag(v.thumb, {drag: false}) : "";
  const asCompare = (it) => it.versions.slice().reverse().map((v) => ({v: v.v, at: v.at, summary: v.summary, files: v.files || []}));
  function compareLatest(it, v) {
    openCompareView({title: it.title, versions: asCompare(it), a: v, b: newest(it).v, post: {p: it.project, i: it.id}});
  }
  function setPeek(ctx, it, v) {
    const pk = peekOf(ctx.key), k = ikey(it);
    if (v === newest(it).v) delete pk[k]; else pk[k] = v;
    if (ctx.m.sel && ctx.m.sel.startsWith(k + "/")) ctx.m.sel = `${k}/${v}`;
    ctx.redraw();
  }
  const SHOWN = 4;            // with the +N, what fits across a card
  function foldChips(ctx) {
    ctx.live.nodes.forEach((n) => {
      const vs = n.it.versions, from = Math.max(0, vs.length - SHOWN);
      const row = document.createElement("div");
      row.className = "bd-vchips"; row.dataset.bdx = "";
      row.innerHTML = (from ? `<span class="bd-more num">+${from}</span>` : "")
        + vs.slice(from).map((v) => `<button class="press num${v === n.v ? " on" : ""}" aria-pressed="${v === n.v}" data-bdpv="${esc(v.v)}">${vShort(v.v)}</button>`).join("");
      n.el.append(row);
      row.querySelectorAll("[data-bdpv]").forEach((b) => b.onclick = () => setPeek(ctx, n.it, b.dataset.bdpv));
      row.querySelector(".bd-more")?.addEventListener("click", () => ctx.live.show(n));
      if (!n.peek) return;
      n.el.classList.add("peek");
      n.el.querySelector(".th").insertAdjacentHTML("beforeend", `<span class="bd-peek" data-bdx>${tl("bdx.peek", {v: vShort(n.v.v)})}</span>`);
    });
  }
  // The detail panel: the item's versions as the item screen's strip (picking one shows that card,
  // or peeks at it in 접기); an older version can be compared with the newest, and a peeked one
  // has the band with the way back.
  function detChips(det, n, live) {
    if (!cur || cur.live !== live) return;   // drawn again by after() once the board is complete
    const c = cur, it = n.it, latest = newest(it);
    const strip = it.versions.length < 2 ? "" : `<div class="vtl bd-vtl"><div class="vtlstrip" role="tablist" aria-label="${tl("bdx.versions")}">${it.versions.slice().reverse().map((v) =>
      `<button class="vtli press${v === n.v ? " on" : ""}" role="tab" aria-selected="${v === n.v}" data-bdpv="${esc(v.v)}"><span class="vth">${thumbIn(v)}</span><span class="vtm"><b>${vShort(v.v)}</b></span></button>`).join("")}</div></div>`;
    const cmp = `<button class="btn sm weak press" data-bdcmp>${tl("bdx.cmplatest")}</button>`;
    const band = n.peek ? `<div class="bd-peekbar"><p>${tl("bdx.peek.long", {v: vShort(n.v.v)})}</p><div><button class="btn sm weak press" data-bdlatest>${tl("bdx.tolatest")}</button>${cmp}</div></div>`
      : `<div class="bd-peekbar plain"><div>${n.v !== latest ? cmp : ""}${trayBtn(it, n.v)}${reelP(c) ? `<button class="btn sm weak press" data-bdreel>${tl("bdx.reel.add")}</button>` : ""}</div></div>`;
    const ch = n.v === latest && choiceOf(it);
    det.querySelector("h3").insertAdjacentHTML("afterend", strip + band + (ch && !(ch.pick < 0 && later.has(`${ikey(it)}/${n.v.v}`)) ? choiceBlock(ch) : ""));
    det.querySelectorAll("[data-bdpv]").forEach((b) => b.onclick = () => {
      if (c.mode === "fold") return setPeek(c, it, b.dataset.bdpv);
      const to = live.nodes.find((x) => x.id === `${ikey(it)}/${b.dataset.bdpv}`);
      if (to) live.show(to);
    });
    det.querySelector("[data-bdlatest]")?.addEventListener("click", () => setPeek(c, it, latest.v));
    det.querySelector("[data-bdcmp]")?.addEventListener("click", () => compareLatest(it, n.v.v));
    det.querySelector("[data-bdreel]")?.addEventListener("click", () => {
      const p = reelP(c);
      reelSet(c, p, post("/api/reel", {p, add: {i: it.id, v: n.v.v}})).then((r) => r && toast(tl("bdx.reel.added", {n: r.rows.length})));
    });
    det.querySelectorAll("[data-bdpick]").forEach((b) => b.onclick = () => { b.disabled = true; pickOne(c, it, ch, +b.dataset.bdpick); });
    det.querySelector("[data-bdlater]")?.addEventListener("click", () => { later.add(`${ikey(it)}/${n.v.v}`); c.redraw(); });
    const tb = det.querySelector("[data-bdtray]");
    if (tb) tb.onclick = () => { toTray(it, n.v); tb.textContent = trayWord(it, n.v); };
  }

  // ---- 여러 개 비교: versions of any items gathered in a dock (A, B, C...), opened together in compare
  const tray = [];            // [{p, i, v, title, at, summary, files}], for this visit
  const inTray = (it, v) => tray.findIndex((t) => t.p === it.project && t.i === it.id && t.v === v.v);
  const trayWord = (it, v) => inTray(it, v) < 0 ? tl("bdx.tray.add") : tl("bdx.tray.out");
  const trayBtn = (it, v) => `<button class="btn sm weak press" data-bdtray>${trayWord(it, v)}</button>`;
  function toTray(it, v) {
    const at = inTray(it, v);
    if (at >= 0) tray.splice(at, 1);
    else if (tray.length >= 6) return toast(tl("bdx.tray.full"));
    else tray.push({p: it.project, i: it.id, v: v.v, title: it.title, at: v.at, summary: v.summary, files: v.files || []});
    dock(cur);
  }
  function dock(ctx) {
    const vp = ctx && ctx.live && ctx.live.vp;
    if (!vp) return;
    vp.querySelector(".bd-dock")?.remove();
    if (!tray.length) return;
    const el = document.createElement("div");
    el.className = "bd-dock"; el.dataset.bdx = ""; el.setAttribute("role", "group"); el.setAttribute("aria-label", tl("bdx.tray.aria"));
    el.innerHTML = `<div class="bd-dkl">${tray.map((t, n) => `<span class="bd-dk"><b>${String.fromCharCode(65 + n)}</b>${esc(t.title)} ${vShort(t.v)}<button class="press" data-bdrm="${n}" aria-label="${tl("bdx.tray.rm")}">${ic("x")}</button></span>`).join("")}</div>`
      + `<button class="btn sm fill press" data-bdset${tray.length < 2 ? " disabled" : ""}>${tl("bdx.tray.open", {n: tray.length})}</button>`;
    vp.append(el);
    el.querySelectorAll("[data-bdrm]").forEach((b) => b.onclick = () => { tray.splice(+b.dataset.bdrm, 1); dock(ctx); });
    el.querySelector("[data-bdset]").onclick = () => openCompareView({title: tl("bdx.tray.title"), versions: [], set: tray.slice()});
  }

  // ---- 시간순: each project lane named over its newest card, since a newly framed view opens on
  // the newest end
  function lanes(ctx, fresh) {
    const {world, cam, vp, nodes} = ctx.live, grid = BV.layoutByTime(ctx.items, null);
    grid.lanes.forEach((l) => world.insertAdjacentHTML("beforeend",
      `<span class="bd-lanel" style="top:${l.y - 28}px;left:${Math.max(...grid.nodes.filter((n) => n.y === l.y).map((n) => n.x))}px">${esc(l.name === null ? tl("bdx.other") : pname(l.name))}</span>`));
    if (!fresh || !nodes.length) return;
    const right = Math.max(...nodes.map((n) => n.x + n.w)), b = BV.bounds(nodes), k = cam.k;
    cam.x = Math.min(cam.x, vp.clientWidth - 24 - right * k);
    // Below the filter bar with room for the lane names, centred in the height left under it.
    const fb = vp.querySelector(".bd-filter"), top = (fb ? fb.offsetTop + fb.offsetHeight : 48) + 16 + 28 * k;
    cam.y = top + Math.max(0, (vp.clientHeight - top - 24 - b.h * k) / 2) - b.y * k;
    ctx.live.apply();
  }

  // ---- 프로젝트 콜라주: the all-projects board ("*") opens on one card per project; a double press
  // (or Enter) goes in, and the path pill in the bar comes back out. "카드 전부 보기" is the old board.
  let level = "";             // "" = the collage, "*" = every card, else the project gone into
  const ALL = "*";
  const inCollage = (key) => key === ALL && level === "";
  function collage(host, items, repaint) {
    const ps = projectsOf(items, (it) => status("need_check", it));
    if (ps.length < 2) return false;
    const go = (to) => { level = to; repaint(); };
    host.style.height = "";
    host.innerHTML = `<div class="bd-col"><div class="bd-colh"><p>${tl("bdx.pj.n", {n: ps.length})} · ${tl("bdx.pj.hint")}</p><button class="btn sm weak press" data-bdall>${tl("bdx.pj.all")}</button></div>
      <div class="bd-colg">${ps.map((x) => `<button class="press bd-pj" data-bdpj="${esc(x.project)}" aria-label="${esc(tl("bdx.pj.enter", {p: pname(x.project)}))}">
        <span class="bd-cl n${Math.max(1, x.thumbs.length)}">${(x.thumbs.length ? x.thumbs : [""]).map((t) => `<span>${t ? imgTag(t, {drag: false}) : ic("grid")}</span>`).join("")}</span>
        <b>${esc(pname(x.project))}</b><span class="num">${tl("bdx.pj.items", {n: x.items})}${x.wait ? ` · <em>${tl("bdx.pj.wait", {n: x.wait})}</em>` : ""}</span></button>`).join("")}</div></div>`;
    host.querySelector("[data-bdall]").onclick = () => go(ALL);
    let last = null, at = 0;
    host.querySelectorAll("[data-bdpj]").forEach((b) => {
      b.onclick = (e) => {
        const now = e.timeStamp;
        if (last === b && now - at < 400) return go(b.dataset.bdpj);
        host.querySelectorAll(".bd-pj.on").forEach((o) => o.classList.remove("on"));
        b.classList.add("on"); last = b; at = now;
      };
      b.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); go(b.dataset.bdpj); } };
    });
    return true;
  }
  // The way back out, at the head of the bar while inside the all-projects board.
  function pathPill(ctx, bar) {
    if (ctx.key !== ALL || level === "") return;
    bar.insertAdjacentHTML("afterbegin", `<span class="bd-path"><button class="press" data-bdout aria-label="${tl("bdx.pj.root")}">${ic("back")}<span>${tl("bdx.pj.root")}</span></button><b>${esc(level === ALL ? tl("bdx.pj.allcards") : pname(level))}</b></span>`);
    bar.querySelector("[data-bdout]").onclick = () => { level = ""; ctx.m.cam = null; ctx.m.sel = null; ctx.redraw(); };
  }

  // ---- 기록 서랍 and 넘기기: two panes under the bar, one open at a time with the filter sheet
  let side = "";              // "", "log" or "tree"
  function setSide(v) {
    side = v; popOpen = popOpen && !v;
    document.querySelectorAll(".bd-fpop").forEach((p) => {
      const on = p.classList.contains("bd-log") ? v === "log" : p.classList.contains("bd-tree") ? v === "tree" : popOpen;
      p.classList.toggle("on", on); p.inert = !on;
    });
    document.querySelectorAll("[data-bdlog],[data-bdtree],[data-bdfp]").forEach((b) => b.setAttribute("aria-expanded",
      b.hasAttribute("data-bdlog") ? v === "log" : b.hasAttribute("data-bdtree") ? v === "tree" : popOpen));
    if (v === "tree" && !targets) loadTargets();
  }
  // 기록: what came up, what waits for a check, what still has open directives. A row finds its card.
  const logRow = (it, v, note) => `<button class="press bd-lgr" data-bdloc="${esc(ikey(it))}" data-v="${esc(v.v)}"><span class="th">${thumbIn(v)}</span>`
    + `<span class="bd-lgt"><b><span>${esc(it.title)}</span> <em class="num">${vShort(v.v)}</em></b><small>${esc(note)}</small></span></button>`;
  function logPane(ctx) {
    const ups = ctx.items.flatMap((it) => it.versions.map((v) => [it, v])).sort((a, b) => String(b[1].at || "").localeCompare(String(a[1].at || ""))).slice(0, 8);
    const wait = ctx.items.filter((it) => status("need_check", it));
    const open = ctx.items.filter((it) => it.open.length);
    const sec = (t, rows) => `<p class="k">${t} <span class="num">${rows.length}</span></p>` + (rows.length ? `<div class="bd-lgl">${rows.join("")}</div>` : `<p class="bd-lg0">${tl("bdx.log.none")}</p>`);
    return sec(tl("bdx.log.up"), ups.map(([it, v]) => logRow(it, v, ago(v.at))))
      + sec(tl("bdx.log.wait"), wait.map((it) => logRow(it, newest(it), ago(waitOf(it)))))
      + sec(tl("bdx.log.open"), open.map((it) => logRow(it, newest(it), tl("board.open", {n: it.open.length}))));
  }
  const logCount = (ctx) => ctx.items.filter((it) => status("need_check", it) || it.open.length).length;
  // A card brought into view and opened; on the version rows, its row scrolled to.
  function locate(ctx, key, v) {
    if (!ctx.live) {
      const lane = ctx.host.querySelectorAll(".bd-lane")[ctx.items.findIndex((it) => ikey(it) === key)];
      if (!lane) return;
      lane.scrollIntoView({block: "center", behavior: calm() ? "auto" : "smooth"});
      lane.classList.add("found"); setTimeout(() => lane.classList.remove("found"), 1400);
      return;
    }
    const ns = ctx.live.nodes.filter((n) => n.type === "ver" && ikey(n.it) === key), n = ns.find((x) => x.v.v === v) || ns[ns.length - 1];
    if (n) ctx.live.show(n);
  }

  // 넘기기: every project with its newest conversation (GET /api/board/targets, read once a visit).
  // A card carried onto a row hands the result over there; @ starts that conversation with --item.
  let targets = null;
  const loadTargets = () => get("/api/board/targets").then((r) => {
    targets = r.targets;
    if (cur) document.querySelectorAll(".bd-tree").forEach((p) => { p.innerHTML = treePane(cur); wireTree(cur, p); });
  }).catch((e) => toast(e.message));
  // Every project of the app (projects(), in the person's own order) with its newest pictures, how
  // many items it has, how many a session is working on and how many wait for a check; the board's
  // own project is marked. @ waits for the newest conversations to be read.
  function treePane(ctx) {
    const sid = new Map((targets || []).map((t) => [t.project, t.sid])), now = Date.now();
    const is = (k, x) => SMART[k]({...x, flow: flowOf(x)}, now);
    const own = ctx.key === ALL ? (level !== "" && level !== ALL ? level : null) : reelP(ctx);
    return `<p class="k">${tl("bdx.tree.h")}</p><p class="bd-lg0">${tl("bdx.tree.hint")}</p><div class="bd-trl">${projects().map((g) => {
      const work = g.items.filter((x) => is("fixing", x)).length, wait = g.items.filter((x) => is("need_check", x)).length;
      const thumbs = g.items.slice().sort((a, b) => String(b.at || "").localeCompare(String(a.at || ""))).filter((x) => x.thumb).slice(0, 3);
      const at = tl("bdx.tree.at", {p: pname(g.name)}), there = sid.get(g.name);
      return `<div class="bd-trr${g.name === own ? " own" : ""}" data-bdto="${esc(g.name)}"><span class="bd-trt">${thumbs.length ? thumbs.map((x) => `<span>${imgTag(x.thumb, {drag: false})}</span>`).join("") : deptIco(g, "ico")}</span>`
        + `<span class="bd-lgt"><b><span>${esc(pname(g.name))}</span>${g.name === own ? ` <em>${tl("bdx.tree.own")}</em>` : ""}</b><small class="num">${tl("bdx.pj.items", {n: g.items.length})}`
        + (work ? ` · <i class="w">${tl("bdx.tree.work", {n: work})}</i>` : "") + (wait ? ` · <i class="c">${tl("bdx.pj.wait", {n: wait})}</i>` : "") + `</small></span>`
        + `<button class="press bd-at" data-bdat="${esc(g.name)}" aria-label="${esc(at)}" title="${esc(at)}"${there ? "" : " disabled"}>@</button></div>`;
    }).join("")}</div>`;
  }
  function wireTree(ctx, pane) {
    pane.querySelectorAll("[data-bdat]").forEach((b) => b.onclick = () => atChat(ctx, b.dataset.bdat));
  }
  async function handOff(it, to) {
    if (!await askSheet(tl("bdx.tree.go"), tl("bdx.tree.ask", {t: it.title, to: jo(pname(to), "로", "으로")}), false, tl("bdx.tree.go"))) return;
    try {
      const r = await loopFetch("/api/board/handoff", {json: {p: it.project, i: it.id, to}});
      toast(r.declined ? tl("bdx.ask.no") : tl("bdx.tree.sent", {to: jo(pname(to), "로", "으로")}));
    } catch (e) { toast(e.message); }
  }
  async function atChat(ctx, to) {
    const n = ctx.live && ctx.m.sel && ctx.live.nodes.find((x) => x.id === ctx.m.sel), t = (targets || []).find((x) => x.project === to);
    if (!n) return toast(tl("bdx.tree.pick"));
    if (!t || !t.sid) return toast(tl("bdx.tree.none", {to: pname(to)}));
    const s = await get("/api/project/session?id=" + encodeURIComponent(t.sid)).catch(() => null);
    if (!s || !s.found || !s.project) return toast(tl("itemView.madeGone"));
    window.pjDraft?.(t.sid, `--item ${n.it.id} `);
    nav("project/" + encodeURIComponent(s.project) + "/" + encodeURIComponent(t.sid));
  }
  // A card carried over the board opens the 넘기기 pane for the drop (and shuts it after, if it
  // was shut); a drop on another project's row puts the card back and asks to hand it over.
  function carry(ctx) {
    const {vp, nodes, saved} = ctx.live;
    let c = null;
    // The carried card is under the pointer too, so every element there is looked through.
    const rowAt = (e, own) => document.elementsFromPoint(e.clientX, e.clientY).map((x) => x.closest("[data-bdto]")).find((r) => r && r.dataset.bdto !== own) || null;
    vp.addEventListener("pointerdown", (e) => {
      if (!e.isPrimary) { c = null; return; }
      const hit = !(e.pointerType === "mouse" && e.button) && !e.target.closest("[data-bdx]") && e.target.closest(".bd-node.ver"), n = hit && nodes.find((x) => x.el === hit);
      c = n ? {n, sx: e.clientX, sy: e.clientY, was: saved[n.id], on: false, row: null, opened: false} : null;
    });
    vp.addEventListener("pointermove", (e) => {
      if (!c) return;
      if (!c.on) {
        if (Math.hypot(e.clientX - c.sx, e.clientY - c.sy) < 5) return;
        c.on = true; c.opened = side !== "tree";
        if (c.opened) setSide("tree");
      }
      vp.querySelectorAll(`.bd-tree [data-bdto="${CSS.escape(c.n.it.project)}"]:not(.here)`).forEach((r) => r.classList.add("here"));
      const r = rowAt(e, c.n.it.project);
      if (r === c.row) return;
      c.row?.classList.remove("hot"); r?.classList.add("hot"); c.row = r;
    });
    const end = (e) => {
      const d = c; c = null;
      if (!d || !d.on) return;
      vp.querySelectorAll(".bd-tree .here,.bd-tree .hot").forEach((r) => r.classList.remove("here", "hot"));
      if (d.opened) setSide("");
      const to = e.type === "pointerup" && d.row && d.row.dataset.bdto;
      if (!to) return;
      if (d.was) saved[d.n.id] = d.was; else delete saved[d.n.id];
      ctx.live.keep(); ctx.redraw();
      handOff(d.n.it, to);
    };
    vp.addEventListener("pointerup", end); vp.addEventListener("pointercancel", end);
  }

  // ---- 고르기: a version with one picture per option is answered on the board ([이걸로]); the
  // answer is the same "[답]" comment the item page writes, and the others fold into 다른 안.
  const later = new Set();    // "project/id/v" put off with [나중에], for this visit
  function choiceBlock(c) {
    const cell = (f, i) => `<div class="bd-cc${c.q.rec === i ? " rec" : ""}"><span class="th">${f.thumb ? imgTag(f.thumb, {drag: false}) : ic("image")}</span><b>${esc(c.q.options[i])}</b>`
      + (c.pick < 0 ? `<button class="btn sm fill press" data-bdpick="${i}">${tl("bdx.c.this")}</button>` : "") + `</div>`;
    if (c.pick < 0) return `<div class="bd-cands"><p class="k">${esc(c.q.q)}</p><div class="bd-cg">${c.files.map(cell).join("")}</div><button class="btn sm weak press" data-bdlater>${tl("bdx.c.later")}</button></div>`;
    const others = c.files.map((f, i) => i === c.pick ? "" : cell(f, i)).join("");
    return `<div class="bd-cands"><p class="k">${esc(c.q.q)} · <b>${esc(c.q.options[c.pick])}</b></p><div class="bd-cg one">${cell(c.files[c.pick], c.pick)}</div>`
      + `<details class="bd-other"><summary class="press">${tl("bdx.c.other", {n: c.files.length - 1})}</summary><div class="bd-cg">${others}</div></details></div>`;
  }
  async function pickOne(ctx, it, c, i) {
    const at = {p: it.project, i: it.id, v: newest(it).v, dept: it.sum.dept};
    try { await post("/api/comment", {p: at.p, i: at.i, v: at.v, text:`[답]\n${c.q.n}. ${c.q.q} → ${c.q.options[i]}`}); await sendNow(at); ctx.again(); }
    catch (e) { toast(e.message); ctx.redraw(); }
  }

  // ---- 릴: the project's reel (reel.py) as a band at the foot of the board. A press on a frame
  // finds its card; a mouse carries a frame to another place (web/listorder.js does the
  // room-making arithmetic, sideways here; touch keeps scrolling, as on the project list), and
  // Alt+←/→ moves one.
  const reels = {};           // project -> GET /api/reel, read once a visit and after each change
  const reelP = (ctx) => { const ps = new Set(ctx.items.map((it) => it.project)); return ps.size === 1 ? [...ps][0] : null; };
  const reelN = (p, it) => ((reels[p] || {}).rows || []).filter((r) => r.id === it.id).length;
  const reelSet = (ctx, p, req) => req.then((r) => { reels[p] = r; if (cur === ctx) ctx.redraw(); return r; }).catch((e) => toast(e.message));
  function syncReel(ctx, p) {
    reelSet(ctx, p, post("/api/reel/sync", {p})).then((r) => r && r.moved && toastAct(tl("bdx.reel.synced", {n: r.moved}), tl("bdx.reel.undo"),
      () => reelSet(cur, p, post("/api/reel/sync", {p, undo: true}))));
  }
  function band(ctx) {
    const p = reelP(ctx), vp = ctx.live.vp;
    if (!p) return;
    if (!reels[p]) { get("/api/reel?p=" + encodeURIComponent(p)).then((r) => { reels[p] = r; if (cur === ctx) ctx.redraw(); }).catch((e) => toast(e.message)); return; }
    const rows = reels[p].rows;
    if (!rows.length) return;
    const behind = rows.filter((r) => r.behind).length, el = document.createElement("div");
    el.className = "bd-reel"; el.dataset.bdx = ""; el.setAttribute("role", "group"); el.setAttribute("aria-label", tl("bdx.reel"));
    el.innerHTML = `<button class="press bd-rlh" data-bdreeltab title="${tl("bdx.reel.tabgo")}">${tl("bdx.reel")} <b class="num">${rows.length}</b></button>`
      + `<div class="bd-rll">${rows.map((r) => `<button class="press bd-rlc${r.behind ? " old" : ""}" aria-label="${esc(r.title)} ${vShort(r.v)}"><span class="th">${r.thumb ? imgTag(r.thumb, {drag: false}) : ic("image")}</span><b class="num">${vShort(r.v)}${r.behind ? ` → ${vShort(r.latest)}` : ""}</b></button>`).join("")}</div>`
      + (behind ? `<button class="btn sm weak press" data-bdsync>${tl("bdx.reel.sync", {n: behind})}</button>` : "");
    vp.append(el);
    el.querySelector("[data-bdreeltab]").onclick = () => nav("reel");
    el.querySelector("[data-bdsync]")?.addEventListener("click", () => syncReel(ctx, p));
    const list = el.querySelector(".bd-rll"), chips = [...list.children];
    chips.forEach((ch, from) => {
      const row = rows[from];
      ch.onclick = () => { if (ch.dataset.moved) { delete ch.dataset.moved; return; } locate(ctx, `${p}/${row.id}`, row.v); };
      ch.onkeydown = (e) => {
        const to = from + (e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0);
        if (!e.altKey || to === from || to < 0 || to >= chips.length) return;
        e.preventDefault();
        // The redrawn band gets the keyboard back on the frame that moved.
        reelSet(ctx, p, post("/api/reel", {p, order: reordered(chips.length, from, to)})).then(() => cur?.live?.vp.querySelectorAll(".bd-rlc")[to]?.focus());
      };
      ch.onpointerdown = (e) => {
        if (e.pointerType !== "mouse" || e.button) return;
        const sx = e.clientX;
        let st = null;
        const move = (ev) => {
          const dx = ev.clientX - sx;
          if (!st) {
            if (Math.abs(dx) < 4) return;
            const rs = chips.map((x) => x.getBoundingClientRect());
            st = {mids: rs.map((r) => r.left + r.width / 2), sizes: rs.map((r, i) => i + 1 < rs.length ? rs[i + 1].left - r.left : r.width), to: from};
            list.classList.add("drag"); ch.classList.add("lift");
          }
          st.to = PjOrder.slot(st.mids, st.mids[from] + dx, from);
          PjOrder.shifts(st.sizes, from, st.to).forEach((d, i) => { if (i !== from) chips[i].style.transform = d ? `translateX(${d}px)` : ""; });
          ch.style.transform = `translateX(${dx}px)`;
        };
        const up = () => {
          removeEventListener("pointermove", move); removeEventListener("pointerup", up);
          if (!st) return;
          ch.dataset.moved = "1"; ch.classList.remove("lift");
          ch.style.transform = `translateX(${PjOrder.shifts(st.sizes, from, st.to)[from]}px)`;
          setTimeout(() => {
            list.classList.remove("drag");
            if (st.to !== from) reelSet(ctx, p, post("/api/reel", {p, order: reordered(chips.length, from, st.to)}));
            else ch.style.transform = "";
          }, calm() ? 0 : 220);
        };
        addEventListener("pointermove", move); addEventListener("pointerup", up);
      };
    });
  }
  // Each card's corner: 릴 (×n when the item is in it more than once) and 고르기's state; a picked
  // option's own picture stands in for the first one.
  function marks(ctx) {
    const p = reelP(ctx);
    ctx.live.nodes.forEach((n) => {
      if (n.type !== "ver" || !(n.last || ctx.mode === "fold")) return;
      const th = n.el.querySelector(".th"), tags = [], k = p ? reelN(p, n.it) : 0, c = n.last && choiceOf(n.it);
      if (k) tags.push(`<span>${k > 1 ? tl("bdx.reel.xn", {n: k}) : tl("bdx.reel")}</span>`);
      if (c && c.pick < 0 && !later.has(`${ikey(n.it)}/${n.v.v}`)) tags.push(`<span class="ask">${tl("bdx.c.badge", {n: c.files.length})}</span>`);
      if (c && c.pick >= 0) {
        tags.push(`<span>${tl("bdx.c.other", {n: c.files.length - 1})}</span>`);
        const im = th.querySelector("img"), f = c.files[c.pick];
        if (im && f.thumb) im.src = f.thumb;
      }
      if (tags.length) th.insertAdjacentHTML("beforeend", `<span class="bd-tags">${tags.join("")}</span>`);
    });
  }

  // ---- 빈 칸 = 요청: a + between rows opens one line there; it goes to the project's newest
  // conversation as a scoped request (boardask.py), after the exact text is shown once. The slot
  // waits, dashed, until the project has an item newer than the request ("v2-bdreq", per device).
  let reqs = ls("v2-bdreq") || [];
  let slotAt = -1;            // the gap whose line is open, on the board on screen
  async function askBoard(body) {
    const prep = await post("/api/board/ask", body);
    if (!await askSheet(tl("bdx.ask.go"), `${tl("bdx.ask.q")} ${prep.line}`, false, tl("bdx.ask.go"))) return false;
    const r = await loopFetch("/api/board/ask", {json: {...body, send: true}});
    toast(r.declined ? tl("bdx.ask.no") : tl("bdx.ask.sent"));
    return !r.declined;
  }
  function slots(ctx) {
    const {world} = ctx.live, gapY = (g) => g * (BV.CH + BV.GY) - BV.GY / 2;
    const left = reqs.filter((r) => !filled(r, ctx.items));
    if (left.length !== reqs.length) { reqs = left; ls("v2-bdreq", reqs); }
    const waiting = new Map(reqs.map((r) => [ctx.items.findIndex((it) => ikey(it) === r.after) + 1, r]));
    ctx.items.forEach((it, i) => {
      const g = i + 1, y = gapY(g);
      if (g === slotAt) {
        world.insertAdjacentHTML("beforeend", `<form class="bd-slot" data-bdx style="transform:translate(0px,${y - 15}px)"><input maxlength="600" placeholder="${tl("bdx.slot.ph")}" aria-label="${tl("bdx.slot.ph")}"><button class="btn sm fill press">${tl("bdx.slot.send")}</button><button type="button" class="press bd-slx" aria-label="${tl("ui.close")}">${ic("x")}</button></form>`);
        const f = world.lastElementChild, q = f.querySelector("input");
        const shut = () => { slotAt = -1; f.remove(); };
        f.querySelector(".bd-slx").onclick = shut;
        q.onkeydown = (e) => { if (e.key === "Escape") { e.preventDefault(); shut(); } };
        f.onsubmit = async (e) => {
          e.preventDefault();
          const text = q.value.trim(), since = ctx.items.flatMap((x) => x.versions.map((v) => String(v.at || ""))).sort().pop() || "";
          if (!text) return q.focus();
          try {
            if (!await askBoard({p: it.project, items: [it.id], what: "new", text})) return;
            reqs.push({p: it.project, after: ikey(it), text, since}); ls("v2-bdreq", reqs); slotAt = -1; ctx.redraw();
          } catch (err) { toast(err.message); }
        };
        requestAnimationFrame(() => q.focus({preventScroll: true}));
      } else if (waiting.has(g)) {
        world.insertAdjacentHTML("beforeend", `<div class="bd-slot wait" data-bdx style="transform:translate(0px,${y - 14}px)">${ic("clock")}<span>${tl("bdx.slot.wait")} · ${esc(waiting.get(g).text)}</span></div>`);
      } else {
        world.insertAdjacentHTML("beforeend", `<button class="press bd-plus" data-bdx style="transform:translate(${BV.CW / 2 - 12}px,${y - 12}px)" aria-label="${tl("bdx.slot.add")}" title="${tl("bdx.slot.add")}">${ic("plus")}</button>`);
        world.lastElementChild.onclick = () => { slotAt = g; ctx.redraw(); };
      }
    });
  }

  // ---- 휴대폰 보기: each item's versions as one strip that slides sideways (the newest in view),
  // and ticks at the edge, one per item, lit for the ones on screen; a tick goes to its item.
  let tickIO = null;
  function ticks(ctx) {
    const rail = ctx.host.querySelector(".bd-rail");
    if (!rail) return;
    rail.classList.add("film");
    rail.querySelectorAll(".bd-steps").forEach((s) => { s.scrollLeft = s.scrollWidth; });
    tickIO?.disconnect();
    const lanes = [...rail.querySelectorAll(".bd-lane")];
    if (lanes.length < 2) return;
    const el = document.createElement("nav");
    el.className = "bd-ticks"; el.dataset.bdx = ""; el.setAttribute("aria-label", tl("bdx.ticks"));
    el.innerHTML = lanes.map((l, n) => `<button class="press" data-bdtk="${n}" aria-label="${esc(l.querySelector("h3").textContent)}"><i></i></button>`).join("");
    rail.append(el);
    tickIO = new IntersectionObserver((es) => es.forEach((e) => el.children[lanes.indexOf(e.target)]?.classList.toggle("on", e.isIntersecting)), {rootMargin: "-30% 0px -30% 0px"});
    lanes.forEach((l) => tickIO.observe(l));
    el.onclick = (e) => { const b = e.target.closest("[data-bdtk]"); if (b) lanes[+b.dataset.bdtk].scrollIntoView({block: "start", behavior: calm() ? "auto" : "smooth"}); };
  }

  // ---- 결과물 › 릴: every project's reel, its rows in order with the files' fps, 맞추기 (with
  // its 되돌리기), a pin that keeps a row on its version, and a request about the reel alone.
  function reelRow(r) {
    const pin = r.pin ? tl("bdx.reel.unpin") : tl("bdx.reel.pin");
    return `<li class="rl-row${r.gone ? " gone" : ""}"><span class="rl-n num">${r.n + 1}</span><span class="th">${r.thumb ? imgTag(r.thumb, {drag: false}) : ic("image")}</span>`
      + `<span class="rl-tx"><b><span>${esc(r.title)}</span> <em class="num">${vShort(r.v)}</em></b>`
      + (r.behind ? `<span class="rl-up">${tl("bdx.reel.behind", {a: vShort(r.v), b: vShort(r.latest)})}</span>` : "")
      + `<span class="rl-fps">${r.files.map((f) => `<span class="num">${esc(f.name)} · ${f.fps ? tl("bdx.reel.fps", {n: f.fps}) : tl("bdx.reel.still")}</span>`).join("")}</span></span>`
      + `<button class="ib press rl-pin${r.pin ? " on" : ""}" data-rlpin="${r.n}" aria-pressed="${r.pin}" aria-label="${pin}" title="${pin}">${ic("lock")}</button></li>`;
  }
  // 이어 보기: a clip plays through at its own speed (the frame count follows its fps); a still
  // holds for STILL_MS.
  const STILL_MS = 2000;
  function player(card, rows) {
    const clips = clipsOf(rows);
    const el = card.querySelector(".rl-play");
    if (!clips.length) { el.innerHTML = `<p class="rl-none">${tl("bdx.reel.noplay")}</p>`; return () => { el.innerHTML = ""; }; }
    el.innerHTML = `<div class="rl-scr"></div><div class="rl-ctl"><button class="ib press" data-rlgo="-1" aria-label="${tl("bdx.reel.prev")}" title="${tl("bdx.reel.prev")}">${ic("back")}</button>`
      + `<button class="ib press" data-rlpp></button><button class="ib press rl-nx" data-rlgo="1" aria-label="${tl("bdx.reel.next")}" title="${tl("bdx.reel.next")}">${ic("back")}</button>`
      + `<span class="rl-at num"></span><span class="sp"></span><button class="ib press" data-rlx aria-label="${tl("bdx.reel.close")}" title="${tl("bdx.reel.close")}">${ic("x")}</button></div>`;
    const scr = el.querySelector(".rl-scr"), at = el.querySelector(".rl-at"), pp = el.querySelector("[data-rlpp]");
    let n = 0, on = true, done = false, timer = 0, vid = null;
    const label = () => {
      const {f} = clips[n];
      const fr = vid && f.fps ? ` · ${tl("bdx.reel.frame", {f: Math.min(Math.floor(vid.currentTime * f.fps) + 1, f.frames || Infinity), of: f.frames || "?"})}` : "";
      at.textContent = `${f.fps ? tl("bdx.reel.fps", {n: f.fps}) : tl("bdx.reel.still")}${fr}`;
    };
    const paint = () => {
      const t = on ? tl("bdx.reel.pause") : tl("bdx.reel.play");
      pp.innerHTML = ic(on ? "pause" : "play"); pp.setAttribute("aria-label", t); pp.title = t;
      card.querySelectorAll(".rl-row").forEach((li, k) => li.classList.toggle("on", rows[k] === clips[n].r));
    };
    const run = () => {
      clearTimeout(timer);
      if (!on) return vid?.pause();
      if (vid) return vid.play().catch(() => {});
      timer = setTimeout(() => go(1), STILL_MS);
    };
    // The last one ends the run (play again starts from the first).
    const go = (d) => {
      if (n + d >= clips.length) { on = false; done = true; paint(); return run(); }
      show(n + d);
    };
    const show = (k) => {
      n = k; done = false;
      const {f, clip} = clips[n];
      scr.innerHTML = clip ? `<video src="${esc(f.play)}" playsinline preload="auto"></video>` : `<img src="${esc(f.play)}" alt="" draggable="false">`;
      vid = scr.querySelector("video");
      if (vid) { vid.onended = () => go(1); vid.ontimeupdate = label; }
      label(); paint(); run();
    };
    el.onclick = (e) => {
      const g = e.target.closest("[data-rlgo]");
      if (g) { on = true; show((n + +g.dataset.rlgo + clips.length) % clips.length); return; }
      if (!e.target.closest("[data-rlpp]")) return;
      on = !on;
      if (done) show(0); else { paint(); run(); }
    };
    show(0);
    return () => { clearTimeout(timer); vid?.pause(); el.innerHTML = ""; card.querySelectorAll(".rl-row.on").forEach((li) => li.classList.remove("on")); };
  }
  function drawReels(box, list, again) {
    box.innerHTML = !list.length ? `<div class="card plan none"><p>${tl("bdx.reel.none")}</p></div>` : list.map((x) => {
      const behind = x.rows.filter((r) => r.behind).length;
      return `<section class="card rl-card" data-rlp="${esc(x.project)}"><div class="ch"><h2>${esc(pname(x.project))}</h2><span class="n num">${x.rows.length}</span><span class="sp"></span>`
        + `<button class="btn sm weak press" data-rlplay aria-expanded="false">${ic("play")}<span>${tl("bdx.reel.play")}</span></button>`
        + (behind ? `<button class="btn sm press" data-rlsync>${tl("bdx.reel.sync", {n: behind})}</button>` : "")
        + `<button class="btn sm weak press" data-rlask aria-expanded="false">${tl("bdx.reel.ask")}</button></div>`
        + `<div class="rl-play"></div>`
        + `<form class="rl-ask" hidden><input maxlength="600" placeholder="${tl("bdx.reel.ask.ph")}" aria-label="${tl("bdx.reel.ask.ph")}"><button class="btn sm fill press">${tl("bdx.slot.send")}</button></form>`
        + `<ol class="rl-rows">${x.rows.map(reelRow).join("")}</ol></section>`;
    }).join("");
    box.querySelectorAll(".rl-card").forEach((card) => {
      const p = card.dataset.rlp, x = list.find((y) => y.project === p), f = card.querySelector(".rl-ask"), q = f.querySelector("input"), ab = card.querySelector("[data-rlask]");
      const pb = card.querySelector("[data-rlplay]");
      let stop = null;
      const close = () => { stop?.(); stop = null; pb.setAttribute("aria-expanded", "false"); };
      pb.onclick = () => { if (stop) return close(); stop = player(card, x.rows); pb.setAttribute("aria-expanded", "true"); };
      card.querySelector(".rl-play").addEventListener("click", (e) => { if (e.target.closest("[data-rlx]")) close(); });
      card.querySelector("[data-rlsync]")?.addEventListener("click", () => post("/api/reel/sync", {p}).then((r) => {
        again();
        if (r.moved) toastAct(tl("bdx.reel.synced", {n: r.moved}), tl("bdx.reel.undo"), () => post("/api/reel/sync", {p, undo: true}).then(again).catch((e) => toast(e.message)));
      }).catch((e) => toast(e.message)));
      ab.onclick = () => { f.hidden = !f.hidden; ab.setAttribute("aria-expanded", !f.hidden); if (!f.hidden) q.focus(); };
      f.onsubmit = async (e) => {
        e.preventDefault();
        if (!q.value.trim()) return q.focus();
        try { if (await askBoard({p, items: [...new Set(x.rows.map((r) => r.id))], what: "reel", text: q.value})) { q.value = ""; f.hidden = true; ab.setAttribute("aria-expanded", "false"); } }
        catch (err) { toast(err.message); }
      };
      card.querySelectorAll("[data-rlpin]").forEach((b) => b.onclick = () => post("/api/reel", {p, pin: +b.dataset.rlpin, on: b.getAttribute("aria-pressed") !== "true"}).then(again).catch((e) => toast(e.message)));
    });
  }
  // Every reel (no p) or one project's, into box. A refresh with the same reels leaves the box
  // alone, so a reel that is playing or a request being written is not cut off.
  const reelSeen = new WeakMap();
  function loadReels(box, p) {
    const again = () => { reelSeen.delete(box); loadReels(box, p); };
    return get(p ? `/api/reel?p=${encodeURIComponent(p)}` : "/api/reel").then((r) => {
      const list = p ? (r.rows.length ? [r] : []) : r.reels, s = JSON.stringify(list);
      if (!box.isConnected || s === reelSeen.get(box)) return;
      reelSeen.set(box, s); drawReels(box, list, again);
    }).catch((e) => { if (box.isConnected) box.innerHTML = `<div class="card plan none"><p>${esc(e.message)}</p></div>`; });
  }
  window.BoardSpread = {reel: loadReels};
  // 릴 is a tab of 결과물 (results.js draws the switch while this beta is on).
  MOVED.reel = "lib";
  SCREENS.reel = function () {
    // Own id: the project page's 릴 view keeps its box in #rlbox, and reusing it would leave
    // that page on screen when history steps back here.
    if (!document.getElementById("rlall")) V().innerHTML = `${window.resTabs ? resTabs("reel") : ""}<div id="rlall">${loadingHtml("", {quiet: true})}</div>`;
    loadReels(document.getElementById("rlall"));
    return {};
  };

  // A press anywhere else closes the filter sheet and the panes (넘기기 stays while a card is
  // pressed, since it may be carried onto a row).
  addEventListener("pointerdown", (e) => {
    if (!(popOpen || side) || e.target.closest(".bd-fpop,[data-bdfp],[data-bdlog],[data-bdtree]")) return;
    if (side === "tree" && e.target.closest(".bd-node.ver")) return;
    popOpen = false; setSide("");
  });
  const calm = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

  let cur = null;             // the board on screen: the ctx handed to after()
  let framed = false;         // the camera was fitted afresh in this paint
  const cols = (host) => Math.max(1, Math.floor((host.clientWidth - 24) / (BV.CW + BV.GY)));
  BV.ext = {
    sig: (key) => JSON.stringify([filt, peekOf(key), key === ALL ? level : ""]),
    items: (key, items, m) => { framed = !m.cam; return order(key === ALL && level !== "" && level !== ALL ? items.filter((it) => it.project === level) : items, filt.sort); },
    focus: (key, items) => filtering() ? new Set(items.filter((it) => matches(it, filt, status)).map(ikey)) : null,
    paint: (host, key, items, m, repaint) => inCollage(key) && collage(host, items, () => { m.cam = null; m.sel = null; repaint(); }),
    lay: (key, md, host) => md === "time" ? BV.layoutByTime
      : md === "fold" ? (items, saved) => layoutFold(items, saved, peekOf(key), cols(host), BV) : null,
    after: (ctx) => {
      cur = ctx;
      bar(ctx);
      if (!ctx.live) return ticks(ctx);
      if (ctx.mode === "fold") foldChips(ctx);
      if (ctx.mode === "time") lanes(ctx, framed);
      marks(ctx); band(ctx); carry(ctx);
      if (ctx.mode === "board") slots(ctx);
      dock(ctx);
      const sel = ctx.m.sel && ctx.live.nodes.find((n) => n.id === ctx.m.sel);
      if (sel) ctx.live.show(sel, true);
    },
    shown: (det, n, live) => detChips(det, n, live),
  };
})();
