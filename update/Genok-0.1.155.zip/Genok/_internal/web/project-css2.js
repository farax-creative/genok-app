// Genok web UI, cut from project.js: the room screen's stylesheet, second half.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
const PJ_CSS_2 = `
  .pj-newg{display:inline-flex;flex:none;border-radius:999px;background:#dcdcdc;color:#141414;transition:transform .18s var(--ease)}
  html[data-theme="light"] .pj-newg{background:#111114;color:#fff}
  .pj-newg:active{transform:scale(.97)}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn{height:34px;background:none;color:inherit;transform:none;transition:background-color .14s ease}
  :is(.pj-lhd,.pj-rail) .pj-newb{padding:0 8px 0 12px;border-radius:999px 0 0 999px;font-size:13px;font-weight:600;gap:6px;white-space:nowrap}
  :is(.pj-lhd,.pj-rail) .pj-newb svg{width:14px;height:14px;flex:none}
  :is(.pj-lhd,.pj-rail) .pj-newc{position:relative;width:34px;padding:0 2px 0 0;border-radius:0 999px 999px 0;justify-content:center}
  :is(.pj-lhd,.pj-rail) .pj-newc::before{content:"";position:absolute;left:0;top:10px;bottom:10px;width:1px;background:currentColor;opacity:.2}
  :is(.pj-lhd,.pj-rail) .pj-newc svg{width:12px;height:12px;flex:none;transform:rotate(90deg);transition:transform .2s var(--ease)}
  :is(.pj-lhd,.pj-rail) .pj-newc[aria-expanded="true"] svg{transform:rotate(-90deg)}
  @media(hover:hover){html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:hover{background:rgba(255,255,255,.42)}html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:hover{background:rgba(255,255,255,.14)}}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:active,html :is(.pj-lhd,.pj-rail) .pj-newg .pj-newc[aria-expanded="true"]{background:rgba(0,0,0,.1)}
  html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:active,html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-newc[aria-expanded="true"]{background:rgba(255,255,255,.22)}
  /* The keyboard's ring goes round the whole pill and the half it is on is tinted like a hover: a ring
     round one half alone (a 999px corner on one side only) was drawn in pieces. */
  .pj-newg:has(.pj-btn:focus-visible){outline:2px solid var(--focus-line);outline-offset:2px}
  html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:focus-visible{outline:none;background:rgba(255,255,255,.42)}
  html[data-theme="light"] :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn:focus-visible{background:rgba(255,255,255,.14)}
  @container (max-width:300px){.pj-vwb>span{display:none}}
  @container (max-width:165px){.pj-lhd .pj-newb span{display:none}.pj-lhd .pj-newb{padding:0 8px 0 12px}}
  @media(pointer:coarse){
    html :is(.pj-lhd,.pj-rail) .pj-newg .pj-btn{height:40px}
    :is(.pj-lhd,.pj-rail) .pj-newb{padding:0 12px 0 16px;font-size:15px}
    :is(.pj-lhd,.pj-rail) .pj-newc{width:44px}
    :is(.pj-lhd,.pj-rail) .pj-newc::before{top:12px;bottom:12px}
    .pj-vwb{height:40px;padding:0 12px 0 12px;font-size:15px}
    .pj-vwb::after,:is(.pj-lhd,.pj-rail) .pj-newg .pj-btn::after{content:"";position:absolute;inset:-2px 0}
    :is(.pj-lhd,.pj-rail) .pj-newb{position:relative}
  }
  @media(prefers-reduced-motion:reduce){.pj-newg,.pj-vwb,.pj-vwb .cv,:is(.pj-lhd,.pj-rail) .pj-newc svg{transition:none}.pj-newg:active{transform:none}}
  .pj-srow .sr-1 .pj-pinmk{flex:none;align-self:center;margin:0 -2px 0 -4px;color:var(--t3)}
  .pj-srows.sm .sr-1 .pj-pinmk{margin:0}
  /* The project's face before a title: identity, where the orb is state. Text-sized and flat. */
  .pj-face{flex:none;display:inline-grid;place-items:center;width:16px;height:16px;font-size:13px;line-height:1;color:var(--t2)}
  .pj-face .phi{display:block;width:16px;height:16px}
  .pj-face.hv .phi{width:15px;height:15px}
  .pj-face.ph.tint{color:color-mix(in srgb,var(--em-c) 70%,var(--t1))}
  .pj-srow .sr-1 .pj-face{align-self:center;margin-right:-2px}
  .pj-srows.sm .sr-1 .pj-face{margin-right:-2px}
  .pj-srow.mut .pj-face,.pj-olds .pj-srow .pj-face{opacity:.7}
  .pj-nth .t .pj-face{width:18px;height:18px;font-size:15px;margin-right:8px;vertical-align:-3px}
  .pj-nth .t .pj-face .phi{width:18px;height:18px} .pj-nth .t .pj-face.hv .phi{width:17px;height:17px}
  .pj-nth .t .pj-pinmk{margin-right:6px;vertical-align:-1px}
  .pj-fx .tin{margin-top:6px}
  .pj-fx .lbl{margin-top:16px}
  .pj-fx .seg.wide{margin:6px 0 0}
  .pj-fx [data-pv]{margin-top:0}
  .pj-fx [data-pv]:not(:empty){margin-top:8px}
  .pj-fx .btn.xl{width:100%;margin-top:16px}
  .pj-fx .fx-nm{display:grid;grid-template-columns:48px minmax(0,1fr);gap:8px;margin-top:6px}
  .pj-fx .fx-nm .tin{margin-top:0}
  .fx-ico{position:relative;width:48px;height:48px;border:0;border-radius:var(--r-md);background:var(--card-hi);box-shadow:inset 0 0 0 1px var(--line);display:grid;place-items:center;cursor:pointer;padding:0}
  .fx-pen{position:absolute;right:-4px;bottom:-4px;width:18px;height:18px;border-radius:50%;background:var(--card);box-shadow:0 0 0 1px var(--line);display:grid;place-items:center;color:var(--t2,var(--t3))}
  .fx-pen svg{width:10px;height:10px;fill:currentColor}
  .fx-loc .btn.sm,.pj-ov .btn.sm:not(.fill),.ip-c.auto{background:color-mix(in srgb,var(--t1) 9%,transparent);box-shadow:inset 0 0 0 1px var(--line)}
  @media (hover:hover){.fx-loc .btn.sm:hover,.pj-ov .btn.sm:not(.fill):not(:disabled):hover{background:color-mix(in srgb,var(--t1) 15%,transparent)}}
  .fx-ico .pj-em{width:34px;height:34px;font-size:22px;border-radius:8px}
  @media (hover:hover){.fx-ico:hover{background:var(--btn-hi)}}
  .fx-ico:focus-visible,.fx-reset:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
  .pj-em.tint,.pj-head .em.tint{background:color-mix(in srgb,var(--em-c) 26%,transparent);border-radius:8px}
  .pj-head .em.tint{border-radius:11px;font-size:24px}
  .pj-sgl .pj-em.tint{width:22px;height:22px;font-size:14px;border-radius:6px}
  .fx-loc{display:flex;align-items:center;gap:8px;margin-top:6px;padding:8px 12px 8px 16px;border-radius:var(--r-md);background:var(--card-hi);min-width:0}
  .fx-path{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
  .fx-par{display:flex;min-width:0;font-size:12px;line-height:1.4;color:var(--t2,var(--t3))}
  .fx-par .h{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-par .t{flex:0 0 auto;max-width:62%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-new{display:flex;align-items:center;gap:6px;min-width:0;font-size:15px;line-height:1.35;color:var(--t1)}
  .fx-new svg{flex:none;width:16px;height:16px;fill:currentColor;color:var(--t3)}
  .fx-new b{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fx-new b.none{font-weight:400;color:var(--t3);font-size:13px}
  .fx-loc .btn.sm{flex:none;gap:4px} .fx-loc .btn.sm svg,.pj-ov .btn.sm svg{width:15px;height:15px;fill:currentColor}
  .fx-loc.ed{padding:0;background:none;gap:8px;align-items:stretch}
  .fx-loc.ed .tin{flex:1;min-width:0;margin-top:0;font-size:14px}
  .fx-loc.ed .btn.sm{height:auto;min-height:40px;padding:0 12px}
  .fx-res{margin-top:8px;padding:0 2px}
  .pj-mkbox{margin-top:8px;padding:12px;border-radius:var(--r-md);background:var(--card);border:1px solid var(--line)}
  .pj-mkbox[hidden]{display:none}
  .pj-mkbox .lbl{font-size:13px;color:var(--t3);font-weight:600;margin:8px 0 6px} .pj-mkbox .lbl:first-child{margin-top:0}
  .pj-mkbox .tin{width:100%;box-sizing:border-box;height:40px;border:0;outline:none;background:var(--card-hi);border-radius:var(--r-md);padding:0 12px;font:inherit;font-size:14px;color:var(--t1)}
  .pj-mkbox .tin:focus-visible,.fx-loc.ed .tin:focus-visible{box-shadow:0 0 0 2px var(--blue)}
  .pj-mkbtn{flex:none;gap:4px} .pj-mkbtn svg{width:15px;height:15px;fill:currentColor}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-mkbox .tin,.fx-loc.ed .tin{font-size:16px;height:44px}}
  .pj-fx .fx-note{margin-top:8px;line-height:1.5}
  .fx-reset{border:0;background:none;padding:0;margin-left:4px;font:inherit;color:var(--blue-t,var(--blue));cursor:pointer;border-radius:4px;position:relative}
  .fx-reset::before{content:"";position:absolute;inset:-10px -6px}
  .pj-fx [hidden]{display:none}
  /* Each agent carries its own colour here as in the lists, so the pick reads at a glance. */
  .pj-fx .agdot{opacity:.55;transition:opacity .16s var(--ease)}
  .pj-fx .on .agdot{opacity:1}
  /* A short window: the sheet tightens rather than scrolls. */
  @media (max-height:940px){
    .pj-fx .lbl{margin-top:8px} .pj-fx .tin,.pj-fx .fx-nm,.pj-fx .seg.wide{margin-top:4px}
    .pj-fx .tin{padding-top:8px;padding-bottom:8px} .pj-fx .fx-ico{height:auto}
    .pj-fx .fx-note{margin-top:4px;line-height:1.35} .pj-fx .btn.xl{margin-top:8px;min-height:44px;padding-top:8px;padding-bottom:8px}
    .pj-fx [data-pv]:not(:empty){margin-top:6px} .pj-fx > .hint:first-of-type{margin-bottom:0}
  }
  .pj-ov{position:fixed;z-index:400;box-sizing:border-box;width:min(380px,calc(100vw - 16px));max-height:min(520px,calc(100dvh - 16px));display:flex;flex-direction:column;gap:8px;padding:12px;
    background:var(--menu-bg,var(--card));border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--menu-shadow,0 12px 40px rgba(0,0,0,.35));color:var(--t1);font-size:14px}
  .pj-ov .sp{flex:1}
  .pj-ov button{font:inherit;color:inherit;cursor:pointer}
  .pj-ov button:focus-visible,.pj-ov input:focus-visible{outline:2px solid var(--blue);outline-offset:1px}
  .pj-ov .btn:disabled{opacity:.4;cursor:default}
  .pj-ov .fp-none{margin:0;padding:16px 8px;color:var(--t3);font-size:13px;text-align:center}
  /* The folder chooser: places down the left, the address bar and the folders beside them, one
     row of actions underneath. Hairlines and the app's small radii; nothing is a pill. */
  .pj-fp{width:min(540px,calc(100vw - 16px));height:min(396px,calc(100dvh - 16px));max-height:none;display:grid;grid-template-columns:148px minmax(0,1fr);grid-template-rows:minmax(0,1fr) auto;gap:0;padding:0;overflow:hidden;font-size:13px}
  .pj-fp:focus{outline:none}
  .fp-side{display:flex;flex-direction:column;gap:6px;min-width:0;min-height:0;padding:12px 8px;border-right:1px solid var(--line);overflow-y:auto;scrollbar-width:none}
  .fp-side::-webkit-scrollbar,.fp-pl::-webkit-scrollbar,.fp-cr::-webkit-scrollbar{display:none}
  .fp-sh{padding:0 8px;font-size:11.5px;font-weight:500;letter-spacing:.01em;color:var(--t4)}
  .fp-pl{display:flex;flex-direction:column;gap:1px;min-width:0}
  .fp-pc{display:flex;align-items:center;gap:8px;min-width:0;height:28px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;font-size:13px;font-weight:400;color:var(--t2,var(--t3));text-align:left}
  .fp-pc svg{flex:none;width:14px;height:14px;fill:currentColor;color:var(--t4)}
  .fp-pc span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fp-pc.on{background:var(--btn-hi);color:var(--t1);font-weight:500} .fp-pc.on svg{color:var(--t2,var(--t3))}
  .fp-pc[data-p="pc"]{margin-top:8px;position:relative;overflow:visible}
  .fp-pc[data-p="pc"]::before{content:"";position:absolute;left:8px;right:8px;top:-5px;height:1px;background:var(--line)}
  .fp-main{display:flex;flex-direction:column;gap:6px;min-width:0;min-height:0;padding:12px 12px 8px}
  .fp-bar{display:flex;align-items:center;gap:4px;min-width:0}
  .fp-up,.fp-ed{flex:none;width:28px;height:28px;border:0;border-radius:var(--r-xs);background:none;display:grid;place-items:center;padding:0;color:var(--t3)}
  .fp-up svg{width:14px;height:14px;fill:currentColor} .fp-up:disabled{opacity:.3;cursor:default}
  .fp-ad{flex:1;min-width:0;height:30px;display:flex;align-items:center;border-radius:var(--r-sm);box-shadow:inset 0 0 0 1px var(--line);cursor:text;transition:box-shadow .15s ease,background-color .15s ease}
  .fp-ad.ed{background:var(--card-hi);box-shadow:inset 0 0 0 1.5px var(--blue)}
  .fp-ad.busy{opacity:.6}
  .fp-cr{flex:1;min-width:0;height:100%;display:flex;align-items:center;margin-right:16px;padding:0 2px 0 4px;overflow-x:auto;scrollbar-width:none;white-space:nowrap}
  .fp-cr.cut{-webkit-mask-image:linear-gradient(90deg,transparent,#000 22px);mask-image:linear-gradient(90deg,transparent,#000 22px)}
  .fp-cr button{flex:none;border:0;background:none;height:24px;padding:0 4px;border-radius:6px;font-size:13px;color:var(--t3);max-width:150px;overflow:hidden;text-overflow:ellipsis}
  .fp-cr button[aria-current]{color:var(--t1);font-weight:500}
  .fp-cr i{flex:none;display:grid;place-items:center;color:var(--t4)} .fp-cr i svg{width:9px;height:9px;fill:currentColor}
  .fp-ed{width:26px;height:26px;margin-right:2px;color:var(--t4)} .fp-ed svg{width:13px;height:13px;fill:currentColor}
  .fp-ad.ed .fp-cr,.fp-ad.ed .fp-ed{display:none}
  .fp-ad-in{flex:1;min-width:0;height:100%;border:0;background:none;padding:0 8px;font:inherit;font-size:13px;color:var(--t1);outline:none}
  .pj-ov .fp-ad-in:focus-visible{outline:none}
  .fp-ad-in[hidden]{display:none}
  .fp-ad-in::placeholder{color:var(--t4)}
  .fp-er{margin:0 2px 0 34px;font-size:12px;line-height:1.45;color:var(--red-t,#ff6b77);overflow-wrap:anywhere}
  .fp-er[hidden]{display:none}
  .fp-ls{flex:1 1 0;min-height:0;overflow-y:auto;margin:0 -4px;padding:0 4px;overscroll-behavior:contain}
  .fp-row{display:flex;align-items:center;gap:8px;width:100%;height:30px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;text-align:left;font-size:13px;color:var(--t1)}
  .fp-row span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fp-row svg{flex:none;width:15px;height:15px;fill:currentColor;color:var(--t3)} .fp-row svg:last-child{width:10px;height:10px;color:var(--t4);opacity:0}
  @media (hover:hover){.fp-row:hover,.fp-pc:not(.on):hover,.fp-cr button:hover,.fp-up:not(:disabled):hover,.fp-ed:hover,.fp-txt:not(:disabled):hover{background:color-mix(in srgb,var(--t1) 7%,transparent)}
    .fp-row:hover svg:last-child{opacity:1}.fp-ed:hover,.fp-up:not(:disabled):hover,.fp-txt:not(:disabled):hover{color:var(--t1)}}
  .pj-fp .fp-row:focus-visible{outline:none;background:var(--btn-hi);box-shadow:inset 0 0 0 1px var(--line)} .fp-row:focus-visible svg:last-child{opacity:1}
  .pj-fp .fp-none{padding:34px 12px 0;color:var(--t4);font-size:12px;line-height:1.5} .pj-fp .fp-none.more{padding:8px 12px 6px}
  .fp-new{display:flex;align-items:center;gap:8px;padding:0 0 4px 8px}
  .fp-new svg{flex:none;width:15px;height:15px;fill:currentColor;color:var(--t3)}
  .fp-new input{flex:1;min-width:0;height:30px;border:0;border-radius:var(--r-xs);background:var(--card-hi);padding:0 8px;font:inherit;font-size:13px;color:var(--t1);outline:none}
  .pj-fp .fp-new input:focus-visible{outline:none;box-shadow:inset 0 0 0 1.5px var(--blue)}
  .fp-new .btn.sm{height:30px;padding:0 12px;font-size:13px;font-weight:500}
  .fp-ft{grid-column:1/-1;display:flex;flex-wrap:wrap;align-items:center;gap:8px 4px;min-width:0;padding:8px 12px 8px 8px;border-top:1px solid var(--line)}
  .fp-say{flex:1 1 100%;margin:0 0 0 8px;font-size:12px;line-height:1.45;color:var(--t3);overflow-wrap:anywhere}
  .fp-txt{display:inline-flex;align-items:center;gap:6px;height:30px;padding:0 8px;border:0;border-radius:var(--r-xs);background:none;font-size:13px;font-weight:500;color:var(--t2,var(--t3));white-space:nowrap}
  .fp-txt svg{flex:none;width:13px;height:13px;fill:currentColor;color:var(--t3)} .fp-txt:disabled{opacity:.4;cursor:default}
  .fp-ft .btn.sm.fill{height:30px;padding:0 12px;font-size:13px;font-weight:600}
  @media (prefers-reduced-motion:reduce){.fp-ad{transition:none}}
  /* A narrow window: the places lie along the top in one quiet row. */
  @media (max-width:556px){
    .pj-fp{grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto}
    .fp-side{flex-direction:row;padding:8px 8px 8px;border-right:0;border-bottom:1px solid var(--line);overflow:visible}
    .fp-sh{display:none} .fp-pl{flex-direction:row;gap:2px;overflow-x:auto;scrollbar-width:none}
    .fp-pc{flex:none;max-width:150px} .fp-pc[data-p="pc"]{margin:0 0 0 8px} .fp-pc[data-p="pc"]::before{left:-5px;right:auto;top:6px;width:1px;height:16px}
    .fp-main{padding-top:8px} .pj-fp{height:min(476px,calc(100dvh - 16px))}
  }
  .pj-ip{width:min(344px,calc(100vw - 16px))}
  .ip-top{display:flex;align-items:center;gap:6px;min-height:32px}
  .ip-top .btn.sm{gap:4px}
  .ip-h{font-size:13px;font-weight:600;color:var(--t3)}
  .ip-sug,.ip-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:2px}
  /* Rows keep their cells' height: a clipped cell has no minimum of its own, and in a grid of limited
     height plain auto rows shrank to nothing, every row drawn over the last. */
  .ip-grid{grid-auto-rows:max-content;flex:1 1 auto;min-height:120px;max-height:192px;overflow-y:auto;border-radius:var(--r-md);background:var(--bg);padding:4px;align-content:start;overscroll-behavior:contain}
  .ip-grid .fp-none{grid-column:1/-1}
  .ip-sug button,.ip-grid button{aspect-ratio:1;border:0;border-radius:8px;background:none;padding:0;font-size:20px;line-height:1;display:grid;place-items:center;overflow:hidden}
  .ip-sug button.on,.ip-grid button.on{background:var(--blue-w,var(--btn-hi));box-shadow:inset 0 0 0 2px var(--blue-t,var(--blue))}
  @media (hover:hover){.ip-sug button:hover,.ip-grid button:hover{background:var(--btn-hi)}}
  .ip-seg{display:flex;gap:2px;padding:2px;border-radius:var(--r-sm);box-shadow:inset 0 0 0 1px var(--line)}
  .ip-seg button{flex:1 1 0;min-width:0;height:26px;border:0;border-radius:calc(var(--r-sm) - 2px);background:none;padding:0 2px;font-size:12px;font-weight:550;letter-spacing:-.01em;color:var(--t3);white-space:nowrap}
  .ip-seg button.on{background:color-mix(in srgb,var(--t1) 11%,transparent);color:var(--t1)}
  @media (hover:hover){.ip-seg button:not(.on):hover{color:var(--t1)}}
  .ip-seg button:focus-visible,.ip-sug button:focus-visible,.ip-grid button:focus-visible{outline:2px solid var(--blue);outline-offset:-2px}
  .pj-em .phi,.pj-head .em .phi,.pj-ip .phi{display:block}
  .ip-sug button[data-i],.ip-grid button[data-i]{color:var(--t1)}
  /* Only the cells in view are drawn. */
  .ip-grid button{content-visibility:auto;contain-intrinsic-size:auto 38px}
  .pj-em.ph.tint,.pj-head .em.ph.tint{color:color-mix(in srgb,var(--em-c) 72%,var(--t1))}
  .ip-q{height:34px;border:0;border-radius:var(--r-sm);background:var(--card-hi);padding:0 12px;font:inherit;font-size:14px;color:var(--t1);outline:none;width:100%;box-sizing:border-box}
  .ip-cols{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  .ip-c{width:26px;height:26px;border:0;border-radius:50%;padding:0;background:var(--em-c);position:relative}
  .ip-c::before{content:"";position:absolute;inset:-4px}
  .ip-c.on{box-shadow:0 0 0 2px var(--menu-bg,var(--card)),0 0 0 4px var(--em-c)}
  .ip-c.auto{width:auto;height:28px;padding:0 12px;border-radius:99px;font-size:13px;font-weight:550}
  .ip-c.auto.on{box-shadow:inset 0 0 0 1.5px var(--blue-t,var(--blue));background:var(--blue-w,var(--btn-hi));color:var(--blue-t,var(--t1))}
  @media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    .ip-sug,.ip-grid{grid-template-columns:repeat(auto-fill,minmax(44px,1fr))}
    .ip-sug button,.ip-grid button{min-height:44px;font-size:22px}
    /* The bigger cells need a taller picker: at the common height the list showed two rows. */
    .pj-ip{max-height:min(660px,calc(100dvh - 16px))} .ip-grid{max-height:264px}
    .ip-c{width:32px;height:32px} .ip-c::before{inset:-6px} .ip-c.auto{height:36px} .ip-cols{gap:12px}
    .fp-row{height:44px;font-size:15px} .fp-pc{height:44px;font-size:14px} .fp-up{width:44px;height:44px} .fp-ed{width:44px;height:44px} .fp-ad{height:44px} .fp-cr button{height:44px;font-size:14px}
    .pj-ov .btn.sm,.fp-ft .btn.sm.fill,.fp-new .btn.sm{height:40px} .fp-txt{height:44px}
    .pj-gh .pj-gn{position:relative} .pj-gh .pj-gn::before{content:"";position:absolute;inset:-8px -11px} .fp-txt,.fp-ft .btn.sm.fill{font-size:14px} .fp-new input,.fp-ad-in{height:40px;font-size:16px} .ip-q{height:44px;font-size:16px} .ip-seg button{height:36px;font-size:14px}
    .fp-er{margin-left:48px}
  }
  .pj-sq{display:block;width:100%;height:40px;font-size:15px;border-radius:var(--r-lg)}
  .pj-sfil{margin:8px 0 0}
  /* Claude | Codex under the tabs: two small chips, each with its tool's mark and how many it would show. */
  .pj-agf{display:flex;gap:6px;margin:6px 0 0}
  .pj-agf button{flex:0 1 auto;min-width:0;display:inline-flex;align-items:center;gap:4px;height:26px;padding:0 8px 0 8px;border-radius:999px;font-size:12px;font-weight:600;line-height:1;color:var(--t3);
    background:none;box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap;transition:background-color .14s ease,color .14s ease,box-shadow .14s ease}
  .pj-agf button .agdot{margin:0}
  .pj-agf button .num{font-size:12px;font-weight:500;font-variant-numeric:tabular-nums;color:var(--t4)}
  .pj-agf button.on{color:var(--t1);background:color-mix(in srgb,var(--ag-claude) 14%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--ag-claude) 46%,transparent)}
  .pj-agf button.cx.on{background:color-mix(in srgb,var(--ag-codex) 15%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--ag-codex) 46%,transparent)}
  .pj-agf button.on .num{color:var(--t2)}
  .pj-agf button:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(pointer:coarse){.pj-agf button{position:relative}.pj-agf button::after{content:"";position:absolute;inset:-5px 0}}
  @media(hover:hover){.pj-agf button:not(.on):hover{color:var(--t1);background:var(--card-hi)}}
  @media(pointer:coarse){.pj-agf{gap:8px;margin-top:8px}.pj-agf button{height:34px;padding:0 12px 0 12px;font-size:14px}.pj-agf button .dot{width:8px;height:8px}}
  .pj-none{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:center;gap:4px 8px}
  .pj-fclr{height:28px;padding:0 12px;border-radius:999px;font-size:12px;font-weight:600;color:var(--t1);background:var(--btn)}
  .pj-fclr:focus-visible{outline:2px solid var(--focus-line);outline-offset:2px}
  @media(hover:hover){.pj-fclr:hover{background:var(--btn-hi)}}
  @media(pointer:coarse){.pj-fclr{height:36px;padding:0 16px;font-size:14px}}
  .pj-srows{margin-top:8px}
  .pj-sfil{container-type:inline-size}
  .pj-sfil button{min-width:0;padding:0 4px;white-space:nowrap}
  @container (max-width:230px){.pj-sfil button{font-size:12px;letter-spacing:-.02em}}
  /* One row shape for both views: the project's icon (or its indent), the title, a quiet line
     under it, when. Titles start on one axis (42px) whichever view is on. */
  .pj-srow{position:relative;display:flex;align-items:center;gap:8px;width:100%;height:56px;padding:0 12px 0 8px;margin-top:2px;border-radius:var(--r-lg);
    text-align:left;color:var(--t1);cursor:pointer;-webkit-tap-highlight-color:transparent;transition:background-color .14s ease,transform .18s var(--ease)}
  .pj-srow.inert{cursor:default}
  @media(hover:hover){.pj-srow:hover{background:var(--card-hi)}}
  .pj-srow.on{background:color-mix(in srgb,var(--t1) 10%,transparent)}
  /* On a phone the bar above already says 대화. */
  @media(max-width:699px){.pj-lhd{margin-left:0}.pj-lhd b{display:none}.pj-lhd .pj-vwb{margin-right:auto}}
  .pj-lhd.ph{margin-bottom:8px}
  /* A phone: 새 세션 waits in the thumb's corner, over the list and above the tab bar. */
  .pj-newg.pj-fab{position:fixed;z-index:8;right:calc(16px + env(safe-area-inset-right));bottom:calc(78px + env(safe-area-inset-bottom));box-shadow:0 6px 20px rgba(0,0,0,.34),0 0 0 1px rgba(0,0,0,.06)}
  html .pj-rail .pj-newg.pj-fab .pj-btn{height:48px}
  .pj-rail .pj-fab .pj-newb{padding:0 12px 0 16px;font-size:16px}
  .pj-rail .pj-fab .pj-newb svg{width:16px;height:16px}
  .pj-rail .pj-fab .pj-newc::before{top:14px;bottom:14px}
  .pj-rail:has(.pj-fab){padding-bottom:72px}
  body.pjchat .pj-fab,body.typing .pj-fab{display:none}
  .pj-lhd.ph .pj-sq{flex:1;min-width:0;width:auto;margin:0}
  .pj-srow:focus-visible,.pj-sgh:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  .pj-srow .sr-e{flex:none;width:24px;height:24px;display:grid;place-items:center}
  .pj-srow .sr-e .pj-em{font-size:16px}
  /* The cell before a row says where the session was opened: Claude Code in its orange with a
     spark, Codex in its blue with code brackets (the two colours 사용량 already draws them in).
     Shape and colour both, so neither is needed alone. */
  .pj-srow .sr-e.ag{border-radius:8px;color:var(--ag-claude);background:color-mix(in srgb,var(--ag-claude) 15%,transparent)}
  .pj-srow .sr-e.ag.cx{color:var(--ag-codex);background:color-mix(in srgb,var(--ag-codex) 16%,transparent)}
  .pj-srow .sr-e.ag svg{width:14px;height:14px}
  .pj-srow .sr-x{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .pj-srow .sr-1{display:flex;align-items:baseline;gap:8px;min-width:0}
  .pj-srow .sr-2{display:flex;align-items:center;gap:6px;min-width:0;height:18px;font-size:12px;line-height:18px;color:var(--t3)}
  .pj-srow .sr-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14.5px;font-weight:600;line-height:20px;letter-spacing:-.005em}
  .pj-srow .sr-s{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-srow .sr-w{flex:none;min-width:28px;text-align:right;font-size:12px;line-height:20px;color:var(--t3);font-variant-numeric:tabular-nums;transition:opacity .12s ease}
  .pj-srow .sr-i{flex:none;display:inline-flex;align-items:center;height:18px}
  .pj-srow .sr-i i{width:7px;height:7px;border-radius:50%;background:var(--green)}
  .pj-srow .sr-dup{flex:none;position:relative;font-size:11px;font-weight:600;line-height:18px;padding:0 6px;border:0;border-radius:6px;background:var(--btn);color:var(--t2);font-variant-numeric:tabular-nums;cursor:pointer}
  .pj-srow.tw{margin-left:16px;width:calc(100% - 16px)}
  .pj-srow .sr-dup::before{content:"";position:absolute;inset:-10px -8px}
  .pj-srow .sr-dup:hover,.pj-srow .sr-dup[aria-expanded="true"]{color:var(--t1)}
  .pj-srow .sr-ask{flex:none;font-size:12px;font-weight:600;line-height:18px;padding:0 6px;border-radius:6px;color:var(--orange);
    background:color-mix(in srgb,var(--orange) 14%,transparent)}
  .pj-srow.mut .sr-t,.pj-olds .pj-srow .sr-t{color:var(--t2);font-weight:500}
  /* The row's menu: with a pointer it takes the place of the time while the row is pointed at or
     focused; on a touch screen it is always there, at the row's end. */
  .pj-srow .sr-m,.pj-sgl .sr-m{position:relative;flex:none;width:28px;height:28px;margin:0;z-index:1}
  .sr-m::after{content:"";position:absolute;inset:0}
  @media(hover:hover) and (pointer:fine){
    .pj-srow .sr-m{position:absolute;right:6px;top:6px;opacity:0;transition:opacity .12s ease,background-color .14s ease}
    .pj-sgl .sr-m{opacity:0;transition:opacity .12s ease,background-color .14s ease}
    .pj-srow .sr-m::after,.pj-sgl .sr-m::after{inset:-3px}
    .pj-srow:hover .sr-m,.pj-srow:focus-within .sr-m,.pj-sgl:hover .sr-m,.pj-sgl:focus-within .sr-m,.sr-m[aria-expanded="true"]{opacity:1}
    .pj-srow:hover .sr-m~.sr-x .sr-w,.pj-srow:focus-within .sr-m~.sr-x .sr-w{opacity:0}
  }
  @media not ((hover:hover) and (pointer:fine)){
    .pj-srow{height:60px;padding-right:4px}
    .pj-srow .sr-m,.pj-sgl .sr-m{width:44px;height:44px;color:var(--t4)}
    .pj-srow .sr-x{order:1}.pj-srow .sr-m{order:2}
  }
  /* 작게: one line a row. The title, how it is doing (the dot, 내 차례), when. */
  .pj-srows.sm .pj-srow{height:36px;margin-top:1px;border-radius:var(--r-md)}
  .pj-srows.sm .sr-x{flex-direction:row;align-items:center;gap:8px}
  .pj-srows.sm .sr-1{display:contents}
  .pj-srows.sm .sr-t{font-size:13px;font-weight:500}
  .pj-srows.sm .sr-2{order:1;flex:none;height:auto}
  .pj-srows.sm .sr-s{display:none}
  .pj-srows.sm .sr-w{order:2;line-height:18px}
  .pj-srows.sm .sr-e .pj-em{font-size:15px}
  .pj-srows.sm .pj-sgrp{margin-top:4px}
  .pj-srows.sm .pj-sdv{margin-top:8px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-srow .sr-m{top:4px}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-srow{height:44px}}
  /* 폴더별: the project's name once, its sessions under it on the title axis. */
  .pj-sgrp{margin-top:6px}
  .pj-sgrp:first-child,.pj-sdv:first-child{margin-top:0}
  .pj-sgl{display:flex;align-items:center;gap:2px;min-width:0;padding-right:6px}
  .pj-sgh{flex:1;min-width:0;display:flex;align-items:center;gap:8px;height:36px;padding:0 4px 0 8px;border-radius:var(--r-md);text-align:left;
    color:var(--t2);font-size:13px;font-weight:600;transition:background-color .14s ease,color .14s ease,transform .18s var(--ease)}
  @media(hover:hover){.pj-sgh:hover{color:var(--t1)}}
  .pj-sgh .pj-em{font-size:16px}
  .pj-sgh .nm{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-sgh .n{flex:none;margin-left:-4px;color:var(--t4);font-weight:500;font-variant-numeric:tabular-nums}
  .pj-sgh .cv{flex:none;width:12px;height:12px;color:var(--t4);transform:rotate(90deg);transition:transform .2s var(--ease)}
  .pj-sgh[aria-expanded="false"] .cv{transform:none}
  /* Shut with the open chat inside: the head carries the open row's fill, so the list still says where you are. */
  .pj-sgh.has{background:var(--btn);color:var(--t1)}
  .pj-sgl .sr-m{order:2}
  /* 꺼진 부서: the departments with nothing up and no row in the list, behind one fold at its end
     (and found by the search). Each says the talk 켜기 brings back. No motion. */
  .pj-on{flex:none;height:26px;padding:0 12px;border-radius:999px;font-size:12px;font-weight:600;line-height:26px;white-space:nowrap;color:var(--t1);background:var(--btn);transition:background-color .14s ease}
  .pj-on:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  .pj-on[disabled],.pj-on[aria-disabled="true"]{color:var(--t3);cursor:default}
  .pj-card .pj-on{display:inline-block;color:var(--t1)}
  .pj-card .pj-on[aria-disabled="true"]{color:var(--t3)}
  @media(hover:hover){.pj-on:not([disabled]):hover{background:var(--btn-hi)}}
  @media(pointer:coarse){.pj-on{position:relative;height:40px;padding:0 16px;font-size:14px;line-height:40px}.pj-on::after{content:"";position:absolute;inset:-2px 0}}
  /* What 켜기 offers: the talks a department had, then 새로 시작. A menu beside the button, the
     bottom sheet on a phone; the same lines are the second step of 찾아서 켜기. */
  .pj-onp button[aria-current="true"]{background:var(--btn)}
  body .pj-pop.pj-onp{width:auto;min-width:184px;max-width:min(300px,calc(100vw - 16px))}
  body .pj-pop.pj-onp button.two{white-space:normal;min-width:0} .pj-onp button.two span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
  .pj-onp small{font-size:12px;color:var(--t3)}
  #sheet .pj-onp{display:flex;flex-direction:column;gap:4px}
  #sheet .pj-onp .h{font-size:16px;font-weight:700;margin:0 44px 8px 4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #sheet .pj-onp button[data-i],#sheet .pj-onp button[data-a],#sheet .pj-fo button[data-fd]{display:flex;align-items:center;gap:8px;width:100%;min-width:0;min-height:52px;padding:8px 12px;border-radius:12px;text-align:left;font-size:16px;color:var(--t1)}
  #sheet .pj-onp button.two{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px}
  #sheet .pj-onp button svg{flex:none;width:18px;height:18px;fill:currentColor;color:var(--t3)}
  #sheet .pj-onp small{font-size:13px}
  #sheet .pj-onp hr{width:100%;border:0;border-top:1px solid var(--line);margin:4px 0}
  #sheet .pj-onp button:focus-visible,#sheet .pj-fo button:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  @media(hover:hover){#sheet .pj-onp button[data-i]:hover,#sheet .pj-onp button[data-a]:hover,#sheet .pj-fo button[data-fd]:hover{background:var(--btn)}}
  /* 찾아서 켜기: one title, the search field, the departments. */
  .pj-fo{display:flex;flex-direction:column;gap:8px;min-width:0}
  /* 말로 만들기: a line, then the card it became, then what was made. One sheet, changed in place. */
  .pj-tm{display:flex;flex-direction:column;min-width:0}
  .pj-tm h3{margin-right:44px}
  .pj-tm .pj-ta2{margin-top:8px;min-height:68px;font-size:16px;resize:none}
  .pj-tm .hint{margin:2px 0 0}
  .pj-tmr{display:flex;align-items:center;gap:8px;margin-top:16px}
  .pj-tmr .sp{flex:1}
  .pj-tmr .pj-text{margin-left:-12px}
  .pj-tmr .pj-btn{min-width:76px;justify-content:center;gap:6px}
  .pj-tmr .pj-btn svg.lu{color:inherit}
  .pj-tm .lbl{margin-top:12px}
  .pj-tm .tin{margin-top:4px;width:100%}
  .pj-tm .tm-nm{display:grid;grid-template-columns:44px minmax(0,1fr);gap:8px;margin-top:4px}
  .pj-tm .tm-nm .tin{margin-top:0}
  .pj-tm .tm-em{display:grid;place-items:center;border-radius:8px;background:var(--btn);font-size:20px;line-height:1;cursor:pointer}
  .pj-tm .tm-em[aria-expanded="true"]{box-shadow:0 0 0 1.5px var(--focus-line)}
  .pj-tm .tm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(36px,1fr));gap:2px;max-height:156px;margin-top:8px;padding:4px;border-radius:8px;background:var(--btn);overflow-y:auto;overscroll-behavior:contain}
  .pj-tm .tm-grid[hidden]{display:none}
  .pj-tm .tm-grid button{height:36px;border-radius:6px;font-size:20px;line-height:1;display:grid;place-items:center}
  @media (hover:hover){.pj-tm .tm-grid button:hover,.pj-tm .tm-gs button:hover{background:var(--card-hi)}}
  .pj-tm .tm-gs{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
  .pj-tm .tm-gs:empty,.tm-gs:not(.on){display:none}
  .pj-tm .tm-gs button{height:28px;padding:0 10px;border-radius:14px;background:var(--btn);font-size:13px;color:var(--t2)}
  .pj-tm [data-par] .lbl{margin-top:8px}
  .pj-tm .tm-par{display:flex;align-items:center;gap:8px;margin-top:4px}
  .pj-tm .tm-par .tin{flex:1;min-width:0;margin-top:0}
  .pj-tm button.tm-at{width:100%;padding:4px 0;color:inherit;font:inherit;text-align:left;cursor:pointer}
  .pj-tm button.tm-at svg:last-child{margin-left:auto;opacity:.7}
  .pj-tm [data-pv]{min-height:20px;margin-top:8px;font-size:13px;line-height:1.5;color:var(--t3)}
  .pj-tm .tm-at{display:flex;align-items:center;gap:6px;min-width:0}
  .pj-tm .tm-at svg{flex:none;width:14px;height:14px;fill:currentColor}
  .pj-tm .tm-at span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
  .pj-tm .tm-done{display:flex;flex-direction:column;align-items:center;gap:4px;padding:16px 0 4px;text-align:center}
  .pj-tm .tm-done .e{font-size:40px;line-height:1.1}
  .pj-tm .tm-done b{max-width:100%;font-size:16px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-tm .tm-done span{font-size:14px;color:var(--t3)}
  .pj-fo h3{margin-right:44px}
  .pj-fo .rows{display:flex;flex-direction:column;gap:2px;max-height:min(52vh,420px);overflow-y:auto;margin:0 -4px;padding:0 4px}
  .pj-fo button[data-fd] .ox{flex:1;min-width:0;display:flex;flex-direction:column;line-height:1.35}
  .pj-fo button[data-fd] .nm{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-fo button[data-fd] .bk{font-size:13px;color:var(--t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-fo button[data-fd] .oe{flex:none;width:24px;display:grid;place-items:center}
  .pj-fo .pj-fob{align-self:flex-start;display:inline-flex;align-items:center;gap:4px;height:40px;padding:0 12px 0 4px;margin:-6px 0 0 -4px;border-radius:8px;color:var(--t2);font-size:15px;font-weight:600}
  .pj-fo .pj-fob svg{width:18px;height:18px;fill:currentColor;transform:rotate(180deg)}
  @media(prefers-reduced-motion:reduce){.pj-on{transition:none}}
  /* 세션: 오늘 / 어제 / 이전, said once each. */
  .pj-sdv{margin-top:16px;padding:0 8px 4px;font-size:12px;font-weight:600;line-height:18px;color:var(--t3)}
  /* 검토 대기 (.rv): one small dot inside the time, before it, as the official apps mark a conversation; the row never moves for it. */
  .pj-srow.rv .sr-w::before{content:"";display:inline-block;width:6px;height:6px;margin:0 4px 1px 0;border-radius:50%;background:var(--sr-rv);vertical-align:middle}
  .pj-srows .pj-fold{padding:8px 12px 6px 42px}
  .pj-srows .pj-oldb,.pj-srows .pj-tidb{margin-top:8px;padding:12px 12px;border-top:1px solid var(--line);font-size:13px}
  .pj-srows .pj-oldb+.pj-tidb,.pj-srows .pj-tidb+.pj-oldb{margin-top:0;border-top:0;padding-top:0}
  .pj-apart .pj-sgl,.pj-olds .pj-sgl{padding:8px;color:var(--t3);font-weight:600;font-size:12px}
  .pj-srows>.pj-empty{padding:28px 12px;text-align:center}
  @media(prefers-reduced-motion:reduce){.pj-srow,.pj-sgh,.pj-sgh .cv{transition:none}}
  /* Each session is its own block: a surface with a hairline and a lit top edge, the state orb
     before the title, and the orb's light bleeding faintly into the block (one still gradient,
     nothing animates). Colour is kept for two states: a quiet amber for 내 차례 and a muted red
     for 막힘; the rest is the text ink. Ended and long-unused sessions recede to a hairline. */
  :root{--sr-rv:#8ea2f0;--sr-work:#55d2ac;--sr-gw:85,210,172;--sr-ink:#efe9dc;--sr-turn:#e2b45c;--sr-stuck:#c46c6c;--sr-g:239,233,220;--sr-gt:226,180,92;--sr-gs:196,108,108;--sr-ga:1;
    --sr-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 9%,transparent),inset 0 1px 0 color-mix(in srgb,var(--t1) 6%,transparent);
    --sr-edge-on:inset 0 0 0 1px color-mix(in srgb,var(--t1) 24%,transparent);--sr-lift:0 1px 2px rgba(0,0,0,.4)}
  html[data-theme="light"]{--sr-rv:#4a63c9;--sr-work:#086b50;--sr-gw:16,150,112;--sr-ink:#3c4250;--sr-turn:#a36a10;--sr-stuck:#b4545c;--sr-g:60,66,80;--sr-gt:214,150,40;--sr-gs:200,90,98;--sr-ga:.75;
    --sr-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 11%,transparent);--sr-edge-on:inset 0 0 0 1px color-mix(in srgb,var(--t1) 34%,transparent);
    --sr-lift:0 1px 2px rgba(15,23,42,.07)}
  .pj-srows{--ts:36px}
  .pj-srows.sm{--ts:24px}
  .pj-srows .pj-srow{height:60px;gap:12px;padding:0 12px 0 12px;margin-top:6px;background:var(--card);box-shadow:var(--sr-edge),var(--sr-lift);
    overflow:hidden;isolation:isolate;--orb-ink:var(--sr-ink)}
  .pj-srows.sm .pj-srow{height:40px;gap:8px;padding:0 12px 0 8px;margin-top:4px}
  @media(hover:hover){.pj-srows .pj-srow:hover{background:var(--card-hi)}}
  .pj-srows .pj-srow.on{background:var(--btn);box-shadow:var(--sr-edge-on),var(--sr-lift)}
  .pj-srows .pj-srow.s-ended,.pj-srows .pj-srow.s-stale{background:none;box-shadow:inset 0 0 0 1px var(--line)}
  @media(hover:hover){.pj-srows .pj-srow.s-ended:hover,.pj-srows .pj-srow.s-stale:hover{background:var(--card)}}
  .pj-srows .pj-srow.s-ended.on,.pj-srows .pj-srow.s-stale.on{background:var(--btn);box-shadow:var(--sr-edge-on)}
  .pj-srows .pj-srow.s-turn{--orb-ink:var(--sr-turn);box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.26),var(--sr-lift)}
  .pj-srows .pj-srow.s-turn.on{box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.5),var(--sr-lift)}
  .pj-srows .pj-srow.s-stuck{--orb-ink:var(--sr-stuck)}
  /* 내 차례 is said by colour alone: the orb's tile and the line under the title. The row keeps its place. */
  .pj-srow .sr-ask{display:none}
  .pj-srow .sr-s{transition:color .2s ease}
  .pj-srows .pj-srow.s-turn .sr-s{color:var(--sr-turn)}
  @media(prefers-reduced-motion:reduce){.pj-srow .sr-s{transition:none}}
  .pj-srow::before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;
    background:radial-gradient(130px 80px at 28px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),calc(var(--a) * var(--sr-ga) * .35)) 45%,rgba(var(--g),0) 100%)}
  .pj-srows.sm .pj-srow::before{background:radial-gradient(90px 50px at 20px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),0) 100%)}
  .pj-srow.s-live{--g:var(--sr-g);--a:.085} .pj-srow.s-turn{--g:var(--sr-gt);--a:.2}
  .pj-srow.s-idle{--g:var(--sr-g);--a:.03} .pj-srow.s-stuck{--g:var(--sr-gs);--a:.15}
  .pj-srow.s-ended::before,.pj-srow.s-stale::before,.pj-srow.s-new::before{display:none}
  .pj-srow .sr-e{width:var(--ts);height:var(--ts)}
  .pj-srow .sr-o rl-orb{display:block}
  .pj-srow.s-idle .sr-o rl-orb{opacity:.62}
  .pj-srow.s-ended .sr-o rl-orb,.pj-srow.s-new .sr-o rl-orb{opacity:.42}
  .pj-srow .sr-o>i{width:5px;height:5px;border-radius:50%;background:var(--t4)}
  .pj-srows.sm .sr-o>i{width:4px;height:4px}
  /* The compact list's state mark for working / 내 차례 / stuck: a still dot in the state's colour, no motion. */
  .pj-srows.sm .sr-o>i.st-dot{width:8px;height:8px;background:var(--sr-work)}
  .pj-srows.sm .pj-srow.s-turn .sr-o>i.st-dot{background:var(--sr-turn)}
  .pj-srows.sm .pj-srow.s-stuck .sr-o>i.st-dot{background:var(--sr-stuck)}
  .pj-srows.sm .pj-srow.s-turn::after{display:none}
  /* The tool the session was opened in: a dot in its colour (and its name, in the two-line view). */
  .pj-srow .agd{margin:0 6px 0 1px}
  .pj-srow.mut .agd,.pj-srow.s-ended .agd,.pj-srow.s-stale .agd{opacity:.6}
  .pj-srow .sr-ad{display:none}
  .pj-srows.sm .sr-ad{display:inline-block;margin:0 1px}
  .pj-srows.sm .sr-ask{order:1}
  .pj-srows .pj-fold{padding-left:59px}
  .pj-srows.sm .pj-fold{padding-left:42px}
  @media(hover:hover) and (pointer:fine){.pj-srows .pj-srow .sr-m,.pj-srows.sm .pj-srow .sr-m{top:calc(50% - 14px)}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows .pj-srow{padding-right:4px}.pj-srows.sm .pj-srow{height:44px}}
  /* 작게: one line a row and no card, as a sidebar. The state is the small orb, the
     row's ground only says pointed-at or open; names line up under their group's name. */
  .pj-srows.sm{--ts:16px}
  .pj-srows.sm .pj-srow{height:32px;gap:8px;padding:0 8px;margin-top:2px;border-radius:8px}
  .pj-srows.sm .pj-srow,.pj-srows.sm .pj-srow.s-ended,.pj-srows.sm .pj-srow.s-stale,.pj-srows.sm .pj-srow.s-turn{background:none;box-shadow:none}
  @media(hover:hover){.pj-srows.sm .pj-srow:hover,.pj-srows.sm .pj-srow.s-ended:hover,.pj-srows.sm .pj-srow.s-stale:hover{background:color-mix(in srgb,var(--t1) 6%,transparent)}}
  .pj-srows.sm .pj-srow.on,.pj-srows.sm .pj-srow.s-ended.on,.pj-srows.sm .pj-srow.s-stale.on,.pj-srows.sm .pj-srow.s-turn.on{background:color-mix(in srgb,var(--t1) 11%,transparent);box-shadow:none}
  .pj-srows.sm .pj-srow::before{display:none}
  /* On screen in a split pane (.vis, set by splitMarks): the row's ground is lifted a little and a
     short tick stands at its left edge, in the colour of the focused pane's ring; both sit under
     whatever the row's state draws (the ring, the glow, the sweep). The focused pane's row is .on,
     as ever, and its tick is full. The tick is a ground layer: ::before and ::after are the state's. */
  .pj-srows .pj-srow.vis:not(.on){background-color:color-mix(in srgb,var(--btn) 75%,var(--card))}
  .pj-srows.sm .pj-srow.vis:not(.on){background-color:color-mix(in srgb,var(--t1) 7.5%,transparent)}
  @media(hover:hover){.pj-srows .pj-srow.vis:not(.on):hover{background-color:var(--btn)}
    .pj-srows.sm .pj-srow.vis:not(.on):hover{background-color:color-mix(in srgb,var(--t1) 9.5%,transparent)}}
  .pj-srow.vis{--vis-c:color-mix(in srgb,var(--blue) 72%,transparent)} .pj-srow.vis.on{--vis-c:var(--blue)}
  .pj-cols .pj-rail .pj-srows .pj-srow.vis{background-image:linear-gradient(var(--vis-c),var(--vis-c));background-repeat:no-repeat;background-size:3px 20px;background-position:5px 50%}
  .pj-cols .pj-rail .pj-srows .pj-srow.vis.on{background-size:3px 28px}
  .pj-cols .pj-rail .pj-srows.sm .pj-srow.vis{background-size:3px 14px;background-position:3px 50%}
  .pj-cols .pj-rail .pj-srows.sm .pj-srow.vis.on{background-size:3px 20px}
  /* Its row is folded away under the project's name: the name carries a small dot. */
  .pj-sgl.vis .pj-sgh .sp::before{content:"";display:block;width:6px;height:6px;margin:0 0 0 2px;border-radius:50%;background:color-mix(in srgb,var(--blue) 70%,transparent)}
  .pj-srows.sm .pj-srow .sr-x{flex-direction:row;align-items:center;gap:8px}
  .pj-srows.sm .pj-sgl~.pj-srow{padding-left:16px}
  .pj-srows.sm .sr-1{display:contents}
  .pj-srows.sm .sr-t{font-size:13px;font-weight:500;line-height:20px;letter-spacing:0}
  .pj-srows.sm .pj-srow.on .sr-t,.pj-srows.sm .pj-srow.s-turn .sr-t{font-weight:600}
  .pj-srows.sm .pj-srow.s-turn .sr-w{color:var(--sr-turn)}
  /* A reply not read yet: a dot in the row's own left padding, so nothing in the row moves for it. */
  .pj-srows .pj-srow.s-turn::after{content:"";position:absolute;left:3px;top:calc(50% - 3px);width:6px;height:6px;border-radius:50%;background:var(--blue);pointer-events:none}
  .pj-srows.sm .pj-srow.s-turn::after{left:1.5px;top:calc(50% - 2.5px);width:5px;height:5px}
  .pj-srows.sm .pj-sgl~.pj-srow.s-turn::after{left:6px}
  /* Picking several: each row's mark takes the dot's place and a picked row is tinted. The bar
     stands where the list's head was, as tall as it, and fades in where it is. */
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr])::after{content:none}
  /* The mark takes the state glyph's own slot (it is faded out), so nothing moves when picking starts. */
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e{position:relative}
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e>*{opacity:0}
  .pj-rail.picking .pj-srows .pj-srow:is([data-sid],[data-dr]) .sr-e::after{content:"";position:absolute;left:50%;top:50%;width:18px;height:18px;margin:-9px 0 0 -9px;box-sizing:border-box;border:1.5px solid var(--t3);border-radius:50%;transition:background-color .14s ease,border-color .14s ease}
  .pj-rail.picking .pj-srows.sm .pj-srow:is([data-sid],[data-dr]) .sr-e::after{width:16px;height:16px;margin:-8px 0 0 -8px}
  .pj-rail.picking .pj-srows .pj-srow.pk .sr-e::after{border-color:var(--blue);background:var(--blue) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M2.8 6.3l2.2 2.2 4.2-4.8' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/12px no-repeat}
  .pj-rail.picking .pj-srows .pj-srow.pk,.pj-rail.picking .pj-srows.sm .pj-srow.pk{background:color-mix(in srgb,var(--blue) 13%,transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 42%,transparent)}
  .pj-rail.picking .pj-srow{user-select:none;-webkit-user-select:none}
  /* The bar stays at the top of what scrolls (the list; on a page that scrolls, under the top bar) so
     a long list never carries it away; a fade under it covers the gap it leaves. */
  .pj-lhd.pj-pick{position:sticky;top:var(--pk-top,0);z-index:4;background:var(--bg)}
  .pj:has(>.pj-cols .pj-pick){overflow-x:clip}   /* the page's own side clip made it a scroller that never scrolls: nothing could stick in it */
  .pj-lhd.pj-pick::after{content:"";position:absolute;left:0;right:0;top:100%;height:12px;pointer-events:none;background:linear-gradient(var(--bg),transparent)}
  .pj-lhd.pj-pick{flex-wrap:nowrap;gap:2px;min-height:34px}   /* one line at every width: the list header may wrap, this bar must not */
  .pj-lhd.pj-pick.new{animation:pj-pkf .18s ease both}
  /* A phone's picking bar (pickMarks): fixed above the tabs, where the thumb is; it fades in where it stands.
     The list keeps room under its last row so the bar never covers it. */
  .pj-pkd{position:fixed;left:12px;right:12px;bottom:calc(74px + env(safe-area-inset-bottom));z-index:10;container-type:inline-size}
  .pj-pkd .pj-lhd.pj-pick{position:static;padding:4px 4px 4px 2px;border-radius:16px;background:var(--panel);box-shadow:0 0 0 1px var(--line),0 10px 28px rgba(0,0,0,.3)}
  .pj-pkd .pj-lhd.pj-pick::after{content:none}
  .pj-rail.pkdock .pj-srows{padding-bottom:calc(76px + env(safe-area-inset-bottom))}
  @keyframes pj-pkf{from{opacity:0}}
  .pj-lhd.pj-pick b{display:block;visibility:visible;flex:1;min-width:0;margin:0 8px 0 4px;font-size:14px;font-weight:600;letter-spacing:0;line-height:30px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pj-pb .pj-pl{display:none;font-size:13px;font-weight:600;line-height:1}
  .pj-pb.lb{display:inline-flex;align-items:center;justify-content:center;gap:6px}
  @container (min-width:372px){.pj-pb.lb{width:auto;padding:0 8px;gap:4px}.pj-pb.lb .pj-pl{display:inline}}
  /* The two that act on the picked rows say what they do at every width: as icons alone nobody found them. */
  .pj-pb.tx{width:auto;padding:0 6px}.pj-pb.tx .pj-pl{display:inline}
  @container (max-width:371px){.pj-pb.tx svg{display:none}}
  /* The way into picking several, in plain sight beside the list's head. */
  .pj-pkb{flex:none;height:32px;padding:0 8px;border-radius:8px;color:var(--t2);font-size:13px;font-weight:500;white-space:nowrap;transition:background-color .14s ease,color .14s ease}
  .pj-pkb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-pkb:hover{background:var(--btn);color:var(--t1)}}
  @media(pointer:coarse){.pj-pkb{height:44px;padding:0 12px;font-size:15px}}
  @media(prefers-reduced-motion:reduce){.pj-pkb{transition:none}}
  .pj-pb.dz:not([aria-disabled]){color:var(--red)}
  @media(hover:hover){.pj-pb.dz:not([aria-disabled]):hover{background:color-mix(in srgb,var(--red) 14%,transparent)}}
  .pj-pb{flex:none;display:grid;place-items:center;width:30px;height:30px;border-radius:8px;color:var(--t2);transition:background-color .14s ease}
  .pj-pb svg{width:16px;height:16px;fill:currentColor}
  .pj-pb[aria-disabled="true"]{color:var(--t4);cursor:default}
  .pj-pb.dz:not([aria-disabled]){color:var(--red)}
  .pj-pb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-pb:not([aria-disabled]):hover{background:var(--btn)}}
  @media(pointer:coarse){.pj-lhd.pj-pick{min-height:40px}.pj-pb{width:40px;height:40px}.pj-pb svg{width:18px;height:18px}.pj-pb{position:relative}.pj-pb::after{content:"";position:absolute;inset:-2px 0}}
  @media(prefers-reduced-motion:reduce){.pj-pb{transition:none}}
  /* The list's head stays where it is while the rows scroll under it (the list, or the page on a phone:
     --lh-top is the page's top bar then). Opaque; the hairline under it shows only once rows have gone
     beneath (.scr). One 8px grid: 32px lines 4px apart, 8px to the first row. */
  .pj-lh{position:sticky;top:var(--lh-top,0);z-index:3;display:flex;flex-direction:column;gap:4px;padding:4px 0 8px;background:var(--lh-bg,var(--bg));box-shadow:0 1px 0 transparent;transition:box-shadow .16s ease}
  .pj-rail.scr .pj-lh{box-shadow:0 1px 0 var(--line)}
  .pj:has(>.pj-cols .pj-lh){overflow-x:clip}   /* as for the picking bar: a page that clips sideways by scrolling lets nothing stick */
  .pj-rail .pj-lh>*{margin:0}
  .pj-lh+.pj-srows{margin-top:0}
  .pj-lh .pj-lhd.pj-pick::after{content:none}
  .pj-lh .pj-lhd.pj-pick{background:none}
  .pj-lsr{display:flex;align-items:center;gap:4px;min-width:0}
  .pj-mrb{position:relative;flex:none;display:grid;place-items:center;width:32px;height:32px;border-radius:8px;color:var(--t3);transition:background-color .14s ease,color .14s ease}
  .pj-mrb svg{width:16px;height:16px;fill:currentColor}
  .pj-mrb[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-mrb.fx::after{content:"";position:absolute;right:5px;top:5px;width:6px;height:6px;border-radius:50%;background:var(--blue)}
  .pj-mrb:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-mrb:hover{background:var(--btn);color:var(--t1)}}
  /* What 더보기 folds: how the list looks as plain icon buttons, then Claude | Codex. */
  .pj-lmo{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px;min-width:0}
  .pj-lmo[hidden]{display:none}
  .pj-lmo .pj-tgs{gap:8px}
  .pj-lmo .pj-tg{padding:0;gap:2px;border-radius:8px;background:none}
  .pj-lmo .pj-tg button{width:32px;height:32px;border-radius:8px}
  .pj-lmo .pj-tg button.on{background:var(--btn)}
  .pj-lmo .pj-agf{margin:0}
  .pj-lmo .pj-agf button{position:relative;height:28px}
  .pj-lmo .pj-agf button::after{content:"";position:absolute;inset:-2px 0}
  /* With a mouse 새 세션 is a quiet row of the list's own shape, its caret at the row's end (a phone keeps
     the pill in the thumb's corner). */
  .pj-rail .pj-lsr .pj-sq{flex:1;min-width:0;width:auto;height:32px;min-height:32px;font-size:13px;border-radius:8px}
  .pj-rail .pj-lh .pj-lhd:not(.ph){flex-wrap:nowrap;justify-content:flex-start}
  .pj-rail .pj-lsr~.pj-lhd.pj-pick{min-height:32px}
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){
    .pj-cols:not(.no-rail)>.pj-rail>.pj-lh{margin-top:-4px}   /* over the column's own 4px, so nothing shows above it once it sticks */
    .pj-rail .pj-lh .pj-sfil{padding:2px;border-radius:8px}
  }
  html .pj-lh .pj-lhd .pj-newg{flex:1;min-width:0;border-radius:8px;background:none;color:var(--t1);transform:none;outline-offset:-2px}
  html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn{height:32px}
  .pj-lh .pj-lhd .pj-newb{flex:1;min-width:0;justify-content:flex-start;padding:0 8px;gap:8px;border-radius:8px;font-size:13px;font-weight:500}
  .pj-lh .pj-lhd .pj-newb svg{width:16px;height:16px;color:var(--t3)}
  .pj-lh .pj-lhd .pj-newc{width:32px;padding:0;border-radius:8px;color:var(--t3)}
  .pj-lh .pj-lhd .pj-newc::before{content:none}
  html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn:is(:active,:focus-visible,[aria-expanded="true"]){background:color-mix(in srgb,var(--t1) 10%,transparent)}
  @media(hover:hover){html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn:hover{background:color-mix(in srgb,var(--t1) 6%,transparent)}}
  @media(pointer:coarse),(max-width:720px){
    .pj-lh{gap:8px}
    .pj-mrb,.pj-lmo .pj-tg button{width:40px;height:40px}
    .pj-lhd.ph .pj-mrb{width:44px;height:44px}   /* beside the phone search field, its height */
    .pj-rail .pj-lsr .pj-sq,html .pj-rail .pj-lh .pj-lhd .pj-newg .pj-btn{height:40px;min-height:40px}
    .pj-lh .pj-lhd .pj-newc{width:40px}
    .pj-rail .pj-lsr~.pj-lhd.pj-pick{min-height:40px}
    .pj-lmo .pj-agf button{height:36px}
  }
  @media(prefers-reduced-motion:reduce){.pj-lh,.pj-mrb{transition:none}}
  .pj-dlg .pj-dsub{margin:0 0 4px;font-size:13px;line-height:1.5;color:var(--t3)}
  /* Flat list: the session's name, then what was said in the room left over. The excerpt gives
     way first; the name is only cut once the excerpt is gone. */
  .pj-srows.sm .sr-t.nm{flex:0 1 auto;font-weight:600}
  .pj-srows.sm .sr-q{flex:1 1 0;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;line-height:20px;color:var(--t3)}
  .pj-srows.sm .sr-2{order:1;flex:none;height:auto} .pj-srows.sm .sr-s,.pj-srows.sm .sr-ask{display:none}
  .pj-srows.sm .sr-w{order:2;min-width:0;font-size:11.5px;line-height:18px}
  .pj-srows.sm .sr-ad{display:inline-block;margin:0 1px;width:5px;height:5px}
  .pj-srows.sm .sr-1 .pj-pinmk{margin:0;order:1} .pj-srows.sm .sr-1 .pj-pinmk svg{width:11px;height:11px}
  .pj-srows.sm .sr-1 .pj-face{margin-right:-2px}
  .pj-srows.sm .pj-srow .sr-e .pj-em{width:16px;height:16px;font-size:13px;border-radius:6px;background:none}
  .pj-srows.sm .pj-srow .sr-e .pj-em .phi{width:16px;height:16px}
  .pj-srows.sm .sr-o>i{width:5px;height:5px}
  .pj-srows.sm .pj-srow .sr-m,.pj-srows.sm .pj-sgl .sr-m{width:24px;height:24px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-srow .sr-m{top:calc(50% - 12px);right:4px}
    .pj-srows.sm .pj-srow:hover .sr-m~.sr-x .sr-2,.pj-srows.sm .pj-srow:focus-within .sr-m~.sr-x .sr-2,.pj-srows.sm .pj-srow:hover .sr-m~.sr-x .pj-pinmk,.pj-srows.sm .pj-srow:focus-within .sr-m~.sr-x .pj-pinmk{opacity:0}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-srow{height:40px;padding-right:0}
    .pj-srows.sm .pj-srow .sr-m,.pj-srows.sm .pj-sgl .sr-m{width:40px;height:40px}}
  .pj-srows.sm .pj-sgrp{margin-top:8px}
  .pj-srows.sm .pj-sgl{padding:0 4px 0 8px}
  .pj-srows.sm .pj-sgh{height:28px;gap:8px;padding:0 4px 0 8px;font-size:12px;font-weight:600;color:var(--t3);border-radius:8px}
  .pj-srows.sm .pj-sgh .pj-em,.pj-srows.sm .pj-sgl .pj-em.tint{width:16px;height:16px;font-size:13px;border-radius:6px;background:none}
  .pj-srows.sm .pj-sgh .pj-em .phi{width:16px;height:16px}
  .pj-srows.sm .pj-sgh .n{margin-left:-2px;font-size:11.5px}
  @media(hover:hover) and (pointer:fine){.pj-srows.sm .pj-sgh[aria-expanded="true"] .cv{opacity:0;transition:opacity .12s ease}
    .pj-srows.sm .pj-sgl:hover .cv,.pj-srows.sm .pj-sgh:focus-visible .cv{opacity:1}}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows.sm .pj-sgh{height:36px}.pj-srows.sm .pj-sgl{padding-right:0}}
  .pj-srows.sm .pj-fold{padding:0 8px 0 40px;margin-top:0;height:24px;font-size:12px}
  .pj-srows.sm .pj-sdv{margin-top:8px}
  /* 크게: the two-line cards, with less air around them: closer cards, a lower group line. */
  .pj-srows:not(.sm) .pj-srow{height:56px;margin-top:4px}
  .pj-srows:not(.sm) .pj-sgrp{margin-top:8px}
  .pj-srows:not(.sm) .pj-sgl{padding:0 4px 0 0}
  .pj-srows:not(.sm) .pj-sgh{height:32px}
  .pj-srows:not(.sm) .pj-fold{padding-top:4px;padding-bottom:4px;margin-top:0}
  @media(pointer:coarse){.pj-srows .pj-fold{min-height:40px}}
  /* the rows that close the list (older, hidden, same-name) start where the session rows do */
  .pj-srows>.pj-fold{padding-left:12px}
  .pj-srows.sm>.pj-fold{padding-left:8px}
  .pj-srows:not(.sm) .sr-q{display:none}
  .pj-srow .sr-st{color:var(--sr-work);font-weight:600}
  /* One line a row in both sizes: the name, then one word for how it is doing, the tool it runs
     in, when. 크게 is a low card, 작게 a sidebar line. A narrow list keeps the tool's dot only. */
  .pj-srows{container-type:inline-size}
  .pj-srows .pj-srow .sr-x{flex-direction:row;align-items:center;gap:8px}
  .pj-srows .pj-srow .sr-1{display:contents}
  .pj-srows .pj-srow .sr-2{order:1;flex:none;height:auto;gap:8px}
  .pj-srows .pj-srow .sr-w{order:2;min-width:0;font-size:11.5px;line-height:18px}
  .pj-srows .pj-srow .sr-s{display:block;flex:none;font-size:12px}
  .pj-srows .pj-srow .sr-s:empty{display:none}
  .pj-srow .sr-ag{display:inline-flex;align-items:center;font-size:11.5px;line-height:18px;color:var(--t3)}
  .pj-srow .sr-ag .agd{margin:0 4px 0 0}
  .pj-srows.sm .sr-ag{font-size:0}
  .pj-srows.sm .sr-ag .agd{margin:0}
  @container (max-width:300px){.pj-srow .sr-ag{font-size:0}.pj-srow .sr-ag .agd{margin:0}}
  .pj-srows:not(.sm){--ts:24px}
  .pj-srows:not(.sm) .pj-srow{height:44px;gap:10px;margin-top:4px}
  .pj-srows:not(.sm) .sr-t{font-size:14px}
  @media not ((hover:hover) and (pointer:fine)){.pj-srows:not(.sm) .pj-srow{height:48px}}
  /* 작업 중: the working hue on the orb, and one slow light travelling along the row's top edge.
     Only its transform animates (its own layer: nothing is laid out or repainted around it). */
  .pj-srows .pj-srow.s-live{--orb-ink:var(--sr-work);overflow:hidden}
  .pj-srows .pj-srow.s-live::after{content:"";position:absolute;left:0;top:0;width:42%;height:1px;pointer-events:none;will-change:transform;
    background:linear-gradient(90deg,rgba(var(--sr-gw),0),rgba(var(--sr-gw),.85) 50%,rgba(var(--sr-gw),0));
    transform:translateX(-100%);animation:pj-sheen 5.2s linear infinite}
  html[data-theme="light"] .pj-srows .pj-srow.s-live::after{height:2px}
  @keyframes pj-sheen{to{transform:translateX(240%)}}
  @media(prefers-reduced-motion:reduce){.pj-srows .pj-srow.s-live::after{animation:none;transform:none;width:60%;
    background:linear-gradient(90deg,rgba(var(--sr-gw),.6),rgba(var(--sr-gw),0))}}
  .pj-olds>.pj-card{opacity:.72}
  /* The chat's own head when the list is beside it: the conversation's name and one line under it. */
  .pj-nth{flex:none;display:flex;align-items:center;gap:8px;padding:16px 12px 12px 16px;border-bottom:1px solid var(--line)}
  .pj-nth .tx{flex:1;min-width:0}
  .pj-nth .t{font-size:16px;font-weight:600;letter-spacing:-.01em;line-height:1.35;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-nth .s{margin-top:2px;font-size:12px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-nth .pj-more{margin:0}
  .pj-nth [data-list]{margin-left:-8px}
  .pj-nth [data-list] svg{width:18px;height:18px}
  .pj-listonly>.pj-body{display:none}
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.pj-nth{padding:8px 8px 8px 16px}.pj-nth .t{font-size:16px}
    .pj-nth~.pj-wrap .pj-msgs{padding:16px}
    /* A phone's open chat is the whole screen (body.pjchat, phoneChat()): the name on top, the log
       taking what is left, the message box on the bottom edge. Its height is the part of the
       screen that can be seen (--pj-vh/--pj-vt follow visualViewport), so the box sits right on
       the keyboard and the page under it has nothing to scroll. */
    body.pjchat{overflow:hidden}
    body.pjchat .tabbar,body.pjchat #m-goo,body.pjchat .pj-seg,body.pjchat:not(.inapp) #top{display:none}
    body.pjchat #view>.pj{animation:none;padding-bottom:0}
    body.pjchat .pj-conv{touch-action:pan-y;position:fixed;z-index:4;left:0;right:0;top:var(--pj-vt,0px);height:var(--pj-vh,100dvh);border-radius:0;background:var(--bg)}
    body.pjchat .pj-wrap{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
    body.pjchat .pj-msgs{flex:1 1 auto;height:auto;min-height:0}
    body.pjchat .pj-conv>.pj-in{padding-bottom:max(12px,env(safe-area-inset-bottom))}
    /* What a thumb presses is 44px: back, results, the picture button (send and the model chip already are). */
    body.pjchat .pj-nth{gap:4px;padding-top:calc(4px + env(safe-area-inset-top));padding-bottom:4px;padding-left:calc(6px + env(safe-area-inset-left));padding-right:calc(6px + env(safe-area-inset-right))}
    body.pjchat.inapp .pj-nth{padding-top:4px}
    body.pjchat .pj-nth [data-list],body.pjchat .pj-nth [data-res]{display:inline-flex;position:relative;width:44px;height:44px;margin:0;border-radius:50%;color:var(--t1)}
    body.pjchat .pj-nth [data-list] svg,body.pjchat .pj-nth [data-res] svg{width:22px;height:22px}
    body.pjchat .pj-nth [data-res] .pj-nb{position:absolute;top:4px;right:2px;margin:0}
    body.pjchat .pj-nth .tx{padding:4px 0}
    body.pjchat .pj-box .pj-clip{position:relative}
    body.pjchat .pj-box .pj-clip::after{content:"";position:absolute;inset:-6px}
    /* The keyboard leaves little room: the first-visit tip and the standing note give theirs to the log. */
    body.pjchat.pj-kb .pj-tip,body.pjchat.pj-kb .pj-note{display:none}
    body.pjchat.pj-kb .pj-note:has(.pj-q){display:block}   /* a question being answered is typed into the note itself */
    /* So does everything else that is not the conversation. The state line folds into the name's
       row as its mark alone (the words, the chips and the menu come back with the keyboard down),
       the name's row is exactly its 44px buttons, and the box is one line of text over its
       buttons with no room around it. Nothing moves in: the rows are simply not there. */
    body.pjchat.pj-kb .pj-nth{padding-top:env(safe-area-inset-top);padding-bottom:0;border-bottom:1px solid var(--line)}
    body.pjchat.pj-kb.inapp .pj-nth{padding-top:0}
    body.pjchat.pj-kb .pj-nth:has(+#pj-state) .tx{padding-right:16px}
    body.pjchat.pj-kb .pj-nth~#pj-state .pj-state{position:absolute;top:env(safe-area-inset-top);right:calc(50px + env(safe-area-inset-right));height:44px;padding:0;border:0;pointer-events:none}
    body.pjchat.pj-kb.inapp .pj-nth~#pj-state .pj-state{top:0}
    body.pjchat.pj-kb .pj-nth~#pj-state .pj-state>:not(:first-child),body.pjchat.pj-kb .pj-nth~#pj-state .pj-acts{display:none}
    body.pjchat.pj-kb .pj-nth~.pj-wrap .pj-msgs{padding-top:8px;padding-bottom:8px}
    body.pjchat.pj-kb .pj-conv>.pj-in{padding:2px 8px 4px}
    body.pjchat.pj-kb .pj-box{padding:6px 8px 6px 12px;gap:4px 6px}
    /* Over a keyboard on a short screen four lines pushed Send off the bottom (9px at 360, all of it at 300): the box takes
       what the screen has left after the title, one line of the chat and its own row, and scrolls inside that. */
    body.pjchat.pj-kb .pj-box #pj-ta{min-height:0;padding:2px 2px 4px;max-height:max(44px,calc(var(--pj-vh,100vh) - 222px))}}
  .pj-nth [data-res]{display:none}
  .pj-nth+.pj-state{display:none}
  /* An open session: its state row is the one line under the name (state · project · agent).
     The standing "goes straight through" note and the first-visit tip are not repeated here. */
  .pj-nth:has(+#pj-state){border-bottom:0;padding-bottom:0}
  .pj-stx{display:none;min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-nth~#pj-state .pj-stx{display:inline}
  .pj-nth.pn~#pj-state .pj-stp{display:none}   /* the title above already is the project's name */
  .pj-nth~#pj-state .pj-state{padding:2px 12px 8px 16px;font-size:12px;color:var(--t3);gap:6px}
  .pj-nth~#pj-state .pj-state .pj-more{margin:-8px 0}
  .pj-nth~#pj-tip{display:none}
  .pj-nth~#pj-note:not(:has(div:not(.nl))){display:none}
  /* Who receives the line is said by the pills under the text, not by a line above the box. */
  .pj-nth~.pj-to{display:none}
  .pj-nth~.pj-in,.pj-nth~.pj-to+.pj-in{border-top:0;padding:4px 16px 16px}
  .pj-pjn{display:none}
  .pj-nth~.pj-in .pj-pjn{display:inline-flex;align-items:center;gap:6px;flex:0 1 auto;min-width:0;height:32px;padding:0 12px;border:1px solid var(--line);
    border-radius:999px;font-size:13px;color:var(--t2);white-space:nowrap}
  .pj-pjn .pj-em{flex:none;font-size:13px;width:auto}
  .pj-pjn span:last-child{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-nth~.pj-in .pj-clip{width:32px;height:32px;margin-left:-2px;border:1px solid var(--line);border-radius:999px}
  .pj-nth~.pj-in .pj-clip svg{width:15px;height:15px}
  /* A session that is up keeps its actions in the menu beside its state; one that ended shows them. */
  .pj-nth~#pj-state:not(:has(.pj-stl.ended)) .pj-acts{display:none}
  .pj-nth~.pj-wrap .pj-msgs{padding:16px 20px;gap:16px}
  .pj-nth~.pj-wrap .pj-msg.user,.pj-nth~.pj-wrap .pj-msg.claude{font-size:17px;line-height:1.7}
  .pj-nth~.pj-wrap .pj-md :is(p,ul,ol){margin-bottom:16px}.pj-nth~.pj-wrap .pj-md li{margin:8px 0}
  .pj-nth~.pj-wrap .pj-md>:last-child{margin-bottom:0}
  .pj-nth~.pj-wrap .pj-msg.user{padding:8px 16px;border-radius:16px 16px 4px 16px}
  /* A window on a desk reads at the size of the rest of the app (13-15px); 16px is the phone's. */
  @media(min-width:1024px),(min-width:721px) and (pointer:fine){.pj-nth~.pj-wrap .pj-msg.user,.pj-nth~.pj-wrap .pj-msg.claude{font-size:14.5px;line-height:1.6}
    .pj-nth~.pj-wrap .pj-md :is(p,ul,ol){margin-bottom:12px}.pj-nth~.pj-wrap .pj-md li{margin:6px 0}.pj-nth~.pj-wrap .pj-md>:last-child{margin-bottom:0}
    .pj-nth~.pj-wrap .pj-msg.user{padding:8px 12px;border-radius:12px 12px 4px 12px}}
  /* The message box, two rows in one field: the text, and under it picture / model / send. */
  .pj-box{flex-wrap:wrap;align-items:center;gap:6px;padding:8px 12px 8px 16px;border-radius:16px}
  .pj-box:focus-within{border-color:color-mix(in srgb,var(--t1) 26%,transparent);box-shadow:none}
  .pj-box textarea{order:-1;flex:1 0 100%;padding:2px 2px 8px}
  .pj-box .pj-clip{margin-left:-6px}
  .pj-box .pj-go{border-radius:50%;margin-left:auto}
  .pj-enter{margin-left:auto;padding-right:6px;font-size:12px;color:var(--t4);white-space:nowrap}
  html[data-theme="light"] .pj-enter{color:var(--t3)}
  .pj-enter+.pj-go{margin-left:0}
  @media(max-width:899px){.pj-enter{display:none}.pj-enter+.pj-go{margin-left:auto}}
  .pj-mwrap{position:relative;display:inline-flex;min-width:0}
  .pj-mwrap:empty{display:none}
  /* How full the conversation is: a quiet number that only takes a colour when it matters. */
  .pj-ctx{flex:none;align-self:center;display:inline-flex;align-items:baseline;gap:4px;font-size:12px;line-height:18px;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap}
  .pj-ctx small{font-size:inherit;opacity:.8}
  .pj-ctx.hot{color:var(--orange)} html[data-theme="light"] .pj-ctx.hot{color:#b77400}
  .pj-gauge{flex:none;align-self:center;position:relative;display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:4px;border-radius:50%;color:var(--t3);cursor:pointer;transition:background-color .12s ease,color .12s ease}
  .pj-gauge::before{content:"";position:absolute;inset:-6px}
  @media(pointer:coarse){.pj-gauge::before{inset:-10px -6px}}
  .pj-gauge:hover,.pj-gauge[aria-expanded="true"]{background:var(--btn);color:var(--t1)}
  .pj-gauge svg{display:block;width:14px;height:14px;transform:rotate(-90deg)}
  .pj-gauge circle{fill:none;stroke-width:2.5;stroke:currentColor}
  .pj-gauge circle.tr{opacity:.28} .pj-gauge circle.ar{stroke-linecap:round}
  .pj-gauge.hot circle.ar{stroke:var(--orange)}
  .pj-upop{padding:14px 12px 12px;transition:opacity .14s ease-out;opacity:0}
  .pj-upop.on{opacity:1}
  .pj-upop h5{margin:0 6px 8px;font-size:12px;font-weight:600;line-height:16px;color:var(--t3)}
  .pj-upop .w{display:grid;grid-template-columns:auto 1fr auto;align-items:baseline;column-gap:8px;row-gap:6px;margin:0 6px;font-variant-numeric:tabular-nums}
  .pj-upop .w+.w{margin-top:12px}
  .pj-upop .w .k{font-size:13px;font-weight:600;line-height:18px;color:var(--t1)}
  .pj-upop .w .t{font-size:12px;line-height:18px;color:var(--t3);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-upop .w .v{font-size:12px;line-height:18px;color:var(--t2)}
  .pj-upop .w .bar{grid-column:1/-1;display:block;height:4px;border-radius:2px;background:var(--btn);overflow:hidden}
  .pj-upop .w .bar i{display:block;height:100%;border-radius:2px;background:var(--t2)}
  .pj-upop .w:first-child .bar i{background:var(--blue-t)}
  .pj-upop .w.hot .bar i,.pj-upop .w.hot:first-child .bar i{background:var(--orange)}
  .pj-upop .s{margin:8px 6px 0;font-size:12px;line-height:1.45;color:var(--t3)}
  .pj-upop hr{margin:12px 0}
  .pj-upop .go{display:inline-flex;align-items:center;height:28px;margin:12px 6px 0;padding:0 10px;border-radius:var(--r-md);background:var(--btn);font-size:12px;font-weight:600;color:var(--t1);cursor:pointer}
  .pj-upop .go:hover{background:var(--btn-hi)}
  @media(pointer:coarse){.pj-upop .go{position:relative}.pj-upop .go::after{content:"";position:absolute;inset:-8px -4px}}   /* 28px on a phone: the press area is 44 */
  /* A phone's row has no room for one more thing: the number takes the place of the chip's caret and dot. */
  .pj-box.pj-tight .pj-mwrap:has(.pj-gauge) .pj-mbtn :is(.cv,.sep){display:none}
  .pj-box .pj-agseg{flex:none}
  /* A new chat in a row under 440px has the Claude/Codex switch in it too: 54px are left for the chip, so it says the effort alone
     and the switch gives up 5px a side. The model's name is one press away, in the popover. */
  .pj-box.pj-slim:has(.pj-agseg) .pj-mbtn{padding:0 7px}
  .pj-box.pj-slim:has(.pj-agseg) .pj-mbtn :is(.sk,.mn,.sep,.cv){display:none}
  .pj-box.pj-slim:has(.pj-agseg) .pj-mbtn b{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-box.pj-slim .pj-agseg button{padding:0 7px}
  /* On a phone the switch is as tall as the chip beside it; the press area keeps its height. */
  @media(max-width:560px){.pj-box .pj-agseg button{position:relative;height:28px;padding:0 12px}.pj-box .pj-agseg button::after{content:"";position:absolute;inset:-8px 0}}
  /* The model chip: what this conversation runs on, and above it the popover that changes it.
     The popover grows out of the chip on a stepped spring (see open()); the chip only eases its hover. */
  .pj-mbtn{position:relative;display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px 0 8px;border:1px solid var(--line);
    border-radius:999px;color:var(--t2);font-size:13px;font-weight:500;white-space:nowrap;cursor:pointer;min-width:0;max-width:100%;transition:background-color .14s ease,transform .18s var(--ease)}
  .pj-mbtn:hover{background:var(--btn)}
  .pj-mbtn[aria-expanded="true"]{border-color:var(--blue);background:var(--btn)}
  .pj-mbtn .sk{flex:none;width:14px;height:14px;color:var(--t3)}
  .pj-mbtn .mn{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .pj-mbtn .sep{color:var(--t4)}
  .pj-mbtn b{color:var(--t1);font-weight:700}
  .pj-mbtn .dt{flex:none;width:7px;height:7px;border-radius:50%;background:var(--blue)}
  .pj-mbtn .dt.w{width:8px;height:8px;background:none;box-shadow:inset 0 0 0 1.5px var(--t1)}
  .pj-mbtn .cv{flex:none;width:11px;height:11px;transform:rotate(90deg);color:var(--t3)}
  .pj-feedback{margin:8px 12px;color:var(--t3);font-size:13px}.pj-feedback summary{cursor:pointer;min-height:44px;padding:12px 0}.pj-feedback-row{padding:12px 0;border-top:1px solid var(--line)}.pj-feedback-row p{white-space:pre-wrap;overflow-wrap:anywhere;margin:8px 0;color:var(--t2)}.pj-feedback-row button{font-size:13px;min-height:44px}
  @media(max-width:600px){.pj-feedback{margin:8px 16px}.pj-todo{padding:6px 16px 0}}   /* the phone's lines and its box start at 16px: these two rows with them */
  .pj-mpop{position:absolute;left:0;bottom:calc(100% + 8px);z-index:6;width:264px;box-sizing:border-box;padding:16px 12px 12px;border-radius:var(--menu-r);
    background:var(--menu-bg);border:1px solid var(--line);box-shadow:var(--menu-shadow);cursor:default;text-align:left;white-space:normal;overflow:auto}
  .pj-mpop .hd{display:flex;align-items:center;gap:8px;min-height:24px;margin:0 6px}
  .pj-mpop h4{flex:1;min-width:0;margin:0;font-size:15px;font-weight:600;line-height:1.3;color:var(--t1)}
  .pj-mpop .mx{display:none;flex:none;position:relative;width:28px;height:28px;margin:-2px 0;border-radius:50%;align-items:center;justify-content:center;color:var(--t2);background:var(--btn);cursor:pointer}
  .pj-mpop .mx::before{content:"";position:absolute;inset:-8px}
  .pj-mpop .mx .i{width:14px;height:14px}
  .pj-mpop p{margin:0 6px}
  .pj-mpop .wn{margin-top:4px;font-size:12px;line-height:1.45;color:var(--t3)}
  .pj-mpop .lb{display:flex;align-items:baseline;gap:6px;margin:12px 6px 6px;font-size:12px;font-weight:600;color:var(--t3)}
  .pj-mpop .lb small{font-size:12px;font-weight:500;color:var(--t4)}
  .pj-mrow{display:flex;align-items:center;gap:8px;width:100%;box-sizing:border-box;min-height:44px;padding:4px 6px;border-radius:var(--r-sm);text-align:left;cursor:pointer}
  .pj-mrow:hover{background:var(--btn)}
  .pj-mrow .ck{flex:none;display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:auto;color:var(--t1);opacity:0}
  .pj-mrow .ck .i{display:block;width:16px;height:16px;margin:0}
  .pj-mpop.off .pj-mrow,.pj-mpop.off .pj-mem,.pj-mpop.off .pj-meff,.pj-mrow[aria-disabled="true"]{opacity:.45;pointer-events:none}
  .pj-mrow[aria-checked="true"] .ck{opacity:1}
  .pj-mpop .lb b{margin-left:auto;font-weight:600;color:var(--t1)}
  .pj-mem.em{margin:0 6px;--em-fill:var(--blue);--em-knob:var(--on-blue,#fff)}
  .pj-meff[hidden]{display:none}
  .pj-mrow .tx{flex:1;min-width:0}
  .pj-mrow .nm{display:flex;align-items:center;flex-wrap:wrap;gap:2px 8px;font-size:14px;font-weight:600;line-height:1.3;color:var(--t1)}
  .pj-mrow .nm em{font-style:normal;font-size:12px;font-weight:600;line-height:16px;padding:0 6px;border-radius:999px;color:var(--t2);box-shadow:inset 0 0 0 1px var(--line);white-space:nowrap}
  .pj-mrow[aria-checked="true"] .nm em{color:var(--blue);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--blue) 45%,transparent)}
  .pj-mrow .ds{display:block;margin-top:1px;font-size:12px;line-height:1.35;color:var(--t3)}
  .pj-mpop .nt{margin-top:6px;font-size:11.5px;line-height:1.45;color:var(--t3)}
  .pj-meff{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:2px;padding:4px;border-radius:8px;background:var(--bg)}
  .pj-meff button{height:30px;min-width:0;border-radius:8px;font-size:12px;color:var(--t2);cursor:pointer}
  .pj-meff button:hover{color:var(--t1)}
  .pj-meff button[aria-checked="true"]{background:var(--btn-hi);color:var(--t1);font-weight:700}
  .pj-mpop .ed{margin-top:8px;min-height:17px;font-size:12px;line-height:1.4;color:var(--t2)}
  .pj-mpop hr{margin:12px 0 8px;border:0;border-top:1px solid var(--line)}
  .pj-box.pj-tight .pj-pjn,.pj-box.pj-tight .pj-enter{display:none}
  .pj-box.pj-tight .pj-enter+.pj-go{margin-left:auto}
  /* A narrow box keeps its controls on one line: the model chip gives way (its name ends in …) instead
     of the send button dropping alone to the next line, which it did in one pane of three and not the others. */
  .pj-box.pj-tight .pj-mwrap{flex:1 1 0}
  /* The mic is send's neighbour on the right: it takes the push where the Enter hint is not shown. */
  .pj-in .pj-box button.pj-mic{margin-left:0}
  .pj-in .pj-box .pj-mic+.pj-go{margin-left:0}
  @media(max-width:899px){.pj-in .pj-box button.pj-mic{margin-left:auto}}
  .pj-in .pj-box.pj-tight button.pj-mic{margin-left:auto}
  .pj-in .pj-box.pj-rec button:is(.pj-mic,.pj-vx){margin-left:0}
  @media (pointer:coarse),(max-width:720px){
    .pj-mbtn::before{content:"";position:absolute;inset:-6px 0}
    .pj-meff button{height:44px}
    .pj-mem .em-track{height:44px}
    .pj-mpop .mx{display:inline-flex}
  }
  @media(max-width:380px){.pj-meff button{font-size:11.5px}}
  html.pj3 .pj-conv.pj-draft{grid-column:2/-1}
  /* The line waiting for its session stays where the draft showed it: the same two columns, under the room the title took. */
  html.pj3 .pj-pendc{grid-column:2/-1;padding-top:58px}
  .pj-draft .pj-empty{margin:auto}
  .pj-pendc .pj-msgs{height:auto;min-height:0} .pj-pendc .pj-empty b{display:block;color:var(--t1)}
  .pj-draft .pj-empty b{display:block;color:var(--t1);font-size:16px;font-weight:600;margin-bottom:4px}
  .pj-anim{animation:pj-in .16s ease-out both}
  /* A page that is redrawn in place (a refresh, another session in the same view): nothing comes in again */
  #view.still .pj-anim{animation:none}
  /* Another conversation in the same column: its lines settle in, the frame around them never moves */
  .pj-msgs.pj-swap{animation:pj-swap .13s ease-out}
  @keyframes pj-swap{from{opacity:.6}}
  /* Lines still on their way: the shared loader (loading.js), in the middle of the chat */
  .pj-wait{margin:auto;padding:0;width:100%}
  @media(prefers-reduced-motion:reduce){.pj-msgs.pj-swap{animation:none}}
  @keyframes pj-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  @media(prefers-reduced-motion:reduce){.pj-anim{animation:pj-fade .2s ease both}
    @keyframes pj-fade{from{opacity:0}to{opacity:1}}}
  /* Phone pass over the conversation (mchat68). The chat is the screen: one header row, a message
     box that is one row until something is typed, and the model popover as a bottom sheet that
     fades where it is. Sizes: 44px to press, 13px to read. */
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    /* The state folds into the name's row: its mark, and the menu. The words and the project /
       agent line say what the name and the chip beside it already say. An ended session keeps its row (its actions). */
    body.pjchat .pj-nth:has(+#pj-state .pj-stl:not(.ended)){padding-right:calc(70px + env(safe-area-inset-right))}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)){height:0}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state{position:absolute;top:env(safe-area-inset-top);right:env(safe-area-inset-right);z-index:1;height:48px;padding:0;gap:0;border:0;pointer-events:none}
    body.pjchat.inapp .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state{top:0}
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>.pj-more{pointer-events:auto;margin:2px 4px 2px 6px!important;width:44px;height:44px;border-radius:50%}   /* over the button's inline margin: that pulled it past the edge and against the mark */
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>:is(.pj-stl,.pj-stx,.sp){position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
    /* Only the menu takes a press there: 변경 and 로그 were drawn over the header's own button and answered nothing.
       The chips (창 없음, 옮겨짐, 오프라인) go too: they widened the row over the results button; the list row keeps them. */
    body.pjchat .pj-nth+#pj-state:has(.pj-stl:not(.ended)) .pj-state>:is(.pj-chg,[data-bglog],.pj-bg,.off){display:none}
    body.pjchat .pj-in[data-off]::before{content:attr(data-off);display:block;padding:0 16px 6px;font-size:12px;line-height:16px;color:var(--orange)}
    body.pjchat.pj-kb .pj-nth{padding-right:calc(6px + env(safe-area-inset-right))}
    /* The log: no clock on every line, the last one keeps its time; the tool lines read at 13px. */
    body.pjchat .pj-msgs>.pj-msg .pj-tm{display:none}
    body.pjchat .pj-msgs>.pj-msg:last-child .pj-tm{display:block}
    body.pjchat .pj-msgs>.pj-msg.user:last-child>.pj-tm{display:block}
    .pj-msg.tool,.pj-tfold,.pj-msg .tg,.pj-day{font-size:13px}
    .pj-md code{font-size:14px}
    .pj-tfold{position:relative}.pj-tfold::after{content:"";position:absolute;inset:-10px -6px}
    .pj-msg .tg button{position:relative}.pj-msg .tg button::after{content:"";position:absolute;inset:-11px -4px}
    /* The picture waiting to go: its remove mark is a 44px press, the picture stays small. The mark
       stays where it is (absolute, in the corner): made relative here it dropped under the picture
       and the tile cut it off, so a picture on a phone had no way out. The press grows into the tile. */
    .pj-att .th button::after{content:"";position:absolute;inset:-2px -2px -22px -22px}
    .pj-att .th.doc button::after{inset:-12px}
    /* The message box: the words on their own row, the buttons under them. One shared row cut the words short. */
    body.pjchat .pj-conv>.pj-in,body.pjchat .pj-nth~.pj-in{padding:4px 10px max(10px,env(safe-area-inset-bottom))}
    body.pjchat .pj-box #pj-ta{font-size:16px}
    .pj-box.pj-rec .pj-wave{height:44px}
    /* The model chip: 44px to press, the same look. */
    .pj-mbtn{min-width:44px;height:44px;font-size:14px}.pj-mbtn::before{inset:-4px 0}
    .pj-box .pj-clip{width:44px;height:44px}
    .pj-nth~.pj-in .pj-clip{width:44px;height:44px;margin-left:-8px;border:0}
    .pj-nth~.pj-in .pj-clip svg{width:20px;height:20px}
    .pj-box .pj-agseg button{height:36px;font-size:14px}.pj-box .pj-agseg button::after{inset:-4px 0}
    /* The model popover is a bottom sheet: it fades in place, over a veil that closes it. It floats
       clear of the screen's edges with a grabber, close on the left of a centred title, and the
       models as one card of rows with a line between them. */
    .pj-mscrim{position:fixed;inset:0;z-index:79;background:rgba(0,0,0,.4)}
    .pj-mpop.sheet{display:block;position:fixed;left:8px!important;right:8px;top:auto!important;bottom:max(8px,env(safe-area-inset-bottom));width:auto!important;max-height:min(82vh,82dvh)!important;z-index:80;margin:0;
      padding:20px 12px 12px;border-radius:28px;overscroll-behavior:contain;transform:none!important}
    .pj-mpop.sheet::before{content:"";position:absolute;top:8px;left:50%;width:36px;height:4px;margin-left:-18px;border-radius:2px;background:var(--t4)}
    .pj-mpop.sheet .hd{position:relative;justify-content:center;min-height:44px;margin:0 0 8px}
    .pj-mpop.sheet h4{flex:none;max-width:calc(100% - 104px);font-size:16px;text-align:center}
    .pj-mpop.sheet .mx{position:absolute;left:0;top:0;width:44px;height:44px;margin:0;box-shadow:inset 0 0 0 1px var(--line)}.pj-mpop.sheet .mx .i{width:16px;height:16px}
    .pj-mpop.sheet :is([data-g="model"],[data-g="perm"]){padding:0 16px;border-radius:20px;background:var(--card)}
    .pj-mpop.sheet .pj-mrow{min-height:60px;padding:10px 0;border-radius:0}
    .pj-mpop.sheet .pj-mrow:hover{background:none}
    .pj-mpop.sheet .pj-mrow+.pj-mrow{border-top:1px solid var(--line)}
    .pj-mpop.sheet .wn{margin-bottom:8px;text-align:center}
    .pj-mpop.sheet .wn,.pj-mpop.sheet .lb,.pj-mpop.sheet .lb small,.pj-mpop.sheet .ed,.pj-mpop.sheet .us,.pj-mpop.sheet .pj-mrow .ds{font-size:13px}
    .pj-mpop.sheet .pj-mrow .nm{font-size:16px}.pj-mpop.sheet .pj-mrow .nm em{font-size:12px}
    .pj-mpop.sheet .nt{display:none}
    .pj-mpop.sheet .nt.pnt{display:block;margin:8px 6px 0;font-size:13px}       /* when a permission pick takes is the one note kept */
  }
  /* The list as a chat app's sidebar: rows have no card, only the ground that says pointed-at or
     open, and nothing glows or travels; the state word and the 내 차례 dot carry the state.
     새 대화 leads the list with a filled mark, so the first thing to do is the first thing seen. */
  .pj-srows:not(.sm) .pj-srow,.pj-srows:not(.sm) .pj-srow:is(.s-ended,.s-stale,.s-turn){background:none;box-shadow:none;margin-top:1px;border-radius:8px}
  @media(hover:hover){.pj-srows:not(.sm) .pj-srow:hover,.pj-srows:not(.sm) .pj-srow:is(.s-ended,.s-stale):hover{background:color-mix(in srgb,var(--t1) 6%,transparent)}}
  .pj-srows:not(.sm) .pj-srow.on,.pj-srows:not(.sm) .pj-srow:is(.s-ended,.s-stale,.s-turn).on{background:color-mix(in srgb,var(--t1) 10%,transparent);box-shadow:none}
  .pj-srows:not(.sm) .pj-srow.vis:not(.on){background-color:color-mix(in srgb,var(--t1) 7%,transparent)}
  .pj-srows .pj-srow::before,.pj-srows .pj-srow.s-live::after{display:none}
  .pj-lh .pj-lhd:not(.ph) .pj-newb{font-weight:600;color:var(--t1)}
  .pj-lh .pj-lhd:not(.ph) .pj-newb svg{box-sizing:border-box;width:22px;height:22px;padding:4px;margin-left:-3px;border-radius:50%;background:var(--t1);color:var(--bg)}
  .pj-sfil .num.hot{color:var(--sr-turn);font-weight:700}
  @media(hover:hover) and (pointer:fine){.pj-feedback{margin:4px 16px 0;font-size:12px;color:var(--t4)}.pj-feedback summary{min-height:28px;padding:4px 0}.pj-feedback[open] summary{color:var(--t3)}}
  /* ---------- compact chat (2026-10-17): less on every line, more lines on the screen ----------
     As in the official apps' sidebars a row is its title and its time: 대기 is what the orb already
     says and Claude is what nearly every row is, so only 작업 중 / 내 차례 and a Codex row say more. */
  .pj-srows .pj-srow.s-idle .sr-s{display:none}
  .pj-srows .pj-srow:not(.cx) .sr-ag{display:none}
  /* With a pointer the rows are a sidebar's 36px and a folder's name is a 28px label; an open
     folder's arrow shows when the name is pointed at (a closed one keeps it: that is its state). */
  @media(hover:hover) and (pointer:fine){
    .pj-srows:not(.sm) .pj-srow{height:36px}
    .pj-srows:not(.sm) .pj-sgrp{margin-top:6px}
    .pj-srows:not(.sm) .pj-sgl{padding-top:2px;padding-bottom:0}
    .pj-srows:not(.sm) .pj-sgh{height:28px}
    .pj-sgh[aria-expanded="true"] .cv{opacity:0;transition:opacity .15s ease}
    .pj-sgl:is(:hover,:focus-within) .pj-sgh .cv{opacity:1}
  }
  /* The read offer is one thin line, not a card of two rows. */
  .pj-rbar{flex-wrap:nowrap;gap:8px;padding:4px 4px 4px 12px}
  .pj-rbar>span:first-child{flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pj-rbar .pj-btn{height:28px;padding:0 10px}
  /* The Enter hint is for typing: an empty, unused box does not carry it. */
  .pj-box:not(:focus-within):has(#pj-ta:placeholder-shown) .pj-enter{visibility:hidden}
  /* A phone's box at rest is one line - picture, words, voice, send - as in a messenger; the model
     and the rest of the row come back when it is pressed (the keyboard rises at the same moment). */
  @media(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){
    body.pjchat .pj-box:not(:focus-within):not(.pj-rec):not(:has(.pj-att)):has(#pj-ta:placeholder-shown){flex-wrap:nowrap;padding-top:0;padding-bottom:0}
    body.pjchat .pj-box:not(:focus-within):not(.pj-rec):not(:has(.pj-att)):has(#pj-ta:placeholder-shown) #pj-ta{order:0;flex:1 1 auto;min-width:0;height:44px;min-height:44px;padding:11px 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;resize:none}
    body.pjchat .pj-box:not(:focus-within):not(.pj-rec):not(:has(.pj-att)):has(#pj-ta:placeholder-shown) :is(.pj-mwrap,.pj-pjn,.pj-ctx,.pj-agseg,.pj-gauge,#pj-bqb){display:none}
    body.pjchat .pj-box:not(:focus-within):not(.pj-rec):not(:has(.pj-att)):has(#pj-ta:placeholder-shown) .pj-clip:not(.pj-mic){order:-1}
  }
  /* Edit a line of mine and send it again, run the last answer again (project-branch.js): a pencil
     beside the copy button of a line that can be cut at, the same small ink; dimmed with its reason
     while it cannot. A finger taps the line to bring its pencil up. The new answer's button sits
     beside copy, not under the pin, so a one-line answer's tools stay two rows high. */
  .pj-ed,.pj-rg{position:absolute;display:none;place-items:center;width:28px;height:24px;border-radius:6px;color:var(--t3);opacity:0;transition:opacity .14s ease,background-color .14s ease,color .14s ease}
  .pj-ed svg,.pj-rg svg{width:14px;height:14px;fill:currentColor}
  .pj-msg.user[data-ed]>.pj-ed{display:grid;right:calc(100% + 56px);top:-4px}
  .pj-msg.claude[data-rg]>.pj-rg{display:grid;left:calc(100% + 28px);top:0}
  .pj-msg[data-ed="dim"]>.pj-ed,.pj-msg[data-rg="dim"]>.pj-rg{cursor:default;color:var(--t4)}
  .pj-ed:focus-visible,.pj-rg:focus-visible{opacity:1;outline:2px solid var(--focus-line);outline-offset:1px}
  @media(hover:hover){.pj-msg:hover>.pj-ed,.pj-msg:hover>.pj-rg{opacity:1}
    .pj-msg:not([data-ed="dim"])>.pj-ed:hover,.pj-msg:not([data-rg="dim"])>.pj-rg:hover{color:var(--t1);background:var(--btn)}}
  @media(pointer:coarse){.pj-msg.user[data-ed]>.pj-ed{display:none}
    .pj-msg.user[data-ed].tap>.pj-ed{display:grid;opacity:1;right:100%;top:0;width:44px;height:44px;margin-right:4px}
    .pj-msgs>.pj-msg.claude[data-rg]:nth-last-child(1 of .pj-msg.claude)>.pj-rg{opacity:1;left:31px;top:auto;bottom:-8px;width:44px;height:44px}
    .pj-ed svg,.pj-rg svg{width:18px;height:18px}}
  /* The line being edited: the bubble gives its place to a box with the words, 취소 and 보내기. */
  .pj-edit{align-self:flex-end;width:min(88%,720px);display:flex;flex-direction:column;gap:8px;padding:8px 12px;border-radius:12px 12px 4px 12px;
    background:var(--btn-hi);box-shadow:inset 0 0 0 1px var(--line)}
  .pj-edit textarea{width:100%;min-height:24px;max-height:40vh;resize:none;border:0;padding:0;background:none;color:var(--t1);font:inherit;font-size:14.5px;line-height:1.6;outline:none}
  .pj-edit .acts{display:flex;justify-content:flex-end;align-items:center;gap:8px}
  .pj-edit .acts .why{flex:1;min-width:0;font-size:12px;color:var(--t3)}
  .pj-edit .pj-btn{height:28px;padding:0 12px;font-size:13px}
  @media(pointer:coarse){.pj-edit .pj-btn{height:44px;padding:0 16px}}
  /* The keys line says nothing to a finger, and a narrow box has no room for it (as .pj-enter). */
  @media(pointer:coarse),(max-width:899px){.pj-edit .acts .why.keys{display:none}}
  /* ‹ 2/3 ›: the other branches at this line, under it, the size and ink of a time. */
  .pj-br{align-self:flex-end;display:flex;align-items:center;gap:2px;margin:-8px 0 0;font-size:12px;line-height:16px;color:var(--t3);font-variant-numeric:tabular-nums}
  .pj-br button{position:relative;display:grid;place-items:center;width:22px;height:22px;border-radius:6px;color:var(--t3);font-size:15px;line-height:1}
  .pj-br button:disabled{color:var(--t4);cursor:default}
  .pj-br button:not(:disabled):hover{color:var(--t1);background:var(--btn)}
  .pj-br button:focus-visible{outline:2px solid var(--focus-line);outline-offset:1px}
  @media(pointer:coarse){.pj-br button::after{content:"";position:absolute;inset:-11px -6px}}
  .pj-edit.in,.pj-br.in{animation:pjBrIn .18s ease-out}
  @keyframes pjBrIn{from{opacity:0}}
  @media(prefers-reduced-motion:reduce){.pj-ed,.pj-rg{transition:none}.pj-edit.in,.pj-br.in{animation:none}}
  `;
