// 렌더 자동 검사 on the item screen (docs/night/big-qc.md §1): one chip on the header line, next to
// the rule badge, that says what the check found in this version (검은 프레임, 빠진 프레임, NaN/inf,
// 반딧불, 밝기 튐, 하이라이트 날아감); tapping it opens a sheet whose frame numbers jump the player
// there. The check itself runs on the server after a push (qc_server.py); a version opened without
// a result asks for one, and the chip shows its progress until the result is in.
//
// The player's rail draws the same findings as ticks (v2-stage.js drawMarks calls LoopQc.rail).
// Classic script: it shares v2.js's globals (tl, esc, ic, ago, post, toast, sheet, closeSheet,
// openItem, stageAt, stageGo, stageVideo, frameAt) and attaches through window.LOOP_ITEM_VIEW.
(function () {
  "use strict";
  if (!window.genokBeta?.("qc")) return;      // 설정 → 베타 off: no chip, no rail ticks (LoopQc stays unset)

  const KEYS = ["missing", "unreadable", "black", "empty", "nonfinite", "fireflies", "flicker", "clipped"];
  const LABEL = {missing: () => tl("qc.k.missing"), unreadable: () => tl("qc.k.unreadable"), black: () => tl("qc.k.black"),
    empty: () => tl("qc.k.empty"), nonfinite: () => tl("qc.k.nonfinite"), fireflies: () => tl("qc.k.fireflies"),
    flicker: () => tl("qc.k.flicker"), clipped: () => tl("qc.k.clipped")};
  const WHY = {no_source: () => tl("qc.why.no_source"), numpy: () => tl("qc.why.numpy"), ffmpeg: () => tl("qc.why.ffmpeg"),
    stalled: () => tl("qc.why.stalled"), crashed: () => tl("qc.why.crashed")};
  const POLL = 3000;
  const CHIP_MAX = 2;      // findings named on the chip; the rest is "+n", all of them in the sheet

  // What /api/qc said per item@version, so a redraw shows the chip at once; and what was asked.
  const live = {}, asked = new Set();
  let timer = null;

  const busy = (st) => Object.values(st.files).some((s) => s.state === "running" || s.state === "queued");
  const fr = (n) => "f" + n;
  const span = (r) => (r[0] === r[1] ? fr(r[0]) : `${fr(r[0])}–${fr(r[1])}`);
  // The frame numbers of one kind of finding: plain numbers, or [n, …] entries.
  const nums = (list) => list.map((e) => (Array.isArray(e) ? e[0] : e));
  // Consecutive numbers as [first, last] runs; clipping is stored as runs already.
  const runs = (k, list) => {
    if (k === "clipped") return list.map((e) => [e[0], e[1]]);
    const out = [];
    nums(list).forEach((n) => { const r = out[out.length - 1]; if (r && n === r[1] + 1) r[1] = n; else out.push([n, n]); });
    return out;
  };
  const count = (q, k) => (q.found[k] || []).length + (q.found[k + "_more"] || 0);
  const isImage = (q) => q.source === "image";
  // Clipping over the whole shot reads as one phrase, not a range from the first to the last frame.
  const wholeClip = (q) => { const c = q.found.clipped || [];
    return c.length === 1 && q.frames && q.frames[1] > q.frames[0] && c[0][0] === q.frames[0] && c[0][1] === q.frames[1]; };

  // One finding for the chip: "검은 프레임 2개", "빠진 프레임 f1013–f1014 외 3".
  function part(q, k) {
    const list = q.found[k] || [];
    if (!list.length) return "";
    if (isImage(q)) return LABEL[k]();
    if (k === "black") return tl("qc.n.black", {n: count(q, k)});
    if (k === "empty") return tl("qc.n.empty", {n: count(q, k)});
    if (k === "clipped" && wholeClip(q)) return `${LABEL[k]()} ${tl("qc.all", {p: Math.round(list[0][2] * 100)})}`;
    const rs = runs(k, list), first = rs[0];
    const rest = k === "clipped" ? rs.length - 1 + (q.found.clipped_more || 0) : count(q, k) - (first[1] - first[0] + 1);
    return `${LABEL[k]()} ${span(first)}${rest > 0 ? " " + tl("qc.more", {n: rest}) : ""}`;
  }
  const parts = (q) => KEYS.map((k) => part(q, k)).filter(Boolean);

  // The files of the shown version the check reads, each {name, state, done, total, qc}.
  function files(it, d) {
    const st = live[key(it)];
    if (st) return Object.entries(st.files).map(([name, s]) => ({name, ...s, qc: s.qc || fileOf(d, it, name)?.qc || null}));
    return verFiles(d, it).filter((f) => f.qc).map((f) => ({name: f.name, state: "done", qc: f.qc}));
  }
  const key = (it) => `${it.p}/${it.i}@${it.v}`;
  const verFiles = (d, it) => (d.versions || []).find((w) => w.v === it.v)?.files || [];
  const fileOf = (d, it, name) => verFiles(d, it).find((f) => f.name === name);
  const checkable = (f) => f.kind === "video" || /\.exr$/i.test(f.name || "");

  function chip(fs) {
    if (!fs.length) return "";
    const run = fs.filter((f) => f.state === "running" || f.state === "queued");
    if (run.length) {
      const done = run.reduce((a, f) => a + (f.done || 0), 0), total = run.reduce((a, f) => a + (f.total || 0), 0);
      const t = total ? tl("qc.chip.run", {p: Math.min(99, Math.floor(done / total * 100))}) : tl("qc.chip.wait");
      return `<span class="tag qc muted" aria-live="polite"><span class="qct">${t}</span></span>`;
    }
    const got = fs.filter((f) => f.qc);
    if (!got.length) return "";
    const bad = got.find((f) => f.qc.error);
    const found = got.flatMap((f) => (f.qc.found ? parts(f.qc) : []));
    if (!found.length && bad) {
      const why = WHY[bad.qc.error] ? WHY[bad.qc.error]() : tl("qc.why.read");
      return btn("muted", tl("qc.chip.fail", {why}));
    }
    if (!found.length) return btn("muted", tl("qc.chip.ok"));
    // A long list pushed the item's … button onto a line of its own: the chip names the first
    // findings and counts the rest; the tooltip and the sheet have every one.
    const shown = found.slice(0, CHIP_MAX).join(" · ") + (found.length > CHIP_MAX ? " · " + tl("qc.kinds", {n: found.length - CHIP_MAX}) : "");
    return btn("lint", tl("qc.chip.found", {list: shown}), tl("qc.chip.found", {list: found.join(" · ")}));
  }
  const btn = (cls, text, title = text) => `<span class="tag qc ${cls} press" role="button" tabindex="0" data-qc title="${esc(title)}"><span class="qct">${esc(text)}</span></span>`;

  // ---- the sheet: one row per kind of finding, its frames as buttons that jump the player
  function frameBtns(q, k, name) {
    const list = q.found[k] || [];
    const jump = (n) => `<button class="qcf press num" data-qf="${n}" data-qn="${esc(name)}">${fr(n)}</button>`;
    if (k === "clipped") return list.map((e) => `<button class="qcf press num" data-qf="${e[0]}" data-qn="${esc(name)}">${span(e)}</button>`).join("");
    const rs = runs(k, list).slice(0, 24);
    return rs.map((r) => (r[0] === r[1] ? jump(r[0]) : `<button class="qcf press num" data-qf="${r[0]}" data-qn="${esc(name)}">${span(r)}</button>`)).join("");
  }
  function coords(q, k) {
    const e = (q.found[k] || [])[0];
    const xy = Array.isArray(e) && Array.isArray(e[2]) ? e[2] : [];
    return xy.length ? `<div class="s qcxy num">${tl("qc.xy", {xy: xy.map((p) => `(${p[0]}, ${p[1]})`).join(" ")})}</div>` : "";
  }
  function rowsOf(f) {
    const q = f.qc;
    // A check that could not run says why (and what the child said); the gaps push saw still list.
    const why = WHY[q.error] ? WHY[q.error]() : tl("qc.why.read"), said = WHY[q.error] ? q.detail : q.error;
    const fail = q.error ? `<div class="row"><span class="ico sm c-grey">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${tl("qc.chip.fail", {why})}</div>${said ? `<div class="s" style="white-space:normal">${esc(said)}</div>` : ""}</span></div>` : "";
    const ks = KEYS.filter((k) => (q.found?.[k] || []).length);
    if (!ks.length) return fail || `<div class="row"><span class="ico sm c-green">${ic("check")}</span><span class="tx"><div class="t" style="font-size:16px">${tl("qc.ok")}</div></span></div>`;
    return fail + ks.map((k) => {
      const n = count(q, k), whole = k === "clipped" && wholeClip(q);
      const head = isImage(q) ? LABEL[k]() : whole ? `${LABEL[k]()} ${tl("qc.all", {p: Math.round(q.found.clipped[0][2] * 100)})}`
        : k === "clipped" ? tl("qc.n.ranges", {kind: LABEL[k](), n}) : tl("qc.n.frames", {kind: LABEL[k](), n});
      const shown = k === "clipped" ? (q.found.clipped || []).length : runs(k, q.found[k]).slice(0, 24).reduce((a, r) => a + r[1] - r[0] + 1, 0);
      const more = n - shown;
      return `<div class="row qcrow" data-qk="${k}"><span class="ico sm c-orange">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${head}</div>
        ${isImage(q) || whole ? "" : `<div class="qcfs">${frameBtns(q, k, f.name)}${more > 0 ? `<span class="s">${tl("qc.more", {n: more})}</span>` : ""}</div>`}
        ${k === "nonfinite" || k === "fireflies" ? coords(q, k) : ""}</span></div>`;
    }).join("");
  }
  function open(it, d) {
    const fs = files(it, d).filter((f) => f.qc);
    if (!fs.length) return;
    const q0 = fs[0].qc;
    const notes = [q0.source === "video" ? (q0.note === "no_source" ? tl("qc.note.no_source") : tl("qc.note.video")) : ""].filter(Boolean);
    const sub = [ago(q0.at), q0.decoded ? tl("qc.frames", {n: q0.decoded}) : ""].filter(Boolean).join(" · ");
    sheet(`<h2 style="margin:0 0 4px">${tl("qc.title")}</h2><p class="hint" style="margin:0 0 12px">${sub}${notes.length ? `<br>${notes.join(" ")}` : ""}</p>
      ${fs.map((f) => (fs.length > 1 ? `<p class="hint qcname">${esc(f.name)}</p>` : "") + rowsOf(f)).join("")}
      <div class="qcact"><button class="btn press" data-qcre>${ic("sync", "i")}<span>${tl("qc.rerun")}</span></button></div>`, (box) => {
      box.querySelectorAll("[data-qf]").forEach((b) => b.onclick = () => { closeSheet(); jump(b.dataset.qn, +b.dataset.qf, `${b.textContent} ${LABEL[b.closest(".qcrow").dataset.qk]()}`); });
      box.querySelector("[data-qcre]").onclick = () => { closeSheet(); rerun(it); };
    });
  }

  // Stand the player on frame n of the named file and say what is there, as a comment dot does.
  function jump(name, n, say) {
    if (!openItem || typeof stageGo !== "function") return;
    const pics = openItem.pics || [];
    const at = pics.findIndex((f) => f.name === name && f.kind === "video");
    if (at < 0) return;
    if (at !== stageAt) stageGo(at);
    const vd = stageVideo(), f = pics[at];
    if (!vd || !f.fps) return;
    vd.pause(); vd.currentTime = frameAt(n, f.fps, f.start);
    toast(say, 4500);
  }

  async function rerun(it) {
    try { live[key(it)] = await post("/api/qc", {p: it.p, i: it.i, v: it.v, rerun: "1"}); }
    catch (e) { return toast(e.message); }
    toast(tl("qc.rerun.done"));
    paint(it);
    poll(it);
  }

  // While a check of the shown version runs, ask how far it is every few seconds.
  function poll(it) {
    clearTimeout(timer);
    const st = live[key(it)];
    if (!st || !busy(st)) return;
    timer = setTimeout(async () => {
      if (!openItem || key(openItem) !== key(it)) return;
      try {
        const q = new URLSearchParams({p: it.p, i: it.i, v: it.v});
        live[key(it)] = await fetch("/api/qc?" + q).then((r) => r.json());
      } catch { return; }
      paint(it);
      poll(it);
    }, POLL);
  }

  // A result that came in while the item is open goes into the item's own file entries too: the
  // player's rail draws from openItem.pics[].qc (v2-stage.js drawMarks), and it redraws on the
  // video's seeked event, as a ticked-off directive's dots do.
  function adopt(it, d) {
    const st = live[key(it)];
    if (!st || !d) return;
    let moved = false;
    Object.entries(st.files).forEach(([name, s]) => {
      if (s.state !== "done" && s.state !== "none") return;
      const f = fileOf(d, it, name), q = s.qc || null;
      if (f && (f.qc?.at || null) !== (q?.at || null)) { f.qc = q; moved = true; }
    });
    if (moved && openItem && key(openItem) === key(it)) stageVideo()?.dispatchEvent(new Event("seeked"));
  }

  let last = null;
  function paint(it, d = last?.d) {
    const box = last?.box;
    if (!box || !d) return;
    adopt(it, d);
    const p = box.querySelector(".htitle p");
    if (!p) return;
    p.querySelector(".tag.qc")?.remove();
    const html = chip(files(it, d));
    if (!html) return;
    const lint = p.querySelector(".tag.lint"), more = p.querySelector(".imore");
    if (lint) lint.insertAdjacentHTML("afterend", html);
    else if (more) more.insertAdjacentHTML("beforebegin", html);
    else p.insertAdjacentHTML("beforeend", html);
  }

  function attach(box, it, d) {
    last = {box, d};
    const k = key(it);
    // Once nothing runs, the item's own data carries the result: what /api/qc said is not needed.
    if (live[k] && !busy(live[k])) delete live[k];
    paint(it, d);
    const want = verFiles(d, it).some((f) => checkable(f) && !f.qc);
    if (want && !asked.has(k)) {
      asked.add(k);
      post("/api/qc", {p: it.p, i: it.i, v: it.v}).then((got) => {
        if (!got?.on) return;
        live[k] = got;
        if (openItem && key(openItem) === k) { paint(it); poll(it); }
      }).catch(() => {});
    } else if (live[k]) poll(it);
  }

  const onChip = (e) => {
    const b = e.target.closest?.("[data-qc]");
    if (!b || (e.type === "keydown" && e.key !== "Enter" && e.key !== " ")) return;
    e.preventDefault(); e.stopPropagation();
    if (openItem && last) open(openItem, last.d);
  };
  document.addEventListener("click", onChip, true);
  document.addEventListener("keydown", onChip, true);

  // ---- the player's rail: a tick per frame with a finding, a band per clipped stretch
  function rail(f, duration) {
    const q = f.qc;
    if (!q || !q.found || !f.fps || !(duration > 0) || isImage(q)) return "";
    const at = (n) => frameAt(n, f.fps, f.start), pct = (t) => Math.min(100, Math.max(0, t / duration * 100));
    const spots = new Map();
    KEYS.forEach((k) => {
      if (k === "clipped" && wholeClip(q)) return;
      runs(k, q.found[k] || []).forEach((r) => {
        const t = at(r[0]), x = Math.round(pct(t) * 2) / 2;      // ticks within 0.5% share one
        const s = spots.get(x) || {t, x, says: []};
        s.says.push(`${span(r)} ${LABEL[k]()}`);
        spots.set(x, s);
      });
    });
    const bands = (q.found.clipped || []).filter((e) => e[1] > e[0]).map((e) => {
      const a = pct(at(e[0]) - 0.5 / f.fps), b = pct(at(e[1]) + 0.5 / f.fps);
      return `<b class="qcb" style="left:${a}%;width:${Math.max(0.4, b - a)}%"></b>`;
    }).join("");
    return bands + [...spots.values()].map((s) => {
      const say = s.says.join(" · ");
      return `<button class="qcm press" style="left:${s.x}%" data-mt="${s.t}" title="${esc(say)}" aria-label="${esc(say)}"></button>`;
    }).join("");
  }

  window.LoopQc = {rail, parts, runs, chip};
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(attach);
})();
