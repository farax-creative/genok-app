// Genok web UI, cut from v2.js: the shared page chrome: refresh without a blank, the title row, the menu rail, the kit look.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- refresh without a blank (stale-while-revalidate) ----------
// A redraw of the screen that is already open (the 30s round, the live watch, the refresh
// button) used to rebuild #view from nothing: the entry fade started every child at opacity 0,
// extension screens cleared themselves and drew "loading" before their fetch answered, and the
// page jumped to the top. Now the shown content stays until the new one is ready, it is swapped
// in one step, and scroll, open folds and focus are put back. First loads are untouched.
let softN = 0, viewGen = 0;                  // softN>0 while a refresh redraw runs; viewGen counts real navigations
const innerDesc = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML");
const innerSet = innerDesc.set;
const FOCUSABLE = "button,a,input,textarea,gk-select,summary,[tabindex]";
// Only elements that ever scrolled are asked for their scroll: reading scrollTop on every element
// laid out each content-visibility:auto card, and a refresh of 800 results froze the page for ~2s.
const scrolled = new Set();
document.addEventListener("scroll", (e) => { if (e.target instanceof Element) scrolled.add(e.target); }, {capture: true, passive: true});
function viewState(root = V()) {
  const a = document.activeElement, all = [...root.querySelectorAll(FOCUSABLE)], fi = a && root.contains(a) ? all.indexOf(a) : -1;
  scrolled.forEach((e) => { if (!e.isConnected) scrolled.delete(e); });
  const moved = [...scrolled].filter((e) => root.contains(e) && (e.scrollTop || e.scrollLeft)), els = moved.length ? [...root.querySelectorAll("*")] : [];
  return {y: scrollY, fi, tag: fi >= 0 ? a.tagName : "", sel: fi >= 0 && typeof a.selectionStart === "number" ? [a.selectionStart, a.selectionEnd] : null,
    open: [...root.querySelectorAll("details")].map((d) => d.open),
    inner: moved.map((e) => [els.indexOf(e), e.tagName, e.scrollTop, e.scrollLeft, scrollKey(e)]).sort((x, y) => x[0] - y[0])};
}
// A scrolled column is found again by its id or classes: rows added above it shift every index.
const scrollKey = (e) => e.id ? "#" + e.id : e.className && typeof e.className === "string" ? e.tagName + "." + e.className.trim().split(/\s+/).sort().join(".") : "";
function restoreView(st, root = V()) {
  const ds = [...root.querySelectorAll("details")];
  if (ds.length === st.open.length) ds.forEach((d, i) => { if (d.open !== st.open[i]) d.open = st.open[i]; });
  if (st.inner.length) { const all = root.querySelectorAll("*"); st.inner.forEach(([i, tag, top, left, key]) => {
    let e = all[i];
    if (key && !(e && scrollKey(e) === key)) { const same = [...all].filter((x) => scrollKey(x) === key); if (same.length === 1) e = same[0]; }
    if (e && e.tagName === tag) { e.scrollTop = top; e.scrollLeft = left; scrolled.add(e); } }); }
  if (scrollY !== st.y) scrollTo(0, st.y);
  if (st.fi >= 0 && !root.contains(document.activeElement)) {
    const e = [...root.querySelectorAll(FOCUSABLE)][st.fi];
    if (e && e.tagName === st.tag && !e.disabled) { try { e.focus({preventScroll: true}); if (st.sel) e.setSelectionRange(st.sel[0], st.sel[1]); } catch {} }
  }
}
// What a refresh must not move: a redraw builds every <img> again, and the new one would load and
// come in where the old one stood; a new result card starts as its 300px content-visibility
// placeholder, which pushed everything below the cards scrolled past. Call before the draw; the
// function it hands back puts the pictures that were on screen into the new page (same src, in
// order) and gives each card the height it had.
function keepLook(root = V()) {
  const pics = new Map(), tall = new Map();
  root.querySelectorAll("img[src]").forEach((im) => { if (!im.complete || !im.naturalWidth) return;
    const k = im.getAttribute("src"); if (!pics.has(k)) pics.set(k, []); pics.get(k).push(im); });
  root.querySelectorAll(".gw").forEach((el) => { const k = el.querySelector(".gi")?.dataset.item; if (k) tall.set(k, el.offsetHeight); });
  return () => {
    const news = [...root.querySelectorAll("img[src]")];
    news.forEach((b) => { const q = pics.get(b.getAttribute("src")), i = q ? q.indexOf(b) : -1; if (i >= 0) q.splice(i, 1); });   // it never left
    news.forEach((b) => { const q = pics.get(b.getAttribute("src")); if (!q || !q.length) return;
      const a = q.shift(); if (a.isConnected) return;
      a.className = b.className; a.classList.remove("loading", "imgin"); b.replaceWith(a); });
    if (tall.size) root.querySelectorAll(".gw").forEach((el) => { const h = tall.get(el.querySelector(".gi")?.dataset.item); if (h) el.style.containIntrinsicHeight = `auto ${h}px`; });
  };
}
// Run a screen's draw for a refresh: same page, so no entry animation, and the state kept.
function softDraw(fn) {
  const st = viewState(), keep = keepLook(); V().classList.add("still"); softN++;
  try { return fn(); } finally { softN--; try { keep(); } catch (e) { console.error(e); } restoreView(st); }
}
// The open screen, redrawn from fresh data. Never while a detail page is up (it has its own state).
let gaBusy = 0;                           // X15: until when result cards are mid-spring (gactFlip)
function redraw() {
  if (detail || !SCREENS[cur] || cur === "settings") return;
  // X15: the server's "something changed" lands a few ms after 정리; rebuilding now would cut the cards' spring.
  if (performance.now() < gaBusy) return void setTimeout(redraw, gaBusy - performance.now() + 20);
  softDraw(() => gaPics(() => SCREENS[cur](cur === "inbox" ? inTab : undefined)));   // X15: result cards keep their pictures
}
// openmoji.js wraps each department emoji in <span class="emo"> once it is on the page, so what
// stands there never equalled the html it was written from and the rail was rebuilt every round
// (the emoji blinked as text first). The copy handed back has the plain characters again.
function plainEmoji(el) {
  if (!el.querySelector(".emo")) return el;
  const c = el.cloneNode(true);
  c.querySelectorAll(".emo").forEach((n) => n.replaceWith(n.textContent)); c.normalize();
  return c;
}
// Write html into a chrome element only when it differs, and keep its scroll and focus: the
// rail and the bars were rebuilt every round, which dropped hover and focus for nothing.
function setHTML(el, html) {
  if (!el) return;
  const t = el.cloneNode(false); innerSet.call(t, html);
  if (t.isEqualNode(el) || t.isEqualNode(plainEmoji(el))) return;
  const a = document.activeElement, kf = (x) => x.dataset.go || x.dataset.key || x.dataset.dept || ("sync" in x.dataset ? "sync" : "");
  const key = a && el.contains(a) && a.dataset ? kf(a) : "", top = el.scrollTop;
  innerSet.call(el, html); el.scrollTop = top;
  if (key) { const n = [...el.querySelectorAll(FOCUSABLE)].find((x) => kf(x) === key); if (n) n.focus({preventScroll: true}); }
}
// Hold back the innerHTML writes of a draw that will repaint later (a placeholder line, then the
// data): the old content stays on screen, and the LAST write lands once the draw is done. A draw
// that hands back a promise is waited for; otherwise the last write lands after 1.5s. A draw that
// adds nodes instead of setting innerHTML is swapped at once (new nodes are in, old ones go out).
// A hold belongs to one draw of one screen. A move to another screen (or the next refresh) lets go
// of it first: the new screen's own writes would otherwise be held back and then thrown away.
let holdOff = null;
// A layer that covers the screen owns the keyboard: everything beside it (and beside each of its
// parents) is out of reach until the returned function gives it back and returns focus to `from`.
// Layers that open on top of it (search, sheets, the toast and its 되돌리기, the wizard) and the
// window buttons stay reachable.
const MODAL_KEEP = "#toast,#ov,#spop,.sheet,.ob-scrim,.wtbar,script";
function modalHold(el, from) {
  const off = [];
  for (let n = el; n && n !== document.body; n = n.parentElement)
    for (const c of n.parentElement.children) if (c !== n && !c.inert && !c.matches(MODAL_KEEP)) { c.inert = true; off.push(c); }
  let done = false;
  return (stay) => { if (done) return; done = true; off.forEach((c) => { c.inert = false; });
    if (!stay && from?.isConnected && from !== document.body) from.focus({preventScroll: true}); };
}
let modalOff = null;
function holdWrites(el, run, apply) {
  if (holdOff) holdOff();
  const gen = viewGen, before = [...el.childNodes];
  let held = null, done = false, timer = 0;
  const off = holdOff = () => { if (holdOff === off) holdOff = null; if (done) return; done = true; clearTimeout(timer); delete el.innerHTML; };
  Object.defineProperty(el, "innerHTML", {configurable: true, get() { return innerDesc.get.call(el); },
    set(v) { if (done) innerSet.call(el, v); else held = {v}; }});
  const fin = () => {
    if (done) return; done = true; clearTimeout(timer); delete el.innerHTML;
    if (!held || !el.isConnected || gen !== viewGen) return;
    apply ? apply(() => innerSet.call(el, held.v)) : innerSet.call(el, held.v);
  };
  let r; try { r = run(); } catch (e) { console.error(e); return fin(); }
  if (el.childNodes.length > before.length || before.some((n) => n.parentNode !== el)) {     // it built with DOM calls
    before.forEach((n) => { if (n.parentNode === el) n.remove(); });
    done = true; delete el.innerHTML; return;
  }
  const then = r && typeof r.then === "function";
  timer = setTimeout(fin, then ? 10000 : 1500);
  if (then) r.then(fin, fin);
}

// Where each list was scrolled when a result opened from it, so coming back lands on the same card
// (phone list apps keep the place; it used to jump to the top). Keyed by the full list address.
// Noted on scroll, not at render: a filter tab rewrites the address in place without a render.
const listY = {}; let renderHash = location.hash, libTabAt = "";
addEventListener("scroll", () => { if (!detail) listY[location.hash] = scrollY; }, {passive: true});
// On a wide window the verdict cards scroll inside their own column ([data-rdw]), not the window.
const listIn = {};
document.addEventListener("scroll", (e) => { const t = e.target; if (!detail && t.dataset?.rdw) listIn[location.hash] = [t.dataset.rdw, t.scrollTop]; }, {capture: true, passive: true});
function render(opts) {
  // Capture the built-in screen keys once (before any extension registers), so an extension
  // tab can never take a core id; then fold in whatever tabs extensions have pushed by now.
  window.LOOP_CORE_SCREENS = window.LOOP_CORE_SCREENS || Object.keys(SCREENS);
  syncExtTabs();
  // opts.soft: the same page again with fresh data (the refresh button): keep the place, no entry animation.
  const soft = !!(opts && opts.soft), y0 = scrollY;
  // Another screen ends a full-screen page; a redraw of the same one (a decision, a comment) keeps it.
  if (!soft && location.hash !== renderHash) pgFull(false);
  if (!soft) { viewGen++; if (holdOff) holdOff(); if (modalOff) { modalOff(true); modalOff = null; } V().classList.remove("still"); }
  if (!(soft && !detail)) { endCompose(); closeResult(); }
  document.body.classList.remove("ctahide"); stageMount = null;
  // A name with a bare % ("진행률 50%") is not valid percent-encoding: read it as typed.
  let raw = location.hash.slice(1) || "home";
  // The results list keeps its filter in the address (#lib?f=pending&d=부서&q=글자), so a
  // refresh or a sent link opens the same list.
  if (/^lib\?/.test(raw)) { const u = new URLSearchParams(raw.slice(4)); libFAuto = !u.get("f"); libF = libFAuto ? "" : stTabKey(u.get("f")); libD = u.get("d") || ""; libQ = u.get("q") || ""; libK = u.get("k") || ""; raw = "lib";
    // The lab list (web/v2-results.js) keeps its own tab: a link that names one opens on it, once
    // per address, so a redraw or a Back from a card does not undo a tab picked since.
    if (window.genokBeta?.("pai")) { if (location.hash !== libTabAt && !libFAuto && typeof k3f !== "undefined") k3f = libF === "all" ? "" : libF;
      libTabAt = location.hash; } }
  // A compare view keeps its pair, mode, and moment in the address (#item/<id>?cmp=v3,v5&m=wipe&t=12.4)
  // so a reload, Back, or a link opened elsewhere restores the exact comparison. A project/item
  // name can never hold "?", so the query safely starts at the first one.
  pendingCmp = null;
  if (/^item\//.test(raw) && raw.includes("?")) {
    const qi = raw.indexOf("?"), u = new URLSearchParams(raw.slice(qi + 1)), cmp = (u.get("cmp") || "").split(",");
    if (cmp[0]) pendingCmp = {id: null, a: cmp[0], b: cmp[1] || "", m: u.get("m") || "", t: parseFloat(u.get("t")), thr: parseInt(u.get("thr"), 10)};
    raw = raw.slice(0, qi);
  }
  let h = raw; try { h = decodeURIComponent(raw); } catch {}
  // #mission · #alerts · #tasks became sections of 받은함: the address is rewritten in place,
  // so Back does not bounce through the old name.
  if (ALIAS[h]) { h = ALIAS[h]; history.replaceState(null, "", "#" + h); }
  // 전체 is the phone's menu page; the desktop layout has no way to it and no styles for it. An
  // address that names it there (a link sent from the phone) opens home instead.
  if (h === "all" && wide()) { h = "home"; history.replaceState(null, "", "#home"); }
  const [k, ...rest] = h.split("/");
  const id = rest.join("/");
  if (pendingCmp) pendingCmp.id = id;
  if (k !== "lib") { libSel = null; document.getElementById("selbar")?.remove(); selOff(); }
  if (k === "search") { search(true); return; }
  search(false);
  if ((k === "item" || k === "dept") && id) {
    detail = [k, id];
    document.body.classList.add("push"); document.body.classList.remove("allpg");
    document.body.classList.toggle("detail", !wide() && k === "item");
    ({item: itemView, dept: deptView})[k](id);
    infoPanel(null);
  } else {
    detail = null;
    cur = SCREENS[k] ? k : "home";
    document.body.classList.remove("push", "detail");
    if (cur !== "settings") setDeep = false;
    if (cur === "settings") { setShowPage = setDeep; setUpdSeen = false; setNav.run?.stop(); setNav.run = null; setNav.drag = false; }   // a fresh open of settings starts on the menu (phone)
    const r = soft ? softDraw(() => SCREENS[cur](k === "inbox" ? id : undefined)) : SCREENS[cur](k === "inbox" ? id : undefined);
    document.body.classList.toggle("allpg", cur === "all");   // phone: 전체 draws its own top row
    head(M(cur)?.n || (cur === "inbox" ? tl("TABS.1") : "") || (cur === "all" ? tl("all.tab") : "") || extTabs().find((t) => t.id === cur)?.label || "", r?.right);
    infoPanel(cur);
  }
  const was = renderHash; renderHash = location.hash;
  // Back from a chat opened in the sessions list: the list is where it was left, not at its top.
  const fromItem = /^#(item|dept)\//.test(was) || (cur === "sessions" && /^#project\//.test(was));
  // The place a list opens at is its remembered place too: a scroll that does not move fires no event,
  // and an older place would be what the next back from an item returns to.
  const y = soft ? y0 : !detail && fromItem && listY[location.hash] || 0;
  scrollTo(0, y); if (!detail) listY[location.hash] = y;
  if (!soft && !detail) { const w = fromItem && listIn[location.hash], c = w && V().querySelector(`[data-rdw="${w[0]}"]`);
    if (c) c.scrollTop = w[1]; else delete listIn[location.hash]; }
  drawChrome();
  // Customisation (web/custom.js): re-apply per-project accent and any view options that
  // depend on the screen just drawn. A no-op when custom.js has not loaded.
  try { window.LOOP_AFTER_RENDER && window.LOOP_AFTER_RENDER(); } catch (e) {}
}
function back() {
  // An embedded report has its own history; the app's back button leaves the result directly.
  if (detail?.[0] === "item") return nav("lib");
  if (history.length > 1 && sessionStorage.getItem("v2-inner")) history.back();
  else nav(detail?.[0] === "item" ? "lib" : "dept");
}
// A result opened from a conversation remembers it, so the back spot can say where it leads
// ("대화로" + the conversation's name). Noted when the address moves from a room to a result, kept
// from one result to the next (those replace each other in history, so back still lands in the
// room) and across the search/settings overlays. Memory only: a result opened by its address or
// after a reload has no known origin and shows the plain back arrow.
let navLast = location.hash.slice(1), itemFrom = null;
window.LOOP_ITEM_FROM = () => itemFrom?.sid || null;
function noteFrom() {
  const h = location.hash.slice(1), room = /^project\/[^/?]+\/([^/?]+)/.exec(navLast), over = /^(search|settings)/;
  if (h.startsWith("item/")) {
    if (room) {
      const f = itemFrom = {hash: navLast, sid: decodeURIComponent(room[1]), title: ""};
      get("/api/project/session?id=" + encodeURIComponent(f.sid)).then((x) => { if (itemFrom !== f || !x?.title) return;
        f.title = x.title; document.querySelectorAll(".tochat .bn").forEach((n) => { n.textContent = x.title; n.closest("button").title = x.title; }); }).catch(() => {});
    } else if (!navLast.startsWith("item/") && !(over.test(navLast) && itemFrom?.at === h)) itemFrom = null;
    if (itemFrom) itemFrom.at = h;
  } else if (!over.test(h)) itemFrom = null;
  navLast = h;
}
// A link to a result inside a conversation opens it here, in the app, so back returns to the
// conversation (it used to open a second window). A link that names a version still opens as before.
document.addEventListener("click", (e) => {
  const a = e.target.closest?.(".pj-msgs a[href]"); if (!a || e.defaultPrevented || e.button || e.ctrlKey || e.metaKey || e.shiftKey) return;
  let u; try { u = new URL(a.href); } catch { return; }
  const m = /^\/i\/([^/]+)\/([^/]+)\/?$/.exec(u.pathname);
  if (!m || u.search || u.port !== location.port || !["localhost", "127.0.0.1", location.hostname].includes(u.hostname)) return;
  let id; try { id = decodeURIComponent(m[1]) + "/" + decodeURIComponent(m[2]); } catch { return; }
  if (!D.items?.some((x) => iid(x) === id)) return;
  e.preventDefault(); nav("item/" + encodeURIComponent(decodeURIComponent(m[1])) + "/" + encodeURIComponent(decodeURIComponent(m[2])));
});
// Back on a phone while the viewer or a sheet is up: the page under it changes, so they go too.
addEventListener("hashchange", () => { try { sessionStorage.setItem("v2-inner", "1"); } catch {}
  noteFrom();
  vwClose?.(); stkClose?.(); if (document.getElementById("sheet")?.classList.contains("on")) closeSheet(); closeResult(); render(); });

// The sidebar toggle: one control in one place - the first slot of the top bar on every desktop
// screen, list or detail, so it never moves or goes missing when the rest of the bar changes.
// Whether history has a page ahead (Navigation API; where it is missing the button stays on).
const fwdOk = () => { try { return window.navigation ? navigation.canGoForward : true; } catch { return true; } };
// The one panel icon (a window with a side panel on the right). The left menu's controls draw it mirrored (CSS).
const PANEL_ICO = '<svg class="i" viewBox="0 0 256 256" aria-hidden="true"><path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM40,56H160V200H40ZM216,200H176V56h40V200Z"/></svg>';
const railBtn = () => `<button class="ib press railtgl" data-railmin aria-label="${railTip()}" aria-expanded="${railState() === "full"}" title="${railTip()} ( [ )">${PANEL_ICO}</button>`;
function head(title, right = "") {
  const t = document.getElementById("top"); head.last = [title, right];
  if (detail) {
    // Result back always returns to the library; do not label it as a chat return.
    const fc = null;
    setHTML(t, `${LAB3 && wide() ? `<div class="tbtools">` : ""}${wide() ? railBtn() : ""}<button class="ib back press${fc ? " tochat" : ""}" data-back aria-label="${fc ? tl("head.tochat") : tl("head.1")}"${fc ? ` title="${esc(fc.title)}"` : ""}>${ic("back")}${fc ? `<span class="bl">${tl("head.tochat")}</span><span class="bn">${esc(fc.title)}</span>` : ""}</button>${LAB3 && wide() ? "</div>" : ""}<h1 class="dt">${title}</h1><span class="sp"></span>${syncBtn()}${right}${fbBtn()}${connPill()}${updPill()}${wcSpacer()}`);
    return;
  }
  // A screen with its own action keeps the bell beside it: 알림 is reached the same way everywhere.
  if (right && !right.includes("data-bell")) right += bellOnly();
  if (!wide()) { setHTML(t, `<h1>${title}</h1><span class="sp"></span>${zoomBtn()}${right || bellSearch()}${fbBtn()}${connPill()}${updPill()}${wcSpacer()}`); return; }
  // Desktop: refern's single toolbar — a cluster of chrome icons on the left, an address-like path
  // pill centred between two flexible gaps, the screen's right-side actions, then (on a frameless
  // Windows window) room for the min/max/close corner bar. Refresh is the quiet data-sync icon in the
  // left cluster; its last-sync time lives in the tooltip, so "방금 동기화" is no longer a text pill.
  setHTML(t, `<div class="tbtools">`
    + railBtn()
    + `<button class="ib press" data-back aria-label="${tl("ui.tb.back")}" title="${tl("ui.tb.back")}">${ic("back")}</button>`
    + `<button class="ib press fwd" data-fwd aria-label="${tl("ui.tb.fwd")}" title="${fwdOk() ? tl("ui.tb.fwd") : tl("ui.tb.fwd.none")}"${fwdOk() ? "" : " disabled"}>${ic("back")}</button>`
    + `<button class="ib press" data-sync aria-label="${tl("ui.tb.refresh")}" title="${tl("syncBtn.2", {p0: D.at ? hm(D.at) : "-"})}">${ic("sync")}</button>`
    + `<button class="ib press tbset ${cur === "settings" ? "on" : ""}" data-go="settings" aria-label="${tl("TABS.4")}" title="${tl("TABS.4")}">${ic("gear")}</button>`
    // Search is one icon here (Ctrl K). The wide centre pill repeated the sidebar highlight and
    // crowded the title bar, so the middle is left empty to drag the window by.
    + (LAB3 ? "" : `<button class="ib press" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")} (${tl("ui.ctrlk")})">${ic("search")}</button>`)
    + `</div>`
    // Lab layout: the screen's name leads the bar (home greets below instead). Lab 3 has the one
    // bar only, with the search field in the middle of it and no greeting.
    + (LAB3 && cur !== "home" ? `<h1 class="ttl">${title}</h1>` : "")
    + (LAB3 ? `<span class="sp"></span><button class="k3q press" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")} (${tl("ui.ctrlk")})">${ic("search")}<span>${tl("MENUS.5")}</span></button>` : "")
    + `<span class="sp"></span><div class="tbright">${zoomBtn()}${right || bellOnly()}${fbBtn()}</div>${connPill()}${updPill()}${wcSpacer()}`);
}
// Frameless Windows window chrome, drawn by the page (refern style): no separate title strip. The
// page runs to the top edge; min/max/close sit transparent in the top-right corner of every screen
// (one fixed bar above every overlay, onboarding and tour included) and headers reserve that corner
// with wcSpacer. A press on any empty spot in the top row drags the window: the bridge (start_move)
// hands it to the system move loop, so Snap and FancyZones work; double-click maximizes. The resize
// border is native (winframe.py).
let WINCHROME = IN_APP && OS_WIN;
// The shell says whether it really hid the native frame (tray.frameless via js_api.env). When that failed
// the window still has Windows' own title bar, and our buttons would be a second set: drop them.
function dropWinChrome() {
  if (!WINCHROME) return;
  WINCHROME = false;
  document.documentElement.classList.replace("os-win", "os-other");
  document.querySelectorAll(".wtbar,.wcsp").forEach((x) => x.remove());
}
async function checkNativeFrame() {
  try { const e = await window.pywebview.api.env(); if (e && e.frameless === false) dropWinChrome(); } catch (err) { /* browser tab or old shell */ }
}
if (WINCHROME) {
  const go = () => { checkNativeFrame(); setTimeout(checkNativeFrame, 2000); setTimeout(checkNativeFrame, 6000); };
  if (window.pywebview?.api) go(); else addEventListener("pywebviewready", go, {once: true});
}
// The title-bar update pill's state (see updPill); declared up here because head() draws it.
// phase: "" | "dl" | "ready" (downloaded, waiting to be applied) | "install". auto: install as soon as
// the download is in. err: why the last try failed. sure: the busy-session warning was confirmed.
const UPD = {u: null, phase: "", pct: 0, enterUntil: 0, auto: true, err: "", same: true, run: 0};
const WG = {
  min: `<line x1="1.5" y1="5" x2="8.5" y2="5"/>`,
  max: `<rect x="1.5" y="1.5" width="7" height="7" rx="0.5"/>`,
  restore: `<rect x="1.4" y="3.1" width="5.5" height="5.5" rx="0.5"/><path d="M3.6 3.1V1.4h5.5v5.5H7.3"/>`,
  close: `<path d="M1.5 1.5l7 7M8.5 1.5l-7 7"/>`,
};
const winGlyph = (k) => `<svg class="wg" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">${WG[k]}</svg>`;
const winMaxed = () => document.body.classList.contains("winmax");
const wcSpacer = () => WINCHROME ? `<span class="wcsp" aria-hidden="true"></span>` : "";
const winCtl = () => `<div class="wctl">`
  + `<button class="wb" data-wmin aria-label="${tl("ui.win.min")}" title="${tl("ui.win.min")}">${winGlyph("min")}</button>`
  + `<button class="wb" data-wmax aria-label="${tl("ui.win.max")}" title="${winMaxed() ? tl("ui.win.restore") : tl("ui.win.max")}">${winGlyph(winMaxed() ? "restore" : "max")}</button>`
  + `<button class="wb wclose" data-wclose aria-label="${tl("ui.win.close")}" title="${tl("ui.win.close")}">${winGlyph("close")}</button>`
  + `</div>`;
// Python (tray._sync_maxed) calls this on maximize/restore (Snap and double-click included).
window.__rlWinMax = (maxed) => {
  document.body.classList.toggle("winmax", !!maxed);
  const b = document.querySelector("[data-wmax]");
  if (b) { b.innerHTML = winGlyph(maxed ? "restore" : "max"); b.title = tl(maxed ? "ui.win.restore" : "ui.win.max"); }
};
document.addEventListener("click", (e) => {
  const w = e.target.closest?.("[data-wmin],[data-wmax],[data-wclose]");
  if (!w || !window.pywebview?.api) return;
  if (w.dataset.wmin !== undefined) window.pywebview.api.minimize?.();
  else if (w.dataset.wmax !== undefined) window.pywebview.api.toggle_maximize?.();
  else if (w.dataset.wclose !== undefined) window.pywebview.api.close?.();
});
const DRAGH = 36;
// Real controls only. [data-go]/[data-back] are not listed: every one is a button or link already, and
// the Settings/Search backdrop (a full-screen div with data-back) would make the whole top row undraggable.
const dragSpot = (e) => e.clientY >= 0 && e.clientY < DRAGH && !e.target.closest?.(
  "button,a,input,gk-select,textarea,label,summary,[role=button],[role=checkbox],.ib,.btn,.field,.wctl,.updpill,.connpill,.updpop,[contenteditable]");
document.addEventListener("mousedown", (e) => {
  if (!WINCHROME || e.button !== 0 || e.detail > 1 || !window.pywebview?.api?.start_move || !dragSpot(e)) return;
  e.preventDefault();
  window.pywebview.api.start_move();
}, true);
document.addEventListener("dblclick", (e) => {
  if (WINCHROME && window.pywebview?.api && dragSpot(e)) window.pywebview.api.toggle_maximize?.();
});
function initWinChrome() {
  if (!WINCHROME) return;
  const bar = document.createElement("div");
  bar.className = "wtbar";
  bar.innerHTML = winCtl();
  document.body.appendChild(bar);
  // Drawn once, outside drawChrome: a language switch relabels the buttons here.
  addEventListener("loop-lang", () => { if (bar.isConnected) bar.innerHTML = winCtl(); });
}
initWinChrome();
// A refresh that really refreshes: everything reloads and the open screen redraws, even the
// ones the 30-second round leaves alone. How old the data is sits beside it.
const syncBtn = () => `<button class="sync press" data-sync aria-label="${tl("syncBtn.1")}" title="${tl("syncBtn.2", {p0: D.at ? hm(D.at) : "-"})}">${ic("sync")}<span>${syncAgo()}</span></button>`;
const syncAgo = () => { if (!D.at) return (loadLost ? tl("syncAgo.4") : tl("syncAgo.1")); const m = Math.floor((Date.now() - hostDate(D.at)) / 6e4); return (m < 1 ? tl("ago.2") : m < 60 ? tl("syncAgo.2", {m}) : tl("ago.4", {p0: Math.floor(m / 60)})) + tl("syncAgo.3"); };
async function syncNow(b) {
  if (b.classList.contains("on")) return;
  document.querySelectorAll("[data-sync]").forEach((x) => x.classList.add("on"));
  // A bar that just came up already says why; the toast repeats it only when the bar was there before.
  const barred = !!document.getElementById("netbar");
  try { const ok = await load(); render({soft: true}); if (ok || barred) toast(ok ? tl("syncNow.1") : lostMsg, 2200, ok ? "synced" : "failed"); }
  catch (e) { toast(e.message); }
  document.querySelectorAll("[data-sync]").forEach((x) => { x.classList.remove("on"); const sp = x.querySelector("span"); if (sp) sp.innerHTML = syncAgo(); });
}
setInterval(() => document.querySelectorAll("[data-sync] span").forEach((x) => { const h = syncAgo(); if (x.innerHTML !== h) x.innerHTML = h; }), 20000);
// Search + bell, the always-there right cluster. On desktop the sync sits quietly in the left chrome
// cluster, so the toolbar uses searchBell(); the phone header keeps the sync pill via bellSearch().
// The bell is the one way into 알림: it carries the number 할 일 has (a dot for unread 소식 alone) and
// opens on the tab that has something. drawChrome redraws it in place when the number moves.
const bellOnly = () => { const todo = todoCount(), news = newsUnread(), t = tl("TABS.1") + (todo ? " " + todo : "");
  return `<button class="ib press bellb ${!detail && cur === "inbox" ? "on" : ""}" data-bell data-go="${!todo && news ? "inbox/news" : "inbox"}" aria-label="${t}" title="${tl("TABS.1")}">${ic("bell")}${todo ? `<b class="bcnt num">${todo > 99 ? "99+" : todo}</b>` : news ? `<span class="dot"></span>` : ""}</button>`; };
const searchOnly = () => `<button class="ib press sbsearch" data-go="search" aria-label="${tl("MENUS.5")}" title="${tl("MENUS.5")}">${ic("search")}</button>`;
// The zoom magnifier (web/custom.js zoomChip) leads the right cluster; it is hidden at 100%.
const zoomBtn = () => (window.zoomChip ? zoomChip() : "");
const searchBell = () => `${searchOnly()}${bellOnly()}`;
const bellSearch = () => `${syncBtn()}${searchBell()}`;
// "의견 남기기" (G-024): the beta feedback form. The address comes from the server (version.py
// FEEDBACK_URL, the one place it lives) with only the app version filled in; while it is
// empty or not http(s) nothing is drawn. A plain new-tab link in a browser; in the app window the
// click asks the server to open the PC's default browser instead.
// Since the popup (fbSheet): the button opens a short form here, and Send posts what was typed plus
// the app's version through the server (/api/feedback-send). The page stays as the way out when
// that fails.
const fbUrl = () => { const u = (LANG() === "en" && D.fbEn) || D.fb || ""; return /^https?:\/\//i.test(u) ? u : ""; };
const fbLink = (cls, inner, label) => `<a class="${cls}" data-feedback href="${esc(fbUrl())}" target="_blank" rel="noopener noreferrer"${label ? ` aria-label="${label}" title="${label}"` : ""}>${inner}</a>`;
// A megaphone, not the speech bubble: the bubble already means "conversation" in the side menu.
// The words stand beside it on a PC-wide bar (v2.css .fbb); narrower, the icon alone, down to 600px.
const fbBtn = () => fbUrl() ? fbLink("ib press fbb", ic("megaphone") + `<span>${tl("fb.send")}</span>`, tl("fb.send")) : "";
const fbPage = () => IN_APP ? post("/api/feedback-open", {lang: LANG()}).catch((x) => toast(x.message)) : window.open(fbUrl(), "_blank", "noopener");
const FB_DRAFT = "genok-fb-draft";
const FB_IMG_MAX = 4, FB_IMG_BYTES = 5 * 1024 * 1024;
function fbSheet() {
  let d = {}; try { d = JSON.parse(localStorage.getItem(FB_DRAFT) || "{}") || {}; } catch (e) { /* no draft */ }
  const st = {text: typeof d.text === "string" ? d.text : "", mail: typeof d.mail === "string" ? d.mail : ""};
  const imgs = [], canImg = !!D.fbImg;   // pictures live for this popup only, never in the draft
  sheet(`<h2 style="margin:0 0 4px">${tl("fb.send")}</h2><p class="hint" style="margin:0 0 12px">${canImg ? tl("fb.pop.di", {v: esc(D.ver || "")}) : tl("fb.pop.d", {v: esc(D.ver || "")})}</p>
    <form class="fbf" novalidate>
    <textarea class="fbta" id="fb-t" rows="5" maxlength="5000" placeholder="${tl("fb.pop.ph")}" aria-label="${tl("fb.pop.ph")}">${esc(st.text)}</textarea>
    ${canImg ? `<div class="fbimgs" id="fb-i"></div><input type="file" id="fb-f" accept="image/png,image/jpeg,image/gif,image/webp" multiple hidden>` : ""}
    <div class="fbl"><label for="fb-m">${tl("fb.pop.mail")}</label></div>
    <input class="fbin" id="fb-m" type="email" inputmode="email" autocomplete="email" spellcheck="false" maxlength="200" placeholder="name@example.com" value="${esc(st.mail)}">
    <div class="cf-acts"><button type="submit" class="btn xl fill press" id="fb-go">${tl("fb.pop.go")}</button><button type="button" class="btn xl press" data-sclose>${tl("fb.pop.cancel")}</button></div>
    <button type="button" class="lnk press fbalt" id="fb-page">${tl("fb.pop.page")}</button></form>`, (el) => {
    const ta = el.querySelector("#fb-t"), mail = el.querySelector("#fb-m"), go = el.querySelector("#fb-go"), form = el.querySelector(".fbf");
    const keep = () => { try { localStorage.setItem(FB_DRAFT, JSON.stringify(st)); } catch (e) { /* storage off */ } };
    const paint = () => { go.disabled = !st.text.trim(); };
    paint();
    ta.oninput = () => { st.text = ta.value; keep(); paint(); };
    mail.oninput = () => { st.mail = mail.value; keep(); };
    el.querySelector("#fb-page").onclick = () => fbPage();
    if (canImg) {
      const box = el.querySelector("#fb-i"), pick = el.querySelector("#fb-f");
      const draw = () => { box.innerHTML = imgs.map((m, i) => `<span class="fbim"><img src="${m.url}" alt=""><button type="button" class="press" data-del="${i}" title="${tl("fb.pop.imgdel")}" aria-label="${tl("fb.pop.imgdel")}">${ic("x")}</button></span>`).join("")
        + (imgs.length < FB_IMG_MAX ? `<button type="button" class="fbadd press" id="fb-add" title="${esc(tl("fb.pop.img"))}">${ic("image")}<span>${tl("fb.pop.img")}</span></button>${imgs.length || !wide() ? "" : `<span class="fbhint">${tl("fb.pop.imgd")}</span>`}` : ""); };
      const add = (files) => { for (const f of files) {
        if (!/^image\/(png|jpeg|gif|webp)$/.test(f.type)) continue;
        if (imgs.length >= FB_IMG_MAX) { toast(tl("fb.pop.imgmax")); break; }
        if (f.size > FB_IMG_BYTES) { toast(tl("fb.pop.imgbig")); continue; }
        const m = {url: URL.createObjectURL(f), data: ""}; imgs.push(m);
        const fr = new FileReader(); fr.onload = () => { m.data = String(fr.result).split(",")[1] || ""; }; fr.readAsDataURL(f);
      } draw(); };
      draw();
      box.onclick = (e) => { const x = e.target.closest("[data-del]");
        if (x) { URL.revokeObjectURL(imgs.splice(+x.dataset.del, 1)[0].url); draw(); } else if (e.target.closest("#fb-add")) pick.click(); };
      pick.onchange = () => { add(pick.files); pick.value = ""; };
      // Ctrl+V anywhere in the popup, or a drop on it: pictures only, text pastes as usual.
      el.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith("image/")); if (fs.length) { e.preventDefault(); add(fs); } });
      const over = (on) => form.classList.toggle("drop", on);
      el.addEventListener("dragover", (e) => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); e.stopPropagation(); over(true); } });
      el.addEventListener("dragleave", (e) => { if (!el.contains(e.relatedTarget)) over(false); });
      el.addEventListener("drop", (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); e.stopPropagation(); over(false); add(e.dataTransfer.files); });
    }
    form.onsubmit = (e) => { e.preventDefault(); if (go.disabled) return;
      if (imgs.some((m) => !m.data)) return;   // a picture still being read: the next press sends it
      go.disabled = true; go.textContent = tl("fb.pop.going");
      post("/api/feedback-send", {text: st.text, mail: st.mail.trim(), ...(imgs.length ? {images: imgs.map((m) => ({data: m.data}))} : {})})
        .then(() => { try { localStorage.removeItem(FB_DRAFT); } catch (x) { /* storage off */ } imgs.forEach((m) => URL.revokeObjectURL(m.url)); closeSheet(); toast(tl("fb.pop.done")); })
        .catch((x) => { go.textContent = tl("fb.pop.go"); go.disabled = false; toast(x.message); }); };
    if (wide()) ta.focus();
  });
}
document.addEventListener("click", (e) => {
  if (!e.target.closest?.("[data-feedback]")) return;
  e.preventDefault(); fbSheet();
});
// Ctrl/Cmd K opens search from anywhere, like refern's Ctrl K hint on the home search box.
addEventListener("keydown", (e) => {
  if (FLOAT) return;
  if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
    if (e.target.closest?.("input,textarea,[contenteditable]")) return;
    e.preventDefault(); search(true);
  }
});

// The menu on the left folds to its icons (as Linear and Slack do), so the conversation or
// the result being looked at gets the width. "[" does the same from the keyboard.
// Three states, one key: v2-railmin is "0" (full), "2" (icons only) or "1" (hidden: the value a
// fold wrote before there were three, so a menu that was folded stays folded). The toolbar button
// and "[" switch full <-> icons; the border handle, the 보기 menu and "{" hide it altogether, and
// showing it again brings back the shape it had (v2-railwas).
// A window that never chose starts on the icons: each one names itself on hover (railTip).
const railState = (v) => { try {
  const c = compact();
  if (v === undefined) { const s = localStorage.getItem(railKey()) || "2"; return s === "1" ? "off" : c ? railPeek ? "full" : "icons" : s === "2" ? "icons" : "full"; }
  if (c) railPeek = v === "full";
  if (v === "off") localStorage.setItem(railKey("was"), !c && railState() === "icons" ? "2" : "0");
  localStorage.setItem(railKey(), v === "off" ? "1" : v === "icons" ? "2" : "0"); } catch { return compact() ? "icons" : "full"; } };
// A compact window (a PC under 1024px) keeps its own choice apart from the wide window's, so
// narrowing the window folds the menu and widening it brings back what the wide window had.
// There the menu is its icons; opened in full it lies over the page for as long as it is used
// (railPeek, never saved) and folds again on a pick, a press outside it or Escape - as Slack and
// Notion do in a narrow window.
let railPeek = false;
const railKey = (k) => "v2-rail" + (k || "min") + (compact() ? "-c" : "");
const railMin = () => railState() === "off";
// The menu shows its icons; its names come on from 설정 > 화면 > 배치 (kept per device).
const navLabels = (v) => { try { if (v !== undefined) localStorage.setItem("genok-navlb", v ? "1" : "0"); return localStorage.getItem("genok-navlb") === "1"; } catch (e) { return !!v; } };
const railRoom = () => railState() === "full" && !compact() ? 216 : 72;   // what the menu takes from the page, about
const railTip = () => { const s = railState(); return s === "full" ? tl("ui.tb.railIcons") : s === "off" ? tl("ui.tb.railShow") : tl("ui.tb.railFull"); };
const railMark = () => { const s = railState(); document.body.classList.toggle("railmin", s === "off"); document.body.classList.toggle("railico", s === "icons"); };
railMark();
function setRail(s) { railState(s); railMark();
  // Keep the toolbar toggle honest (the toolbar is not re-rendered on toggle).
  document.querySelectorAll("[data-railmin]").forEach((b) => { b.setAttribute("aria-expanded", String(s === "full")); b.setAttribute("aria-label", railTip()); b.title = railTip() + " ( [ )"; });
  railTipOff(); drawChrome(); setClw(clw()); window.LOOP_FOLDS?.(); }
function toggleRail() { const s = railState(); setRail(s === "off" ? railWas() : s === "full" ? "icons" : "full"); }
const railWas = () => { try { return compact() || localStorage.getItem(railKey("was")) === "2" ? "icons" : "full"; } catch { return "full"; } };
const railUnpeek = () => { if (railPeek) setRail("icons"); };
document.addEventListener("pointerdown", (e) => { if (railPeek && !e.target.closest?.("#rail,[data-railmin],[data-edge]")) railUnpeek(); }, true);
addEventListener("hashchange", railUnpeek);
// Escape folds the menu and nothing else: on a result it would also go back.
addEventListener("keydown", (e) => { if (e.key === "Escape" && railPeek) { e.stopImmediatePropagation(); e.preventDefault(); railUnpeek(); } }, true);
function railHide(on) { if (on === undefined) on = !railMin(); if (on !== railMin()) setRail(on ? "off" : railWas()); }
// Icons only: a row's name is its tooltip, on hover and on keyboard focus (the native title waits
// a second and never shows for the keyboard). One tip, placed beside the row.
const railTipOff = () => document.querySelectorAll(".railtip").forEach((t) => t.remove());
function railTipOn(b) {
  railTipOff(); if (!b || !document.body.classList.contains("railico") || !wide() || !b.dataset.tip) return;
  const t = document.createElement("div"), r = b.getBoundingClientRect(); t.className = "gatip railtip"; t.setAttribute("role", "tooltip"); t.textContent = b.dataset.tip;
  document.body.appendChild(t);
  t.style.left = r.right + 10 + "px"; t.style.top = Math.max(8, Math.min(innerHeight - t.offsetHeight - 8, r.top + r.height / 2 - t.offsetHeight / 2)) + "px";
}
const railRow = (e) => e.target.closest?.("#rail .it");
document.addEventListener("mouseover", (e) => { const b = railRow(e); if (b) railTipOn(b); else railTipOff(); });
document.addEventListener("focusin", (e) => { const b = railRow(e); if (b && b.matches(":focus-visible")) railTipOn(b); else railTipOff(); });
document.addEventListener("pointerdown", railTipOff, true);
// Icons only: the names are not on screen, so a row carries its name (and its count) for a screen
// reader and for the tip above instead of a native title, which would come up on top of the tip.
const railIco = () => railState() === "icons" && wide();
const rn = (t, n) => railIco() ? ` data-tip="${t}" aria-label="${t}${n ? " " + n : ""}"` : ` title="${t}"`;
// Not named chrome(): a global function by that name replaces window.chrome, and with it
// window.chrome.webview, which is the pywebview bridge (every window.pywebview.api call fails).
// Lab 3: the kit's own shell, its left capsule menu and right capsule column, stands around Genok's pages.
// Lab 3: every inner screen wears the kit's own classes (glass card, pill, list row) on top of its
// markup, so the kit stylesheet paints it while the screen keeps its handlers.
let k3obs = null;
// Lab 3, PC: the bell opens the kit's notification drawer over the page instead of leaving it -
// what waits on me by kind, then the latest news. Rows are ordinary [data-go]/[data-item] controls.
function kitBell(from) {
  const old = document.getElementById("k3bell"); if (old) { old.k3shut(); return; }
  const T = todoSecs().filter((s) => secN(s)), N = newsList().slice(0, 6);
  const d = document.createElement("aside"); d.id = "k3bell"; d.className = "glass-drawer k3bell"; d.setAttribute("aria-label", tl("TABS.1"));
  d.innerHTML = `<div class="drawer-header"><span class="drawer-title">${tl("TABS.1")}</span><button class="drawer-close-btn press" data-k3bx aria-label="${tl("ui.close")}">${ic("x")}</button></div>
    <div class="drawer-list">${T.length ? `<div class="k3bh">${tl("bell.todo")}</div>` : ""}${T.map((s) => `<button class="drawer-item unread press" data-go="inbox" data-k="${s.k}"><span class="k3bi">${ic(s.i)}</span><span class="tx"><div class="drawer-item-title">${esc(s.n)}</div><div class="drawer-item-desc">${esc(String(s.peek(s.L[0]) || ""))}</div></span><b class="num">${secN(s)}</b></button>`).join("")
    }${N.length ? `<div class="k3bh">${tl("bell.news")}</div>` : ""}${N.map((a) => `<button class="drawer-item news${newsNew(a) ? " unread" : ""} press" ${a.item ? `data-item="${esc(a.item)}"` : `data-go="inbox/news"`}><span class="k3bi">${ic(a.i)}</span><span class="tx"><div class="drawer-item-title">${esc(a.t)}</div><div class="drawer-item-desc">${esc(a.s || "")}</div></span><span class="drawer-item-time">${ago(a.at)}</span></button>`).join("")
    }${T.length || N.length ? "" : `<div class="drawer-item-desc">${tl("bell.none")}</div>`}</div>
    <button class="btn k3bellall press" data-go="inbox">${tl("itemView.31")}</button>`;
  // Opens under the bell that was pressed: 홈's own header sits lower than the toolbar.
  if (from) d.style.top = Math.round(from.getBoundingClientRect().bottom + 14) + "px";
  document.body.append(d);
  const shut = () => { d.remove(); document.removeEventListener("keydown", key, true); document.removeEventListener("mousedown", out, true); };
  d.k3shut = shut;
  const key = (e) => { if (e.key === "Escape") { e.stopPropagation(); shut(); } };
  // A press outside only closes: the click that follows is swallowed, so it cannot open what lay under it.
  const out = (e) => { if (d.contains(e.target) || e.target.closest("[data-bell]")) return; shut();
    const eat = (c) => { c.preventDefault(); c.stopPropagation(); }; document.addEventListener("click", eat, {capture: true, once: true});
    setTimeout(() => document.removeEventListener("click", eat, true), 400); };
  document.addEventListener("keydown", key, true); document.addEventListener("mousedown", out, true);
  d.addEventListener("click", (e) => { if (e.target.closest("[data-k3bx],[data-go],[data-item]")) setTimeout(shut, 0); });
}
if (LAB3) document.addEventListener("click", (e) => { const b = e.target.closest("#top [data-bell],.d2-header [data-bell]"); if (!b || !wide()) return;
  e.preventDefault(); e.stopPropagation(); kitBell(b); }, true);
function kitDress() {
  const v = V(); if (!v) return;
  v.querySelectorAll(":is(.card,.set,.uz-panel,.hsv):not(.glass-card)").forEach((e) => e.classList.add("glass-card"));
  v.querySelectorAll(".row:not(.video-row-item)").forEach((e) => e.classList.add("video-row-item"));
  v.querySelectorAll(".cnrow:not(.drawer-item)").forEach((e) => e.classList.add("drawer-item"));
  v.querySelectorAll(".chip").forEach((e) => { if (!e.classList.contains("category-pill")) e.classList.add("category-pill");
    const on = e.classList.contains("on"); if (on !== e.classList.contains("active")) e.classList.toggle("active", on); });
}
function drawKit() {
  if (!k3obs && V()) { k3obs = new MutationObserver(kitDress); k3obs.observe(V(), {childList: true, subtree: true, attributes: true, attributeFilter: ["class"]}); kitDress(); }
  const app = document.querySelector(".app"); if (!app) return;
  let L = document.getElementById("k3l"), R = document.getElementById("k3r");
  if (!L) { L = document.createElement("aside"); L.id = "k3l"; L.className = "d2-sidebar-left"; app.prepend(L);
    R = document.createElement("aside"); R.id = "k3r"; R.className = "d2-sidebar-right"; app.append(R);
    R.addEventListener("click", (e) => { if (k3skip) return;
      const b = e.target.closest("[data-k3n]"); if (b) return srShow(b.dataset.k3k, b.dataset.k3n);
      if (e.target.closest("[data-k3set]")) return kitPins();
      if (e.target.closest("[data-k3next]")) { const r = unreadRooms()[0]; if (!r) return toast(tl("nextUnread.none")); if (srOpen !== r.key) srShow(r.key, r.dept); } });
    kitSort(R);
    kitTip(L); kitTip(R);
    const logo = (on) => (e) => { const b = e.target.closest?.(".d2-logo-wrap"); if (b && !b.contains(e.relatedTarget)) kitLogo(b, on); };
    L.addEventListener("mouseover", logo(true)); L.addEventListener("mouseout", logo(false));
    L.addEventListener("focusin", logo(true)); L.addEventListener("focusout", logo(false)); }
  if (k3d && k3d.on) return;                       // a drag in progress keeps its buttons
  const at = detail ? "lib" : cur, name = (k) => (MENUS.find((m) => m.k === k) || {}).n || "";
  // Home carries the one count that needs the person (지금 필요한 일's 결정), in the muted accent.
  const need = window.GQ ? GQ.count() : 0;
  const nb = (k, i, t) => `<button type="button" class="d2-nav-btn${at === k ? " active" : ""}" data-go="${k}" data-tip="${esc(t)}" aria-label="${esc(t + (k === "home" && need ? " " + need : ""))}"${at === k ? ' aria-current="page"' : ""}>${ic(i, "d2-nav-icon")}${k === "home" && need ? `<b class="k3need num" aria-hidden="true">${need > 9 ? "9+" : need}</b>` : ""}${RD && navLabels() ? `<span class="rdlb" aria-hidden="true">${esc(t)}</span>` : ""}</button>`;
  L.setAttribute("aria-label", tl("MENUS.1"));
  setHTML(L, `<button type="button" class="d2-logo-wrap" data-go="home" title="Genok" aria-label="Genok">${brandMark(24)}</button>`
    + `<nav class="d2-left-nav">${nb("home", "home", name("home"))}${nb("project", "chat", name("project"))}${nb("lib", "lib", name("lib"))}${typeof SCREENS.usage === "function" ? nb("usage", "chart", ((window.LOOP_TABS || []).find((t) => t.id === "usage") || {}).label || "") : ""}${nb("settings", "gear", name("settings"))}</nav>`
    + `<div class="d2-left-bottom">${fbUrl() ? fbLink("d2-nav-btn k3fb", ic("megaphone", "d2-nav-icon"), tl("fb.send")) : ""}${D.ver ? `<button type="button" class="d2-nav-btn k3ver press" data-stupd title="${esc(tl("upd.check"))} · v${esc(D.ver)}" aria-label="${esc(tl("upd.check"))}">${ic("dl", "d2-nav-icon")}${updOn() ? `<i class="k3vdot"></i>` : ""}</button>` : ""}<button type="button" class="d2-plus-btn" data-go="depts" title="${esc(name("depts"))}" aria-label="${esc(name("depts"))}">${ic("plus", "d2-nav-icon")}</button></div>`);
  // pinned projects first, each with its chat's state; then the other live chats, then the rest of the projects
  // A department's face wears its most pressing session (srRooms puts those first).
  // Beta "pai" off: no live counts, and the map keeps the last session per department as before.
  const pai = window.genokBeta?.("pai"), SRR = srRooms(), LV = pai ? stLive(SRR) : {}, PJ = projects(), who = [], seen = new Set();
  const rm = pai ? new Map() : new Map(SRR.map((q) => [q.r.dept, q]));
  if (pai) SRR.forEach((q) => { if (!rm.has(q.r.dept)) rm.set(q.r.dept, q); });
  const sel = k3Sel(), add = (n, icon, q) => { if (seen.has(n) || who.length >= (sel ? K3MAX : 9)) return; seen.add(n);
    who.push({n, icon, s: k3S(q), key: q ? q.r.key : ""}); };
  const named = (n) => { const q = rm.get(n), g = PJ.find((x) => x.name === n); if (q || g) add(n, (q && q.r.icon) || (g && g.icon) || "", q); };
  if (sel) sel.forEach(named);
  else rm.forEach((q, n) => { if (K3LIVE(q.s)) add(n, q.r.icon, q); });
  const unread = unreadRooms().length;
  R.setAttribute("aria-label", tl("srail.label"));
  setHTML(R, `<button type="button" class="d2-social-top-avatar" data-k3next data-tip="${esc(tl("k3.next"))}" aria-label="${esc(tl("k3.next") + (unread ? " " + unread : ""))}">${ic("chat", "d2-social-icon")}${unread ? `<b class="k3cnt num">${unread > 9 ? "9+" : unread}</b>` : ""}</button>`
    + `<div class="d2-friends-list">${who.map((w) => { const lv = liveText(LV[w.n]), t = pname(w.n) + (lv ? " · " + lv : w.s ? " · " + SR_T[w.s] : "");
      return `<button type="button" class="d2-friend-avatar-wrap${srOpen === (w.key || "d:" + w.n) ? " on" : ""}" data-k3n="${esc(w.n)}" data-k3k="${esc(w.key)}" data-s="${w.s}" data-tip="${esc(pname(w.n))}"${lv ? ` data-live="${esc(lv)}"` : ""} aria-label="${esc(t)}"><span class="d2-friend-img"${k3Col(w.n)}>${k3Face(w.n, w.icon)}</span></button>`; }).join("")}</div>`
    + `<div class="d2-social-bottom"><button type="button" class="d2-social-icon-btn" data-go="project" data-tip="${esc(name("project"))}" aria-label="${esc(name("project"))}">${ic("rooms", "d2-social-icon")}</button><button type="button" class="d2-social-icon-btn" data-k3set data-tip="${esc(tl("k3.pins.set"))}" aria-label="${esc(tl("k3.pins.set"))}">${ic("sliders", "d2-social-icon")}</button></div>`);
  srHeadSync();
}
// Lab 3: the logo's ring turns while the pointer rests on it (or it has the keyboard) and stills
// when it leaves. The still mark is the ring's own logo frame, so the two cross-fade in place.
function kitLogo(b, on) { b.classList.toggle("spin", !!on && !RM()); }
// Lab 3: which conversations stand in the right column, and in what order. Nothing stored = the
// automatic list (pinned projects, then live chats, then the rest). Once the person picks or
// drags, the list is theirs: project names in their order, kept in this window ("genok-k3r").
const K3MAX = 12, K3LIVE = (s) => s === "work" || s === "ask" || s === "stuck";
// The state a column icon wears: none for a session that has ended (it was shown as 대기, the
// same as one that is up and waiting).
const k3S = (q) => (q && !(q.s === "idle" && (q.r.state === "ended" || q.r.job === "stopped")) ? q.s : "");
// 작업 중 N · 나를 기다림 N (web/status.js stLive): the rail's label and the department lists' line.
const liveText = (c) => c ? [c.work ? tl("dlive.work", {n: c.work}) : "", c.ask ? tl("dlive.ask", {n: c.ask}) : ""].filter(Boolean).join(" · ") : "";
const liveTag = (n) => { if (!window.genokBeta?.("pai")) return ""; const c = stLive(srRooms())[n], t = liveText(c);
  return t ? `<span class="dlive" data-s="${c.ask ? "ask" : "work"}"><i aria-hidden="true"></i>${esc(t)}</span>` : ""; };
// A face in the right column: the icon chosen for the project (a drawn one takes its colour).
// Name label beside a column icon, in place of the browser's own tooltip. It fades in where it stands.
function kitTip(col) {
  let tip = null, at = null;
  const off = () => { at = null; if (tip) tip.classList.remove("on"); };
  col.addEventListener("pointerover", (e) => { let b = e.pointerType === "touch" ? null : e.target.closest("[data-tip]");
    if (b && b.querySelector(".rdlb")) b = null;      // a menu button that shows its name needs no label beside it
    if (!b || col.classList.contains("sorting")) return off(); if (b === at) return;
    if (!tip) { tip = document.createElement("div"); tip.className = "k3tip"; tip.setAttribute("aria-hidden", "true"); document.body.append(tip); }
    at = b; const s = b.dataset.s, r = b.getBoundingClientRect(), c = col.getBoundingClientRect(), left = col.id === "k3l";
    const st = b.dataset.live || (s && SR_T[s]) || "";
    tip.innerHTML = `${s ? `<i data-s="${esc(s)}"></i>` : ""}<span>${esc(b.dataset.tip)}</span>${st ? `<em>${esc(st)}</em>` : ""}`;
    tip.style.top = Math.round(r.top + r.height / 2) + "px";
    tip.style.left = left ? Math.round(c.right + 8) + "px" : ""; tip.style.right = left ? "" : Math.round(innerWidth - c.left + 8) + "px";
    tip.classList.add("on"); });
  col.addEventListener("pointerleave", off); col.addEventListener("pointerdown", off);
}
const k3Face = (n, emoji) => identFace(n, emoji) || ic("folder", "d2-social-icon");
const k3Col = (n) => { const c = D.ident?.[n]?.color; return c && /^#[0-9a-f]{3,8}$/i.test(c) ? ` style="color:${c}"` : ""; };
window.k3FaceSet = (n) => { const b = [...document.querySelectorAll("#k3r [data-k3n]")].find((x) => x.dataset.k3n === n), f = b && b.querySelector(".d2-friend-img"); if (!f) return;
  const i = D.ident?.[n] || {}; f.innerHTML = k3Face(n, i.emoji || ""); f.style.color = i.color && /^#[0-9a-f]{3,8}$/i.test(i.color) ? i.color : ""; };
function k3Sel(v) { try {
  if (v === undefined) { const a = JSON.parse(localStorage.getItem("genok-k3r") || "null"); return Array.isArray(a) ? a.filter((x) => typeof x === "string") : null; }
  if (v) localStorage.setItem("genok-k3r", JSON.stringify(v)); else localStorage.removeItem("genok-k3r"); } catch (e) { /* stays automatic */ } return v || null; }
// Dragging a face up or down the column moves it there. The face follows the pointer 1:1 from
// where it was grabbed, the others step aside, and letting go settles it into its slot.
let k3d = null, k3skip = false;
function kitSort(R) {
  const STEP = 44;                                   // a face and the gap under it
  R.addEventListener("pointerdown", (e) => { const b = e.target.closest("[data-k3n]"); if (b && !e.button) k3d = {b, id: e.pointerId, x0: e.clientX, y0: e.clientY, on: false}; });
  // On the window, not the column: a quick pull sideways leaves the column before the face is held.
  addEventListener("pointermove", (e) => { const d = k3d; if (!d || e.pointerId !== d.id) return;
    const dy = e.clientY - d.y0, dx = e.clientX - d.x0;
    if (!d.on) { if (Math.hypot(dx, dy) < 6) return;
      d.on = true; d.L = [...R.querySelectorAll("[data-k3n]")]; d.i = d.j = d.L.indexOf(d.b);
      d.b.setPointerCapture(e.pointerId); srClose(); R.classList.add("sorting"); d.b.classList.add("drag"); }
    // Pulled sideways it leaves the column, and let go outside the window it becomes a floating card.
    const far = Math.abs(dx) > 28;
    d.out = e.clientX < 0 || e.clientY < 0 || e.clientX > innerWidth || e.clientY > innerHeight;
    d.b.style.transform = `translate(${far ? dx : 0}px,${dy}px)`; d.b.classList.toggle("away", far);
    if (far) { d.j = d.i; d.L.forEach((x) => { if (x !== d.b) x.style.transform = ""; }); return; }
    d.j = Math.max(0, Math.min(d.L.length - 1, d.i + Math.round(dy / STEP)));
    d.L.forEach((x, n) => { if (x === d.b) return;
      const sh = d.i < d.j && n > d.i && n <= d.j ? -STEP : d.i > d.j && n >= d.j && n < d.i ? STEP : 0;
      x.style.transform = sh ? `translateY(${sh}px)` : ""; }); });
  const drop = (e) => { const d = k3d; if (!d || e.pointerId !== d.id) return; k3d = null; if (!d.on) return;
    k3skip = true; setTimeout(() => { k3skip = false; }, 80);          // the click that ends a drag opens nothing
    const names = d.L.map((x) => x.dataset.k3n);
    if (e.type === "pointerup" && d.out) k3Float(d.b);
    if (e.type === "pointerup" && d.j !== d.i) { names.splice(d.j, 0, names.splice(d.i, 1)[0]); k3Sel(names); }
    else d.j = d.i;
    const end = () => { R.classList.remove("sorting"); drawKit(); };
    if (RM()) return end();
    d.b.classList.remove("drag"); d.b.style.transform = `translateY(${(d.j - d.i) * STEP}px)`; setTimeout(end, 200); };
  addEventListener("pointerup", drop); addEventListener("pointercancel", drop);
}
// A face let go outside the window: its conversation goes up as a floating card (floatwin.py).
async function k3Float(b) {
  const key = b.dataset.k3k || "", sid = key.replace(/^[a-z]:/, ""), F = window.GenokFloat;
  if (!sid) return toast(tl("k3.float.none"));
  const q = srRooms().find((x) => x.r.key === key), meta = {name: b.dataset.k3n, title: (q && q.r.title) || b.dataset.k3n, agent: (q && q.r.agent) || "claude"};
  try {
    const r = F && F.set ? await F.set(sid, true, meta) : await post("/api/float/pin", Object.assign({sid, on: true, open: true}, meta));
    toast(!r || r.opened ? tl("fl.pinned") : r.native ? tl("fl.openFail") : tl("fl.noApp"));
  } catch (e) { toast(e.message); }
}
// The sliders at the foot of the column: choose which conversations stand there.
function kitPins() {
  const pai = window.genokBeta?.("pai"), rm = pai ? new Map() : new Map(srRooms().map((q) => [q.r.dept, q])), PJ = projects(), all = [], seen = new Set();
  if (pai) srRooms().forEach((q) => { if (!rm.has(q.r.dept)) rm.set(q.r.dept, q); });
  const put = (n, icon) => { if (!seen.has(n)) { seen.add(n); all.push({n, icon}); } };
  (k3Sel() || []).forEach((n) => { const q = rm.get(n), g = PJ.find((x) => x.name === n); if (q || g) put(n, (q && q.r.icon) || (g && g.icon) || ""); });
  rm.forEach((q, n) => put(n, q.r.icon)); PJ.forEach((g) => put(g.name, g.icon));
  const live = () => all.filter((x) => rm.get(x.n) && K3LIVE(rm.get(x.n).s)).map((x) => x.n).slice(0, K3MAX);
  let auto = !k3Sel(), pick = auto ? live() : k3Sel().filter((n) => seen.has(n));
  sheet(`<h2 style="margin:0 0 4px">${tl("k3.pins.t")}</h2><p class="hint" style="margin:0 0 10px">${tl("k3.pins.d")}</p>
    <div class="k3ptop"><span class="k3pn num" data-k3cnt></span><span class="sp"></span><button type="button" class="btn sm press" data-k3none>${tl("k3.pins.none")}</button></div>
    <div class="k3pins">${all.map((a) => { const q = rm.get(a.n);
      return `<button type="button" class="k3prow press" role="checkbox" data-k3p="${esc(a.n)}"><span class="ico sm"${k3Col(a.n)}>${k3Face(a.n, a.icon)}</span><span class="t">${esc(pname(a.n))}</span>${k3S(q) ? `<span class="s" data-s="${q.s}">${esc(SR_T[q.s])}</span>` : ""}<i class="k3chk">${ic("check")}</i></button>`; }).join("")}</div>
    <div class="cf-acts"><button class="btn xl fill press" data-k3done>${tl("lib.fil.done")}</button><button class="btn xl press" data-k3auto aria-pressed="false">${tl("k3.pins.auto")}</button></div>`, (el) => {
    const mark = () => { el.querySelectorAll("[data-k3p]").forEach((b) => b.setAttribute("aria-checked", String(pick.includes(b.dataset.k3p))));
      el.querySelector("[data-k3cnt]").textContent = auto ? tl("k3.pins.autoOn") : pick.length + " / " + K3MAX;
      el.querySelector("[data-k3auto]").setAttribute("aria-pressed", String(auto));
      el.querySelector("[data-k3none]").disabled = !pick.length; };
    mark();
    // Press and sweep down the list: every row passed takes the first row's new state.
    let sw = null;
    const set = (n, on) => { if (on === pick.includes(n)) return true;
      if (!on) pick = pick.filter((x) => x !== n);
      else if (pick.length >= K3MAX) return false;
      else pick.push(n);
      auto = false; return true; };
    const list = el.querySelector(".k3pins");
    list.addEventListener("pointerdown", (e) => { const b = e.target.closest("[data-k3p]"); if (!b || e.button) return;
      sw = {on: !pick.includes(b.dataset.k3p), y: e.clientY, moved: false}; });
    list.addEventListener("pointermove", (e) => { if (!sw || e.pointerType === "touch") return;
      if (!sw.moved && Math.abs(e.clientY - sw.y) < 8) return;
      sw.moved = true; const b = document.elementFromPoint(e.clientX, e.clientY)?.closest?.("[data-k3p]");
      if (b && list.contains(b) && set(b.dataset.k3p, sw.on)) mark(); });
    el.addEventListener("pointerup", () => setTimeout(() => { sw = null; })); el.addEventListener("pointercancel", () => { sw = null; });
    list.onclick = (e) => { const b = e.target.closest("[data-k3p]"); if (!b) return;
      if (sw && sw.moved) return;   // the sweep already set it
      const n = b.dataset.k3p;
      if (!set(n, !pick.includes(n))) return toast(tl("k3.pins.max", {n: K3MAX}));
      mark(); };
    el.querySelector("[data-k3none]").onclick = () => { pick = []; auto = false; mark(); };
    el.querySelector("[data-k3auto]").onclick = () => { auto = true; pick = live(); mark(); };
    el.querySelector("[data-k3done]").onclick = () => { k3Sel(auto || !pick.length ? null : pick); closeSheet(); drawKit(); };
  });
}
function drawChrome() {
  drawSrail(); if (LAB3) drawKit();
  window.GQ?.fab();   // the phone's 다음 button (web/queue.js)
  // Keyboard: the first Tab offers a jump past the side menu to the page itself.
  const sk = document.getElementById("skip");
  if (sk) sk.textContent = tl("a11y.skip");   // every draw: follows a language switch
  if (sk && !sk.onclick) { sk.onclick = () => { const v = document.getElementById("view"); v.tabIndex = -1; v.focus({preventScroll: true}); }; }
  if (document.querySelector("#rail .sorting")) return;   // a drag in progress keeps its rows
  const todo = todoCount(), news = newsUnread();
  // The tab says it too: the number for 할 것, a dot for unread 소식 only (as on the 받은함 tab).
  const title = todo ? `(${todo}) Genok` : news ? "• Genok" : "Genok";
  if (document.title !== title) document.title = title;
  markIcon(todo, news, badgeCount());
  barBadge(todo);
  document.querySelectorAll("#top [data-bell]").forEach((b) => { const h = bellOnly();      // serialised html never equals its source (attribute order, icons): compare as nodes
    const t = document.createElement("template"); innerSet.call(t, h); if (!t.content.firstElementChild?.isEqualNode(b)) b.outerHTML = h; });
  const on = (k) => !detail && menuKey(cur) === k || detail?.[0] === "item" && k === "lib" || detail?.[0] === "dept" && k === "depts";
  // The 대화 tab carries what its menu row does: how many rooms have a reply not read yet (quiet,
  // the red number is the bell's). A screen that has a tab of its own is not listed again after it.
  const xt = extTabs(), rooms = unreadRooms().length;
  // The 결과물 tab does the same for results: how many sit in 새로 온 것 (the list it opens on).
  const fresh = D.items.filter((x) => stOf(x) === "fresh" && !libHide.has(iid(x))).length;
  const cnt = (k) => k === "project" ? rooms : k === "lib" ? fresh : 0;
  // 전체 (the right end) holds what has no tab of its own: the other screens, extensions, usage, settings.
  const inAll = !detail && (["all", "settings", "depts", "routines", "retro"].includes(menuKey(cur)) || tabExt(xt).some((t) => t.id === cur));
  setHTML(document.getElementById("tabbar"), TABS.map(([k, n, i]) => {
    const lit = k === "all" ? inAll : on(k);
    const c = cnt(k);
    return `<button class="${lit ? "on" : ""}" data-go="${k}"${c ? ` aria-label="${esc(n)} ${c}"` : ""}>${ic(i)}${n}${c ? `<b class="tcnt soft num">${c > 99 ? "99+" : c}</b>` : ""}</button>`; }).join(""));
  const rail = document.getElementById("rail");
  const pj = projects();
  // Extension screens turned off in the menu editor (web/custom.js) are out of the rail too.
  const MH = window.LOOP_MENUHIDE, xr = xt.filter((t) => !MENUS.some((m) => m.k === t.id) && !(MH && MH.ext(t.id)));
  // The projects are one plain row that opens their list (no block of rows in the menu): it carries
  // how many results in them wait to be checked.
  const need = pj.reduce((s, g) => s + g.todo, 0);
  // No wordmark at the top of the menu (the name lives in the window title and 정보): the toggles in the top bar come first.
  setHTML(rail, ""
    // Groups carry no titles: a gap tells them apart. Hiding and restoring entries is in 설정 (사용 방식 > 메뉴).
    + menuGroups().map(([g, L]) => [g, L.filter((m) => !(m.k === "settings" && settingsAtFoot()) && !(m.k === "search" && wide()))]).filter(([, L]) => L.length).map(([g, L]) => `<div class="rgrp" ${g === favTitle() ? `data-sort="favs"` : ""}>` + L.map((m) => {
      const mine = m.k === "project" ? rooms : m.k === "lib" ? fresh : m.k === "depts" ? need : 0;
      return `<button class="it press ${on(m.k) ? "on" : ""} ${m.plan ? "soon" : ""}" data-key="${m.k}" data-go="${m.k}"${m.k === FAV_LOCK ? " data-fixed" : ""}${rn(esc(m.n), mine)}>${menuIco(m, "ri")}<span class="mn">${m.n}</span>${mine ? `<small class="cnt num" title="${esc(m.k === "depts" ? tl("home.g.n", {n: mine}) : m.k === "lib" ? `${tl("st.fresh")} ${mine}` : tl("chrome.unreadRooms", {n: mine}))}">${mine}</small>` : m.plan ? `<small>${tl("chrome.2")}</small>` : ""}${favBtn(m.k, "inrow")}</button>`; }).join("") + "</div>").join("")
    // Extension screens (window.LOOP_TABS) get their own group in the sidebar, routed like the rest.
    + (xr.length ? `<div class="rgrp">` + xr.map((t) => `<button class="it press ${on(t.id) ? "on" : ""}" data-key="${esc(t.id)}" data-go="${esc(t.id)}"${rn(esc(t.label))}><span class="ri">${ic(t.icon)}</span><span class="mn">${esc(t.label)}</span></button>`).join("") + "</div>" : "")
    // The sidebar is folded from the refern-style toolbar toggle (data-railmin) and "[", so the
    // old in-rail "메뉴 접기" text item is gone — one control, no duplicate.
    + `<div class="foot2 railend">${tl("ui.end")}</div>`
    // 설정 is pinned to the foot, away from the rows that get clicked all day; it stays in view
    // while the list above scrolls.
    + (settingsAtFoot() ? `<div class="railfoot"><button class="it press ${on("settings") ? "on" : ""}" data-key="settings" data-go="settings"${rn(tl("TABS.4"))}><span class="ri">${ic("gear")}</span><span class="mn">${tl("TABS.4")}</span></button>${railIco() ? "" : `<button class="railver press num" data-stupd title="${tl("upd.check")}" aria-label="${tl("upd.check")}">${esc(D.ver ? planVer() : "")}</button>`}</div>` : ""));
  rail.querySelectorAll("[data-sort]").forEach((b) => sortable(b, (keys) => reorder(b.dataset.sort, keys), true));
  drawStatus();
}
// The favicon and the installed app's icon carry the same signal: a red dot (and the app badge's
// number) while 할 것 has something, a quieter dot for unread 소식 alone. Drawn only on change.
let iconSvg = null, iconMark = "";
// The app's taskbar button carries 할 것's number too (taskbar.py): told only when it changes.
let barN = -1;
function barBadge(n) { if (!IN_APP || n === barN) return; barN = n; post("/api/taskbar/badge", {n}).catch(() => { barN = -1; }); }
function markIcon(todo, news, badge = todo) {
  const want = todo ? "todo" : news ? "news" : "";
  try { if (navigator.setAppBadge) badge ? navigator.setAppBadge(badge).catch(() => {}) : navigator.clearAppBadge().catch(() => {}); } catch {}
  if (want === iconMark) return; iconMark = want;
  const link = document.querySelector('link[rel="icon"]'); if (!link) return;
  if (!want) { link.href = "/icon.svg"; return; }
  const put = () => { if (iconMark !== want || !iconSvg) return;
    const dot = `<circle cx="206" cy="50" r="${want === "todo" ? 50 : 36}" fill="${want === "todo" ? "#ff3b30" : "#0a84ff"}" stroke="#0b0b0c" stroke-width="12"/>`;
    link.href = "data:image/svg+xml," + encodeURIComponent(iconSvg.replace(/<\/svg>\s*$/, dot + "</svg>")); };
  if (iconSvg) return put();
  fetch("/icon.svg").then((r) => r.ok ? r.text() : null).then((t) => { if (t) { iconSvg = t; put(); } }).catch(() => {});
}
