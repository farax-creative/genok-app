// Genok web UI, cut from project.js: a line of mine edited and sent again, the branches that opens, a new answer.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- 갈래 ---------------------------------------------------------------------------------------
  // The server forks the conversation just before the line (branches.py) and leaves the old one as
  // it was. The page asks once per change which lines can be edited and where branches part, and
  // draws a pencil on those lines, ‹ i/n › under a line that has branches and 다시 받기 on the last
  // answer. Within one chat only attributes and the small rows change; moving to another branch
  // opens that branch's own chat, which keeps the lines the two share (brKeep). Pictures the line carries go with
  // it: the server reads them back from the record, the editor changes only the words.
  const edBtn = () => `<button type="button" class="pj-ed press" aria-label="${tl("br.edit")}" title="${tl("br.edit")}">${ic("pen")}</button>`;
  const rgBtn = () => `<button type="button" class="pj-rg press" aria-label="${tl("br.regen")}" title="${tl("br.regen")}">${ic("loop")}</button>`;
  const BR_WHY = {version: () => tl("br.why.version"), exec: () => tl("br.why.exec")};
  const brWhy = (v, busy) => BR_WHY[v.editable.why] ? BR_WHY[v.editable.why]() : busy ? tl("br.why.busy") : "";
  const brBusy = (c) => !!(c.br && c.br.editable.busy) || !!(c.state && c.state.busy) || !!c.sending;
  // Bumped on every move between branches: an edit or a new answer changes the family of the chat
  // it came from too, so each chat asks again when it is shown next.
  let brGen = 0;

  function brRows(box, c) {
    const sid = c.sid; if (!sid || !c.loaded) return;
    const sig = sid + "|" + c.entries.length + "|" + !!(c.state && c.state.busy) + "|" + brGen;
    if (c.brSig !== sig) { c.brSig = sig; brLoad(c, sid); }
    if (c.br && c.br.sid === sid) brDraw(box, c);
  }
  async function brLoad(c, sid) {
    let v; try { v = await loopFetch("/api/session/branches?id=" + enc(sid)); } catch (e) { return; }
    if (c.sid !== sid || !v || !v.editable) return;
    v.sid = sid; c.br = v;
    const box = c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"); if (box) brDraw(box, c);
  }
  const setAttr = (n, k, v) => { if (v == null) { if (n.hasAttribute(k)) n.removeAttribute(k); } else if (n.getAttribute(k) !== v) n.setAttribute(k, v); };
  const setTip = (b, t) => { if (b && b.title !== t) { b.title = t; b.setAttribute("aria-label", t); } };

  function brDraw(box, c) {
    const v = c.br, keys = new Set(v.keys), dim = brWhy(v, brBusy(c)), gone = v.editable.why === "exec";
    const mine = box.querySelectorAll(":scope>.pj-msg.user[data-key]");
    mine.forEach((n) => {
      const on = gone || !keys.has(n.dataset.key) ? null : dim ? "dim" : "1";
      setAttr(n, "data-ed", on);
      const b = n.querySelector(":scope>.pj-ed"); if (b) { setTip(b, on === "dim" ? dim : tl("br.edit")); setAttr(b, "aria-disabled", on === "dim" ? "true" : null); }
    });
    // ‹ i/n › under each line where branches part
    const want = new Map(v.points.map((p) => [p.key, p]));
    box.querySelectorAll(":scope>.pj-br").forEach((r) => { const p = want.get(r.dataset.for), n = r.previousElementSibling;
      if (!p || !n || n.dataset.key !== p.key && !n.classList.contains("pj-edit")) r.remove(); });
    mine.forEach((n) => {
      const p = want.get(n.dataset.key); if (!p) return;
      let r = n.nextElementSibling; if (r && r.classList.contains("pj-edit")) r = r.nextElementSibling;
      const sig = [p.i, p.n, p.prev, p.next].join("|");
      if (r && r.classList.contains("pj-br") && r.dataset.for === p.key) { if (r.dataset.sig === sig) return; r.remove(); }
      n.insertAdjacentHTML("afterend", brHtml(p, sig));
    });
    // 다시 받기 on the last answer, when the line it answers can be edited
    const last = [...box.querySelectorAll(":scope>.pj-msg.claude:not([data-pend])")].pop();
    let ask = null;
    for (let n = last && last.previousElementSibling; n; n = n.previousElementSibling) if (n.matches(".pj-msg.user")) { ask = n; break; }
    const rg = last && ask && ask.dataset.key && !gone && keys.has(ask.dataset.key) && !last.nextElementSibling?.matches?.(".pj-msg.user") ? (dim ? "dim" : "1") : null;
    box.querySelectorAll(":scope>.pj-msg.claude[data-rg]").forEach((n) => { if (n !== last || !rg) { n.removeAttribute("data-rg"); const b = n.querySelector(":scope>.pj-rg"); if (b) b.remove(); } });
    if (rg) {
      setAttr(last, "data-rg", rg);
      let b = last.querySelector(":scope>.pj-rg"); if (!b) { last.insertAdjacentHTML("beforeend", rgBtn()); b = last.querySelector(":scope>.pj-rg"); }
      setTip(b, rg === "dim" ? dim : tl("br.regen")); setAttr(b, "aria-disabled", rg === "dim" ? "true" : null);
      last.dataset.rgFor = ask.dataset.key;
    }
  }
  const brHtml = (p, sig) => `<div class="pj-br in" data-for="${esc(p.key)}" data-sig="${esc(sig)}" role="group" aria-label="${tl("br.group", {i: p.i, n: p.n})}">`
    + `<button type="button" class="press" data-brgo="${esc(p.prev || "")}"${p.prev ? "" : " disabled"} aria-label="${tl("br.prev")}" title="${tl("br.prev")}">‹</button>`
    + `<span>${p.i}/${p.n}</span>`
    + `<button type="button" class="press" data-brgo="${esc(p.next || "")}"${p.next ? "" : " disabled"} aria-label="${tl("br.next")}" title="${tl("br.next")}">›</button></div>`;

  // The chat on the screen moves to another branch of the same family; the address names it, so a
  // reload comes back to it. In the several-chat view only this pane's place in the list changes.
  // The lines both branches share are not drawn again: paint() of the chat it opens takes them
  // over as they stand (brTake), and a switch keeps the log where it was, so ‹ › stays under the
  // pointer. The address is replaced, as moves between results are: back leaves the conversation.
  function brGo(from, to, box, keep) {
    const w = where(); brGen++;
    if (box) brKeep(box, to, keep);
    if (w.name === MULTI) return location.replace("#project/" + MULTI + "/" + w.sid.split(",").map((x) => enc(x === from ? to : x)).join(","));
    location.replace("#project/" + enc(w.name) + "/" + enc(to));
  }

  // ---- the shared lines, carried over ---------------------------------------------------------------
  // paint() marks the nodes each line of the record drew (brMark) with the line's identity: what
  // was said, by whom, when, and its id - the same in every branch that holds it. Where a line sits
  // in a record (data-ln) differs between branches, so that is put right on the carried node.
  let brCarry = null;                                  // {to, lines: Map(key -> nodes), until} until that chat paints
  const brLineKey = (e) => [e.kind, e.at || "", e.key || e.id || "", e.text || ""].join("\u0001");
  function brMark(box, end, now, k) {
    const ns = [];
    for (let n = end ? end.nextElementSibling : box.firstElementChild; n && n !== now; n = n.nextElementSibling) ns.push(n);
    ns.forEach((n) => { n._br = [k, ns]; });
  }
  function brLines(box) {
    const got = new Map();
    for (const n of box.children) {
      const g = n._br; if (!g || g[1][0] !== n || !g[1].every((x) => x.parentNode === box)) continue;
      g[1].forEach((x) => { x.style.display = ""; x.classList.remove("tap"); x.querySelectorAll(":scope>.tg.ok").forEach((t) => t.remove());
        if (box._ro) box._ro.unobserve(x); x._ro = 0; });
      got.set(g[0], g[1]);
    }
    return got;
  }
  function brKeep(box, to, keep) {
    brCarry = {to, lines: brLines(box), until: performance.now() + 10000};
    if (keep) C(to).pos = spot(box, false);
  }
  // The chat `c` takes what a move left for it. The read right after a chat shown from memory
  // draws the log whole again: within a moment of the move that read keeps the same nodes too.
  function brTake(c, box) {
    if (brCarry && performance.now() > brCarry.until) brCarry = null;     // that chat never opened
    if (brCarry && brCarry.to === c.sid) { const m = brCarry.lines; brCarry = null; box._brOwn = performance.now() + 5000; return m; }
    if (box._brOwn && performance.now() < box._brOwn) { box._brOwn = 0; return brLines(box); }
    return null;
  }
  function brReline(ns, e) {
    ns.forEach((n) => { if (n.dataset.ln != null && e.line != null && n.dataset.ln !== String(+e.line)) n.dataset.ln = String(+e.line); });
  }

  // ---- editing in place ---------------------------------------------------------------------------
  const brEntry = (c, key) => c.entries.find((e) => e.kind === "user" && e.key === key);
  // The branch forks only the conversation: files Claude edited after the line stay as they are
  // now. The paths its edit calls named after `key` (a call that came back with an error changed nothing).
  function brLeft(entries, key) {
    const at = entries.findIndex((e) => e.kind === "user" && e.key === key); if (at < 0) return [];
    const bad = new Set(entries.filter((e) => e.kind === "res" && e.err).map((e) => e.id));
    const out = [];
    entries.slice(at + 1).forEach((e) => {
      if (e.kind === "tool" && e.cat === "edit" && e.what && !bad.has(e.id) && !bad.has(String(e.id || "").replace(/:\d+$/, "")) && !out.includes(e.what)) out.push(e.what);
    });
    return out;
  }
  const brLeftHtml = (paths) => !paths.length ? "" : `<div class="left">${tl("br.left", {n: paths.length})} `
    + paths.slice(0, 3).map((p) => `<span title="${esc(Redact.show(p))}">${esc(Redact.show(p.split(/[\\/]/).pop()))}</span>`).join(", ")
    + (paths.length > 3 ? " " + tl("br.left.more", {n: paths.length - 3}) : "") + `</div>`;
  function brShut(box) {
    box.querySelectorAll(":scope>.pj-edit").forEach((ed) => { const n = ed.previousElementSibling; if (n) n.style.display = ""; ed.remove(); });
  }
  function brEdit(box, n) {
    const c = box._c, b = n.querySelector(":scope>.pj-ed");
    if (n.dataset.ed === "dim") { toast(b.title); return; }
    const e = brEntry(c, n.dataset.key); if (!e) { toast(tl("br.why.moved")); return; }
    brShut(box);
    const raw = unnote(e.text), clips = raw.split("\n").filter((l) => l.trim().startsWith(CLIP)), pics = (e.imgs || []).length > 0;
    n.insertAdjacentHTML("afterend", `<div class="pj-edit in"><textarea rows="1" aria-label="${tl("br.edit")}" enterkeyhint="send"></textarea>`
      + brLeftHtml(brLeft(c.entries, n.dataset.key)) + `<div class="acts"><span class="why${pics ? "" : " keys"}">${pics ? tl("br.pics") : tl("br.hint")}</span><button type="button" class="pj-btn press" data-brx>${tl("br.cancel")}</button>`
      + `<button type="button" class="pj-btn light press" data-brok>${tl("br.send")}</button></div></div>`);
    const ed = n.nextElementSibling, ta = ed.querySelector("textarea"), ok = ed.querySelector("[data-brok]");
    ta.value = parts(raw).words.trim();
    n.style.display = "none";
    const grow = () => { ta.style.height = "auto"; ta.style.height = ta.scrollHeight + "px"; ok.disabled = !ta.value.trim() && !pics && !clips.length; };
    const shut = () => { brShut(box); n.classList.remove("tap"); b.focus({preventScroll: true}); };
    const go = async () => {
      const words = ta.value.trim(); if (ok.disabled) return;
      if (words === parts(raw).words.trim()) { shut(); return; }
      // The fork waits for Claude to start (seconds on a cold CLI): the button says it is on its way.
      const x = ed.querySelector("[data-brx]");
      ok.disabled = true; ta.readOnly = true; x.disabled = true;
      ok.setAttribute("aria-busy", "true"); ok.innerHTML = `<span class="pj-spin" aria-hidden="true"></span>${tl("room.sending")}`;
      if (!await brSend(c, n, [words, ...clips].filter(Boolean).join("\n"), false)) {
        ok.disabled = false; ta.readOnly = false; x.disabled = false; ok.removeAttribute("aria-busy"); ok.textContent = tl("br.send");
      }
    };
    ta.addEventListener("input", grow);
    ta.addEventListener("keydown", (k) => {
      if (k.isComposing || k.keyCode === 229) return;
      if (k.key === "Escape") { k.preventDefault(); k.stopPropagation(); shut(); }
      else if (k.key === "Enter" && !k.shiftKey && !k.altKey && !k.ctrlKey && !k.metaKey) { k.preventDefault(); go(); }
    });
    ed.querySelector("[data-brx]").onclick = shut;
    ok.onclick = go;
    grow(); ta.focus({preventScroll: true}); ta.setSelectionRange(ta.value.length, ta.value.length);
  }
  // Sent: the new branch opens with the line on its way in it; the old one stays as it was.
  async function brSend(c, n, text, regen) {
    const sid = c.sid, key = n.dataset.key, line = +n.dataset.ln;
    let r;
    try { r = await act("/api/session/edit", regen ? {sid, key, line, regen: true} : {sid, key, line, text}); }
    catch (err) { if (err.message !== "cancelled") toast(err.message); return false; }
    if (!r || !r.sid) return false;
    const e = brEntry(c, key) || {}, said = regen ? unnote(e.text) : text, nc = C(r.sid);
    // The pictures went with the line: they show on its way in, at the addresses the old chat had.
    nc.pend.push({text: said, said, imgs: (e.imgs || []).map((url) => ({url})), tag: tl("room.sent"), busy: false, kept: true, route: r.routed, at: Date.now()});
    nc.waiting = true; nc.stick = true;
    ansMark(r.sid, true);
    brGo(sid, r.sid, c.body && c.body.isConnected && c.body.querySelector("#pj-msgs"));     // the new branch and its ‹ i/n › say what happened: no toast over the page

    return true;
  }

  // One listener for every chat on the page: the buttons are drawn inside the log.
  document.addEventListener("click", (e) => {
    const t = e.target.closest && e.target.closest(".pj-ed,.pj-rg,[data-brgo],.pj-msg.user[data-ed]");
    const box = t && t.closest("#pj-msgs"); if (!box || !box._c) return;
    const c = box._c;
    if (t.matches(".pj-ed")) { e.preventDefault(); brEdit(box, t.parentNode); return; }
    if (t.matches(".pj-rg")) {
      e.preventDefault();
      const m = t.parentNode, n = m.dataset.rgFor && box.querySelector(`:scope>.pj-msg.user[data-key="${CSS.escape(m.dataset.rgFor)}"]`);
      if (m.dataset.rg === "dim") { toast(t.title); return; }
      if (n && !t.disabled) { t.disabled = true; brSend(c, n, "", true).then((ok) => { if (!ok) t.disabled = false; }); }
      return;
    }
    if (t.matches("[data-brgo]")) {
      e.preventDefault();
      const to = t.dataset.brgo, from = c.sid; if (!to || t.disabled) return;
      loopFetch("/api/session/branch-pick", {method: "POST", json: {sid: to}}).catch(() => {});
      brGo(from, to, box, true);
      return;
    }
    // A finger has no hover: a tap on a line of mine shows its pencil, the next tap elsewhere hides it.
    if (matchMedia("(pointer:coarse)").matches && !e.target.closest("a,button,img,.pj-pic")) {
      const on = !t.classList.contains("tap");
      box.querySelectorAll(":scope>.pj-msg.tap").forEach((x) => x.classList.remove("tap"));
      t.classList.toggle("tap", on);
    }
  });
  document.addEventListener("mousedown", (e) => { if (e.target.closest && e.target.closest(".pj-ed,.pj-rg,[data-brgo]")) e.preventDefault(); });
