// Genok web UI, cut from project.js: the line just sent, the live tail, and joining the app (the last part).
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- what is happening to the line just sent ---------------------------------------------------
  // One line under the newest: on its way, held, or what the session is on right now (the step
  // its own record names, see sessions_ctl.step_of) with how long the turn has taken. Only what
  // is known is said. The answer arrives above it, in its place.
  const NOW_FAST = 30000, STEPS = {think: () => tl("pj.now.think"), run: () => tl("pj.now.run"), read: () => tl("pj.now.read"), edit: () => tl("pj.now.edit"),
    search: () => tl("pj.now.search"), web: () => tl("pj.now.web"), agent: () => tl("pj.now.agent"), write: () => tl("pj.now.write"),
    tool: (s) => s.name ? tl("pj.now.tool", {name: s.name}) : tl("pj.now.tool0")};
  function nowOf(c) {
    const st = c.state || {}, live = st.state === "live", p = [...c.pend].reverse().find((x) => !x.failed);
    if (p && p.busy && !live) return {text: tl("pj.now.sending"), at: p.at};
    if (c.fail && !live) return {text: c.fail, still: true, bad: true};      // the last line failed after it was taken
    if (live) {
      const s = st.step, say = s && Object.prototype.hasOwnProperty.call(STEPS, s.kind) ? STEPS[s.kind] : null;
      return {text: say ? say(s) : tl("pj.st.live"), what: (s && s.what) || "", at: c.turnAt};
    }
    // The session is holding the line for review: one press lets it take such lines at once.
    if ((p && p.route === "held") || c.queued.some((q) => q.held)) return st.peer_accept ? {text: tl("pj.now.heldOn"), still: true} : {text: tl("pj.now.heldBy"), still: true, accept: true};
    // Resting with a command of its own still running: it is not stopped for a line, so say why the answer waits.
    if (st.shell) return {text: p && p.route === "hook" ? tl("pj.now.shellHeld") : tl("pj.now.shell"), still: true};
    if (p && p.route === "hook") return {text: tl("pj.now.held"), still: true};
    if (p && p.route === "wake") return {text: tl("pj.now.wake"), at: p.at};
    // Once the session was seen working on it and rests again, the answer is on its way to the page.
    if ((p && (p.route === "live" || p.route === "native")) || (c.waiting && st.state !== "ended" && !c.sawLive)) return {text: tl("pj.now.sent"), at: c.turnAt || (p && p.at)};
    return null;
  }
  function nowSec(el) {
    const s = el._at ? Math.floor((Date.now() - el._at) / 1000) : 0;
    const t = s < 1 ? "" : " · " + (s < 60 ? tl("pj.now.sec", {n: s}) : tl("pj.now.min", {m: Math.floor(s / 60), n: s % 60}));
    // A room's first answer waits for the session to start; say so once the wait is noticeable.
    const hint = el._first && s >= 5 ? " · " + tl("pj.now.first") : "";
    if (el.lastChild.textContent !== t + hint) el.lastChild.textContent = t + hint;
  }
  function nowLine(box, c) {
    const n = nowOf(c);
    let el = box.querySelector(":scope>.pj-now");
    if (!n) { if (!c.pend.length && !c.waiting) c.turnAt = 0; if (el) el.classList.remove("on"); return; }
    if (!el) { box.insertAdjacentHTML("beforeend", `<div class="pj-now" role="status" aria-live="off"><span class="mk keys" aria-hidden="true"></span><span class="tx"></span><span class="nsec" aria-hidden="true"></span></div>`); el = box.lastElementChild; }
    const mk = el.firstChild, tx = mk.nextSibling, k = n.bad ? "b" : n.still ? "s" : "m";
    el.classList.toggle("bad", !!n.bad);
    // The app's own activity mark (orb.js): it moves only while something is really on its way.
    if (mk.dataset.k !== k) { mk.dataset.k = k; mk.innerHTML = n.bad ? ic("warn") : n.still ? `<rl-orb state="breathing" size="20" px="14" paused aria-label=""></rl-orb>`
      : `<i class="st-dot"></i>`; }
    const html = esc(n.text) + (n.what ? `<span> · ${esc(Redact.show(n.what))}</span>` : "") + (n.accept ? ` <button type="button" class="btn sm press" data-peeraccept>${tl("pj.now.accept")}</button>` : "");
    if (tx._h !== html) {
      const was = tx._h; tx._h = html; tx.innerHTML = html;
      if (was && el.classList.contains("on") && tx.animate) tx.animate([{opacity: .3}, {opacity: 1}], {duration: 180, easing: "ease-out"});
    }
    const acc = tx.querySelector("[data-peeraccept]");
    if (acc && !acc.onclick) acc.onclick = async () => {
      acc.disabled = true;
      try {
        const r = await loopFetch("/api/peer/accept", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({place: (c.state || {}).project || ""})});
        const j = await r.json().catch(() => ({}));
        if (j.need_consent) return;               // the person said "not now"
        toast(j.result === "written" ? tl("pj.now.acceptDone") : tl("pj.now.acceptFail"));
        if (j.result === "written") c.pend.forEach((p) => { if (p.route === "held") p.route = "live"; });
        if (c.kick) c.kick();
      } catch (e) { toast(e.message); }
      finally { if (acc.isConnected) acc.disabled = false; }
    };
    el._at = n.at || 0; el._first = !n.bad && (n.text === tl("pj.now.wake") || !c.entries.some((e) => e.kind !== "user"));
    el.classList.add("on"); nowSec(el);
  }
  // ---- the answer while it is being written (Codex, Claude in host mode) ------------------------------
  // One bubble over the line under the log, growing as the answer is written (/api/project/draft). It gives
  // way to the record's own line once the tail has it: any answer read in after this one began,
  // or, for one already done when first seen, the newest answer starting with the same words.
  const DRAFT_MS = 150;
  // An answer already over (not `live`) is still given out for a few seconds (claude_host.DRAFT_AFTER).
  // One that ended before the oldest Claude line on its way was sent is the last one's, not that line's
  // first words (after a stop that ended the process, the old answer showed as the new one); one that
  // ended after it is a short new answer and is taken, as is any once this line's turn was seen live.
  // `age` (seconds since it ended) is counted back from `now`, when the draft was asked: the server
  // answered later than that, so the end is never placed later than it was, whatever the network adds.
  const staleDraft = (c, d, now) => { const on = c.pend.filter((p) => !p.failed);
    return !!(d && d.key && d.live === false && on.length && !c.sawLive && !(c.stream && c.stream.key === d.key)
      && now - (d.age || 0) * 1000 < Math.min(...on.map((p) => p.at))); };
  // chat-stream:begin
  function streamTake(c, d) {
    const was = c.stream;
    // Asked with `from`, a Claude host answers only the text past it: joined onto what the bubble holds.
    if (d && d.add != null) {
      if (!was || was.key !== d.key || d.from > was.text.length) return false;
      d = {key: d.key, text: was.text.slice(0, d.from) + d.add, done: d.done};
    }
    if (!d || !d.key || !d.text || d.key === c.streamGone) { c.stream = null; return !!was; }
    if (was && was.key === d.key && was.text === d.text && was.done === d.done) return false;
    c.stream = was && was.key === d.key ? Object.assign({}, was, {text: d.text, done: d.done}) : {key: d.key, text: d.text, done: d.done, from: c.entries.length};
    return true;
  }
  function streamLanded(c, d) {
    if (c.entries.slice(d.from).some((e) => e.kind === "claude" && !e.error)) return true;
    if (!d.done) return false;
    const last = [...c.entries].reverse().find((e) => e.kind === "claude"), head = d.text.trim().slice(0, 40);
    return !!(last && head && String(last.text || "").trim().startsWith(head));
  }
  // Where the settled part of a growing answer ends: just after the last finished blank line
  // outside a code fence, read on from `from` (such a point). No block of markdown.js runs across
  // that line, so the part before it never changes as more is written.
  function streamCut(text, from) {
    let cut = from, fence = "";
    for (let at = from, nl; (nl = text.indexOf("\n", at)) >= 0; at = nl + 1) {
      const l = text.slice(at, nl).trim();
      // Same rule as markdown.js: a fence closes only on a bare run of its own character, as long or longer.
      const f = (/^(`{3,}|~{3,})/.exec(l) || [])[1];
      if (f && !fence) fence = f;
      else if (f && f === l && f[0] === fence[0] && f.length >= fence.length) fence = "";
      else if (!l && !fence) cut = nl + 1;
    }
    return cut;
  }
  // chat-stream:end
  // The bubble's markdown is drawn once per settled piece; each new draft redraws only what
  // follows the last cut (the block being written), so the blocks above keep their nodes, scroll
  // and selection. A draft that is not the last one grown, plain text, or 가림 모드 switched, is drawn whole.
  function streamDraw(el, t) {
    let art = el._head != null && el._rd === Redact.on() && t.startsWith(el._head) ? el.firstElementChild : null;
    if (!art) {
      el._head = null;
      if (!(typeof looksMarkdown === "function" && looksMarkdown(Redact.show(t)))) { el.innerHTML = marked(t); return; }
      el.textContent = ""; art = el.appendChild(mdNode("")); el._head = ""; el._n = 0; el._rd = Redact.on();
    }
    const piece = (a, b) => Redact.show(a ? t.slice(a, b) : t.slice(0, b).trimStart());
    const old = art.childNodes.length > el._n && art.lastElementChild, sx = old && old.matches(".pj-prew") ? old.firstElementChild.scrollLeft : 0;
    while (art.childNodes.length > el._n) art.lastChild.remove();
    const from = el._head.length, cut = streamCut(t, from);
    if (cut > from) { art.append(...mdNode(piece(from, cut)).childNodes); el._head = t.slice(0, cut); el._n = art.childNodes.length; }
    art.append(...mdNode(piece(cut, t.length).trimEnd()).childNodes);
    if (sx && art.lastElementChild.matches(".pj-prew")) art.lastElementChild.firstElementChild.scrollLeft = sx;
  }
  function streamRow(box, c) {
    if (c.stream && streamLanded(c, c.stream)) { c.streamGone = c.stream.key; c.stream = null; }
    let el = box.querySelector(":scope>.pj-stream");
    if (!c.stream) { if (el) el.remove(); return; }
    const now = box.querySelector(":scope>.pj-now");
    if (!el) { el = document.createElement("div"); el.className = "pj-msg claude pj-stream"; el.setAttribute("aria-busy", "true"); }
    if (now ? el.nextElementSibling !== now : el !== box.lastElementChild) { if (now) now.before(el); else box.append(el); }
    if (el._t !== c.stream.text) { el._t = c.stream.text; streamDraw(el, c.stream.text); }
    if (box._ro && !el._ro) { el._ro = 1; box._ro.observe(el, {box: "border-box"}); }   // keeps the end in view while it grows
  }
  // Paint the conversation from cache. `all` repaints; otherwise only the tail after `from` is added.
  // Scroll rules: a repaint lands where the person left off (or on the newest); new lines follow
  // the end only while they are at the end, otherwise the way-down button carries their count.
  // Tail/state updates wait while text is selected, then catch up from the earliest queued offset.
  document.addEventListener("selectionchange", () => {
    document.querySelectorAll("#pj-msgs").forEach((box) => {
      const p = box._selectionPaint;
      if (!p || selectedText(box)) return;
      delete box._selectionPaint;
      if (p.body.isConnected) paint(p.body, p.c, p.all, p.from);
    });
  });
  // 가림 모드 changed (here, in settings or in another window): every chat on the page is drawn
  // again from what it holds, and the line over its box says the mode is on.
  document.addEventListener("redact", () => Object.values(convs).forEach((c) => {
    if (!c.body || !c.body.isConnected) return;
    const rd = c.body.querySelector("#pj-rd"); if (rd) rd.hidden = !Redact.on();
    paint(c.body, c, true);
  }));
  document.addEventListener("redact", () => { if (location.hash.startsWith("#project")) render(); });   // the lists beside the chats
  document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("[data-unmask]")) Redact.set(false); });
  // A chat opened again is drawn from its newest lines, like its first look: everything the tail
  // gathered while it was open (thousands of lines froze the page for a second) waits behind the
  // "older" row. The cut is at a line that starts a turn, the only kind that says its byte (`line`),
  // which a read further back starts from; the line being read when the chat was left stays in.
  const KEEP = 200;
  function keepTail(c) {
    if (c.entries.length <= 2 * KEEP) return;
    let i = c.entries.length - KEEP;
    const p = c.pos, at = p && !p.stick && p.at;
    if (at) { const j = c.entries.findIndex((e) => e.at === at); if (j >= 0 && j < i) i = j; }
    while (i > 0 && !(c.entries[i].kind === "user" && c.entries[i].line > 0)) i--;
    if (!i) return;
    c.entries = c.entries.slice(i); c.start = c.entries[0].line;
    if (c.stream && c.stream.from != null) c.stream.from = Math.max(0, c.stream.from - i);
    if (p) delete p.k;                                   // its index counted the lines cut off; `at` finds it
  }
  function paint(body, c, all, from) {
    const box = body.querySelector("#pj-msgs"), st = body.querySelector("#pj-state"), nt = body.querySelector("#pj-note");
    if (st) { const h = pjState(c); if (h !== c.stateHtml) { c.stateHtml = h; st.innerHTML = h; } }
    // The phone's header has no room for "연결을 다시 잡는 중…": it is said over the input box there.
    const pin = body.querySelector(".pj-in"); if (pin && !!c.offline !== ("off" in pin.dataset)) { if (c.offline) pin.dataset.off = tl("pj.offline"); else delete pin.dataset.off; }
    // Written only when it changed: a press on a button in it (허용 / 거부, 새 세션 열기) must not
    // find the button swapped for a new one between the finger going down and coming up.
    if (nt) { const h = note(c); if (h !== c.noteHtml) { const had = !!(document.activeElement && document.activeElement.closest && document.activeElement.closest("#pj-note .pj-why"));
      c.noteHtml = h; nt.innerHTML = h; whyKeep(nt, c, had); } }
    const fb = body.querySelector("#pj-feedback"), records = c.state?.feedback || [];
    // Same here, and for `hidden` above all: the page's `:has([hidden])` rules restyle the whole
    // document on any write to it, even of the value it already had, which a long log felt as a stall.
    if (fb) { if (fb.hidden !== !records.length) fb.hidden = !records.length;
      const sm = fb.querySelector("summary"), smt = tl("pj.feedback.history", {n: records.length}); if (sm.textContent !== smt) sm.textContent = smt;
      const html = records.map((r) => `<div class="pj-feedback-row"><button class="press" data-go="item/${enc(r.project)}/${enc(r.item)}">${esc(r.item)} · ${esc(r.v || "")}</button><p>${esc(r.text)}</p><small>${r.fixed_in ? tl("itemView.7", {esc: esc(r.fixed_in)}) : r.ack ? tl("itemView.122") : r.delivered ? tl("itemView.123") : tl("itemView.125")} · <time data-note-at="${esc(r.at || "")}">${ago(r.at)}</time></small></div>`).join("");
      if (fb.dataset.records !== JSON.stringify(records)) { fb.dataset.records = JSON.stringify(records); fb.querySelector("div").innerHTML = html; }
    }
    const ta = body.querySelector("#pj-ta");
    if (ta) { const ph = body.dataset.ph || (((c.state && c.state.state) === "ended") ? tl("pj.phEnded") : tl("pj.ph")); if (ta.placeholder !== ph) ta.placeholder = ph; }
    if (!box) return;
    if (selectedText(box)) {
      const p = box._selectionPaint;
      box._selectionPaint = {body, c, all: all || !!(p && p.all), from: p ? Math.min(p.from ?? c.entries.length, from ?? c.entries.length) : from};
      return;
    }
    const deferred = box._selectionPaint;
    if (deferred) {
      all = all || deferred.all;
      from = Math.min(deferred.from ?? c.entries.length, from ?? c.entries.length);
      delete box._selectionPaint;
    }
    const stick = !all && c.stick;
    // A move to another branch brings the lines the branches share along as they stand (project-branch.js).
    const brOn = !!window.genokBeta?.("edit"), carry = brOn && all && c.loaded ? brTake(c, box) : null;
    if (all) {
      if (c.loaded && !box.querySelector(":scope>.pj-msg")) keepTail(c);   // a new box; one on screen keeps what it shows
      box.innerHTML = "";
      if (!c.loaded) box.innerHTML = `<div class="pj-empty pj-wait">${loadingHtml(tl(c.offline ? "pj.offline" : "pj.loading"))}</div>`;
      else if (!c.entries.length && !c.pend.length && !c.queued.length) box.innerHTML = `<div class="pj-empty">${tl("pj.empty")}</div>`;
    }
    const empty = box.querySelector(".pj-empty");
    let added = 0;
    const now = box.querySelector(":scope>.pj-now"), put = (html) => now ? now.insertAdjacentHTML("beforebegin", html) : box.insertAdjacentHTML("beforeend", html);
    const add = (html, e) => {
      if (empty && empty.parentNode) empty.remove();
      const k = brOn && e && brLineKey(e), got = k && carry && carry.get(k);
      if (got) { carry.delete(k); got.forEach((n) => box.insertBefore(n, now)); brReline(got, e); }
      else if (k) { const end = now ? now.previousElementSibling : box.lastElementChild; put(html); brMark(box, end, now, k); }
      else put(html);
      added++;
    };
    const fresh = all ? c.entries : c.entries.slice(from);
    let placed = !!box.querySelector(".pj-unread");
    fresh.forEach((e) => {
      if (e.kind === "sub" || e.kind === "res") return;    // no line of its own (see subs, acts)
      if (!placed && c.divTs && e.kind === "claude" && e.at === c.divTs) { add(`<div class="pj-unread">${tl("pj.unread")}</div>`); placed = true; }
      add(bubble(e), e);
      if (e._recv) { const t = setTimeout(() => { e._recv = false; box.querySelectorAll(".tg.ok").forEach((n) => n.remove()); }, 3500); timers.add(t); }
    });
    // pending: lines we sent that are not in the transcript yet, then lines held for the hook.
    // Each stands where it was said: above whatever the session wrote after it, not under it.
    // Drawn again only when something about them changed: the state loop paints every second or
    // three, and a line put back each time restarted its spinner and counted as new to a reader.
    const wrote = [...box.querySelectorAll(".pj-msg.claude[data-at], .pj-msg.tool[data-at]")], ats = wrote.map((n) => n.dataset.at);
    const rows = c.pend.map((p, i) => [pendSlot(ats, p.at), pendRow(p, i), p.at || 0]);
    const held = c.queued.filter((q) => !c.pend.some((p) => sameLine(p.text, q.text))).map((q) =>
      [pendSlot(ats, Date.parse(q.at)), bubble({kind: "user", text: q.text, at: q.at},
        q.fail ? tl("room.failed") + " · " + srvMsg(q.fail) : tl("pj.queued"), q.fail ? " failed" : ""), Date.parse(q.at) || 0]);
    const pkey = JSON.stringify([rows, held]), had = box.querySelectorAll("[data-pend]");
    if (added || pkey !== box._pendKey || had.length !== box._pendN) {
      had.forEach((n) => n.remove());
      // Server-held lines keep their send time too; they must not cover every newer answer.
      rows.concat(held).sort((a, b) => a[2] - b[2]).forEach(([k, html]) => { const before = k < 0 ? null : wrote[k];
        const at = before && before.previousElementSibling && before.previousElementSibling.classList.contains("pj-unread") ? before.previousElementSibling : before;
        if (at) at.insertAdjacentHTML("beforebegin", html); else put(html); });
      box._pendKey = pkey; box._pendN = box.querySelectorAll("[data-pend]").length;
      writeOut(c.out, c.pend);
    }
    nowLine(box, c); streamRow(box, c);
    olderRow(box, c); fold(box); acts(box, c); subs(box, c); resRows(box, c); stamp(box); recap(box, c); markRows(box, c); if (brOn) brRows(box, c); todoStrip(body, c);
    if (added && box._find) box._find();                 // the find bar counts lines that came in while it is open
    if (box._ro) for (const n of box.children) if (!n._ro) { n._ro = 1; box._ro.observe(n, {box: "border-box"}); }
    if (all) {
      const p = c.pos, back = p && !p.stick && c.loaded;
      if (back) seat(box, p);                                          // back where they were reading
      else box.scrollTop = box.scrollHeight;                           // the newest; the "새 글" line stays in the log above it
      c.stick = nearEnd(box);
      if (c.loaded) hold(box, c, back ? p : spot(box, c.stick));
    } else if (stick) {
      box.scrollTop = box.scrollHeight;
      if (c.hold) c.hold = {stick: true};
    } else if (added && fresh.length) {
      c.unseen += fresh.length;
    }
    endBtn(box, c);
  }

  // Sending never waits on the server: the line is in the chat and the box is empty the moment it
  // is sent, and the box takes the next line straight away. The server is asked after that, one
  // line at a time per conversation so they arrive in the order they were typed.
  const MAX_LINE = 12000;                                  // sessions_ctl.MAX_TEXT
  function sendLine(body, s, name, root) {
    const ta = body.querySelector("#pj-ta"), c = C(s.id);
    const said = ta.value.trim(); if (!said && !c.imgs.length) return;
    // Over the server's cap the line would only come back failed: it stays in the box, with how much to cut.
    if (said.length > MAX_LINE) { toast(tl("srv.rooms.23", {a: (said.length - MAX_LINE).toLocaleString(), b: MAX_LINE.toLocaleString()})); return; }
    const p = {text: said, said, imgs: c.imgs.slice(), tag: tl("room.sending"), busy: true, at: Date.now()};
    c.pend.push(p); ta.value = ""; c.draft = ""; writeDraft(s.id, ""); c.imgs = []; chips(body, c);
    if (!c.turnAt) c.turnAt = p.at;
    c.fastUntil = p.at + NOW_FAST; c.sawLive = false; if (c.kick) c.kick(); if (c.dkick) c.dkick();
    c.stick = true; tipOff(); const tp = body.querySelector("#pj-tip"); if (tp) tp.hidden = true;
    paint(body, c, false, c.entries.length); ta.focus({preventScroll: true});
    if (c.sync) c.sync();                                   // the box is one line again at once
    queue(s, c, p);
  }
  // State facts the server only sends while they hold (sessions_ctl): dropped when an answer leaves them out.
  const GONE = ["ask", "cut", "stuck", "stuck_hint", "fail", "shell"];
  // The server says these Codex lines in Korean only; known ones are shown in the page's language.
  const SRV_ASK_GONE = "이미 처리된 요청이에요.";
  const SRV = {"Codex 앱이나 터미널에서 이 대화가 열려 있어요. 거기서 닫고 1분쯤 뒤 다시 보내 주세요.": () => tl("room.srv.elsewhere"),
    "Codex가 허락을 기다리고 있어요. 먼저 [허용]이나 [거절]을 눌러 주세요.": () => tl("room.srv.askFirst"),
    [SRV_ASK_GONE]: () => tl("room.srv.askGone"), "허용했어요. Codex가 이어서 해요.": () => tl("room.srv.allowed"),
    "거절했어요. Codex가 그 일은 하지 않고 이어서 답해요.": () => tl("room.srv.denied")};
  const srvMsg = (t) => t && SRV[t] ? SRV[t]() : srvT(t);
  // A line on its way is an answer: the row is not my-turn from here on (ansMark).
  const queue = (s, c, p) => { ansMark(s.id, true); c.chain =(c.chain || Promise.resolve()).then(() => deliver(s, c, p)); };
  async function deliver(s, c, p) {
    // The page may have been drawn again while this waited: paint whichever chat is up now.
    const show = () => { if (c.body && c.body.isConnected) { paint(c.body, c, false, c.entries.length); if (c.sync) c.sync(); } };
    if (!c.pend.includes(p)) return;                       // taken away while it waited its turn
    p.busy = true; p.failed = ""; p.uncertain = false; p.route = ""; p.tag = tl("room.sending"); c.sending = (c.sending || 0) + 1; show();
    try {
      if (p.imgs.length) {
        const paths = await uploadImgs(p.imgs, s.id);
        p.imgs.forEach((im) => URL.revokeObjectURL(im.url)); p.imgs = [];
        p.text = (p.said || (paths.some((x) => PIC_EXT.test(x)) ? tl("pj.img.look") : tl("pj.file.look"))) + paths.map((x) => "\n" + CLIP + x).join("");
      }
      const r = await act("/api/session/tell", {sid: s.id, text: p.text});
      // A command that ran (/compact): it is not a line of the talk and no answer follows it.
      if (r.routed === "command") { const i = c.pend.indexOf(p); if (i >= 0) c.pend.splice(i, 1); ansMark(s.id, false); toast(tl("pj.cmd.done")); if (c.kick) c.kick(); return; }
      // "보냄" = it reached the session's inbox; the line turns into a normal bubble marked 받음 the
      // moment the session writes it into its transcript.
      p.tag = r.routed === "native" ? tl("pj.native.accepted") : r.routed === "live" ? tl("room.sent") : (r.message || tl("pj.relayed"));
      p.route = r.routed;
      if (r.routed === "live" || r.routed === "native") p.sentAt = Date.now();
      if (s.agent !== "codex" && r.routed !== "hook") c.waiting = true;   // held for the hook = not on its way, no spinner
      if (r.routed !== "live" && r.routed !== "native") toast(r.message || tl("pj.relayed"));
      if (c.kick) c.kick();
    } catch (e) {
      // Nothing typed is lost: the line stays in the chat, marked, with 다시 보내기 on it.
      // Said once: on the line itself while its chat is on screen, as a toast only when it is not.
      p.uncertain = e.code === "delivery_unconfirmed";
      if (!p.uncertain) ansMark(s.id, false);              // it never left: still the person's turn
      p.failed = srvMsg(e.message) || tl("room.failed");
      if (e.message !== "cancelled" && !(c.body && c.body.isConnected)) { if (window.genokBeta?.("pai")) toast(srvMsg(e.message) + (p.uncertain ? "" : "\n" + tl("pj.kept.sent")), 3600); else toast(srvMsg(e.message)); }
      if (p.uncertain) p.failed = tl("pj.delivery.unknown");
    } finally { p.busy = false; c.sending = Math.max(0, (c.sending || 1) - 1); show(); }
  }

  // ---- live tail -------------------------------------------------------------------------------
  // Two loops per open chat. The transcript loop holds a request open on the server (up to 20s)
  // that answers the moment the file gains a complete line, so a reply lands in well under a
  // second and an idle chat costs one request per 20s. The state loop refreshes the session's
  // facts (working / waiting / queued lines) every 3s, and right after the transcript moves.
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function start(body, s, name, my) {
    const c = C(s.id), ac = new AbortController(), run = {body, ac};
    endLoop(body); body._pjRun = run; runs.add(run);
    const alive = () => body._pjRun === run && body.isConnected && !ac.signal.aborted && (my && my.embed ? true : location.hash.startsWith("#project"));
    // The server leaves a fact out once it no longer holds (a Codex request answered, a cut answer
    // taken up again, a login fixed): it must leave this chat too, not linger from an older answer.
    const merge = (st) => { c.state = Object.assign({}, c.state, st); GONE.forEach((k) => { if (!(k in st)) delete c.state[k]; }); c.queued = st.queued || [];
      // A line the app was carrying in that did not make it: the row says so, with 다시 보내기.
      c.queued.forEach((q) => { if (!q.fail) return; const p = c.pend.find((x) => x.text === q.text && !x.failed && !c.sending); if (p) { p.failed = srvMsg(q.fail); p.busy = false; c.waiting = false; } });
      // A line written to the session's inbox that never turned up in its record: it waits for the
      // session's next turn, so the line under the chat says that instead of "sent".
      c.queued.forEach((q) => { if (!q.stuck) return; const p = c.pend.find((x) => x.text === q.text && !x.failed && x.route === "live"); if (p) p.route = q.held ? "held" : "hook"; });
      // Codex is not working and its record never took the line: it did not arrive.
      if (s.agent === "codex") c.pend.forEach((p) => { if (lostLine(p, st, Date.now())) {
        p.uncertain = p.route === "native";
        p.failed = p.uncertain ? tl("pj.delivery.unknown") : tl("room.codexLost");
      } });
      // Codex took the line and the turn failed at once, or a wake with nowhere to hold the line
      // failed: said on the line (다시 보내기) and under the chat.
      c.fail = srvMsg(st.fail && st.fail.text || "");
      if (c.fail && st.state !== "live") { const p = c.pend.find((x) => !x.failed && !x.busy && (x.route === "live" || x.route === "wake")); if (p) p.failed = c.fail; }
      // How long the turn has been going is the server's to say (a turn that began before this page did).
      // A Claude host just began its turn: the answer is asked for now, not after the draft loop's slow wait.
      if (st.state === "live" && st.turn_stop && !c.sawLive && c.dkick) c.dkick();
      if (st.state === "live") c.sawLive = true;
      if (st.state === "live" && st.step && st.step.sec != null) { const t = Date.now() - st.step.sec * 1000; if (!c.turnAt || Math.abs(c.turnAt - t) > 3000) c.turnAt = t; }
      // The list's row says what this header says (one state per conversation).
      if (rowSync && st.found !== false) rowSync(s.id, st);
      if (c.goMode) c.goMode();                               // send turns into 답 멈추기 while an answer is written
      if (c.agKey !== undefined && JSON.stringify(st.agents || []) !== c.agKey) side(sideOf(body), name, c); };
    let lastState = 0;
    async function states() {
      while (alive()) {
        // Side by side, a pane that is not the focused one asks a third as often (new lines still kick it at once).
        await Promise.race([sleep(Date.now() < (c.fastUntil || 0) ? 1000 : body.matches(".pj-pane:not(.focus)") ? 9000 : 3000), new Promise((r) => { c.kick = r; })]);
        if (!alive()) return;
        if (document.hidden || (!streamOn() && Date.now() - lastState < 700)) continue;
        // Asked again within 700ms: once that is over, not at the next 3s (a line sent just after an
        // answer ended kicked into that gap, and its turn showed no 답 멈추기 for seconds).
        const gap = 700 - (Date.now() - lastState);
        if (gap > 0) { await sleep(gap); if (!alive()) return; }
        lastState = Date.now();
        // When it was asked for: a draft asked for later is newer than this (drafts below).
        const at = performance.now();
        try {
          let st = await get("/api/project/session?id=" + enc(s.id));
          // A host's draft asked after this said whether its answer runs: that is newer (a state asked
          // just before a turn began put "보냈어요" back over the words already coming in).
          const dr = c.draftSaid;
          if (dr && dr.at > at && st && st.turn_stop && (st.state === "live") !== dr.live && (dr.live || st.state === "live")) {
            st = Object.assign({}, st, dr.live ? {state: "live", busy: true} : {state: "idle", busy: false});
            if (dr.live) delete st.cut;
          }
          merge(st); c.stateAt = at; paint(body, c, false, c.entries.length);
        }
        catch (e) { /* the transcript loop shows the offline note */ }
      }
    }
    async function tail() {
      let first = true, slow = false;
      while (alive()) {
        if (document.hidden && !first) { await sleep(1000); continue; }
        if (slow) { slow = false; await sleep(body.matches(".pj-pane:not(.focus)") ? 3000 : 1000); if (!alive()) return; }
        // A waiting answer keeps a connection, and the browser has six for the whole app: side by
        // side, HOLD panes wait for their next line; the rest ask instead (the focused one every
        // second, the others every 3s).
        // After a failure the next read asks without waiting: a held one kept "연결을 다시 잡는 중…" up
        // for up to 20s after the connection was back.
        const hold = !first && c.offset != null && holds < HOLD && !c.offline;
        if (hold) holds++;
        try {
          const q = "/api/sessions/transcript?id=" + enc(s.id) + "&agent=" + enc(s.agent)
            + (c.offset != null ? "&offset=" + c.offset + (hold ? "&wait=20" : "") : "");
          let tx, st = null;
          // A later read gives up on its own (a held one is answered within 20s): a connection that
          // died without closing left the chat still, with nothing saying so. The first read has
          // no limit, since it may be waiting on the person's answer to a consent question.
          const one = new AbortController(), stop = () => one.abort();
          ac.signal.addEventListener("abort", stop);
          const limit = first ? 0 : setTimeout(stop, hold ? 30000 : 15000);
          try {
            if (first) [tx, st] = await Promise.all([loopFetch(q, {signal: one.signal}), get("/api/project/session?id=" + enc(s.id))]);
            else tx = await loopFetch(q, {signal: one.signal});
          } finally { if (hold) holds--; clearTimeout(limit); ac.signal.removeEventListener("abort", stop); }
          slow = !first && !hold;
          if (!alive()) return;
          if (c.offline) { c.offline = false; paint(body, c, !c.loaded, c.entries.length); }
          if (st) { merge(st); lastState = Date.now(); }
          if (tx.declined || tx.need_consent) {
            c.loaded = true; paint(body, c, true);
            const b = body.querySelector("#pj-msgs");
            if (b && !c.entries.length) {
              b.innerHTML = `<div class="pj-empty">${tl("pj.needRead")}<br><button class="pj-btn light press" style="margin-top:12px" data-retry>${tl("room.askAgain")}</button></div>`;
              b.querySelector("[data-retry]").onclick = () => draw(body.closest(".pj") || body);
            }
            return;
          }
          if (tx.found === false) {
            if (!c.loaded) { c.loaded = true; paint(body, c, true); const b = body.querySelector("#pj-msgs"); if (b && !c.entries.length) b.innerHTML = `<div class="pj-empty">${tl("pj.noLog")}</div>`; }
            first = false; await sleep(5000); continue;
          }
          const from = c.entries.length, got = tx.entries || [];
          const firstLoad = c.divTs === undefined;
          if (tx.reset || c.offset == null) { c.entries = got; c.start = tx.start || 0; } else if (got.length) c.entries = c.entries.concat(got);
          if (tx.offset != null) c.offset = tx.offset;
          if (tx.results && tx.results.length) c.results = tx.results;
          if (tx.work) c.work = tx.work;
          c.sid = s.id;
          got.forEach((e) => { if (e.kind === "user") { const i = c.pend.findIndex((p) => sameLine(p.text, e.text) && !(p.kept && Date.parse(e.at) < p.at - 60000)); if (i >= 0) { c.pend.splice(i, 1); e._recv = true; } } });
          if (got.some((e) => e.kind === "claude")) c.waiting = false;
          c.loaded = true;
          if (firstLoad) {                       // where the person stopped reading, fixed for this visit
            c.divTs = null;
            if (st && st.read_at) { const f = c.entries.find((e) => e.kind === "claude" && e.at && Date.parse(e.at) > Date.parse(st.read_at)); if (f) c.divTs = f.at; }
          }
          if (first || tx.reset || got.length || c.entries.length < from) {
            paint(body, c, first || tx.reset || c.entries.length < from, from);
            if (first && c.seek) { const k = c.seek, bx = body.querySelector("#pj-msgs"); c.seek = null;
              findOpen(bx.closest(".pj-conv"), k.q); if (k.at) seekLine(bx, c, s, k.side, k.at); }
            markRead(c, s.id);
            side(sideOf(body), name, c);
            if (!first && c.kick) c.kick();
          }
          first = false;
        } catch (e) {
          if (!alive()) return;
          // A record that never arrived is still the first read: the wait says why, and the read
          // that gets through draws the chat whole (it was left saying "불러오는 중" with no end).
          c.offline = true; paint(body, c, !c.loaded, c.entries.length);
          first = first && !c.loaded; await sleep(2000);
        }
      }
    }
    // The seconds on the status line count on their own, between the server's answers.
    (async () => { while (alive()) { await sleep(1000); const n = body.querySelector("#pj-msgs>.pj-now.on"); if (n) nowSec(n); } })();
    // The answer while it is written (Codex, or Claude in host mode: turn_stop): asked often only
    // while a turn runs, a Claude line was just sent and its turn is not seen yet (an ended chat's
    // first line starts a host, and the state loop may say so a second later), or a bubble waits
    // for its record line.
    async function drafts() {
      const busy = () => { const st = c.state || {}, on = s.agent === "codex" || !!st.turn_stop;
        return (on && st.state === "live") || !!c.stream
          || (s.agent !== "codex" && (c.pend.some((p) => !p.failed) || (!c.sawLive && Date.now() < (c.fastUntil || 0)))); };
      while (alive()) {
        await Promise.race([sleep(!busy() ? 1000 : body.matches(".pj-pane:not(.focus)") ? 1000 : DRAFT_MS), new Promise((r) => { c.dkick = r; })]);
        if (!alive()) return;
        if (document.hidden || !busy()) continue;
        try {
          // Only the text past what the bubble holds, while it still grows (a host answers {from, add}).
          const was = c.stream, more = was && !was.done ? "&key=" + enc(was.key) + "&from=" + was.text.length : "";
          const asked = performance.now(), askedAt = Date.now(), d = await get("/api/project/draft?id=" + enc(s.id) + more), box = body.querySelector("#pj-msgs");
          if (s.agent !== "codex" && staleDraft(c, d, askedAt)) continue;
          // Words are coming before the state loop has seen the turn: it asks now, so 답 멈추기 and Esc are there with them.
          if (d && d.live && s.agent !== "codex" && !c.sawLive && c.kick) { lastState = 0; c.kick(); }
          // A Claude host's draft says first whether its answer runs (`live` with its words): send turns into
          // 답 멈추기 with the first words and back the moment the answer ends, not a state poll later
          // (a tap in that second asked to stop an answer that had already ended). A state the state loop
          // asked for after this draft was is newer: the last answer's draft must not end the next turn.
          if (d && d.key && s.agent !== "codex" && c.goMode && !(c.stateAt > asked)) {
            const st = c.state || {}, on = !!d.live;
            c.draftSaid = {at: asked, live: on};
            if (on !== (st.state === "live") && (on || st.turn_stop)) {
              c.state = Object.assign({}, st, on ? {state: "live", busy: true, turn_stop: true} : {state: "idle", busy: false});
              if (on) { delete c.state.cut; c.sawLive = true; }
              c.goMode();
              paint(body, c, false, c.entries.length);           // the header, the note and the line under the chat say so too
              if (!on && c.kick) { lastState = 0; c.kick(); }   // the state loop confirms (a queued line may be next)
            }
          }
          // The tool Claude just picked: only the line under the log changes, before the tool's input is in.
          const k = d && d.step && (c.state || {}).state === "live" ? JSON.stringify([d.step.kind, d.step.name, d.step.what]) : "";
          if (k && k !== c.stepKey) { c.stepKey = k; c.state = Object.assign({}, c.state, {step: d.step}); if (box) nowLine(box, c); }
          if (!streamTake(c, d)) continue;
          if (box && !selectedText(box)) streamRow(box, c);
        } catch (e) { /* the transcript loop shows the offline note */ }
      }
    }
    tail(); states(); if (s.agent === "codex" || streamOn()) drafts();
  }
  // Move the read marker to the newest thing the session said, while the room is open and visible.
  function markRead(c, sid) {
    if (document.hidden) return;
    const last = [...c.entries].reverse().find((e) => e.kind === "claude" && e.at);
    if (!last || last.at === c.readSent) return;
    c.readSent = last.at;
    post("/api/room-read", {key: "c:" + sid, at: last.at}).then(() => {
      // What the list remembers follows too: the row left behind must not turn to 내 차례 again
      // from an answer that was read before the server heard about this.
      Object.keys(projSeen).forEach((n) => { const p = projSeen[n], x = ((p.v && p.v.sessions) || []).find((y) => y.id === sid); if (x && x.unread) { x.unread = 0; p.k = JSON.stringify(p.v); } });
      (roomsCache || []).forEach((r) => { if (r.sid === sid) r.unread = 0; (r.more || []).forEach((m) => { if (m.sid === sid) m.unread = 0; }); });
      // The next-unread jump and the counts read attention's rooms: this one is read now.
      if (typeof att !== "undefined" && att) (att.rooms || []).forEach((r) => { if (r.key === sid) r.unread = 0; });
      if (typeof drawChrome === "function") drawChrome();   // the sidebar's unread pill follows at once
    }).catch(() => { c.readSent = null; });
  }

  // Results this session pushed (with their picture, linked to the result) + the project's open comments.
  function resThumb(r) {
    let it = null;
    try { it = (D.items || []).find((x) => iid(x) === r.project + "/" + r.item); } catch (e) { /* items not loaded yet */ }
    const kind = (it && it.kind) || "doc", k = (typeof KIND !== "undefined" && KIND[kind]) || ["doc"];
    return `<span class="th">${ic(k[0])}${it && it.thumb ? `<img src="${esc(it.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : ""}${kind === "video" && it && it.thumb ? `<span class="play">${ic("play")}</span>` : ""}</span>`;
  }
  function side(box, name, c) {
    if (!box) return;
    let items = [];
    try { items = (D.items || []).filter((x) => x.project === name || (typeof gname === "function" && gname(x) === name)); } catch (e) {}
    const open = items.filter((x) => (x.open || 0) > 0);
    const res = c.results || [];
    const row = (t, sub, go, badge) => `<button class="pj-item press" data-go="${esc(go)}">
      <span class="tx"><div class="t">${esc(t)}</div><div class="s">${esc(sub)}</div></span>${badge ? `<span class="cm">${esc(badge)}</span>` : ""}</button>`;
    const resRow = (r) => `<button class="pj-res press" data-go="${esc("item/" + r.project + "/" + r.item)}" title="${esc(r.title)}">${resThumb(r)}
      <span class="tx"><div class="t">${esc(r.title)}</div><div class="s">${esc(vShort ? vShort(r.v) : r.v)}${r.at ? " · " + esc(ago(r.at)) : ""}</div></span></button>`;
    // X7 agent mode: the role agents working for this head, their state, and 멈추기 where it can stop.
    const ags = (c.state && c.state.agents) || [];
    const canFold = threeCols() && !box.closest("[data-multi]");
    // The panel is shut (its strip, or the other tab): the way in carries how many results were
    // not looked at yet. It moves once, when that number goes up, and then only keeps its colour
    // and the number. Open, the results are in view: they count as looked at.
    const sid = (c.state && c.state.id) || "", shut = canFold ? folded("side") : tab !== "side";
    const nf = shut ? unseenRes(sid, res) : 0, pop = nf > (c.popN || 0);
    c.popN = nf;
    if (!shut && res.length) seeRes(sid, res);
    (!canFold && c.body ? c.body.querySelectorAll(`[data-t="side"]`) : []).forEach((tb) => {
      if (tb.dataset.nf === String(nf)) return;
      tb.dataset.nf = nf;
      tb.innerHTML = (tb.hasAttribute("data-res") ? ic("tray") : tl("pj.tab.side")) + (nf ? `<b class="pj-nb${pop ? " pop" : ""}" aria-label="${esc(tl("pj.res.unseen", {n: nf}))}">${nf}</b>` : "");
    });
    if (canFold && shut) {
      const key = [nf, res.length, open.length].join("/"), tip = (nf ? tl("pj.res.unseen", {n: nf}) + " · " : "") + tl("pj.res.tip", {n: res.length, o: open.length});
      c.agKey = JSON.stringify(ags);
      if (box.dataset.strip === key && box.querySelector(".pj-strip")) return;      // nothing new: a mark in motion is left alone
      box.dataset.strip = key; box.classList.remove("pj-dn1");
      const was = box.firstElementChild && !box.querySelector(":scope>.pj-strip");      // the open panel was there: it was folded just now
      box.innerHTML = `<button class="pj-strip r${was ? " pj-anim" : ""} press${nf ? " new" : ""}${pop ? " pop" : ""}" data-fold="side" aria-expanded="false" aria-label="${esc(tip)}" title="${esc(tip)}">${ICO.panel}<span class="c${nf ? " new" : ""}" aria-hidden="true">${ic("stack")}${nf || res.length ? `<b>${nf || res.length}</b>` : ""}</span><span class="c${open.length ? " hot" : ""}" aria-hidden="true">${ic("chat")}${open.length ? `<b>${open.length}</b>` : ""}</span></button>`;
      return;
    }
    delete box.dataset.strip;
    const rd = folded("rdense");
    box.classList.toggle("pj-dn1", rd);
    const foldBtn = `<span class="sp"></span><button class="pj-fbtn pj-rdn press" data-rdense aria-pressed="${rd}" aria-label="${esc(tl("pj.res.dense"))}" title="${esc(tl("pj.res.dense"))}">${ic("list")}</button>`
      + (canFold ? `<button class="pj-fbtn r press" data-fold="side" aria-expanded="true" aria-label="${esc(tl("pj.side.fold"))}" title="${esc(tl("pj.side.fold"))}">${ICO.panel}</button>` : "");
    const WHY = {inside: [tl("pj.ag.no.inside"), tl("pj.ag.why.inside")], terminal: [tl("pj.ag.no.terminal"), tl("pj.ag.why.terminal")],
      codex: [tl("pj.ag.no.codex"), tl("pj.ag.why.codex")]};
    const agRow = (a) => `<div class="pj-agt"><button class="go press" data-go="${esc(a.inside ? "item/" + a.project + "/" + a.item : "project/" + enc(name) + "/" + enc(a.sid))}">${dot(a.state)}
      <span class="tx"><div class="t">${esc(a.role)}</div><div class="s">${esc(LABEL[a.state] || a.state)} · ${esc(a.inside ? tl("pj.ag.inside") : (a.title || a.sid.slice(0, 8)))}${a.at ? " · " + esc(ago(a.at)) : ""}</div></span></button>
      ${a.stoppable ? `<button class="stp press" data-agstop="${esc(a.sid)}">${esc(tl("pj.ag.stop"))}</button>`
        : WHY[a.why] ? `<span class="s" style="flex:none;font-size:11.5px;color:var(--t4)" title="${esc(WHY[a.why][1])}">${esc(WHY[a.why][0])}</span>` : ""}</div>`;
    box.innerHTML =
      (ags.length ? `<div class="pj-lab" style="margin-top:4px">${esc(tl("pj.ag.head"))} <span class="n">${ags.length}</span>${foldBtn}</div>` + ags.slice(0, 12).map(agRow).join("") : "") +
      `<div class="pj-lab"${ags.length ? "" : ` style="margin-top:4px"`}>${tl("pj.res.head")} <span class="n">${res.length}</span>${ags.length ? "" : foldBtn}</div>` +
      (res.length ? res.slice(0, 12).map(resRow).join("")
        : `<div class="pj-empty" style="text-align:left;padding:8px 2px">${tl("pj.res.none")}</div>`) +
      `<div class="pj-lab">${tl("pj.open.head")} <span class="n">${open.length}</span></div>` +
      (open.length ? open.slice(0, 12).map((x) => row(x.title, `${vShort(x.v)} · ${ago(x.at)}`, "item/" + iid(x), tl("pj.open.n", {n: x.open}))).join("")
        : `<div class="pj-empty" style="text-align:left;padding:8px 2px">${tl("pj.open.none")}</div>`);
    c.agKey = JSON.stringify(ags);
    const db = box.querySelector("[data-rdense]");
    if (db) db.onclick = () => { setFold("rdense", !folded("rdense")); side(box, name, c); const b = box.querySelector("[data-rdense]"); if (b) b.focus({preventScroll: true}); };
    box.querySelectorAll("[data-agstop]").forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const a = ags.find((x) => x.sid === b.dataset.agstop);
      if (a) control("stop", {id: a.sid, agent: a.agent, state: a.state}, name, () => { if (c.kick) c.kick(); });
    });
  }

  // Desktop: size the columns to the room left under the toolbar. The bottom status bar (#status, fixed
  // from 1024px) and every ancestor's bottom padding are taken off, so the composer is never under it.
  function fit() {
    const g = document.querySelector(".pj-cols"); if (!g) return;
    if (!wide()) { g.style.removeProperty("--pjh"); return; }
    const st = document.getElementById("status");
    let r = st && getComputedStyle(st).position === "fixed" ? st.offsetHeight : 0;
    for (let n = g.parentElement; n && n !== document.body; n = n.parentElement) {
      const cs = getComputedStyle(n); r += (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.marginBottom) || 0);
    }
    let top = 0;                          // offsetTop ignores the entrance animation's translate
    for (let n = g; n; n = n.offsetParent) top += n.offsetTop;
    g.style.setProperty("--pjh", Math.max(320, Math.floor(innerHeight - r - top)) + "px");
  }
  window.pjFit = fit;
  window.pjCtx = ctxRow;                                       // the floating window's cards say how full a conversation is the same way
  window.pjCss = ensureCss;                                    // the floating window's blocks wear the session row's tokens
  // The same menu, for surfaces that are not the chat list (web/railmenu.js: the side menu's rows,
  // result cards): one place for the position, the keys and the look. `at` is {x, y, row, kb, label}.
  window.pjPopAt = (pop, anchor, at) => { ensureCss(); ctxAt = at || null; const off = popAt(pop, anchor); ctxAt = null; return off; };
  window.pjIconOf = (anchor, name) => iconOf(anchor, name, () => {});
  // Phone: an open chat takes the whole visible screen (see body.pjchat in the CSS). Decided from
  // what is drawn: a chat pane that is showing, on the chat screen, under 1024px.
  function phoneChat() {
    const {name} = where();
    const conv = !wide() && name && name !== ALL && name !== MULTI && document.querySelector("#view .pj>.pj-cols:not(.pj-listonly) .pj-conv");
    const on = !!conv && conv.style.display !== "none" && !!conv.querySelector(".pj-nth");
    document.body.classList.toggle("pjchat", on);
    if (swLeft && !(SW && SW.live())) { SW.clear(swLeft); swLeft = null; swRail = null; swPeek(false); }
    if (!on && typeof typingSync === "function") typingSync();   // a box hidden with the chat no longer hides the tab bar (v2.js)
    if (on) vvFit(); else document.body.classList.remove("pj-kb");
    // The chat appears where it is, once per opening (a redraw, another session picked while it is
    // up, or coming back from the results tab is not an opening). Only the hand slides it (below).
    if (!on) { if (!conv) chatAt = ""; return; }
    const was = chatAt; chatAt = location.hash;
    if (was) return;
    conv.animate([{opacity: 0}, {opacity: 1}], {duration: RM() ? 180 : 140, easing: "ease-out"});
  }
  let chatAt = "";
  // By hand (web/swipe.js): a row of the list is pulled sideways for its buttons, the chat is
  // pulled from the left edge to show the list under it, and from the right edge the list gives
  // the chat back. Here is only what those act on; every button is one the row's menu has.
  const swRoot = () => document.querySelector("#view .pj");
  const swPeek = (on) => document.body.classList.toggle("pj-peek", on);
  let swRail = null;
  if (SW) SW.host = {
    ok: () => phoneList() && location.hash.startsWith("#project") && !document.querySelector(".pj-pop,#sheet.on,#ov.on,.vw,.stk"),
    row: (sid) => {
      const h = railRows.get(sid); if (!h) return null;
      // Each: its outline icon, one short word under it, and its tone (go = the accent, dz = caution).
      const s = h.s, b = (a, icon, text, tone) => ({a, icon: icl(icon), text: esc(text), label: esc(what(a, s).label), dz: tone === "dz", go: tone === "go", off: what(a, s).off || ""});
      const hide = b("tidy", "hide", tl("mn.tidy"));
      // The menu's own order: 이어서 하기 (an ended one), 읽음, then 숨기기 or 끝내기.
      return {left: (s.state === "ended" ? [b("open", "resume", tl("sw.open"), "go")] : []).concat(s.agent === "codex" ? [] : [s.unread ? b("read", "read", tl("sw.read")) : b("read", "unread", tl("sw.unread"))],
        s.state === "ended" ? hide : b("stop", "end", turnStop(s) ? tl("room.codexStop") : tl("mn.stop"), "dz")), right: hide};
    },
    act: (a, sid) => { const h = railRows.get(sid), el = swRoot(); if (h && el) return control(a, h.s, h.name, () => draw(el)); },
    edge: {
      can: (side) => {
        const el = swRoot(), cols = el && el.querySelector(":scope>.pj-cols"), conv = cols && cols.querySelector("#pj-body .pj-conv");
        if (!conv || !conv.querySelector(".pj-nth [data-list]")) return false;
        return side === "l" ? document.body.classList.contains("pjchat") && !document.body.classList.contains("pj-kb") : listAt && cols.classList.contains("pj-listonly") && !!lastChat.name;
      },
      // The list is put under the chat (left edge), or the chat over the list's right edge.
      begin: (side) => {
        const cols = swRoot().querySelector(":scope>.pj-cols"), conv = cols.querySelector("#pj-body .pj-conv");
        if (side === "l") {
          if (!cols.querySelector(":scope>.pj-rail")) { swRail = document.createElement("div"); swRail.className = "pj-rail"; cols.insertBefore(swRail, cols.firstChild); if (railNow) railNow(); }
          swPeek(true); document.documentElement.scrollTop = pjListY;
        } else { pjListY = scrollY; cols.classList.remove("pj-listonly"); document.body.classList.add("pjchat"); swPeek(true); vvFit(); }
        return conv;
      },
      end: (to, conv) => {
        const el = swRoot(), cols = el && el.querySelector(":scope>.pj-cols"), now = cols && cols.classList.contains("pj-listonly") ? "list" : "chat";
        const done = () => { swPeek(false); swRail = null; SW.clear(conv); };
        if (!cols || !conv.isConnected) return done();
        if (to === "chat" && listAt) {                 // the chat was pulled back over the list: it is opened
          done(); const y = pjListY; fromList("project/" + enc(lastChat.name) + "/" + enc(lastChat.sid)); pjListY = y; return;
        }
        if (to === "chat") { if (swRail) swRail.remove(); document.documentElement.scrollTop = 0; return done(); }
        if (listAt) { cols.classList.add("pj-listonly"); document.body.classList.remove("pjchat"); return done(); }
        swLeft = conv; toList();                      // the page that follows clears it (phoneChat)
        setTimeout(() => { if (swLeft === conv) { swLeft = null; done(); } }, 1500);
      },
    },
  };
  let swLeft = null;
  // The pane is as tall as what can be seen: on an iPhone the keyboard covers the page instead of
  // resizing it, and the page may be pushed up under it (offsetTop). A pinch zoom is left alone.
  // Whether the keyboard is up is read against the tallest the screen has been at this width with
  // no box in use: an iPhone can report innerHeight already shrunk by the keyboard, and a phone
  // that resizes the page always does, so "innerHeight - height" alone can miss it.
  let vvBase = 0, vvW = 0;
  function vvFit() {
    const b = document.body, v = window.visualViewport;
    if (!b.classList.contains("pjchat") || (v && v.scale > 1.01)) return;
    const h = v ? v.height : innerHeight, t = v ? v.offsetTop : 0;
    const bar = b.classList.contains("inapp") ? (document.getElementById("top") || {}).offsetHeight || 0 : 0;
    b.style.setProperty("--pj-vh", Math.round(h - bar) + "px");
    b.style.setProperty("--pj-vt", Math.round(t + bar) + "px");
    const a = document.activeElement, typing = !!(a && a.matches && a.matches("textarea, input, [contenteditable]"));
    if (innerWidth !== vvW) { vvW = innerWidth; vvBase = 0; }
    vvBase = typing ? Math.max(vvBase, h, innerHeight, document.documentElement.clientHeight) : h;
    const kb = typing && vvBase - h > 80;
    if (kb === b.classList.contains("pj-kb")) return;
    b.classList.toggle("pj-kb", kb);
    // The box's height was set for the other padding: one line again, or what is typed (four lines at most over the keyboard).
    const ta = document.getElementById("pj-ta");
    if (ta) { const cs = getComputedStyle(ta), cap = Math.round((parseFloat(cs.lineHeight) || 22) * (kb ? 4 : 6) + parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom));
      if (!ta.value || !ta.scrollHeight) ta.style.height = "";
      else { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, cap) + "px"; } }
  }
  if (window.visualViewport) {
    let raf = 0;
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(vvFit); };
    visualViewport.addEventListener("resize", on); visualViewport.addEventListener("scroll", on);
    addEventListener("focusout", () => setTimeout(on, 80));   // the keyboard put away with no resize told: the rows come back
    addEventListener("focusin", on);   // the phone's top bar steps out while a box is in use: the pane takes its room
  }
  // Put a line in a conversation's message box before it opens (the item screen's 후속 요청).
  // Text typed and not sent, anywhere (a new conversation's first line or an open one): the app
  // update asks before a restart would drop it.
  window.pjUnsent = () => Object.values(drafts).some((v) => v && v.trim()) || Object.values(convs).some((c) => c.draft && c.draft.trim());
  window.pjDraft = (sid, text) => { const c = C(sid); c.draft = text; writeDraft(sid, text); c.focusDraft = true; };
  // The same chat, mounted somewhere else (the item screen's chat tab, custom.js): one pane, no
  // side column. `o.sid` is the session to open; without it (or when it is unknown here) the
  // department `o.name` gives its own session (the pin), else one that is up, else the newest.
  window.pjEmbed = async function (body, o) {
    ensureCss();
    body._pjEmbed = () => window.pjEmbed(body, o);
    let cur = null, name = o.name || "";
    if (o.sid) {
      // A failed read is the caller's to ask again: falling through would draw another session under this one's name.
      const s = await get("/api/project/session?id=" + enc(o.sid));
      if (s && s.found) { cur = Object.assign({}, s, {id: o.sid}); name = s.project || name; }
    }
    if (!cur && name) {
      const v = await readOrAsk("/api/project?name=" + enc(name)).catch(() => null);
      if (v && (v.need_consent || v.declined)) return {name, consent: true};
      const all = (v && v.sessions) || [];
      cur = all.find((s) => v.pin && s.id === v.pin) || pickCurrent(all.filter((s) => !s.tidied));
    }
    if (!body.isConnected) return null;
    if (!cur) return {name, session: null};
    body.dataset.multi = "1"; tab = "conv";
    drawSession(body, body, name, cur, {embed: body});
    return {name, session: cur, state: () => (C(cur.id).state || cur).state};
  };
  addEventListener("resize", () => { fit(); const b = document.getElementById("pj-body"); if (b && b.querySelector("[data-col]")) cols(b); else phoneChat(); });
  // The page width also changes without the window (the app menu folding): when that crosses the
  // three-column line the room is drawn again in its other shape; otherwise the two side widths
  // are fitted again so the chat keeps its 380px.
  if (typeof ResizeObserver === "function") {
    let t = 0, was = null;
    const settle = () => {
      const pj = document.querySelector("#view .pj"), now = threeNow();
      if (!pj || !pj.querySelector(".pj-cols") || !location.hash.startsWith("#project/")) return;
      if (threeCols() !== now || (!now && document.documentElement.classList.contains("pj2") !== twoNow()) || splitWant(pj) !== splitDrawn(pj) || splitStale(pj)) draw(pj); else if (now) { colGrips(pj); fit(); }
    };
    const ro = new ResizeObserver((es) => { const w = Math.round(es[0].contentRect.width); if (w === was) return; was = w; clearTimeout(t); t = setTimeout(settle, 180); });
    const v = document.getElementById("view"); if (v) ro.observe(v);
  }
  addEventListener("hashchange", () => { if (!location.hash.startsWith("#project")) pjStop(true); phoneChat(); });

  // ---- join the app ------------------------------------------------------------------------------------
  window.LOOP_TABS = window.LOOP_TABS || [];
  // The room page stays up while the person moves inside it (another conversation, another
  // project, back and forward) and across the app's refresh rounds: draw() brings it up to date.
  // The list of rooms stays up the same way, so a refresh round only touches the rows that changed.
  const keeps = (v) => { const p = v.firstElementChild, w = where(); if (!p || v.children.length !== 1 || !p.classList.contains("pj")) return false;
    // The first loader stays up when the list hands over to a chat (a PC opens the last one): one loader, not two.
    if (p.querySelector(":scope>rl-load")) return true;
    if (!w.name || w.name === ALL) return !!p.querySelector(":scope>#pj-rg");
    return !!p.querySelector(":scope>.pj-cols") && w.name !== MULTI; };
  window.LOOP_TABS.push({id: "project", get label() { return tl("menu.chat"); }, icon: "chat", draw, keeps});
  // v2.js drew once before this file loaded: register the screen now and redraw if we are on it.
  try { syncExtTabs(); if (location.hash.startsWith("#project")) render(); else drawChrome(); } catch (e) { /* the next render picks the tab up */ }
