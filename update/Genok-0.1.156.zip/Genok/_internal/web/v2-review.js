// Genok web UI, cut from v2.js: the item page's keys, the comment box, the decision, the full-screen viewer.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ===== X17: item-page shortcuts - hint bar, extra keys, keys from inside a shown HTML result =====
// Self-contained: the handler above keeps its bindings; this adds W / B / Enter / , . / Esc, the
// bar under the result, and the bridge that lets the keys work while focus is inside the frame.
// The bar is on until the reader turns it off (same "keys" preference as the settings switch).
try { if (localStorage.getItem("v2-keys") === null) localStorage.setItem("v2-keys", "1"); } catch {}
// The item frame asks for its page with ?keys=1: the server appends a small key listener (server.KEY_BRIDGE).
// &app=1 inside the app window: there the frame also hands over Ctrl + wheel (the app's screen size).
const keyUrl = (u) => u + (u.includes("?") ? "&" : "?") + "keys=1" + (IN_APP ? "&app=1" : "") + (document.documentElement.dataset.theme === "light" ? "" : "&sch=dark");   // sch: the frame's scrollbar follows the app theme
// Zoom of the shown HTML result. The frame is laid out at its width divided by the zoom (the way a
// browser zooms a page), so the report reflows instead of growing a sideways scrollbar.
// d: 1 / -1 one step, 0 back to 100%, null only shows the size it has.
function pageZoom(d) {
  const w = document.getElementById("pgw"); if (!w) return;
  if (d != null) { pageZ = d ? PAGE_Z[Math.max(0, Math.min(PAGE_Z.length - 1, PAGE_Z.indexOf(pageZ) + d))] : 1;
    try { localStorage.setItem("pageZ", String(pageZ)); } catch {} }
  w.style.setProperty("--pgz", pageZ);
  const c = document.querySelector(".pgtop .pgzoom"); if (!c) return;
  c.querySelector(".zpct").textContent = `${Math.round(pageZ * 100)}%`;
  c.querySelector('[data-z="-1"]').disabled = pageZ === PAGE_Z[0];
  c.querySelector('[data-z="1"]').disabled = pageZ === PAGE_Z[PAGE_Z.length - 1];
  c.querySelector('[data-z="0"]').disabled = c.querySelector('[data-z="100"]').disabled = pageZ === 1;
}
// A report on a phone is as tall as its content, so the page is the only thing that scrolls: a
// frame with its own scroll swallowed the swipe and the questions under it stayed out of reach.
// The frame's page reports its height (server.KEY_BRIDGE "size"); the frame is an opaque origin
// and cannot be measured from here. Left at the CSS height (it scrolls inside, as before) when
// the page lays itself out against the viewport (it would grow for ever), pins something to the
// viewport (position:fixed), or is taller than PG_FIT[1]. A PC keeps the fixed frame beside the panel.
const PG_FIT = [160, 20000];
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "size") return;
  const h = +d.h, ih = +d.ih, st = fr._fit || (fr._fit = {});
  if (!Number.isFinite(h) || !Number.isFinite(ih) || h <= 0 || fr.closest(".pgw.full") || document.body.classList.contains("composing")) return;
  const pgw = fr.closest(".pgw"), base = () => { fr.style.height = ""; pgw.classList.remove("fit"); };
  if (wide() || st.lock) return base();
  // A page that still overflows after it was given its full height is following the viewport:
  // the same overflow three times running, or four overflows in a row (content that really grew
  // reads 0 once the frame has caught up).
  const over = Math.round(h - ih);
  st.run = over > 1 ? (st.run || 0) + 1 : 0;
  st.same = over > 1 && st.set && Math.abs(over - st.over) <= 1 ? (st.same || 0) + 1 : 0;
  if (d.fixed || h > PG_FIT[1] || st.run >= 4 || st.same >= 2) { st.lock = true; return base(); }
  // Content that hangs out of its own box measures short once it fits: the height would swing
  // between the two readings, so after one swing the taller one stays.
  const to = Math.max(PG_FIT[0], Math.ceil(h));
  if (st.h2 != null && Math.abs(to - st.h2) <= 1 && Math.abs(to - st.h1) > 1) st.keep = true;
  if (st.keep && to < st.h1) return;
  st.over = over; st.set = true;
  if (to !== st.h1) { st.h2 = st.h1; st.h1 = to; }
  fr.style.height = to + "px"; pgw.classList.add("fit");   // .fit: shown in full, so no 전체 화면 on it
});
// Alt + wheel over the report: the frame's page hands the wheel over (server.KEY_BRIDGE).
let pgWheel = 0, pgWheelAt = 0;
addEventListener("message", (e) => {
  const fr = document.querySelector(".media iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "wheel" || d.mod !== "alt" || !Number.isFinite(d.dy) || !wide()) return;
  const now = Date.now(); if (now - pgWheelAt > 300) pgWheel = 0;
  pgWheelAt = now; pgWheel += d.dy;
  if (Math.abs(pgWheel) < 50) return;
  pageZoom(pgWheel < 0 ? 1 : -1); pgWheel = 0;
});
const KB_KEY = {"space": " ", "←": "arrowleft", "→": "arrowright", "esc": "escape"};
// Only the keys that apply to what is on screen: o = {video, pics, page, decide, next, vers, cmp, mount}.
function keyBarHtml(o) {
  if (o.mount) return "";
  const K = [];
  if (o.video) K.push(["Space", tl("keybar.play")], ["← →", tl("keybar.frame")]);
  else if (o.pics) { K.push(["Space", tl("keybar.big")]); if (o.pics > 1) K.push(["← →", tl("keybar.file")]); }
  else if (o.page) K.push(["W", tl("keybar.width")], ["Enter", tl("keybar.full")]);
  if (o.decide) K.push(["A", tl("keybar.ok")]);
  K.push(["C", tl("keybar.cmt")]);
  if (o.next) K.push(["N", tl("keybar.next")]);
  if (o.cmp) K.push(["B", tl("keybar.cmp")]);
  const cap = (x) => `<kbd data-k="${esc(KB_KEY[x.toLowerCase()] || x.toLowerCase())}">${esc(x)}</kbd>`;
  return `<div class="kbar${pref("keys") ? "" : " off"}" id="kbar" role="note" aria-label="${tl("keysSheet.20")}"><div class="kbar-l">${K.map(([k, t]) => `<span class="kb">${k.split(" ").map(cap).join("")}<em>${t}</em></span>`).join("")}</div><button class="kbar-b press" id="kbarall">${tl("keybar.all")}</button><button class="kbar-b ic press" id="kbarx" aria-label="${tl("keybar.off")}" title="${tl("keybar.off")}">${ic("x")}</button></div>`;
}
// The same bar under the lists that are gone through by keyboard (home, 알림 · 할 일, 결과물), with
// the keys of the list. It follows the one 단축키 안내 setting, and ? turns it on from any of them.
function listKeyBar() {
  const K = [["J K", tl("keyHelp.7")], ["Enter", tl("search.3")], ["A", tl("STATUS_T.4")], ["R", tl("cmt.1")], ["H", tl("palActs.2")]];
  if (cur === "lib") K.push(["1-7", tl("keybar.lists")]);
  K.push(["?", tl("keybar.hide")]);
  const cap = (x) => `<kbd data-k="${esc(x.toLowerCase())}">${esc(x)}</kbd>`;
  return `<div class="kbar${pref("keys") ? "" : " off"}" id="kbar" role="note" aria-label="${tl("keysSheet.20")}"><div class="kbar-l">${K.map(([k, t]) => `<span class="kb">${k.split(" ").map(cap).join("")}<em>${t}</em></span>`).join("")}</div><button class="kbar-b press" id="kbarlist">${tl("keybar.all")}</button><button class="kbar-b ic press" id="kbarx" aria-label="${tl("keybar.off")}" title="${tl("keybar.off")}">${ic("x")}</button></div>`;
}
function keyBarToggle(v = !pref("keys")) {
  pref("keys", v); document.getElementById("kbar")?.classList.toggle("off", !v);
  // Closing says how to bring it back, and offers the way right there; turning it on says it too.
  if (!v) toastAct(tl("keybar.offd"), tl("keybar.undo"), () => keyBarToggle(true), 7000);
  else toast(tl("keybar.ond"));
}
// ? works on every screen (the item screen's own handler has it too and skips a second toggle).
addEventListener("keydown", (e) => {
  if (e.key !== "?" || e.ctrlKey || e.metaKey || e.altKey || e.defaultPrevented || typingIn(e.target)) return;
  if (detail?.[0] === "item" || wrLive() || document.getElementById("sheet")?.classList.contains("on")) return;
  keyBarToggle();
});
// A pressed key lights its cap for a moment (CSS transition, so a second press just restarts it).
function keyBarHit(k) {
  const c = [...document.querySelectorAll("#kbar kbd")].find((x) => x.dataset.k === k); if (!c) return;
  c.classList.add("hit"); clearTimeout(c._hit); c._hit = setTimeout(() => c.classList.remove("hit"), 170);
}
addEventListener("click", (e) => { const b = e.target.closest?.("#kbarx,#kbarall,#kbarlist"); if (!b) return;
  if (b.id === "kbarx") keyBarToggle(false); else if (b.id === "kbarlist") keyHelp(); else keysSheet(); });
// The shell never slides sideways, whatever asked the window to (a focus on something off the edge).
addEventListener("scroll", () => { if (scrollX) scrollTo(0, scrollY); }, {passive: true});
// Same gates as the handler above, plus the compare workspace, the search overlay and the 보기 menu.
const itemKeysFree = (e) => !!openItem && detail?.[0] === "item" && !wrLive() && !drawing && !e.ctrlKey && !e.metaKey && !e.altKey && !typingIn(e.target)
  && !document.documentElement.classList.contains("cmpv-lock") && !document.querySelector(".vw,.stk,#ov.on") && !document.getElementById("sheet")?.classList.contains("on");
addEventListener("keydown", (e) => {
  if (!itemKeysFree(e)) return;
  const k = e.key.toLowerCase(), menu = document.querySelector(".viewmenu.on");
  if (menu) { if (k === "escape") menu.classList.remove("on"); return; }
  keyBarHit(e.shiftKey && k === "n" ? "shift+n" : k);
  if (e.repeat) return;
  const onBtn = e.target.closest?.("button,a,summary,[role=switch]"), full = document.getElementById("pgfull");
  // W: an HTML result at PC width / phone width. Enter: the page full screen (a still or a video already opens big).
  // + / - / 0: the result's own zoom (a picture on the stage, or the shown page), at PC width.
  const zk = wide() && !onBtn ? (k === "+" || k === "=" ? 1 : k === "-" ? -1 : k === "0" ? 0 : null) : null;
  if (zk != null && (document.getElementById("pgw") || stageZoom)) { e.preventDefault();
    if (document.getElementById("pgw")) pageZoom(zk); else zk ? stageZoom.step(zk) : stageZoom.fit(); }
  else if (k === "w" && wide()) document.querySelector(".pgtop [data-pw]:not(.on)")?.click();
  else if (k === "enter" && full && !onBtn) { e.preventDefault(); full.click(); }
  // B: the one compare entry on screen (the stage's 나란히, else the version strip's 비교); B again closes it (cmpview.js).
  else if (k === "b") [".sside", "#vtlcmp"].map((q) => document.querySelector(q)).find((b) => b?.offsetParent)?.click();
  // , and . walk the versions where they are not a video's frame step (V / Shift+V do the same everywhere).
  else if ((k === "," || k === ".") && !stageVideo() && openItem.vers.length > 1) document.body.dispatchEvent(new KeyboardEvent("keydown", {key: k === "," ? "v" : "V", shiftKey: k === ".", bubbles: true}));
  // Esc leaves the result when there is nothing left to close (a pin being placed and the full-screen page close first).
  else if (k === "escape" && !e.defaultPrevented && !pinning && !document.querySelector(".pgw.full")) back();
});
// Keys pressed while focus is inside the shown HTML result. The frame is an opaque origin, so its
// page (server.KEY_BRIDGE) posts the keys it did not use itself; they are replayed here as if
// pressed on the app. Only from our own frame and only while the reader is really inside it.
addEventListener("message", (e) => {
  const fr = document.querySelector(".media iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "key" || typeof d.key !== "string" || d.key.length > 12) return;
  if (document.activeElement !== fr) return;
  // A pushed page must never be able to approve itself: A from inside the frame only hands the
  // keyboard back to the app, and the next A (a real key press on the app) approves.
  if (/^a$/i.test(d.key)) { fr.blur(); if (openItem?.latest && openItem.status !== "approved") toast(tl("keybar.again")); return; }
  document.body.dispatchEvent(new KeyboardEvent("keydown", {key: d.key, shiftKey: !!d.shift, repeat: !!d.repeat, bubbles: true, cancelable: true}));
});
// ===== /X17 =====
// Enter sends, Shift+Enter breaks the line. An Enter that only finishes a Korean syllable is left alone.
// An iPhone's Korean keyboard reports Enter as composing (229), so the keydown path alone let
// the key drop a line break into the box instead of sending; the line break it inserts once
// the syllable is committed is caught here as well. Shift+Enter still makes a new line.
const enterSends = (t, b) => { let shift = false;
  const go = () => setTimeout(() => { if (!b.disabled) b.click(); });
  t.onkeydown = (e) => { shift = e.shiftKey;
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); go(); } };
  t.addEventListener("beforeinput", (e) => {
    if (!shift && (e.inputType === "insertLineBreak" || e.inputType === "insertParagraph")) { e.preventDefault(); go(); } }); };
// Reads a box only after the keyboard has committed the syllable still being typed; a phone
// otherwise sent the words without their last letter.
const settled = (t) => new Promise((r) => { if (document.activeElement === t) t.blur(); setTimeout(r, 30); });
// Ready answers above the comment box: the department's own --reject list when it gave one,
// else the usual few. A tap adds it to the box (a second tap takes it out); 보내기 still sends.
// No "좋아요" here: a yes is the 승인 button right above, and a yes-shaped comment next to it
// left two ways to say the same thing and no telling which one counted.
const QUICK = LT(() => ([tl("QUICK.1"), tl("QUICK.2"), tl("QUICK.3"), tl("QUICK.4"), tl("QUICK.5"), tl("QUICK.6")]));
// The server fills a version's reject list with its own default four (hub_store.REJECT_DEFAULT,
// stored in Korean) when the department named none: those are shown in the reader's language.
const REJECT_DEFAULT = ["방향이 달라요 · 다시 잡아주세요", "디테일만 고치면 돼요", "화질·기술 문제예요", "더 얘기하고 정하죠"];
const rejectList = (r) => (r || []).map((t) => { const n = REJECT_DEFAULT.indexOf(t); return n < 0 ? t : tl(`rejectSheet.${n + 1}`); });
const quickPicks = (it) => (it.reject?.length ? rejectList(it.reject) : QUICK).slice(0, 8);
// What was typed but not sent, per item: switching to 기록 and back, or a redraw, rebuilt the box empty.
// Drafts outlive a reload: a phone browser throws a tab away while another app is in front.
const cmDraft = (() => { try { return JSON.parse(localStorage.getItem("cmDraft") || "{}"); } catch (e) { return {}; } })();
const saveDraft = () => { try { localStorage.setItem("cmDraft", JSON.stringify(Object.fromEntries(Object.entries(cmDraft).filter(([, t]) => t)))); } catch (e) {} };
// Screenshots pasted, dropped or picked for a comment on a result, per item until sent (C04).
// They go up with the comment as "📎 <path>" lines, the way a picture in a talk room does.
const cmImgs = {}, CM_IMG_MAX = 4, CM_IMG_BYTES = 20 * 1024 * 1024;
// The composer dock (#cdk) is always on screen: pinned under the side panel on a PC, to the bottom
// edge on a phone. Only the 대화 tab, which has its own message box, puts it away.
function cmShow() {
  // The 대화 and 질문 tabs have no comment box of their own: the box is on 코멘트.
  if (["chat", "ask"].includes(document.querySelector("#itabs .on")?.dataset.v)) document.querySelector('#itabs [data-v="cm"]')?.click();
  // A phone's dock shows only the verdicts until something is written: anything that wants the box brings it up.
  if (!wide()) startCompose();
  return document.getElementById("cm");
}
// How far the end of the list is from the top of the dock (0 = resting right on it). A stage/sheet
// mount has the dock in the flow, so there is nothing to measure.
function cmGap() {
  const c = document.querySelector(".card.itab"), k = document.getElementById("cdk");
  if (!c || !k || k.closest(".mounted") || !k.offsetHeight) return null;
  return c.getBoundingClientRect().bottom - k.getBoundingClientRect().top;
}
let cmJump = 0;   // until when a redraw brings the list's end up to the box (a comment was just sent)
function cmEnd() {
  const g = cmGap(); if (g == null) return;
  const p = document.getElementById("cdk").parentElement;
  if (wide() && p.scrollHeight > p.clientHeight) p.scrollTop += g + 8; else scrollBy({top: g + 8, behavior: "instant"});
}
// The box grows with the words up to its CSS max-height, then scrolls inside.
function cmGrow(t) { t.style.height = "auto"; t.style.height = t.scrollHeight + 2 + "px"; }
let cdkRO = null;
function wireComments(it) {
  const t = document.getElementById("cm"), add = document.getElementById("cmadd"), tg = document.querySelector(".tgt");
  if (!t || !add) return;
  const cdk = document.getElementById("cdk");
  const imgs = cmImgs[it.id] || (cmImgs[it.id] = []);
  // With something to send, 보내기 is the one lit button: 승인 beside it steps back (.has).
  const hasPic = () => drawPic?.id === it.id, can = () => { add.disabled = !t.value.trim() && !hasPic() && !imgs.length; cdk?.classList.toggle("has", !add.disabled); };
  t.value = cmDraft[it.id] || ""; can(); showDrawPic(); showQuote(); cmGrow(t);
  // The phone's page leaves room for the docked bar, however tall it has grown.
  cdkRO?.disconnect();
  // On a PC the dock grows when its tools come out: the panel moves up by as much, so what sat right
  // above the dock (다음 결과물) stays in sight instead of going under it.
  if (cdk && window.ResizeObserver) { let h0 = cdk.offsetHeight;
    cdkRO = new ResizeObserver(() => { const h = cdk.offsetHeight, dh = h - h0, pn = cdk.parentElement; h0 = h;
      document.body.style.setProperty("--cdkH", h + "px");
      if (dh > 0 && wide() && pn.scrollHeight > pn.clientHeight) pn.scrollTop += dh; });
    cdkRO.observe(cdk); }
  const attBox = document.getElementById("cmatt"), fileIn = document.getElementById("cmfile");
  const drawAtt = () => { if (!attBox) return; attBox.hidden = !imgs.length;
    attBox.innerHTML = imgs.map((im, n) => `<div class="th"><img src="${im.url}" alt="${tl("cmImg.3", {n: n + 1})}"><button class="press" data-imgrm="${n}" aria-label="${tl("cmImg.4")}">${ic("x")}</button></div>`).join(""); };
  const addImgs = (files) => { for (const f of files) {
      if (!f.type.startsWith("image/")) { toast(tl("cmImg.5")); continue; }
      if (f.size > CM_IMG_BYTES) { toast(tl("cmImg.6")); continue; }
      if (imgs.length >= CM_IMG_MAX) { toast(tl("cmImg.7", {n: CM_IMG_MAX})); break; }
      imgs.push({blob: f, url: URL.createObjectURL(f)}); }
    drawAtt(); can(); updSplit(); };
  if (attBox) attBox.onclick = (e) => { const x = e.target.closest("[data-imgrm]"); if (!x) return;
    const [gone] = imgs.splice(+x.dataset.imgrm, 1); if (gone) URL.revokeObjectURL(gone.url); drawAtt(); can(); updSplit(); };
  const ib = document.getElementById("cmimg"); if (ib && fileIn) { ib.onclick = () => fileIn.click(); fileIn.onchange = () => { addImgs([...fileIn.files]); fileIn.value = ""; }; }
  t.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith("image/"));
    if (fs.length) { e.preventDefault(); addImgs(fs); } });
  const dock = document.getElementById("cdock");
  if (dock) { ["dragenter", "dragover"].forEach((k) => dock.addEventListener(k, (e) => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); dock.classList.add("drop"); } }));
    dock.addEventListener("dragleave", (e) => { if (!dock.contains(e.relatedTarget)) dock.classList.remove("drop"); });
    dock.addEventListener("drop", (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); dock.classList.remove("drop"); addImgs([...e.dataTransfer.files]); }); }
  drawAtt();
  const db = document.getElementById("drawbtn"); if (db) db.onclick = () => drawing ? endDraw(true) : startDraw();
  document.querySelectorAll("#qpick .opt").forEach((o) => o.onclick = () => {
    const q = o.dataset.q, on = !t.value.includes(q);
    t.value = (on ? (t.value.trim() ? t.value.trim() + ", " : "") + q : t.value.replace(q, ""))
      .replace(/(\s*,\s*){2,}/g, ", ").replace(/^[\s,]+|[\s,]+$/g, "");
    o.classList.toggle("on", on); can(); cmDraft[it.id] = t.value; saveDraft();
  });
  if (tg) tg.querySelectorAll(".tg").forEach((b) => b.onclick = () => { tg.dataset.on = b.dataset.tgt; tgtLabel(); t.placeholder = b.dataset.tgt === "file" ? tl("itemView.109") : tl("wireComments.1"); t.focus(); });
  const pb = document.getElementById("pinbtn");
  pinLabel = () => { if (!pb) return; pb.classList.toggle("on", pinning || !!pin);
    pb.querySelector("span").textContent = pinning ? (it.pics[stageAt]?.kind === "video" ? tl("wireComments.2") : tl("loc.pinning")) : pin?.r ? tl("loc.region_set") : pin ? tl("wireComments.3", {x: pin.x, y: pin.y}) : tl("itemView.106"); };
  if (pb) pb.onclick = () => { if (drawing) endDraw(false); if (pin) { pin = null; pinning = false; } else if ((pinning = !pinning)) { stageVideo()?.pause();
      document.getElementById("stage")?.scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"}); }
    drawPins(); pinLabel(); };
  pinLabel();
  // Several directives written one per line can go as one comment or be split, each on its own.
  // The chip shows only when there are 2+ lines and no pin/drawing is attached (those belong to a
  // single note). Splitting is off by default, so a plain paragraph is never broken up by surprise.
  // With the split on, the lines it will send are listed under the box before anything goes,
  // so what arrives as separate directives is never a surprise (C07).
  const splitBtn = document.getElementById("cmsplit"), pv = document.getElementById("splitpv");
  let splitMode = false;
  function updSplit() { if (!splitBtn) return;
    const lines = splitDirectives(t.value), n = lines.length, show = n >= 2 && !hasPic() && !pin && !imgs.length && pgQuote?.id !== it.id;
    if (!show) { splitMode = false; splitBtn.hidden = true; splitBtn.setAttribute("aria-pressed", "false"); if (pv) { pv.hidden = true; pv.innerHTML = ""; } return; }
    splitBtn.hidden = false; splitBtn.setAttribute("aria-pressed", String(splitMode));
    splitBtn.classList.toggle("on", splitMode);
    splitBtn.querySelector("span").textContent = splitMode ? tl("itemView.164") : tl("itemView.163", {n});
    if (pv) { pv.hidden = !splitMode;
      pv.innerHTML = splitMode ? `<div class="spvh">${tl("cmSplit.2", {n})}</div><ol>${lines.map((ln) => `<li>${esc(ln)}</li>`).join("")}</ol>` : ""; }
    fitCompose(); }
  if (splitBtn) splitBtn.onclick = () => { splitMode = !splitMode; updSplit(); t.focus(); };
  updSplit();
  t.oninput = () => { can(); cmGrow(t); cmDraft[it.id] = t.value; saveDraft(); updSplit(); };
  // Lab 4 (Style Lab): a quiet line under the box while a draft is kept on this device.
  if (RD) { const sv = document.createElement("p"), sync = () => { sv.hidden = !t.value.trim(); };
    sv.className = "rdsaved"; sv.textContent = tl("rv.saved"); t.closest(".cbox")?.after(sv); sync(); t.addEventListener("input", sync); }
  // Typing about a moment while the video runs on sent a later moment than the one meant.
  t.addEventListener("focus", () => { const vd = stageVideo(); if (vd && !vd.paused) vd.pause(); cmWhen(); startCompose(); });
  document.querySelectorAll(".qtog").forEach((b) => b.onclick = () => { const on = !qpOn(); qpOn(on);
    document.getElementById("qpick")?.classList.toggle("off", !on);
    document.querySelectorAll(".qtog").forEach((x) => { x.setAttribute("aria-pressed", on); x.textContent = tl("wireComments.4", {p0: on ? tl("itemView.108") : tl("catchBar.2")}); });
    fitCompose(); });
  const cx = document.getElementById("cmpx"); if (cx) cx.onclick = () => endCompose();
  cmWhen();
  enterSends(t, add);
  add.onclick = async () => { add.disabled = true; await settled(t);
    const text = t.value.trim() || (hasPic() ? tl("wireComments.5") : imgs.length ? tl("cmImg.9") : pgQuote?.id === it.id && quoteLine(pgQuote.to) ? tl("pgq.to_say") : ""); if (!text) { add.disabled = false; return; }
    // Which file, and for a video the moment it was paused at, go in front of the words.
    const f = it.pics[stageAt], onFile = it.pics.length > 1 && (tg?.dataset.on || "file") === "file";
    // A typed viewer (code/doc/sheet, types.js) may anchor the comment to a file line, cell, or
    // selection; it returns that anchor as plain text to sit in the leading [...] tag.
    const anch = (window.LOOP_ANCHOR && window.LOOP_ANCHOR(it)) || "";
    const tag = [onFile ? f.name : "", anch, pin && pin.at === stageAt ? (pin.r ? boxTag(pin.r) : tl("wireComments.6", {x: pin.x, y: pin.y})) : "", momentOf(stageVideo(), f)].filter(Boolean).join(" ");
    // Split on: each line goes as its own directive (the same file/moment tag in front), so a
    // list a session wrote in one box lands as separate items to work through. A pin/drawing is
    // ruled out above, so there is nothing per-line to attach.
    // 되돌리기 takes back the parts no session has read yet and puts the text back in the box; the
    // hand-over (sendNow) waits out that window so its own toast does not hide the button.
    if (splitMode && !hasPic() && !imgs.length) { const plan = splitPlan(t.value, tag), draft = t.value;
      if (plan.length >= 2) { const made = [];
        try { for (const x of plan) made.push((await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: x})).entry?.id);
          await toChanges(it); delete cmDraft[it.id]; saveDraft(); pin = null; pinning = false; endCompose();
          await load(); cmJump = Date.now() + 1500; again();
          let undone = false;
          const later = setTimeout(() => { if (!undone) sendNow(it); }, 6000);
          toastAct(tl("itemView.165", {n: plan.length}), tl("toggleFav.3"), async () => { undone = true; clearTimeout(later);
            try { const d = await get(`/api/item?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`);
              const kept = (d.log || []).filter((e) => made.includes(e.id) && (e.delivered || e.ack)).map((e) => e.id);
              for (const id of made) if (id && !kept.includes(id)) await post("/api/delete", {p: it.p, i: it.i, id});
              if (!kept.length) { cmDraft[it.id] = draft; saveDraft(); }
              toast(kept.length ? tl("cmSplit.3", {n: kept.length}) : tl("cmSplit.4"));
              if (kept.length) sendNow(it);
              await load(); again(); }
            catch (e) { toast(e.message); } }, 6000);
          return; }
        catch (e) { toast(e.message); add.disabled = false; return; } } }
    try {
      // A drawing goes up first: the comment carries its path, as a picture in a talk room does,
      // plus the vector strokes so the viewer can replay them on the media (see draw.js).
      let att = "", draw = null, drawPng = null;
      if (hasPic()) { const r = await fetch(`/api/attach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`, {method: "POST", headers: {"Content-Type": "image/png"}, body: drawPic.blob});
        const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || tl("wireComments.7"));
        att = `\n📎 ${j.path}`; drawPng = j.path;
        draw = drawPic.strokes?.length ? {strokes: drawPic.strokes, file: drawPic.file} : null; }
      for (const im of imgs) { const r = await fetch(`/api/attach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`, {method: "POST", headers: {"Content-Type": im.blob.type || "image/png"}, body: im.blob});
        const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || tl("cmImg.8"));
        att += `\n📎 ${j.path}`; }
      // The box/spot and the I-O stretch ride in the tag (the server reads them into pin/rect and
      // at_/to_ fields); which file of several is named as data too.
      // A box also goes as rect (0..1, finer than the tag's whole percent); the server refuses one
      // that pokes past the edge, so it is fitted inside first.
      const rect = pin && pin.at === stageAt && pin.r ? fitRect(pin.r) : null;
      // A quoted passage leads the comment; "→ words" under it is what should stand there instead.
      const qTo = pgQuote?.id === it.id ? quoteLine(pgQuote.to) : "";
      const quote = pgQuote?.id === it.id ? `> ${pgQuote.text}\n${qTo ? `→ ${qTo}\n` : ""}` : "";
      await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: quote + (tag ? `[${tag}] ${text}` : text) + att, draw, draw_png: drawPng,
        ...(it.pics.length > 1 && f ? {file: f.name} : {}), ...(rect ? {rect} : {}), ...(quote && pgQuote.n ? {quote_n: pgQuote.n} : {})});
      await toChanges(it);
      if (hasPic()) { URL.revokeObjectURL(drawPic.url); drawPic = null; }
      imgs.splice(0).forEach((im) => URL.revokeObjectURL(im.url));
      delete cmDraft[it.id]; saveDraft(); pin = null; pinning = false; pgQuote = null; endCompose(); await sendNow(it); await load(); cmJump = Date.now() + 1500; await again();
      // On a PC the box takes the next comment straight away; a phone keeps its keyboard down.
      if (wide()) document.getElementById("cm")?.focus({preventScroll: true}); }
    catch (e) { toastFail(e.message, tl("err.words.meta")); add.disabled = false; } };
}
// Leaving a comment is asking for a fix: the newest version is sent back (changes). An approved one
// keeps its mark - but once that word is sent the lists file it by the work flow again, until it
// is approved once more (status.js, `reopened`).
const toChanges = (it) => it.latest && !["changes", "approved"].includes(it.status)
  ? post("/api/status", {p: it.p, i: it.i, v: it.v, status: "changes"}).catch(() => null) : Promise.resolve();
// What went into a version in code: the commits of the pushing folder's repository since the
// version before. Folders outside git (most render work) show nothing.
const gitMemo = new Map();
async function gitCard(body, p, i, vv) {
  const key = `${p}/${i}/${vv}`;
  if (!gitMemo.has(key)) gitMemo.set(key, get(`/api/commits?p=${encodeURIComponent(p)}&i=${encodeURIComponent(i)}&v=${vv}`).then((j) => j.commits || []).catch(() => []));
  const cs = await gitMemo.get(key);
  if (!cs.length || !body.isConnected || body.querySelector(".gitc")) return;
  body.insertAdjacentHTML("afterbegin", `<details class="gitc"><summary>${ic("code")}<span>${tl("gitCard.1")} <b class="num">${cs.length}</b></span>${ic("chev", "i dn")}</summary>
    ${cs.map((c) => `<div class="row gc"><code class="num">${esc(c.id)}</code><span class="tx"><div class="t">${esc(c.text)}</div><div class="s">${ago(c.at)}</div></span></div>`).join("")}</details>`);
}
// Quick picks can be put away; the choice is kept per browser.
function qpOn(set) {
  // Hidden unless turned on: they took half of what the keyboard left (user, 2026-09-26).
  try { if (set !== undefined) localStorage.setItem("qpShow", set ? "1" : "0"); return localStorage.getItem("qpShow") === "1"; } catch (e) { return false; }
}
// Writing on a phone pushed the result off the screen: the keyboard took half, the box
// the rest. While composing, the result is pinned above and the box sits on the keys, and
// it stays that way with the keyboard down so the files can be swiped between sentences.
let composing = null;
function startCompose() {
  // The pinned element is the image/video stage, or an HTML report's frame when there is no stage.
  if (wide() || composing || !(document.getElementById("stage") || document.getElementById("pgw")) || !document.getElementById("cdock")) return;
  const bg = document.createElement("div"); bg.className = "cmpbg"; bg.onclick = () => endCompose();
  // Inside the app, not on <body>: a skin that lifts .app into its own layer put this over the result and the box.
  (document.querySelector(".app") || document.body).appendChild(bg);
  let raf = 0; const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(fitCompose); };
  // Back on a phone puts the box away and stays on the result (it left for the list); the draft is kept.
  let hist = 0; if (window.genokBeta?.("pai")) try { if (history.state?.cmp) hist = history.state.cmp; else history.pushState({cmp: hist = Date.now()}, ""); } catch (e) { /* no history: the scrim still ends it */ }
  composing = {bg, on, hist};
  visualViewport?.addEventListener("resize", on); visualViewport?.addEventListener("scroll", on); addEventListener("resize", on);
  document.body.classList.add("composing"); fitCompose();
  setTimeout(fitCompose, 350);   // after the keyboard has finished coming up
}
addEventListener("popstate", () => { if (composing?.hist && history.state?.cmp !== composing.hist) { composing.hist = 0; endCompose(); } });
function fitCompose() {
  if (!composing) return;
  // The redesign lays the dock out as display:contents inside the pinned .cdk card: size and lift that box.
  const cdock = document.getElementById("cdock"), dock = cdock && (cdock.offsetHeight ? cdock : cdock.closest(".cdk") || cdock);
  const media = document.querySelector(".media");
  const stage = document.getElementById("stage"), st = stage || document.getElementById("pgw");
  if (!dock || !media || !st) return endCompose();
  const vv = window.visualViewport, top = vv ? vv.offsetTop : 0, h = vv ? vv.height : innerHeight;
  dock.style.bottom = Math.max(0, innerHeight - h - top) + "px"; media.style.top = top + "px";
  const other = media.offsetHeight - st.offsetHeight;
  document.body.style.setProperty("--cmpH", Math.max(120, Math.round(h - dock.offsetHeight - other - 6)) + "px");
  if (stage) stageGo?.(stageAt, 0, true);
}
function endCompose() {
  if (!composing) return;
  const {bg, on, hist} = composing; composing = null; bg.remove();
  if (hist) setTimeout(() => { if (history.state?.cmp === hist && composing?.hist !== hist && !navOffSheet) history.back(); });
  visualViewport?.removeEventListener("resize", on); visualViewport?.removeEventListener("scroll", on); removeEventListener("resize", on);
  document.body.classList.remove("composing");
  const dock = document.getElementById("cdock"), media = document.querySelector(".media");
  if (dock) { dock.style.bottom = ""; const card = dock.closest(".cdk"); if (card) card.style.bottom = ""; }
  if (media) media.style.top = "";
  if (document.activeElement?.id === "cm") document.activeElement.blur();
  if (document.getElementById("stage")) { stageGo?.(stageAt, 0, true); document.querySelector(".itab")?.scrollIntoView({block: "start"}); }
  else if (document.getElementById("pgw")) document.querySelector(".itab")?.scrollIntoView({block: "start"});
}
// 코멘트 in the phone's bottom bar: the box sat in a second tab under the questions, so a
// phone never found it (user, 2026-09-29). Opens that tab and puts the keyboard up in the
// same tap (a phone only raises it from a gesture), which docks the box over the result.
function openCmt() {
  const t = cmShow(); if (!t) return;
  t.focus({preventScroll: true});
  if (!composing && t.closest(".mounted")) t.scrollIntoView({block: "center", behavior: RM() ? "auto" : "smooth"});
}
// A shown HTML page (picker, checklist) can hand its result to the comment box. It only
// fills the box; the reader still presses 보내기. Accepted from the item's own frame only.
window.addEventListener("message", (e) => {
  // Only our own result iframe may hand a comment over: it is sandboxed (opaque origin, no
  // fetch), so this postMessage is its one way to the app. {hub:"comment"} is the hub's
  // wording; {loop:"comment"} is ours - both mean the same and carry a `text`.
  const fr = document.querySelector(".media iframe");
  const asks = e.data?.hub === "comment" || e.data?.loop === "comment";
  if (!fr || e.source !== fr.contentWindow || !asks || typeof e.data.text !== "string") return;
  cmShow();
  const t = document.getElementById("cm"), add = document.getElementById("cmadd");
  if (!t) return;
  t.value = e.data.text.slice(0, 8000); add.disabled = !t.value.trim();
  if (t.closest(".mounted")) t.scrollIntoView({block: "center", behavior: "smooth"});
  cmGrow(t); document.getElementById("cdk")?.classList.toggle("has", !add.disabled); t.focus({preventScroll: true});
  toast(tl("openCmt.1"));
});
// Words selected in the shown report (server.KEY_BRIDGE "sel") wait over the comment box as the
// comment's quote. A selection dropped while the reader is still inside the report takes the quote
// away; one that goes because they moved on to type does not.
let pgQuote = null;                       // {id, text}
function showQuote() {
  const el = document.getElementById("qchip"), t = document.getElementById("cm"); if (!el) return;
  const on = !!pgQuote && pgQuote.id === openItem?.id; el.hidden = !on;
  // The pen opens one line for the words that should stand there instead (sent as "→ words").
  const to = on && pgQuote.to != null;
  el.innerHTML = on ? `<span class="tx">${esc(pgQuote.text)}</span><button class="ib press${to ? " on" : ""}" id="qchipr" aria-pressed="${to}" aria-label="${tl("pgq.to_t")}" title="${tl("pgq.to_t")}">${ic("pen")}</button><button class="ib press" id="qchipx" aria-label="${tl("pgq.drop")}" title="${tl("pgq.drop")}">${ic("x")}</button>${to ? `<input id="qto" maxlength="160" autocomplete="off" placeholder="${tl("pgq.to_ph")}" aria-label="${tl("pgq.to_t")}" value="${esc(pgQuote.to)}">` : ""}` : "";
  if (t && openItem?.page) t.placeholder = on ? tl("pgq.ph_on") : tl("pgq.ph");
  document.getElementById("qchipx")?.addEventListener("click", () => { pgQuote = null; showQuote(); });
  document.getElementById("qchipr")?.addEventListener("click", () => { pgQuote.to = to ? null : ""; showQuote(); document.getElementById("qto")?.focus(); });
  document.getElementById("qto")?.addEventListener("input", (e) => { pgQuote.to = e.target.value; });
}
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "sel" || typeof d.text !== "string" || !openItem) return;
  const q = quoteLine(d.text);
  if (q.length > 1) pgQuote = {id: openItem.id, text: q, n: d.n | 0};
  else if (document.activeElement === fr && pgQuote?.id === openItem.id) pgQuote = null;
  else return;
  showQuote();
});
// A quote in the log, a 지시 row's 이 부분, a changed line: the report goes to those words and
// lights them (server.KEY_BRIDGE "find"). The page answers "found"; a phone's full-length frame
// cannot scroll itself, so the app scrolls to where the page says the words are.
// The quoted passages stay marked while the pen is on (server.KEY_BRIDGE "marks"). The page says
// "size" once its listener is up, and again when it grows: the list goes out each time.
let sgOnly = false;                       // the file grid shows only the files that changed
let pgMarksOn = !lsGet("pg-marks-off"), pgMarkAt = 0;
function pgMarksSend() {
  document.querySelector(".media .pgw iframe")?.contentWindow.postMessage({loop: "marks", list: pgMarksOn ? openItem?.quotes || [] : []}, "*");
}
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe");
  if (fr && e.source === fr.contentWindow && e.data?.loop === "size" && openItem?.quotes?.length) pgMarksSend();
});
function pgFind(text, n = 0) {
  document.querySelector(".media .pgw iframe")?.contentWindow.postMessage({loop: "find", text: text.replace(/…$/, ""), n}, "*");
}
document.addEventListener("click", (e) => { const b = e.target.closest?.("button[data-qj]"); if (b) pgFind(b.dataset.qj, +b.dataset.qn); });
addEventListener("message", (e) => {
  const fr = document.querySelector(".media .pgw iframe"), d = e.data;
  if (!fr || e.source !== fr.contentWindow || d?.loop !== "found") return;
  if (!d.ok) return toast(tl("pgq.gone"));
  const top = fr.getBoundingClientRect().top, how = RM() ? "auto" : "smooth";
  if (fr.closest(".pgw.fit") && Number.isFinite(d.y)) scrollTo({top: scrollY + top + d.y - innerHeight / 3, behavior: how});
  else if (top < 0 || top > innerHeight * 0.6) fr.scrollIntoView({block: "start", behavior: how});
});
// Above the report: how many places its words changed since the version before. A press lists
// them, was over now; a line still in the report goes to its place.
async function pgChgFill(el, aUrl, bUrl, av, bv) {
  const d = await pgDiff(aUrl, bUrl);
  if (!el.isConnected) return;
  if (!d) { const row = el.parentElement; el.remove(); if (!row.children.length) row.remove(); return; }
  const n = d.changes.length;
  el.innerHTML = n ? `<button class="press">${ic("swap")}<b>${tl("pgd.n", {n})}</b><span class="num">${esc(av)} → ${esc(bv)}</span>${ic("chev")}</button>`
    : `<span>${ic("swap")}${d.same ? tl("pgd.same", {v: av}) : tl("pgd.words", {v: av})}</span>`;
  el.querySelector("button")?.addEventListener("click", () => pgChgSheet(d.changes, av, bv));
}
function pgChgSheet(ch, av, bv) {
  const MAX = 60;
  // Two lines that mostly share their words show which words changed; unrelated ones read whole.
  const line = (c) => { const runs = c.was && c.now ? wordDiff(c.was, c.now) : null;
    const kin = !!runs && runs.filter((r) => r.type === "same").reduce((n, r) => n + r.text.length, 0) >= 0.4 * Math.max(c.was.length, c.now.length);
    const side = (txt, drop, tag) => kin ? runs.filter((r) => r.type !== drop).map((r) => r.type === "same" ? esc(r.text) : `<${tag}>${esc(r.text)}</${tag}>`).join("") : tag === "del" ? `<del>${esc(txt)}</del>` : esc(txt);
    return (c.was ? `<span class="was">${side(c.was, "add", "del")}</span>` : "") + (c.now ? `<span class="now">${side(c.now, "del", "ins")}</span>` : ""); };
  sheet(`<h3>${tl("pgd.n", {n: ch.length})}</h3><p class="hint num">${esc(av)} → ${esc(bv)}</p>
    <div class="pgdl">${ch.slice(0, MAX).map((c, n) => c.now ? `<button class="pgd press${c.was ? "" : " new"}" data-pd="${n}">${line(c)}</button>` : `<div class="pgd">${line(c)}</div>`).join("")}</div>
    ${ch.length > MAX ? `<p class="hint">${tl("conflict.more", {n: ch.length - MAX})}</p>` : ""}`, (el) => {
    el.querySelectorAll("[data-pd]").forEach((b) => b.onclick = () => { closeSheet(); pgFind(ch[+b.dataset.pd].go, ch[+b.dataset.pd].n); }); });
}
// 승인 settles every request before it, the ones still open too: those are shown first, once.
function owedSheet(it) {
  sheet(`<h3>${tl("owed.h", {n: it.owed.length})}</h3><p class="hint">${tl("owed.sub")}</p>
    <ul class="owedl">${it.owed.slice(0, 3).map((t) => `<li>${t}</li>`).join("")}</ul>
    <div class="cf-acts"><button class="btn xl fill press" id="owedgo">${tl("conflict.approve")}</button><button class="btn xl press" data-sclose>${tl("finishSheet.4")}</button></div>`, (el) => {
    el.querySelector("#owedgo").onclick = () => { it.owedOk = true; closeSheet(); decide("approved"); }; });
}
// Saved comments go straight on to the session; nothing waits for a second button.
// The session gets one short nudge, not the comments: the hook attaches those on that turn.
let sendSeq = 0;
async function sendNow(it) {
  // A send that failed says why: the comment is still unsent, not "on its way".
  let err = null;
  const r = await post("/api/comments/send", {p: it.p, i: it.i, v: it.v}).catch((e) => { err = e; return null; });
  if (err) { toastFail(err.message, tl("err.cmt.meta")); return; }
  // Did it go straight into a live session, or wait for the hook? Ask the same reach check
  // the app uses, then watch the entries: "delivered" is promised only once one is stamped peer.
  const reach = await get(`/api/session/reach?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`).catch(() => null);
  const who = pname(it.dept || "") || tl("sendNow.1"), later = () => tl("sendNow.3", {jo: jo(who, "가", "이")});
  const sent = (r?.log || []).filter((e) => (e.kind === "comment" || e.kind === "message") && handed(e) && !e.ack);
  const ids = sent.filter((e) => !e.delivered).map((e) => e.id);
  // Nothing left to watch: "delivered" only when the log itself shows every one stamped, never on reach alone.
  if (!reach?.reachable || !ids.length) { const ok = !!reach?.reachable && sent.length > 0;
    toast(ok ? tl("sendNow.2", {p0: who}) : later(), 2200, ok ? "delivered" : "later"); return; }
  const me = ++sendSeq, say = (t, ms, m) => { if (me === sendSeq) toast(t, ms, m); };
  say(tl("sendNow.4"), 24000, "sending");
  // Not awaited: callers re-render right after this returns. The courier waits up to 20s for the line.
  (async () => {
    let took = false;
    for (let n = 0; n < 16 && me === sendSeq; n++) {
      await new Promise((ok) => setTimeout(ok, 1500));
      const d = await get(`/api/item?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`).catch(() => null);
      const mine = (d?.log || []).filter((e) => ids.includes(e.id));
      // A comment is never stamped peer: its notice goes into the live session (`nudged`) and
      // the hook attaches the body on the turn that notice starts. That is delivered at once too.
      const now = (e) => e.delivered_via === "peer" || !!(e.nudged && e.delivered);
      if (mine.length && mine.every(now)) return say(tl("sendNow.2", {p0: who}), 2200, "delivered");
      if (mine.length && mine.every((e) => e.delivered)) { took = true; break; }   // the hook took it on a later turn
      if (mine.some((e) => e.delivered && !now(e))) break;
    }
    say(took ? tl("sendNow.2", {p0: who}) : later(), 2200, took ? "delivered" : "later");
  })();
}
// Same "[답]" comment the classic page writes, so departments read answers one way.
// The answers on record: every "[답]" comment of this version, read line by line ("2. 질문 → 답");
// a later answer to the same question replaces the earlier one. An answer written some other way
// (no numbered lines) counts for all the questions, as it always did.
function askAnswers(ask, log, vname) {
  const out = ask.map(() => null);
  (log || []).filter((e) => e.kind === "comment" && e.v === vname && (e.text || "").startsWith("[답]")).forEach((e) => {
    const body = attOf(e.text).words.split("\n").slice(1);
    const ls = body.map((l) => /^(\d+)\.\s.*?→\s*(.+)$/.exec(l.trim())).filter((m) => m && ask[+m[1] - 1]);
    if (ls.length) ls.forEach((m) => { out[+m[1] - 1] = {text: m[2].trim(), at: e.at}; });
    else { const t = body.join(" ").trim() || tl("ask.done"); ask.forEach((q, qi) => { out[qi] = out[qi] || {text: t, at: e.at}; }); }
  });
  return out;
}
const askEdit = {};                       // item id -> the answered questions opened again to change
function wireAsk(it, ask) {
  const box = document.getElementById("ask"), b = document.getElementById("asend"); if (!b) return;
  // Only the questions open on screen are sent: a folded one keeps the answer it has.
  const live = (qi) => box.querySelector(`.aq:not(.done)[data-q="${qi}"]`);
  const pick = ask.map((q, qi) => { const p = +(live(qi)?.dataset.pick ?? -1); return p >= 0 ? p : null; });
  const line = (q, qi) => { const el = live(qi); if (!el) return null; const note = el.querySelector(".anote").value.trim();
    const o = pick[qi] != null ? q.options[pick[qi]] : null;
    return o || note ? `${qi + 1}. ${q.q} → ${[o, note].filter(Boolean).join(" · ")}` : null; };
  // An answer opened to change is sent only once it differs; a question with no answer on
  // record has nothing to differ from, so its preselected recommendation can be sent as it is.
  const was = ask.map((q, qi) => live(qi)?.hasAttribute("data-new") ? null : line(q, qi));
  const lines = () => ask.map(line).filter((l, qi) => l && l !== was[qi]);
  const sync = () => { b.disabled = !lines().length; };
  box.querySelectorAll(".aq:not(.done)").forEach((el) => { const qi = +el.dataset.q;
    el.querySelectorAll(".opt").forEach((o) => o.onclick = () => { pick[qi] = pick[qi] === +o.dataset.a ? null : +o.dataset.a;
      el.querySelectorAll(".opt").forEach((q) => q.classList.toggle("on", +q.dataset.a === pick[qi])); sync(); });
    const t = el.querySelector(".anote"); cmGrow(t);
    t.oninput = () => { cmGrow(t); sync(); };
    t.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing) e.preventDefault(); }; });
  sync();
  b.onclick = async () => { const L = lines(); if (!L.length) return; b.disabled = true;
    try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: `[답]\n${L.join("\n")}`});
      // An answer is not a rejection: "지금 그대로" came back labelled 수정 요청.
      delete askEdit[it.id]; tabPick[it.id] = "ask";
      sendNow(it); await load(); again(); }
    catch (e) { toastFail(e.message, tl("err.words.meta")); b.disabled = false; } };
}
// 승인 is the everyday yes. 확정 (done) is the last word: approved, archived, and the
// department told the work is over - a new push brings the item back either way.
// A decision on the newest version is the end of that look: go straight on to the next one
// waiting, so running through the list is decide, decide, decide - not back, find, open.
async function onward(it, said) {
  const n = it.latest && nextOf(it.id);
  await load();
  // In the workroom the result stays on its stage: the room is the place, not the next item.
  if (wrLive()) { toast(said); again(); return; }
  if (n && D.items.some((x) => iid(x) === iid(n))) { toast(tl("onward.1", {said})); autoPlay = true; nav("item/" + iid(n)); }
  else { toast(said); render(); }
}
let deciding = false;                     // a second A or double-click must not decide twice
// An approval waits five seconds before it goes, so a slipped A can be taken back before the
// department hears of it. Leaving the page sends it at once.
let okLater = null;
function sendOk() {
  const o = okLater; if (!o) return Promise.resolve(); okLater = null; clearTimeout(o.timer);
  // The approval names the review revision this screen read: if a version or an ask landed in
  // the five seconds (or before), the server says 409 and the reader sees what changed first.
  return fetch("/api/status", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"},
    body: JSON.stringify({p: o.it.p, i: o.it.i, v: o.it.v, status: "approved", rev: o.it.rev})})
    .then(async (r) => { if (!r.ok) { const j = await r.json().catch(() => ({})); throw Object.assign(new Error(j.error || tl("get.1")), {status: r.status, body: j}); } })
    .catch((e) => isConflict(e) && !document.hidden ? approveConflict(o.it, e.body)
      // The screen has usually moved on to the next result by now, so a toast that fades would
      // leave the reader believing it was approved: it stays up with a way to send it again.
      : toastAct(tl("sendOk.2", {p0: e.message === "Failed to fetch" ? tl("sendOk.1") : e.message}), tl("room.retry"),
        // Sent directly, not through okLater: another approval may be waiting out its five seconds there.
        () => post("/api/status", {p: o.it.p, i: o.it.i, v: o.it.v, status: "approved", rev: o.it.rev})
          .then(() => { toast(tl("decide.1", {p0: pname(o.it.dept || "") || tl("lib.3")})); return load().then(render); })
          .catch((e2) => isConflict(e2) ? approveConflict(o.it, e2.body) : toast(tl("sendOk.2", {p0: e2.message}), 8000)), 30000));
}
function approveConflict(it, body) {
  conflictSheet(body, {v: it.v, log: it.log, again: tl("conflict.approve"),
    retry: async (b) => { await post("/api/status", {p: it.p, i: it.i, v: it.v, status: "approved", rev: b.rev}); toast(tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")})); await load(); render(); },
    reload: async () => { await load(); if (detail?.[0] === "item" && openItem?.id === it.id) again(); else nav("item/" + it.id); }});
}
addEventListener("pagehide", () => { sendOk(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) sendOk(); });
async function decide(status) {
  const it = openItem || {};
  if (deciding) return;
  if (status === "changes") return openCmt();
  if (status === "done") return finishSheet(it);
  if (status === "approved" && it.owed?.length && !it.owedOk) return owedSheet(it);
  if (status === "approved") {
    await sendOk();                          // one held at a time
    const n = it.latest && nextOf(it.id);
    const o = okLater = {it};                // sent when the toast's time is up (it waits while the toast is held)
    toastAct(tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")}), tl("toggleFav.3"), () => {
      if (!okLater) return toast(tl("decide.2"));
      clearTimeout(okLater.timer); const back = okLater.it; okLater = null;
      toast(tl("approveMany.3"), 2200, "undo"); wrLive() ? again() : nav("item/" + back.id); }, 5000, "approve",
      () => { if (okLater === o) sendOk().then(load).then(() => {
        if (wrLive()) again(); else if (!document.activeElement?.matches?.("input,textarea,gk-select")) render(); }); });
    // On a stage the result stays put; its buttons wait out the five seconds the approval can be taken back.
    if (wrLive()) { const c = stageMount.el.querySelector(".decide"); if (c) { c.querySelectorAll("button").forEach((b) => { b.disabled = true; }); c.querySelector("p").textContent = tl("decide.3"); } return; }
    if (n && D.items.some((x) => iid(x) === iid(n))) { autoPlay = true; nav("item/" + iid(n)); }
    else back();
    return;
  }
  deciding = true;
  try {
    if (status === "reopen") {
      await post("/api/archive", {p: it.p, i: it.i, on: false});
      toast(tl("decide.4"), 2200, "undo");
    } else {
      // Refused here, nothing moved: the failure says the verdict is as it was.
      await post("/api/status", {p: it.p, i: it.i, v: it.v, status}).catch((e) => { e.kept = tl("err.verdict.meta"); throw e; });
      if (status === "approved") return await onward(it, tl("decide.1", {p0: pname(it.dept || "") || tl("lib.3")}));
      toast(tl("decide.5"), 2200, "undo");
    }
    await load(); wrLive() ? again() : render();
  } catch (e) { e.kept ? toastFail(e.message, e.kept) : toast(e.message); }
  finally { deciding = false; }
}
function finishSheet(it) {
  sheet(`<h3>${tl("finishSheet.1")}</h3><p class="hint">${more1(tl("finishSheet.2"), tl("finishSheet.3"))}</p>
    <div class="cf-acts"><button class="btn xl fill press" id="fin">${tl("itemView.57")}</button><button class="btn xl press" data-sclose>${tl("finishSheet.4")}</button></div>`, (el) => {
    const b = el.querySelector("#fin");
    b.onclick = async () => { b.disabled = true;
      try {
        if (it.status !== "approved") await post("/api/status", {p: it.p, i: it.i, v: it.v, status: "approved", rev: it.rev}).catch((e) => {
          if (isConflict(e)) { closeSheet(); setTimeout(() => approveConflict(it, e.body), 280); e.shown = true; } throw e; });
        await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: "[확정] 이 작업은 끝났어요. 더 고칠 것 없어요."});
        await post("/api/comments/send", {p: it.p, i: it.i, v: it.v}).catch(() => null);
        await post("/api/archive", {p: it.p, i: it.i, on: true});
        await post("/api/storage/final", {p: it.p, i: it.i, v: it.v}).catch(() => null);   // 확정 = also the 최종본
        closeSheet(); toast(tl("finishSheet.5"), 2600, "finish"); await load(); wrLive() ? again() : render();
      } catch (e) { if (!e.shown) toast(e.message); b.disabled = false; } };
  });
}
// ---------- full-screen viewer: swipe between a version's files ----------
// The strip follows the finger 1:1, keeps the release velocity, projects where the flick
// was going and settles on a spring from wherever it is - so it can be caught mid-flight.
const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function springTo(get0, set, to, v0, done, response = 0.36, damping = 1) {
  const k = (2 * Math.PI / response) ** 2, c = 4 * Math.PI * damping / response;
  let x = get0(), v = v0, last = performance.now(), id, dead = false;
  const step = (now) => { const dt = Math.min(0.032, (now - last) / 1000); last = now;
    for (let n = 0; n < 4; n++) { const a = -k * (x - to) - c * v; v += a * dt / 4; x += v * dt / 4; }
    if (Math.abs(x - to) < 0.3 && Math.abs(v) < 8) { set(to); done && done(); return; }
    // set() may stop this very spring (a card that flew far enough hands over): no next frame then.
    set(x); if (!dead) id = requestAnimationFrame(step); };
  id = requestAnimationFrame(step);
  return () => { dead = true; cancelAnimationFrame(id); };
}
const project = (v, r = 0.998) => (v / 1000) * r / (1 - r);
function viewer(files, start, it = openItem, from = null) {
  if (!files.length) return;
  // 설정 → 베타 "pai": the speed chip, the full-screen button, tap to play and the stage's video keys.
  const pai = !!window.genokBeta?.("pai");
  const vseqs = SeqGroup.runs(files);
  const el = document.createElement("div"); el.className = "vw"; el.setAttribute("role", "dialog"); el.setAttribute("aria-label", tl("itemView.38"));
  el.innerHTML = `<div class="vbg"></div><div class="vtrack">${files.map((f, n) => { const near = Math.abs(n - start) <= 1;
      // Only the slide on screen and its neighbours load now; warm() fetches the rest as they come near.
      return `<div class="vs${f.kind !== "video" && f.thumb && near ? ` thb" style="--thb:url('${esc(f.thumb)}')` : ""}">${f.kind === "video"
      ? `<video src="${esc(f.play || f.url)}"${loopOn ? " loop" : ""} playsinline preload="${near ? "metadata" : "none"}" ${sound() ? "" : "muted"} ${f.thumb ? `poster="${esc(f.thumb)}"` : ""}></video>`
      : `<img src="${esc(f.play || f.url)}" alt="${esc(f.name)}"${n === start ? "" : ` loading="lazy" decoding="async"`} draggable="false" onload="this.parentNode.classList.remove('thb')">`}</div>`; }).join("")}</div>
    <div class="vspin" hidden>${loadingHtml("", {tight: true})}</div>
    <div class="vtop"><span class="vn num"></span><span class="vname"></span><button class="ib press vplay" type="button" hidden aria-label="${tl("itemView.39")}">${ic("play")}</button><button class="ib press vfs" type="button" data-vfs="-1" hidden aria-label="${tl("itemView.41")}" title="${tl("itemView.42")}">${ic("chev")}</button><button class="ib press vfs" type="button" data-vfs="1" hidden aria-label="${tl("itemView.45")}" title="${tl("itemView.46")}">${ic("chev")}</button>${pai ? `<button class="ib press frate num${rate !== 1 ? " on" : ""}" type="button" hidden aria-label="${tl("itemView.47")}" title="${tl("itemView.48")}">${rate}×</button>` : ""}<button class="ib press vmute" type="button" hidden aria-label="${tl("vol.off")}" title="${tl("vol.off")}">${ic("sound")}</button><span class="vz num"></span>${files.length > 1 ? `<button class="ib press vsb" type="button" aria-label="${tl("viewer.strip")}" title="${tl("viewer.strip")}">${ic("grid")}</button>` : ""}${pai && (document.fullscreenEnabled || document.webkitFullscreenEnabled) ? `<button class="ib press vfull" type="button" aria-label="${tl("vfull.on")}" title="${tl("vfull.on")}">${ic("full")}</button>` : ""}<a class="ib press" target="_blank" rel="noopener" aria-label="${tl("viewer.3")}">${ic("ext")}</a><button class="ib press" data-vclose aria-label="${tl("itemView.114")}">${ic("x")}</button></div>
    ${files.length > 1 ? `<button class="vnav l press" aria-label="${tl("itemView.27")}">${ic("chev")}</button><button class="vnav r press" aria-label="${tl("itemView.28")}">${ic("chev")}</button>` : ""}
    <div class="vscrub" hidden><u class="fill"></u><i class="ph"></i></div>
    ${files.length > 1 ? `<div class="vstrip">${files.map((f, n) => { const run = SeqGroup.at(vseqs, n); if (run && n > run.start) return "";
      return run ? `<button class="vt vsq press" type="button" data-vt="${n}" data-vte="${run.end}" aria-label="${tl("seq.tile", {a: f.name, b: files[run.end].name, n: run.count})}"><img src="${esc(f.thumb || f.play || f.url)}" alt="" loading="lazy" draggable="false"><em class="num">${run.count}</em></button>` : `<button class="vt press" type="button" data-vt="${n}" aria-label="${esc(f.name)}">${f.kind === "video" && !f.thumb ? ic("play") : `<img src="${esc(f.kind === "video" ? f.thumb : f.thumb || f.play || f.url)}" alt="" loading="lazy" draggable="false">`}</button>`; }).join("")}</div>` : ""}
    ${it?.p ? `<form class="vcm"><input placeholder="${tl("viewer.1")}" autocomplete="off" enterkeyhint="send"><button class="press" aria-label="${tl("viewer.2")}">${ic("up")}</button></form>` : ""}`;
  document.body.appendChild(el); el.setAttribute("aria-modal", "true");
  const unhold = modalHold(el, document.activeElement);
  el.querySelectorAll("video").forEach((vd) => { vd.playbackRate = rate; });
  const tr = el.querySelector(".vtrack"), bg = el.querySelector(".vbg"), W = () => el.clientWidth, H = () => el.clientHeight;
  let idx = start, x = -start * W(), y = 0, stop = null, stopY = null, stopZ = null, wrote = false;
  // Zoom of the picture on screen: scale and offset from its resting centre.
  let z = {s: 1, tx: 0, ty: 0};
  // A paused video frame zooms like a picture: render noise and edges need a close look too.
  const media = () => { const s = tr.children[idx], v = s?.querySelector("video"); return s?.querySelector("img") || (v && (v.paused || z.s > 1.02) ? v : null); };
  // How much the picture is shrunk to fit, and the zoom limit from it: the stage's rule, so a 4K
  // render on a phone still reaches its real size. The % is the real size too (100% = 1:1 pixels).
  const zfit = () => { const m = media(), nw = m && (m.videoWidth || m.naturalWidth); return nw && m.offsetWidth ? m.offsetWidth / nw : null; };
  const zmax = () => { const f = zfit(); return Math.max(8, f ? 4 / f : 8); };
  const paintZ = () => { const m = media(); if (m) { m.style.transform = z.s === 1 && !z.tx && !z.ty ? "" : `translate3d(${z.tx}px,${z.ty}px,0) scale(${z.s})`;
    // Above real size show hard pixels, as RV and Nuke do; fitted and shrunk views stay smooth.
    m.style.imageRendering = z.s * (zfit() || 1) > 1 ? "pixelated" : ""; }
    // Back at fit the slot shows the video frame again: a paused video fires no timeupdate to restore it.
    el.querySelector(".vz").textContent = z.s > 1.02 ? `${Math.round(z.s * (zfit() || 1) * 100)}%` : ""; if (z.s <= 1.02) frameNow(); el.classList.toggle("zoomed", z.s > 1.02); };
  const bounds = (s) => { const m = media(); if (!m) return {x: 0, y: 0};
    const w = m.offsetWidth * s, h = m.offsetHeight * s; return {x: Math.max(0, (w - W()) / 2), y: Math.max(0, (h - H()) / 2)}; };
  const zoomTo = (s, tx, ty) => { stopZ && stopZ(); const b = bounds(s), to = {s, tx: Math.max(-b.x, Math.min(b.x, tx)), ty: Math.max(-b.y, Math.min(b.y, ty))}, from = {...z};
    if (RM()) { z = to; paintZ(); return; }
    let t = 0; stopZ = springTo(() => t, (v) => { t = v; z = {s: from.s + (to.s - from.s) * v, tx: from.tx + (to.tx - from.tx) * v, ty: from.ty + (to.ty - from.ty) * v}; paintZ(); }, 1, 0, () => { z = to; paintZ(); }, 0.3, 1); };
  // Zoom about a screen point: the spot under the finger or cursor stays put.
  const about = (s, px, py, base = z) => { const cx = W() / 2, cy = H() / 2;
    return {s, tx: (px - cx) - ((px - cx) - base.tx) / base.s * s, ty: (py - cy) - ((py - cy) - base.ty) / base.s * s}; };
  const unzoom = () => { stopZ && stopZ(); const m = media(); if (m) m.style.transform = ""; z = {s: 1, tx: 0, ty: 0}; paintZ(); };
  const paint = () => { tr.style.transform = `translate3d(${x}px,${y}px,0)`; bg.style.opacity = String(1 - Math.min(0.6, Math.abs(y) / 500)); };
  // A video here steps frames like the stage does; the frame shows where the zoom % would.
  const vidAt = () => tr.children[idx]?.querySelector("video") || null;
  const fsOn = () => (document.fullscreenElement || document.webkitFullscreenElement) === el;
  const fsExit = () => { if (fsOn()) Promise.resolve((document.exitFullscreen || document.webkitExitFullscreen).call(document)).then(() => { try { screen.orientation?.unlock?.(); } catch (e) {} }, () => {}); };
  const frameNow = () => { const vd = vidAt(), f = files[idx]; if (vd) el.querySelector(".vz").textContent = f.fps ? `f${frameOf(vd.currentTime, f.fps, f.start)}` : clock(vd.currentTime, true); };
  tr.querySelectorAll("video").forEach((vd) => ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt()) frameNow(); })));
  // A video still showing its poster takes the poster's size (the 640×360 thumb) until it plays or
  // seeks, so a neighbour slid in small and jumped; a seek once its size is known drops the poster.
  tr.querySelectorAll("video").forEach((vd) => vd.addEventListener("loadedmetadata", () => { if (vd.paused && !vd.currentTime) vd.currentTime = 0; }, {once: true}));
  // The I-O stretch set on the stage holds here too (kept by item and file), and I / O / X set it.
  const loopKey = (n) => it?.id && it.pics?.[n] === files[n] ? `${it.id}#${n}` : null, abSig = new AbortController();
  [...tr.children].forEach((s, n) => { const vd = s.querySelector("video"); if (vd) wrapAB(vd, () => abFor(loopKey(n)), () => files[n].fps, abSig); });
  // §4.14: native controls는 없앴으니 재생버튼·스크럽바·버퍼링 스피너를 직접 그린다.
  const vplayBtn = el.querySelector(".vplay"), vscrub = el.querySelector(".vscrub"), vspin = el.querySelector(".vspin");
  const updatePlayIcon = (vd) => { if (!vplayBtn) return;
    const playing = vd && !vd.paused;
    vplayBtn.innerHTML = ic(playing ? "pause" : "play");
    vplayBtn.setAttribute("aria-label", tl(playing ? "showPlay.1" : "itemView.39")); };
  const putScrub = (vd) => { if (!vscrub) return; const dur = Number.isFinite(vd.duration) && vd.duration > 0 ? vd.duration : 1;
    const f = Math.min(1, Math.max(0, vd.currentTime / dur)) * 100;
    vscrub.querySelector(".fill").style.width = f + "%"; vscrub.querySelector(".ph").style.left = f + "%"; };
  vplayBtn?.addEventListener("click", () => { const vd = vidAt(); if (!vd) return; vd.paused ? playNow(vd) : vd.pause(); });
  // One frame per tap, running on while held - the same buttons as under the stage.
  const vstep = (n) => stepVideo(vidAt(), files[idx], n), vfsBtns = el.querySelectorAll(".vfs");
  vfsBtns.forEach((b) => holdStep(b, +b.dataset.vfs, vstep));
  const vmuteBtn = el.querySelector(".vmute");
  // S and J/L change the speed here too; the chip keeps it in sight, and a tap goes round like the stage's.
  const vrateBtn = el.querySelector(".frate");
  vrateBtn?.addEventListener("click", nextRate);
  vmuteBtn.addEventListener("click", () => flipMute(vidAt()));
  let scrubbing = false, scrubWasPlaying = false;
  const seekTo = (clientX) => { const vd = vidAt(); if (!vd || !vscrub) return;
    const r = vscrub.getBoundingClientRect(), dur = Number.isFinite(vd.duration) && vd.duration > 0 ? vd.duration : 1;
    vd.currentTime = Math.min(1, Math.max(0, (clientX - r.left) / r.width)) * dur; putScrub(vd); };
  vscrub?.addEventListener("pointerdown", (e) => { const vd = vidAt(); if (!vd) return; e.preventDefault();
    try { vscrub.setPointerCapture(e.pointerId); } catch {} scrubbing = true; scrubWasPlaying = !vd.paused; vd.pause(); seekTo(e.clientX); });
  vscrub?.addEventListener("pointermove", (e) => { if (scrubbing) seekTo(e.clientX); });
  const scrubEnd = (e) => { if (!scrubbing) return; scrubbing = false; try { vscrub.releasePointerCapture(e.pointerId); } catch {}
    if (scrubWasPlaying) playNow(vidAt()); };
  vscrub?.addEventListener("pointerup", scrubEnd); vscrub?.addEventListener("pointercancel", scrubEnd);
  tr.querySelectorAll("video").forEach((vd) => {
    vd.addEventListener("play", () => { if (vd === vidAt()) updatePlayIcon(vd); });
    vd.addEventListener("pause", () => { if (vd === vidAt()) updatePlayIcon(vd); });
    vd.addEventListener("volumechange", () => { if (vd === vidAt()) showMute(vmuteBtn, vd); });
    vd.addEventListener("waiting", () => { if (vd === vidAt() && vspin) vspin.hidden = false; });
    ["playing", "canplay"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt() && vspin) vspin.hidden = true; }));
    ["timeupdate", "seeked"].forEach((ev) => vd.addEventListener(ev, () => { if (vd === vidAt() && !scrubbing) putScrub(vd); }));
  });
  const label = () => { el.querySelector(".vn").textContent = files.length > 1 ? `${idx + 1} / ${files.length}` : ""; frameNow();
    el.querySelector(".vname").textContent = files[idx].name; el.querySelector(".vtop a").href = files[idx].url;
    el.querySelectorAll("video").forEach((vd, n) => { if (n !== idx) vd.pause(); });
    const vd = vidAt();
    el.classList.toggle("vid", !!vd);
    el.querySelectorAll(".vt").forEach((b) => b.classList.toggle("on", idx >= +b.dataset.vt && idx <= +(b.dataset.vte || b.dataset.vt)));
    el.querySelector(".vt.on")?.scrollIntoView({block: "nearest", inline: "nearest"});
    if (vplayBtn) vplayBtn.hidden = !vd; vfsBtns.forEach((b) => { b.hidden = !vd; }); if (vscrub) vscrub.hidden = !vd; if (vspin) vspin.hidden = true;
    vmuteBtn.hidden = !vd || files[idx].audio === false; if (vrateBtn) vrateBtn.hidden = !vd;
    if (vd) { updatePlayIcon(vd); putScrub(vd); showMute(vmuteBtn, vd); } };
  const vidOf = (n) => tr.children[n]?.querySelector("video");
  const warm = () => { for (let n = idx - 1; n <= idx + 1; n++) { const s = tr.children[n]; if (!s) continue;
    const m = s.querySelector("img"), v = s.querySelector("video");
    if (m && m.loading === "lazy") m.loading = "eager"; if (v && v.preload === "none") v.preload = "metadata"; } };
  const go = (n, vel = 0, glide = false) => { const was = idx; idx = Math.max(0, Math.min(files.length - 1, n)); warm();
    if (was !== idx) { const m = tr.children[was]?.querySelector("img"); if (m) { m.style.transform = ""; m.style.imageRendering = ""; } z = {s: 1, tx: 0, ty: 0}; paintZ(); }
    label(); stop && stop();
    if (was !== idx) playNow(vidOf(idx));
    if (!glide && was !== idx) { x = -idx * W(); y = 0; paint(); return; }
    if (RM()) { x = -idx * W(); y = 0; tr.style.transition = "opacity .2s"; tr.style.opacity = ".4"; paint(); requestAnimationFrame(() => tr.style.opacity = "1"); return; }
    stop = springTo(() => x, (v) => { x = v; paint(); }, -idx * W(), vel, null, 0.34, 1);
    if (y) { stopY && stopY(); stopY = springTo(() => y, (v) => { y = v; paint(); }, 0, 0, null, 0.3, 1); } };
  // popped: the phone's back button already took our history entry; otherwise we take it back ourselves.
  const close = (popped) => { vwClose = null; fsExit(); stop && stop(); stopY && stopY(); stopZ && stopZ(); abSig.abort(); removeEventListener("keydown", key); removeEventListener("resize", fit);
    removeEventListener("popstate", pop);
    if (popped !== true && history.state?.vw) history.back();
    const lv = vidAt(), lt = lv ? lv.currentTime : 0, lp = !!lv && !lv.paused;
    el.querySelectorAll("video").forEach((vd) => vd.pause());
    if (wrote) again();
    if (from?.back && lv && idx === start) from.back(lt, lp);
    unhold();
    if (RM()) { el.remove(); return; }
    el.classList.add("out"); setTimeout(() => el.remove(), 220); };
  const key = (e) => { if (e.target.closest?.(".vcm")) { if (e.key === "Escape") e.target.blur(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;   // Ctrl +/-/0 is the browser's zoom
    if (e.key === "Escape" && fsOn()) { fsExit(); return; }
    if (e.key === "Escape") { if (z.s > 1.02) zoomTo(1, 0, 0); else close(); }
    else if (vidAt() && (e.key === "ArrowRight" || e.key === "ArrowLeft")) { e.preventDefault(); stepVideo(vidAt(), files[idx], (e.key === "ArrowRight" ? 1 : -1) * (e.shiftKey ? 10 : 1)); }
    else if (vidAt() && (e.key === "s" || e.key === "S")) nextRate();
    // , . step a frame, J K L shuttle, Home / End jump to the ends - the stage's keys, kept in full screen.
    else if (vidAt() && (e.key === "," || e.key === ".")) { e.preventDefault(); vstep(e.key === "." ? 1 : -1); }
    else if (vidAt() && /^[jkl]$/i.test(e.key)) jkl(e.key.toLowerCase(), vidAt());
    else if (vidAt() && (e.key === "Home" || e.key === "End")) { e.preventDefault(); const vd = vidAt();
      if (e.key === "Home") vd.currentTime = 0; else if (Number.isFinite(vd.duration)) vd.currentTime = Math.max(0, vd.duration - 0.001); }
    else if (vidAt() && e.key === " ") { e.preventDefault(); const vd = vidAt(); vd.paused ? vd.play().catch(() => {}) : vd.pause(); }
    else if (vidAt() && /^[iox]$/i.test(e.key) && loopKey(idx)) setAB(e.key.toLowerCase(), vidAt(), loopKey(idx), files[idx]);
    else if (vidAt() && (e.key === "m" || e.key === "M") && it === openItem) jumpMark(e.shiftKey ? -1 : 1, vidAt(), files[idx]);
    // ↑ ↓ jump a second and 0–9 jump to 0%–90%, as on the stage; 0 on a zoomed frame still unzooms.
    else if (pai && vidAt() && (e.key === "ArrowUp" || e.key === "ArrowDown")) { e.preventDefault(); const vd = vidAt();
      const end = Number.isFinite(vd.duration) ? vd.duration - 0.001 : Infinity; vd.currentTime = Math.max(0, Math.min(end, vd.currentTime + (e.key === "ArrowUp" ? 1 : -1))); }
    else if (pai && vidAt() && /^[0-9]$/.test(e.key) && !(e.key === "0" && z.s > 1.02) && Number.isFinite(vidAt().duration)) { e.preventDefault(); vidAt().currentTime = vidAt().duration * (+e.key) / 10; }
    // PgUp / PgDn change files on a still and on a video alike (a video's arrows are frames).
    else if (pai && (e.key === "PageUp" || e.key === "PageDown")) { e.preventDefault(); go(idx + (e.key === "PageDown" ? 1 : -1)); }
    else if (e.key === "ArrowRight") go(idx + 1); else if (e.key === "ArrowLeft") go(idx - 1);
    else if (e.key === "+" || e.key === "=") zoomTo(Math.min(zmax(), z.s * 1.5), z.tx * 1.5, z.ty * 1.5);
    else if (e.key === "-") zoomTo(Math.max(1, z.s / 1.5), z.tx / 1.5, z.ty / 1.5);
    else if (e.key === "0") zoomTo(1, 0, 0); };
  addEventListener("keydown", key); vwClose = close;
  // Back on a phone closes full screen and stays on the result (it used to leave to the list).
  const pop = () => close(true);
  try { history.pushState({vw: 1}, ""); addEventListener("popstate", pop); } catch (e) {}
  if (from && vidOf(start)) { const vd = vidOf(start), seek = () => { try { vd.currentTime = from.t; } catch (e) {} if (from.play) playNow(vd); };
    vd.readyState >= 1 ? seek() : vd.addEventListener("loadedmetadata", seek, {once: true}); }
  const fit = () => { stop && stop(); unzoom(); x = -idx * W(); paint(); }; addEventListener("resize", fit);
  el.querySelector("[data-vclose]").onclick = () => close();
  // Focus the dialog itself, not the close button: Space or Enter on a focused button would close
  // the viewer on a still, while the same Space plays on a video slide.
  el.tabIndex = -1; el.focus({preventScroll: true});
  // The file strip along the bottom: every file of the version, folded or shown by the button
  // in the top bar. The choice is kept for the next time.
  const vsb = el.querySelector(".vsb"), stripSet = (on) => { el.classList.toggle("strip", on); vsb.setAttribute("aria-pressed", String(on)); };
  if (vsb) { let on = true; try { on = localStorage.getItem("vstrip") !== "0"; } catch (e) {}
    stripSet(on);
    vsb.onclick = () => { on = !on; stripSet(on); try { localStorage.setItem("vstrip", on ? "1" : "0"); } catch (e) {} };
    el.querySelector(".vstrip").onclick = (e) => { const b = e.target.closest("[data-vt]"); if (b) go(+b.dataset.vt); }; }
  // True full screen (browser bars gone), as YouTube and Frame.io have; Esc leaves it first. A wide
  // video on a phone also turns the screen sideways where the browser allows it.
  const vfull = el.querySelector(".vfull");
  vfull?.addEventListener("click", () => { if (fsOn()) return fsExit();
    Promise.resolve((el.requestFullscreen || el.webkitRequestFullscreen).call(el, {navigationUI: "hide"})).then(() => {
      const vd = vidAt(); if (!wide() && vd && vd.videoWidth > vd.videoHeight) screen.orientation?.lock?.("landscape").catch(() => {}); }).catch(() => {}); });
  const fsShow = () => { const on = fsOn();
    if (vfull) { const lb = on ? tl("vfull.off") : tl("vfull.on"); vfull.innerHTML = ic(on ? "unfull" : "full"); vfull.setAttribute("aria-label", lb); vfull.title = lb; }
    if (!on) try { screen.orientation?.unlock?.(); } catch (e) {} };
  ["fullscreenchange", "webkitfullscreenchange"].forEach((ev) => document.addEventListener(ev, fsShow, {signal: abSig.signal}));
  el.querySelector(".vnav.l")?.addEventListener("click", () => go(idx - 1));
  el.querySelector(".vnav.r")?.addEventListener("click", () => go(idx + 1));
  // A comment from here says which file it is about.
  const form = el.querySelector(".vcm");
  form?.querySelector("input").addEventListener("focus", () => vidAt()?.pause());
  if (form) form.onsubmit = async (e) => { e.preventDefault(); const i = form.querySelector("input"), text = i.value.trim(); if (!text) return;
    i.disabled = true;
    const r = abFor(loopKey(idx)), at = r ? spanWhen(r.a, r.last ?? r.b, files[idx].fps, files[idx].start) : whenOf(vidAt(), files[idx]);
    try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: `[${[files[idx].name, at].filter(Boolean).join(" ")}] ${text}`}); i.value = ""; wrote = true; await sendNow(it); }
    catch (err) { toastFail(err.message, tl("err.words.meta")); }
    i.disabled = false; };
  // Pointers: one finger pages (or pans when zoomed), vertical dismisses, two fingers pinch,
  // a double tap zooms in on that spot or back out. Every one follows the finger 1:1.
  const pts = new Map(); let drag = null, pinch = null, lastTap = null, tapTimer = null;
  // A video is the picture here: its native controls are gone (§4.14) and the drawn scrub bar is its
  // own element (.vscrub) off the video, so the whole frame pans, pinches and taps like a picture.
  // onControls used to skip its lower 110px, half of a wide video on a phone.
  tr.addEventListener("pointerdown", (e) => {
    pts.set(e.pointerId, [e.clientX, e.clientY]);
    stop && stop(); stopY && stopY(); stopZ && stopZ();
    // A second finger pinches, never pages or dismisses: a playing video pauses first so its frame
    // zooms (Frame.io, Photos and RV zoom a playing clip too), and a slide already dragged springs back.
    // (Beta "pai" only; off, two fingers on a video page or close as before.)
    if (pts.size === 2 && (pai || media())) { if (pai) { const vd = vidAt(); if (vd && !vd.paused) vd.pause();
      clearTimeout(tapTimer); if (drag?.axis === "x" || drag?.axis === "y") go(idx, 0, true); } drag = null;
      if (!media()) return; const [a, b] = [...pts.values()];
      pinch = {d0: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, m0: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], z0: {...z}};
      pts.forEach((_, id) => { try { tr.setPointerCapture(id); } catch {} }); return; }
    if (pts.size > 2) return;
    drag = {id: e.pointerId, sx: e.clientX, sy: e.clientY, x0: x, z0: {...z}, axis: null, h: [[e.clientX, e.clientY, e.timeStamp]], img: !!e.target.closest("img, video"), vd: e.target.closest("video")}; });
  tr.addEventListener("pointermove", (e) => { if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, [e.clientX, e.clientY]);
    if (pinch && pts.size >= 2) { const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]), m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
      let s = pinch.z0.s * d / pinch.d0; if (s < 1) s = 1 - rubber(1 - s, 1, 0.4); if (s > zmax()) s = zmax();
      const r = about(s, pinch.m0[0], pinch.m0[1], pinch.z0); z = {s, tx: r.tx + m[0] - pinch.m0[0], ty: r.ty + m[1] - pinch.m0[1]}; paintZ(); return; }
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.axis) { if (Math.hypot(dx, dy) < 10) return; drag.axis = drag.z0.s > 1.02 ? "pan" : Math.abs(dx) > Math.abs(dy) ? "x" : "y"; tr.setPointerCapture(e.pointerId); }
    drag.h.push([e.clientX, e.clientY, e.timeStamp]); if (drag.h.length > 5) drag.h.shift();
    if (drag.axis === "pan") { const b = bounds(z.s); let tx = drag.z0.tx + dx, ty = drag.z0.ty + dy;
      if (tx > b.x) tx = b.x + rubber(tx - b.x, W()); else if (tx < -b.x) tx = -b.x - rubber(-b.x - tx, W());
      if (ty > b.y) ty = b.y + rubber(ty - b.y, H()); else if (ty < -b.y) ty = -b.y - rubber(-b.y - ty, H());
      z = {...z, tx, ty}; paintZ(); return; }
    if (drag.axis === "x") { let nx = drag.x0 + dx; const min = -(files.length - 1) * W();
      if (nx > 0) nx = rubber(nx, W()); else if (nx < min) nx = min - rubber(min - nx, W()); x = nx; }
    else y = dy;
    paint(); });
  const up = (e) => { if (!pts.has(e.pointerId)) return; pts.delete(e.pointerId);
    if (pinch) { if (pts.size < 2) { pinch = null; drag = null; zoomTo(z.s < 1.05 ? 1 : z.s, z.s < 1.05 ? 0 : z.tx, z.s < 1.05 ? 0 : z.ty); } return; }
    if (!drag || e.pointerId !== drag.id) return; const d = drag; drag = null;
    const a = d.h[0], b = d.h[d.h.length - 1], dt = Math.max(1, b[2] - a[2]), vx = (b[0] - a[0]) / dt * 1000, vy = (b[1] - a[1]) / dt * 1000;
    if (!d.axis) {                                           // a tap
      const now = e.timeStamp;
      if (lastTap && now - lastTap.t < 300 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 30 && media()) {
        clearTimeout(tapTimer); lastTap = null;
        if (z.s > 1.02) zoomTo(1, 0, 0); else { const r = about(2.5, e.clientX, e.clientY, {s: 1, tx: 0, ty: 0}); zoomTo(2.5, r.tx, r.ty); }
        return; }
      lastTap = {t: now, x: e.clientX, y: e.clientY};
      // One tap beside the picture closes, once it is clear no second tap is coming. A video is the
      // picture, so a tap on it stays (a lone video never closed on a tap before either).
      if (!d.img && z.s <= 1.02) { clearTimeout(tapTimer); tapTimer = setTimeout(close, 300); }
      // A tap on a video at fit plays or pauses it, as the stage's click does (Frame.io, YouTube, Photos).
      else if (pai && d.vd && z.s <= 1.02) { const vd = d.vd; clearTimeout(tapTimer);
        tapTimer = setTimeout(() => { if (el.isConnected && vd === vidAt()) vd.paused ? playNow(vd) : vd.pause(); }, 300); }
      return; }
    if (d.axis === "pan") { const t = 0.35; zoomTo(z.s, z.tx + vx * t / 2, z.ty + vy * t / 2); return; }
    if (d.axis === "y") { if (Math.abs(y) + Math.abs(project(vy)) * 0.3 > 140) return close(); return go(idx, 0, true); }
    const target = Math.round(-(x + project(vx)) / W());
    go(Math.max(idx - 1, Math.min(idx + 1, target)), vx, true); };
  tr.addEventListener("pointerup", up); tr.addEventListener("pointercancel", up);
  // The wheel zooms a playing video the same way: scrolling in pauses it, then zooms the frame.
  tr.addEventListener("wheel", (e) => { if (!media()) { const vd = pai && vidAt(); if (!vd || e.deltaY >= 0) return; vd.pause(); } e.preventDefault();
    const s = Math.max(1, Math.min(zmax(), z.s * Math.exp(-e.deltaY * 0.0015)));
    if (s === 1) { z = {s: 1, tx: 0, ty: 0}; paintZ(); return; }
    const r = about(s, e.clientX, e.clientY), b = bounds(s);
    z = {s, tx: Math.max(-b.x, Math.min(b.x, r.tx)), ty: Math.max(-b.y, Math.min(b.y, r.ty))}; paintZ(); }, {passive: false});
  paint(); label();
  if (!RM()) { el.classList.add("from"); requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("from"))); }
}
const rubber = (o, d, c = 0.55) => (o * d * c) / (d + c * Math.abs(o));
function rejectSheet(it) {
  const opts = it.reject.length ? rejectList(it.reject) : [tl("rejectSheet.1"), tl("rejectSheet.2"), tl("rejectSheet.3"), tl("rejectSheet.4")];
  // The words come first: a pick alone told the department too little (user, 2026-09-29).
  sheet(`<h3>${tl("rejectSheet.5")}</h3>
    <textarea id="rj" rows="3" enterkeyhint="send" placeholder="${tl("rejectSheet.6")}"></textarea>
    <div class="sub rjq">${tl("rejectSheet.7")}</div><div class="opts">${opts.map((o, n) => `<button class="opt press" data-opt="${n}">${esc(o)}</button>`).join("")}</div>
    <button class="btn xl fill press" id="rjs" disabled>${tl("rejectSheet.8")}</button>`, (el) => {
    let pick = null; const t = el.querySelector("#rj"), b = el.querySelector("#rjs");
    const sync = () => { b.disabled = pick == null && !t.value.trim(); };
    el.querySelectorAll(".opt").forEach((o) => o.onclick = () => { pick = pick === +o.dataset.opt ? null : +o.dataset.opt;
      el.querySelectorAll(".opt").forEach((q) => q.classList.toggle("on", +q.dataset.opt === pick)); sync(); });
    t.oninput = sync; enterSends(t, b);
    b.onclick = async () => { b.disabled = true; await settled(t);
      const words = [pick != null ? opts[pick] : null, t.value.trim()].filter(Boolean).join(" · ");
      if (!words) { b.disabled = false; return; }
      try { await post("/api/comment", {p: it.p, i: it.i, v: it.v, text: pick != null ? `[거절] ${words}` : words});
        await toChanges({...it, latest: true}); sendNow(it);   // list rows are always the newest version
        closeSheet(); await onward(it, tl("rejectSheet.9", {p0: pname(it.dept || "") || tl("lib.3")}));
      } catch (e) { toastFail(e.message, tl("err.words.meta")); b.disabled = false; } };
  });
}
SCREENS.item = () => { const x = myTurn()[0] || D.items.slice().sort(byAt)[0];
  if (x) setTimeout(() => location.replace("#item/" + iid(x)));
  else V().innerHTML = `<div class="card plan none">${mEmpty("emptyInbox")}<p>${tl("item.1")}</p></div>`; return {}; };

