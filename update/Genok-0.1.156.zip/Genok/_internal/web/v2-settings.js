// Genok web UI, cut from v2.js: 설정.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- 설정: refern's settings modal (a left menu of pages, a right panel of rows) ----------
// LOOP_SETTINGS takes two forms so other tracks can extend settings; the final merge moves each
// track to the object form. Both are supported here:
//   - a plain function(container)          -> collected onto the "기타" page. It still receives an
//                                             #ext-settings <div> (the old contract), so existing
//                                             connect.js/phone.js/... keep working unchanged.
//   - {page, icon, title, draw(container)} -> its own menu page, slotted by `page`. The reserved
//                                             pages are connect·phone·wake·rules·backup.
let setPage = "connect";
// The settings menu: five groups, each a menu entry whose pages are tabs on the right. Order inside
// the flattened list also sets the tab order; a page not named here (an unknown extension) falls
// into a "기타" tail group. setPage stays a page key, so every deep link (setPage = "license" ...)
// still lands on its page: the group is read off the page.
// Lab 3 sorts the same pages into six smaller groups (five tabs at most, each group one subject):
// the page keys are unchanged, so deep links and the phone list work as before.
const SET_GROUPS = LT(() => (LAB3 ? [
  {k: "connect", i: "plug",    n: tl("ui.setg.connect"), keys: ["connect", "consent", "phone", "apps3d", "wake"]},
  {k: "general", i: "toggle",  n: tl("ui.setg.general"), keys: ["lang", "general"]},
  {k: "look",    i: "monitor", n: tl("ui.setg.screen"),  keys: ["screen", "mode", "views", "beta"]},
  {k: "work",    i: "server",  n: tl("ui.setg.data"),    keys: ["backup", "migrate", "rules", "misc"]},
  {k: "plan",    i: "key",     n: tl("ui.setg.ver"),     keys: ["update", "history", "license"]},
  {k: "info",    i: "info",    n: tl("ui.setg.help"),    keys: ["diag", "selfcheck", "oss", "about"]},
] : [
  {k: "connect", i: "plug",    n: tl("ui.setg.connect"), keys: ["connect", "consent", "phone", "apps3d", "wake"]},
  {k: "look",    i: "monitor", n: tl("ui.setg.look"),    keys: ["lang", "general", "screen", "mode", "views", "beta"]},
  {k: "work",    i: "server",  n: tl("ui.setg.work"),    keys: ["backup", "history", "selfcheck", "diag", "migrate", "rules", "misc"]},
  {k: "plan",    i: "key",     n: tl("ui.setg.plan"),    keys: ["license"]},
  {k: "info",    i: "info",    n: tl("ui.setg.info"),    keys: ["update", "oss", "about"]},
]));
// Pages shown under another one: a row fewer in the list, the same controls where they belong
// (자동 점검 under 문제 진단 as "점검", 오픈소스 under Genok 정보). A deep link to a folded page
// opens the page that holds it.
const SET_FOLD = {selfcheck: "diag", oss: "about"};
const SET_ORDER = SET_GROUPS.reduce((a, g) => a.concat(g.keys), []);
const SET_GROUP_OF = SET_GROUPS.reduce((m, g, gi) => { g.keys.forEach((k) => m[k] = gi); return m; }, {});
const SET_META = LT(() => ({
  mode:    {i: "sliders", n: tl("custom.tab.mode")},
  screen:  {i: "monitor", n: tl("custom.tab.screen")},
  views:   {i: "list", n: tl("views.title")},
  connect: {i: "plug", n: tl("ui.set.connect")},
  phone:   {i: "phone", n: tl("ui.set.phone")},
  wake:    {i: "bolt", n: tl("ui.set.wake")},
  rules:   {i: "scroll", n: tl("ui.set.rules")},
  backup:  {i: "server", n: tl("ui.set.backup")},
}));
// What a tab says: one or two words. The page under it keeps its full title, and the tab's tooltip says it.
const SET_TAB = LT(() => ({connect: tl("set.tab.connect"), consent: tl("set.tab.consent"), phone: tl("set.tab.phone"), wake: tl("set.tab.wake"), views: tl("set.tab.views"),
  history: tl("set.tab.history"), migrate: tl("set.tab.migrate"), rules: tl("set.tab.rules"), oss: tl("set.tab.oss"), about: tl("set.tab.about"), beta: tl("set.tab.beta"),
  general: tl("set.tab.general"), screen: tl("set.tab.screen"), diag: tl("set.tab.diag")}));
const setTabN = (p) => SET_TAB[p.k] || p.n;
const setRow = (title, desc, ctl) => `<div class="srow"><span class="srtx"><span class="srt">${title}</span>${desc ? `<span class="srd">${desc}</span>` : ""}</span><span class="srctl">${ctl || ""}</span></div>`;
// The taskbar (taskbar.py), where there is one: the app on this PC. Each thing it does has a
// switch of its own; what hangs on another (how usage is drawn, what a pin does) shows with it.
function setBar(box) {
  const B = window.GenokBar;
  if (!box || !B) return;
  if (!B.opts) { B.load().then(() => { if (box.isConnected && B.opts) setBar(box); }, () => {}); return; }
  if (!B.native) return;
  const o = B.opts, held = document.activeElement && box.contains(document.activeElement) ? document.activeElement.dataset.bar : "";
  const rows = [["usage", tl("bar.s.usage")], ["badge", tl("bar.s.badge")], ["pin", tl("bar.s.pin")], ["chat", tl("bar.s.chat")], ["dragout", tl("bar.s.dragout")]]
    .filter(([k]) => o.pin || k !== "chat");
  const styles = [["bar", tl("bar.s.bar")], ["num", tl("bar.s.num")], ["ring", tl("bar.s.ring")]];
  box.innerHTML = `<div class="setsec">${tl("ui.set.sec.taskbar")}</div>` + rows.map(([k, n]) => setRow(n, "", `<button class="sw ${o[k] ? "on" : ""}" role="switch" aria-checked="${!!o[k]}" data-bar="${k}" aria-label="${n}"></button>`)
    + (k === "usage" && o.usage ? setRow(tl("bar.s.style"), "", `<div class="seg" role="group" aria-label="${tl("bar.s.style")}">${styles.map(([v, t]) => `<button class="press ${o.style === v ? "on" : ""}" data-barstyle="${v}" aria-pressed="${o.style === v}">${t}</button>`).join("")}</div>`) : "")).join("");
  if (held) box.querySelector(`[data-bar="${held}"]`)?.focus({preventScroll: true});
  // The switch turns where it stands; the rows are drawn again only when others come or go with it.
  box.querySelectorAll("[data-bar]").forEach((b) => b.onclick = () => { const k = b.dataset.bar, on = !o[k];
    b.classList.toggle("on", on); b.setAttribute("aria-checked", on);
    B.set({[k]: on}).then(() => { if (box.isConnected && (k === "usage" || k === "pin")) setBar(box); }, (e) => { toast(e.message); if (box.isConnected) setBar(box); }); });
  box.querySelectorAll("[data-barstyle]").forEach((b) => b.onclick = () => { const v = b.dataset.barstyle;
    box.querySelectorAll("[data-barstyle]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
    B.set({style: v}).catch((e) => toast(e.message)); });
}
function setGeneral(c) {
  c.innerHTML = `<h2 class="seth">${tl("ui.set.general")}</h2><p class="setd">${tl("ui.set.general.d")}</p>`
    // 언어 comes first: the person finds it before anything else on the page.
    + (isPhoneW() ? "" : setRow(tl("lang.label"), tl("lang.d"), langSeg("setlang")))
    // On a phone the two chips are not offered: the heading stays only for the install row.
    + (isPhoneW() && !window.LOOP_PWA ? "" : `<div class="setsec">${tl("ui.set.start")}</div>`)
    + (isPhoneW() ? "" : `<div class="setchips"><button class="setchip press" data-start="connect">${ic("plug")}${tl("connect.title")}</button>`
    + `<button class="setchip press" data-start="phone">${ic("phone")}${tl("phone.title")}</button></div>`)
    + (window.LOOP_PWA ? LOOP_PWA.row() : "")
    + `<div class="setsec">${tl("ui.set.sec.behavior")}</div>`
    + setRow(tl("settings.2"), tl("settings.3"), `<button class="sw ${pref("calm") ? "on" : ""}" role="switch" aria-checked="${pref("calm")}" data-pref="calm" aria-label="${tl("settings.2")}"></button>`)
    + (isPhoneW() ? "" : setRow(tl("settings.keysbar"), tl("settings.keysbar.d"), `<button class="sw ${pref("keys") ? "on" : ""}" role="switch" aria-checked="${pref("keys")}" data-pref="keys" aria-label="${tl("settings.keysbar")}"></button>`))
    + setRow(tl("settings.steps"), tl("settings.steps.d"), `<button class="sw ${pref("steps") ? "on" : ""}" role="switch" aria-checked="${pref("steps")}" data-pref="steps" aria-label="${tl("settings.steps")}"></button>`)
    + setRow(tl("settings.ctxrows"), tl("settings.ctxrows.d"), `<button class="sw ${pref("ctxrows") ? "on" : ""}" role="switch" aria-checked="${pref("ctxrows")}" data-pref="ctxrows" aria-label="${tl("settings.ctxrows")}"></button>`)
    + setRow(tl("settings.redact"), tl("settings.redact.d"), `<button class="sw ${pref("redact") ? "on" : ""}" role="switch" aria-checked="${pref("redact")}" data-pref="redact" aria-label="${tl("settings.redact")}"></button>`)
    + setRow(tl("settings.4"), tl("settings.5"), `<button class="sw ${sound() ? "on" : ""}" role="switch" aria-checked="${sound()}" id="snd" aria-label="${tl("settings.4")}"></button>`)
    + (Object.keys(noAsk()).length ? setRow(tl("noask.t"), tl("noask.d", {n: Object.keys(noAsk()).length}), `<button class="btn sm press" id="noaskb">${tl("noask.on")}</button>`) : "")
    + `<div class="srow" id="autor" hidden><span class="srtx"><span class="srt">${tl("auto.1")}</span><span class="srd">${tl("auto.2")}</span></span><span class="srctl"><button class="sw" role="switch" aria-checked="false" id="autob" aria-label="${tl("auto.1")}"></button></span></div>`
    + `<div class="setsec">${tl("ui.set.sec.notify")}</div>`
    + `<div class="srow"><span class="srtx"><span class="srt">${tl("settings.6")}</span><span class="srd" id="pushs">${tl("settings.7")}</span></span><span class="srctl"><button class="btn sm press" id="pushb" disabled>${tl("settings.8")}</button></span></div>`
    // This PC, when a conversation not on screen hands the turn back (turn_toast.py). The phone has its own above.
    + (isPhoneW() ? "" : setRow(tl("settings.pcturn"), tl("settings.pcturn.d"), `<button class="sw ${window.LOOP_TURN?.pc() !== false ? "on" : ""}" role="switch" aria-checked="${window.LOOP_TURN?.pc() !== false}" data-pcturn aria-label="${tl("settings.pcturn")}"></button>`))
    // The icon's number is the phone's business (and an installed PWA's): elsewhere there is no badge to set.
    + (isPhoneW() || navigator.setAppBadge ? [["res", tl("settings.badge.res"), tl("settings.badge.res.d")], ["chat", tl("settings.badge.chat"), tl("settings.badge.chat.d")]].map(([k, n, d]) => setRow(n, d,
      `<button class="sw ${badgeOn(k) ? "on" : ""}" role="switch" aria-checked="${badgeOn(k)}" data-badge="${k}" aria-label="${n}"></button>`)).join("") : "")
    + `<div id="setbar"></div>`;
  setBar(c.querySelector("#setbar"));
  c.querySelectorAll("[data-pcturn]").forEach((b) => b.onclick = () => { if (!window.LOOP_TURN) return;
    const on = b.getAttribute("aria-checked") !== "true", paint = (v) => { b.classList.toggle("on", v); b.setAttribute("aria-checked", v); };
    paint(on); window.LOOP_TURN.set({pc_turn_toast: on}).catch((er) => { paint(!on); toast(er.message); }); });
  c.querySelectorAll("[data-badge]").forEach((b) => b.onclick = () => { const on = !badgeOn(b.dataset.badge);
    // Both switches are written, so the earlier three-way value stops deciding either of them.
    const now = {res: badgeOn("res"), chat: badgeOn("chat"), [b.dataset.badge]: on};
    lsSet("v2-badge-res", now.res ? "1" : "0"); lsSet("v2-badge-chat", now.chat ? "1" : "0"); lsSet("v2-badge", "");
    b.classList.toggle("on", on); b.setAttribute("aria-checked", on); drawChrome(); });
  c.querySelectorAll("[data-start]").forEach((b) => b.onclick = () => {
    const what = b.dataset.start;
    if (what === "phone") { try { window.LOOP_PHONE?.open(); } catch (e) {} }
    else if (what === "connect") { setPage = "connect"; setShowPage = true; SCREENS.settings(); }
  });
  const na = c.querySelector("#noaskb");
  if (na) na.onclick = () => { noAskClear(); na.closest(".srow").remove(); toast(tl("noask.done")); };
  const snd = c.querySelector("#snd");
  if (snd) snd.onclick = (e) => { const v = !sound(); sound(v); e.currentTarget.classList.toggle("on", v); e.currentTarget.setAttribute("aria-checked", v);
    document.querySelectorAll("video").forEach((x) => x.muted = !v); };
  drawPush(); drawAutostart(); window.LOOP_PWA?.wire(c);
}
// Phone: the languages as a short list, each in its own name, a check on the current one. Picking one
// applies it (setLang, the same as the switch on the PC) and goes back to the list.
function setLanguage(c) {
  c.innerHTML = `<h2 class="seth">${tl("lang.label")}</h2><div class="sgcard langlist" role="radiogroup" aria-label="${tl("lang.label")}">`
    + LANG_NAMES.map(([k, n]) => `<button class="sgrow press" role="radio" aria-checked="${LANG() === k}" data-lang="${k}" lang="${k}"><span class="srn">${n}</span>${LANG() === k ? ic("check", "i ck") : ""}</button>`).join("") + `</div>`;
  // The click itself is handled by the one [data-lang] listener (setLang); this only leaves the page after it.
  c.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.lang === LANG()) return setBackNow?.();
    window.addEventListener("loop-lang", () => setTimeout(() => { if (cur === "settings") setBackNow?.(); }, 0), {once: true});
  }));
}
function setUpdate(c) {
  c.innerHTML = `<h2 class="seth">${tl("update.1")}</h2><p class="setd">${tl("ui.set.update.d")}</p>`
    + `<div class="srow updrow"><span class="srtx"><span class="srt">${tl("update.1")}</span><span class="srd" id="upds" aria-live="polite">…</span></span><span class="srctl"><button class="btn sm press" id="updchk">${tl("upd.check")}</button></span></div>`
    + `<div class="updbox" id="updbox" hidden></div>`
    + setRow(tl("settings.9"), D.at ? hm(D.at) + tl("settings.1") : "", "");
  c.querySelector("#updchk").onclick = () => drawUpdate(true, true);
  // Opening the page looks at the feed once; a redraw of the same page paints what is already known.
  if (UPD.u && setUpdSeen) { drawUpdBox(); drawUpdate(false); } else { setUpdSeen = true; drawUpdate(true); }
}
let setUpdSeen = false;
// The logo mark (web/orb.js markSVG): the breathing ring's still frame in the key colour.
const brandMark = (px) => window.Orb?.markSVG ? window.Orb.markSVG(px) : "";
// "Lite · v0.1.46": plan names are the store's, in English on every screen.
const planName = () => ({free: "Lite", pro: "Pro", lifetime: "Lifetime", trial: "Trial"}[(window.LOOP_PLAN || {}).plan] || "Lite");
const planVer = () => tl("ui.statusPlan", {plan: planName(), v: D.ver});
function setAbout(c) {
  // The top (mark, version, tools, system, update, feedback, licenses) is web/about.js; the tour
  // and the manual stay here.
  c.innerHTML = `<div id="abt-top"></div>`
    + (window.LOOP_TOUR ? `<div class="setsec">${tl("ui.set.help")}</div>`
      + setRow(tl("tour.replay"), tl("tour.replayd"), `<button class="btn sm press" data-tour-replay>${tl("tour.replaybtn")}</button>`) : "")
    // First setup (name, data folder, agent logins in a window on the PC) is the PC's business, as in
    // onboard.js: a phone over serve would replay screens it cannot act on.
    + (["127.0.0.1", "localhost", "::1", ""].includes(location.hostname) ? (window.LOOP_TOUR ? "" : `<div class="setsec">${tl("ui.set.help")}</div>`)
      + setRow(tl("onboard.reopen"), tl("onboard.reopend"), `<button class="btn sm press" data-first-replay>${tl("onboard.reopenbtn")}</button>`) : "")
    + `<div class="setsec">${tl("settings.10")}<button type="button" class="lnk press" id="abt-manb" aria-expanded="false" aria-controls="abt-manual">${tl("ui.more1")}</button></div>`
    + `<div id="abt-manual" hidden>${MENUS.map((m) => setRow(esc(m.n), MANUAL[m.k] || m.d, "")).join("")}</div><p class="abt-foot">© 2026 Genok</p>`;
  try { window.LOOP_ABOUT(c.querySelector("#abt-top")); } catch (e) { console.error(e); }
  // The tour re-creates the sample if it was deleted, and rewinds it to v1 if it was walked.
  // 페이지별 사용법 is reference: one press shows it where it stands.
  c.querySelector("#abt-manb").onclick = (e) => {
    const m = c.querySelector("#abt-manual"), open = m.hidden;
    m.hidden = !open; e.currentTarget.setAttribute("aria-expanded", String(open));
    e.currentTarget.textContent = open ? tl("itemView.30") : tl("ui.more1");
  };
  const rb = c.querySelector("[data-tour-replay]");
  if (rb) rb.onclick = () => { try { window.LOOP_TOUR.start({}); } catch (e) {} };
  const fb = c.querySelector("[data-first-replay]");
  if (fb) fb.onclick = () => { try { window.LOOP_FIRSTRUN ? window.LOOP_FIRSTRUN.replay() : window.LOOP_ONBOARD?.open(); } catch (e) {} };
}
SCREENS.settings = function () {
  // tabs.js sorts LOOP_SETTINGS into own-page entries (object form {page, icon, title, draw}, or
  // a draw function carrying .page/.title) and bare functions (the old 기타 slot). Custom's own
  // pages (mode·screen·views·accounts) are object-form entries, so they land in objPages too.
  const {pages: objPages, misc: fnDraws} = (typeof loopSettings === "function")
    ? loopSettings()
    : {pages: (window.LOOP_SETTINGS || []).filter((f) => f && typeof f === "object" && typeof f.draw === "function"),
       misc: (window.LOOP_SETTINGS || []).filter((f) => typeof f === "function")};
  // No icon twice on one screen: the gear is the way into settings itself (rail, top bar).
  const pages = [{k: "general", i: "toggle", n: tl("ui.set.general"), draw: setGeneral}];
  objPages.forEach((o, i) => { const m = SET_META[o.page] || {}; pages.push({k: o.page || ("ext" + i), i: o.icon || m.i || "tool", n: o.title ? tl(o.title) : (m.n || tl("ui.set.other")), draw: o.draw}); });
  if (fnDraws.length) pages.push({k: "misc", i: "tool", n: tl("ui.set.other"), draw: (c) => { const ext = document.createElement("div"); ext.id = "ext-settings"; c.appendChild(ext);
    // Every entry may decide to show nothing (pack.js outside the installed build): say so instead of a blank page.
    Promise.allSettled(fnDraws.map((f) => { try { return f(ext); } catch (e) { console.error(e); } }))
      .then(() => { if (!ext.children.length) ext.innerHTML = `<div class="s" style="padding:14px 4px">${tl("ui.set.other.empty")}</div>`; }); }});
  // The phone lists 언어 as a row of its own (value on the right); the PC has it at the top of 일반.
  if (isPhoneW()) pages.push({k: "lang", i: "globe", n: tl("lang.label"), draw: setLanguage});
  pages.push({k: "update", i: "dl", n: tl("update.1"), draw: setUpdate});
  pages.push({k: "about", i: "info", n: tl("ui.set.about"), draw: setAbout});
  for (const [k, into] of Object.entries(SET_FOLD)) {
    const at = pages.findIndex((p) => p.k === k), host = pages.find((p) => p.k === into);
    if (at < 0 || !host) continue;
    const [low] = pages.splice(at, 1), own = host.draw;
    host.draw = (c) => { const a = document.createElement("div"), b = document.createElement("div");
      a.className = b.className = "setfold"; c.append(a, b); own(a); low.draw(b); };
    if (setPage === k) setPage = into;
  }
  // Order by the grouped menu; anything unlisted (an unknown extension) tails as its own group.
  const TAIL = SET_GROUPS.length;
  const grpOf = (k) => (k in SET_GROUP_OF ? SET_GROUP_OF[k] : TAIL);
  const rank = (k) => { const i = SET_ORDER.indexOf(k); return i < 0 ? SET_ORDER.length : i; };
  pages.sort((a, b) => (grpOf(a.k) - grpOf(b.k)) || (rank(a.k) - rank(b.k)));
  // On a direct load the page scripts register after this first draw. setPage keeps what was asked
  // for; 일반 stands in (never a lazy page: loading one now would swallow the later registrations)
  // and the screen is drawn again once everything has loaded.
  const found = pages.find((p) => p.k === setPage);
  if (!found && document.readyState !== "complete")
    window.addEventListener("load", () => { if (cur === "settings") SCREENS.settings(); }, {once: true});
  // The phone opens on a short menu: what is changed from a phone. The rest (connections, records,
  // the key) is set up at the PC and waits behind one row.
  // (Since 0.1.55 the phone lists every group as well; SET_PHONE is kept for the count below.)
  const phone = isPhoneW(), short = false;
  const rest = pages.filter((p) => !SET_PHONE.includes(p.k)).length;
  const active = found || pages.find((p) => p.k === "general");
  // One menu entry per group; its pages are the tabs. The phone lists only what it can change, plus
  // the open page (a deep link may land on a PC-only page).
  const shown = (p) => !(phone && p.k === "phone") && (!short || SET_PHONE.includes(p.k) || p === active);
  const groupOf = (gi) => gi < TAIL ? SET_GROUPS[gi] : {k: "other", i: "tool", n: tl("ui.set.other")};
  const inGroup = (gi) => pages.filter((p) => grpOf(p.k) === gi && shown(p));
  const actG = grpOf(active.k);
  setTabOf[groupOf(actG).k] = active.k;
  // The phone's list says under each group what it is set to now (a value this screen already
  // holds; where there is none, the pages inside). The PC menu does not show the line.
  const sumOf = (gi) => {
    const g = groupOf(gi), names = inGroup(gi).map(setTabN).join(" · ");
    try {
      if (g.k === "connect") return CONN ? connLabel() : names;
      if (g.k === "look") return (document.documentElement.dataset.theme === "light" ? tl("custom.theme.light") : tl("custom.theme.dark")) + " · " + (sound() ? tl("ui.sets.snd.on") : tl("ui.sets.snd.off"));
      if (g.k === "plan") return planName();
      if (g.k === "info" && D.ver) return updOn() ? tl("ui.sets.upd", {v: D.ver}) : tl("ui.sets.ver", {v: D.ver});
    } catch (e) {}
    return names;
  };
  // Phone: each group is a card under its own bold header; every row is one page, its current value
  // (where there is one) on the right in the accent colour. The PC keeps one menu entry per group.
  const rowVal = (k) => { try {
    if (k === "lang") return LANG_NAMES.find(([l]) => l === LANG())?.[1] || "";
    if (k === "screen") return document.documentElement.dataset.theme === "light" ? tl("custom.theme.light") : tl("custom.theme.dark");
    if (k === "connect") return CONN ? connLabel() : "";
    if (k === "license") return planName();
    if (k === "update") return updOn() ? tl("set.val.new") : D.ver ? "v" + D.ver : "";
  } catch (e) {} return ""; };
  let menu = "";
  if (phone) {
    for (const gi of LAB3 ? [1, 2, 0, 3, 4, 5, TAIL] : [1, 0, 2, 3, 4, TAIL]) {
      const g = groupOf(gi), gp = inGroup(gi);
      if (!gp.length) continue;
      menu += `<section class="setgrp"><h3 class="setgh">${esc(g.n)}</h3><div class="sgcard">`
        + gp.map((p) => `<button class="sgrow press" data-setp="${esc(p.k)}"><span class="smi">${ic(p.i)}</span><span class="srn">${esc(setTabN(p))}</span>${p.k === "consent" ? `<span class="setmn num" data-setlater hidden></span>` : ""}<span class="srv" data-sv="${esc(p.k)}">${esc(rowVal(p.k))}</span><span class="smc">${ic("chev")}</span></button>`).join("")
        + `</div></section>`;
    }
  }
  for (let gi = 0; gi <= TAIL && !phone; gi++) {
    const g = groupOf(gi), gp = inGroup(gi);
    if (!gp.length) continue;
    // The group opens on the tab last seen in it, or its first.
    const to = gp.find((p) => p.k === setTabOf[g.k]) || gp[0];
    // On the phone the list is a screen of its own: no row is "the open one" there.
    const on = !phone && gi === actG;
    menu += `<button class="setmi press ${on ? "on" : ""}" data-setp="${esc(to.k)}"${on ? ` aria-current="page"` : ""}><span class="smi">${ic(g.i)}</span><span class="smn">${esc(g.n)}</span>${g.k === "connect" ? `<span class="setmn num" data-setlater hidden></span>` : ""}<span class="sms" data-sums="${gi}">${esc(sumOf(gi))}</span><span class="smc">${ic("chev")}</span></button>`;
  }
  if (false && phone && rest) menu += `<button class="setmi setmore press" data-setall aria-expanded="${!short}"><span class="smi">${ic("monitor")}</span>${short ? tl("ui.set.pcmore", {n: rest}) : tl("ui.set.pcless")}</button>`;
  const tabsOf = inGroup(actG);
  const tabs = tabsOf.length > 1 ? `<div class="settabs" role="tablist" aria-label="${esc(groupOf(actG).n)}">`
    + tabsOf.map((p) => `<button class="settab press ${p === active ? "on" : ""}" role="tab" id="settab-${esc(p.k)}" aria-selected="${p === active}" aria-controls="setpanel" tabindex="${p === active ? 0 : -1}" data-setp="${esc(p.k)}"${setTabN(p) !== p.n ? ` title="${esc(p.n)}"` : ""}>${esc(setTabN(p))}</button>`).join("") + `</div>` : "";
  // "again": settings drawn over itself (a row or tab was picked), so the phone does not fade the
  // whole screen in a second time under the page that is sliding.
  V().innerHTML = `<div class="setwrap${V().querySelector(".setwrap") ? " again" : ""}"><div class="setbackdrop" data-back></div>
    <div class="setmodal" role="dialog" aria-modal="true" aria-label="${tl("TABS.4")}">
      <aside class="setmenu"><button class="setbk press" data-setbk aria-label="${tl("head.1")}">${ic("back")}</button><div class="setmtitle">${tl("TABS.4")}<button class="setxm press" data-back aria-label="${tl("ui.close")}">${ic("x")}</button></div>
        <div class="setlist">${menu}</div>
      </aside>
      <section class="setpage" id="setpage"><div class="setnavb"><button class="setback press" data-setback aria-label="${tl("ui.set.menu")}">${ic("back")}${tl("TABS.4")}</button></div>${tabs}</section>
      <button class="setx press" data-back aria-label="${tl("ui.close")}">${ic("x")}</button>
    </div></div>`;
  // The rest of the window (title bar, side menu, tab bar) sits under the backdrop: out of reach,
  // and a keyboard open lands inside the dialog.
  const wrap = V().querySelector(".setwrap");
  if (modalOff) modalOff(true);
  modalOff = modalHold(wrap, null);
  if (!wrap.contains(document.activeElement)) wrap.querySelector(isPhoneW() && setShowPage ? "[data-setback]" : `[data-setp="${CSS.escape(setPage || "")}"],.setmi.on,.setmi,.sgrow`)?.focus({preventScroll: true});
  // On the phone, the list and the page are two layers; showpage means a page is open (with a back
  // button) and setNav places them while one slides over the other. On desktop both panels always
  // show, so the classes are harmless there.
  if (!setNav.run && !setNav.drag) setNav.p = setShowPage ? 1 : 0;
  setNavPaint();
  const pg = document.getElementById("setpage");
  setEdge(pg);
  const body = document.createElement("div"); pg.appendChild(body);
  body.id = "setpanel";
  if (tabs) { body.setAttribute("role", "tabpanel"); body.setAttribute("aria-labelledby", "settab-" + active.k); body.dataset.tab = active.k; }
  // A tab or group that was just picked eases in; a redraw of the same page (fresh values) does not.
  if (setSwap) { body.classList.add("swap"); setSwap = false; }
  try { active.draw(body); } catch (e) { console.error(e); }
  // From the phone's list the page slides in over it (setNavTo); a tab inside an open page eases in as before.
  const goPage = (k, focus) => { const slide = isPhoneW() && !setShowPage; setPage = k; setSwap = !slide;
    // The page is a level of history: the browser's / Android's back leaves it for the list (popstate below).
    if (slide) { setNavTo(1); try { history.pushState({setpage: 1}, ""); } catch (e) {} } else setShowPage = true;
    SCREENS.settings();
    if (focus) { const t = V().querySelector(focus); if (t) t.focus({preventScroll: true}); } };
  V().querySelectorAll(".setmi[data-setp],.sgrow[data-setp]").forEach((b) => b.onclick = (e) => goPage(b.dataset.setp, isPhoneW() || e.detail ? "" : ".setmi.on"));
  const strip = V().querySelector(".settabs");
  if (strip) {
    strip.querySelectorAll(".settab").forEach((b) => b.onclick = (e) => goPage(b.dataset.setp, e.detail ? "" : ".settab.on"));
    // Arrow keys walk the tabs (Home/End jump); the picked tab opens and keeps the focus.
    strip.onkeydown = (e) => {
      const ks = tabsOf.map((p) => p.k), i = ks.indexOf(active.k);
      const j = e.key === "ArrowRight" ? (i + 1) % ks.length : e.key === "ArrowLeft" ? (i - 1 + ks.length) % ks.length
        : e.key === "Home" ? 0 : e.key === "End" ? ks.length - 1 : -1;
      if (j < 0 || j === i) return;
      e.preventDefault(); goPage(ks[j], ".settab.on");
    };
    // A long row scrolls inside itself: keep the open tab in sight.
    const on = strip.querySelector(".settab.on");
    if (on && strip.scrollWidth > strip.clientWidth) strip.scrollLeft = Math.max(0, on.offsetLeft - (strip.clientWidth - on.offsetWidth) / 2);
  }
  // The count of put-off permission requests beside 연결 (web/consent.js owns the number).
  try { window.LOOP_CONSENT?.count(); } catch (e) {}
  const allBtn = V().querySelector("[data-setall]");
  if (allBtn) allBtn.onclick = () => { setAllPages = !setAllPages; SCREENS.settings(); };
  const backBtn = V().querySelector("[data-setback]");
  // Back leaves the way the page came in; the list under it shows what was just changed.
  setSums = () => { V().querySelectorAll("[data-sums]").forEach((s) => { s.textContent = sumOf(+s.dataset.sums); });
    V().querySelectorAll("[data-sv]").forEach((s) => { s.textContent = rowVal(s.dataset.sv); }); };
  // A page opened straight from 전체 goes back to 전체; one opened from this list goes back to the list.
  const bk = () => { setSums(); if (setDeep && window.LOOP_ALL) LOOP_ALL.pop(); else setLeave(); };
  setBackNow = bk;
  if (backBtn) backBtn.onclick = bk;
  // The list's own arrow: back to 전체 when it was opened from there, else where history says.
  const lb = V().querySelector("[data-setbk]");
  if (lb) lb.onclick = () => { if (window.LOOP_ALL?.from()) LOOP_ALL.pop(); else back(); };
};
let setShowPage = false, setAllPages = false, setSwap = false, setSums = null;
let setPopV = 0;           // the speed a swipe let go with, handed on to the slide that popstate then runs
// Leave the open page for the list. The page sits one entry above the list in history (goPage), so
// going back through history is what keeps the arrow, the swipe and the system back in step.
function setLeave(v) { if (history.state?.setpage) { setPopV = v || 0; history.back(); } else setNavTo(0, v); }
addEventListener("popstate", () => {
  if (cur !== "settings" || detail || !setShowPage || setDeep || history.state?.setpage || location.hash !== "#settings") return;
  const v = setPopV; setPopV = 0; setSums?.(); setNavTo(0, v || undefined);
});
let setDeep = false;       // the page on screen was opened straight from a 전체 row (web/all.js), not from the list
let setBackNow = null;     // what the page's back arrow does now (the edge swipe uses the same)
// Phone: the list and the open page as two layers. p runs 0 (list) to 1 (page); run is the spring
// moving it, drag a finger holding it. It lives outside the screen's markup, so a redraw in the
// middle of a slide (a page asking for fresh values) carries on from the same spot.
const setNav = {p: 0, run: null, drag: false};
function setNavPaint() {
  const m = V().querySelector(".setmodal"); if (!m) return;
  const p = Math.min(1, Math.max(0, setNav.p)), mid = !!setNav.run || setNav.drag;
  m.classList.toggle("moving", mid);
  m.classList.toggle("showpage", !mid && p > 0.5);
  // Written on the two layers themselves (a variable on the modal would restyle everything in it
  // each frame) and taken off again at rest. Reduced motion: the page fades, nothing moves.
  const pg = m.querySelector(".setpage").style, mn = m.querySelector(".setmenu").style;
  if (!mid) pg.transform = pg.opacity = mn.transform = mn.opacity = mn.filter = "";
  else if (RM()) { pg.opacity = p.toFixed(3); mn.transform = mn.opacity = mn.filter = ""; }
  else { pg.transform = `translate3d(${((1 - p) * 100).toFixed(3)}%,0,0)`; mn.transform = `translate3d(${(p * -22).toFixed(3)}%,0,0)`; mn.filter = `brightness(${(1 - p * 0.18).toFixed(3)})`; }
}
// Send the page in (1) or out (0) from where it is now, at the speed it has (v, in screens per
// second: a finger's on release, or the unfinished slide's). Critically damped: no bounce, since a
// page overshooting would uncover what is behind it. Reduced motion gets a short fade (v2.css).
function setNavTo(to, v) {
  const was = setNav.run ? setNav.run.stop() : null;
  setNav.run = null; setShowPage = to === 1;
  // Back on the list: focus goes to the row of the page that was open, once the list can take it.
  const land = () => { const a = document.activeElement;
    if (!to && (!a || a === document.body || a.closest("#setpage"))) V().querySelector(`[data-setp="${CSS.escape(setPage || "")}"],.setmi.on`)?.focus({preventScroll: true}); };
  if (!isPhoneW() || !window.Motion?.drive || !V().querySelector(".setmodal")) { setNav.p = to; setNavPaint(); return land(); }
  setNav.run = Motion.drive({z: 1, r: RM() ? 0.2 : 0.38, from: setNav.p, to, v: v != null ? v : was ? was.v : 0,
    step: (x) => { setNav.p = x; setNavPaint(); }, done: () => { setNav.run = null; setNavPaint(); land(); }});
  setNavPaint();
}
// The open page follows a finger that starts at its left edge, 1:1 from where it was caught. A
// page still sliding can be caught anywhere on it. Letting go carries the finger's speed on, and
// where that flick would coast to decides between going back and staying.
function setEdge(pg) {
  let id = null, x0 = 0, y0 = 0, p0 = 0, lock = false, pts = [];
  const W = () => pg.offsetWidth || innerWidth;
  const end = (e, cancelled) => {
    if (e.pointerId !== id) return;
    id = null;
    if (!setNav.drag) return;
    setNav.drag = false;
    if (!lock) return setNavTo(setShowPage ? 1 : 0, 0);          // caught mid-slide and let go: carry on
    // A finger that stopped before lifting has no speed left, whatever it was doing before.
    const a = pts[0], b = pts[pts.length - 1], vx = cancelled || b.t - a.t < 1 || e.timeStamp - b.t > 80 ? 0 : (b.x - a.x) / (b.t - a.t) * 1000;
    const out = (1 - setNav.p) * W() + Motion.project(vx) > W() / 2;
    if (out) setSums?.();
    if (out && setDeep && window.LOOP_ALL) return void LOOP_ALL.pop();    // opened from 전체: the swipe goes back there
    if (out) return setLeave(-vx / W());
    setNavTo(1, -vx / W());
  };
  pg.addEventListener("pointerdown", (e) => {
    if (id !== null || e.button || !isPhoneW() || RM() || !window.Motion?.drive) return;
    const mid = !!setNav.run;
    if (!mid && (!setShowPage || e.clientX > 32 || e.target.closest("input,textarea,select"))) return;
    id = e.pointerId; x0 = e.clientX; y0 = e.clientY; lock = false; pts = [{x: x0, t: e.timeStamp}];
    if (mid) { setNav.run.stop(); setNav.run = null; setNav.drag = true; setNavPaint(); }
  });
  pg.addEventListener("pointermove", (e) => {
    if (e.pointerId !== id) return;
    const dx = e.clientX - x0, dy = e.clientY - y0;
    if (!lock) {
      // A few px of slack tell a swipe from a tap or a scroll; a page caught in flight needs less.
      if (Math.abs(dx) < (setNav.drag ? 3 : 10) && Math.abs(dy) < 10) return;
      if (Math.abs(dy) > Math.abs(dx) || (!setNav.drag && dx < 0)) { if (setNav.drag) { setNav.drag = false; setNavTo(setShowPage ? 1 : 0, 0); } id = null; return; }
      lock = true; setNav.drag = true; x0 = e.clientX; p0 = setNav.p;
      try { pg.setPointerCapture(id); } catch (er) {}
    }
    pts.push({x: e.clientX, t: e.timeStamp}); while (pts.length > 2 && e.timeStamp - pts[0].t > 100) pts.shift();
    setNav.p = Math.min(1, Math.max(0, p0 - (e.clientX - x0) / W())); setNavPaint();
  });
  // A swipe that is ours is not also the browser's: left alone, Chromium reads the lift as a fling
  // and swallows the next tap (the row tapped right after swiping back did nothing).
  pg.addEventListener("touchmove", (e) => { if (lock && id !== null && e.cancelable) e.preventDefault(); }, {passive: false});
  pg.addEventListener("pointerup", (e) => end(e, false));
  pg.addEventListener("pointercancel", (e) => end(e, true));
}
const setTabOf = {};
// consent: the dialog says a grant can be taken back in settings, so the phone needs that page too.
const SET_PHONE = ["general", "screen", "consent", "update", "about"];
const isPhoneW = () => { try { return matchMedia("(max-width:720px)").matches; } catch (e) { return false; } };
// Only the installed Windows app can start at login; elsewhere the row stays hidden.
// A Store install has no switch of ours: Windows owns it (the package's startup task), so the
// row carries a button that opens Windows' own Startup apps page instead of a switch.
async function drawAutostart() {
  const a = await fetch("/api/autostart").then((r) => r.json()).catch(() => null);
  const row = document.getElementById("autor"), b = document.getElementById("autob");
  if (!a || !row) return;
  if (!a.installed) {
    const m = await fetch("/api/msix").then((r) => r.json()).catch(() => null);
    if (!m || !m.packaged) return;
    row.querySelector(".srd").textContent = tl("auto.store.d");
    const go = document.createElement("button");
    go.className = "btn sm press"; go.id = "autob"; go.textContent = tl("auto.store.b");
    go.onclick = () => post("/api/msix/startup-settings", {}).catch((e) => toast(e.message));
    b.replaceWith(go);
    row.hidden = false;
    return;
  }
  row.hidden = false;
  const show = (v) => { b.classList.toggle("on", v); b.setAttribute("aria-checked", v); };
  show(a.on);
  b.onclick = async () => { const v = b.getAttribute("aria-checked") !== "true"; show(v);
    try { show((await post("/api/autostart", {on: v})).on); } catch (e) { show(!v); toast(e.message); } };
}
document.addEventListener("click", (e) => { if (e.target.closest("[data-openweb]")) post("/api/open-browser", {hash: location.hash}).catch((x) => toast(x.message)); });
// The Windows build updates itself, but only when asked. Settings > 버전 is the full view: 업데이트
// 확인, whether the newer build can be installed at all (an unsigned feed cannot - the server says
// why), what changed, known issues, and the one line of progress. The title-bar pill (updPill)
// is the everyday way in and shares this state (UPD).
// go: the person pressed 업데이트 확인 themselves. A newer build it finds is shown with its notes
// and the 업데이트 button; nothing is fetched until that button is pressed.
const updPhone = () => matchMedia("(max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none)").matches;
async function drawUpdate(force, go) {
  const s0 = document.getElementById("upds"), b0 = document.getElementById("updchk");
  if (s0 && force) { s0.textContent = tl("upd.checking"); s0.classList.remove("warn"); if (b0) b0.disabled = true; }
  const u = await getUpd(force);
  const s = document.getElementById("upds"), b = document.getElementById("updchk");
  if (b) b.disabled = false;
  if (u) takeUpd(u);
  if (u && !s && u.available && !u.can_apply && !force) toast(tl("update.3", {v: u.latest}), 4000);
  if (s && !u) { s.textContent = tl("upd.nocheck"); s.classList.add("warn"); if (b) b.textContent = tl("upd.retry"); }
  if (go && u && u.can_apply && !updPhone()) updShow();
}
// What a restart would cut off right now: sessions mid-answer, or text typed and not sent (the
// page reloads, and a draft lives only in the page). The update is fetched anyway and then waits
// with this one line and 지금 다시 켜기 - never a silent restart over someone's work.
const updBusy = () => (D.sessions || []).filter((r) => state(r) === "work").length;
const updDraft = () => typeof pjUnsent === "function" && pjUnsent();
const updHold = () => { const n = updBusy(); return n ? tl("upd.busy", {n}) : updDraft() ? tl("upd.draft") : ""; };
const updList = (a, cls) => `<ul class="${cls}">${a.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>`;
// The one line of progress: 받는 중 n% -> 설치 중 -> 다시 켜는 중.
const updLine = () => UPD.phase === "dl" ? tl("upd.dl", {p: UPD.pct}) : UPD.phase === "install" ? tl("upd.installing") : UPD.phase === "restart" ? tl("upd.restarting") : "";
// The part that changes while an update runs, shared by the settings box (ub*) and the pill's
// popover (up*): the failure, the progress line or why it waits, and at most one button.
function updNow(x) {
  if (updPhone()) return `<p class="ubd">${tl("upd.phone.pc")}</p>`;
  const hold = UPD.phase === "ready" ? updHold() : "";
  let h = UPD.err ? `<p class="${x}w" role="alert">${esc(tl("upd.failed", {why: UPD.err}))}</p>${UPD.same && window.genokBeta?.("pai") ? `<p class="${x}k">${tl("err.ver.meta")}</p>` : ""}` : "";
  if (UPD.phase === "dl") h += `<div class="ubp" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${UPD.pct}"><i style="width:${UPD.pct}%"></i></div>`;
  if (hold) h += `<p class="${x}w">${esc(hold)}</p>`;
  const line = updLine() || (UPD.phase === "ready" && !hold ? tl("upd.readynote") : "");
  const btn = UPD.phase === "dl" ? `<button class="btn sm press" data-updcancel>${tl("upd.cancel")}</button>`
    : UPD.phase === "ready" ? `<button class="btn sm fill press" data-updapply>${hold ? tl("upd.now") : tl("upd.apply")}</button>`
    : updLocked() ? "" : `<button class="btn sm fill press" data-updgo>${UPD.err ? tl("upd.retry") : tl("upd.go")}</button>`;
  return h + `<div class="${x}a"><span class="${x === "ub" ? "ubd" : "upl"}" aria-live="polite">${esc(line)}</span>${btn}</div>`;
}
// The updater (updater.py latest) words its errors in Korean; the fixed ones read from the dictionary.
const updErr = (e) => LANG() === "ko" ? e : /준비 중/.test(e) ? tl("upd.e.soon") : /목록을 읽지/.test(e) ? tl("upd.e.list") : /연결하지 못했/.test(e) ? tl("upd.e.net") : e;
function drawUpdBox() {
  const s = document.getElementById("upds"), box = document.getElementById("updbox"), b = document.getElementById("updchk"), u = UPD.u;
  if (!s || !box || !u) return;
  const sig = [updPhone(), u.latest, u.found, u.blocked, u.error, u.checked, u.can_apply, UPD.phase, UPD.pct, UPD.err, UPD.phase === "ready" ? updHold() : ""].join("|");
  if (box.dataset.sig === sig) return;
  box.dataset.sig = sig;
  const bad = !u.found && !!u.error, at = u.checked ? " · " + tl("upd.checked", {t: hm(u.checked)}) : "";
  s.classList.toggle("warn", bad || !!u.blocked);
  s.textContent = u.packaged ? tl("upd.store", {cur: u.current})
    : bad ? tl("upd.cur", {cur: u.current}) + " · " + updErr(u.error)
    : u.blocked ? tl("upd.blocked", {cur: u.current, v: u.latest}) + at
    : (u.found ? tl("update.4", {cur: u.current, v: u.latest}) : tl("update.5", {cur: u.current})) + at;
  if (b) { b.hidden = !!u.packaged; b.textContent = bad ? tl("upd.retry") : tl("upd.check"); }
  if (updPhone()) {
    if (b) b.hidden = false;
    box.hidden = false;
    setHTML(box, `<p class="ubd">${tl("upd.phone.pc")}</p>`);
    return;
  }
  if (!u.found || u.packaged) { box.hidden = true; box.innerHTML = ""; return; }
  box.hidden = false;
  let h = `<div class="ubh">${esc(tl("upd.title", {v: u.latest}))}</div>`;
  if (u.blocked) h += `<p class="ubw" role="alert">${esc(u.blocked)}</p><p class="ubd">${tl("upd.blocked.d")}</p>`;
  else {
    h += `<div class="ubs">${tl("upd.notes")}</div>` + (u.notes?.length ? updList(u.notes, "ubl") : `<p class="ubd">${tl("upd.nonotes")}</p>`);
    if (u.known_issues?.length) h += `<div class="ubs">${tl("upd.issues")}</div>` + updList(u.known_issues, "ubl");
    h += u.can_apply ? updNow("ub") : `<p class="ubd">${tl("upd.srconly")}</p>`;
  }
  setHTML(box, h);
}
// After /api/update hands over to the swap script: wait for the new build to answer, then reload.
async function awaitRestart() {
  const t0 = Date.now(); await new Promise((r) => setTimeout(r, 2000));
  while (Date.now() - t0 < 60000) {
    if (await fetch("/api/health").then((r) => r.ok).catch(() => false)) { location.reload(); return true; }
    await new Promise((r) => setTimeout(r, 1000));
  }
  toast(tl("update.7")); return false;
}
// Click-to-update: the server only looks for a newer build (on start, then every few hours) and never
// installs on its own. When one is there, a quiet "업데이트" pill sits at the right end of the title
// bar, just left of the window controls (a button, so dragSpot leaves it out of the window drag).
// One press on it is the update: it downloads, installs and restarts, with the one line of progress
// (and 취소 while it downloads) in the popover under it. Only when a restart would cut work off
// (updHold) does it stop at "ready" and wait for 지금 다시 켜기.
function updOn() { return !!(UPD.u && UPD.u.can_apply) || UPD.phase !== ""; }
function updLabel() { return UPD.phase === "dl" ? `${UPD.pct}%` : UPD.phase === "ready" ? tl("upd.readypill") : updLine() || tl("update.2"); }
const updLocked = () => UPD.phase === "dl" || UPD.phase === "install" || UPD.phase === "restart";
function updPill() {
  if (updPhone() || !updOn()) return "";
  const cls = (Date.now() < UPD.enterUntil ? " enter" : "") + (updLocked() ? " busy" : "");
  return `<button class="updpill press${cls}" data-updpill aria-haspopup="dialog" style="--p:${UPD.pct}%" title="${esc(tl("upd.title", {v: UPD.u?.latest || ""}))}">${ic("dl")}<span>${updLabel()}</span></button>`;
}
// Keep every pill on screen in step without redrawing the header (the next head() draws it the same).
function paintUpd() {
  const t = document.getElementById("top");
  if (t && updOn() && !t.querySelector("[data-updpill]")) {
    const sp = t.querySelector(":scope > .wcsp"), tmp = document.createElement("template");
    tmp.innerHTML = updPill();
    t.insertBefore(tmp.content, sp);
  }
  document.querySelectorAll("[data-updpill]").forEach((b) => {
    if (!updOn()) return b.remove();
    b.classList.toggle("busy", updLocked()); b.style.setProperty("--p", (UPD.phase === "ready" ? 0 : UPD.pct) + "%");
    const sp = b.querySelector("span"); if (sp.textContent !== updLabel()) sp.textContent = updLabel();
  });
  const now = document.querySelector("#updpop .upx"), h = now && updNow("up");
  if (now && now.dataset.h !== h) { now.dataset.h = h; setHTML(now, h); }
  drawUpdBox();
}
function takeUpd(u) {
  const was = updOn(); UPD.u = u;
  if (!was && updOn()) UPD.enterUntil = Date.now() + 700;
  const d = u.download || {};
  // What the server already holds (the page was reloaded mid-way): a running download keeps showing
  // its progress but no longer installs by itself; a finished one waits to be applied; a failed
  // one shows its reason with a retry.
  if (!UPD.phase && u.can_apply) {
    if (d.state === "downloading") { UPD.phase = "dl"; UPD.auto = false; updPoll(); }
    else if (d.state === "ready" && d.version === u.latest) { UPD.phase = "ready"; UPD.pct = 100; }
    else if (d.state === "error" && d.version === u.latest && !UPD.err) { UPD.err = d.error || tl("get.1"); UPD.same = true; }
  }
  paintUpd();
}
const checkUpd = () => getUpd().then((u) => u && takeUpd(u));
if (!FLOAT) setInterval(checkUpd, 30 * 60e3);
// Title-bar connection pill: what the connect screen found, in one word. "ok" a line reaches a
// session at once, "slow" it is carried in by stop + resume, "off" no agent is connected. Only a
// real detect() result is shown (nothing before the first answer); a click opens 설정 > 연결.
let CONN = "";
const connHidden = () => { try { return localStorage.getItem("loop.connpill") === "0"; } catch (e) { return false; } };
function connKind(s) {
  // Codex needs no hook to talk here: it is up once signed in and a real test turn got a reply.
  const upC = (d) => !!d && d.installed && d.logged_in !== false && (d.pieces?.hook || {}).present === true && d.launcher !== "opaque";
  const c = s && s.claude, x = s && s.codex;
  const up = (d) => d === x ? !!d && d.installed && d.logged_in === true && !!d.talked : upC(d);
  if (!up(c) && !up(x)) return "off";
  // One agent is up while the other is installed here but stopped part-way: name the one that
  // works instead of a bare "연결됨" (an agent that is not installed at all is not counted).
  if (up(c) && x && x.installed && !up(x)) return "onlyc";
  if (up(x) && c && c.installed && !up(c)) return "onlyx";
  return up(c) && c.inbox === false ? "slow" : "ok";
}
const connLabel = () => CONN === "ok" ? tl("connpill.ok") : CONN === "slow" ? tl("connpill.slow")
  : CONN === "onlyc" ? tl("connpill.onlyc") : CONN === "onlyx" ? tl("connpill.onlyx") : tl("connpill.off");
// The pill itself is two small lamps, one per agent, with no words on it: lit = connected,
// hollow = not connected, amber = something to look at. The words are in the tooltip and the
// accessible name. The lamp's look is one class on <html> (lamp-a / lamp-b / lamp-c in v2.css).
document.documentElement.classList.add("lamp-b");
let CONNS = null;
function connLamp(k, s) {
  const d = s && s[k], st = d && d.installed && window.LOOP_CONNECT ? window.LOOP_CONNECT.step(k, s) : "";
  if (st === "done" && !(k === "claude" && d.launcher === "opaque")) return k === "claude" && d.inbox === false ? "slow" : "on";
  // Amber only when there is something to do: parts are in but the check was never passed.
  const any = d && Object.values(d.pieces || {}).some((x) => x && x.present === true);
  return st === "unsure" || (st === "check" && any) ? "need" : "off";
}
const connWord = () => ({on: tl("connpill.ok"), slow: tl("connpill.slow"), need: tl("connpill.need"), off: tl("connpill.off")});
const connLamps = () => [["claude", "Claude", "c"], ["codex", "Codex", "x"]].map(([agent, name, k]) => ({agent, name, k, state: connLamp(agent, CONNS)}))
  .map((l) => ({...l, word: connWord()[l.state]}));
// Each lamp may also carry the agent's weekly plan % (web/connuse.js): then the hover / long-press
// card says it all and the plain title is left off, so two tooltips never show at once.
// The pill as last painted. The first check runs 4 s in (and the plan numbers after it), so the
// pill used to arrive late and push what sits beside it: four buttons 40px on a phone, the bell
// 133px at 800px. Until the first answer the title bar shows the last one, at its settled width.
const CONN_LAST = "loop.connpill.last";
let connLast = "";
try { const h = localStorage.getItem(CONN_LAST) || ""; if (h.startsWith('<button class="connpill')) connLast = h; } catch (e) { /* starts without it */ }
function connPill() {
  if (connHidden()) return "";
  // Before the first answer on a device that never had one: an invisible pill of the plain width
  // holds the slot, so the buttons beside it do not jump when the real one lands.
  if (!CONN) return connLast || `<button class="connpill connph" data-connpill tabindex="-1" aria-hidden="true" style="visibility:hidden"><i class="lamp c off"></i><i class="lamp x off"></i></button>`;
  const CU = window.ConnUse, sh = CU ? CU.shown() : {}, any = sh.h5 || sh.wk, lamps = connLamps();
  const use = (l) => (CU ? CU.now(l.agent) : null);
  const say = lamps.map((l) => l.name + " " + l.word).join(" · ");
  const full = lamps.map((l) => [l.name + " " + l.word, any ? CU.say(use(l)) : ""].filter(Boolean).join(" ")).join(" · ");
  const hiAgent = any ? lamps.reduce((a, l) => (CU.worst(use(l)) > CU.worst(use(a)) ? l : a), lamps[0]).agent : "";
  return `<button class="connpill press${any && lamps.some((l) => CU.lamp(l.k, "", use(l), sh).includes("cu-w")) ? " cunum" : ""}" data-connpill${any ? "" : ` title="${esc(say)}"`} aria-label="${esc(full + " · " + tl("connpill.title"))}">${lamps.map((l) => {
    const cls = l.state === "on" ? "on" : l.state === "off" ? "off" : "wait";
    return CU ? CU.lamp(l.k, cls, use(l), sh, {name: l.name, hi: l.agent === hiAgent}) : `<i class="lamp ${l.k} ${cls}"></i>`;
  }).join("")}</button>`;
}
function paintConn() {
  document.querySelectorAll("[data-connpill]").forEach((b) => b.remove());
  const t = document.getElementById("top"); if (!t || !connPill()) return;
  const at = t.querySelector(":scope > [data-updpill]") || t.querySelector(":scope > .wcsp"), tmp = document.createElement("template");
  const h = connPill();
  tmp.innerHTML = h;
  t.insertBefore(tmp.content, at);
  if (CONN && h !== connLast) { connLast = h; try { localStorage.setItem(CONN_LAST, h); } catch (e) { /* this page only */ } }
}
async function checkConn(fresh) {
  const c = window.LOOP_CONNECT; if (!c) return;
  const s = fresh ? await c.refresh() : await c.status();
  if (!s) return;
  const k = connKind(s), was = connPill();
  CONNS = s;
  if (k !== CONN) { CONN = k; if (cur === "settings") setSums?.(); }
  if (connPill() !== was) paintConn();
}
// The one way to the connect card (설정 > 연결): the pill, and any "연결하기" link elsewhere
// (data-connopen), land on the same page.
function openConn() {
  setPage = "connect"; setShowPage = true;
  if (location.hash === "#settings") SCREENS.settings(); else location.hash = "#settings";
}
// The search pill is pinned to the bar's centre (glass.css), so what stands at its right (usage numbers,
// bell, window buttons) cannot push it: its width stops 8px short of the nearest of them instead. Below
// its 180px minimum (the same as glass.css) it turns into the icon-only search (#top.k3ic) rather than
// running under them.
let tbFitQ = 0;
const TB_PILL_MIN = 180;
function tbFit() {
  tbFitQ = 0;
  const t = document.getElementById("top"), k = t && t.querySelector(".k3q"); if (!k) return;
  const icon = t.classList.contains("k3ic");
  if (!matchMedia("(min-width:1280px)").matches || (!icon && getComputedStyle(k).position !== "absolute")) {
    t.style.removeProperty("--k3w"); t.classList.remove("k3ic"); return;
  }
  const tr = t.getBoundingClientRect(), cx = tr.left + tr.width / 2;
  let edge = tr.right;
  for (const c of t.children) { if (c === k || c.classList.contains("sp") || getComputedStyle(c).display === "none") continue;
    const r = c.getBoundingClientRect(); if (r.width && r.right > cx && r.left < edge) edge = Math.max(r.left, cx); }
  const room = Math.floor(2 * (edge - 8 - cx));
  t.classList.toggle("k3ic", room < TB_PILL_MIN);
  const w = Math.min(380, Math.max(TB_PILL_MIN, room));
  if (t.style.getPropertyValue("--k3w") !== w + "px") t.style.setProperty("--k3w", w + "px");
}
const tbFitSoon = () => { if (!tbFitQ) tbFitQ = requestAnimationFrame(tbFit); };
addEventListener("resize", tbFitSoon);
{ const t = document.getElementById("top"); if (t) new MutationObserver(tbFitSoon).observe(t, {childList: true, subtree: true, characterData: true}); }
window.LOOP_CONNPILL = {paint: paintConn, check: checkConn, open: openConn, lamps: connLamps};
setTimeout(checkConn, 4000);
setInterval(() => { if (!document.hidden) checkConn(true); }, 5 * 60e3);
// A lamp that is not lit is asked again every minute while a chat is open: an answer that just
// came back there is the proof (codex_check.last), and the pill must not go on saying otherwise.
setInterval(() => {
  if (document.hidden || !CONNS || !location.hash.startsWith("#project")) return;
  if (["claude", "codex"].some((k) => CONNS[k] && CONNS[k].installed && connLamp(k, CONNS) !== "on")) checkConn(true);
}, 60e3);
document.addEventListener("click", (e) => {
  if (!e.target.closest?.("[data-connpill],[data-connopen]")) return;
  if (e.target.closest("[data-connopen]") && typeof closeSheet === "function") closeSheet();
  openConn();
});   // reads the server's cached check; the server itself looks every few hours
function updPop(open) {
  const old = document.getElementById("updpop");
  document.querySelectorAll("[data-updpill]").forEach((b) => b.setAttribute("aria-expanded", String(!!open)));
  if (old) {
    old.classList.remove("on"); old.removeAttribute("id");
    const rm = () => old.remove(); old.addEventListener("transitionend", rm, {once: true}); setTimeout(rm, 400);
  }
  if (!open || !UPD.u || updPhone()) return false;
  const pill = document.querySelector("[data-updpill]"); if (!pill) return false;
  const u = UPD.u, now = updNow("up");
  const el = document.createElement("div");
  el.id = "updpop"; el.className = "updpop"; el.setAttribute("role", "dialog");
  el.setAttribute("aria-label", tl("upd.title", {v: u.latest}));
  el.innerHTML = `<div class="uph"><b>${esc(tl("upd.title", {v: u.latest}))}</b><span>${esc(tl("upd.cur", {cur: u.current}))}</span></div>`
    + (u.notes?.length || u.known_issues?.length ? `<details class="upd"><summary>${tl("upd.notes")}</summary>`
      + (u.notes?.length ? updList(u.notes.slice(0, 3), "upn") : "")
      + (u.known_issues?.length ? `<p class="upk">${esc(tl("upd.issuesn", {n: u.known_issues.length}))}</p>` : "") + `</details>` : "")
    + `<div class="upx">${now}</div>`;
  el.querySelector(".upx").dataset.h = now;
  const r = pill.getBoundingClientRect();
  el.style.top = Math.round(r.bottom + 8) + "px";
  document.body.appendChild(el);
  el.style.left = Math.max(12, Math.round(r.right - el.offsetWidth)) + "px";   // right edges meet, scrollbar or not
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("on")));
  return true;
}
const updClose = () => { updPop(false); document.querySelector("[data-updpill]")?.focus({preventScroll: true}); };
// Progress shows where the person is looking: the settings box when it is on screen, else the
// popover under the pill.
const updShow = () => !!document.getElementById("updbox") || !!document.getElementById("updpop") || updPop(true);
// The one press (업데이트 확인 that found a newer build, the pill, 업데이트): fetch, then apply.
function updStart() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  if (updLocked()) return updShow();
  if (UPD.phase !== "ready") return updGo();
  if (updHold()) { paintUpd(); return updShow(); }
  updInstall();
}
async function updGo() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  if (updLocked()) return;
  const run = ++UPD.run;
  UPD.auto = true; UPD.err = ""; UPD.phase = "dl"; UPD.pct = 0; paintUpd(); updShow();
  try { await post("/api/update", {step: "download"}); } catch (e) { if (run === UPD.run) updFail(e.message); return; }
  if (run === UPD.run) updPoll();
}
// 취소 while it downloads: the server stops fetching at its next chunk; nothing was installed.
function updCancel() {
  if (UPD.phase !== "dl") return;
  UPD.run++; UPD.phase = ""; UPD.pct = 0; updPop(false); paintUpd();
  post("/api/update", {step: "cancel"}).catch(() => {});
}
// A failure keeps its reason on screen (settings box, popover) with 다시 하기 until the next try.
// `same`: the running version is known to be untouched (every failure before the restart).
function updFail(msg, phase = "", same = true) { UPD.phase = phase; UPD.pct = phase ? 100 : 0; if (msg) { UPD.err = msg; UPD.same = same; } paintUpd();
  if (msg && !updShow()) toastFail(msg, same ? tl("err.ver.meta") : "", 5000, 5000); }
async function updPoll() {
  const run = UPD.run;
  while (UPD.phase === "dl" && run === UPD.run) {
    await new Promise((r) => setTimeout(r, 400));
    const d = (await fetch("/api/update").then((r) => r.json()).catch(() => null))?.download;
    if (run !== UPD.run || UPD.phase !== "dl") return;
    if (!d) continue;
    if (d.state === "error" || d.state === "idle") return updFail(d.error || tl("get.1"));
    UPD.pct = d.total ? Math.min(100, Math.floor(d.done * 100 / d.total)) : 0;
    if (d.state === "ready") {
      UPD.pct = 100;
      if (UPD.auto && !updHold()) return updInstall();
      UPD.phase = "ready"; paintUpd();
      if (!updShow()) toast(updHold() || tl("upd.readynote"), 5000);
      return;
    }
    paintUpd();
  }
}
async function updInstall() {
  if (updPhone()) return toast(tl("upd.phone.pc"), 4000);
  UPD.phase = "install"; UPD.err = ""; paintUpd();
  try { await post("/api/update", {step: "install"}); } catch (e) { return updFail(e.message, "ready"); }
  UPD.phase = "restart"; paintUpd();
  if (!await awaitRestart()) updFail(tl("update.7"), "", false);
}
document.addEventListener("click", (e) => {
  if (e.target.closest?.("[data-updpill]")) {
    // The pill only shows or hides the popover; 업데이트 / 지금 적용 inside it is the person's yes.
    if (document.getElementById("updpop")) return updPop(false);
    return updPop(true);
  }
  if (e.target.closest?.("[data-updgo]")) return updGo();
  if (e.target.closest?.("[data-updcancel]")) return updCancel();
  if (e.target.closest?.("[data-updapply]")) { if (UPD.phase === "ready") { updPop(false); updInstall(); } return; }
  if (document.getElementById("updpop") && !e.target.closest?.("#updpop")) updPop(false);
});
addEventListener("keydown", (e) => { if (e.key === "Escape" && document.getElementById("updpop")) updClose(); });
addEventListener("resize", () => { if (document.getElementById("updpop")) updPop(false); });
// The top bar and chrome are drawn for one side of the 1024 breakpoint, so a window dragged across it is drawn again.
{ const lay = () => wide() ? compact() ? "compact" : "wide" : "phone"; let was = lay();
  addEventListener("resize", () => { if (was === lay()) return; const flip = (was === "phone") !== (lay() === "phone"); was = lay(); railPeek = false; railMark();
    // Phone <-> desktop: a detail page decided its layout (body.detail, header tools, columns) when it
    // was routed, so it is routed again; the desktop bell drawer has no place on a phone.
    if (flip && !wide()) document.getElementById("k3bell")?.k3shut?.();
    if (flip && detail) return render();
    drawChrome(); if (head.last) head(...head.last); redraw(); }); }
const sound = (v) => { try {
  // Key renamed off the old product name "reviewhub"; read it once so a saved preference carries over.
  const p = JSON.parse(localStorage.getItem("genok") ?? localStorage.getItem("reviewhub") ?? "{}");
  if (v === undefined) return p.sound !== false; p.sound = v; localStorage.setItem("genok", JSON.stringify(p)); } catch { return true; } };
// Phone notifications (Web Push via /sw.js). An iPhone only allows them from the home-screen app.
const pushable = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
let swReg = null;
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").then((r) => { swReg = r; return pushSync().catch(() => {}); }).then(() => { if (cur === "settings") drawPush(); }).catch(() => {});
  navigator.serviceWorker.addEventListener("message", (e) => { if (e.data?.open) location.href = e.data.open; });
}
const urlKey = (b64) => Uint8Array.from(atob(b64.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - b64.length % 4) % 4)), (c) => c.charCodeAt(0));
// Keeps this device's subscription deliverable, on every load and before a test. A phone drops
// its subscription without a word (the app was re-added, the permission flipped off and on), the
// PC forgets one its push service called gone, and one made for another server key is refused
// for good. While the permission stands a new one is made without asking again.
// pushLast: how the last notice to this device went ({at, code}), null when none was sent.
let pushLast = null;
async function pushSync() {
  if (!swReg || !pushable || Notification.permission !== "granted" || (window.planCan && !planCan("push_notify"))) return null;
  const {key} = await get("/api/push/key");
  let sub = await swReg.pushManager.getSubscription();
  const made = sub?.options?.applicationServerKey;
  if (made && btoa(String.fromCharCode(...new Uint8Array(made))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") !== key) { await sub.unsubscribe(); sub = null; }
  if (!sub) sub = await swReg.pushManager.subscribe({userVisibleOnly: true, applicationServerKey: urlKey(key)});
  pushLast = (await post("/api/push/subscribe", {subscription: sub.toJSON()})).last || null;
  return sub;
}
async function drawPush() {
  const s = document.getElementById("pushs"), b = document.getElementById("pushb"); if (!s) return;
  // Push notifications are a Pro feature (pricing.md): show a calm hint and open the Pro
  // sheet instead of subscribing. The server also 403s /api/push/* on free.
  if (window.planCan && !planCan("push_notify")) {
    s.textContent = tl("license.pro_push_notify");
    b.textContent = tl("license.pro_enter"); b.disabled = false;
    b.onclick = () => window.proSheet("push_notify");
    return;
  }
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent), home = matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
  // Safari shows no buttons on a notification: say so where approving from one would be expected.
  if (ios && !document.getElementById("pushios")) s.insertAdjacentHTML("afterend", `<span class="srd" id="pushios">${tl("pwa.ios_push")}</span>`);
  if (ios && !home) { s.textContent = tl("drawPush.1"); return; }
  if (!pushable) { s.textContent = tl("drawPush.2"); return; }
  const sub = swReg ? await swReg.pushManager.getSubscription().catch(() => null) : null, on = !!sub && Notification.permission === "granted";
  // One quiet line, and it says what is true: blocked, the last notice did not go out, on, or off.
  const sent2xx = (l) => !l || (l.code >= 200 && l.code < 300);
  s.textContent = Notification.permission === "denied" ? tl("drawPush.6") : on && !sent2xx(pushLast) ? tl("drawPush.failed") : on ? tl("drawPush.3") : tl("drawPush.4");
  b.textContent = on ? tl("drawPush.5") : tl("settings.8"); b.disabled = !swReg;
  b.onclick = async () => { b.disabled = true;
    try {
      if (!on && await Notification.requestPermission() !== "granted") throw new Error(tl("drawPush.6"));
      const mine = await pushSync();
      // The test goes to this device only.
      const {sent, pc, last} = await post("/api/push/test", {endpoint: mine.endpoint}); pushLast = last;
      // Gone at the push service (the PC already forgot it) or refused there: make a new one now.
      if (!sent && (!last || last.code === 403)) { await mine.unsubscribe(); await pushSync(); toast(tl("drawPush.renewed")); }
      else toast(sent ? tl("drawPush.7") : pc ? tl("drawPush.pc") : tl("drawPush.8"));
    } catch (err) { toast(err.message); }
    drawPush(); };
}
