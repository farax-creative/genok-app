# cryptography

Genok bundles the **cryptography** library to send phone notifications over standard
Web Push: it encrypts each message for one phone (RFC 8291, aes128gcm) and signs the VAPID
token (RFC 8292). See `push.py`.

- License: dual-licensed **Apache-2.0 OR BSD-3-Clause** (you may use either).
- Copyright © The Python Cryptographic Authority and individual contributors.
- Full license text:
  https://github.com/pyca/cryptography/blob/main/LICENSE
  (Apache-2.0: https://github.com/pyca/cryptography/blob/main/LICENSE.APACHE,
  BSD-3-Clause: https://github.com/pyca/cryptography/blob/main/LICENSE.BSD)
- Project: https://cryptography.io/

The binary wheel statically links **OpenSSL**, which is licensed under the Apache License 2.0
(https://www.openssl.org/source/license.html).
