# FFmpeg (bundled)

Genok bundles `ffmpeg.exe` and `ffprobe.exe` (with their DLLs) so it can make video
thumbnails and browser-playable proxies on a machine that has no system ffmpeg installed.

- Build used: an **LGPL** build of FFmpeg from BtbN's FFmpeg-Builds
  (https://github.com/BtbN/FFmpeg-Builds), `win64-lgpl-shared`.
- Because it is an LGPL build it does **not** include GPL encoders such as `libx264`. Genok
  detects the available encoders at runtime and uses `libopenh264` (LGPL) for H.264 output; see
  `mediatools.py`.
- FFmpeg is free software licensed under the GNU Lesser General Public License (LGPL) version 2.1
  or later. The full license text is at https://www.gnu.org/licenses/lgpl-2.1.html and the
  corresponding source is available from https://ffmpeg.org/ and the BtbN build repository above.

The binaries are downloaded at build time (see `tools/build_exe.py::ensure_ffmpeg`) and are not
committed to this repository.
