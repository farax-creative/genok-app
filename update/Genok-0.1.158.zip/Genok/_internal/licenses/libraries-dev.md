# Libraries.dev (Border Beam)

The rotating border glow (`.bbeam` in `web/v2.css`) is an independent CSS take on the
**Border Beam** idea from Libraries.dev by Jakub Antalik; no source files were copied.

- License of the project: **MIT**.
- Project: https://github.com/Jakubantalik/Libraries.dev
