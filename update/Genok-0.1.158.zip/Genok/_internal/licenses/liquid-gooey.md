# liquid-gooey (Libraries.dev)

The effort control in the model menu (`web/effort-move.js`, `web/effort-move.css`) is a plain
JavaScript port of the **move** effect of `liquid-gooey` 0.2.2 from Libraries.dev by Jakub Antalik:
the goo filter chain, the surface spring and the velocity stretch. The React wrappers and the
other effects of the package are not included.

- License: **MIT**, Copyright (c) 2026 Jakub Antalik.
- Project: https://github.com/Jakubantalik/Libraries.dev (packages/liquid-gooey) - https://libraries.dev/gooey

```
MIT License

Copyright (c) 2026 Jakub Antalik

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
