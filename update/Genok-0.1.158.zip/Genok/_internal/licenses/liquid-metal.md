# Liquid Metal (Libraries.dev) and Paper Shaders

The silver sheen on the Pro buttons (`.m-metal` in `web/motion.css`, `metal()` in `web/motion.js`) follows the
look of the **Liquid Metal** component (`metal-fx`) from Libraries.dev by Jakub Antalik: flowing chrome stripes,
noise-warped, with red and blue dispersion at the stripe edges and a lit rim. The component's material is the
`liquidMetal` shader of **Paper Shaders** by Paper Design, Inc.

Genok does not bundle either package or any of their shader source. The effect is rewritten as a small
software renderer on a 2D canvas (no WebGL), paused when the button is off screen, still under reduced motion.

- Libraries.dev Liquid Metal: **MIT**, Copyright (c) 2026 Jakub Antalik. https://github.com/Jakubantalik/Libraries.dev
- Paper Shaders (`liquidMetal`): **Apache License 2.0**, Copyright (c) Paper Design, Inc. https://github.com/paper-design/shaders
  Licence text: http://www.apache.org/licenses/LICENSE-2.0

```
MIT License

Copyright (c) 2026 Jakub Antalik

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
