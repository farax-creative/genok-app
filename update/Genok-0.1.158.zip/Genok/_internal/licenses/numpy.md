# NumPy

Genok bundles **NumPy** to measure every frame of a render in the render check (렌더 자동 검사):
NaN/inf pixels, fireflies, flicker and clipped highlights. See `qc.py`.

- License: **BSD-3-Clause**.
- Copyright © 2005-2025, NumPy Developers. All rights reserved.
- Full license text: https://github.com/numpy/numpy/blob/main/LICENSE.txt
- Project: https://numpy.org/

The NumPy wheel carries further libraries in `numpy.libs`, each under its own license:

- **OpenBLAS** (scipy-openblas build) - BSD-3-Clause. Copyright © 2011-2014, The OpenBLAS Project.
  https://github.com/OpenMathLib/OpenBLAS/blob/develop/LICENSE
- **LAPACK** (inside OpenBLAS) - modified BSD license. Copyright © 1992-2013 The University of
  Tennessee and The University of Tennessee Research Foundation, The University of California
  Berkeley, The University of Colorado Denver. http://www.netlib.org/lapack/LICENSE.txt
- **GCC runtime libraries** (libgfortran, libquadmath, built into OpenBLAS) - GPL-3.0 with the GCC
  Runtime Library Exception 3.1. https://www.gnu.org/licenses/gcc-exception-3.1.html
- **Microsoft Visual C++ runtime** (msvcp140) - redistributed under the Microsoft Visual Studio
  redistributable license.
