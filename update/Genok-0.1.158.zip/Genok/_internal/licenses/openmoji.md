# OpenMoji

Department emoji are shown with **OpenMoji** artwork (`web/emoji/color/*.svg` and
`web/emoji/black/*.svg`, SVG files from the openmoji npm package v15.1.0, unmodified).

- License: **CC BY-SA 4.0** (https://creativecommons.org/licenses/by-sa/4.0/).
- Copyright: the OpenMoji contributors (https://openmoji.org/).
- Project: https://github.com/hfg-gmuend/openmoji

The emoji artwork is licensed separately from the app code; the share-alike term applies to the
artwork files themselves, not to the rest of Genok.
