# Phosphor Icons

The UI icons in `web/v2.js` (the `P` table behind `ic()`) are Phosphor Icons, regular weight, plus the
fill weight for the pinned star. Only the glyphs the app uses are inlined; the path data is unmodified
(from @phosphor-icons/core 2.1.1).

The animated icons in `web/motion.js` use the same regular-weight glyphs in their stroked source form
(16-unit strokes on the 256 grid), split into parts so each part can move.

The icon picker's styles (라인 · 굵게 · 채움 · 듀오톤) are the whole set in four weights - regular, bold, fill
and duotone - as one sprite per weight under `web/icons/ph-<weight>.svg`, built by `tools/gen_phosphor.py`
from the "SVGs Flat" folder of the Phosphor download (phosphoricons.com, 2.1). Path data unmodified.

- License: **MIT**.
- Project: https://github.com/phosphor-icons/core (https://phosphoricons.com/)

```
MIT License

Copyright (c) 2023 Phosphor Icons

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
