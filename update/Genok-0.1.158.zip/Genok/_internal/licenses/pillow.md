# Pillow

Genok bundles **Pillow** (the friendly PIL fork) to read images and make the
thumbnails shown on result cards. See `mediatools.py`.

- License: **HPND** (Historical Permission Notice and Disclaimer), a permissive
  MIT-style license.
- Copyright © 2010 Jeffrey A. Clark and contributors. Original PIL: copyright ©
  1997-2011 Secret Labs AB, copyright © 1995-2011 Fredrik Lundh.
- Full license text: https://github.com/python-pillow/Pillow/blob/main/LICENSE
- Project: https://python-pillow.org/
