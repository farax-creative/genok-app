# Pretendard

Genok bundles the **Pretendard** font so the Korean UI reads the same on every machine,
without a web font CDN.

- License: **SIL Open Font License 1.1** (OFL).
- Copyright © 2021 Kil Hyung-jin, with Reserved Font Name "Pretendard".
- Full license text: `web/fonts/OFL.txt`
  (OFL 1.1: https://openfontlicense.org/)
- Project: https://github.com/orioncactus/pretendard

The bundled files (`web/fonts/pretendard-*.woff2`) are a Modified Version: Pretendard Variable
split into unicode-range subsets by `tools/font_subset.py`, so a page downloads only the
characters it shows. Every glyph and the variable weight axis are kept. As OFL 1.1 requires for a
Modified Version, the font name inside these files is changed to "Genok Sans"; the copyright
and license records are kept as they were.
