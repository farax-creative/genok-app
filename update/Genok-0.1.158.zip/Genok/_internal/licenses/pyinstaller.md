# PyInstaller

Genok is frozen into an executable with **PyInstaller**. Only PyInstaller's
**bootloader** ends up inside the shipped program; the packaging tool itself is not
redistributed.

- License: **GPL-2.0-or-later with a special bootloader exception**. The exception
  explicitly permits using PyInstaller to build and distribute non-free programs
  (including commercial ones), so bundling the bootloader here is allowed.
- Copyright © 2005-2025, PyInstaller Development Team.
- Full license text and exception:
  https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt
- Project: https://pyinstaller.org/
