# pystray

Genok uses **pystray** to put its icon in the Windows tray (show, quit). See
`tray.py` and `app_main.py`.

- License: **LGPL-3.0-or-later**.
- Copyright © 2016-2025 Moses Palmér.
- Because pystray is an LGPL library, its own source is available from the project below,
  and it is used as an unmodified importable library (dynamically linked), so it can be
  replaced with another compatible build.
- Full license text: https://github.com/moses-palmer/pystray/blob/master/COPYING.LGPL
  (LGPL-3.0: https://www.gnu.org/licenses/lgpl-3.0.html)
- Project: https://github.com/moses-palmer/pystray
