# pywebview

Genok uses **pywebview** to show its window: a native webview hosting the local
app, with no browser chrome. See `app_main.py`.

- License: **BSD 3-Clause**.
- Copyright © 2014-2025 Roman Sirokov and contributors.
- Full license text: https://github.com/r0x0r/pywebview/blob/master/LICENSE
- Project: https://pywebview.flowrl.com/
