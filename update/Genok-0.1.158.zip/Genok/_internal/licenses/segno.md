# segno

Genok vendors **segno** to render the "phone via Tailscale" QR codes as inline SVG.
See `third_party/segno/` and `phone.py`.

- License: **BSD 3-Clause**.
- Copyright © 2016-2025, Lars Heuer.
- Full license text: `third_party/LICENSE`
  (also https://github.com/heuer/segno/blob/master/LICENSE)
- Project: https://github.com/heuer/segno
