import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { GenokFeed } from '../types'

const PANE = 'genok'
const POLL_MS = 30_000
const TIMEOUT_MS = 600
const FEED = { plugin: 'genok', key: 'feed' } as const
const feed = atom(FEED, null)

const WORDS = {
  ko: {
    open: '열린 지시',
    waiting: '승인 대기',
    hint: '/genok-todo 목록 · 올리기 loop push <파일> --item <항목>',
    none: '열린 지시가 없어요.',
    off: 'Genok이 꺼져 있거나 이 폴더의 프로젝트를 찾지 못했어요.',
  },
  en: {
    open: 'Open instructions',
    waiting: 'Awaiting approval',
    hint: '/genok-todo to list · push with loop push <file> --item <item>',
    none: 'No open instructions.',
    off: 'Genok is not running, or this folder has no project.',
  },
}

const listText = (got: GenokFeed | null) => {
  if (got === null) {
    return WORDS.en.off
  }
  if (got.directives.length === 0) {
    return WORDS[got.lang].none
  }

  return got.directives.map(d => `${d.item} [${d.id}] ${d.text}`).join('\n')
}

// The one fail-silent place: Genok closed, slow or answering something else all read as
// "nothing to show". Never awaited by a hook the prompt waits on.
const refresh = async ($: EngineInterface, url: string) => {
  let got: GenokFeed | null = null
  try {
    const cwd = await $.session.cwd()
    const answer = await Promise.race([
      $.http.fetch(`${url}/api/mod?cwd=${encodeURIComponent(cwd)}`),
      $.clock.sleep(TIMEOUT_MS),
    ])
    if (answer?.ok) {
      got = JSON.parse(answer.text)
    }
  } catch {
    got = null
  }
  await update($, feed, old => (JSON.stringify(old) === JSON.stringify(got) ? old : got))
}

export const register: Register = (on, options) => {
  const url = String(options.url)

  on('session.start', async ($, e, next) => {
    void refresh($, url)
    $.clock.every(POLL_MS, () => void refresh($, url))
    await $.command.register({
      name: 'genok-todo',
      description: 'Genok: open instructions for this project',
      immediate: true,
    })

    return next(e)
  })

  on('command.run', { command: 'genok-todo' }, async $ => {
    await refresh($, url)
    const surfaces = await $.session.surfaces()
    if (surfaces.includes('terminal') || surfaces.includes('desktop')) {
      await $.ui.open({ id: PANE, title: 'Genok' })

      return {}
    }

    // Nothing draws a pane here (VS Code panel, claude -p): answer in the transcript.
    return { text: listText((await $.state.get(FEED)).value ?? null) }
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const got = await read($, feed)
    if (e.props.hasSurvey || got === null || got.open + got.waiting === 0) {
      return next(e)
    }

    const { Box, Text } = $.ui.resolve(e)
    const words = WORDS[got.lang]

    return (
      <Box gap={2}>
        <Text>
          {words.open} {got.open} · {words.waiting} {got.waiting}
        </Text>
        <Text dimColor>{words.hint}</Text>
      </Box>
    )
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text } = $.ui.resolve(e)
    const got = await read($, feed)

    return (
      <Box flexDirection="column">
        {(got === null || got.directives.length === 0) && <Text dimColor>{listText(got)}</Text>}
        {got?.directives.map(d => (
          <Box flexDirection="column" marginBottom={1}>
            <Text bold>{d.item}</Text>
            <Text>
              <Text dimColor>[{d.id}]</Text> {d.text}
            </Text>
          </Box>
        ))}
      </Box>
    )
  })
}
