export type GenokDirective = { item: string; id: string; text: string; at: string }

// What GET /api/mod answers (connect_mod.feed).
export type GenokFeed = {
  project: string
  lang: 'ko' | 'en'
  open: number
  waiting: number
  directives: GenokDirective[]
}

declare module 'claude-code' {
  interface PluginState {
    genok: { feed: GenokFeed | null }
  }
}
