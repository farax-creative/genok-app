// Which Claude account a department start lands in, said before starting (acct_guard.py).
// The incident: the desktop app moved to a new account while Claude Code stayed signed into the old
// one, so started sessions opened where the app never showed them. confirmStart(names) asks the
// server first; when the start would land out of sight (or the account is out of limit / signed out)
// a sheet says so plainly with one-tap fixes, and only "그래도 켜기" or a fix goes on. watchStart(name)
// checks a little later that the session really appeared. chip(row) marks a session's account once
// more than one account has been seen. Own file, own CSS; uses v2.js globals get, post, sheet,
// closeSheet, toast, esc, tl.
(function () {
  "use strict";
  const FIRST_KEY = "rl-acct-first-asked";

  (function css() {
    if (document.getElementById("acg-css")) return;
    const st = document.createElement("style"); st.id = "acg-css";
    st.textContent = `
    .acg-w{margin:12px 0 0;padding:12px 16px;border-radius:12px;background:var(--card);border:1px solid var(--line)}
    .acg-w.lv-stop{border-color:color-mix(in srgb,var(--orange) 45%,transparent)}
    .acg-w p{margin:0;font-size:14px;line-height:1.55;color:var(--t1);overflow-wrap:anywhere}
    .acg-fx{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
    .acg-fx .btn{height:34px;min-height:0;padding:0 12px;font-size:13px}
    .acg-acts{display:flex;gap:8px;margin-top:16px}
    .acg-acts .btn{flex:1 1 0}
    .acg-who{margin:4px 0 0;font-size:13px;color:var(--t3)}
    .acc-chip{flex:none;display:inline-flex;align-items:center;height:20px;padding:0 8px;border-radius:6px;font-size:11.5px;
      font-weight:600;white-space:nowrap;color:var(--t2);background:var(--btn)}
    .acc-chip.other{color:var(--orange);background:color-mix(in srgb,var(--orange) 14%,transparent)}`;
    document.head.appendChild(st);
  })();

  const q = (names, fresh) => "/api/accounts/preflight?names=" + encodeURIComponent(names.join(","))
    + "&count=" + names.length + (fresh ? "&fresh=1" : "");
  const seenFirst = () => { try { return !!localStorage.getItem(FIRST_KEY); } catch (e) { return false; } };
  const markFirst = () => { try { localStorage.setItem(FIRST_KEY, "1"); } catch (e) { /* per-viewer only */ } };

  function body(r) {
    const ws = r.warnings.slice().sort((a, b) => (a.level === "stop" ? 0 : 1) - (b.level === "stop" ? 0 : 1));
    const groups = r.groups.filter((g) => g.names.length).map((g) => `${esc(g.label)}${g.short ? " (" + esc(g.short) + ")" : ""}`);
    return `<h3>${tl("acg.h")}</h3>${groups.length ? `<p class="acg-who">${esc(tl("acg.who", {w: groups.join(", ")}))}</p>` : ""}`
      + ws.map((w, i) => `<div class="acg-w lv-${w.level}"><p>${esc(w.text)}</p>${w.fixes.length ? `<div class="acg-fx">`
        + w.fixes.map((f, j) => `<button class="btn press" data-acg-fx="${i}:${j}">${esc(f.label)}</button>`).join("") + `</div>` : ""}</div>`).join("")
      + `<div class="acg-acts"><button class="btn press" data-acg-no>${tl("acg.cancel")}</button>`
      + `<button class="btn fill press" data-acg-go>${r.ok ? tl("acg.go") : tl("acg.anyway")}</button></div>`;
  }

  // Resolves true to go on with the start, false to stop. Never throws: if the check itself fails the
  // start goes on as before (the server-side start still reports its own errors).
  async function confirmStart(names) {
    names = (names || []).filter(Boolean);
    if (!names.length) return true;
    let r;
    try { r = await get(q(names)); } catch (e) { return true; }
    if (!r || !Array.isArray(r.warnings)) return true;
    const first = r.warnings.some((w) => w.code === "first");
    if (r.ok && (!first || seenFirst())) {
      const info = r.warnings.find((w) => w.level === "info" && w.code !== "first");
      if (info) toast(info.text, 5200);
      return true;
    }
    if (first) markFirst();
    return new Promise((resolve) => {
      let done = false;
      const end = (v) => { if (done) return; done = true; obs.disconnect(); resolve(v); };
      const host = document.getElementById("sheet");
      // Any way the sheet goes away (scrim, X, Esc, drag down) counts as 취소.
      const obs = new MutationObserver(() => { if (!host.classList.contains("on")) end(false); });
      const paint = (box, rr) => {
        r = rr; box.querySelectorAll(":scope > :not(.sgrab):not(.sx)").forEach((x) => x.remove());
        box.insertAdjacentHTML("beforeend", body(r));
      };
      sheet(body(r), (box) => {
        box.addEventListener("click", async (e) => {
          const b = e.target.closest("[data-acg-fx],[data-acg-go],[data-acg-no]"); if (!b) return;
          if (b.hasAttribute("data-acg-no")) { end(false); closeSheet(); return; }
          if (b.hasAttribute("data-acg-go")) { end(true); closeSheet(); return; }
          const [i, j] = b.dataset.acgFx.split(":").map(Number);
          const ws = r.warnings.slice().sort((a, c) => (a.level === "stop" ? 0 : 1) - (c.level === "stop" ? 0 : 1));
          const f = ws[i] && ws[i].fixes[j]; if (!f) return;
          b.disabled = true;
          try {
            if (f.kind === "use") {
              await post("/api/accounts/use", {names, account: f.account || ""});
              end(true); closeSheet(); return;
            }
            if (f.kind === "login") {
              const res = await post("/api/accounts/login", {account: f.account || ""});
              toast(res.note || tl("acg.login"), 6000);
            } else if (f.kind === "app") {
              await post("/api/accounts/app", {org: f.org});
            }
            const rr = await get(q(names, true));
            if (rr && rr.ok) { end(true); closeSheet(); return; }
            if (rr) paint(box, rr);
          } catch (err) { toast(err.message); }
          finally { if (b.isConnected) b.disabled = false; }
        });
      });
      obs.observe(host, {attributes: true, attributeFilter: ["class"]});
    });
  }

  // A background start said "opened", but the session never showed up: say why (usually the account).
  function watchStart(name, wait) {
    setTimeout(async () => {
      try {
        const r = await get("/api/accounts/started?name=" + encodeURIComponent(name));
        if (r && r.seen === false && r.hint) toast(r.hint, 8000);
      } catch (e) { /* nothing to add */ }
    }, wait || 25000);
  }

  function chip(row) {
    if (!row || !row.acct_short) return "";
    const t = row.acct_other ? tl("acg.other") : row.acct_short;
    return `<span class="acc-chip${row.acct_other ? " other" : ""}" title="${esc(t)}">${esc(row.acct_short)}</span>`;
  }

  window.RLAcct = {confirmStart, watchStart, chip};
})();
