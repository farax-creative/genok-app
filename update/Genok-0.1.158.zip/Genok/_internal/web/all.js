// 전체: the right-most phone tab. A compact top row (the app's name, small links: 알림, 검색, 설정)
// and below it every place that has no tab of its own, in cards under bold headers: the other
// screens, extension screens, usage, connections, update and help. Every row opens a real place.
//
// Phone routes enter in place without copying the app shell or its tab bar.
// Settings pages keep their own direct-manipulation edge gesture.
//
// Uses v2.js globals: SCREENS, V, tl, ic, esc, nav, back, isPhoneW, RM, extTabs, tabExt, projects,
// unitWord, D, CONN, connLabel, updOn, planName, todoCount, fbUrl, setPage, setDeep.
(function () {
  "use strict";

  // ------------------------------------------------------------------ the page
  const row = (o) => {
    const inner = `<span class="ai">${ic(o.i)}</span><span class="srn">${esc(o.n)}</span>${o.v ? `<span class="srv">${esc(o.v)}</span>` : ""}<span class="smc">${ic("chev")}</span>`;
    return o.href ? `<a class="allrow press" href="${esc(o.href)}" data-feedback target="_blank" rel="noopener noreferrer">${inner}</a>`
      : `<button class="allrow press" ${o.attr}>${inner}</button>`;
  };
  const card = (title, rows) => rows.length ? `<section class="setgrp"><h3 class="setgh">${esc(title)}</h3><div class="sgcard">${rows.map(row).join("")}</div></section>` : "";

  // What the page lists, as data: [{title, rows: [{i, n, v, attr | href}]}]. Pure given the app's state,
  // so the structure can be read and tested without drawing it.
  function sections() {
    const xt = extTabs(), usage = xt.find((t) => t.id === "usage"), others = tabExt(xt).filter((t) => t.id !== "usage");
    const screens = [
      {i: "folders", n: unitWord(), v: String(projects().length), attr: `data-go="depts"`},
      {i: "clock", n: tl("routines.nav"), attr: `data-go="routines"`},
      {i: "flag", n: tl("retro.nav"), attr: `data-go="retro"`},
    ];
    const link = [
      ...(usage ? [{i: usage.icon, n: usage.label, attr: `data-go="usage"`}] : []),
      {i: "plug", n: tl("ui.set.connect"), v: CONN ? connLabel() : "", attr: `data-allset="connect"`},
      {i: "phone", n: tl("ui.set.phone"), attr: `data-allset="phone"`},
    ];
    const info = [
      {i: "dl", n: tl("update.1"), v: updOn() ? tl("set.val.new") : D.ver ? "v" + D.ver : "", attr: `data-allset="update"`},
      {i: "info", n: tl("ui.set.about"), attr: `data-allset="about"`},
      ...(fbUrl() ? [{i: "megaphone", n: tl("fb.send"), href: fbUrl()}] : []),
    ];
    return [
      {k: "screens", title: tl("all.sec.screens"), rows: screens},
      {k: "ext", title: tl("ui.ext"), rows: others.map((t) => ({i: t.icon, n: t.label, attr: `data-go="${esc(t.id)}"`}))},
      {k: "link", title: tl("all.sec.link"), rows: link},
      {k: "info", title: tl("ui.setg.info"), rows: info},
    ].filter((s) => s.rows.length);
  }

  SCREENS.all = function () {
    const todo = todoCount();
    V().innerHTML = `<div class="allpage">`
      + `<div class="alltop"><div class="allname"><h1>Genok</h1><span class="allsub num">${esc(planName())}</span></div><nav class="alllinks" aria-label="${esc(tl("all.tab"))}">`
      + `<button class="press" data-go="inbox">${tl("TABS.1")}${todo ? `<b class="num">${todo > 99 ? "99+" : todo}</b>` : ""}</button>`
      + `<button class="press" data-go="search">${tl("MENUS.5")}</button>`
      + `<button class="press" data-allset="">${tl("TABS.4")}</button></nav></div>`
      + sections().map((s) => card(s.title, s.rows)).join("") + `</div>`;
  };

  // A route owns one live screen. Copying the whole shell loses id-based layout and duplicates
  // navigation chrome; only the destination enters in place, never a frozen shell above it.
  const S = {fromAll: false, prevHash: ""};
  function push(page) {
    setPage = page || setPage; setDeep = !!page && isPhoneW();
    S.fromAll = isPhoneW(); S.prevHash = location.hash;
    nav("settings");
  }
  function pop() {
    S.fromAll = false;
    if (S.prevHash === "#all") history.back(); else nav("all");
  }
  addEventListener("hashchange", () => { if (cur !== "settings") S.fromAll = false; });

  // ------------------------------------------------------------------ wiring
  document.addEventListener("click", (e) => {
    const b = e.target.closest?.("[data-allset]"); if (!b) return;
    e.preventDefault(); e.stopPropagation(); push(b.dataset.allset);
  }, true);

  // A flick from the left edge on the settings list goes back to 전체 (the open page has its own
  // 1:1 swipe, v2.js setEdge). Not dragged along with the finger: the list and 전체 are two screens.
  let ex = null;
  document.addEventListener("pointerdown", (e) => {
    ex = null;
    if (!isPhoneW() || RM() || e.button || e.clientX > 24 || cur !== "settings" || setShowPage || !S.fromAll) return;
    ex = {id: e.pointerId, x: e.clientX, y: e.clientY, t: e.timeStamp};
  }, true);
  document.addEventListener("pointerup", (e) => {
    const s = ex; ex = null;
    if (!s || s.id !== e.pointerId) return;
    const dx = e.clientX - s.x, dy = Math.abs(e.clientY - s.y);
    if (dx > 64 && dy < dx * 0.6 && (dx > 140 || dx / Math.max(1, e.timeStamp - s.t) > 0.35)) pop();
  }, true);

  window.LOOP_ALL = {sections, pop, push, from: () => S.fromAll && cur === "settings"};
  if (typeof module !== "undefined" && module.exports) module.exports = {sections};
})();
