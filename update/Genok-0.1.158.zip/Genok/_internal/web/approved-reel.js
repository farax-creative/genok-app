// Approved reel (beta "pai", approved_reel.py): a project's newest approved version of each item played back
// to back in shot order, or one item's versions in a row, as one continuous review. The original
// files play in two <video> elements that take turns: while one plays, the other already holds the
// next clip, so the cut lands without a gap and nothing is stitched or encoded. The bar under the
// picture is the reel itself: one segment per clip, as wide as the clip is long; a press jumps there.
(function () {
  "use strict";

  // ---- pure (tests/approved-reel.test.js) ----
  // Segment widths: a clip whose length is not known yet takes the mean of the known ones.
  function weights(durs) {
    const known = durs.filter((d) => d > 0), mean = known.length ? known.reduce((a, b) => a + b, 0) / known.length : 4;
    return durs.map((d) => (d > 0 ? d : mean));
  }
  // Seconds into the whole reel at clip `at`, `t` seconds in.
  const elapsed = (ws, at, t) => ws.slice(0, at).reduce((a, b) => a + b, 0) + Math.max(0, t || 0);
  const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
  const pure = {weights, elapsed, fmt};
  if (typeof module !== "undefined" && module.exports) { module.exports = pure; return; }
  if (!window.genokBeta?.("pai")) return;

  const enc = encodeURIComponent;
  let shut = null;                                    // closes the reel that is up

  async function open(p, item, startId) {
    if (shut) shut();
    let r;
    try { r = await get(`/api/reel/approved?p=${enc(p)}${item ? `&i=${enc(item)}` : ""}`); } catch (e) { return toast(e.message); }
    const clips = r.clips || [];
    if (!clips.length) return toast(item ? tl("areel.none.item") : tl("areel.none"));
    const k = Math.max(0, clips.findIndex((c) => c.id === startId));
    build(p, item, clips, item ? 0 : k);
  }

  function build(p, item, clips, start) {
    const el = document.createElement("div");
    el.className = "arl"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true");
    el.setAttribute("aria-label", item ? tl("areel.item") : tl("areel.t"));
    const one = clips[0];
    el.innerHTML = `<div class="arlstage"><video class="arlv on" playsinline preload="auto"></video><video class="arlv" playsinline preload="auto"></video><div class="arlspin" hidden>${loadingHtml("", {tight: true})}</div></div>
      <div class="arltop"><div class="arlhd"><b>${item ? esc(tl("areel.item.of", {t: one.title})) : tl("areel.t")}</b><span class="arln num"></span></div>
        <div class="seg arlseg" role="group" aria-label="${tl("areel.mode")}"><button class="press${item ? "" : " on"}" data-arlm="all" aria-pressed="${!item}">${tl("areel.m.all")}</button><button class="press${item ? " on" : ""}" data-arlm="item" aria-pressed="${!!item}">${tl("areel.m.item")}</button></div>
        <button class="ib press" data-arlx aria-label="${tl("itemView.114")}">${ic("x")}</button></div>
      <div class="arlfoot"><div class="arlnow"><button class="ib press arlplay" type="button" aria-label="${tl("itemView.39")}">${ic("play")}</button><span class="arlname"></span><span class="arltime num"></span></div>
        <div class="arlbar" role="group" aria-label="${tl("areel.bar")}">${clips.map((c, n) => `<button class="arlc press" type="button" data-arlc="${n}" aria-label="${esc(`${c.title} · ${c.v}`)}" title="${esc(`${c.title} · ${c.v}`)}"><u></u><span>${esc(item ? vShort(c.v) : c.title)}</span></button>`).join("")}</div></div>`;
    document.body.appendChild(el);
    const unhold = modalHold(el, document.activeElement);
    const vids = [...el.querySelectorAll(".arlv")], segs = [...el.querySelectorAll(".arlc")];
    const playBtn = el.querySelector(".arlplay"), spin = el.querySelector(".arlspin");
    const durs = clips.map((c) => c.dur || 0);
    let act = 0, at = start, raf = 0, dead = false, lastSec = -1;
    const A = () => vids[act], B = () => vids[1 - act];
    vids.forEach((v) => { v._k = -1; });

    const put = (v, k) => {
      const c = clips[k];
      if (!c) { if (v._k !== -1) { v._k = -1; v.removeAttribute("src"); v.load(); } return; }
      if (v._k === k) return;
      v._k = k; v.muted = !sound() || c.audio === false; v.src = c.play; v.load();
    };
    const flip = () => { act = 1 - act; vids.forEach((v, n) => v.classList.toggle("on", n === act)); };
    const layout = () => { const ws = weights(durs); segs.forEach((s, n) => { s.style.flexGrow = String(ws[n]); }); };
    const paint = () => {
      const a = A(), ws = weights(durs), c = clips[at];
      const t = a._k === at ? a.currentTime : 0, part = ws[at] ? Math.min(1, t / ws[at]) : 0;
      segs.forEach((s, n) => { s.classList.toggle("on", n === at); s.firstChild.style.transform = `scaleX(${n < at ? 1 : n === at ? part : 0})`; });
      const sec = Math.floor(elapsed(ws, at, t));
      if (sec !== lastSec) { lastSec = sec; el.querySelector(".arltime").textContent = `${fmt(sec)} / ${fmt(ws.reduce((x, y) => x + y, 0))}`; }
      el.querySelector(".arln").textContent = `${at + 1} / ${clips.length}`;
      el.querySelector(".arlname").textContent = `${c.title} · ${c.v}`;
    };
    const icon = () => { const on = !A().paused; playBtn.innerHTML = ic(on ? "pause" : "play"); playBtn.setAttribute("aria-label", on ? tl("showPlay.1") : tl("itemView.39")); };
    const loop = () => { paint(); raf = A().paused ? 0 : requestAnimationFrame(loop); };
    const run = () => { if (!raf && !dead) raf = requestAnimationFrame(loop); };

    // Jump: the clip goes into the element on screen (or the other one, when it already holds it).
    const show = (k, play) => {
      at = Math.max(0, Math.min(clips.length - 1, k));
      if (B()._k === at && A()._k !== at) { A().pause(); flip(); }
      put(A(), at);
      try { A().currentTime = 0; } catch (e) { /* not loaded yet: it starts at 0 anyway */ }
      B().pause(); put(B(), at + 1);
      lastSec = -1; paint(); icon();
      if (play) playNow(A());
      segs[at].scrollIntoView?.({block: "nearest", inline: "nearest"});
    };
    // The cut: the waiting element starts, and takes the screen once it shows a frame, so the last
    // frame of the clip that ended stays up until then (no black between shots).
    const next = () => {
      if (at + 1 >= clips.length) { icon(); paint(); return; }
      at += 1;
      const b = B(); put(b, at);
      try { b.currentTime = 0; } catch (e) { /* fresh element */ }
      const take = () => { if (dead || b !== B()) return; flip(); put(B(), at + 1); lastSec = -1; paint(); icon(); run(); };
      playNow(b);
      if (b.readyState >= 2) take(); else b.addEventListener("playing", take, {once: true});
    };
    vids.forEach((v) => {
      v.addEventListener("ended", () => { if (v === A()) next(); });
      v.addEventListener("loadedmetadata", () => { if (v._k >= 0 && !durs[v._k] && v.duration > 0 && Number.isFinite(v.duration)) { durs[v._k] = v.duration; layout(); paint(); } });
      v.addEventListener("play", () => { if (v === A()) { icon(); run(); } });
      v.addEventListener("pause", () => { if (v === A()) icon(); });
      v.addEventListener("waiting", () => { if (v === A()) spin.hidden = false; });
      ["playing", "canplay"].forEach((ev) => v.addEventListener(ev, () => { if (v === A()) spin.hidden = true; }));
    });
    // Lengths the push did not record: read from each file's header, two at a time (no download of
    // the picture, nothing re-encoded), so the segments settle to their real widths.
    const probe = () => {
      const todo = durs.map((d, n) => (d ? -1 : n)).filter((n) => n >= 0);
      const one = () => { const n = todo.shift(); if (n === undefined || dead) return;
        if (durs[n]) return one();
        const v = document.createElement("video"); v.preload = "metadata"; v.muted = true;
        const done = () => { v.removeAttribute("src"); v.load(); one(); };
        v.addEventListener("loadedmetadata", () => { if (v.duration > 0 && Number.isFinite(v.duration)) { durs[n] = v.duration; layout(); paint(); } done(); }, {once: true});
        v.addEventListener("error", done, {once: true});
        v.src = clips[n].play; };
      one(); one();
    };

    const toggle = () => { const a = A();
      if (!a.paused) return a.pause();
      if (at === clips.length - 1 && a.ended) return show(0, true);
      playNow(a); };
    playBtn.onclick = toggle;
    segs.forEach((s) => { s.onclick = () => show(+s.dataset.arlc, true); });
    el.querySelectorAll("[data-arlm]").forEach((b) => b.onclick = () => {
      const want = b.dataset.arlm === "item", c = clips[at];
      if (want === !!item) return;
      close("swap"); open(p, want ? c.id : null, c.id);
    });
    const key = (e) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      // Everything under the reel waits while it is up: its keys are the reel's.
      e.stopImmediatePropagation();
      if (e.key === "Escape") { e.preventDefault(); close(); }
      else if (e.key === " ") { e.preventDefault(); toggle(); }        // a focused button still takes Enter
      else if (e.key === "ArrowRight" || e.key === "ArrowLeft") { e.preventDefault(); show(at + (e.key === "ArrowRight" ? 1 : -1), !A().paused); }
    };
    const pop = () => close(true);
    function close(popped) {
      if (dead) return; dead = true; shut = null;
      cancelAnimationFrame(raf); removeEventListener("keydown", key, true); removeEventListener("popstate", pop);
      // A switch of mode keeps the history entry: the next reel stands on it.
      if (popped !== true && popped !== "swap" && history.state?.arl) history.back();
      vids.forEach((v) => { v.pause(); v.removeAttribute("src"); v.load(); });
      unhold();
      if (RM()) return el.remove();
      el.classList.add("out"); setTimeout(() => el.remove(), 220);
    }
    shut = close;
    el.querySelector("[data-arlx]").onclick = () => close();
    addEventListener("keydown", key, true);
    try { if (!history.state?.arl) history.pushState({arl: 1}, ""); addEventListener("popstate", pop); } catch (e) { /* no history: the X closes */ }
    layout(); show(start, true); probe();
    requestAnimationFrame(() => el.classList.add("in"));
    el.querySelector("[data-arlx]").focus({preventScroll: true});
  }

  // The project page's button: only where something was approved at all (approved_reel.py says which play).
  const btn = (g) => (g.items || []).some((x) => x.status === "approved" || x.approved_v)
    ? `<button class="btn sm weak press arlgo" data-areel="${esc(g.name)}" aria-label="${esc(tl("areel.t"))}" title="${esc(tl("areel.go.h"))}">${ic("play")}<span>${tl("areel.go")}</span></button>` : "";
  // The item page's chip: two or more versions with a video.
  const chip = (p, d) => (d.versions || []).filter((w) => (w.files || []).some((f) => f.kind === "video")).length > 1
    ? `<button class="ichip press" data-areel="${esc(p)}" data-areel-i="${esc(d.id)}" title="${esc(tl("areel.item.h"))}">${ic("play", "i")}<span>${tl("areel.item")}</span></button>` : "";
  document.addEventListener("click", (e) => {
    const b = e.target.closest?.("[data-areel]"); if (!b) return;
    e.preventDefault(); open(b.dataset.areel, b.dataset.areelI || null, b.dataset.areelI || null);
  });
  window.ApprovedReel = {open, btn, chip};
})();
