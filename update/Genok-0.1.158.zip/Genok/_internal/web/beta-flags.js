// 설정 → 베타 switches (beta_flags.py, docs/beta-flags.md): genokBeta("qc") says whether a feature in
// trial is on. The server writes the switches into /i18n.js (window.LOOP_BETA), the page's first
// script, so they are known before any feature script runs: one that is off returns at its top and
// never draws. A switch flipped on the settings page takes effect on the reload that follows.
(function () {
  "use strict";
  const on = window.LOOP_BETA || {};
  window.genokBeta = (key) => on[key] === true;
  // A style that would also restyle something already there is scoped to html.beta-<key>.
  const root = window.document?.documentElement;
  if (root) Object.keys(on).forEach((k) => { if (on[k] === true) root.classList.add("beta-" + k); });
})();
