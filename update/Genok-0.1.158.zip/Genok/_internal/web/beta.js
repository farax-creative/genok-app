// 설정 → 베타: features to try before they ship to everyone. The theme: the new glass design is LAB3
// in v2.js (localStorage "genok-lab"), on unless "0" is stored. Below it one row per feature switch
// (beta_flags.py, GET/POST /api/beta), all off until turned on here; web/beta-flags.js answers
// genokBeta(key) for the feature scripts.
// Its own small file + one LOOP_SETTINGS entry. Uses v2.js globals: tl, setRow, post, toast, setReload.
// Both read once at start, so a switch is saved and shown at once and the app reloads a single time
// when settings is left, however many were flipped.
(function () {
  "use strict";

  const now = () => { try { return localStorage.getItem("genok-lab") === "0" ? "0" : "3"; } catch (e) { return "3"; } };

  // [key, title, what it does]. Literal tl() calls so tests/test_i18n.py can see each key.
  const NAMES = () => ({
    qc: [tl("beta.f.qc"), tl("beta.f.qc.s")],
    stream: [tl("beta.f.stream"), tl("beta.f.stream.s")],
    edit: [tl("beta.f.edit"), tl("beta.f.edit.s")],
    vdiff: [tl("beta.f.vdiff"), tl("beta.f.vdiff.s")],
    pai: [tl("beta.f.pai"), tl("beta.f.pai.s")],
    board: [tl("beta.f.board"), tl("beta.f.board.s")],
    fv: [tl("beta.f.fv"), tl("beta.f.fv.s")],
  });

  function featureRows(list) {
    const names = NAMES();
    return list.filter((f) => names[f.key]).map((f) => {
      const [t, s] = names[f.key];
      const opt = (on, label) => `<button class="press ${f.on === on ? "on" : ""}" data-bf="${f.key}" data-on="${on ? 1 : 0}" aria-pressed="${f.on === on}">${label}</button>`;
      return setRow(t, s, `<div class="seg" role="group" aria-label="${t}">${opt(true, tl("beta.on"))}${opt(false, tl("beta.off"))}</div>`);
    }).join("");
  }

  function picked(b, attr) {
    b.closest(".seg").querySelectorAll(`[${attr}]`).forEach((o) => { o.classList.toggle("on", o === b); o.setAttribute("aria-pressed", String(o === b)); });
    if (!setReload) toast(tl("beta.later"));
    setReload = true;
  }

  async function draw(c) {
    const cur = now();
    const opt = (v, t) => `<button class="press ${cur === v ? "on" : ""}" data-beta="${v}" aria-pressed="${cur === v}">${t}</button>`;
    c.innerHTML = `<h2 class="seth">${tl("beta.title")}</h2>
      <p class="setd">${tl("beta.desc")}</p>
      ${setRow(tl("beta.theme"), tl("beta.theme.new.s"), `<div class="seg" role="group" aria-label="${tl("beta.theme")}">${opt("3", tl("beta.theme.new"))}${opt("0", tl("beta.theme.base"))}</div>`)}
      <div data-bfs></div>`;
    c.querySelectorAll("[data-beta]").forEach((b) => { b.onclick = () => {
      if (b.dataset.beta === now()) return;
      try { localStorage.setItem("genok-lab", b.dataset.beta); } catch (e) { return; }
      picked(b, "data-beta");
    }; });
    let got;
    try { got = await fetch("/api/beta").then((r) => r.json()); } catch (e) { return; }
    const box = c.querySelector("[data-bfs]");
    if (!box || !Array.isArray(got?.features)) return;
    box.innerHTML = featureRows(got.features);
    box.querySelectorAll("[data-bf]").forEach((b) => { b.onclick = async () => {
      if (b.getAttribute("aria-pressed") === "true") return;
      try { await post("/api/beta", {key: b.dataset.bf, on: b.dataset.on === "1"}); }
      catch (err) { toast(err.message); return; }
      picked(b, "data-bf");
    }; });
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "beta", icon: "star", title: "beta.title", draw, featureRows});
})();
