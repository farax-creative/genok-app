// 설정 → 베타 "board": what ties the rest of the app to the board (web/boardview.js).
// Any element with data-bdloc="<project>/<item>" (and data-bdv="<version>", else the version picked
// on the item screen, else the newest) shows that card on the board when pressed: the item screen's
// header button, a result card's last segment.
// While one project's board is up, a version that lands in another project says so with 보기, which
// shows it on the board (the all-projects board places new cards itself: web/boardview.js fill).
// A result row in a chat (data-bdhl) outlines its card while pointed at, and when the board on screen
// has that card a press shows it there instead of opening the item.
(function () {
  "use strict";
  if (!window.genokBeta?.("board") || !window.BoardView) return;

  const where = (el) => { const k = el.dataset.bdloc, at = k.indexOf("/");
    return {p: k.slice(0, at), i: k.slice(at + 1), v: el.dataset.bdv || verPick[k] || ""}; };

  // Capture, so a card's own press (open the item) never runs under the button.
  document.addEventListener("click", (e) => {
    const el = e.target.closest?.("[data-bdloc]"); if (!el) return;
    e.preventDefault(); e.stopPropagation();
    const {p, i, v} = where(el);
    BoardView.focus(p, i, v);
  }, true);
  document.addEventListener("click", (e) => {
    const el = e.target.closest?.("[data-bdhl]"); if (!el || !BoardView.shows(el.dataset.bdhl, el.dataset.bdv)) return;
    e.preventDefault(); e.stopPropagation();
    const k = el.dataset.bdhl, at = k.indexOf("/");
    BoardView.focus(k.slice(0, at), k.slice(at + 1), el.dataset.bdv);
  }, true);
  const point = (on) => (e) => { const el = e.target.closest?.("[data-bdhl]");
    if (el && !el.contains(e.relatedTarget)) BoardView.hl(el.dataset.bdhl, el.dataset.bdv, on); };
  document.addEventListener("pointerover", point(true));
  document.addEventListener("pointerout", point(false));

  // The items list is replaced, never edited, when the app hears of a change: a new array is the cue.
  let list = null, had = null;
  setInterval(() => {
    if (D.items === list) return;
    list = D.items;
    const now = new Map(list.map((x) => [iid(x), x.v])), was = had;
    had = now;
    const on = BoardView.onScreen();
    if (!was || !on || on === "*") return;
    const come = list.filter((x) => was.get(iid(x)) !== x.v && gname(x) !== on && !libHide.has(iid(x)));
    if (!come.length) return;
    const x = come[0];
    toastAct(come.length === 1 ? tl("board.arr", {p: pname(gname(x)), v: vShort(x.v)}) : tl("board.arr.n", {n: come.length}),
      tl("board.see"), () => BoardView.focus(x.project, x.id, x.v), 8000);
  }, 1500);
})();
