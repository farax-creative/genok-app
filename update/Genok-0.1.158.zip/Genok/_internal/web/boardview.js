// The board view of results: one project's (deptView in v2.js, "목록 | 보드") or every project's
// (the 보드 tab of 결과물, SCREENS.board in v2.js).
//
// Every item is a row of version cards joined by lines; a line carries how many directives the
// next version answered, and an item with open directives ends in a dashed "next" card. A card
// opens its detail in place: the result itself (the picture, the video, the page), why that
// version was made and, on the newest one, a comment that
// goes to the session exactly as a comment on the item page does (POST /api/comment, sendNow).
//
// Data: GET /api/boardview?p=<project> (boardview.py), asked again only when the items on screen change.
// Nothing about the board is stored on the server: a card dragged somewhere keeps its place in
// this browser ("v2-bdpos", per project screen), and 정렬 puts every card back on the grid.
// With 설정 → 베타 "board" on the places are also kept by the app (boardpos.py, /api/boardpos), so
// another window or the phone opens the board as it was left; the browser's copy stays the fallback.
// A phone opens the same data as version rows ("v2-bdmode" remembers the pick per device).
//
// Camera: the board follows the pointer 1:1, a release keeps its speed, buttons spring, and
// anything in flight can be grabbed. With reduced motion every move lands at once.
// Pure parts (layout, snap, bounds, fit) are tested in tests/boardview.test.js.
(function () {
  "use strict";
  const CW = 208, CH = 150, GX = 104, GY = 36, NEXT_W = 148, NEXT_H = 56, TOL = 8, ZMAX = 4, SHARP = 1.3;
  const nid = (it, v) => `${it.project}/${it.id}/${v}`;

  // items: [{project, id, title, versions: [{v, why, ...}], open: [text]}]; saved: {id: [x, y]} or,
  // kept with the switch on, {id: [x, y, dy]}: dy is the height above or below the top of the card's
  // own row (n.lane). With opts a card with a dy goes with its row when the rows reorder (the
  // newest item comes first), so a card placed by hand stays beside its own item's cards.
  // opts: true (the "board" beta), or (web/board-select.js) group(it) -> {key, title, rank} puts the
  // rows into frames, ratio (view width / height) picks bands or lanes for them, extra adds the
  // board's own cards ({id, type, w, h, x?, y?}: notes, 묶음, shortcuts, asks).
  function layout(items, saved, opts) {
    if (opts && typeof opts === "object") return framed(items, saved, opts);
    const nodes = [], links = [];
    items.forEach((it, row) => rowOf(it, 0, row * (CH + GY), saved, nodes, links, !!opts));
    return {nodes, links};
  }
  function rowOf(it, x0, y0, saved, nodes, links, lanes) {
    let prev = null;
    it.versions.forEach((v, i) => {
      const id = nid(it, v.v), at = saved && saved[id];
      const n = {id, type: "ver", it, v, last: i === it.versions.length - 1, w: CW, h: CH, lane: y0,
        x: at ? at[0] : x0 + i * (CW + GX), y: at ? (lanes && at.length > 2 ? y0 + at[2] : at[1]) : y0};
      nodes.push(n);
      if (prev) links.push({a: prev, b: n, n: (v.why || []).length});
      prev = n;
    });
    if (prev && it.open && it.open.length) {
      const g = {id: nid(it, "next"), type: "next", it, of: prev, w: NEXT_W, h: NEXT_H, x: 0, y: 0};
      follow(g); nodes.push(g); links.push({a: prev, b: g, next: true, n: 0});
    }
  }
  const rowW = (it) => it.versions.length * (CW + GX) - GX + (it.open && it.open.length ? GX + NEXT_W : 0);

  // Frames: rows grouped (by project, or by where they stand), each group in a titled box. Stacked
  // as bands or side by side as lanes, whichever whole is nearer the view's shape. A card keeps a
  // place it was moved to, held inside its own frame.
  const FH = 44, FP = 20, FG = 56;
  function framed(items, saved, {group, ratio, extra}) {
    const nodes = [], links = [], frames = [];
    if (group) {
      const by = new Map();
      items.forEach((it) => { const g = group(it); if (!by.has(g.key)) by.set(g.key, {...g, items: []}); by.get(g.key).items.push(it); });
      [...by.values()].sort((a, b) => a.rank - b.rank).forEach((g) => {
        const w = Math.max(CW, ...g.items.map(rowW)) + 2 * FP, h = FH + g.items.length * (CH + GY) - GY + FP;
        frames.push({id: "frame/" + g.key, type: "frame", key: g.key, title: g.title, items: g.items, w, h, x: 0, y: 0,
          n: g.items.reduce((s, it) => s + (it.open ? it.open.length : 0), 0),
          at: g.items.map((it) => it.versions[it.versions.length - 1].at || "").sort().pop() || ""});
      });
      const span = (f, i) => frames.slice(0, i).reduce((s, o) => s + o[f] + FG, 0);
      const W = [Math.max(...frames.map((f) => f.w)), frames.reduce((s, f) => s + f.w + FG, -FG)];
      const H = [frames.reduce((s, f) => s + f.h + FG, -FG), Math.max(...frames.map((f) => f.h))];
      const off = (k) => Math.abs(Math.log(W[k] / H[k] / (ratio || 1.6)));
      const lanes = frames.length > 1 && off(1) < off(0);
      frames.forEach((f, i) => {
        if (lanes) { f.x = span("w", i); f.h = H[1]; } else { f.y = span("h", i); f.w = W[0]; }
        f.box = {x: f.x + FP, y: f.y + FH, w: f.w - 2 * FP, h: f.h - FH - FP};
        nodes.push(f);
        const from = nodes.length;
        f.items.forEach((it, r) => rowOf(it, f.box.x, f.box.y + r * (CH + GY), saved, nodes, links, true));
        nodes.slice(from).forEach((n) => { n.frame = f; if (n.type === "ver") Object.assign(n, inBox(n, f.box)); });
        nodes.slice(from).forEach((n) => { if (n.of) follow(n); });
      });
      frames.mode = lanes ? "lanes" : "bands";
    } else items.forEach((it, row) => rowOf(it, 0, row * (CH + GY), saved, nodes, links, true));
    // The board's own cards keep the place they were left at, moved clear of the result cards when
    // those have grown into it (new versions, frames turned on or off); a new one goes in a column
    // right of the rest. The place kept on the server stays as it was.
    const b = bounds(nodes), busy = nodes.filter((n) => n.type === "ver" || n.type === "next"); let y = b.y;
    (extra || []).forEach((e) => {
      const n = {...e};
      if (n.x == null) { n.x = b.x + b.w + GX; n.y = y; y += n.h + GY; }
      Object.assign(n, clear(n, busy));
      busy.push(n); nodes.push(n);
    });
    return {nodes, links, mode: frames.mode || null};
  }
  const hits = (n, o, gap) => n.x < o.x + o.w + gap && n.x + n.w + gap > o.x && n.y < o.y + o.h + gap && n.y + n.h + gap > o.y;
  // The nearest place to a card's own where it covers none of `busy` (it stays put when it covers none).
  function clear(n, busy) {
    if (!busy.some((o) => hits(n, o, 0))) return {x: n.x, y: n.y};
    for (let r = 1; r <= 40; r++)
      for (let i = 0; i < 8 * r; i++) {
        const a = (i / (8 * r)) * 2 * Math.PI, c = {x: Math.round(n.x + Math.cos(a) * r * 24), y: Math.round(n.y + Math.sin(a) * r * 24), w: n.w, h: n.h};
        if (!busy.some((o) => hits(c, o, 12))) return {x: c.x, y: c.y};
      }
    return {x: n.x, y: n.y};
  }
  // A card held inside a box: as near to where it is as the box lets it be.
  const inBox = (n, box) => ({x: Math.max(box.x, Math.min(n.x, box.x + box.w - n.w)), y: Math.max(box.y, Math.min(n.y, box.y + box.h - n.h))});
  // The "next" card has no place of its own: it stays beside the newest version.
  function follow(g) { g.x = g.of.x + g.of.w + GX; g.y = g.of.y + (g.of.h - g.h) / 2; }

  // A dragged card lines up with another's edge or middle, or sits one gap beside it, when within
  // tol. {x, y, gx, gy}: where it lands and the guide lines to show (null: none on that axis).
  // box (optional): the frame the card stays inside.
  function snap(n, others, tol, box) {
    let x = n.x, y = n.y, gx = null, gy = null, bx = tol, by = tol;
    for (const o of others) {
      for (const f of [0, .5, 1]) {
        const dx = o.x + o.w * f - (n.x + n.w * f), dy = o.y + o.h * f - (n.y + n.h * f);
        if (Math.abs(dx) < bx) { bx = Math.abs(dx); x = n.x + dx; gx = o.x + o.w * f; }
        if (Math.abs(dy) < by) { by = Math.abs(dy); y = n.y + dy; gy = o.y + o.h * f; }
      }
      for (const dx of [o.x + o.w + GX - n.x, o.x - GX - n.w - n.x]) if (Math.abs(dx) < bx) { bx = Math.abs(dx); x = n.x + dx; gx = null; }
    }
    if (box) ({x, y} = inBox({x, y, w: n.w, h: n.h}, box));
    return {x, y, gx, gy};
  }

  // Whether result cards dropped on a target are taken: {ok, reason}. The target's `holds` lists
  // the version ids already in it (a 묶음's slot, a note's links, a card's links). A frame is cut by
  // status, so nothing is put in one by hand; a card is not linked to its own item. A note let go
  // on a result card is linked to it, as the card let go on the note would be.
  function admit(target, cards) {
    const holds = target.holds || [];
    if (cards.length === 1 && cards[0].type === "note" && target.type === "ver") return (cards[0].holds || []).includes(target.id) ? {ok: false, reason: "linked"} : {ok: true, reason: null};
    if (!cards.length || cards.some((c) => c.type !== "ver")) return {ok: false, reason: "kind"};
    if (target.type === "frame") return {ok: false, reason: "frame"};
    if (!["group", "note", "ver"].includes(target.type)) return {ok: false, reason: "kind"};
    if (target.type === "ver" && cards.some((c) => c.it.project === target.it.project && c.it.id === target.it.id)) return {ok: false, reason: "same"};
    if (cards.every((c) => holds.includes(c.id))) return {ok: false, reason: target.type === "group" ? "dup" : "linked"};
    return {ok: true, reason: null};
  }
  function bounds(nodes) {
    let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
    nodes.forEach((n) => { a = Math.min(a, n.x); b = Math.min(b, n.y); c = Math.max(c, n.x + n.w); d = Math.max(d, n.y + n.h); });
    return nodes.length ? {x: a, y: b, w: c - a, h: d - b} : {x: 0, y: 0, w: 1, h: 1};
  }
  // The camera that shows the board: fitted to the width and never enlarged; one too wide to read
  // when whole (a phone) opens at its top-left at a readable size and is panned from there.
  // foot: the height a band lies over at the bottom of the view (the 릴), kept clear as padding.
  // kmin (맞춤 with the switch on): the height is fitted too, down to that scale, as zoom-to-fit does.
  const PAD = {l: 24, r: 24, t: 56, b: 24}, READ = .62;
  function fit(b, vw, vh, foot = 0, kmin) {
    const fw = vw - PAD.l - PAD.r, fh = vh - PAD.t - PAD.b - foot, kw = Math.min(1, fw / b.w);
    if (kw < READ) return {k: READ, x: PAD.l - b.x * READ, y: PAD.t - b.y * READ};
    const k = kmin ? Math.max(kmin, Math.min(kw, fh / b.h)) : kw;
    return {k, x: PAD.l + (fw - b.w * k) / 2 - b.x * k, y: PAD.t + Math.max(0, (fh - b.h * k) / 2) - b.y * k};
  }

  // The minimap draws the board's bounds b into a w×h box 6px in; mapTo turns a point on it back into
  // the camera that centres that board point, at scale k, in a vw×vh view (a press or a drag there).
  function mapXf(b, w = 120, h = 72) { const s = Math.min(w / b.w, h / b.h); return {s, ox: 6 - b.x * s, oy: 6 - b.y * s}; }
  function mapTo(f, px, py, vw, vh, k) { const wx = (px - f.ox) / f.s, wy = (py - f.oy) / f.s; return {k, x: vw / 2 - wx * k, y: vh / 2 - wy * k}; }

  // A free place for card r ({x, y, w, h}): from r's spot rightward along the row in grid steps,
  // then row by row below it, the first that clears every card in others by margin.
  const roomAt = (r, x, y, others, margin) => !others.some((o) => x < o.x + o.w + margin && x + r.w + margin > o.x && y < o.y + o.h + margin && y + r.h + margin > o.y);
  function freeSlot(r, others, margin = 16) {
    for (let row = 0; row < 64; row++) for (let col = 0; col < 12; col++) {
      const x = r.x + col * (CW + GX), y = r.y + row * (CH + GY);
      if (roomAt(r, x, y, others, margin)) return {x, y};
    }
    return {x: r.x, y: r.y};
  }
  // On a board arranged by hand (saved), cards with no place of their own (layout put them on the
  // grid) must not land on top of moved ones, and an item's versions still read left to right. Such
  // a card keeps its grid spot, or sits right of its previous version when that one was pushed
  // along, and steps right along its row past any moved card. None of that is kept: every draw
  // works it out again, so a row closes up when the moved card leaves it.
  // A card new since the board was last drawn (fresh: a Set of ids, or null) whose previous version
  // was placed by hand goes to the first free place beside that one instead. Only those are
  // returned: they are kept with the hand-placed card they follow, and announced with 되돌리기.
  function fill(nodes, saved, fresh) {
    const put = [];
    if (!saved || !Object.keys(saved).length) return put;
    const vers = nodes.filter((n) => n.type === "ver"), fixed = vers.filter((n) => saved[n.id]), later = [];
    let prev = null;
    vers.forEach((n) => {
      const p = prev && prev.it === n.it ? prev : null; prev = n;
      if (saved[n.id]) return;
      if (p && saved[p.id] && fresh && fresh.has(n.id)) return later.push([n, p]);
      if (p && !saved[p.id] && n.x < p.x + p.w + GX) n.x = p.x + p.w + GX;
      while (!roomAt(n, n.x, n.y, fixed, 0)) n.x += CW + GX;
    });
    // What a new card must keep clear of: every other card, the dashed "next" ones included.
    nodes.forEach((g) => { if (g.of) follow(g); });
    const taken = nodes.filter((n) => !later.some(([o]) => o === n || o === n.of));
    later.forEach(([n, p]) => {
      const at = freeSlot({x: p.x + p.w + GX, y: p.y, w: n.w, h: n.h}, taken);
      n.x = at.x; n.y = at.y; taken.push(n); put.push(n);
    });
    nodes.forEach((g) => { if (g.of) follow(g); });
    return put;
  }

  // The card an arrow key goes to: the nearest one whose middle lies that way (dx, dy: -1, 0 or 1)
  // from the middle of `from`, a step off to the side counting double.
  function nearest(from, nodes, dx, dy) {
    const cx = from.x + from.w / 2, cy = from.y + from.h / 2;
    let best = null, score = Infinity;
    nodes.forEach((n) => { if (n === from || n.type !== "ver") return;
      const ox = n.x + n.w / 2 - cx, oy = n.y + n.h / 2 - cy, along = ox * dx + oy * dy, off = Math.abs(dx ? oy : ox);
      if (along <= 0) return;
      const s = along + 2 * off; if (s < score) { score = s; best = n; } });
    return best;
  }

  // A short name per item to say it by ("P12"): the project's first letter and the item's place
  // among that project's items by when its first version came (oldest is 1). {"project/id": "P12"}.
  // Projects on the same board that start alike get as many letters as tell them apart ("Po12",
  // "Pi12"), and a dot when those end in a digit, so no two items share a name.
  function shortIds(items) {
    const by = {}, out = {};
    items.forEach((it) => (by[it.project] = by[it.project] || []).push(it));
    const names = Object.keys(by), low = (p) => [...p.toLowerCase()];
    const tag = (p) => {
      const a = low(p), alike = (k) => names.some((q) => q !== p && low(q).slice(0, k).join("") === a.slice(0, k).join(""));
      let k = 1; while (k < a.length && alike(k)) k++;
      const s = [...p].slice(0, k); s[0] = s[0].toUpperCase();
      return s.join("") + (k > 1 && /\d$/.test(s[k - 1]) ? "·" : "");
    };
    Object.entries(by).forEach(([p, its]) => {
      const first = (it) => (it.versions[0] && it.versions[0].at) || "", t = tag(p);
      its.slice().sort((a, b) => first(a).localeCompare(first(b)) || a.id.localeCompare(b.id))
        .forEach((it, i) => { out[`${p}/${it.id}`] = t + (i + 1); });
    });
    return out;
  }

  // A deep copy of the saved places, taken before something rearranges the board, so 되돌리기 can put
  // every card back exactly where it was (layout(items, copy) gives those places again).
  const snapshot = (saved) => JSON.parse(JSON.stringify(saved || {}));


  // A line from card a to card b (the "board" beta's links, notes and asks): out of the sides that
  // face each other, so a target left of or below its source is not reached by a loop through cards.
  function wire(a, b) {
    const side = b.x >= a.x + a.w ? "r" : b.x + b.w <= a.x ? "l" : b.y >= a.y + a.h ? "b" : "t";
    const out = {r: [1, 0], l: [-1, 0], b: [0, 1], t: [0, -1]}[side];
    const at = (n, d) => [n.x + n.w / 2 + d[0] * n.w / 2, n.y + n.h / 2 + d[1] * n.h / 2];
    const [x1, y1] = at(a, out), [x2, y2] = at(b, [-out[0], -out[1]]);
    const c = Math.max(32, (out[0] ? Math.abs(x2 - x1) : Math.abs(y2 - y1)) / 2);
    return `M${x1},${y1} C${x1 + out[0] * c},${y1 + out[1] * c} ${x2 - out[0] * c},${y2 - out[1] * c} ${x2},${y2}`;
  }

  // 시간순 (the "board" beta): every version on one time axis, oldest at the left, in a lane per
  // project; past `max` projects the quietest share one 기타 lane (name null). A card keeps a
  // place it was dragged to. {nodes, links, lanes: [{name, y}]}.
  function layoutByTime(items, saved, max = 6) {
    const all = items.flatMap((it) => it.versions.map((v, i) => ({it, v, i})));
    all.sort((a, b) => String(a.v.at || "").localeCompare(String(b.v.at || "")));
    const newest = {};
    all.forEach(({it, v}) => { newest[it.project] = String(v.at || ""); });
    const order = Object.keys(newest).sort((a, b) => newest[b].localeCompare(newest[a]));
    const named = order.length > max ? max - 1 : order.length;
    const lanes = order.slice(0, named).map((name, i) => ({name, y: i * (CH + GY)}));
    if (order.length > named) lanes.push({name: null, y: named * (CH + GY)});
    const nodes = [], links = [], prev = new Map();
    all.forEach(({it, v, i}, rank) => {
      const id = nid(it, v.v), at = saved && saved[id], lane = Math.min(order.indexOf(it.project), named);
      const n = {id, type: "ver", it, v, last: i === it.versions.length - 1, w: CW, h: CH,
        x: at ? at[0] : rank * (CW + GY), y: at ? at[1] : lane * (CH + GY)};
      nodes.push(n);
      const p = prev.get(it); if (p) links.push({a: p, b: n, n: (v.why || []).length});
      prev.set(it, n);
    });
    return {nodes, links, lanes};
  }

  // 설정 → 베타 "board": the board's additions (web/board-select.js, web/board-cards.js) draw only while it is on.
  const bdOn = () => typeof window !== "undefined" && window.genokBeta?.("board") === true;
  const api = {CW, CH, GX, GY, FH, FP, layout, layoutByTime, snap, bounds, fit, snapshot, mapXf, mapTo, freeSlot, fill, nearest, shortIds, admit, wire, beta: bdOn};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;

  const calm = () => matchMedia("(prefers-reduced-motion:reduce)").matches;
  // 설정 → 베타 "board": the board's new controls. Off, the board is exactly as it was before them.
  const beta = () => !!window.genokBeta?.("board");
  const BC = () => (bdOn() && window.BoardCards) || null;   // the beta's card parts (web/board-cards.js)
  const small = () => matchMedia("(max-width:720px)").matches;
  // 접기 and 시간순 exist only while the "board" beta is on (web/board-spread.js sets api.ext); a
  // pick left over from it reads as the default again.
  const modes = () => api.ext ? ["board", "rail", "fold", "time"] : ["board", "rail"];
  const mode = (v) => { try { if (v === undefined) { const s = localStorage.getItem("v2-bdmode"); return modes().includes(s) ? s : small() ? "rail" : "board"; } localStorage.setItem("v2-bdmode", v); } catch { return "board"; } };
  const pinned = (v) => { try { if (v === undefined) return localStorage.getItem("v2-bdmini") === "1"; localStorage.setItem("v2-bdmini", v ? "1" : "0"); } catch { return false; } };
  const lines = (v) => { try { if (v === undefined) return localStorage.getItem("v2-bdedges") !== "0"; localStorage.setItem("v2-bdedges", v ? "1" : "0"); } catch { return true; } };
  const stored = () => { try { return JSON.parse(localStorage.getItem("v2-bdpos") || "{}"); } catch { return {}; } };
  let srv = null;           // the app's copy of the places (beta "board"), read once per page
  const places = () => (srv && beta() ? {...stored(), ...srv} : stored());
  const sending = {};       // a screen's places go to the app a moment after the last move
  const keep = (key, m) => {
    try { const a = stored(); if (m && Object.keys(m).length) a[key] = m; else delete a[key]; localStorage.setItem("v2-bdpos", JSON.stringify(a)); } catch { /* this page only */ }
    if (!srv || !beta()) return;
    if (m && Object.keys(m).length) srv[key] = snapshot(m); else delete srv[key];
    clearTimeout(sending[key]);
    sending[key] = setTimeout(() => post("/api/boardpos", {key, pos: srv[key] || {}}).catch(() => {}), 400);
  };

  const mem = {};           // per project screen: {data, sig, cam, sel, draft}
  let pend = null;          // a card asked for (focus) before its board was drawn: {k: "project/id", v, t}
  const asked = () => { const p = pend; if (!p || Date.now() - p.t > 8000) return null; return p; };
  let raf = 0, live = null; // the running animation and the board on screen
  let zt = null;            // a wheel zoom in flight: the scale it heads for and the screen point it holds still
  const stop = () => { cancelAnimationFrame(raf); raf = 0; zt = null; };

  const sigOf = (its) => its.map((x) => `${iid(x)}:${x.v}:${x.rev}:${x.open}:${x.comments}${BC() ? ":" + BC().sig(x) : ""}`).join("|");
  const stamp = (key, sig) => `${key}|${mode()}|${sig}` + (api.ext ? "|" + api.ext.sig(key) : "");
  // A refresh with nothing new for a board already on screen: it stays as it is, with its camera,
  // open card and half-written comment (it was rebuilt node by node on every round).
  const same = (host, key, its) => !!host && !!host.firstElementChild && host.dataset.bdsig === stamp(key, sigOf(its)) && mem[key]?.sig === sigOf(its);
  // focus (optional): the items ("project/id") drawn strong; the others are dimmed, not hidden.
  // The "board" beta (api.ext) reorders and narrows what is drawn, can draw a screen of its own
  // in place of the board, and adds its parts after; with it off this is the board as it was.
  function draw(host, key, its, focus) {
    stop(); live = null;
    const m = mem[key] || (mem[key] = {data: null, sig: "", cam: null, sel: null, draft: ""});
    const sig = sigOf(its), ex = api.ext;
    const paint = () => {
      host.dataset.bdsig = stamp(key, sig);
      const by = new Map(m.data.map((d) => [iid(d), d]));
      let items = its.map((x) => by.has(iid(x)) && {...by.get(iid(x)), sum: x}).filter((it) => it && it.versions.length);
      const again = () => { m.sig = ""; draw(host, key, its, focus); };
      if (ex) items = ex.items(key, items, m);
      if (ex && ex.paint(host, key, items, m, repaint)) return;
      (mode() === "rail" ? rail : canvas)(host, key, items, m, again, focus || (ex ? ex.focus(key, items) : null));
      if (ex) ex.after({host, key, items, m, again, redraw: repaint, mode: mode(), live});
    };
    // The same data drawn again (a filter or a view picked): no new answer is asked for.
    const repaint = () => { stop(); live = null; paint(); };
    if (m.data) paint(); else host.innerHTML = `<div class="bd-wait">${loadingHtml("", {quiet: true})}</div>`;
    if (m.sig === sig) return;
    const asked = m.asked = (m.asked || 0) + 1;   // an older answer that comes late is dropped
    const pos = beta() && !srv ? get("/api/boardpos").then((r) => { srv = r.pos || {}; }, () => { srv = {}; }) : null;
    // With the beta on, the first answer also carries this board's own cards (boardgroups.py) under k.
    Promise.all([...new Set(its.map((x) => x.project))].map((p, i) => get("/api/boardview?p=" + encodeURIComponent(p) + (!i && bdOn() ? "&k=" + encodeURIComponent(key) : ""))).concat(pos || [])).then((all) => {
      if (asked !== m.asked) return;
      const rs = all.filter(Boolean);
      m.data = rs.flatMap((r) => r.items); m.sig = sig;
      if (bdOn()) { m.links = rs.flatMap((r) => r.links || []); m.board = rs[0] && rs[0].board; }
      if (host.isConnected) paint();
    }).catch(() => { if (host.isConnected && !m.data) host.innerHTML = `<div class="card plan none"><p>${tl("board.fail")}</p></div>`; });
  }

  const thumbOf = (v) => `<div class="th">${ic((KIND[v.kind] || ["doc"])[0])}${v.thumb && !v.removed ? imgTag(v.thumb, {drag: false}) : ""}</div>`;
  // The item screen opens on the version pressed (verPick, web/v2.js); the newest needs no pick.
  const open = (it, v) => { const id = iid(it.sum); if (v && v !== it.versions[it.versions.length - 1].v) verPick[id] = v; else delete verPick[id];
    nav("item/" + encodeURIComponent(it.project) + "/" + encodeURIComponent(it.id)); };
  const swap = (host, to, again) => host.querySelectorAll("[data-bdmode]").forEach((b) => b.onclick = () => { mode(to); again(); });

  // The result itself: a picture whole, a video that plays, a page live. Empty for a removed file or a kind with no view.
  const preview = (v, title) => { const src = !v.removed && v.play; return !src ? ""
    : v.kind === "image" ? `<div class="bd-pv">${imgTag(src, {lazy: false, drag: false})}</div>`
    : v.kind === "video" ? `<div class="bd-pv"><video src="${esc(src)}"${v.thumb ? ` poster="${esc(v.thumb)}"` : ""} controls${beta() ? " loop" : ""} playsinline preload="metadata"></video></div>`
    : v.kind === "html" ? `<div class="bd-pv page"><iframe src="${esc(keyUrl(src))}" title="${esc(title)}" sandbox="allow-scripts allow-popups"></iframe></div>` : ""; };

  // ---- version rows: the same data top to bottom, the first view on a phone
  const dim = (strong, it) => strong && !strong.has(`${it.project}/${it.id}`) ? " dim" : "";
  function rail(host, key, items, m, again, strong) {
    host.innerHTML = `<div class="bd-rail"><div class="bd-rh"><button class="ib press" data-bdmode aria-label="${tl("board.asboard")}" title="${tl("board.asboard")}">${ic("stack")}</button></div>`
      + items.map((it, n) => `<section class="bd-lane${dim(strong, it)}"><h3>${esc(it.title)}</h3><div class="bd-steps">`
        + it.versions.map((v, i) => (v.why.length ? `<span class="bd-fb">${esc(v.why.join(" · "))}</span>` : "")
          + `<button class="bd-step press${i === it.versions.length - 1 ? " last" : ""}" data-bdopen="${n}" data-bdv="${esc(v.v)}">${BC() ? BC().railThumb(v, thumbOf(v)) : thumbOf(v)}${BC() ? BC().step(v, it, i === it.versions.length - 1) : ""}<span class="bd-meta"><b>${vShort(v.v)}</b><span>${esc(v.summary)}</span></span></button>`).join("")
        + (it.open.length ? (BC() ? BC().railNext(it) : `<span class="bd-fb open">${tl("board.open", {n: it.open.length})}</span>`) : "")
        + `</div></section>`).join("") + `</div>`;
    host.style.height = "";
    swap(host, "board", again);
    // A row opens its result under its own lane; a second tap folds it, a file with nothing to show goes to the item.
    host.querySelectorAll("[data-bdopen]").forEach((b) => b.onclick = () => {
      const it = items[+b.dataset.bdopen], v = it.versions.find((x) => x.v === b.dataset.bdv), was = b.classList.contains("on"), pv = preview(v, it.title);
      host.querySelectorAll(".bd-in").forEach((e) => e.remove());
      host.querySelectorAll(".bd-step.on").forEach((e) => e.classList.remove("on"));
      if (was) return;
      if (!pv) return open(it, v.v);
      b.classList.add("on");
      b.closest(".bd-lane").insertAdjacentHTML("beforeend", `<div class="bd-in">${pv}<button class="btn weak press">${vShort(v.v)} · ${tl("board.openitem")}</button></div>`);
      b.closest(".bd-lane").querySelector(".bd-in .btn").onclick = () => open(it, v.v);
    });
    const p = asked(), n = p ? items.findIndex((it) => `${it.project}/${it.id}` === p.k) : -1;
    if (n >= 0) {
      pend = null;
      const lane = host.querySelectorAll(".bd-lane")[n], steps = [...lane.querySelectorAll(".bd-step")];
      lane.scrollIntoView({block: "center", behavior: calm() ? "auto" : "smooth"});
      flash(steps.find((s) => s.dataset.bdv === p.v) || steps[steps.length - 1]);
    }
  }
  // One ring around a card that was asked for, fading out.
  const flash = (el) => { el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 1400); };

  // ---- the board
  function canvas(host, key, items, m, again, strong) {
    const b2 = beta(), zmin = b2 ? .1 : .25;
    // 접기 and 시간순 lay the cards out their own way (alt) and keep dragged places apart from the board's.
    const md = mode(), alt = md !== "board" && api.ext && api.ext.lay(key, md, host);
    // The "board" beta's additions (web/board-select.js): frames, the board's own cards, picking
    // several, drops and the lines between items. Absent while the switch is off.
    // Only on the board view itself, not on 접기 or 시간순.
    const X = !alt && window.BoardSelect && window.BoardSelect({key, items, m, again, redo: () => canvas(host, key, items, m, again, strong)});
    const pkey = X ? X.pkey : md === "board" ? key : key + "|" + md, saved = places()[pkey] || {};
    // A card's place as kept: with the switch on it also carries its height against its own row (layout).
    const spot = (n) => b2 && n.lane != null ? [Math.round(n.x), Math.round(n.y), Math.round(n.y - n.lane)] : [Math.round(n.x), Math.round(n.y)];
    const tb = ([a, i, n, k]) => `<button class="press" ${a} aria-label="${n}" title="${k ? `${n} (${k})` : n}"${k ? ` aria-keyshortcuts="${k === "−" ? "-" : k}"` : ""}>${ic(i)}</button>`;
    // With the switch on: a zoom bar (− / the scale, pressed for 100% / +), and the minimap can be kept up.
    const tools = b2 ? `<div class="bd-zoom">${tb(["data-bdzo", "minus", tl("board.zout"), "−"])}<button class="press pct num" data-bdz1 aria-label="${tl("board.z100")}" title="${tl("board.z100")} (0)">100%</button>${tb(["data-bdzi", "plus", tl("board.zin"), "+"])}</div>`
        + [["data-bdz", "fit", tl("board.fit"), "F"], ["data-bdtidy", "grid", tl("board.tidy")], [`data-bdmini aria-pressed="${pinned()}"`, "pin", tl("board.mini.pin")], [`data-bdedge aria-pressed="${!lines()}"`, "link", tl("board.edges")], ["data-bdmode", "list", tl("board.rail")]].map(tb).join("")
      : [["data-bdz", "fit", tl("board.fit")], ["data-bdtidy", "grid", tl("board.tidy")], ["data-bdmode", "list", tl("board.rail")]].map(tb).join("");
    host.innerHTML = `<div class="bd${b2 ? " b2" + (lines() ? "" : " noedge") : ""}" tabindex="0"><div class="bd-world"><svg class="bd-edges"></svg>${X ? '<svg class="bd-links"></svg>' : ""}<i class="bd-g v"></i><i class="bd-g h"></i></div>
      <div class="bd-tools">${X ? X.tools : ""}${tools}</div>
      <div class="bd-mini${b2 ? " b2" + (pinned() ? " pin" : "") : ""}" aria-hidden="true"${b2 ? ` title="${tl("board.mini")}"` : ""}></div><aside class="bd-det" aria-live="polite" inert></aside></div>`;
    const vp = host.firstElementChild, world = vp.querySelector(".bd-world"), edges = vp.querySelector(".bd-edges"), lk = vp.querySelector(".bd-links"),
      mini = vp.querySelector(".bd-mini"), det = vp.querySelector(".bd-det"), gv = vp.querySelector(".bd-g.v"), gh = vp.querySelector(".bd-g.h");
    // The phone's tab bar lies over the foot of the page: the board ends above it.
    const size = () => { host.style.height = Math.max(360, innerHeight - host.getBoundingClientRect().top - 16 - document.getElementById("tabbar").offsetHeight) + "px"; };
    size();
    const opts = X && X.opts(vp.clientWidth / vp.clientHeight);
    const {nodes, links} = alt ? alt(items, saved) : layout(items, saved, opts || b2);
    // With the switch on, cards that would land on hand-placed ones move along their row (fill); a new
    // version that follows a hand-placed card is put beside it, kept at once, and announced with
    // 되돌리기 once the board is up (`put`). The first draw has nothing new (m.seen), so opening the
    // board never moves a kept place.
    const sid = b2 ? shortIds(items) : null;
    const fresh = m.seen ? new Set(nodes.filter((n) => !m.seen.has(n.id)).map((n) => n.id)) : null;
    if (b2) m.seen = new Set(nodes.map((n) => n.id));
    const before = b2 ? snapshot(saved) : null, put = b2 && !alt ? fill(nodes, saved, fresh) : [];
    const place = (n) => { n.el.style.transform = `translate(${n.x}px,${n.y}px)`; };
    nodes.forEach((n) => {
      const d = n.el = document.createElement("div");
      if (n.type === "next") { d.className = "bd-node next"; d.textContent = tl("board.open", {n: n.it.open.length}); BC()?.next(d, n); }
      else if (n.type !== "ver") X.paint(n, d);
      else {
        d.className = "bd-node ver" + (n.last ? " last" : "") + dim(strong, n.it); d.setAttribute("role", "button"); d.tabIndex = 0; if (bdOn()) d.dataset.bdid = n.id;
        d.innerHTML = `${thumbOf(n.v)}${sid ? `<span class="bd-sid num">${esc(sid[`${n.it.project}/${n.it.id}`])}/${vShort(n.v.v)}</span>` : ""}<span class="bd-meta"><b><span>${esc(n.it.title)}</span><em>${vShort(n.v.v)}</em></b><span>${esc(n.v.summary)}</span></span>`;
        BC()?.card(d, n, key);
        // A video plays under the pointer, silent and looping, and leaves with it.
        if (n.v.kind === "video" && n.v.play && !n.v.removed) {
          d.onpointerenter = (e) => { if (e.pointerType !== "mouse" || d.querySelector("video")) return;
            if (b2) world.querySelectorAll(".th video").forEach((x) => x.remove());   // one playing at a time
            d.querySelector(".th").insertAdjacentHTML("beforeend", `<video src="${esc(n.v.play)}" muted loop playsinline autoplay></video>`); };
          d.onpointerleave = () => d.querySelector("video")?.remove();
        }
      }
      if (X && n.type === "ver") X.paint(n, d);
      // A frame lies under the lines and the cards.
      d.style.width = n.w + "px"; d.style.height = n.h + "px"; if (n.type === "frame") world.prepend(d); else world.appendChild(d); place(n);
    });
    const chips = links.map((l) => { if (BC()) { const c = BC().chip(l, nodes); if (c) world.appendChild(c); return c; }
      if (!l.n) return null; const c = document.createElement("span"); c.className = "bd-chip"; c.textContent = tl("board.fixed", {n: l.n}); world.appendChild(c); return c; });
    // The 릴 band (web/board-spread.js) lies over the foot of the view: what it covers is not free view.
    const foot = () => { const r = vp.querySelector(".bd-reel"); return r && r.offsetParent ? vp.clientHeight - r.offsetTop : 0; };
    const cam = m.cam || (m.cam = fit(bounds(nodes), vp.clientWidth, vp.clientHeight, foot()));
    // A line's curve (and its chip, set in passing).
    function curve(l, i) {
      const x1 = l.a.x + l.a.w, y1 = l.a.y + l.a.h / 2, x2 = l.b.x, y2 = l.b.y + l.b.h / 2, c = Math.max(24, Math.abs(x2 - x1) / 2);
      if (chips[i]) chips[i].style.cssText = `left:${(x1 + x2) / 2}px;top:${(y1 + y2) / 2}px`;
      return `M${x1},${y1} C${x1 + c},${y1} ${x2 - c},${y2} ${x2},${y2}`;
    }
    // With the switch on the paths are made once; a dragged card (`only`: it and what follows it)
    // redraws just its own lines, and the minimap waits for the drop.
    let paths = null;
    function wires(only) {
      if (X) lk.innerHTML = X.wires(nodes);
      if (paths) { links.forEach((l, i) => { if (!only || only.has(l.a) || only.has(l.b)) paths[i].setAttribute("d", curve(l, i)); }); if (!only) { chart(); map(); } return; }
      edges.innerHTML = links.map((l, i) => `<path${l.next ? ' class="next"' : ""} d="${curve(l, i)}"/>`).join("");
      if (b2) paths = [...edges.children];
      chart(); map();
    }
    // The map's cards are drawn when a card moves; a camera move only moves the frame over them.
    let mapT = 0, mb = null;
    function chart() {
      mb = bounds(nodes); const {s, ox, oy} = mapXf(mb);
      mini.innerHTML = nodes.map((n) => `<i style="left:${ox + n.x * s}px;top:${oy + n.y * s}px;width:${n.w * s}px;height:${n.h * s}px"></i>`).join("") + "<u></u>";
    }
    function map(byHand) {
      if (!mb) chart();
      const b = mb, {s, ox, oy} = mapXf(b);
      // The map is for finding what is off the screen: it shows while the user moves the view and for a
      // moment after, then gets out of the way of the cards under it; with every card in view it stays away.
      if (byHand) { mini.classList.add("live"); clearTimeout(mapT); mapT = setTimeout(() => mini.classList.remove("live"), 1500); }
      mini.classList.toggle("off", cam.x + b.x * cam.k >= 0 && cam.y + b.y * cam.k >= 0 && cam.x + (b.x + b.w) * cam.k <= vp.clientWidth && cam.y + (b.y + b.h) * cam.k <= vp.clientHeight);
      mini.lastChild.style.cssText = `left:${ox - cam.x / cam.k * s}px;top:${oy - cam.y / cam.k * s}px;width:${vp.clientWidth / cam.k * s}px;height:${vp.clientHeight / cam.k * s}px`;
    }
    // Zoomed in, a picture card shows the picture itself in place of its small thumbnail (asked for once).
    const sharpen = () => { if (cam.k < SHARP) return; nodes.forEach((n) => { if (n.sharp || n.type !== "ver" || n.v.kind !== "image" || !n.v.play || n.v.removed) return;
      const x = cam.x + n.x * cam.k, y = cam.y + n.y * cam.k; if (x > vp.clientWidth || y > vp.clientHeight || x + n.w * cam.k < 0 || y + n.h * cam.k < 0) return;
      n.sharp = true; const im = n.el.querySelector(".th img"); if (im) im.src = n.v.play; }); };
    const pct = vp.querySelector("[data-bdz1]");
    const apply = (byHand) => { world.style.transform = `translate(${cam.x}px,${cam.y}px) scale(${cam.k})`; map(byHand); sharpen(); BC()?.zoom(vp, cam.k);
      if (pct) { const z = Math.round(cam.k * 100) + "%"; if (pct.textContent !== z) pct.textContent = z; edges.style.setProperty("--k", cam.k); cull(); } };
    // Cards well outside the view skip their paint (content-visibility) until the view comes near.
    const cull = () => { const w = vp.clientWidth, h = vp.clientHeight, m = 160;
      nodes.forEach((n) => { const x = cam.x + n.x * cam.k, y = cam.y + n.y * cam.k, far = x > w + m || y > h + m || x + n.w * cam.k < -m || y + n.h * cam.k < -m;
        if (far !== !!n.far) { n.far = far; n.el.classList.toggle("far", far); } }); };
    // One spring for the camera and for cards going back to the grid: `step` moves everything a
    // tick toward its target and says whether it has arrived.
    function spring(parts, after) {
      stop();
      if (calm()) { parts.forEach(([o, t]) => Object.assign(o, t)); return after(); }
      const vel = parts.map(([, t]) => Object.fromEntries(Object.keys(t).map((p) => [p, 0])));
      let last = performance.now();
      const tick = (now) => {
        const dt = Math.min(.032, (now - last) / 1000); last = now; let rest = true;
        parts.forEach(([o, t], i) => { for (const p in t) {
          vel[i][p] += ((t[p] - o[p]) * 170 - vel[i][p] * 26) * dt; o[p] += vel[i][p] * dt;
          if (Math.abs(t[p] - o[p]) > (p === "k" ? .001 : .3) || Math.abs(vel[i][p]) > (p === "k" ? .01 : 4)) rest = false; } });
        if (rest) parts.forEach(([o, t]) => Object.assign(o, t));
        after(); raf = rest ? 0 : requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }
    const camTo = (t) => spring([[cam, t]], apply);
    function zoomAt(k, cx, cy) {
      k = Math.max(zmin, Math.min(ZMAX, k));
      const t = {k, x: cx - (cx - cam.x) * k / cam.k, y: cy - (cy - cam.y) * k / cam.k};
      Object.assign(cam, t); apply(true);
    }
    // The wheel: each notch moves the target, and the view eases to it around the pointer, so a
    // spin reads as one move in place of a row of jumps. A pinch on a trackpad (ctrl) is already smooth.
    function wheel(f, cx, cy, direct) {
      const k = Math.max(zmin, Math.min(ZMAX, (zt ? zt.k : cam.k) * f));
      if (direct || calm()) { stop(); return zoomAt(k, cx, cy); }
      if (zt) { zt = {k, cx, cy}; return; }
      stop(); zt = {k, cx, cy}; let last = performance.now();
      const tick = (now) => {
        const dt = Math.min(.032, (now - last) / 1000); last = now;
        const near = Math.abs(Math.log(zt.k / cam.k)) < .002, to = near ? zt.k : cam.k * Math.pow(zt.k / cam.k, 1 - Math.exp(-16 * dt));
        zoomAt(to, zt.cx, zt.cy);
        if (near) { zt = null; raf = 0; } else raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }
    function glide(vx, vy) {
      if (calm() || Math.hypot(vx, vy) < 60) return;
      let last = performance.now();
      const tick = (now) => { const dt = (now - last) / 1000; last = now; cam.x += vx * dt; cam.y += vy * dt; const f = Math.exp(-5 * dt); vx *= f; vy *= f; apply(true); raf = Math.hypot(vx, vy) > 12 ? requestAnimationFrame(tick) : 0; };
      raf = requestAnimationFrame(tick);
    }
    // Bring a picked card clear of the detail panel (beside it on a PC, above it on a phone); `only`
    // hands back the camera that would (null: it is clear already) instead of moving there.
    function reveal(n, only) {
      const w = vp.clientWidth, h = vp.clientHeight, phone = w < 600, gap = 16;
      const right = phone ? w : det.offsetLeft, bottom = phone ? det.offsetTop : h - foot();
      const x = cam.x + n.x * cam.k, y = cam.y + n.y * cam.k, nw = n.w * cam.k, nh = n.h * cam.k;
      const dx = x + nw > right - gap ? right - gap - nw - x : x < gap ? gap - x : 0, dy = y + nh > bottom - gap ? bottom - gap - nh - y : y < PAD.t ? PAD.t - y : 0;
      const t = dx || dy ? {k: cam.k, x: cam.x + dx, y: cam.y + dy} : null;
      if (only) return t;
      if (t) camTo(t);
    }

    // ---- a card's detail, and a comment on the newest version
    let cur = null;
    function hide() { det.classList.remove("on"); det.inert = true; vp.classList.remove("sel"); if (cur) cur.el.classList.remove("on"); cur = null; m.sel = null; }
    function show(n, quiet) {
      if (cur) cur.el.classList.remove("on");
      if (m.sel !== n.id) m.draft = "";
      cur = n; m.sel = n.id; n.el.classList.add("on");
      const why = n.v.why, still = n.last ? n.it.open : [];
      const list = (title, xs) => (xs.length ? `<p class="k">${title}</p><ul>${xs.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>` : "");
      // The result itself, so a look does not need the item screen: a picture whole, a video that plays, a page live.
      const pv = preview(n.v, n.it.title);
      det.classList.toggle("wide", !!pv);
      det.innerHTML = `<button class="ib press x" aria-label="${tl("ui.close")}">${ic("x")}</button>${pv}<h3>${esc(n.it.title)} · ${vShort(n.v.v)}</h3><p class="s">${esc([n.v.summary, ago(n.v.at)].filter(Boolean).join(" · "))}</p>`
        + list(tl("board.why"), why) + list(tl("board.open", {n: still.length}), still)
        + (n.last ? `<textarea placeholder="${tl("board.ph")}" aria-label="${tl("board.ph")}">${esc(m.draft)}</textarea><button class="btn fill press send">${tl("board.send")}</button>` : `<p class="s">${tl("board.newest")}</p>`)
        + `<button class="btn weak press go">${tl("board.openitem")}</button>`;
      if (X) X.detail(n, det);
      det.classList.add("on"); det.inert = false; vp.classList.add("sel");
      if (!quiet) reveal(n);
      det.querySelector(".x").onclick = () => { hide(); n.el.focus(); };
      det.querySelector(".go").onclick = () => open(n.it, n.v.v);
      BC()?.detail(det, n, again);
      if (api.ext) api.ext.shown(det, n, live);
      const ta = det.querySelector("textarea"), send = det.querySelector(".send");
      if (!ta) return;
      ta.oninput = () => { m.draft = ta.value; };
      send.onclick = async () => {
        const text = ta.value.trim(); if (!text) return ta.focus();
        send.disabled = true;
        const it = {p: n.it.project, i: n.it.id, v: n.v.v, dept: n.it.sum.dept};
        try { await post("/api/comment", {...it, text}); m.draft = ""; await sendNow(it); again(); }
        catch (e) { send.disabled = false; toast(e.message); }
      };
    }

    // ---- pointers: one finger pans or drags a card, two pinch
    const pts = new Map(); let drag = null, pinch = null;
    const local = (e) => { const r = vp.getBoundingClientRect(); return {x: e.clientX - r.left, y: e.clientY - r.top}; };
    const guide = (s) => {
      const b = bounds(nodes);
      gv.style.cssText = s && s.gx != null ? `display:block;left:${s.gx}px;top:${b.y - 40}px;height:${b.h + 80}px` : "";
      gh.style.cssText = s && s.gy != null ? `display:block;top:${s.gy}px;left:${b.x - 40}px;width:${b.w + 80}px` : "";
    };
    // With the beta, a press depends on the tool (select draws a box, the hand pans; shift draws a
    // box with either), a picked card carries the other picked ones with it, and cards let go over
    // a target are offered to it (admit) and go back to where they were.
    const atW = (p) => ({x: (p.x - cam.x) / cam.k, y: (p.y - cam.y) / cam.k});
    const within = (w, r) => w.x >= r.x && w.y >= r.y && w.x <= r.x + r.w && w.y <= r.y + r.h;
    vp.addEventListener("pointerdown", (e) => {
      // The wheel button drags the board from anywhere, a card included; the right button is not ours.
      const mid = e.pointerType === "mouse" && e.button === 1;
      if (e.target.closest(".bd-tools,.bd-det,.bd-x,[data-bdx]") || (e.pointerType === "mouse" && e.button && !mid)) return;
      if (mid) e.preventDefault();
      stop(); vp.setPointerCapture(e.pointerId); pts.set(e.pointerId, local(e));
      if (pts.size === 2) { const [a, b] = [...pts.values()]; const cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2; pinch = {d: Math.hypot(a.x - b.x, a.y - b.y) || 1, k: cam.k, wx: (cx - cam.x) / cam.k, wy: (cy - cam.y) / cam.k}; drag = null; guide(); if (X) X.box(null); return; }
      const hit = !mid && e.target.closest(X ? ".bd-node:not(.frame):not(.next)" : ".bd-node.ver"), n = hit && nodes.find((x) => x.el === hit), p = local(e);
      drag = {n, mid, sx: p.x, sy: p.y, ox: n ? n.x : cam.x, oy: n ? n.y : cam.y, moved: false, t: e.timeStamp, lx: p.x, ly: p.y, vx: 0, vy: 0,
        box: !!X && !n && !mid && (X.tool() === "select" || e.shiftKey), add: e.shiftKey || e.ctrlKey || e.metaKey};
    });
    vp.addEventListener("pointermove", (e) => {
      if (!pts.has(e.pointerId)) return;
      const p = local(e); pts.set(e.pointerId, p);
      // Two fingers: the board point that was between them stays between them, so they zoom and carry it at once.
      if (pinch && pts.size === 2) { const [a, b] = [...pts.values()];
        cam.k = Math.max(zmin, Math.min(ZMAX, pinch.k * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d)); cam.x = (a.x + b.x) / 2 - pinch.wx * cam.k; cam.y = (a.y + b.y) / 2 - pinch.wy * cam.k; return apply(true); }
      if (!drag) return;
      // Past the slop the drag starts from where the pointer is, so nothing jumps to catch up.
      if (!drag.moved) { if (Math.hypot(p.x - drag.sx, p.y - drag.sy) < 5) return; drag.moved = true; drag.sx = p.x; drag.sy = p.y; drag.lx = p.x; drag.ly = p.y; drag.t = e.timeStamp; }
      const dx = p.x - drag.sx, dy = p.y - drag.sy;
      if (drag.box) return X.box({a: atW({x: drag.sx, y: drag.sy}), b: atW(p), add: drag.add});
      if (drag.n && X) {
        const n = drag.n;
        if (!drag.set) { drag.set = X.carry(n); drag.from = drag.set.map((o) => [o, o.x, o.y]); }
        n.x = drag.ox + dx / cam.k; n.y = drag.oy + dy / cam.k;
        // Inside its own frame a card stays in it; taken past the edge it follows the pointer, to be dropped on something.
        const w = atW(p), box = n.frame && within(w, n.frame) ? n.frame.box : null;
        const s = snap(n, nodes.filter((o) => !drag.set.includes(o) && o.type === n.type && o.frame === n.frame), TOL / cam.k, box);
        n.x = s.x; n.y = s.y; guide(s);
        const [, x0, y0] = drag.from.find(([o]) => o === n);
        drag.from.forEach(([o, ox, oy]) => { o.x = ox + n.x - x0; o.y = oy + n.y - y0; place(o); });
        nodes.forEach((g) => { if (drag.set.includes(g.of)) { follow(g); place(g); } });
        drag.over = X.over(w, drag.set);
        vp.classList.add("drag"); wires(new Set([...drag.set, ...nodes.filter((g) => drag.set.includes(g.of))]));
      } else if (drag.n) {
        const n = drag.n; n.x = drag.ox + dx / cam.k; n.y = drag.oy + dy / cam.k;
        const s = snap(n, nodes.filter((o) => o !== n && o.type === "ver"), TOL / cam.k);
        n.x = s.x; n.y = s.y; place(n); guide(s);
        nodes.forEach((g) => { if (g.of === n) { follow(g); place(g); } });
        vp.classList.add("drag"); wires(b2 ? new Set([n, ...nodes.filter((g) => g.of === n)]) : undefined);
      } else {
        vp.classList.add("pan"); cam.x = drag.ox + dx; cam.y = drag.oy + dy; apply(true);
        const dt = Math.max(1, e.timeStamp - drag.t) / 1000; drag.vx = drag.vx * .3 + (p.x - drag.lx) / dt * .7; drag.vy = drag.vy * .3 + (p.y - drag.ly) / dt * .7; drag.t = e.timeStamp; drag.lx = p.x; drag.ly = p.y;
      }
    });
    const up = (e) => {
      if (!pts.delete(e.pointerId)) return;
      // One finger left of two goes on moving the board from where it is.
      if (pinch && pts.size === 1) { const [p] = [...pts.values()]; pinch = null; drag = {n: null, sx: p.x, sy: p.y, ox: cam.x, oy: cam.y, moved: true, t: e.timeStamp, lx: p.x, ly: p.y, vx: 0, vy: 0}; return; }
      vp.classList.remove("pan", "drag"); guide();
      const d = drag; drag = null; if (!d) return;
      if (d.box) { X.box(null); if (d.moved) return; }
      if (!d.moved) { if (d.mid) return; if (d.n && X && !X.tap(d.n, d.add)) return; if (d.n) show(d.n); else { hide(); if (X) X.clear(); } }
      else if (d.n && X && (d.over || (d.n.frame && !within(atW(local(e)), d.n.frame)))) {
        // Let go over a target, or out of its own frame: the cards go back, and the target takes them or says why not.
        const r = d.over ? admit(d.over, d.set) : {ok: false, reason: "frame"};
        X.over(null);
        spring(d.from.map(([o, x, y]) => [o, {x, y}]), () => { nodes.forEach((g) => { if (g.of) follow(g); place(g); }); wires(); });
        if (r.ok) X.drop(d.over, d.set); else X.refuse(d.over || d.n, r.reason);
      }
      else if (d.n && X) {
        // The cards settle on the whole pixel they are kept at, and the cards they now stand on make
        // way along their row, as the next draw would place them.
        const had = new Map(d.set.filter((o) => o.type === "ver").map((o) => [o.id, saved[o.id]]));
        d.set.forEach((o) => { if (o.type === "ver") { o.x = Math.round(o.x); o.y = Math.round(o.y); saved[o.id] = spot(o); } else X.moved(o); }); keep(pkey, saved);
        arrange(saved, {...cam});
        // 되돌리기: every card of the move back where it was picked up, and its kept place with it.
        X.undoMove(d.set.length, async () => {
          const back = d.from.map(([o, x, y]) => [o, {x, y}]);
          const kept = vp.isConnected ? saved : places()[pkey] || {};   // drawn again since: the places read back
          back.forEach(([o]) => { if (o.type !== "ver") return; const was = had.get(o.id); if (was) kept[o.id] = was; else delete kept[o.id]; });
          keep(pkey, kept);
          await Promise.all(back.filter(([o]) => o.type !== "ver").map(([o, t]) => X.moved({...o, ...t})));
          if (!vp.isConnected) return host.isConnected && X.redo();
          arrange(kept, {...cam}, back.filter(([o]) => o.type !== "ver"));
        });
      }
      else if (d.n) {
        // With the switch on the card settles on the whole pixel it is kept at, so another window,
        // a reload and 되돌리기 show it exactly where it was left.
        // The cards it now stands on make way along their row, as the next draw would place them.
        if (b2) { d.n.x = Math.round(d.n.x); d.n.y = Math.round(d.n.y); }
        saved[d.n.id] = spot(d.n); keep(pkey, saved); if (b2) arrange(saved, {...cam}); }
      else if (e.timeStamp - d.t < 80) glide(d.vx, d.vy);
    };
    vp.addEventListener("pointerup", up); vp.addEventListener("pointercancel", up);
    vp.addEventListener("wheel", (e) => { if (e.target.closest(".bd-det,[data-bdx]")) return; e.preventDefault(); const p = local(e); wheel(Math.exp(-e.deltaY * (e.deltaMode === 1 ? 33 : 1) * (e.ctrlKey ? .01 : .0018)), p.x, p.y, e.ctrlKey); }, {passive: false});
    // The wheel button is the board's hand: no autoscroll compass, no paste or new tab from a card under it.
    vp.addEventListener("mousedown", (e) => { if (e.button === 1 && !e.target.closest(".bd-det")) e.preventDefault(); });
    vp.addEventListener("auxclick", (e) => { if (e.button === 1) e.preventDefault(); });
    vp.addEventListener("keydown", (e) => {
      const n = e.target.closest(".bd-node.ver") && nodes.find((x) => x.el === e.target);
      // The open card's video answers as the item page's does: Space plays or pauses, , and . step a frame.
      // With the switch on only; off, Space on the open card opens it again as before.
      const vd = b2 && cur && det.querySelector(".bd-pv video");
      if (vd && (n === cur || e.target === vd) && !e.altKey && !e.ctrlKey && !e.metaKey) {
        if (e.key === " " && n) { e.preventDefault(); if (vd.paused) vd.play().catch(() => {}); else vd.pause(); return; }
        if (e.key === "," || e.key === ".") {
          e.preventDefault();
          stepVideo(vd, (cur.v.files || []).find((f) => f.play === vd.getAttribute("src")) || {}, e.key === "." ? 1 : -1);
          return;
        }
      }
      if (n && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); show(n); return; }
      // With the switch on, the board's keys (BoardView.keys); never while typing a comment.
      if (!b2 || e.altKey || e.ctrlKey || e.metaKey || e.target.closest("input,textarea,select,[contenteditable]")) return;
      const f = api.keys[e.key.length === 1 ? e.key.toLowerCase() : e.key];
      if (f && f(kx, e) !== false) e.preventDefault();
    });
    // Zoom is the wheel or a pinch; the one button brings the whole board back into view.
    const fitAll = () => camTo(fit(bounds(nodes), vp.clientWidth, vp.clientHeight, foot(), b2 ? zmin : 0));
    vp.querySelector("[data-bdz]").onclick = fitAll;
    // The zoom bar eases around the middle of the view, as a wheel notch does around the pointer.
    const zoomBy = (f) => wheel(f, vp.clientWidth / 2, vp.clientHeight / 2);
    const zoom100 = () => zoomBy(1 / (zt ? zt.k : cam.k));
    if (b2) {
      vp.querySelector("[data-bdzi]").onclick = () => zoomBy(1.25);
      vp.querySelector("[data-bdzo]").onclick = () => zoomBy(.8);
      pct.onclick = zoom100;
      const pin = vp.querySelector("[data-bdmini]");
      pin.onclick = () => { const on = !pinned(); pinned(on); pin.setAttribute("aria-pressed", on); mini.classList.toggle("pin", on); map(); };
      // The lines and their chips can be put away for a clean look; the work they show is untouched.
      const eb = vp.querySelector("[data-bdedge]");
      eb.onclick = () => { const on = !lines(); lines(on); eb.setAttribute("aria-pressed", !on); vp.classList.toggle("noedge", !on); };
      // The minimap answers a press (the view glides there) and a drag (the view follows 1:1). It
      // takes the pointer only while it shows: kept up, or for the moment after the view moved.
      let md = null;
      const toCam = (e, glideTo) => { const r = mini.getBoundingClientRect();
        const t = mapTo(mapXf(mb), e.clientX - r.left, e.clientY - r.top, vp.clientWidth, vp.clientHeight, cam.k);
        if (glideTo) camTo(t); else { stop(); Object.assign(cam, t); apply(true); } };
      mini.addEventListener("pointerdown", (e) => { if (e.button) return; e.stopPropagation(); e.preventDefault(); stop();
        mini.setPointerCapture(e.pointerId); md = {x: e.clientX, y: e.clientY, moved: false}; });
      mini.addEventListener("pointermove", (e) => { if (!md) return; if (!md.moved && Math.hypot(e.clientX - md.x, e.clientY - md.y) < 3) return; md.moved = true; toCam(e, false); });
      mini.addEventListener("pointerup", (e) => { if (md && !md.moved) toCam(e, true); md = null; });
      mini.addEventListener("pointercancel", () => { md = null; });
      mini.addEventListener("pointerenter", () => { mini.classList.add("live"); clearTimeout(mapT); });
      mini.addEventListener("pointerleave", () => { if (!md) { clearTimeout(mapT); mapT = setTimeout(() => mini.classList.remove("live"), 1500); } });
    }
    // 정렬: every card back to its place on the grid, and the view back to the whole board.
    // Every card to the places `to` gives them, and the camera to `view`, on the one spring (with
    // `more`: other [card, {x, y}] moves riding along).
    const arrange = (to, view, more = []) => {
      guide();
      const grid = (alt ? alt(items, to) : layout(items, to, opts || b2)).nodes, vers = nodes.filter((n) => n.type === "ver");
      if (b2 && !alt) fill(grid, to, null);
      const parts = vers.map((n) => { const g = grid.find((x) => x.id === n.id); return [n, {x: g.x, y: g.y}]; });
      parts.push(...more, [cam, view || fit(bounds(grid), vp.clientWidth, vp.clientHeight, foot())]);
      spring(parts, () => { nodes.forEach((n) => { if (n.of) follow(n); place(n); }); wires(); apply(); });
    };
    // 되돌리기 for a rearrangement: the places saved before it (snapshot) come back, and the view it was seen in.
    const restore = (prev, view) => {
      for (const k in saved) delete saved[k];
      Object.assign(saved, snapshot(prev)); keep(pkey, saved);
      arrange(saved, view);
    };
    vp.querySelector("[data-bdtidy]").onclick = () => {
      // With the switch on, the hand-made places are kept aside for 30 seconds behind 되돌리기.
      const prev = b2 && Object.keys(saved).length ? snapshot(saved) : null, view = {...cam};
      for (const k in saved) delete saved[k];
      keep(pkey, saved);
      arrange(null);
      if (prev) undoable(prev, {view});
    };
    swap(host, "rail", again);

    // Locate: an item's card (version v, else its newest) opens, comes to the middle of the free view
    // at a readable size, and rings once. False when the board has no such item.
    const card = (k, v) => { const row = nodes.filter((n) => n.type === "ver" && `${n.it.project}/${n.it.id}` === k);
      return (v && row.find((n) => n.v.v === v)) || row[row.length - 1]; };
    const locate = (k, v) => {
      const n = card(k, v); if (!n) return false;
      show(n, true);
      const w = vp.clientWidth, h = vp.clientHeight, phone = w < 600, s = Math.min(1, Math.max(cam.k, READ));
      const right = phone ? w : det.offsetLeft, bottom = phone ? det.offsetTop : h - foot();
      camTo({k: s, x: right / 2 - (n.x + n.w / 2) * s, y: bottom / 2 - (n.y + n.h / 2) * s});
      flash(n.el);
      return true;
    };
    // What a key gets to work with (BoardView.keys): the camera's moves, the picked card, and a step.
    const kx = {fitAll, zoomBy, zoom100, nodes, vp, show, locate,
      // The card a key acts on: the open one, the focused one, else the one nearest the middle of the view.
      at: () => cur || nodes.find((n) => n.el === document.activeElement) || (() => {
        const mx = (vp.clientWidth / 2 - cam.x) / cam.k, my = (vp.clientHeight / 2 - cam.y) / cam.k;
        return nodes.filter((n) => n.type === "ver").sort((a, b) => Math.hypot(a.x + a.w / 2 - mx, a.y + a.h / 2 - my) - Math.hypot(b.x + b.w / 2 - mx, b.y + b.h / 2 - my))[0]; })(),
      go: (n) => { show(n); n.el.focus({preventScroll: true}); },
      // A card nudged by the keyboard keeps its place as a drag would, and the row makes way the same.
      move: (n, dx, dy) => { n.x = Math.round(n.x + dx); n.y = Math.round(n.y + dy); place(n);
        nodes.forEach((g) => { if (g.of === n) { follow(g); place(g); } });
        saved[n.id] = spot(n); keep(pkey, saved); arrange(saved, reveal(n, true) || {...cam}); }};
    // Escape shuts the panel wherever the focus is (it sits on the page after a comment is sent).
    const esc1 = () => { if (!cur) return !!X && X.esc(); const el = cur.el; hide(); el.focus({preventScroll: true}); return true; };
    // The "board" beta reaches the cards and the camera through these.
    live = {size, map, vp, esc: esc1, key, pkey, restore, locate, count: () => nodes.filter((n) => n.type === "ver").length,
      hl: (k, v, on) => card(k, v)?.el.classList.toggle("hl", on), has: (k, v) => { const n = card(k, v); return !!n && (!v || n.v.v === v); },
      world, nodes, cam, camTo, apply, show, hide, wires, place, saved, keep: () => keep(pkey, saved),
      fit: () => fit(bounds(nodes), vp.clientWidth, vp.clientHeight, foot())};
    if (X) X.mount({vp, world, nodes, cam, det, show, hide, place, wires, camTo, local, atW});
    wires(); apply();
    if (put.length) {
      put.forEach((n) => { saved[n.id] = spot(n); n.el.classList.add("bd-new"); });
      keep(pkey, saved);
      const one = put.length === 1;
      undoable(before, {view: {...cam}, ms: 12000,
        text: one ? tl("board.placed", {v: vShort(put[0].v.v), t: put[0].it.title}) : tl("board.placedn", {n: put.length})});
    }
    const was = m.sel && nodes.find((n) => n.id === m.sel);
    if (was) show(was, true); else m.sel = null;
    const p = asked();
    if (p && locate(p.k, p.v)) pend = null;
  }
  addEventListener("resize", () => { if (live && live.vp.isConnected) { live.size(); live.map(); } });
  addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.defaultPrevented && live && live.vp.isConnected && live.esc()) e.preventDefault(); });

  // 되돌리기 for anything that rearranged the board on screen (정렬 here; a layout from another
  // part may call it too): prev is snapshot(saved) taken before the move, opts.view the camera to go
  // back to, opts.text the toast's words. The toast stays opts.ms, else 30 seconds.
  function undoable(prev, opts = {}) {
    if (!live || !live.vp.isConnected) return;
    const key = live.key, pk = live.pkey;
    // A refresh may have drawn the board again meanwhile: the places go back to whichever board is up for
    // that screen, or into storage for the next time it is drawn.
    toastAct(opts.text || tl("board.tidied", {n: live.count()}), tl("board.undo"), () => {
      if (live && live.vp.isConnected && live.key === key) live.restore(prev, opts.view); else keep(pk, snapshot(prev));
    }, opts.ms || 30000);
  }

  // 보드에서 보기 (web/board-cam.js wires the buttons): the board on screen shows the card if it has
  // it; otherwise 결과물 › 보드 opens and shows it once drawn, or says it is not on the board.
  function focus(project, id, v) {
    const k = `${project}/${id}`;
    if (live && live.vp.isConnected && live.locate(k, v)) return;
    if (live && live.vp.isConnected && live.key === "*") return toast(tl("board.nofind"));
    const mine = pend = {k, v, t: Date.now()};
    nav("board");
    setTimeout(() => { if (pend === mine) { pend = null; toast(tl("board.nofind")); } }, 3000);
  }
  // The board's keys with the switch on: a map from KeyboardEvent.key (letters in lower case) to
  // fn(ctx, event); returning false lets the key go on. Other parts may add their own (V, H, ...).
  const arrow = (dx, dy) => (x, e) => { const n = x.at(); if (!n) return;
    if (e.shiftKey) return x.move(n, dx * 8, dy * 8);
    x.go(nearest(n, x.nodes, dx, dy) || n); };
  api.keys = {
    f: (x) => x.fitAll(), "0": (x) => x.zoom100(),
    "+": (x) => x.zoomBy(1.25), "=": (x) => x.zoomBy(1.25), "-": (x) => x.zoomBy(.8),
    ArrowLeft: arrow(-1, 0), ArrowRight: arrow(1, 0), ArrowUp: arrow(0, -1), ArrowDown: arrow(0, 1),
    c: (x) => { const n = x.at(); if (n) compare(n); },
  };
  // C: the card's version beside the one before it, in the compare viewer (web/cmpview.js).
  async function compare(n) {
    const i = n.it.versions.indexOf(n.v);
    if (i < 1) return toast(tl("board.noprev"));
    let d;
    try { d = await get("/api/item?p=" + encodeURIComponent(n.it.project) + "&i=" + encodeURIComponent(n.it.id)); } catch (e) { return toast(e.message); }
    const versions = (d.versions || []).map((q) => ({v: q.v, at: q.at, summary: q.summary, files: q.files || []}))
      .sort((a, b) => b.v.localeCompare(a.v, undefined, {numeric: true}));
    openCompareView({title: n.it.title, versions, a: n.it.versions[i - 1].v, b: n.v.v});
  }
  // A card outlined while its name is pointed at elsewhere (the chat's item chips).
  const hl = (k, v, on) => { if (live && live.vp.isConnected) live.hl(k, v, on); };

  // The board on screen: its screen key ("*" for every project's, else the project's), or null.
  const onScreen = () => (live && live.vp.isConnected ? live.key : null);

  // Whether the board on screen has that item's card (version v, else any).
  const shows = (k, v) => !!(live && live.vp.isConnected && live.has(k, v));

  api.draw = draw; api.same = same; api.shows = shows; api.undoable = undoable; api.focus = focus; api.hl = hl; api.onScreen = onScreen;
  // For the "board" beta (web/board-spread.js): the view pick and the kept card places.
  api.mode = mode; api.places = places; api.keep = keep;
  window.BoardView = api;
})();
