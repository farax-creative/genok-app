// Korean initial-consonant search: "ㄱㄴ" finds "가나다", and a query that mixes full syllables
// with initials ("가ㄴ") works too. A query with no bare initial is a plain substring match, so
// English and full Korean words behave as before. Tested in tests/chosung.test.js.
(function () {
  "use strict";

  // The 19 syllable initials in Unicode order, as the compatibility jamo a keyboard types.
  const CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";

  function initialOf(ch) {
    const c = ch.charCodeAt(0) - 0xac00;
    return c >= 0 && c < 11172 ? CHO[Math.floor(c / 588)] : ch;
  }

  // Does `hay` contain `q`? Both are compared lowercased; a bare initial in `q` matches any
  // syllable that starts with it (or that same initial).
  function has(hay, q) {
    const h = String(hay || "").toLowerCase(), s = String(q || "").toLowerCase();
    if (![...s].some((c) => CHO.includes(c))) return h.includes(s);
    const H = [...h], S = [...s];
    for (let i = 0; i + S.length <= H.length; i++) {
      let ok = true;
      for (let j = 0; j < S.length && ok; j++) ok = H[i + j] === S[j] || (CHO.includes(S[j]) && initialOf(H[i + j]) === S[j]);
      if (ok) return true;
    }
    return false;
  }

  const api = {has, initialOf};
  if (typeof module !== "undefined") module.exports = api;
  if (typeof window !== "undefined") window.Chosung = api;
})();
