// 에이전트 연결 (설정): Claude Code · Codex를 버튼으로 연결한다. 각 조각은 바뀔 내용을
// diff로 보여 주고, 동의하면 적용하고, [해제]로 우리 부분만 되돌린다. (design v2 §5.4·§6.4·§6.5)
// 기본 화면은 에이전트마다 한 줄(색 점 · 이름 · 상태 한 단어). 나머지는 그 줄을 눌러야 나온다.
(function () {
  const AGENTS = [
    {k: "claude", n: () => tl("connect.claude"), install: "https://code.claude.com/docs/en/overview",
     pieces: [["hook", () => tl("connect.p_hook"), () => tl("connect.p_hook_d")],
              ["skill", () => tl("connect.p_skill"), () => tl("connect.p_skill_d")],
              ["mcp", () => tl("connect.p_mcp"), () => tl("connect.p_mcp_d")],
              ["mod", () => tl("connect.p_mod"), () => tl("connect.p_mod_d")],
              ["perm", () => tl("connect.p_perm"), () => tl("connect.p_perm_d")]]},
    {k: "codex", n: () => tl("connect.codex"), install: "https://developers.openai.com/codex/cli",
     pieces: [["agents_md", () => tl("connect.p_agents"), () => tl("connect.p_agents_d")],
              ["hook", () => tl("connect.p_hook"), () => tl("connect.p_hook_d")],
              ["mcp", () => tl("connect.p_mcp"), () => tl("connect.p_mcp_d")]]},
  ];
  let state = null;                         // last /api/connect result
  // What only this page asks, and only when it is opened or a button is pressed: whether each CLI
  // is behind its newest version (cli_update.py), and each agent's default for new conversations.
  const vers = {};
  let defs = null;
  // One read at a time: the page, the pill and a redraw during start-up can all ask at once.
  let sideP = null;
  function loadSide() {
    if (sideP) return sideP;
    return sideP = Promise.all([timed("/api/cli/version", 12000), timed("/api/agentdefault", 20000), timed("/api/consent", 8000), timed("/api/connect/perms", 8000)]).then(([v, d, c, p]) => {
      if (v && v.agents) v.agents.forEach((x) => { vers[x.agent] = x; });
      if (d) defs = d;
      if (c) cons = new Set((c.grants || []).map((g) => g.scope));
      if (p && p.claude) perms = p;
      if (v || d || c || p) redraw();
    }).finally(() => { sideP = null; });
  }

  // One detect at a time: the home card, the wizard and the focus re-check can all ask at once, and
  // each detect spawns the CLIs. Callers that arrive while one is running share its answer.
  let inflight = null, stateAt = 0;         // stateAt: when the last detect answered
  // A read that gives up: a CLI that hangs must never hold a screen. null = no answer in time.
  function timed(url, ms) {
    if (typeof fetch !== "function") return Promise.resolve(null);
    const c = new AbortController(), k = setTimeout(() => c.abort(), ms);
    return fetch(url, {cache: "no-store", signal: c.signal}).then((r) => r.ok ? r.json() : null)
      .catch(() => null).finally(() => clearTimeout(k));
  }
  // /api/connect only sees whether a login file exists; the CLI's own status command is what
  // knows if the person is signed in. Take its word when it answers, and mark "unsure" when it
  // does not, so this page and the wizard never disagree about the same account.
  function withLogin(s, sts) {
    ["claude", "codex"].forEach((k, i) => {
      const d = s && s[k], st = sts[i];
      if (!d || !d.installed || !st || !st.installed) return;
      d.unsure = st.unsure || null;
      if (!st.unsure) d.logged_in = !!st.logged_in;
      if (k === "codex") d.talked = st.talked || null;   // the last real test turn that got a reply
    });
    return s;
  }
  // A state that came back from apply/remove (or a seed) carries only the file-based login guess.
  // Keep what the CLI itself last said, or the card drops back to "로그인 필요" right after a change.
  function adopt(next) {
    if (!next || typeof next !== "object") return state;
    ["claude", "codex"].forEach((k) => {
      const was = state && state[k], d = next[k];
      if (!was || !d || !d.installed || !("unsure" in was)) return;
      d.unsure = was.unsure;
      if (!was.unsure) d.logged_in = was.logged_in;
      if ("talked" in was) d.talked = was.talked;
    });
    state = next;
    return state;
  }
  function fetchState() {
    if (!inflight) {
      inflight = Promise.all([get("/api/connect"), timed("/api/cli/status?agent=claude", 10000),
                              timed("/api/cli/status?agent=codex", 10000)])
        .then(([s, c, x]) => {
          const was = extraOf("codex");
          state = withLogin(s, [c, x]); stateAt = Date.now();
          // The approval can also be found by a full re-read (다시 확인, coming back to the window).
          // Not every reader redraws (the title-bar pill only reads), so the open view is redrawn here.
          if (was === "trust" && extraOf("codex") === "") { trust.phase = "ok"; toast(tl("connect.trust.ok")); setTimeout(() => redraw("codex"), 0); }
          trustPoll(); return state; })
        .finally(() => { inflight = null; });
    }
    return inflight;
  }
  // Where one agent stands on the way to "연결됨": the single next step, the same answer for the
  // settings page, the wizard, the title-bar pill and the new-session picker.
  function stepOf(agent, s) {
    const d = (s || state || {})[agent];
    if (!d) return "";
    if (!d.installed) return "install";
    if (d.unsure && d.logged_in !== true) return "unsure";
    if (d.logged_in === false) return "login";
    // Codex talks in Genok with nothing written into its settings: signed in is enough. "연결됨"
    // is said only after one real test turn got a reply (codex_check.py), so "check" comes first.
    if (agent === "codex") return d.talked ? "done" : "check";
    const req = d.required || ["hook"];
    if (req.some((k) => ((d.pieces || {})[k] || {}).present !== true)) return "connect";
    return "done";
  }
  // Codex's optional extra (comments delivered into a running turn): "connect" = not switched
  // on, "trust" = switched on but not yet allowed inside Codex, "" = on (or not applicable).
  // Never a step on the way to 연결됨.
  function extraOf(agent, s) {
    const d = (s || state || {})[agent];
    if (agent !== "codex" || !d || !d.installed) return "";
    if (((d.pieces || {}).hook || {}).present !== true) return "connect";
    return d.hook_trusted === false ? "trust" : "";
  }
  // The pressed Codex test: what it last said on this page (nothing is kept across a reload
  // except the success, which the server remembers).
  const talk = {busy: false, error: "", detail: "", just: false};

  // Waiting for the one approval inside Codex. While a screen shows "허용 전" the server is asked
  // every 2 s - two small file reads there, no CLI - so the row turns by itself the moment the
  // person approves; nothing depends on the window getting focus back. phase: "wait" a window was
  // opened from here, "closed" it went away (or 3 minutes passed) without the approval, "ok" the
  // approval just arrived.
  const trust = {phase: "", at: 0};
  let trustT = 0;
  function redraw(agent) {
    if (curBox && document.body.contains(curBox)) render(curBox).catch(() => {});
    if (onWatch) { try { onWatch(agent); } catch (e) { /* a listener must not stop the wait */ } }
  }
  function waitTrust() { trust.phase = "wait"; trust.at = Date.now(); trustPoll(); }
  function trustPoll() {
    clearTimeout(trustT);
    if (extraOf("codex") !== "trust") return;
    trustT = setTimeout(async () => {
      const shown = !document.hidden && !!document.querySelector(".cntrust,[data-cntrust]");
      const r = shown ? await timed("/api/connect/trust", 4000) : null;
      if (r && extraOf("codex") === "trust") {
        const was = trust.phase;
        if (r.hook_trusted === true) { state.codex.hook_trusted = true; trust.phase = "ok"; toast(tl("connect.trust.ok")); }
        else if (was === "wait" && (r.window === false || Date.now() - trust.at > 180000)) trust.phase = "closed";
        if (trust.phase !== was) {
          redraw("codex");
          try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
        }
      }
      trustPoll();
    }, 2000);
  }
  window.addEventListener("visibilitychange", () => { if (!document.hidden) trustPoll(); });   // bubbles up from the document

  // A piece as one row: what it does in plain words, its technical name dim under it, and a
  // switch. On: the press takes it out. Off: the press first shows what would change.
  const TECH = {hook: () => tl("connect.k_hook"), skill: () => tl("connect.k_skill"), agents_md: () => "AGENTS.md", mcp: () => "MCP", mod: () => tl("connect.k_mod"), perm: () => tl("connect.k_perm")};
  function pieceRow(agent, k, name, note) {
    const p = (state?.[agent]?.pieces || {})[k] || {};
    const on = p.present === true, say = note || (p.present === null ? tl("connect.unknown") : "");
    return `<div class="cnfr cnpr"><span><b>${esc(name)}</b><small>${esc(TECH[k] ? TECH[k]() : k)}</small></span>
      <span class="cnfrc">${say ? `<span class="cnst" aria-live="polite">${say}</span>` : ""}<button type="button" class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" aria-label="${esc(name)}" ${on ? "data-cnrm" : "data-cncon"}="${agent}/${k}"></button></span></div>`;
  }

  // One plain status line per agent (no jargon). Same logic for every agent, so the app leans
  // toward neither: 설치 → 로그인 → 연결(훅) → 연결됨.
  function agentStatus(d, k) {
    if (!d.installed) return {txt: tl("connect.st_missing"), cls: ""};
    if (d.unsure && d.logged_in !== true) return {txt: tl("connect.st_unsure"), cls: "warn"};
    if (d.logged_in === false) return {txt: tl("connect.st_login"), cls: ""};
    if (k === "codex") {
      if (d.talked) return {txt: talk.just ? tl("connect.cx_just") : tl("connect.cx_ok"), cls: "ok"};
      return talk.error ? {txt: tl("connect.cx_fail"), cls: "warn"} : {txt: tl("connect.cx_todo"), cls: ""};
    }
    const hookOn = (d.pieces?.hook || {}).present === true;
    if (!hookOn) return {txt: tl("connect.st_notyet"), cls: ""};
    // inbox: whether this Claude Code lets a line be dropped straight into a resting session.
    // false = every line takes the slow road (stop + resume), and an update is what fixes it.
    if (d.launcher === "opaque") return {txt: tl("connect.st_opaque"), cls: "warn"};
    if (d.inbox_env === "noeffect") return {txt: tl("connect.st_noeffect"), cls: "warn"};
    if (d.inbox_env === "pending") return {txt: tl("connect.st_pending"), cls: "warn"};
    if (d.inbox === false) return {txt: d.inbox_env === "closed" ? tl("connect.st_closed") : d.inbox_env === "own" ? tl("connect.st_own") : tl("connect.st_slow"), cls: "warn"};
    if (d.inbox_env === "forced") return {txt: tl("connect.st_forced"), cls: "ok"};
    return {txt: d.inbox === true ? tl("connect.st_fast") : tl("connect.st_ready"), cls: "ok"};
  }

  // Codex only: our part is in place but Codex has not been told to allow it. We never write that
  // permission ourselves; the button opens Codex and the lines say exactly what to press there.
  // The boxed lines are Codex's own on-screen words (read from the installed CLI), so the person
  // can match them by eye. `btn` false = the host card draws its own button.
  function trustGuide(btn, recheck) {
    const term = ["Hooks need review", "Hooks can run outside the sandbox after you trust them.", "",
                  "<b>Trust all and continue</b>  \u2190 Enter", "Continue without trusting (hooks won't run)"];
    return `<div class="cnlogin cnguide cntrust"><div class="cngt">${tl("connect.trust.t")}</div>
      <ol>${[tl("connect.trust.1"), tl("connect.trust.2"), tl("connect.trust.3")].map((h, i) => `<li><span class="cnn" aria-hidden="true">${"\u2460\u2461\u2462"[i]}</span><span class="cnx">${h}</span></li>`).join("")}</ol>
      <pre class="cnterm" aria-label="${esc(tl("connect.trust.pic"))}">${term.join("\n")}</pre>
      <details class="cnalt"><summary>${tl("connect.trust.alt")}</summary>
        <p>${tl("connect.trust.alt1")}</p>
        <p>${tl("connect.trust.alt2", {cmd: `<span class="cncmd"><code>${INSTALL_CX}@latest</code><button type="button" class="btn sm press" data-cncopy="${INSTALL_CX}@latest">${tl("connect.copy")}</button></span>`})}</p>
        <p>${tl("connect.trust.alt3")}</p></details>
      ${btn || recheck ? `<div class="srow">${btn ? `<button class="btn sm fill press" data-cntrust="codex">${trust.phase ? tl("connect.trust.again") : tl("connect.trust.btn")}</button>` : ""}
        ${recheck ? `<button class="btn sm press" data-cnrecheck="1">${tl("connect.recheck")}</button>` : ""}</div>` : ""}</div>`;
  }

  // The installed CLI is behind its newest version: say so, with the one button that updates it.
  // A CLI this app did not install (it came inside a desktop app, or by hand) says where it comes
  // from instead of offering a button. `why` adds what the update is for (a model it lacks).
  function oldNote(k, why) {
    const v = vers[k]; if (!v || !v.behind) return "";
    const name = k === "codex" ? tl("connect.codex") : tl("connect.claude");
    const where = v.can_update ? "" : " " + (v.origin === "app" ? tl("connect.upd.app", {name}) : tl("connect.upd.other", {name}));
    return `<div class="cnnote"><span>${tl("connect.upd.old", {name, have: esc(v.installed), latest: esc(v.latest)})}${why ? " " + tl("connect.upd.why") : ""}${where}</span>
      ${v.can_update ? `<button class="btn sm press" data-cnupd="${k}">${tl("connect.upd.btn")}</button>` : ""}</div>`;
  }
  // Codex, signed in, not yet "연결됨": what the test does (it spends a little usage, so it only
  // runs on a press), and - after a failed press - why, with Codex's own line under it. When the
  // model was the reason, the ways out come in order: update an old CLI, else try another model.
  function checkWhy() {
    const err = talk.error ? `<div class="s" style="white-space:normal">${esc(talk.error)}</div>${talk.detail ? `<details class="cnalt"><summary>${tl("connect.cx_raw")}</summary><pre class="cnterm">${esc(talk.detail)}</pre></details>` : ""}` : "";
    const picks = talk.error && talk.models && talk.models.length ? `<div class="cnpick"><div class="s">${tl("connect.cx_pick")}</div>
      <div class="cnpickr">${talk.models.map((m) => `<button class="btn sm press" data-cxcheck="${esc(m.id)}">${esc(m.name)}</button>`).join("")}</div>
      <div class="s cnq">${tl("connect.cx_pick_d")}</div></div>` : "";
    return (talk.missing ? oldNote("codex", true) : "") + (err || picks ? `<div class="cnlogin">${err}${picks}</div>` : "");
  }

  // What is open on this page, per agent: the detail under its row, the settings under a step
  // ("more"), the steps put off with [나중에], and the permission switches held before a connect.
  const ui = {claude: {open: false, more: false, skip: new Set(), perm: null},
              codex: {open: false, more: false, skip: new Set(), perm: null}};
  let extraOpen = false;                    // the "더 보기" row
  let wasOpen = new Set();                  // details already on screen: only a new one fades in
  const SCOPE = {claude: "read:claude-sessions", codex: "read:codex-sessions"};
  const nameOf = (k) => k === "codex" ? tl("connect.codex") : tl("connect.claude");
  const ctest = {ok: null, msg: ""};        // Claude's pressed end-to-end test, as this page last saw it
  const undoTok = {};                      // agent -> the first run's one-press restore token (server memory)
  let cons = null;                          // Set of granted scopes; null until /api/consent answers
  // Permissions agreed at connect (connect_perms.py): one list per agent, the same switches on
  // the connect step, in [설정 다시 하기] and on the agent's row. A short label and one plain reason.
  let perms = null;                         // /api/connect/perms; null until it answers
  const permOpen = new Set();               // agents whose list is unfolded, kept across redraws
  const PERM = {
    "read:claude-sessions": [() => tl("perm.s.read"), () => tl("perm.s.read_d")],
    "read:codex-sessions": [() => tl("perm.s.read"), () => tl("perm.s.read_d")],
    "session.open": [() => tl("perm.s.open"), () => tl("perm.s.open_d")],
    "session:wake": [() => tl("perm.s.wake"), () => tl("perm.s.wake_d")],
    "session:stop": [() => tl("perm.s.stop"), () => tl("perm.s.stop_d")],
    "session:hide": [() => tl("perm.s.hide"), () => tl("perm.s.hide_d")],
    "dept.folder": [() => tl("perm.s.folder"), () => tl("perm.s.folder_d")],
    "dept.files": [() => tl("perm.s.files"), () => tl("perm.s.files_d")],
    "read:agent-config": [() => tl("perm.s.config"), () => tl("perm.s.config_d")],
    "read:claude-memory": [() => tl("perm.s.memory"), () => tl("perm.s.memory_d")],
    "read:workspace-docs": [() => tl("perm.s.docs"), () => tl("perm.s.docs_d")],
    "run:codex": [() => tl("perm.s.codex"), () => tl("perm.s.codex_d")],
    "claude.trust.new": [() => tl("perm.s.trust"), () => tl("perm.s.trust_d")],
    "claude.inbox_env": [() => tl("perm.s.inbox"), () => tl("perm.s.inbox_d")],
    "claude.bypass": [() => tl("perm.s.bypass"), () => tl("perm.s.bypass_d")],
    "codex.auto": [() => tl("perm.s.cxauto"), () => tl("perm.s.cxauto_d")],
  };
  const permItems = (k) => ((perms && perms[k] && perms[k].items) || []).filter((x) => PERM[x.scope]);
  // Before the connection lines are in (`pend`), the switches only hold the choice; the press
  // on [연결] applies it. Every switch says what it is for under its name (nothing on hover only).
  function permPick(k) {
    const u = ui[k];
    if (!u.perm) u.perm = new Map(permItems(k).map((x) => [x.scope, x.on || x.default]));
    return u.perm;
  }
  function permissionIntro() {
    return `<div class="cn-permission-intro"><b>${tl("perm.intro.title")}</b>
      <ul><li>${tl("perm.intro.read")}</li><li>${tl("perm.intro.send")}</li><li>${tl("perm.intro.manage")}</li></ul>
      <p>${tl("perm.intro.remember")}</p><p>${tl("perm.intro.agent")}</p></div>`;
  }
  function permList(k, pend) {
    const pick = pend ? permPick(k) : null;
    const row = (x) => { const on = pend ? !!pick.get(x.scope) : x.on, [n, r] = PERM[x.scope];
      return `<div class="cnfr cnpr"><span><b>${n()}</b><small>${r()}</small></span>
        <button type="button" class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" aria-label="${esc(n())}" data-cnperm="${k}/${esc(x.scope)}"></button></div>`; };
    const it = permItems(k), opt = it.filter((x) => !x.default);
    const cli = (perms[k] || {}).cli || {}, fo = cli.folders || [];
    const asks = k === "codex" ? `<p class="cnfd">${tl("perm.cli_cx")}</p>`
      : `<p class="cnfd">${tl("perm.cli_cc")}</p>` + fo.slice(0, 4).map((f) => `<div class="cnfr cnpr"><span><b>${esc(f.name)}</b><small>${esc(tilde(f.folder))}</small></span>
          <button class="btn sm press" data-cntf="${esc(f.name)}">${tl("perm.cli_cc_btn")}</button></div>`).join("")
        + (fo.length > 4 ? `<p class="cnfd">${tl("perm.cli_cc_more", {n: fo.length - 4})}</p>` : "");
    return it.filter((x) => x.default).map(row).join("")
      + (opt.length ? `<div class="cnph">${tl("perm.opt")}</div>` + opt.map(row).join("") : "")
      + `<div class="cnph">${tl("perm.cli")}</div>` + asks;
  }
  const permDet = (k, label, pend) => `<details class="cndet cnpd" data-cnpermdet="${k}"${pend ? " data-cnpend" : ""}${permOpen.has(k) ? " open" : ""}><summary>${label}</summary>${permList(k, pend)}</details>`;
  async function permPost(body) {
    perms = await post("/api/connect/perms", body);
    const c = await timed("/api/consent", 8000);
    if (c) cons = new Set((c.grants || []).map((g) => g.scope));
  }
  const permTidyKey = (k) => "genok.permtidy." + k;
  function permTidy(k) {
    const n = perms && perms[k] ? perms[k].missing : 0;
    let hid = false; try { hid = localStorage.getItem(permTidyKey(k)) === "1"; } catch (e) { /* no storage: shown */ }
    if (!n || hid) return "";
    return `<div class="cnnote" role="status"><span>${tl("perm.tidy", {n})}</span>
      <span class="cnfa"><button class="cnlk press" data-cnpermx="${k}">${tl("perm.tidy_x")}</button><button class="btn sm press" data-cnpermall="${k}">${tl("perm.all")}</button></span></div>`;
  }
  // Comments delivered by themselves: "on", "trust" (in place, not yet allowed inside Codex), "off".
  function fwdOf(k) {
    const d = (state || {})[k] || {};
    if ((d.required || ["hook"]).some((x) => ((d.pieces || {})[x] || {}).present !== true)) return "off";
    return k === "codex" && d.hook_trusted === false ? "trust" : "on";
  }
  // The one thing an agent needs next, or null. Finished steps are never listed: the row says
  // 연결됨 and the detail shows settings instead. Nothing is written, asked or sent until the
  // step's own button is pressed. {t title, d one line, x extra under it, a buttons, raw: a whole
  // guide instead, keep: the settings stay under it}.
  function needOf(k) {
    const d = (state || {})[k] || {}, u = ui[k], name = nameOf(k);
    const btn = (attr, label, fill) => `<button class="btn ${fill ? "fill " : ""}press" ${attr}>${label}</button>`;
    const later = (id) => `<button class="cnlk press" data-cnskip="${k}/${id}">${tl("connect.flow.later")}</button>`;
    if (!d.installed) {
      const a = AGENTS.find((x) => x.k === k);
      return {id: "cli", raw: installGuide(k, true) + `<a class="cnlk" href="${a.install}" target="_blank" rel="noopener">${tl("connect.how")}</a>`};
    }
    if (d.logged_in !== true)
      return d.unsure ? {id: "login", t: tl("connect.st_unsure"), d: tl("connect.unsure_d", {name: esc(name)}), a: btn('data-cnrecheck="1"', tl("connect.recheck"), true)}
        : {id: "login", t: tl("connect.login_needed"), d: k === "codex" ? tl("connect.login_cx") : tl("connect.login_cc"),
           a: `<button class="cnlk press" data-cnrecheck="1">${tl("connect.recheck")}</button>` + btn(`data-cnlogin="${k}"`, tl("connect.login_open"), true)};
    const done = stepOf(k) === "done", f = fwdOf(k);
    // In place but not yet allowed inside Codex: the person presses there, never this app.
    if (f === "trust" && !u.skip.has("fwd")) {
      const wait = trust.phase === "wait";
      return {id: "trust", keep: done, t: tl("connect.trust.t"),
        d: wait ? `<span class="cnst cnwt" aria-live="polite"><i class="cnwd" aria-hidden="true"></i>${tl("connect.trust.wait")}</span>`
          : trust.phase === "closed" ? tl("connect.trust.notyet") : tl("connect.trust.3"),
        x: `<details class="cndet"><summary>${tl("connect.cxx_how")}</summary>${trustGuide(false, false)}</details>`,
        a: (done ? `<button class="cnlk press" data-cnrecheck="1">${tl("connect.recheck")}</button>` : later("fwd"))
          + btn('data-cntrust="codex"', trust.phase ? tl("connect.trust.again") : tl("connect.trust.btn"), true)};
    }
    if (done) return null;
    // Connecting is also where this agent's permissions are agreed: said on the step, with the
    // switches one tap away, so no dialog has to come up later in the middle of a chat.
    if (f === "off" && !u.skip.has("fwd"))
      return {id: "fwd", t: tl("connect.flow.t", {name: esc(name)}),
        d: perms ? tl("perm.one", {n: [...permPick(k).values()].filter(Boolean).length}) : k === "codex" ? tl("connect.flow.fwd_cx") : tl("connect.flow.fwd_cc"),
        x: perms ? permissionIntro() + permDet(k, tl("perm.pick"), true) : "",
        a: later("fwd") + btn(`data-cnfwd="${k}"`, tl("connect.flow.add"), true)};
    const miss = perms && perms[k] ? perms[k].missing : 0;
    if (miss && f !== "off" && !u.skip.has("perm"))
      return {id: "perm", t: tl("perm.t"), d: tl("perm.tidy", {n: miss}), x: permDet(k, tl("perm.pick")),
        a: later("perm") + btn(`data-cnpermall="${k}"`, tl("perm.all"), true)};
    if (!perms && cons && !cons.has(SCOPE[k]) && !u.skip.has("read"))
      return {id: "read", t: tl("connect.flow.read"), d: tl("connect.flow.read_d", {name: esc(name)}),
        a: later("read") + btn(`data-cncons="grant/${k}"`, tl("connect.flow.grant"), true)};
    if (k === "codex")
      return {id: "check", t: tl("connect.flow.check"), d: tl("connect.flow.check_d"), x: checkWhy(), a: btn("data-cxcheck", tl("connect.flow.check_btn"), true)};
    return null;
  }
  const stepCard = (n) => n.raw ? `<div class="cnstep">${n.raw}</div>`
    : `<div class="cnstep${n.id === "trust" ? " cntrust" : ""}"><div class="cnstt">${n.t}</div><p class="cnfd">${n.d}</p>${n.x ? `<div class="cnfx">${n.x}</div>` : ""}<div class="cnsta">${n.a || ""}</div></div>`;
  // "기본 모델": what a new conversation starts on, per agent. The rows come from the server each
  // time (Codex's from the installed CLI's own catalog), and the pick is kept in this app's
  // settings only. The first row hands the choice back to the agent's own settings.
  const EFF = {minimal: () => tl("mdl.sMinimal"), low: () => tl("mdl.sLow"), medium: () => tl("mdl.sMedium"), high: () => tl("mdl.sHigh"), xhigh: () => tl("mdl.sXhigh"), max: () => tl("mdl.sMax"), ultra: () => tl("mdl.sUltra")};
  const effName = (e) => EFF[e] ? EFF[e]() : e;
  function defRow(k, d) {
    const v = defs && defs[k];
    if (!v || !d.installed || d.logged_in === false || !(v.models || []).length) return "";
    const name = k === "codex" ? tl("connect.codex") : tl("connect.claude");
    const gone = v.start && v.start.gone ? `<div class="cnnote"><span>${tl("connect.def.gone", {old: esc(v.start.gone), name, now: esc(v.start.name)})}</span></div>` : "";
    return gone + `<div class="cnfr cnpr cndef"><span><b>${tl("connect.def.t")}</b><small>${tl("connect.def.d")}</small></span>
      <span class="cnfrc">${defSelects(k, v)}</span></div>`;
  }
  function defSelects(k, v) {
    const name = nameOf(k);
    const opt = (val, label, cur) => `<option value="${esc(val)}"${val === cur ? " selected" : ""}>${esc(label)}</option>`;
    return `<span class="cndefs"><gk-select data-cndef="${k}/model" aria-label="${esc(tl("connect.def.model"))}">${opt("", tl("connect.def.follow", {name}), v.model)}${v.models.map((m) => opt(m.id, m.name, v.model)).join("")}</gk-select>
      <gk-select data-cndef="${k}/effort" aria-label="${esc(tl("connect.def.effort"))}">${opt("", tl("connect.def.eff0"), v.effort)}${(v.efforts || []).map((e) => opt(e, effName(e), v.effort)).join("")}</gk-select></span>`;
  }
  // No Claude Code on this PC: the three steps to get it, with each command one press to copy.
  // One renderer for 설정 > 연결 and the first-run wizard (window.LOOP_CONNECT.installGuide);
  // `recheck` adds the 다시 확인 button where the host card has none of its own.
  const INSTALL_CMD = "irm https://claude.ai/install.ps1 | iex";
  const INSTALL_CX = "npm install -g @openai/codex";
  function installGuide(agent, recheck, other) {
    // The other agent already works here: this one is an extra, not something missing.
    const mate = agent === "claude" ? "codex" : "claude";
    const also = other === true || (other == null && !!(state && state[mate] && state[mate].installed));
    const cmd = (c) => `<span class="cncmd"><code>${esc(c)}</code><button type="button" class="btn sm press" data-cncopy="${esc(c)}">${tl("connect.copy")}</button></span>`;
    // Codex comes through npm, so it needs Node.js first; the steps say so instead of failing at step 2.
    const steps = agent === "codex"
      ? [tl("connect.guide.cx1"), tl("connect.guide.cx2", {cmd: cmd(INSTALL_CX)}), tl("connect.guide.cx3")]
      : [tl("connect.guide.1", {cmd: cmd(INSTALL_CMD)}), tl("connect.guide.2", {cmd: cmd("claude")}), tl("connect.guide.3")];
    const title = agent === "codex" ? (also ? tl("connect.guide.cxAlso") : tl("connect.guide.cxT"))
      : (also ? tl("connect.guide.tAlso") : tl("connect.guide.t"));
    return `<div class="cnlogin cnguide"><div class="cngt">${title}</div>
      <ol>${steps.map((h, i) => `<li><span class="cnn" aria-hidden="true">${"①②③"[i]}</span><span class="cnx">${h}</span></li>`).join("")}</ol>
      ${recheck ? `<div class="srow"><button class="btn sm press" data-cnrecheck="1">${tl("connect.recheck")}</button></div>` : ""}</div>`;
  }
  // Copy buttons, wherever a guide is drawn (settings or the wizard): the button says 복사됨 a moment.
  window.addEventListener("click", async (e) => {
    const b = e.target && e.target.closest && e.target.closest("[data-cncopy]"); if (!b) return;
    try { await navigator.clipboard.writeText(b.dataset.cncopy); } catch { /* clipboard blocked */ }
    if (b.dataset.label || (window.Motion && Motion.copied)) return;   // motion.js answers on the button itself
    b.dataset.label = b.textContent; b.textContent = tl("connect.copied");
    setTimeout(() => { b.textContent = b.dataset.label; delete b.dataset.label; }, 1400);
  });

  // [로그인 창 열기] / [Codex에서 한 번 허용하기], wherever a guide is drawn. The server opens the
  // CLI in a terminal; the press gives up after 15 s and the button always comes back, and a
  // bounded watch then re-checks so the page turns over without another press.
  window.addEventListener("click", async (e) => {
    const b = e.target && e.target.closest && e.target.closest("[data-cnlogin],[data-cntrust]"); if (!b || b.disabled) return;
    const isTrust = b.hasAttribute("data-cntrust"), agent = isTrust ? b.dataset.cntrust : b.dataset.cnlogin;
    const c = new AbortController(), k = setTimeout(() => c.abort(), 15000);
    b.disabled = true;
    try {
      const r = await fetch(isTrust ? "/api/cli/open-trust" : "/api/cli/open-login", {method: "POST", signal: c.signal,
        headers: {"Content-Type": "application/json"}, body: JSON.stringify({agent})});
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || tl("connect.open_fail"));
      toast(isTrust ? tl("connect.trust.opened") : tl("connect.login_opened"));
      if (isTrust) {                              // the 2 s wait takes over; the row says it is waiting
        waitTrust(); redraw(agent);
      } else watch(agent);
    } catch (err) { toast(err.name === "AbortError" ? tl("connect.open_slow") : (err.message || tl("connect.open_fail"))); }
    finally { clearTimeout(k); b.disabled = false; }
  });

  // A long press (a test turn, an update) shows that it is still working: the logo ring turning
  // beside the step it is likely on. No seconds and no fill - a fill read as a progress bar that
  // never finished (the person asked for the logo instead).
  function busyBtn(b, steps) {
    const t0 = Date.now();
    b.classList.add("pbusy"); b.setAttribute("aria-busy", "true");
    let key = "";
    const draw = () => {
      const now = steps.filter((x) => (Date.now() - t0) / 1000 >= x[0]).pop()[1];
      if (now === key) return;
      key = now;
      const t = b.querySelector(".ld-t");
      if (t) t.textContent = tl(key); else b.innerHTML = loadingHtml(esc(tl(key)), {inline: true});
    };
    draw();
    const iv = setInterval(draw, 250);
    return () => { clearInterval(iv); b.classList.remove("pbusy"); b.removeAttribute("aria-busy"); };
  }

  // [업데이트], wherever the old-version note is drawn: the server runs the CLI's own updater once
  // (bounded there), then the version, the model catalog and the page are read again.
  window.addEventListener("click", async (e) => {
    const b = e.target && e.target.closest && e.target.closest("[data-cnupd]"); if (!b || b.disabled) return;
    const agent = b.dataset.cnupd, name = agent === "codex" ? tl("connect.codex") : tl("connect.claude"), old = b.textContent;
    const c = new AbortController(), k = setTimeout(() => c.abort(), 300000);
    b.disabled = true;
    const stop = busyBtn(b, [[0, "connect.upd.busy"], [20, "connect.upd.slow"]]);
    try {
      const r = await fetch("/api/cli/update", {method: "POST", signal: c.signal,
        headers: {"Content-Type": "application/json"}, body: JSON.stringify({agent})});
      const j = await r.json().catch(() => ({}));
      if (j.agent) vers[agent] = j;
      // A failure the server saw leave the CLI as it was (`same`) says so, with the version still there.
      if (j.ok) toast(tl("connect.upd.done", {name, v: j.installed || ""}));
      else toastFail(j.error || tl("connect.upd.fail"), j.same ? (j.installed ? tl("err.ver.meta.v", {v: j.installed}) : tl("err.ver.meta")) : "");
      if (j.ok && agent === "codex") { talk.error = ""; talk.detail = ""; talk.missing = ""; talk.models = null; }
    } catch (err) { toast(tl("connect.upd.fail")); }
    finally {
      clearTimeout(k); stop();
      if (document.body.contains(b)) { b.disabled = false; b.textContent = old; }
      try { await fetchState(); } catch (e2) { /* offline: the page keeps what it showed */ }
      await loadSide();
      try { window.LOOP_CONNPILL.check(); } catch (e2) { /* the pill is optional */ }
    }
  });

  // [연결 확인] for Codex, wherever it is drawn: one real test turn on the server (bounded there
  // at 25 s, given up here at 40 s). The button always comes back and the page redraws from a
  // fresh read, so "연결됨" appears only when the server remembered a reply.
  window.addEventListener("click", async (e) => {
    const b = e.target && e.target.closest && e.target.closest("[data-cxcheck]"); if (!b || b.disabled || talk.busy) return;
    const c = new AbortController(), k = setTimeout(() => c.abort(), 40000), old = b.textContent;
    talk.busy = true; b.disabled = true;
    const stop = busyBtn(b, [[0, "connect.cx_s1"], [3, "connect.cx_s2"], [8, "connect.cx_s3"]]);
    try {
      if (b.dataset.obPerms) await permPost({agent: "codex", all: 1});
      const r = await fetch("/api/cli/codex-check", {method: "POST", signal: c.signal,
        headers: {"Content-Type": "application/json"}, body: JSON.stringify(b.dataset.cxcheck ? {model: b.dataset.cxcheck} : {})});
      const j = await r.json().catch(() => ({}));
      if (!j.busy) {
        talk.just = !!j.ok;
        talk.error = j.ok ? "" : (j.error || tl("connect.cx_fail"));
        talk.detail = j.ok ? "" : (j.detail || "");
        // A model the installed Codex cannot run: the version it is on and the models it does list.
        talk.missing = j.ok ? "" : (j.missing || ""); talk.models = j.ok ? null : (j.models || null);
        if (j.version) vers.codex = j.version;
        if (j.ok) { toast(tl("connect.cx_just")); if (b.dataset.cxcheck) loadSide(); }
      }
    } catch (err) { talk.just = false; talk.error = tl("connect.cx_slow"); talk.detail = ""; }
    finally {
      clearTimeout(k); stop(); talk.busy = false;
      if (document.body.contains(b)) { b.disabled = false; b.textContent = old; }
      try { await fetchState(); } catch (e2) { /* offline: the page keeps what it showed */ }
      if (curBox && document.body.contains(curBox)) await render(curBox);
      if (onWatch) { try { onWatch("codex"); } catch (e2) { /* a listener must not break the press */ } }
      try { window.LOOP_CONNPILL.check(); } catch (e2) { /* the pill is optional */ }
    }
  });

  // After a login / allow window was opened: look again every 5 s for 3 minutes at most, one check
  // at a time (fetchState is shared), and stop as soon as that agent moved on. Listeners (the
  // wizard) are told through onwatch; the settings page redraws only when something changed.
  let watchN = 0, onWatch = null;
  function watch(agent) {
    const my = ++watchN, was = stepOf(agent);
    let left = 36;
    const tick = async () => {
      if (my !== watchN || left-- <= 0) return;
      const before = JSON.stringify(state);
      try { await fetchState(); } catch (e) { /* offline: try again next round */ }
      if (my !== watchN) return;
      if (JSON.stringify(state) !== before) {
        if (curBox && document.body.contains(curBox)) await render(curBox);
        if (onWatch) { try { onWatch(agent); } catch (e) { /* a listener must not stop the watch */ } }
        try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
      }
      if (stepOf(agent) !== was && stepOf(agent) !== "unsure") return;
      setTimeout(tick, 5000);
    };
    setTimeout(tick, 5000);
  }

  const phi = (name) => { try { return window.LOOP_ICONS.html("regular/" + name); } catch (e) { return ""; } };
  // Something in the detail wants a look while the agent is connected (an update, a slow road, an
  // allow still open inside Codex, permissions left off): a small dot on the row, nothing more.
  function attnOf(k) {
    const d = (state || {})[k] || {};
    if (!d.installed || stepOf(k) !== "done") return false;
    const v = vers[k], df = defs && defs[k];
    return !!(v && v.behind) || agentStatus(d, k).cls === "warn" || extraOf(k) === "trust" || !!permTidy(k) || !!(df && df.start && df.start.gone);
  }
  // The settings of one agent, behind one tap on its row: the dim lines that want a look, the
  // default model, each piece as a switch, the permissions, a check, and the way out.
  function rowsOf(a) {
    const k = a.k, d = state?.[k] || {}, v = vers[k], st = agentStatus(d, k), done = stepOf(k) === "done";
    let notes = "";
    // inbox_env closed: no inbox on this PC and nothing written yet - offer the switch (asks before it writes).
    if (done && st.txt !== tl("connect.on"))
      notes += `<div class="cnnote ${st.cls}"><span>${st.txt}</span>${k === "claude" && d.inbox_env === "closed" ? `<button class="btn sm press" data-cninbox>${tl("connect.inbox_on")}</button>` : ""}</div>`;
    if (!(k === "codex" && talk.missing && stepOf("codex") === "check")) notes += oldNote(k, k === "codex" && !!(defs && defs.codex && defs.codex.missing));   // said once: the check's own note carries it
    notes += permTidy(k);
    // The Codex app reads its list when it starts: said once here, in one dim line.
    if (k === "codex" && done) notes += `<div class="cnnote"><span>${tl("connect.cx_app")}</span></div>`;
    // Codex's hook is its optional extra; the one state that needs the person is said next to it.
    const ex = extraOf("codex"), wait = ex === "trust" && trust.phase === "wait";
    const cxNote = wait ? tl("connect.trust.wait") : ex === "trust" ? (trust.phase === "closed" ? tl("connect.trust.notyet") : tl("connect.cxx_allow")) : "";
    const rank = (p) => p === "hook" ? 0 : p === "mcp" ? 2 : p === "mod" ? 3 : p === "perm" ? 4 : 1;
    const pieces = a.pieces.slice().sort((x, y) => rank(x[0]) - rank(y[0]))
      .map(([p, n]) => pieceRow(k, p, n(), k === "codex" && p === "hook" ? cxNote : "")).join("");
    const pit = perms ? permItems(k) : [];
    const permFold = pit.length ? permDet(k, tl("perm.t") + " " + tl("perm.count", {n: pit.length, on: pit.filter((x) => x.on).length})) : "";
    // The permissions list did not answer: reading the conversation records keeps its own switch.
    const granted = !!(cons && cons.has(SCOPE[k]));
    const read = !perms && cons ? `<div class="cnfr cnpr"><span><b>${tl("connect.flow.read")}</b><small>${tl("connect.flow.read_d", {name: esc(a.n())})}</small></span>
      <button type="button" class="sw${granted ? " on" : ""}" role="switch" aria-checked="${granted}" aria-label="${esc(tl("connect.flow.read"))}" data-cncons="${granted ? "revoke" : "grant"}/${k}"></button></div>` : "";
    const check = k === "claude"
      ? `<div class="cnfr cnpr"><span><b>${tl("connect.test")}</b><small class="${ctest.ok === false ? "bad" : ctest.ok ? "ok" : ""}">${ctest.msg ? esc(ctest.msg) : tl("connect.testintro")}</small></span>
          <button class="btn sm press" data-cnftest>${tl("connect.flow.check_btn")}</button></div>`
      : d.logged_in === true && d.talked ? `<div class="cnfr cnpr"><span><b>${tl("connect.flow.check")}</b><small>${tl("connect.flow.check_d")}</small></span>
          <button class="btn sm press" data-cxcheck>${tl("connect.flow.check_btn")}</button></div>` + checkWhy() : "";
    const any = Object.values(d.pieces || {}).some((x) => x && x.present === true);
    const ver = d.version ? "v" + esc(d.version) + (v && v.latest && !v.behind ? " · " + tl("connect.flow.latest") : "") : "";
    const foot = `<div class="cnfoot"><span class="cnver">${ver}</span><span class="cnfa"><button class="cnlk press" data-cnrecheck="1">${tl("connect.recheck")}</button>
      ${undoTok[k] ? `<button class="cnlk press" data-cnundo="${k}">${tl("onboard.cxundo")}</button>` : ""}
      ${d.talked || any ? `<button class="cnlk press" data-cndisc="${k}">${tl("connect.remove")}</button>` : ""}</span></div>`;
    return notes + defRow(k, d) + pieces + permFold + read + check + foot;
  }
  // Every agent is one row: its colour, its name, one status word, and one button only when
  // something is needed. A tap on the row fades its detail in below it, in place.
  function agentBlock(a) {
    const k = a.k, d = state?.[k] || {}, u = ui[k], step = stepOf(k), done = step === "done";
    // The other agent already works here: this one is an extra, not something missing.
    const quiet = !d.installed && stepOf(k === "claude" ? "codex" : "claude") === "done";
    const word = done ? tl("connect.on") : step === "unsure" ? tl("connect.st_unsure") : quiet ? tl("connect.st_missing") : tl("connect.need");
    const attn = attnOf(k) ? `<i class="cnat" role="img" aria-label="${esc(tl("connect.attn"))}" title="${esc(tl("connect.attn"))}"></i>` : "";
    const go = !done && !quiet && !u.open ? `<button class="btn sm fill press" data-cngo="${k}">${tl("connect.connect")}</button>` : "";
    const row = `<div class="cnrow${u.open ? " open" : ""}"><button type="button" class="cnrb press" data-cnopen="${k}" aria-expanded="${u.open}">
        ${agDot(k)}<span class="cnnm"><b>${esc(a.n())}</b><small class="${done ? "ok" : quiet ? "" : "warn"}">${word}${attn}</small></span>
        ${go ? "" : `<span class="cnch" aria-hidden="true">${phi("caret-down")}</span>`}</button>${go}</div>`;
    if (!u.open) return row;
    const need = needOf(k), rows = d.installed && (!need || need.keep || u.more);
    return row + `<div class="cndt${wasOpen.has(k) ? "" : " fresh"}">${need ? stepCard(need) : ""}${rows ? rowsOf(a) : ""}
      ${d.installed && !rows ? `<button type="button" class="cnlk press" data-cnmore="${k}">${tl("connect.more")}</button>` : ""}</div>`;
  }
  // The rest of the page behind one quiet row: other accounts, the first-run screen again, and
  // whether the title bar shows the connection lamp (a per-screen preference, kept in this browser).
  function extraBlock() {
    const row = `<div class="cnrow${extraOpen ? " open" : ""}"><button type="button" class="cnrb press" data-cnopen="extra" aria-expanded="${extraOpen}">
        <span class="cnmi" aria-hidden="true">${phi("dots-three")}</span><span class="cnnm"><b>${tl("connect.menu")}</b></span>
        <span class="cnch" aria-hidden="true">${phi("caret-down")}</span></button></div>`;
    if (!extraOpen) return row;
    let on = true; try { on = localStorage.getItem("loop.connpill") !== "0"; } catch (e) { /* private window */ }
    return row + `<div class="cndt${wasOpen.has("extra") ? "" : " fresh"}">
      <div class="cnfr cnpr"><span><b>${tl("acct.manage")}</b><small>${tl("acct.manage_d")}</small></span><button class="btn sm press" id="cnacctadd">${tl("acct.manage_btn")}</button></div>
      <div id="cnacct"></div>
      <div class="cnfr cnpr"><span><b>${tl("connect.flow.first")}</b></span><button class="btn sm press" id="cnfirst">${tl("acct.manage_btn")}</button></div>
      <div class="cnfr cnpr"><span><b>${tl("connpill.show")}</b><small>${tl("connpill.show.d")}</small></span>
        <button type="button" class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" aria-label="${esc(tl("connpill.show"))}" id="cnpill"></button></div>
      ${useRow()}</div>`;
  }
  // Which plan windows the lamps show (web/connuse.js): 5-hour, weekly, both or neither.
  function useRow() {
    const sh = window.ConnUse ? window.ConnUse.shown() : {};
    const use = (k) => (k === "none" ? !sh.h5 && !sh.wk : !!sh[k]);
    return `<div class="cnfr cnpr"><span><b>${tl("connuse.label")}</b></span>
        <div class="seg cnuse" role="group" aria-label="${esc(tl("connuse.label"))}">${[["h5", tl("connuse.t.h5")], ["wk", tl("connuse.t.wk")], ["none", tl("connuse.t.none")]].map(([k, n]) =>
          `<button type="button" class="press${use(k) ? " on" : ""}" data-cnuse="${k}" aria-pressed="${use(k)}">${esc(n)}</button>`).join("")}</div></div>`;
  }

  // Display only: a folder under the home folder reads from "~" (the stored value is untouched).
  const tilde = (p) => String(p).replace(/^[A-Za-z]:\\Users\\[^\\]+(?=\\|$)/, "~").replace(/^\/(?:home|Users)\/[^/]+(?=\/|$)/, "~");
  // Other accounts: each agent's extra accounts with a per-account 연결 (hook). The default
  // account is the agent's own row above, so with no extra account nothing is listed.
  async function renderAccounts(box) {
    let r;
    try { r = await get("/api/accounts"); }
    catch (e) { box.innerHTML = `<p class="cnfd">${esc(e.message)}</p>`; return; }
    let rows = "";
    ["claude", "codex"].forEach((kind) => {
      const k = r[kind] || {}, accts = k.accounts || [];
      if (!accts.length) return;
      const all = [{id: null, label: tl("acct.default"), config_dir: null, def: true}].concat(accts);
      rows += `<div class="cnph">${agDot(kind)}${kind === "claude" ? tl("connect.claude") : tl("connect.codex")}</div>`;
      rows += all.map((a) => {
        const dot = a.color ? `<span class="acdot" style="background:${esc(a.color)}"></span>` : "";
        const cur = k.current && a.config_dir && String(k.current) === String(a.config_dir);
        return `<div class="cnfr cnpr acctrow" data-kind="${kind}" data-cfg="${esc(a.config_dir || "")}">
          <span><b>${dot}${esc(a.label || a.id || tl("acct.default"))}${cur ? ` <span class="cntag">${esc(tl("acct.running"))}</span>` : ""}</b>
          <small>${esc(tilde(a.config_dir || k.default || "~"))}</small></span>
          ${state && state[kind] && state[kind].installed === false
            ? `<span class="cnst">${tl("connect.st_missing")}</span>`
            : `<button class="btn sm press" data-connect>${esc(tl("acct.connect"))}</button>`}</div>`;
      }).join("");
    });
    box.innerHTML = rows;
    box.querySelectorAll("[data-connect]").forEach((b) => b.onclick = () => {
      const row = b.closest(".acctrow"), kind = row.dataset.kind, cfg = row.dataset.cfg || null;
      post("/api/connect/apply", {agent: kind, piece: "hook", config_dir: cfg})
        .then(() => toast(tl("acct.connected"))).catch((e) => toast(e.message));
    });
  }

  let curBox = null;                         // the live settings connect view, for focus re-check

  async function render(box) {
    curBox = box;
    // One title, one line under it, one row per agent. Everything else is behind a row.
    box.innerHTML = `<h2 class="seth">${tl("connect.title")}</h2>
      <p class="setd">${tl("connect.intro")}</p>
      <div class="cnlist">${AGENTS.map(agentBlock).join("")}${extraBlock()}</div>`;
    wasOpen = new Set(["claude", "codex"].filter((k) => ui[k].open).concat(extraOpen ? ["extra"] : []));
    const acc = box.querySelector("#cnacct"); if (acc) renderAccounts(acc);
    box.querySelectorAll("[data-cndef]").forEach((sel) => sel.addEventListener("change", async () => {
      const [agent] = sel.dataset.cndef.split("/");
      const val = (part) => box.querySelector(`[data-cndef="${agent}/${part}"]`).value;
      try { defs = await post("/api/agentdefault", {agent, model: val("model"), effort: val("effort")});
        toast(tl("connect.def.saved")); await render(box); }
      catch (e) { toast(e.message); }
    }));
    // A row opens and closes its own detail; [연결하기] opens it on the step that needs doing.
    box.querySelectorAll("[data-cnopen]").forEach((b) => b.onclick = () => {
      const k = b.dataset.cnopen;
      if (k === "extra") extraOpen = !extraOpen; else { ui[k].open = !ui[k].open; if (ui[k].open) loadSide(); }
      render(box);
    });
    box.querySelectorAll("[data-cngo]").forEach((b) => b.onclick = () => {
      ui[b.dataset.cngo].open = true;
      render(box).then(() => { const el = box.querySelector(".cnstep"); if (el) el.scrollIntoView({block: "nearest"}); });
      loadSide();
    });
    box.querySelectorAll("[data-cnmore]").forEach((b) => b.onclick = () => { ui[b.dataset.cnmore].more = true; render(box); });
    box.querySelectorAll("[data-cnskip]").forEach((b) => b.onclick = () => { const [k, id] = b.dataset.cnskip.split("/"); ui[k].skip.add(id); render(box); });
    // The first-run screen again: it only shows where things stand; closing comes back here.
    const first = box.querySelector("#cnfirst");
    if (first) first.onclick = () => { try { window.LOOP_ONBOARD.connect(); } catch (e) { toast(e.message); } };
    const add = box.querySelector("#cnacctadd");
    if (add) add.onclick = () => { try { window.LOOP_ONBOARD?.connect({accounts: true}); } catch (e) { toast(e.message); } };
    const pill = box.querySelector("#cnpill");
    if (pill) pill.onclick = () => {
      const v = pill.getAttribute("aria-checked") !== "true";
      pill.classList.toggle("on", v); pill.setAttribute("aria-checked", String(v));
      try { localStorage.setItem("loop.connpill", v ? "1" : "0"); } catch (er) { /* stays for this page only */ }
      try { window.LOOP_CONNPILL.paint(); } catch (er) { /* no title bar here */ }
    };
    box.querySelectorAll("[data-cnuse]").forEach((b) => b.onclick = () => {
      try { window.ConnUse.show(b.dataset.cnuse, !b.classList.contains("on")); } catch (er) { /* no title bar here */ }
      // One press can move the others ("숫자 숨김" turns both windows off): all three are read again.
      const sh = window.ConnUse ? window.ConnUse.shown() : {};
      box.querySelectorAll("[data-cnuse]").forEach((x) => { const k = x.dataset.cnuse, v = k === "none" ? !sh.h5 && !sh.wk : !!sh[k]; x.classList.toggle("on", v); x.setAttribute("aria-pressed", String(v)); });
    });
    // Claude's end-to-end check: one sample is pushed, and the row says what came back.
    box.querySelectorAll("[data-cnftest]").forEach((b) => b.onclick = async () => {
      b.disabled = true; b.textContent = tl("connect.testing");
      try { const r = await post("/api/connect/test", {}); ctest.ok = !!r.ok; ctest.msg = r.message || (r.ok ? tl("connect.testok") : tl("connect.testfail")); }
      catch (e) { ctest.ok = false; ctest.msg = e.message || tl("connect.testfail"); }
      await render(box);
    });
    box.querySelectorAll("[data-cnpermdet]").forEach((d) => d.addEventListener("toggle", () => { permOpen[d.open ? "add" : "delete"](d.dataset.cnpermdet); }));
    // One switch: before the connection it only holds the choice, after it it is applied at once.
    box.querySelectorAll("[data-cnperm]").forEach((b) => b.onclick = async () => {
      const i = b.dataset.cnperm.indexOf("/"), agent = b.dataset.cnperm.slice(0, i), scope = b.dataset.cnperm.slice(i + 1);
      if (b.closest("[data-cnpend]")) { const p = permPick(agent); p.set(scope, !p.get(scope)); return render(box); }
      b.disabled = true;
      try { await permPost(b.classList.contains("on") ? {agent, off: [scope]} : {agent, on: [scope]}); await fetchState(); }
      catch (e) { toast(e.message); }
      await render(box);
    });
    box.querySelectorAll("[data-cnpermall]").forEach((b) => b.onclick = async () => {
      const agent = b.dataset.cnpermall; b.disabled = true;
      try { await permPost({agent, all: 1}); /* the server skips a switch the person turned off */ toast(tl("perm.done")); }
      catch (e) { toast(e.message); }
      await render(box);
    });
    box.querySelectorAll("[data-cnpermx]").forEach((b) => b.onclick = () => {
      try { localStorage.setItem(permTidyKey(b.dataset.cnpermx), "1"); } catch (e) { /* no storage: it comes back next time */ }
      render(box);
    });
    // A folder only Claude Code can be asked about: a terminal with `claude` in that folder.
    box.querySelectorAll("[data-cntf]").forEach((b) => b.onclick = async () => {
      b.disabled = true;
      try { await post("/api/connect/trust-folder", {name: b.dataset.cntf}); toast(tl("perm.cli_opened")); }
      catch (e) { toast(e.message); }
      b.disabled = false;
    });
    // [추가하기]: the pieces the step named, then (Codex) the window where the person allows it.
    box.querySelectorAll("[data-cnfwd]").forEach((b) => b.onclick = async () => {
      const agent = b.dataset.cnfwd; b.disabled = true;
      try {
        const read = !perms && cons && !cons.has(SCOPE[agent]);
        // The switches as they stood when the button was pressed, read before the lines go in.
        const pick = perms ? [...permPick(agent)] : null;
        await window.LOOP_CONNECT.applyAll(agent);
        if (read) cons = new Set(((await post("/api/consent/grant", {scope: SCOPE[agent]})).grants || []).map((g) => g.scope));
        if (pick) {
          const dflt = new Set(permItems(agent).filter((x) => x.default).map((x) => x.scope));
          await permPost({agent, on: pick.filter((x) => x[1]).map((x) => x[0]), off: pick.filter((x) => !x[1] && dflt.has(x[0])).map((x) => x[0])});
          ui[agent].perm = null;
        }
        toast(tl("connect.done"));
        if (extraOf(agent) === "trust") {
          const r = await loopFetch("/api/cli/open-trust", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({agent})});
          if (r.ok) { toast(tl("connect.trust.opened")); waitTrust(); }
        }
      } catch (e) { toast(e.message); }
      await render(box);
      try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
    });
    box.querySelectorAll("[data-cndisc]").forEach((b) => b.onclick = () => openDisc(box, b.dataset.cndisc));
    // [되돌리기]: the first run's connect, put back byte for byte from its backups. The token lives in
    // the server's memory, so it is offered once; a failed press (e.g. after a restart) drops it.
    box.querySelectorAll("[data-cnundo]").forEach((b) => b.onclick = async () => {
      const agent = b.dataset.cnundo, tok = undoTok[agent]; if (!tok) return;
      b.disabled = true;
      try { const r = await post("/api/connect/undo", {token: tok}); adopt(r.state); toast(tl("onboard.cxundone")); }
      catch (e) { toast(e.message); }
      delete undoTok[agent];
      await render(box); if (afterChange) afterChange();
      try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
    });
    box.querySelectorAll("[data-cncon]").forEach((b) => b.onclick = async () => {
      const [agent, k] = b.dataset.cncon.split("/");
      const old = b.textContent, sw = b.classList.contains("sw");   // a switch carries no label
      b.disabled = true; if (!sw) b.textContent = tl("connect.preparing");
      try { await openDiff(box, agent, k); }        // shows a sheet on success, toasts on failure
      finally { if (document.body.contains(b)) { b.disabled = false; if (!sw) b.textContent = old; } }
    });
    box.querySelectorAll("[data-cninbox]").forEach((b) => b.onclick = async () => {
      b.disabled = true;
      try {
        const r = await loopFetch("/api/connect/inbox-env", {method: "POST", headers: {"Content-Type": "application/json"}, body: "{}"});
        const j = await r.json().catch(() => ({}));
        if (j.need_consent) return;               // the person said "not now"
        toast(j.result === "written" ? tl("connect.inbox_done") : j.result === "kept" ? tl("connect.inbox_kept") : tl("connect.inbox_fail"));
        await fetchState(); await render(box);
        try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
      } catch (e) { toast(e.message); }
      finally { if (document.body.contains(b)) b.disabled = false; }
    });
    box.querySelectorAll("[data-cnrecheck]").forEach((b) => b.onclick = async () => {
      const old = b.textContent; b.disabled = true; b.textContent = tl("connect.checking");
      const before = JSON.stringify(state);
      try { await fetchState(); await render(box); try { window.LOOP_CONNPILL.check(); } catch (e) { /* optional */ }
        // Always an answer the person can see, also when nothing moved.
        toast(extraOf("codex") === "trust" && b.closest(".cntrust") ? tl("connect.trust.notyet")
          : JSON.stringify(state) !== before ? tl("connect.rechecked") : tl("connect.recheck_same")); }
      catch (e) { toast(e.message); }
      finally { if (document.body.contains(b)) { b.disabled = false; b.textContent = old; } }
    });
    box.querySelectorAll("[data-cnrm]").forEach((b) => b.onclick = async () => {
      const [agent, k] = b.dataset.cnrm.split("/"); b.disabled = true;
      try { const r = await post("/api/connect/remove", {agent, piece: k}); adopt(r.state);
        toast(tl("connect.removed")); await render(box); }
      catch (e) { toast(e.message); b.disabled = false; }
    });
  }

  // [연결]: 바뀔 내용을 diff로 보여 주는 시트, 그다음 [적용].
  async function openDiff(box, agent, piece) {
    let diff;
    try { diff = (await post("/api/connect/preview", {agent, piece})).diff; }
    catch (e) { return toast(e.message); }
    const pc = AGENTS.find((a) => a.k === agent)?.pieces.find((p) => p[0] === piece) || [, () => piece, () => ""];
    const pieceName = pc[1]();
    const what = agent === "codex" && piece === "hook" ? tl("connect.cxx_d") : pc[2]();
    sheet(`<h3>${tl("connect.applyTitle", {name: esc(pieceName)})}</h3>
      <p class="hint">${what ? esc(what) + " " : ""}${tl("connect.applySub")}</p>
      <pre class="cndiff">${esc(diff || tl("connect.noChange"))}</pre>
      <div class="sacts"><button class="btn press" data-sclose>${tl("connect.cancel")}</button>
        <button class="btn fill press" id="cnapply">${tl("connect.apply")}</button></div>`, (b) => {
      b.querySelector("#cnapply").onclick = async (e) => { e.currentTarget.disabled = true;
        try { const r = await post("/api/connect/apply", {agent, piece}); adopt(r.state);
          if (typeof closeSheet === "function") closeSheet();
          toast(tl("connect.done")); if (box) await render(box); if (afterChange) afterChange();
          // The permission poll (v2-inbox.js) learns at once that requests now come here.
          if (piece === "perm" && typeof refreshPerm === "function") { permAt = 0; refreshPerm(); } }
        catch (err) { toast(err.message); e.currentTarget.disabled = false; } };
    });
  }

  // [연결 끊기]: say what is really there first, then take out only that. Each piece answers for
  // itself: one that could not be edited safely stays as it was and is named.
  function openDisc(box, agent) {
    const a = AGENTS.find((x) => x.k === agent), name = a.n();
    const have = a.pieces.filter(([k]) => ((state[agent].pieces || {})[k] || {}).present !== false);
    sheet(`<h3>${agDot(agent)}${tl("connect.disc.t", {name: esc(name)})}</h3>
      ${have.length ? `<ul class="cndl">${have.map((x) => `<li>${esc(x[1]())}</li>`).join("")}</ul><p class="hint">${tl("connect.disc.d")}</p>`
                    : `<p class="hint">${tl("connect.disc.none", {name: esc(name)})}</p>`}
      ${agent === "codex" && cons && cons.has(SCOPE.codex) ? `<p class="hint">${tl("connect.disc.read")}</p>` : ""}
      ${perms && perms[agent] && perms[agent].held ? `<p class="hint">${tl("perm.disc", {n: perms[agent].held})}</p>` : ""}
      <div class="sacts"><button class="btn press" data-sclose>${tl("connect.cancel")}</button>
        <button class="btn danger press" id="cndiscgo">${tl("connect.remove")}</button></div>`, (b) => {
      b.querySelector("#cndiscgo").onclick = async (e) => { e.currentTarget.disabled = true;
        try {
          const r = await post("/api/connect/disconnect", {agent}); adopt(r.state);
          if (r.revoked && cons) cons.delete(r.revoked);
          (r.perms_off || []).forEach((s) => { if (cons) cons.delete(s); });
          if (perms) { const p = await timed("/api/connect/perms", 8000); if (p && p.claude) perms = p; }
          if (agent === "codex") { state.codex.talked = null; Object.assign(talk, {error: "", detail: "", just: false, missing: "", models: null}); }
          ui[agent].skip.clear(); ui[agent].perm = null;
          delete undoTok[agent];                  // nothing of that connect is left to restore
          if (typeof closeSheet === "function") closeSheet();
          const bad = (r.results || []).filter((x) => x.error);
          toast(bad.length ? tl("connect.disc.part") + " " + bad.map((x) => x.error).join(" ") : tl("connect.disc.done"));
          await render(box); if (afterChange) afterChange();
          try { window.LOOP_CONNPILL.check(); } catch (e2) { /* the pill is optional */ }
        } catch (err) { toast(err.message); e.currentTarget.disabled = false; } };
    });
  }

  // [허용] / [허용 취소] for reading an agent's past conversations, wherever it is drawn.
  window.addEventListener("click", async (e) => {
    const b = e.target && e.target.closest && e.target.closest("[data-cncons]"); if (!b || b.disabled) return;
    const [act, agent] = b.dataset.cncons.split("/");
    b.disabled = true;
    try {
      const c = await post(act === "grant" ? "/api/consent/grant" : "/api/consent/revoke", {scope: SCOPE[agent]});
      cons = new Set((c.grants || []).map((g) => g.scope));
    } catch (err) { toast(err.message); }
    finally { if (document.body.contains(b)) b.disabled = false; redraw(agent); }
  });

  // Auto re-check: when the person comes back from the terminal (window regains focus), refresh
  // the open connect view so a just-completed login flips to 연결됨 without a manual press.
  let focusAt = 0;
  window.addEventListener("focus", async () => {
    if (!curBox || !document.body.contains(curBox) || Date.now() - focusAt < 1500) return;
    focusAt = Date.now();
    const before = JSON.stringify(state);
    try { await fetchState(); } catch { return; /* offline */ }
    focusAt = Date.now();
    if (JSON.stringify(state) !== before && curBox && document.body.contains(curBox)) await render(curBox);
  });

  let afterChange = null;                   // the wizard can watch for changes

  async function draw(el) {
    const box = document.createElement("div"); box.className = "cnbox"; el.appendChild(box);
    // Detection spawns the CLIs and can take a second; show a title + line so the page is never blank.
    box.innerHTML = `<h2 class="seth">${tl("connect.title")}</h2>
      <p class="setd">${tl("connect.intro")}</p><p class="srd cnwait"><rl-orb state="thinking" size="20" aria-label="${esc(tl("connect.detecting"))}"></rl-orb><span>${tl("connect.detecting")}</span></p>`;
    // The server's own words ("boom") tell a person nothing: say what failed and offer the try again.
    try { await fetchState(); } catch (e) {
      box.innerHTML = `<h2 class="seth">${tl("connect.title")}</h2><div class="card cnnote"><p class="s">${tl("connect.failed")}</p><button class="btn sm press" data-cnretry>${tl("upd.retry")}</button></div>`;
      box.querySelector("[data-cnretry]").onclick = () => { box.remove(); draw(el); };
      return;
    }
    // The screen was drawn again while the detect ran (start-up draws it more than once): this box is gone.
    if (!box.isConnected) return;
    await render(box);
    loadSide();                               // versions and defaults fill in when they answer
    try { window.LOOP_CONNPILL.check(); } catch (e) { /* the pill is optional */ }
  }

  // The refern-style settings modal reads .page/.title; the current settings screen just calls it.
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(
    Object.defineProperty(Object.assign(draw, {page: "connect"}), "title", {get: () => tl("connect.title")}));

  async function ensure() { if (!state) { try { await fetchState(); } catch { /* offline */ } } return state; }

  // For the first-run wizard (T5): read detection and drive connect from inside the wizard, so
  // nothing has to open the settings sheet (which sits under the onboarding scrim).
  // A chat's note offers the switch where the session waits on Claude Code's own prompt.
  window.addEventListener("click", (e) => { if (e.target.closest?.("[data-pjperm]")) openDiff(null, "claude", "perm"); });   // bubbles up from the document
  window.LOOP_CONNECT = {
    // A detect that answered a moment ago is the answer (the page asks, then the pill asks right after).
    async status() { if (!cons) loadSide(); if (state && Date.now() - stateAt < 5000) return state; try { return await fetchState(); } catch { return null; } },
    async refresh() { try { return await fetchState(); } catch { return null; } },   // force a fresh detect
    // The last detect without asking again (null before the first one), so a card can draw at once.
    cached() { return state; },
    installGuide, trustGuide, permissionIntro,
    // 폰에서 허용·거절 from outside the settings page (the chat's blocked note): the same diff sheet.
    openPerm() { return openDiff(null, "claude", "perm"); },
    // The one next step for an agent: install / login / connect (Claude) / check (Codex) / done /
    // unsure ("" unknown). extra: Codex's optional part, never a step.
    step(agent, s) { return stepOf(agent, s); },
    extra(agent, s) { return extraOf(agent, s); },
    // Reading this agent's past conversations: true / false, null until the server answered.
    reads(agent) { return cons ? cons.has(SCOPE[agent]) : null; },
    loadSide,
    get talk() { return talk; },
    watch,
    set onwatch(fn) { onWatch = fn; },
    // Adopt a detect the server already ran (apply-all / undo return one), so the next draw is not
    // made from the state read before the change.
    seed(s) { adopt(s); },
    // The first run hands its [되돌리기] here, so it stays one press away in 설정 › 연결.
    keepUndo(agent, token) { if (token) undoTok[agent] = token; else delete undoTok[agent]; },
    set onchange(fn) { afterChange = fn; },
    // What the wizard shows: is the CLI here, its version, and which pieces are still missing.
    async detected(agent) { await ensure(); return state?.[agent] || null; },
    // The pieces not yet present for an installed agent (keys), or [] / null when none / not installed.
    async pendingPieces(agent) {
      await ensure();
      const d = state?.[agent]; if (!d?.installed) return null;
      const a = AGENTS.find((x) => x.k === agent) || {pieces: []};
      // MCP is optional for both agents (the hook + skill/AGENTS.md deliver comments): the safe
      // apply-all never adds it, so counting it would leave a connected agent stuck on "일부만 연결됨".
      const req = d.required || a.pieces.map((p) => p[0]).filter((k) => k !== "mcp" && k !== "mod" && k !== "perm");
      return a.pieces.filter(([k]) => req.includes(k)
        && (d.pieces[k] || {}).present !== true).map((p) => p[0]);
    },
    // One combined preview of every pending piece, so the wizard shows all changes at once.
    async previewAll(agent) {
      const ks = (await this.pendingPieces(agent)) || [];
      const out = [];
      for (const k of ks) {
        try { const d = (await post("/api/connect/preview", {agent, piece: k})).diff; if (d) out.push(d); }
        catch { /* skip a piece that cannot be previewed */ }
      }
      return out.join("\n\n");
    },
    // Apply every pending piece together (the wizard already showed the combined consent).
    async applyAll(agent) {
      const ks = (await this.pendingPieces(agent)) || [];
      for (const k of ks) { const r = await post("/api/connect/apply", {agent, piece: k}); adopt(r.state); }
      if (afterChange) afterChange();
      return state;
    },
    async test() { return await post("/api/connect/test", {}); },
    // Legacy single-piece entry (still used if something opens the settings-style sheet).
    async open(agent) {
      const a = AGENTS.find((x) => x.k === agent); if (!a) return;
      await ensure();
      const d = state?.[agent];
      if (!d?.installed) { toast(tl("connect.missing")); return; }
      const next = a.pieces.find(([k]) => (d.pieces[k] || {}).present !== true);
      openDiff(null, agent, (next || a.pieces[0])[0]);
    },
  };

  const css = document.createElement("style");
  css.textContent = `
    .cn-permission-intro{padding:12px 14px;margin:8px 0;border:1px solid var(--line,#303238);border-radius:12px;text-align:left;font-size:13px;line-height:1.6;color:var(--t2,#bfc1c5)}
    .cn-permission-intro b{color:var(--t1,#eee);font-weight:600}
    .cn-permission-intro ul{padding-left:18px;margin:8px 0}.cn-permission-intro p{margin:6px 0;overflow-wrap:anywhere}
    .cnst{font-size:13px;color:var(--t3);white-space:nowrap}
    .cnst.ok{color:#43c17a}.cnst.warn{color:var(--orange)}
    .cnst.cnwt{display:inline-flex;align-items:center;gap:6px;white-space:normal;color:var(--t2)}.cnst.cnwt .cnwd{flex:none;width:8px;height:8px;border-radius:50%;background:var(--t3)}
    .cnver{font-size:12px;color:var(--t4)}
    .cnpick .s{white-space:normal;font-size:13px;line-height:1.55;color:var(--t2)}
    .cnpick{margin-top:8px}.cnpickr{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}
    .cnlogin .s.cnq{color:var(--t3);font-size:12px}
    .cntag{font-size:12px;font-weight:600;padding:1px 8px;border-radius:999px;background:var(--btn);color:var(--t2);white-space:nowrap}
    /* one row per agent: colour, name, one status word, and a button only when something is needed */
    .cnlist{margin-top:12px;border-top:1px solid var(--line)}
    .cnrow{display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--line)}
    .cnrow.open{border-bottom-color:transparent}
    .cnrb{flex:1;min-width:0;display:flex;align-items:center;gap:12px;min-height:66px;padding:8px 4px;margin:0;background:none;border:0;
      font:inherit;color:inherit;text-align:left;cursor:pointer;border-radius:8px}
    .cnrb:focus-visible{outline:2px solid var(--blue-t,#6aa8ff);outline-offset:-2px}
    @media (hover:hover) and (pointer:fine){.cnrb:hover{background:var(--card-hi)}}
    .cnnm{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
    .cnnm b{font-size:15px;font-weight:600;color:var(--t1)}
    .cnnm small{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--t3)}
    .cnnm small.ok{color:#43c17a}html[data-theme="light"] .cnnm small.ok{color:#127a45}.cnnm small.warn{color:var(--orange)}
    .cnat{flex:none;width:7px;height:7px;border-radius:50%;background:var(--orange)}
    .cnrb .agdot{margin:0}
    .cnmi{flex:none;width:8px;height:16px;display:grid;place-items:center;color:var(--t3)}
    .cnmi svg,.cnch svg{width:16px;height:16px;fill:currentColor}
    .cnch{flex:none;display:grid;place-items:center;color:var(--t4);transition:transform .2s ease}
    .cnrow.open .cnch{transform:rotate(180deg)}
    .cnrow>.btn{flex:none;height:36px;padding:0 16px;font-size:14px}
    /* the detail under a row: fades in where it is, nothing slides */
    .cndt{padding:2px 4px 16px 26px;border-bottom:1px solid var(--line)}
    .cndt.fresh{animation:cnfade .18s ease-out}
    @keyframes cnfade{from{opacity:0}to{opacity:1}}
    .cnstep{border-radius:12px;background:var(--panel);padding:16px;margin:0 0 8px}
    .cnstt{font-size:15px;font-weight:600;color:var(--t1)}
    .cnfd{font-size:13px;line-height:1.5;color:var(--t3);margin:4px 0 0;overflow-wrap:anywhere}
    .cnsta{display:flex;align-items:center;justify-content:flex-end;gap:16px;margin-top:16px}
    .cnsta:empty{display:none}
    .cnsta .btn{height:40px;padding:0 24px;font-size:15px}
    .cnstep .cnlogin{border:0;padding:0;margin:0;background:none}
    .cnstep .cnfx .cnlogin{margin-top:8px}
    .cnstep .cntrust .cngt{display:none}
    .cnstep>.cnlk{display:inline-block;margin-top:8px}
    .cnfx{margin-top:8px;min-width:0}
    .cnlk{background:none;border:0;padding:6px 2px;margin:0;font:inherit;font-size:13px;color:var(--t3);cursor:pointer;text-decoration:none;white-space:nowrap}
    .cnlk:hover{color:var(--t1)}.cnlk:focus-visible{outline:2px solid var(--blue-t,#6aa8ff);outline-offset:2px;border-radius:4px}
    .cnnote{display:flex;align-items:center;justify-content:space-between;gap:6px 8px;flex-wrap:wrap;padding:6px 0;font-size:13px;line-height:1.5;color:var(--t3)}
    .cnnote>span:first-child{flex:1 1 200px;min-width:0;overflow-wrap:anywhere}
    .cnnote.warn>span:first-child{color:var(--orange)}
    .cnfa{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end}
    .cnfoot{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:8px}
    .cnfr{display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:13px;line-height:1.5;color:var(--t2)}
    .cnfr .sw,.cnfr .btn{flex:none}
    .cnfrc{flex:none;display:flex;align-items:center;gap:8px}
    .cnpr{padding:8px 0}.cnpr>span:first-child{min-width:0;display:flex;flex-direction:column}
    .cnpr b{font-weight:500;color:var(--t1);font-size:14px}.cnpr small{font-size:12px;line-height:1.45;color:var(--t3);overflow-wrap:anywhere}
    .cnpr small.ok{color:#43c17a}.cnpr small.bad{color:#e0616b}
    .cnph{font-size:12px;font-weight:600;color:var(--t3);margin:8px 0 2px;padding-top:8px;border-top:1px solid var(--line)}
    .cnuse{flex:none}.cnuse button{height:28px;padding:0 12px;font-size:13px}.cndefs{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.cndef gk-select,.cnfx gk-select{max-width:200px}
    /* folds inside a detail - small, quiet, no heavy borders */
    .setpage .cndet{margin:2px 0}
    .setpage .cndet>summary{list-style:none;cursor:pointer;font-size:13px;color:var(--t2);padding:8px 0;display:inline-flex;align-items:center;gap:6px}
    .setpage .cndet>summary::-webkit-details-marker{display:none}
    .setpage .cndet>summary::before{content:"▸";color:var(--t4);font-size:12px;transition:transform .15s ease}
    .setpage .cndet[open]>summary::before{transform:rotate(90deg)}
    /* Reading width: a line of text never runs the whole settings page on a PC. */
    .cnbox .setd,.cnbox .cnfd,.cnlogin .s,.cnguide .cnx,.cnalt p{max-width:520px}
    @media (prefers-reduced-motion:reduce){.cndt.fresh{animation:none}.cnch{transition:none}}
    @media (max-width:560px){.cndt{padding-left:4px}.cnsta .btn.fill{flex:1}
      .cnfr.cndef{flex-wrap:wrap}.cndef .cnfrc{flex:1 1 100%}.cndefs{flex:1;justify-content:flex-start}.cndef gk-select,.cnfx gk-select{flex:1 1 0;max-width:none}}
    .cndl{margin:4px 0 8px;padding-left:16px;font-size:14px;line-height:1.7;color:var(--t1)}
    .acdot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:8px;vertical-align:1px}
    .cndiff{white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;font-family:ui-monospace,Menlo,Consolas,monospace;
      font-size:12px;line-height:1.5;background:var(--panel,#151619);border:1px solid var(--line,#26272b);border-radius:var(--r-md);
      padding:8px 12px;max-height:46vh;overflow-y:auto;margin:2px 0;color:var(--t2)}
    .cnlogin .srow{display:flex;gap:8px;margin-top:8px}.cnlogin .srow .btn{flex:1}
    .cnlogin{border:1px solid var(--line,#26272b);border-radius:8px;padding:8px;margin:2px 0 8px;background:var(--panel,#151619)}
    .cnlogin .t{margin-bottom:2px}
    .cnguide{text-align:left;border-color:var(--ob-line,var(--line,#26272b));background:var(--ob-panel2,var(--panel,#151619))}
    .cngt{font-size:14px;font-weight:600;color:var(--ob-text,var(--t1))}
    .cnguide ol{list-style:none;margin:8px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}
    .cnguide li{display:flex;gap:8px;min-width:0;font-size:13px;line-height:1.6;color:var(--ob-dim,var(--t2))}
    .cnguide .cnn{flex:none;color:var(--ob-text,var(--t1))}
    .cnguide .cnx{min-width:0;overflow-wrap:anywhere}
    .cncmd{display:inline-flex;align-items:center;gap:6px;max-width:100%;margin:2px 0;padding:4px 4px 4px 8px;vertical-align:middle;
      border:1px solid var(--ob-line,var(--line,#26272b));border-radius:8px;background:var(--ob-bg,var(--bg,#0e0f11))}
    .cncmd code{min-width:0;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;overflow-wrap:anywhere;color:var(--ob-text,var(--t1))}
    .cncmd .btn{flex:none;height:26px;padding:0 8px;font-size:12px}
    .setpage .cnguide .srow .btn{flex:none}
    .setpage .cnlogin .srow{border:0;padding:0;min-height:0;margin-top:8px}
    .cnterm{margin:8px 0 0;padding:8px 12px;border-radius:8px;background:#0b0c0e;color:#9aa0a6;border:1px solid var(--ob-line,var(--line,#26272b));
      font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere}
    .cnterm b{color:#e8eaed;font-weight:600}
    .cnalt{margin-top:8px;font-size:12px;line-height:1.55;color:var(--ob-dim,var(--t2))}
    .cnalt>summary{cursor:pointer;color:var(--ob-dim,var(--t2))}
    .cnalt p{margin:6px 0 0;overflow-wrap:anywhere}
    .cnwait{display:flex;align-items:center;gap:8px}.cnwait rl-orb{flex:none}`;
  document.head.appendChild(css);
})();
