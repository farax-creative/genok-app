// In-app consent: one dialog for every "may I touch your files / sessions?" question, plus the
// settings page that lists what was allowed. Loaded after v2.js (uses tl, esc, ic, toast, netErr).
//
//   loopFetch(url, {method, json})  ->  parsed JSON, like get()/post(), but a 428 or a 200 body
//   carrying {need_consent} opens the dialog. [허용] / [이번만] grant and the same request is sent
//   again; [나중에] resolves with the {need_consent} body and `declined: true`, so a screen can show
//   a quiet "허용이 필요해요" state instead of an error. A request put off that way is recorded
//   (/api/consent/defer) and waits in 설정 › 연결 › 허용, where it can be turned on later.
//
// Look (a system permission sheet): a one-sentence question as the title, one line saying why,
// then [허용] (primary), [이번만 허용] (secondary) and [나중에] (tertiary). The rest (위치 /
// 되돌리는 법 / the reassurance line) waits behind [자세히], one press away, before anything is allowed. Enter = 허용, Esc = 나중에. Motion is a spring-like ease that can be interrupted
// (it is a CSS transition on state, not a timed script) and falls back to a soft fade when the
// person prefers reduced motion.
(function () {
  "use strict";

  const pending = {};       // scope -> the open dialog's promise, so two requests ask once

  // Icons for the detail list, from the shared Phosphor table.
  const SV = (k) => ic(k, "cs-i");
  const IC = {where: SV("folder"), why: SV("bulb"), undo: SV("bendBack"), safe: SV("shieldCheck"), lock: SV("lock")};

  function css() {
    if (document.getElementById("cs-css")) return;
    const s = document.createElement("style");
    s.id = "cs-css";
    s.textContent = `
    .cs-scrim{position:fixed;inset:0;z-index:400;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,0,0,0);-webkit-backdrop-filter:blur(0);backdrop-filter:blur(0);transition:background .3s ease,backdrop-filter .3s ease,-webkit-backdrop-filter .3s ease}
    .cs-scrim.in{background:rgba(0,0,0,.6);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)}
    .cs-box{width:100%;max-width:440px;box-sizing:border-box;background:var(--card);color:var(--t1);border-radius:26px 26px 0 0;padding:26px 22px calc(18px + env(safe-area-inset-bottom));transform:translateY(100%);transition:transform .24s cubic-bezier(.23,1,.32,1);max-height:92dvh;overflow:auto;outline:none;overscroll-behavior:contain;box-shadow:0 -1px 0 var(--line)}
    .cs-scrim.in .cs-box{transform:none}
    .cs-lock{width:44px;height:44px;border-radius:12px;background:var(--blue-w);color:var(--blue-t);display:grid;place-items:center;margin-bottom:16px}
    .cs-lock .cs-i{width:22px;height:22px}
    .cs-h{font-size:20px;line-height:1.35;font-weight:700;letter-spacing:-.01em;margin:0 0 16px;text-wrap:balance;word-break:keep-all;overflow-wrap:break-word}
    .cs-i{flex:none;width:18px;height:18px;fill:currentColor}
    .cs-ls{display:flex;flex-direction:column;gap:16px;margin:0 0 16px}
    .cs-why{font-size:15px;line-height:1.5;color:var(--t2,var(--t1));margin:-6px 0 8px;word-break:keep-all;overflow-wrap:anywhere}
    .cs-more{display:inline-flex;align-items:center;min-height:44px;padding:0 12px;margin:0 0 12px -12px;border-radius:8px;background:none;color:var(--t3);font-size:13px;font-weight:600}
    .cs-more:hover{color:var(--t1);background:var(--card-hi)}
    .cs-det[hidden]{display:none}
    .cs-det{animation:cs-fade .14s ease-out}
    @keyframes cs-fade{from{opacity:0}to{opacity:1}}
    .cs-it{display:flex;gap:12px;align-items:flex-start}
    .cs-it>.cs-i{color:var(--t3);margin-top:2px}
    .cs-b{min-width:0;flex:1}
    .cs-l{font-size:12px;font-weight:600;color:var(--t3);margin-bottom:4px}
    .cs-v{font-size:15px;line-height:1.5;color:var(--t1);font-weight:400;word-break:keep-all;overflow-wrap:anywhere}
    .cs-p{display:inline;font:500 12.5px/1.9 ui-monospace,SFMono-Regular,Consolas,"D2Coding",monospace;background:var(--btn);color:var(--t1);border-radius:6px;padding:2px 8px;margin:0 1px;overflow-wrap:anywhere;word-break:break-all;box-decoration-break:clone;-webkit-box-decoration-break:clone}
    .cs-safe{display:flex;gap:8px;align-items:flex-start;padding:12px 12px;border-radius:12px;background:rgba(74,196,120,.13);color:#7fdca0;font-size:14px;font-weight:600;line-height:1.45;margin:0 0 16px}
    .cs-safe .cs-i{margin-top:1px}
    .cs-safe span{overflow-wrap:anywhere}
    .cs-ok,.cs-2{display:block;width:100%;box-sizing:border-box;border-radius:12px;font-size:16px;font-weight:600;transition:background .15s ease,transform .1s ease}
    .cs-ok{height:44px;background:var(--blue);color:var(--on-blue)}
    .cs-ok:hover{filter:brightness(1.1)}
    .cs-2{height:44px;margin-top:8px;background:var(--btn);color:var(--t1);font-size:15px}
    .cs-2:hover{background:var(--btn-hi)}
    .cs-ok:active,.cs-2:active{transform:scale(.98)}
    .cs-no{display:block;margin:6px auto 0;height:40px;padding:0 20px;border-radius:8px;background:none;color:var(--t3);font-size:14px;font-weight:500}
    .cs-no:hover{color:var(--t1);background:var(--card-hi)}
    .cs-box button:focus-visible{outline:2px solid var(--blue-t);outline-offset:2px}
    .cs-note{margin:0 2px 16px;font-size:12px;line-height:1.5;color:var(--t3)}
    @media (min-width:700px){
      .cs-scrim{align-items:center}
      .cs-box{border-radius:16px;padding:28px 26px 20px;transform:scale(.98);opacity:0;transition:transform .16s ease-out,opacity .14s ease-out;box-shadow:0 24px 64px rgba(0,0,0,.5),0 0 0 1px var(--line)}
      .cs-scrim.in .cs-box{transform:none;opacity:1}
    }
    @media (prefers-reduced-motion:reduce){
      .cs-scrim,.cs-scrim.in{-webkit-backdrop-filter:none;backdrop-filter:none}
      .cs-box,.cs-scrim.in .cs-box{transform:none;transition:opacity .2s ease;opacity:0}
      .cs-det{animation:none}
      .cs-scrim.in .cs-box{opacity:1}
    }
    .cs-set .cs-none{padding:16px 0;color:var(--t3);font-size:13px}
    .cs-set .cs-all{margin:12px 0 4px}
    .cs-set .cs-acts{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
    .cs-set .cs-scope{margin:6px 0 0}
    .cs-set .setsec{text-transform:none}
    .cs-mo summary{display:flex;align-items:center;gap:7px;min-width:0;cursor:pointer;list-style:none}.cs-mo summary::-webkit-details-marker{display:none}
    .cs-mo summary .srd{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cs-mo[open] summary .srd{white-space:normal;overflow-wrap:anywhere}
    .cs-mo summary::after{content:"";flex:none;width:6px;height:6px;margin-right:4px;border-right:1.5px solid var(--t3);border-bottom:1.5px solid var(--t3);transform:translateY(-2px) rotate(45deg)}.cs-mo[open] summary::after{transform:translateY(1px) rotate(-135deg)}
    @media (pointer:coarse){.cs-mo summary{position:relative}.cs-mo summary::before{content:"";position:absolute;inset:-12px 0}}
    .cs-mo summary:hover .srd{color:var(--t2)}.cs-mo>.srd{display:block;margin-top:4px}.cs-set .srtx{min-width:0}
    .cs-set .cs-all .btn.danger{background:rgba(240,68,82,.18);color:var(--t1)}
    @media (max-width:720px){.cs-set .srow{align-items:flex-start}}`;
    document.head.appendChild(s);
  }

  // Wrap file paths in a monospace chip (they wrap on narrow screens); the rest stays plain text.
  function chips(text) {
    const re = /[~\w.:<>ㄱ-힝-]*[\\/][^\s,]*/g;
    let out = "", at = 0, m;
    while ((m = re.exec(text))) {
      out += esc(text.slice(at, m.index)) + `<code class="cs-p">${esc(m[0])}</code>`;
      at = m.index + m[0].length;
    }
    return out + esc(text.slice(at));
  }

  // The last sentence that says "your originals are safe" becomes a reassurance line of its own.
  function splitUndo(undo) {
    const parts = String(undo || "").match(/[^.!?。]+[.!?。]?/g) || [];
    const i = parts.map((p) => /건드리지 않|읽기만|읽지 않|저장하지 않|남아요|untouched|read-only|not read|not saved|not changed|not stopped|stays/.test(p)).lastIndexOf(true);
    if (i < 0) return {how: String(undo || "").trim(), safe: ""};
    const safe = parts[i].trim();
    return {how: parts.filter((_, k) => k !== i).join(" ").trim(), safe};
  }

  // The server's catalog (consent.py CATALOG) is written in Korean. In another language the same
  // scope reads from the dictionary; a scope not listed here keeps the server's own words.
  const CAT = {
    "codex.auto": () => ({title: tl("csc.cxauto.title"), what: tl("csc.cxauto.what"), where: tl("csc.cxauto.where"), why: tl("csc.cxauto.why"), undo: tl("csc.cxauto.undo")}),
    "claude.bypass": () => ({title: tl("csc.bypass.title"), what: tl("csc.bypass.what"), where: tl("csc.bypass.where"), why: tl("csc.bypass.why"), undo: tl("csc.bypass.undo")}),
    "chat.claude.bypass": () => ({title: tl("csc.chat_bypass.title"), what: tl("csc.chat_bypass.what"), where: tl("csc.chat_bypass.where"), why: tl("csc.chat_bypass.why"), undo: tl("csc.chat_bypass.undo")}),
    "chat.codex.full": () => ({title: tl("csc.chat_cxfull.title"), what: tl("csc.chat_cxfull.what"), where: tl("csc.chat_cxfull.where"), why: tl("csc.chat_cxfull.why"), undo: tl("csc.chat_cxfull.undo")}),
    "claude.rateline": () => ({title: tl("csc.claude_rateline.title"), what: tl("csc.claude_rateline.what"), where: tl("csc.claude_rateline.where"), why: tl("csc.claude_rateline.why"), undo: tl("csc.claude_rateline.undo")}),
    "claude.peer-accept": () => ({title: tl("csc.claude_peer_accept.title"), what: tl("csc.claude_peer_accept.what"), where: tl("csc.claude_peer_accept.where"), why: tl("csc.claude_peer_accept.why"), undo: tl("csc.claude_peer_accept.undo")}),
    "claude.inbox_env": () => ({title: tl("csc.claude_inbox_env.title"), what: tl("csc.claude_inbox_env.what"), where: tl("csc.claude_inbox_env.where"), why: tl("csc.claude_inbox_env.why"), undo: tl("csc.claude_inbox_env.undo")}),
    "read:claude-sessions": () => ({title: tl("csc.read_claude_sessions.title"), what: tl("csc.read_claude_sessions.what"), where: tl("csc.read_claude_sessions.where"), why: tl("csc.read_claude_sessions.why"), undo: tl("csc.read_claude_sessions.undo")}),
    "read:codex-sessions": () => ({title: tl("csc.read_codex_sessions.title"), what: tl("csc.read_codex_sessions.what"), where: tl("csc.read_codex_sessions.where"), why: tl("csc.read_codex_sessions.why"), undo: tl("csc.read_codex_sessions.undo")}),
    "dept.folder": () => ({title: tl("csc.dept_folder.title"), what: tl("csc.dept_folder.what"), where: tl("csc.dept_folder.where"), why: tl("csc.dept_folder.why"), undo: tl("csc.dept_folder.undo")}),
    "dept.files": () => ({title: tl("csc.dept_files.title"), what: tl("csc.dept_files.what"), where: tl("csc.dept_files.where"), why: tl("csc.dept_files.why"), undo: tl("csc.dept_files.undo")}),
    "session.open": () => ({title: tl("csc.session_open.title"), what: tl("csc.session_open.what"), where: tl("csc.session_open.where"), why: tl("csc.session_open.why"), undo: tl("csc.session_open.undo")}),
    "session:wake": () => ({title: tl("csc.session_wake.title"), what: tl("csc.session_wake.what"), where: tl("csc.session_wake.where"), why: tl("csc.session_wake.why"), undo: tl("csc.session_wake.undo")}),
    "session:stop": () => ({title: tl("csc.session_stop.title"), what: tl("csc.session_stop.what"), where: tl("csc.session_stop.where"), why: tl("csc.session_stop.why"), undo: tl("csc.session_stop.undo")}),
    "session:hide": () => ({title: tl("csc.session_hide.title"), what: tl("csc.session_hide.what"), where: tl("csc.session_hide.where"), why: tl("csc.session_hide.why"), undo: tl("csc.session_hide.undo")}),
    "session:branch": () => ({title: tl("csc.session_branch.title"), what: tl("csc.session_branch.what"), where: tl("csc.session_branch.where"), why: tl("csc.session_branch.why"), undo: tl("csc.session_branch.undo")}),
    "write:agent-config": () => ({title: tl("csc.write_agent_config.title"), what: tl("csc.write_agent_config.what"), where: tl("csc.write_agent_config.where"), why: tl("csc.write_agent_config.why"), undo: tl("csc.write_agent_config.undo")}),
    "read:claude-memory": () => ({title: tl("csc.read_claude_memory.title"), what: tl("csc.read_claude_memory.what"), where: tl("csc.read_claude_memory.where"), why: tl("csc.read_claude_memory.why"), undo: tl("csc.read_claude_memory.undo")}),
    "read:agent-config": () => ({title: tl("csc.read_agent_config.title"), what: tl("csc.read_agent_config.what"), where: tl("csc.read_agent_config.where"), why: tl("csc.read_agent_config.why"), undo: tl("csc.read_agent_config.undo")}),
    "read:workspace-docs": () => ({title: tl("csc.read_workspace_docs.title"), what: tl("csc.read_workspace_docs.what"), where: tl("csc.read_workspace_docs.where"), why: tl("csc.read_workspace_docs.why"), undo: tl("csc.read_workspace_docs.undo")}),
    "read:scheduled-tasks": () => ({title: tl("csc.read_scheduled_tasks.title"), what: tl("csc.read_scheduled_tasks.what"), where: tl("csc.read_scheduled_tasks.where"), why: tl("csc.read_scheduled_tasks.why"), undo: tl("csc.read_scheduled_tasks.undo")}),
    "write:scheduled-tasks": () => ({title: tl("csc.write_scheduled_tasks.title"), what: tl("csc.write_scheduled_tasks.what"), where: tl("csc.write_scheduled_tasks.where"), why: tl("csc.write_scheduled_tasks.why"), undo: tl("csc.write_scheduled_tasks.undo")}),
    "read:render-farm": () => ({title: tl("csc.read_render_farm.title"), what: tl("csc.read_render_farm.what"), where: tl("csc.read_render_farm.where"), why: tl("csc.read_render_farm.why"), undo: tl("csc.read_render_farm.undo")}),
    "run:codex": () => ({title: tl("csc.run_codex.title"), what: tl("csc.run_codex.what"), where: tl("csc.run_codex.where"), why: tl("csc.run_codex.why"), undo: tl("csc.run_codex.undo")}),
    "read:3d-apps": () => ({title: tl("csc.read_3d_apps.title"), what: tl("csc.read_3d_apps.what"), where: tl("csc.read_3d_apps.where"), why: tl("csc.read_3d_apps.why"), undo: tl("csc.read_3d_apps.undo")}),
    "run:3d-render": () => ({title: tl("csc.run_3d_render.title"), what: tl("csc.run_3d_render.what"), where: tl("csc.run_3d_render.where"), why: tl("csc.run_3d_render.why"), undo: tl("csc.run_3d_render.undo")}),
    "write:render-output": () => ({title: tl("csc.write_render_output.title"), what: tl("csc.write_render_output.what"), where: tl("csc.write_render_output.where"), why: tl("csc.write_render_output.why"), undo: tl("csc.write_render_output.undo")}),
    "write:agent-permissions": () => ({title: tl("csc.write_agent_permissions.title"), what: tl("csc.write_agent_permissions.what"), where: tl("csc.write_agent_permissions.where"), why: tl("csc.write_agent_permissions.why"), undo: tl("csc.write_agent_permissions.undo")}),
  };
  const loc = (need) => (LANG() === "ko" || !need || !CAT[need.scope] ? need : Object.assign({}, need, CAT[need.scope]()));
  // "what" reads as a noun phrase; the server may send a finished question as `title`.
  function titleOf(need) {
    return need.title || (need.what ? tl("consent.q", {what: need.what}) : tl("consent.cap"));
  }

  // Ask once; resolves "always" | "once" | null (cancelled).
  function ask(need) {
    need = loc(need);
    const key = need.scope || "?";
    if (pending[key]) return pending[key];
    css();
    const p = new Promise((resolve) => {
      const back = document.activeElement;
      const el = document.createElement("div");
      el.className = "cs-scrim";
      const {how, safe} = splitUndo(need.undo);
      const item = (icon, label, html) => html ? `<div class="cs-it">${IC[icon]}<div class="cs-b"><div class="cs-l">${label}</div><div class="cs-v">${html}</div></div></div>` : "";
      const title = titleOf(need);
      // One line on the face: the first sentence of the reason. A longer reason is whole behind [자세히].
      const whyAll = String(need.why || "").trim();
      const why1 = (whyAll.match(/^[^.!?。]+[.!?。]?/) || [""])[0].trim();
      // A read scope's one-time pass holds until the app closes (sessions_import._probe): say so.
      const stay = need.once === "session";
      el.innerHTML = `<div class="cs-box" role="dialog" aria-modal="true" aria-labelledby="cs-t" tabindex="-1">
        <div class="cs-lock">${IC.lock}</div>
        <h2 class="cs-h" id="cs-t">${esc(title)}</h2>
        ${why1 ? `<p class="cs-why">${esc(why1)}</p>` : ""}
        <p class="cs-why">${tl("consent.remember.hint")}</p>
        <button class="cs-more press" data-more aria-expanded="false" aria-controls="cs-det">${tl("connect.more")}</button>
        <div class="cs-det" id="cs-det" hidden>
          <div class="cs-ls">${item("where", tl("consent.where"), chips(need.where || ""))}${whyAll !== why1 ? item("why", tl("consent.why"), esc(whyAll.slice(why1.length).trim())) : ""}${item("undo", tl("consent.undo"), esc(how))}</div>
          ${safe ? `<div class="cs-safe">${IC.safe}<span>${esc(safe)}</span></div>` : ""}
          <p class="cs-note">${tl("consent.note.undo")}</p>
        </div>
        <button class="cs-ok press" data-a="always">${tl("consent.allow")}</button>
        <button class="cs-2 press" data-a="once">${stay ? tl("consent.stay") : tl("consent.once")}</button>
        <button class="cs-no press" data-a="no">${tl("consent.cancel")}</button>
      </div>`;
      document.body.appendChild(el);
      const box = el.firstElementChild;
      let done = false;
      // `later`: the person put the question off themselves (the button, Esc, a press outside).
      const finish = (ans, later) => {
        if (done) return;
        done = true;
        if (later && need.scope) send("/api/consent/defer", {json: {scope: need.scope}}).then(() => count(true)).catch(() => {});
        el.classList.remove("in");
        document.removeEventListener("keydown", onKey, true);
        removeEventListener("hashchange", onLeave);
        delete pending[key];
        setTimeout(() => el.remove(), RM() ? 220 : 420);
        if (back && back.isConnected) back.focus({preventScroll: true});
        resolve(ans);
      };
      const onKey = (e) => {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(null, true); return; }
        if (e.key === "Enter" && !e.target.closest("button")) { e.preventDefault(); e.stopPropagation(); finish("always"); return; }
        if (e.key !== "Tab") return;
        const f = [...box.querySelectorAll("button")];
        const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && (document.activeElement === a || document.activeElement === box)) { e.preventDefault(); z.focus(); }
        else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      };
      document.addEventListener("keydown", onKey, true);
      // Leaving the screen that asked (back, a shortcut) is a cancel: the question used to stay
      // over whatever screen came next.
      const onLeave = () => finish(null);
      addEventListener("hashchange", onLeave);
      el.onclick = (e) => {
        if (e.target === el) return finish(null, true);
        // [자세히] opens the facts in place (a button, so Enter on it does not grant).
        const more = e.target.closest("[data-more]");
        if (more) {
          const det = box.querySelector(".cs-det"), open = det.hidden;
          det.hidden = !open; more.setAttribute("aria-expanded", String(open));
          return;
        }
        const b = e.target.closest("[data-a]");
        if (b) b.dataset.a === "no" ? finish(null, true) : finish(b.dataset.a);
      };
      // Focus the primary button so Enter confirms and the focus ring shows for keyboard users.
      requestAnimationFrame(() => { el.classList.add("in"); box.querySelector(".cs-ok").focus({preventScroll: true}); });
    });
    pending[key] = p;
    return p;
  }

  async function send(url, opts) {
    const o = Object.assign({cache: "no-store"}, opts);
    if (o.json !== undefined) {
      o.method = o.method || "POST";
      o.headers = Object.assign({"Content-Type": "application/json"}, o.headers);
      o.body = JSON.stringify(o.json);
      delete o.json;
    }
    let r;
    try { r = await (typeof tagFetch === "function" ? tagFetch : fetch)(url, o); } catch (e) { throw netErr(); }
    const j = await r.json().catch(() => ({}));
    return {r, j};
  }

  async function loopFetch(url, opts) {
    for (let round = 0; round < 3; round++) {
      const {r, j} = await send(url, opts);
      const need = j && j.need_consent;
      if (!need) {
        if (!r.ok) throw Object.assign(srvErr(j.error), {code: j.code});
        return j;
      }
      const ans = await ask(need);
      if (!ans) return Object.assign({}, j, {declined: true});
      // Grant, then send the very same request again.
      const g = await send("/api/consent/grant", {json: {scope: need.scope, remember: ans === "always"}});
      if (!g.r.ok) throw new Error(g.j.error || tl("get.1"));
    }
    throw new Error(tl("consent.loop"));
  }
  window.loopFetch = loopFetch;
  window.loopConsentAsk = ask;
  window.loopConsentLoc = loc;

  // ---------------------------------------------------------------- settings page (연결 › 허용)
  // Two lists from /api/consent: what was allowed (each revocable, or all at once after a
  // confirmation drawn in the page) and what was put off with [나중에] (each can be turned on here).
  let later = null, laterAt = 0;            // requests waiting in 미뤄 둔 것; null before the first read
  function paintCount() {
    document.querySelectorAll("[data-setlater]").forEach((el) => {
      el.hidden = !later; el.textContent = later || "";
      if (later) { el.title = tl("consent.later.n", {n: later}); el.setAttribute("aria-label", el.title); }
    });
  }
  function took(d) { later = (d.deferred || []).length; laterAt = Date.now(); paintCount(); return d; }
  // The small count beside 연결 in the settings menu. Read again at most every few seconds.
  function count(force) {
    paintCount();
    if (!force && Date.now() - laterAt < 5000) return;
    laterAt = Date.now();
    get("/api/consent").then(took).catch(() => {});
  }
  window.LOOP_CONSENT = {count};

  function draw(c) {
    css();
    c.innerHTML = `<h2 class="seth">${tl("consent.title")}</h2><p class="setd">${tl("consent.desc")}</p>
      <div class="cs-set" id="cs-list"><div class="cs-none">${loadingHtml(tl("consent.loading"), {quiet: true})}</div></div>`;
    const list = c.querySelector("#cs-list");
    let last = {}, asking = false;          // asking: the 모두 철회 confirmation is open
    // Display only: a folder under the home folder reads from "~", so rows with the same title
    // (one per trusted folder) stay short enough to tell apart.
    const tilde = (p) => String(p).replace(/^[A-Za-z]:[\\/]Users[\\/][^\\/]+(?=[\\/]|$)/, "~").replace(/^\/(?:home|Users)\/[^/]+(?=\/|$)/, "~");
    // The lab keeps a row to its title and place; how to undo it (or why it was asked) unfolds.
    const fold = document.documentElement.classList.contains("lab");
    const row = (g, more, ctl) => `<div class="srow"><span class="srtx"><span class="srt">${esc(g.what || g.scope)}</span>
          ${more && fold ? `<details class="cs-mo"><summary class="press" title="${tl("connect.more")}"><span class="srd">${esc(tilde(g.where || "")) || tl("connect.more")}</span></summary><span class="srd">${more}</span></details>`
            : `<span class="srd">${esc(tilde(g.where || ""))}</span>${more ? `<span class="srd">${more}</span>` : ""}`}</span>
          <span class="srctl">${ctl}</span></div>`;
    const paint = (d) => {
      last = took(d);
      const rows = (d.grants || []).map(loc), wait = (d.deferred || []).map(loc);
      if (!rows.length) asking = false;
      list.innerHTML = `<div class="setsec">${tl("consent.remembered")}${rows.length && !asking ? `<button class="lnk press" data-all>${tl("consent.all")}</button>` : ""}</div>`
        + (asking ? `<div class="setcard cs-all" role="group" aria-labelledby="cs-allq"><div class="srt" id="cs-allq">${tl("consent.all.q", {n: rows.length})}</div>
          <p class="setd">${tl("consent.all.d")}</p>
          <div class="cs-acts"><button class="btn sm press" data-allno>${tl("consent.all.no")}</button><button class="btn sm danger press" data-allyes>${tl("consent.all")}</button></div></div>` : "")
        + (rows.length ? rows.map((g) => row(g, g.undo ? `${tl("consent.undo")}: ${esc(g.undo)}` : "",
            `<button class="btn sm press" data-revoke="${esc(g.scope)}">${tl("consent.revoke")}</button>`)).join("")
          : `<div class="cs-none">${tl("consent.empty")}</div>`)
        + `<p class="setd cs-scope">${tl("consent.all.scope")}</p>`
        // Nothing put off: the section is not drawn at all.
        + (wait.length ? `<div class="setsec">${tl("consent.later")}</div><p class="setd">${tl("consent.later.d")}</p>` + wait.map((g) => row(g, g.why ? `${tl("consent.why")}: ${esc(g.why)}` : "",
            `<button class="btn sm fill press" data-on="${esc(g.scope)}">${tl("consent.later.on")}</button>`)).join("")
          : "");
    };
    get("/api/consent").then(paint)
      .catch((e) => { list.innerHTML = `<div class="cs-none">${esc(e.message)}</div>`; });
    const focus = (q) => { const el = list.querySelector(q); if (el) el.focus({preventScroll: true}); };
    list.onclick = async (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      const d = b.dataset;
      // 모두 철회 asks once more, in the page: the confirmation opens on the safe answer.
      if ("all" in d) { asking = true; paint(last); focus("[data-allno]"); return; }
      if ("allno" in d) { asking = false; paint(last); focus("[data-all]"); return; }
      if (!("allyes" in d) && !d.revoke && !d.on) return;
      b.disabled = true;
      try {
        if ("allyes" in d) { asking = false; const got = await post("/api/consent/revoke-all", {}); paint(got); toast((got.grants || []).length ? tl("consent.all.some") : tl("consent.all.done")); }
        else if (d.revoke) { paint(await post("/api/consent/revoke", {scope: d.revoke})); toast(tl("consent.revoked")); }
        else { paint(await post("/api/consent/grant", {scope: d.on, remember: true})); toast(tl("consent.later.done")); }
      } catch (err) { toast(err.message); b.disabled = false; }
    };
  }
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "consent", icon: "shield", title: "consent.title", draw});
})();
