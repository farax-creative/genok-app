// The menu a right click opens on a row of the chat list (web/project.js draws and wires it).
// This file owns the two pieces of arithmetic behind it, pure and tested in tests/ctxmenu.test.js:
// where the menu goes for a point on the screen, and which choice an arrow key lands on.
(function () {
  "use strict";

  // A menu w x h opened at (x, y) in a window W x H, kept `m` from every edge. It hangs down and
  // to the right of the point; with no room there it flips to the other side of the point, and a
  // menu taller or wider than the window is pinned to the margin (it scrolls inside).
  // With `row` ({top, bottom}: the pressed row, for a finger) it hangs under the row, or above it
  // when the room below is short, so the row stays in view; with no room either side it takes
  // the roomier one, pinned to the margin.
  function place(x, y, w, h, W, H, m, row) {
    m = m || 0;
    const right = x + w <= W - m;
    let below = y + h <= H - m, at = y;
    if (row) {
      const gap = 4, fitsBelow = row.bottom + gap + h <= H - m, fitsAbove = row.top - gap - h >= m;
      below = fitsBelow || (!fitsAbove && H - row.bottom >= row.top);
      at = below ? row.bottom + gap : row.top - gap;
    }
    const left = Math.max(m, Math.min(right ? x : x - w, W - w - m));
    const top = Math.max(m, Math.min(below ? at : at - h, H - h - m));
    return {left: Math.round(left), top: Math.round(top), right, below};
  }

  // The choice a key moves to: `n` choices, `i` the one that has the keyboard (-1: none yet).
  // Down and up go round, Home and End jump. -1 for a key that is not one of these.
  function step(n, i, key) {
    if (!(n > 0)) return -1;
    if (key === "ArrowDown") return i < 0 ? 0 : (i + 1) % n;
    if (key === "ArrowUp") return i < 0 ? n - 1 : (i - 1 + n) % n;
    if (key === "Home") return 0;
    if (key === "End") return n - 1;
    return -1;
  }

  const api = {place, step};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.PjCtx = api;
})();
