// Morning digest ("아침 검토함"), as a Genok extension screen + home card.
//
// Everything that changed since the person last looked, as a queue of review cards you swipe
// through. Attaches through the app's extension hooks (the loader consumes these):
//   window.LOOP_TABS.push({id, label, icon, draw(el)})       - the full screen (the queue)
//   window.LOOP_HOME_CARDS.push({id, title, draw(el)})       - the home card (two counts)
//
// App globals used with safe fallbacks: get, post, toast, esc, ic. The card's 맞아/아직 posts
// to the app's own /api/directive - the same endpoint the item view uses - so a verdict here
// and a verdict there are the same act. Motion: a real spring for snap-back and card-in, a
// 1:1 drag that carries its release velocity into the fling-out, and a plain fade under
// prefers-reduced-motion.

(function () {
  "use strict";
  // Inline copy in two languages (these extension files carry their own text, not i18n keys).
  const L = (ko, en) => (window.I18N_LANG === "en" ? en : ko);
  if (window.__digestExt) return;
  window.__digestExt = true;

  const _get = typeof get === "function" ? get : (p) => fetch(p, { cache: "no-store" }).then((r) => r.json());
  const _post = typeof post === "function" ? post : (p, b) => fetch(p, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b),
  }).then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || L("불러오지 못했어요", "Could not load")); return j; });
  const _toast = typeof toast === "function" ? toast : (m) => { try { console.log(m); } catch (e) {} };
  const _esc = typeof esc === "function" ? esc : (s) => String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  // What a project (or a group) is called on screen: the display name a person gave it (v2.js).
  const _pn = (n) => typeof pname === "function" ? pname(n) : n;
  const _ic = typeof ic === "function" ? ic : () => "";
  const RM = () => window.matchMedia && window.matchMedia("(prefers-reduced-motion:reduce)").matches;

  const DAY = 86400;
  const md = (t) => { const x = new Date(t); return `${x.getMonth() + 1}/${x.getDate()}`; };
  const ago = (iso) => {
    const t = Date.parse((iso || "").replace(" ", "T"));
    if (!t) return "";
    const s = (Date.now() - t) / 1000;
    if (s < 90) return L("방금", "just now");
    if (s < 3600) return L(`${Math.round(s / 60)}분 전`, `${Math.round(s / 60)}m ago`);
    if (s < DAY) return L(`${Math.round(s / 3600)}시간 전`, `${Math.round(s / 3600)}h ago`);
    if (s < 7 * DAY) return L(`${Math.round(s / DAY)}일 전`, `${Math.round(s / DAY)}d ago`);
    return md(t);
  };

  // ---- a small spring integrator: x -> target, carrying an initial velocity -----------------
  // Critically-ish damped; onFrame(x) each step, onDone() at rest. Returns a cancel fn.
  function spring(x, target, vel, onFrame, onDone, opts) {
    opts = opts || {};
    const stiff = opts.stiffness || 210, damp = opts.damping || 24, mass = opts.mass || 1;
    let v = vel || 0, cur = x, raf = 0, last = 0, stopped = false;
    const step = (now) => {
      if (stopped) return;
      const dt = Math.min(last ? (now - last) / 1000 : 1 / 60, 1 / 30);
      last = now;
      const f = -stiff * (cur - target) - damp * v;
      v += (f / mass) * dt;
      cur += v * dt;
      if (Math.abs(v) < 0.5 && Math.abs(cur - target) < 0.5) {
        onFrame(target); if (onDone) onDone(); return;
      }
      onFrame(cur);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => { stopped = true; if (raf) cancelAnimationFrame(raf); };
  }

  // ---- CSS (namespaced .dg, from the app's tokens with fallbacks) ---------------------------
  const CSS = `
.dg{--d-card:var(--card,#16171a);--d-card2:var(--card-hi,#1d1e22);--d-btn:var(--btn,#222327);
  --d-btn2:var(--btn-hi,#2a2b30);--d-line:var(--line,rgba(255,255,255,.08));
  --d-t1:var(--t1,#efe9dc);--d-t2:var(--t2,#b0b1b8);--d-t3:var(--t3,#8c8d95);
  --d-blue:var(--blue,#5e6ad2);--d-green:var(--green,#1fc67a);--d-orange:var(--orange,#fe9800);
  --d-red:var(--red,#f04452);--d-r:var(--r-card,14px);--d-spring:cubic-bezier(.34,1.4,.64,1);
  color:var(--d-t1);max-width:760px;margin:0 auto;}
.dg *{box-sizing:border-box;}
.dg-head{display:flex;align-items:center;gap:12px;padding:2px 2px 16px;}
.dg-head .sp{flex:1;}
.dg-count{font-size:13px;color:var(--d-t3);font-variant-numeric:tabular-nums;}
.dg-seen{height:34px;padding:0 16px;border-radius:8px;border:1px solid var(--d-line);
  background:var(--d-btn);color:var(--d-t1);font-size:13px;font-weight:600;cursor:pointer;
  transition:background .18s ease,transform .18s var(--d-spring);}
.dg-seen:hover{background:var(--d-btn2);}
.dg-seen:active{transform:scale(.96);}
.dg-stage{position:relative;touch-action:pan-y;min-height:360px;}
.dg-slot{position:absolute;inset:0;}
.dg-card{background:var(--d-card);border:1px solid var(--d-line);border-radius:var(--d-r);
  overflow:hidden;will-change:transform,opacity;}
.dg-peek{position:absolute;inset:0;transform:scale(.94) translateY(14px);opacity:.5;
  pointer-events:none;}
/* the peek is only an edge under the top card: never taller than it, and its link is not shown,
   so no dead "항목 열기" sits below the real one */
.dg-peek .dg-card{height:100%;box-sizing:border-box;}
.dg-peek .dg-open{visibility:hidden;}
.dg-ch{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 8px;padding:16px 16px 4px;}
.dg-dept{font-size:12px;font-weight:700;color:var(--d-blue);background:rgba(94,106,210,.14);
  padding:2px 8px;border-radius:6px;}
.dg-ch h2{margin:0;font-size:16.5px;font-weight:700;letter-spacing:-.01em;flex:1;min-width:120px;word-break:keep-all;overflow-wrap:anywhere;}
.dg-ver{font-size:12px;color:var(--d-t3);font-variant-numeric:tabular-nums;}
.dg-when{padding:0 16px 8px;font-size:12px;color:var(--d-t3);}
.dg-ba{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:4px 16px 12px;}
.dg-ba.one{grid-template-columns:1fr;}
.dg-ba figure{margin:0;background:var(--d-btn);border-radius:8px;overflow:hidden;border:1px solid var(--d-line);}
.dg-ba figcaption{font-size:11.5px;font-weight:600;color:var(--d-t3);padding:8px 12px 4px;}
.dg-ba figcaption.now{color:var(--d-green);}
.dg-ba .im{aspect-ratio:4/3;background:var(--d-card2);display:flex;align-items:center;justify-content:center;overflow:hidden;}
.dg-ba .im img{width:100%;height:100%;object-fit:contain;display:block;}
.dg-ba .im .none{font-size:12px;color:var(--d-t3);padding:20px;text-align:center;}
.dg-summary{padding:2px 16px 12px;font-size:14px;line-height:1.55;color:var(--d-t2);}
.dg-summary b{color:var(--d-t1);}
.dg-later{margin:0 16px 12px;padding:8px 12px;border-radius:8px;background:rgba(254,152,0,.1);
  color:var(--d-t2);font-size:12px;line-height:1.45;}
.dg-sec{border-top:1px solid var(--d-line);padding:12px 16px;}
.dg-sec h3{margin:0 0 8px;font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--d-t3);}
.dg-dir{display:flex;align-items:center;gap:8px;padding:8px 0;}
.dg-dir.done{opacity:.5;}
.dg-dtx{flex:1;font-size:13px;line-height:1.45;color:var(--d-t1);min-width:0;}
.dg-dbtns{display:flex;gap:6px;flex:none;}
.dg-dbtns button{height:30px;padding:0 12px;border-radius:8px;font-size:13px;font-weight:600;
  border:1px solid var(--d-line);cursor:pointer;transition:transform .16s var(--d-spring),background .16s ease;}
.dg-dbtns button:active{transform:scale(.94);}
.dg-yes{background:rgba(31,198,122,.16);color:var(--d-green);border-color:transparent!important;}
.dg-no{background:var(--d-btn);color:var(--d-t2);}
.dg-done-tag{font-size:12px;font-weight:600;color:var(--d-green);flex:none;}
.dg-ask{padding:8px 0;}
.dg-ask .q{font-size:13px;font-weight:600;color:var(--d-t1);margin-bottom:6px;}
.dg-opts{display:flex;flex-wrap:wrap;gap:6px;}
.dg-opts span{font-size:12px;color:var(--d-t2);background:var(--d-btn);border:1px solid var(--d-line);
  padding:4px 8px;border-radius:8px;}
.dg-opts span.rec{color:var(--d-blue);border-color:var(--d-blue);}
.dg-open{display:flex;align-items:center;justify-content:center;gap:6px;padding:12px;
  border-top:1px solid var(--d-line);color:var(--d-t2);font-size:13px;font-weight:600;
  text-decoration:none;cursor:pointer;}
.dg-open:hover{color:var(--d-t1);}
.dg-open svg{width:16px;height:16px;}
.dg-nav{display:flex;align-items:center;gap:12px;padding:16px 2px 2px;}
.dg-nav button{height:40px;flex:1;border-radius:11px;border:1px solid var(--d-line);
  background:var(--d-btn);color:var(--d-t1);font-size:14px;font-weight:600;cursor:pointer;
  transition:background .16s ease,transform .16s var(--d-spring);}
.dg-nav button:hover{background:var(--d-btn2);}
.dg-nav button:active{transform:scale(.97);}
.dg-nav button:disabled{opacity:.4;cursor:default;}
.dg-dots{display:flex;gap:4px;justify-content:center;align-items:center;flex-wrap:wrap;max-width:180px;}
.dg-dots i{width:6px;height:6px;border-radius:50%;background:var(--d-btn2);transition:background .2s ease,transform .2s var(--d-spring);}
.dg-dots i.on{background:var(--d-blue);transform:scale(1.4);}
.dg-empty{background:var(--d-card);border:1px solid var(--d-line);border-radius:var(--d-r);
  padding:44px 20px;text-align:center;color:var(--d-t2);}
.dg-empty .big{font-size:40px;margin-bottom:8px;}
.dg-empty h2{margin:0 0 6px;font-size:16px;font-weight:700;color:var(--d-t1);}
.dg-empty p{margin:0;font-size:13px;color:var(--d-t3);line-height:1.5;}
.dg-loading{padding:40px;text-align:center;color:var(--d-t3);font-size:13px;}
/* home card */
.dg-home{padding:2px 0;}
.dg-home .row{display:flex;gap:16px;flex-wrap:wrap;}
.dg-home .stat{display:flex;flex-direction:column;gap:2px;}
.dg-home .n{font-size:38px;font-weight:750;letter-spacing:-.03em;line-height:1;}
.dg-home .n.warn{color:var(--d-orange);}
.dg-home .lb{font-size:12px;color:var(--d-t3);}
.dg-home .cta{margin-top:16px;font-size:12px;color:var(--d-blue);font-weight:600;}
.dg-home .none{font-size:13px;color:var(--d-t3);line-height:1.5;}
@media (max-width:420px){.dg-ba{grid-template-columns:1fr 1fr;}.dg-ch h2{font-size:15.5px;}
  .dg-home .n{font-size:32px;}}
@media (prefers-reduced-motion:reduce){
  .dg-card,.dg-seen,.dg-nav button,.dg-dbtns button{transition:opacity .25s ease!important;transform:none!important;}
}`;

  function injectCss() {
    if (document.getElementById("dg-style")) return;
    const s = document.createElement("style");
    s.id = "dg-style";
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  // ---- home card ----------------------------------------------------------------------------
  // Home draws its cards twice on boot; the counts are shared for a few seconds.
  let homeMemo = null, homeAt = 0;
  function drawHome(el) {
    injectCss();
    el.innerHTML = `<div class="dg dg-home">${loadingHtml("", {quiet: true})}</div>`;
    if (!homeMemo || Date.now() - homeAt > 5000) {
      homeAt = Date.now();
      homeMemo = _get("/api/digest?counts=1");
      homeMemo.catch(() => { homeMemo = null; });
    }
    homeMemo.then((d) => renderHome(el, d.counts || {})).catch(() => { el.innerHTML = ""; });
  }

  function renderHome(el, c) {
    const nw = c.new || 0, wt = c.waiting || 0;
    if (!nw && !wt) {
      el.innerHTML = `<div class="dg dg-home"><p class="none">${L("지난번 본 뒤로 바뀐 게 없어요", "Nothing changed since you last looked")}</p></div>`;
      return;
    }
    el.innerHTML = `<div class="dg dg-home">
      <div class="row">
        <div class="stat"><span class="n">${nw}</span><span class="lb">${L("새로 바뀐 것", "Newly changed")}</span></div>
        <div class="stat"><span class="n ${wt ? "warn" : ""}">${wt}</span><span class="lb">${L("확인 기다리는 수정", "Fixes to confirm")}</span></div>
      </div>
      <div class="cta">${L("검토함 열기", "Open Review box")} →</div>
    </div>`;
    const go = el.querySelector(".dg-home");
    if (go) { go.style.cursor = "pointer"; go.onclick = () => { location.hash = "digest"; }; }
  }

  // ---- full screen: the queue ---------------------------------------------------------------
  let S = null;   // {el, cards, i, marker}

  function drawTab(el) {
    injectCss();
    el.innerHTML = `<div class="dg">${loadingHtml("", {fill: true})}</div>`;
    _get("/api/digest").then((d) => {
      S = { el, cards: d.cards || [], i: 0, marker: d.marker };
      renderTab();
    }).catch((e) => {
      el.innerHTML = `<div class="dg"><div class="dg-loading">${_esc(e.message || L("불러오지 못했어요", "Could not load"))}</div></div>`;
    });
  }

  function renderTab() {
    const el = S.el;
    if (!S.cards.length) { renderEmpty(); return; }
    if (S.i >= S.cards.length) S.i = S.cards.length - 1;
    el.innerHTML = `<div class="dg">
      <div class="dg-head">
        <span class="dg-count" id="dg-count"></span><span class="sp"></span>
        <button class="dg-seen" id="dg-seen">${L("다 봤어요", "All seen")}</button>
      </div>
      <div class="dg-stage" id="dg-stage"></div>
      <div class="dg-nav">
        <button data-prev>${L("이전", "Back")}</button>
        <div class="dg-dots" id="dg-dots"></div>
        <button data-next>${L("다음", "Next")}</button>
      </div>
    </div>`;
    mountStage();
    updateChrome();
    el.querySelector("#dg-seen").onclick = markSeen;
    el.querySelector("[data-prev]").onclick = () => step(-1);
    el.querySelector("[data-next]").onclick = () => step(1);
    bindKeys();
  }

  function renderEmpty() {
    S.el.innerHTML = `<div class="dg">
      <div class="dg-empty">
        <div class="big">${_ic ? "" : ""}✓</div>
        <h2>${L("다 봤어요", "All seen")}</h2>
        <p>${L("새 버전이 올라오면 여기 쌓여요", "New versions collect here")}</p>
      </div>
    </div>`;
  }

  function cardHTML(c) {
    const im = (f, now) => {
      const src = f && (f.thumb || f.url);
      return `<figure><figcaption class="${now ? "now" : ""}">${now ? L("새 ", "New ") + _esc(c.v) : (c.prevV ? L("이전 ", "Before ") + _esc(c.prevV) : L("이전", "Before"))}</figcaption>
        <div class="im">${src ? `<img src="${_esc(src)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'none',textContent:'${L("미리보기 없음", "No preview")}'}))">`
          : `<div class="none">${now && c.fileCount === 0 ? L("링크 결과물", "Link result") : L("미리보기 없음", "No preview")}</div>`}</div></figure>`;
    };
    const ba = c.prev
      ? `<div class="dg-ba">${im(c.prev, false)}${im(c.cur, true)}</div>`
      : `<div class="dg-ba one">${im(c.cur, true)}</div>`;
    const fixed = (c.claimed || []).length ? `<div class="dg-sec">
      <h3>${L("고쳤다고 한 수정", "Fixes reported done")} ${c.claimed.length}</h3>
      ${c.claimed.map((d) => `<div class="dg-dir" data-id="${_esc(d.id)}">
        <span class="dg-dtx">${_esc(d.text || "")}</span>
        <div class="dg-dbtns"><button class="dg-yes" data-act="ok">${L("확인", "OK")}</button><button class="dg-no" data-act="no">${L("다시", "Again")}</button></div>
      </div>`).join("")}</div>` : "";
    const asks = (c.asks || []).length ? `<div class="dg-sec">
      <h3>${L("물어본 것", "Questions")} ${c.asks.length}</h3>
      ${c.asks.map((a) => `<div class="dg-ask">
        <div class="q">${_esc(a.q || "")}</div>
        ${(a.options || []).length ? `<div class="dg-opts">${a.options.map((o, k) =>
          `<span class="${a.rec === k ? "rec" : ""}">${_esc(o)}${a.rec === k ? " ✓" : ""}</span>`).join("")}</div>` : ""}
      </div>`).join("")}</div>` : "";
    const later = c.later ? `<div class="dg-later">${L("남은 요청을 뒤로 미룬 이유", "Why the rest was put off")}: ${_esc(c.later)}</div>` : "";
    return `<article class="dg-card" data-p="${_esc(c.p)}" data-i="${_esc(c.i)}" data-v="${_esc(c.latestV || c.v)}">
      <div class="dg-ch"><span class="dg-dept">${_esc(_pn(c.dept || "") || L("기타", "Other"))}</span><h2>${_esc(c.title || c.i)}</h2>
        <span class="dg-ver">${L("새", "New")} ${_esc(c.v)}${c.prevV ? ` · ${_esc(c.prevV)}→${_esc(c.v)}` : ""}</span></div>
      <div class="dg-when">${_esc(ago(c.at))}${c.status && c.status !== "pending" ? ` · ${_esc(statusLabel(c.status))}` : ""}</div>
      ${ba}
      ${c.summary ? `<div class="dg-summary">${_esc(c.summary)}</div>` : ""}
      ${later}
      ${fixed}
      ${asks}
      <a class="dg-open" data-open>${_ic("open") || ""}${L("결과물 열기", "Open result")}</a>
    </article>`;
  }

  function statusLabel(s) {
    return { approved: L("승인됨", "Approved"), changes: L("수정 요청", "Changes asked"), hold: L("보류", "On hold") }[s] || s;
  }

  // Mount the current card (and a faint peek of the next) into the stage.
  function mountStage() {
    const stage = S.el.querySelector("#dg-stage");
    if (!stage) return;
    stage.innerHTML = "";
    const next = S.cards[S.i + 1];
    if (next) {
      const peek = document.createElement("div");
      peek.className = "dg-slot dg-peek";
      peek.inert = true; peek.setAttribute("aria-hidden", "true");
      peek.innerHTML = cardHTML(next);
      stage.appendChild(peek);
    }
    const slot = document.createElement("div");
    slot.className = "dg-slot";
    slot.id = "dg-top";
    slot.innerHTML = cardHTML(S.cards[S.i]);
    stage.appendChild(slot);
    // size the stage to the taller of the mounted cards so absolute cards don't clip
    requestAnimationFrame(() => {
      const h = slot.firstElementChild.offsetHeight;
      if (h) stage.style.minHeight = h + "px";
      const peek = stage.querySelector(".dg-peek");
      if (peek && h) { peek.style.bottom = "auto"; peek.style.height = h + "px"; }
    });
    wireCard(slot.firstElementChild);
    if (!RM()) {
      // spring the fresh card up into place
      const card = slot.firstElementChild;
      card.style.opacity = "0";
      card.style.transform = "translateY(16px) scale(.98)";
      requestAnimationFrame(() => {
        card.style.transition = "opacity .28s ease, transform .42s var(--d-spring)";
        card.style.opacity = "1"; card.style.transform = "none";
        setTimeout(() => { card.style.transition = ""; }, 460);
      });
    }
  }

  function updateChrome() {
    const cnt = S.el.querySelector("#dg-count");
    if (cnt) cnt.textContent = `${S.i + 1} / ${S.cards.length}`;
    const dots = S.el.querySelector("#dg-dots");
    if (dots) {
      const n = S.cards.length;
      dots.innerHTML = n <= 24 ? S.cards.map((_, k) => `<i class="${k === S.i ? "on" : ""}"></i>`).join("") : "";
    }
    const prev = S.el.querySelector("[data-prev]"), next = S.el.querySelector("[data-next]");
    // an end of the queue: off, and the tooltip says why
    if (prev) { prev.disabled = S.i <= 0; prev.title = prev.disabled ? L("첫 카드예요", "First card") : ""; }
    if (next) { next.disabled = S.i >= S.cards.length - 1; next.title = next.disabled ? L("마지막 카드예요", "Last card") : ""; }
  }

  // ---- per-card wiring: verdicts, open link, drag -------------------------------------------
  function wireCard(card) {
    if (!card) return;
    card.querySelectorAll(".dg-dir").forEach((row) => {
      row.querySelectorAll("[data-act]").forEach((b) => {
        b.onclick = (e) => { e.stopPropagation(); verdict(card, row, b.dataset.act === "ok"); };
      });
    });
    const open = card.querySelector("[data-open]");
    if (open) open.onclick = () => {
      const c = S.cards[S.i];
      location.hash = "item/" + c.p + "/" + c.i;
    };
    bindDrag(card);
  }

  async function verdict(card, row, ok) {
    const p = card.dataset.p, i = card.dataset.i, id = row.dataset.id;
    // The claim this card showed: the version that claimed it and the directive's own rev, so a
    // claim that moved since the queue loaded comes back as a conflict instead of being judged.
    const d = (S.cards[S.i].claimed || []).find((x) => x.id === id) || {};
    const v = d.fixed_in || card.dataset.v;
    row.querySelectorAll("button").forEach((b) => (b.disabled = true));
    try {
      await _post("/api/directive", { p, i, id, v, ok, verdict: ok ? "ok" : "again", ...(d.rev != null ? { rev: d.rev } : {}) });
      row.classList.add("done");
      row.querySelector(".dg-dbtns").outerHTML = `<span class="dg-done-tag">${ok ? L("확인함", "Confirmed") : L("다시 보냄", "Sent back")}</span>`;
      // reflect in the local model so counts stay honest
      const c = S.cards[S.i];
      c.claimed = (c.claimed || []).filter((d) => d.id !== id);
      _toast(ok ? L("확인했어요", "Confirmed") : L("다시 보냈어요", "Sent back"));
    } catch (e) {
      if (e && (e.status === 409 || /새 버전/.test(e.raw || e.message || ""))) { _toast(L("그 사이 바뀌었어요 · 다시 불러와요", "It changed meanwhile · reloading")); drawTab(S.el); return; }
      row.querySelectorAll("button").forEach((b) => (b.disabled = false));
      _toast(e.message || L("실패", "Failed"));
    }
  }

  // ---- navigation + fling -------------------------------------------------------------------
  let cancelAnim = null;

  function step(dir, vel) {
    const target = S.i + dir;
    if (target < 0 || target >= S.cards.length) {
      // nothing there: rubber-band back
      const card = S.el.querySelector("#dg-top > .dg-card");
      if (card && !RM()) snapBack(card, vel || 0);
      return;
    }
    const card = S.el.querySelector("#dg-top > .dg-card");
    if (RM() || !card) { S.i = target; mountStage(); updateChrome(); return; }
    if (cancelAnim) cancelAnim();
    const w = S.el.querySelector("#dg-stage").offsetWidth || 360;
    const out = dir > 0 ? -w * 1.3 : w * 1.3;
    const startX = curX(card);
    cancelAnim = spring(startX, out, vel || 0, (x) => {
      card.style.transform = `translateX(${x}px) rotate(${x / w * 5}deg)`;
      card.style.opacity = String(Math.max(0, 1 - Math.abs(x) / w));
    }, () => { S.i = target; mountStage(); updateChrome(); }, { stiffness: 170, damping: 22 });
  }

  function snapBack(card, vel) {
    if (cancelAnim) cancelAnim();
    const w = S.el.querySelector("#dg-stage").offsetWidth || 360;
    const startX = curX(card);
    cancelAnim = spring(startX, 0, vel || 0, (x) => {
      card.style.transform = `translateX(${x}px) rotate(${x / w * 5}deg)`;
      card.style.opacity = String(Math.max(0, 1 - Math.abs(x) / (w * 1.4)));
    }, () => { card.style.transform = ""; card.style.opacity = ""; });
  }

  function curX(card) {
    const m = /translateX\(([-0-9.]+)px\)/.exec(card.style.transform || "");
    return m ? parseFloat(m[1]) : 0;
  }

  // 1:1 drag on the top card; release carries velocity into fling or snap-back.
  function bindDrag(card) {
    let startX = 0, startY = 0, dx = 0, dragging = false, lockV = false, lastX = 0, lastT = 0, vel = 0;
    const down = (e) => {
      if (e.target.closest("button, a, [data-act], [data-open]")) return;   // let controls click
      if (RM()) return;
      dragging = true; lockV = false;
      startX = e.clientX; startY = e.clientY; lastX = e.clientX; lastT = e.timeStamp || performance.now();
      if (cancelAnim) cancelAnim();
      card.setPointerCapture && card.setPointerCapture(e.pointerId);
    };
    const move = (e) => {
      if (!dragging) return;
      dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (!lockV && Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 10) { dragging = false; return; } // vertical scroll
      lockV = true;
      const now = e.timeStamp || performance.now();
      if (now > lastT) { vel = (e.clientX - lastX) / (now - lastT) * 1000; lastX = e.clientX; lastT = now; }
      const w = card.offsetWidth || 360;
      card.style.transform = `translateX(${dx}px) rotate(${dx / w * 5}deg)`;
      card.style.opacity = String(Math.max(0.2, 1 - Math.abs(dx) / (w * 1.4)));
      e.preventDefault();
    };
    const up = () => {
      if (!dragging) return;
      dragging = false;
      const w = card.offsetWidth || 360;
      const far = Math.abs(dx) > w * 0.28, fast = Math.abs(vel) > 550;
      if (far || fast) step(dx < 0 ? 1 : -1, vel);
      else snapBack(card, vel);
      dx = 0; vel = 0;
    };
    card.addEventListener("pointerdown", down);
    card.addEventListener("pointermove", move);
    card.addEventListener("pointerup", up);
    card.addEventListener("pointercancel", up);
  }

  // ---- keyboard: j/k and arrows -------------------------------------------------------------
  let keyBound = false;
  function bindKeys() {
    if (keyBound) return;
    keyBound = true;
    document.addEventListener("keydown", (e) => {
      if (!S || !S.el.querySelector(".dg-stage")) return;               // only on the queue screen
      if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName || "")) return;
      if (e.key === "ArrowRight" || e.key === "j") { e.preventDefault(); step(1); }
      else if (e.key === "ArrowLeft" || e.key === "k") { e.preventDefault(); step(-1); }
    });
  }

  async function markSeen() {
    const btn = S.el.querySelector("#dg-seen");
    if (btn) btn.disabled = true;
    try {
      await _post("/api/digest/seen", { at: new Date().toISOString() });
      S.cards = [];
      renderEmpty();
      _toast(L("다 본 걸로 표시했어요", "Marked all as seen"));
    } catch (e) {
      if (btn) btn.disabled = false;
      _toast(e.message || L("실패", "Failed"));
    }
  }

  // ---- 아침 한 화면: the order of what waits (v2.js builds the rows) --------------------------
  // A wait that stops a session outright leads (a permission), then a question to a session,
  // then a result's question, then a result to look at; inside each, the longest wait first.
  // brief-order-start
  const BRIEF_RANK = { perm: 0, allow: 1, answer: 2, ask: 3, look: 4 };
  const rank = (r) => (r.k in BRIEF_RANK ? BRIEF_RANK[r.k] : 9), when = (r) => String(r.at || "￿");
  const briefOrder = (rows) => rows.map((r, i) => [r, i]).sort(([a, i], [b, j]) =>
    rank(a) - rank(b) || (when(a) < when(b) ? -1 : when(a) > when(b) ? 1 : 0) || i - j).map(([r]) => r);
  // brief-order-end
  window.LOOP_BRIEF = { order: briefOrder };

  // ---- register through the app's hooks -----------------------------------------------------
  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({ id: "digest", get title() { return L("검토함", "Review box"); }, draw: drawHome });
  (window.LOOP_TABS = window.LOOP_TABS || []).push({ id: "digest", get label() { return typeof tl === "function" ? tl("tab.digest") : "검토함"; }, icon: "tray", draw: drawTab });
})();
