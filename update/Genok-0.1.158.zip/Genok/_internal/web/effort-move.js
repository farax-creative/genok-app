// EffortMove: a stepped selector (reasoning effort: low / medium / high ...) whose thumb is a
// drop of liquid. The true position goes where the pointer or the chosen stop is; the liquid
// surface chases it on a spring, stretches with speed and strings a short droplet tail behind
// it through an SVG goo filter (blur -> alpha contrast -> source atop).
//
// A vanilla-JS port of the "move" effect of liquid-gooey (React) for this app's plain web/.
// Taken from upstream: the goo filter chain and its contrast/intercept pairing, the surface
// spring (380 / 18), the velocity stretch, the (optional, off by default) trailing droplet (170 / 22 spring, clamped lag,
// onset ramp, two tapering mid-droplets with a distance-driven weave) and the spring presets.
// Not taken: React wrappers, rect observation, shadows, morph / melt / bend / dissolve.
//
// Ported from liquid-gooey 0.2.2 by Jakub Antalik
// https://github.com/Jakubantalik/Libraries.dev (packages/liquid-gooey) - https://libraries.dev/gooey
//
//   MIT License. Copyright (c) 2026 Jakub
//   Permission is hereby granted, free of charge, to any person obtaining a copy of this
//   software and associated documentation files (the "Software"), to deal in the Software
//   without restriction, including without limitation the rights to use, copy, modify, merge,
//   publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
//   to whom the Software is furnished to do so, subject to the following conditions:
//   The above copyright notice and this permission notice shall be included in all copies or
//   substantial portions of the Software.
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
//
// Usage:
//   const sel = EffortMove.mount(el, {
//     steps: [{ id: "low", label: "낮음" }, ...],   // 2..8 steps
//     value: "high",
//     label: "추론 수준",                            // optional header row (label + current value)
//     onChange(id, step) {},                        // committed (release, click, key)
//     onInput(id, step) {},                         // optional: nearest stop while dragging
//   });
//   sel.setValue(id) / sel.setSteps(steps, value) / sel.getValue() / sel.destroy()
// Styling lives in effort-move.css; colours come from CSS variables (--key and neutrals).

(function () {
  "use strict";

  // ---- upstream constants -------------------------------------------------------------------

  // liquid-gooey MOVE_DEFAULTS (observer.ts), unchanged except `tail`: upstream ships 0.46 (a
  // trailing droplet). Here it is 0 - upstream's own "0 disables the tail" - so nothing but
  // the stretching liquid moves along the track. Pass move:{tail:0.46} to bring it back, or
  // move:{damping:27} for a calmer arrival without the wobble.
  const MOVE_DEFAULTS = { stiffness: 380, damping: 18, stretch: 0.18, tail: 0.46, force: 0.5 };
  const TAIL_K = 170, TAIL_C = 22;            // trailing droplet spring (upstream, fixed)
  // The knob's own travel between stops (upstream leaves this to the caller). Critically
  // damped so only the liquid overshoots, and soft enough that the liquid's steady lag
  // (damping / stiffness * speed) stays within about two thumb widths.
  const KNOB = { stiffness: 260, damping: 32 };
  const GOO_CONTRAST = 18;                    // upstream <Liquid contrast>
  let uid = 0;

  function springStep(cur, vel, target, k, c, dt) {
    const a = k * (target - cur) - c * vel;
    const v = vel + a * dt;
    return [cur + v * dt, v];
  }
  // Substepped so the integration stays stable whatever the frame gap was.
  function springSteps(cur, vel, target, k, c, dt) {
    let n = Math.max(1, Math.ceil(dt * 120));
    const h = dt / n;
    let p = cur, v = vel;
    while (n-- > 0) { const s = springStep(p, v, target, k, c, h); p = s[0]; v = s[1]; }
    return [p, v];
  }
  const r1 = (v) => Math.round(v * 10) / 10;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const SVGNS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs) {
    const n = document.createElementNS(SVGNS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }
  function el(tag, cls) { const n = document.createElement(tag); if (cls) n.className = cls; return n; }

  function mount(host, opts) {
    opts = opts || {};
    const move = Object.assign({}, MOVE_DEFAULTS, opts.move || {});
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    const id = "em-goo-" + (++uid);

    let steps = [];
    let index = 0;          // committed step
    let shown = 0;          // step the label / aria currently show (nearest stop while dragging)
    let W = 0, H = 28, R = 8, pad = 10;
    let x = 0, vx = 0;      // knob (true position), px from the track's left edge
    let target = 0;         // stop the knob is travelling to
    let lx = 0, lvx = 0;    // liquid surface centre
    let tx = 0, tvx = 0, tr = 0, phase = 0;   // trailing droplet
    let dragging = false, raf = 0, last = 0, laid = false;

    // ---- DOM ----------------------------------------------------------------------------------
    host.classList.add("em");
    host.textContent = "";
    let valueEl = null;
    if (opts.label) {
      const head = el("div", "em-head");
      const lab = el("span", "em-label"); lab.textContent = opts.label;
      valueEl = el("span", "em-value");
      head.append(lab, valueEl);
      host.append(head);
    }
    const track = el("div", "em-track");
    track.setAttribute("role", "slider");
    track.tabIndex = 0;
    track.setAttribute("aria-label", opts.ariaLabel || opts.label || "");
    track.setAttribute("aria-valuemin", "0");
    const rail = el("span", "em-rail");
    const goo = svg("svg", { class: "em-goo", "aria-hidden": "true", focusable: "false" });
    const filter = svg("filter", { id: id, filterUnits: "userSpaceOnUse", "color-interpolation-filters": "sRGB" });
    const feBlur = svg("feGaussianBlur", { in: "SourceGraphic", result: "blur" });
    const feMat = svg("feColorMatrix", { in: "blur", type: "matrix", result: "goo" });
    filter.append(feBlur, feMat, svg("feComposite", { in: "SourceGraphic", in2: "goo", operator: "atop" }));
    const defs = svg("defs", {}); defs.append(filter);
    const g = svg("g", { filter: "url(#" + id + ")" });
    const bar = svg("rect", { class: "em-bar" });
    const tail = svg("circle", { r: 0 }), midA = svg("circle", { r: 0 }), midB = svg("circle", { r: 0 });
    const body = svg("ellipse", {});
    g.append(bar, tail, midA, midB, body);
    goo.append(defs, g);
    const dots = el("span", "em-dots");     // stop ticks
    const ring = el("span", "em-ring");      // keyboard focus ring, rides with the knob
    track.append(rail, goo, dots, ring);
    host.append(track);

    // ---- geometry -----------------------------------------------------------------------------
    const stopX = (i) => steps.length < 2 ? pad : pad + (i * (W - pad * 2)) / (steps.length - 1);
    function nearest(px) {
      if (steps.length < 2) return 0;
      return clamp(Math.round(((px - pad) / (W - pad * 2)) * (steps.length - 1)), 0, steps.length - 1);
    }
    function layout() {
      const cs = getComputedStyle(host);
      W = track.clientWidth; H = track.clientHeight || 28;
      R = parseFloat(cs.getPropertyValue("--em-thumb")) / 2 || 8;
      pad = R + 2;
      if (!W) return;
      const barH = parseFloat(cs.getPropertyValue("--em-bar")) || 6;
      // Goo sigma scales with the thumb; the intercept tracks the slope as upstream does so
      // the alpha threshold stays at the classic 18 / -7 crossing.
      const blur = Math.max(1.6, R * 0.34);
      feBlur.setAttribute("stdDeviation", String(r1(blur)));
      const intercept = Math.round((0.5 - GOO_CONTRAST * (5 / 12)) * 100) / 100;
      feMat.setAttribute("values", "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 " + GOO_CONTRAST + " " + intercept);
      goo.setAttribute("viewBox", "0 0 " + W + " " + H);
      filter.setAttribute("x", -16); filter.setAttribute("y", -8);
      filter.setAttribute("width", W + 32); filter.setAttribute("height", H + 16);
      bar.setAttribute("x", 2); bar.setAttribute("y", r1(H / 2 - barH / 2));
      bar.setAttribute("height", barH); bar.setAttribute("rx", barH / 2);
      body.setAttribute("cy", H / 2); body.setAttribute("rx", R); body.setAttribute("ry", R);
      tail.setAttribute("cy", H / 2); midA.setAttribute("cy", H / 2); midB.setAttribute("cy", H / 2);
      const kids = dots.children;
      for (let i = 0; i < kids.length; i++) kids[i].style.transform = "translateX(" + r1(stopX(i)) + "px)";
      if (!dragging) { target = stopX(index); x = target; vx = 0; }
      lx = x; lvx = 0; tx = x; tvx = 0; tr = 0;
      laid = true;
      paint();
    }
    // ---- painting -----------------------------------------------------------------------------
    let lastTail = "", lastOn = -1;
    const band = (d) => 5 * (1 - Math.exp(-d / 5));   // soft limit, at most 5px past an end stop
    function disp() {            // liquid centre as drawn
      const lo = pad, hi = W - pad;
      return lx < lo ? lo - band(lo - lx) : lx > hi ? hi + band(lx - hi) : lx;
    }
    function paint() {
      ring.style.transform = "translate3d(" + r1(x) + "px,0,0)";
      ticks();
      const speed = Math.abs(lvx);
      const dx = disp();
      // Mild stretch along the travel axis (upstream: min(stretch, speed * 0.0006)).
      const st = speed > 2 ? Math.min(move.stretch, speed * 0.0006) : 0;
      body.setAttribute("cx", r1(dx));
      body.setAttribute("rx", r1(R * (1 + st)));
      body.setAttribute("ry", r1(R / (1 + st * 0.65)));
      bar.setAttribute("width", r1(Math.max(0, dx - 2)));
      if (tr < 0.3) {
        if (lastTail !== "h") { tail.setAttribute("r", 0); midA.setAttribute("r", 0); midB.setAttribute("r", 0); lastTail = "h"; }
      } else {
        const lag = tx - lx;
        const inside = (v, r) => clamp(v, 2 + r, W - 2 - r);   // droplets never leave the rail
        // Upstream weaves the mid-droplets off-axis; on a 1D track that reads as jitter, so the
        // weave is kept as a small breathing of their size instead.
        const w1 = 1 + Math.sin(phase) * 0.08, w2 = 1 + Math.sin(phase + 2.4) * 0.08;
        const key = r1(tx) + "," + r1(tr) + "," + r1(dx);
        if (key !== lastTail) {
          tail.setAttribute("cx", r1(inside(dx + lag, tr))); tail.setAttribute("r", r1(tr));
          midA.setAttribute("cx", r1(inside(dx + lag * 0.45, tr * 0.62))); midA.setAttribute("r", r1(tr * 0.62 * w1));
          midB.setAttribute("cx", r1(inside(dx + lag * 0.75, tr * 0.4))); midB.setAttribute("r", r1(tr * 0.4 * w2));
          lastTail = key;
        }
      }
    }
    // Stops the liquid has passed read as notches in the fill.
    function ticks() {
      const on = steps.length < 2 ? 0 : Math.floor(((lx - pad + 1) / (W - pad * 2)) * (steps.length - 1) + 1e-6);
      // The tick under the thumb is hidden so the thumb stays plain.
      let under = -1;
      const dx = disp();
      for (let i = 0; i < steps.length; i++) if (Math.abs(stopX(i) - dx) < pad + 1) under = i;
      const key = on * 100 + under;
      if (key === lastOn) return;
      const kids = dots.children;
      for (let i = 0; i < kids.length; i++) {
        kids[i].classList.toggle("on", i <= on);
        kids[i].classList.toggle("under", i === under);
      }
      lastOn = key;
    }
    function show(i) {
      shown = i;
      const s = steps[i];
      if (!s) return;
      if (valueEl) valueEl.textContent = s.label;
      track.setAttribute("aria-valuenow", String(i));
      track.setAttribute("aria-valuetext", s.label);
    }

    // ---- simulation ---------------------------------------------------------------------------
    function wake() { if (!raf) { last = 0; raf = requestAnimationFrame(tick); } }
    function tick(now) {
      raf = 0;
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
      last = now;
      // As upstream: the element jumps to its stop, the liquid chases it on the spring.
      if (!dragging) { x = target; vx = 0; }
      // Lag + wobble: liquid rubber trailing the knob.
      [lx, lvx] = springSteps(lx, lvx, x, move.stiffness, move.damping, dt);
      // Trailing droplet: a laggier satellite the goo filter strings into a tail. The lag is
      // clamped so it always overlaps the body's blur field (alone it would fall under the
      // alpha threshold and vanish).
      [tx, tvx] = springSteps(tx, tvx, lx, TAIL_K, TAIL_C, dt);
      const speed = Math.abs(lvx);
      const maxLag = R + R * (0.2 + move.force * 1.6);
      if (Math.abs(tx - lx) > maxLag) tx = lx + Math.sign(tx - lx) * maxLag;
      const onset = clamp((speed - 20) / 120, 0, 1);
      tr += (R * move.tail * onset - tr) * Math.min(1, dt * 10);
      phase += speed * dt * 0.045;
      paint();
      const still = !dragging && Math.abs(x - target) < 0.05 && Math.abs(vx) < 0.5 &&
        Math.abs(lx - x) < 0.05 && Math.abs(lvx) < 0.5 && tr < 0.3;
      if (still) { x = target; lx = x; lvx = vx = 0; tx = lx; tvx = 0; tr = 0; paint(); return; }
      raf = requestAnimationFrame(tick);
    }
    function snap() {              // reduced motion: no travel, a short fade instead
      x = target; vx = 0; lx = x; lvx = 0; tx = x; tvx = 0; tr = 0;
      paint();
      track.classList.remove("em-snap");
      void track.offsetWidth;
      track.classList.add("em-snap");
    }
    function go(i, v0, silent) {
      i = clamp(i, 0, steps.length - 1);
      const changed = i !== index;
      index = i; target = stopX(i);
      show(i);
      if (reduce.matches) snap(); else { if (v0) lvx = v0; wake(); }
      if (changed && !silent && opts.onChange) opts.onChange(steps[i].id, steps[i]);
    }

    // ---- pointer ------------------------------------------------------------------------------
    let downX = 0, grab = 0, moved = false, samples = [];
    function localX(e) { return e.clientX - track.getBoundingClientRect().left; }
    function onDown(e) {
      if (e.button !== undefined && e.button !== 0) return;
      if (steps.length < 2) return;
      const px = localX(e);
      downX = px; moved = false; samples = [[e.timeStamp, px]];
      // Grabbing the thumb keeps the offset; pressing the bare track brings the knob under the finger.
      grab = Math.abs(px - x) <= R + 6 ? px - x : 0;
      track.setPointerCapture(e.pointerId);
      track.addEventListener("pointermove", onMove);
      track.addEventListener("pointerup", onUp);
      track.addEventListener("pointercancel", onUp);
    }
    function onMove(e) {
      const px = localX(e);
      if (!moved && Math.abs(px - downX) < 3) return;
      if (!moved) { moved = true; dragging = true; track.classList.add("em-drag"); }
      samples.push([e.timeStamp, px]);
      if (samples.length > 6) samples.shift();
      let nx = px - grab;                       // 1:1 with the pointer
      const lo = stopX(0), hi = stopX(steps.length - 1);
      if (nx < lo) nx = lo - Math.min(6, (lo - nx) * 0.2);   // rubber-band past the ends
      if (nx > hi) nx = hi + Math.min(6, (nx - hi) * 0.2);
      x = nx; vx = 0;
      const n = nearest(x);
      if (n !== shown) { show(n); if (opts.onInput) opts.onInput(steps[n].id, steps[n]); }
      if (reduce.matches) { lx = x; tx = x; tr = 0; paint(); } else wake();
    }
    function onUp(e) {
      track.removeEventListener("pointermove", onMove);
      track.removeEventListener("pointerup", onUp);
      track.removeEventListener("pointercancel", onUp);
      track.classList.remove("em-drag");
      if (!moved) { go(nearest(localX(e))); return; }       // a click on the track or a stop
      dragging = false;
      // Release velocity from the last ~80 ms of samples, carried into the knob spring and
      // projected to choose the stop the throw is heading for.
      let v = 0;
      const lastS = samples[samples.length - 1];
      const first = samples.find((s) => lastS[0] - s[0] <= 80) || samples[0];
      if (lastS[0] - first[0] > 4 && e.timeStamp - lastS[0] < 60) v = ((lastS[1] - first[1]) / (lastS[0] - first[0])) * 1000;
      v = clamp(v, -2400, 2400);
      vx = 0;
      go(nearest(x + v * 0.1), v);
    }
    function onKey(e) {
      let i = index;
      if (e.key === "ArrowRight" || e.key === "ArrowUp") i++;
      else if (e.key === "ArrowLeft" || e.key === "ArrowDown") i--;
      else if (e.key === "Home") i = 0;
      else if (e.key === "End") i = steps.length - 1;
      else return;
      e.preventDefault();
      go(i);
    }
    track.addEventListener("pointerdown", onDown);
    track.addEventListener("keydown", onKey);
    const ro = new ResizeObserver(() => { const w = track.clientWidth; if (w && (w !== W || !laid)) layout(); });
    ro.observe(track);

    // ---- API ----------------------------------------------------------------------------------
    function setSteps(next, value) {
      const keep = value !== undefined ? value : (steps[index] && steps[index].id);
      steps = (next || []).slice();
      track.setAttribute("aria-valuemax", String(Math.max(0, steps.length - 1)));
      dots.textContent = "";
      steps.forEach(() => dots.append(el("i")));
      lastOn = -1;
      const i = steps.findIndex((s) => s.id === keep);
      index = i < 0 ? 0 : i;
      show(index);
      layout();
    }
    setSteps(opts.steps, opts.value);

    return {
      setValue(v) { const i = steps.findIndex((s) => s.id === v); if (i >= 0) go(i, 0, true); },
      getValue() { return steps[index] ? steps[index].id : null; },
      setSteps: setSteps,
      destroy() {
        if (raf) cancelAnimationFrame(raf);
        ro.disconnect();
        track.removeEventListener("pointerdown", onDown);
        track.removeEventListener("keydown", onKey);
        host.textContent = ""; host.classList.remove("em");
      },
      _state() { return { x: x, lx: lx, tr: tr, target: target, index: index, running: !!raf }; },
    };
  }

  window.EffortMove = { mount: mount, MOVE_DEFAULTS: MOVE_DEFAULTS };
})();
