// Emoji helpers for the 부서 만들기 sheet: suggest a few emoji from a name, and search all of them.
// Pure (no DOM), so node tests can load it: window.LOOP_EMOJI in the browser, module.exports in node.
//
// ALL is every single-codepoint emoji with its Unicode name (generated once from the Unicode
// database; ZWJ sequences, skin tones and flags are left out). Koreans search in Korean, so CONCEPTS
// maps everyday words to the emoji that fit and to English name words for the search.
(function () {
  "use strict";

  // [Korean/English words the name may contain, suggested emoji, English words for searching names]
  const CONCEPTS = [
    [["영상", "비디오", "동영상", "편집", "촬영", "릴스", "쇼츠", "필름", "영화", "video", "movie", "film", "reel", "shorts", "render", "렌더"], "🎬🎞📹🎥📽", "clapper film movie video camera"],
    [["3d", "모델링", "블렌더", "blender", "애니", "모션", "motion", "houdini", "후디니"], "🧊🌀✨🎞🧱", "cube spiral sparkles film brick"],
    [["디자인", "그래픽", "로고", "브랜드", "일러스트", "그림", "design", "graphic", "logo", "brand", "ui", "ux"], "🎨🖌🖼✏️🌈", "palette brush frame pencil rainbow"],
    [["코드", "개발", "프로그램", "앱", "api", "서버", "스크립트", "code", "dev", "app", "script", "backend", "frontend"], "💻🧩⌨️🖥🛠", "computer puzzle keyboard desktop hammer wrench"],
    [["봇", "자동화", "워크플로", "bot", "auto", "workflow"], "🤖⚙️🔁⚡🔧", "robot gear repeat high voltage wrench"],
    [["버그", "오류", "디버그", "bug", "fix", "수정"], "🐛🔧🩹🔍🧯", "bug wrench bandage magnifying extinguisher"],
    [["사진", "이미지", "갤러리", "카메라", "photo", "image", "img", "gallery", "camera"], "📷📸🖼🌅🏞", "camera photo picture frame sunrise park"],
    [["문서", "글", "원고", "카피", "블로그", "노트", "메모", "기획", "보고서", "doc", "write", "note", "copy", "blog", "report"], "📝📄📃🗒📋", "memo page document notepad clipboard"],
    [["음악", "오디오", "소리", "노래", "사운드", "music", "audio", "sound", "song"], "🎵🎧🎼🔊🎹", "music headphone note speaker keyboard"],
    [["음성", "보이스", "팟캐스트", "더빙", "내레이션", "tts", "voice", "podcast"], "🎙🎤🗣🔊🎧", "microphone speaking speaker headphone"],
    [["마케팅", "광고", "홍보", "sns", "캠페인", "배너", "marketing", "ad", "campaign", "banner", "promo"], "📣📢🎯📈💌", "megaphone loudspeaker target chart love letter"],
    [["판매", "스토어", "가격", "결제", "매출", "돈", "정산", "회계", "쇼핑", "store", "shop", "price", "pay", "sales"], "💰🛒💳🧾🏷", "money cart credit receipt label"],
    [["데이터", "통계", "분석", "차트", "리포트", "data", "stats", "analytics", "chart"], "📊📈📉🔍🗂", "chart increasing decreasing magnifying card index"],
    [["게임", "플레이", "놀이", "game", "play"], "🎮🕹🎲👾🏆", "game controller joystick dice alien trophy"],
    [["번역", "언어", "다국어", "영어", "일본어", "translate", "language", "i18n"], "🌐🗣💬🔤🈯", "globe speaking speech letters"],
    [["회의", "미팅", "상담", "고객", "문의", "cs", "meeting", "support", "customer"], "💬🤝📞🎧🙋", "speech handshake telephone headphone person raising"],
    [["일정", "계획", "스케줄", "캘린더", "로드맵", "schedule", "plan", "calendar", "roadmap"], "📅🗓⏰🧭🗺", "calendar alarm compass map"],
    [["보안", "권한", "로그인", "인증", "비밀", "security", "auth", "login", "secret"], "🔒🔑🛡🔐🕵", "lock key shield detective"],
    [["테스트", "qa", "검수", "검증", "리뷰", "test", "review", "verify"], "✅🧪🔎📋👀", "check test tube magnifying clipboard eyes"],
    [["음식", "요리", "카페", "레시피", "맛집", "food", "cook", "cafe", "recipe"], "🍳🍜☕🍰🍎", "cooking noodle coffee cake apple"],
    [["여행", "호텔", "항공", "trip", "travel", "hotel", "flight"], "✈️🧳🗺🏖🚆", "airplane luggage map beach train"],
    [["운동", "헬스", "건강", "의료", "fit", "health", "gym"], "💪🏃🏋❤️🩺", "muscle runner weight heart stethoscope"],
    [["교육", "학습", "공부", "강의", "수업", "study", "learn", "course", "lecture"], "🎓📚🧠🏫✏️", "graduation books brain school pencil"],
    [["아이디어", "브레인스토밍", "idea", "brainstorm"], "💡🧠✨🔮🌱", "bulb brain sparkles crystal seedling"],
    [["긴급", "알림", "공지", "경고", "urgent", "alert", "notice"], "🚨🔔📢⚠️❗", "siren bell loudspeaker warning exclamation"],
    [["썸네일", "커버", "표지", "포스터", "카드", "cover", "thumbnail", "poster", "card"], "🖼🃏🎴📰🪧", "frame joker flower card newspaper placard"],
    [["배포", "릴리즈", "출시", "업데이트", "버전", "deploy", "release", "update", "launch"], "🚀📦🏷🆕🎉", "rocket package label new party"],
    [["팀", "협업", "사람", "멤버", "team", "people", "member"], "👥🤝🙌🧑🌟", "busts handshake hands person star"],
    [["에셋", "라이브러리", "폴더", "아카이브", "보관", "asset", "library", "folder", "archive"], "🗂📁🗄📦🗃", "index folder cabinet package box"],
    [["설정", "관리", "운영", "setting", "admin", "ops"], "⚙️🛠🧰🔧📎", "gear tools toolbox wrench paperclip"],
    [["고양이", "cat"], "🐱🐈🐾😺🦁", "cat paw lion"],
    [["강아지", "멍멍", "dog"], "🐶🐕🦴🐾🐩", "dog bone paw poodle"],
    [["자연", "식물", "꽃", "날씨", "nature", "plant", "flower", "weather"], "🌿🌸🌞🌧🔥", "herb blossom sun rain fire"],
  ];
  const DEFAULTS = "🗂📁🧩🎬✨🎨";
  // A name with no clue still gets a spread of friendly picks, shifted by the name so two blank-ish
  // names do not offer the same row.
  const POOL = "🗂📁🧩🎬🎨📝📷🎵📣📊🎮🧪🚀🌿💡🔧📦🎯⭐🧭🪄🧵🎁🔖🧲🪴";

  const withVs = (s) => Array.from(s).reduce((a, c) => { if (c === "️" && a.length) a[a.length - 1] += c; else a.push(c); return a; }, []);
  const strip = (e) => e.replace(/️/g, "");
  // Two-letter latin words (ad, ui, cs) only count as whole words, so "download" is not an ad.
  const mention = (low, w) => (/^[a-z0-9]{1,2}$/.test(w) ? new RegExp("(^|[^a-z0-9])" + w + "($|[^a-z0-9])").test(low) : low.includes(w));
  function hash(s) { let h = 0; for (const c of s) h = (h * 31 + c.codePointAt(0)) >>> 0; return h; }

  // Up to n emoji for a name: concepts the name mentions first (more words hit = earlier), then a
  // name-shifted spread. `taken` (emoji other departments already use) go last so a row stays varied.
  function suggest(name, taken, n) {
    n = n || 6;
    const low = String(name || "").trim().toLowerCase();
    const skip = new Set(Array.from(taken || []).map(strip));
    const scored = [];
    CONCEPTS.forEach((c, i) => {
      const hit = low ? c[0].filter((w) => mention(low, w)).length : 0;
      if (hit) scored.push([hit, i, c]);
    });
    scored.sort((a, b) => b[0] - a[0] || a[1] - b[1]);
    const seen = new Set(), fresh = [], used = [];
    const add = (e) => {
      const k = strip(e);
      if (seen.has(k)) return;
      seen.add(k);
      (skip.has(k) ? used : fresh).push(e);
    };
    scored.forEach((s) => withVs(s[2][1]).forEach(add));
    const pool = withVs(POOL), h = hash(low);
    if (!low) withVs(DEFAULTS).forEach(add);
    for (let i = 0; i < pool.length; i++) add(pool[(h + i) % pool.length]);
    return fresh.concat(used).slice(0, n);
  }

  const ALL = `😀 grinning face
😁 grinning face with smiling eyes
😂 face with tears of joy
😃 smiling face with open mouth
😄 smiling face with open mouth and smiling eyes
😅 smiling face with open mouth and cold sweat
😆 smiling face with open mouth and tightly-closed eyes
😇 smiling face with halo
😈 smiling face with horns
😉 winking face
😊 smiling face with smiling eyes
😋 face savouring delicious food
😌 relieved face
😍 smiling face with heart-shaped eyes
😎 smiling face with sunglasses
😏 smirking face
😐 neutral face
😑 expressionless face
😒 unamused face
😓 face with cold sweat
😔 pensive face
😕 confused face
😖 confounded face
😗 kissing face
😘 face throwing a kiss
😙 kissing face with smiling eyes
😚 kissing face with closed eyes
😛 face with stuck-out tongue
😜 face with stuck-out tongue and winking eye
😝 face with stuck-out tongue and tightly-closed eyes
😞 disappointed face
😟 worried face
😠 angry face
😡 pouting face
😢 crying face
😣 persevering face
😤 face with look of triumph
😥 disappointed but relieved face
😦 frowning face with open mouth
😧 anguished face
😨 fearful face
😩 weary face
😪 sleepy face
😫 tired face
😬 grimacing face
😭 loudly crying face
😮 face with open mouth
😯 hushed face
😰 face with open mouth and cold sweat
😱 face screaming in fear
😲 astonished face
😳 flushed face
😴 sleeping face
😵 dizzy face
😶 face without mouth
😷 face with medical mask
😸 grinning cat face with smiling eyes
😹 cat face with tears of joy
😺 smiling cat face with open mouth
😻 smiling cat face with heart-shaped eyes
😼 cat face with wry smile
😽 kissing cat face with closed eyes
😾 pouting cat face
😿 crying cat face
🙀 weary cat face
🙁 slightly frowning face
🙂 slightly smiling face
🙃 upside-down face
🙄 face with rolling eyes
🙅 face with no good gesture
🙆 face with ok gesture
🙇 person bowing deeply
🙈 see-no-evil monkey
🙉 hear-no-evil monkey
🙊 speak-no-evil monkey
🙋 happy person raising one hand
🙌 person raising both hands in celebration
🙍 person frowning
🙎 person with pouting face
🙏 person with folded hands
🤌 pinched fingers
🤍 white heart
🤎 brown heart
🤏 pinching hand
🤐 zipper-mouth face
🤑 money-mouth face
🤒 face with thermometer
🤓 nerd face
🤔 thinking face
🤕 face with head-bandage
🤖 robot face
🤗 hugging face
🤘 sign of the horns
🤙 call me hand
🤚 raised back of hand
🤛 left-facing fist
🤜 right-facing fist
🤝 handshake
🤞 hand with index and middle fingers crossed
🤟 i love you hand sign
🤠 face with cowboy hat
🤡 clown face
🤢 nauseated face
🤣 rolling on the floor laughing
🤤 drooling face
🤥 lying face
🤦 face palm
🤧 sneezing face
🤨 face with one eyebrow raised
🤩 grinning face with star eyes
🤪 grinning face with one large and one small eye
🤫 face with finger covering closed lips
🤬 serious face with symbols covering mouth
🤭 smiling face with smiling eyes and hand covering mouth
🤮 face with open mouth vomiting
🤯 shocked face with exploding head
🤰 pregnant woman
🤱 breast-feeding
🤲 palms up together
🤳 selfie
🤴 prince
🤵 man in tuxedo
🤶 mother christmas
🤷 shrug
🤸 person doing cartwheel
🤹 juggling
🤺 fencer
🤼 wrestlers
🤽 water polo
🤾 handball
🤿 diving mask
🥀 wilted flower
🥁 drum with drumsticks
🥂 clinking glasses
🥃 tumbler glass
🥄 spoon
🥅 goal net
🥇 first place medal
🥈 second place medal
🥉 third place medal
🥊 boxing glove
🥋 martial arts uniform
🥌 curling stone
🥍 lacrosse stick and ball
🥎 softball
🥏 flying disc
🥐 croissant
🥑 avocado
🥒 cucumber
🥓 bacon
🥔 potato
🥕 carrot
🥖 baguette bread
🥗 green salad
🥘 shallow pan of food
🥙 stuffed flatbread
🥚 egg
🥛 glass of milk
🥜 peanuts
🥝 kiwifruit
🥞 pancakes
🥟 dumpling
🥠 fortune cookie
🥡 takeout box
🥢 chopsticks
🥣 bowl with spoon
🥤 cup with straw
🥥 coconut
🥦 broccoli
🥧 pie
🥨 pretzel
🥩 cut of meat
🥪 sandwich
🥫 canned food
🥬 leafy green
🥭 mango
🥮 moon cake
🥯 bagel
🥰 smiling face with smiling eyes and three hearts
🥱 yawning face
🥲 smiling face with tear
🥳 face with party horn and party hat
🥴 face with uneven eyes and wavy mouth
🥵 overheated face
🥶 freezing face
🥷 ninja
🥸 disguised face
🥹 face holding back tears
🥺 face with pleading eyes
🥻 sari
🥼 lab coat
🥽 goggles
🥾 hiking boot
🥿 flat shoe
🦀 crab
🦁 lion face
🦂 scorpion
🦃 turkey
🦄 unicorn face
🦅 eagle
🦆 duck
🦇 bat
🦈 shark
🦉 owl
🦊 fox face
🦋 butterfly
🦌 deer
🦍 gorilla
🦎 lizard
🦏 rhinoceros
🦐 shrimp
🦑 squid
🦒 giraffe face
🦓 zebra face
🦔 hedgehog
🦕 sauropod
🦖 t-rex
🦗 cricket
🦘 kangaroo
🦙 llama
🦚 peacock
🦛 hippopotamus
🦜 parrot
🦝 raccoon
🦞 lobster
🦟 mosquito
🦠 microbe
🦡 badger
🦢 swan
🦣 mammoth
🦤 dodo
🦥 sloth
🦦 otter
🦧 orangutan
🦨 skunk
🦩 flamingo
🦪 oyster
🦫 beaver
🦬 bison
🦭 seal
🦮 guide dog
🦯 probing cane
🦰 emoji component red hair
🦱 emoji component curly hair
🦲 emoji component bald
🦳 emoji component white hair
🦴 bone
🦵 leg
🦶 foot
🦷 tooth
🦸 superhero
🦹 supervillain
🦺 safety vest
🦻 ear with hearing aid
🦼 motorized wheelchair
🦽 manual wheelchair
🦾 mechanical arm
🦿 mechanical leg
🧀 cheese wedge
🧁 cupcake
🧂 salt shaker
🧃 beverage box
🧄 garlic
🧅 onion
🧆 falafel
🧇 waffle
🧈 butter
🧉 mate drink
🧊 ice cube
🧋 bubble tea
🧌 troll
🧍 standing person
🧎 kneeling person
🧏 deaf person
🧐 face with monocle
🧑 adult
🧒 child
🧓 older adult
🧔 bearded person
🧕 person with headscarf
🧖 person in steamy room
🧗 person climbing
🧘 person in lotus position
🧙 mage
🧚 fairy
🧛 vampire
🧜 merperson
🧝 elf
🧞 genie
🧟 zombie
🧠 brain
🧡 orange heart
🧢 billed cap
🧣 scarf
🧤 gloves
🧥 coat
🧦 socks
🧧 red gift envelope
🧨 firecracker
🧩 jigsaw puzzle piece
🧪 test tube
🧫 petri dish
🧬 dna double helix
🧭 compass
🧮 abacus
🧯 fire extinguisher
🧰 toolbox
🧱 brick
🧲 magnet
🧳 luggage
🧴 lotion bottle
🧵 spool of thread
🧶 ball of yarn
🧷 safety pin
🧸 teddy bear
🧹 broom
🧺 basket
🧻 roll of paper
🧼 bar of soap
🧽 sponge
🧾 receipt
🧿 nazar amulet
🩰 ballet shoes
🩱 one-piece swimsuit
🩲 briefs
🩳 shorts
🩴 thong sandal
🩵 light blue heart
🩶 grey heart
🩷 pink heart
🩸 drop of blood
🩹 adhesive bandage
🩺 stethoscope
🩻 x-ray
🩼 crutch
🪀 yo-yo
🪁 kite
🪂 parachute
🪃 boomerang
🪄 magic wand
🪅 pinata
🪆 nesting dolls
🪇 maracas
🪈 flute
🪉 harp
🪏 shovel
🪐 ringed planet
🪑 chair
🪒 razor
🪓 axe
🪔 diya lamp
🪕 banjo
🪖 military helmet
🪗 accordion
🪘 long drum
🪙 coin
🪚 carpentry saw
🪛 screwdriver
🪜 ladder
🪝 hook
🪞 mirror
🪟 window
🪠 plunger
🪡 sewing needle
🪢 knot
🪣 bucket
🪤 mouse trap
🪥 toothbrush
🪦 headstone
🪧 placard
🪨 rock
🪩 mirror ball
🪪 identification card
🪫 low battery
🪬 hamsa
🪭 folding hand fan
🪮 hair pick
🪯 khanda
🪰 fly
🪱 worm
🪲 beetle
🪳 cockroach
🪴 potted plant
🪵 wood
🪶 feather
🪷 lotus
🪸 coral
🪹 empty nest
🪺 nest with eggs
🪻 hyacinth
🪼 jellyfish
🪽 wing
🪾 leafless tree
🪿 goose
🫀 anatomical heart
🫁 lungs
🫂 people hugging
🫃 pregnant man
🫄 pregnant person
🫅 person with crown
🫆 fingerprint
🫎 moose
🫏 donkey
🫐 blueberries
🫑 bell pepper
🫒 olive
🫓 flatbread
🫔 tamale
🫕 fondue
🫖 teapot
🫗 pouring liquid
🫘 beans
🫙 jar
🫚 ginger root
🫛 pea pod
🫜 root vegetable
🫟 splatter
🫠 melting face
🫡 saluting face
🫢 face with open eyes and hand over mouth
🫣 face with peeking eye
🫤 face with diagonal mouth
🫥 dotted line face
🫦 biting lip
🫧 bubbles
🫨 shaking face
🫩 face with bags under eyes
🫰 hand with index finger and thumb crossed
🫱 rightwards hand
🫲 leftwards hand
🫳 palm down hand
🫴 palm up hand
🫵 index pointing at the viewer
🫶 heart hands
🫷 leftwards pushing hand
🫸 rightwards pushing hand
🌀 cyclone
🌁 foggy
🌂 closed umbrella
🌃 night with stars
🌄 sunrise over mountains
🌅 sunrise
🌆 cityscape at dusk
🌇 sunset over buildings
🌈 rainbow
🌉 bridge at night
🌊 water wave
🌋 volcano
🌌 milky way
🌍 earth globe europe-africa
🌎 earth globe americas
🌏 earth globe asia-australia
🌐 globe with meridians
🌑 new moon symbol
🌒 waxing crescent moon symbol
🌓 first quarter moon symbol
🌔 waxing gibbous moon symbol
🌕 full moon symbol
🌖 waning gibbous moon symbol
🌗 last quarter moon symbol
🌘 waning crescent moon symbol
🌙 crescent moon
🌚 new moon with face
🌛 first quarter moon with face
🌜 last quarter moon with face
🌝 full moon with face
🌞 sun with face
🌟 glowing star
🌠 shooting star
🌡️ thermometer
🌤️ white sun with small cloud
🌥️ white sun behind cloud
🌦️ white sun behind cloud with rain
🌧️ cloud with rain
🌨️ cloud with snow
🌩️ cloud with lightning
🌪️ cloud with tornado
🌫️ fog
🌬️ wind blowing face
🌭 hot dog
🌮 taco
🌯 burrito
🌰 chestnut
🌱 seedling
🌲 evergreen tree
🌳 deciduous tree
🌴 palm tree
🌵 cactus
🌶️ hot pepper
🌷 tulip
🌸 cherry blossom
🌹 rose
🌺 hibiscus
🌻 sunflower
🌼 blossom
🌽 ear of maize
🌾 ear of rice
🌿 herb
🍀 four leaf clover
🍁 maple leaf
🍂 fallen leaf
🍃 leaf fluttering in wind
🍄 mushroom
🍅 tomato
🍆 aubergine
🍇 grapes
🍈 melon
🍉 watermelon
🍊 tangerine
🍋 lemon
🍌 banana
🍍 pineapple
🍎 red apple
🍏 green apple
🍐 pear
🍑 peach
🍒 cherries
🍓 strawberry
🍔 hamburger
🍕 slice of pizza
🍖 meat on bone
🍗 poultry leg
🍘 rice cracker
🍙 rice ball
🍚 cooked rice
🍛 curry and rice
🍜 steaming bowl
🍝 spaghetti
🍞 bread
🍟 french fries
🍠 roasted sweet potato
🍡 dango
🍢 oden
🍣 sushi
🍤 fried shrimp
🍥 fish cake with swirl design
🍦 soft ice cream
🍧 shaved ice
🍨 ice cream
🍩 doughnut
🍪 cookie
🍫 chocolate bar
🍬 candy
🍭 lollipop
🍮 custard
🍯 honey pot
🍰 shortcake
🍱 bento box
🍲 pot of food
🍳 cooking
🍴 fork and knife
🍵 teacup without handle
🍶 sake bottle and cup
🍷 wine glass
🍸 cocktail glass
🍹 tropical drink
🍺 beer mug
🍻 clinking beer mugs
🍼 baby bottle
🍽️ fork and knife with plate
🍾 bottle with popping cork
🍿 popcorn
🎀 ribbon
🎁 wrapped present
🎂 birthday cake
🎃 jack-o-lantern
🎄 christmas tree
🎅 father christmas
🎆 fireworks
🎇 firework sparkler
🎈 balloon
🎉 party popper
🎊 confetti ball
🎋 tanabata tree
🎌 crossed flags
🎍 pine decoration
🎎 japanese dolls
🎏 carp streamer
🎐 wind chime
🎑 moon viewing ceremony
🎒 school satchel
🎓 graduation cap
🎖️ military medal
🎗️ reminder ribbon
🎙️ studio microphone
🎚️ level slider
🎛️ control knobs
🎞️ film frames
🎟️ admission tickets
🎠 carousel horse
🎡 ferris wheel
🎢 roller coaster
🎣 fishing pole and fish
🎤 microphone
🎥 movie camera
🎦 cinema
🎧 headphone
🎨 artist palette
🎩 top hat
🎪 circus tent
🎫 ticket
🎬 clapper board
🎭 performing arts
🎮 video game
🎯 direct hit
🎰 slot machine
🎱 billiards
🎲 game die
🎳 bowling
🎴 flower playing cards
🎵 musical note
🎶 multiple musical notes
🎷 saxophone
🎸 guitar
🎹 musical keyboard
🎺 trumpet
🎻 violin
🎼 musical score
🎽 running shirt with sash
🎾 tennis racquet and ball
🎿 ski and ski boot
🏀 basketball and hoop
🏁 chequered flag
🏂 snowboarder
🏃 runner
🏄 surfer
🏅 sports medal
🏆 trophy
🏇 horse racing
🏈 american football
🏉 rugby football
🏊 swimmer
🏋️ weight lifter
🏌️ golfer
🏍️ racing motorcycle
🏎️ racing car
🏏 cricket bat and ball
🏐 volleyball
🏑 field hockey stick and ball
🏒 ice hockey stick and puck
🏓 table tennis paddle and ball
🏔️ snow capped mountain
🏕️ camping
🏖️ beach with umbrella
🏗️ building construction
🏘️ house buildings
🏙️ cityscape
🏚️ derelict house building
🏛️ classical building
🏜️ desert
🏝️ desert island
🏞️ national park
🏟️ stadium
🏠 house building
🏡 house with garden
🏢 office building
🏣 japanese post office
🏤 european post office
🏥 hospital
🏦 bank
🏧 automated teller machine
🏨 hotel
🏩 love hotel
🏪 convenience store
🏫 school
🏬 department store
🏭 factory
🏮 izakaya lantern
🏯 japanese castle
🏰 european castle
🏳️ waving white flag
🏴 waving black flag
🏵️ rosette
🏷️ label
🏸 badminton racquet and shuttlecock
🏹 bow and arrow
🏺 amphora
🐀 rat
🐁 mouse
🐂 ox
🐃 water buffalo
🐄 cow
🐅 tiger
🐆 leopard
🐇 rabbit
🐈 cat
🐉 dragon
🐊 crocodile
🐋 whale
🐌 snail
🐍 snake
🐎 horse
🐏 ram
🐐 goat
🐑 sheep
🐒 monkey
🐓 rooster
🐔 chicken
🐕 dog
🐖 pig
🐗 boar
🐘 elephant
🐙 octopus
🐚 spiral shell
🐛 bug
🐜 ant
🐝 honeybee
🐞 lady beetle
🐟 fish
🐠 tropical fish
🐡 blowfish
🐢 turtle
🐣 hatching chick
🐤 baby chick
🐥 front-facing baby chick
🐦 bird
🐧 penguin
🐨 koala
🐩 poodle
🐪 dromedary camel
🐫 bactrian camel
🐬 dolphin
🐭 mouse face
🐮 cow face
🐯 tiger face
🐰 rabbit face
🐱 cat face
🐲 dragon face
🐳 spouting whale
🐴 horse face
🐵 monkey face
🐶 dog face
🐷 pig face
🐸 frog face
🐹 hamster face
🐺 wolf face
🐻 bear face
🐼 panda face
🐽 pig nose
🐾 paw prints
🐿️ chipmunk
👀 eyes
👁️ eye
👂 ear
👃 nose
👄 mouth
👅 tongue
👆 white up pointing backhand index
👇 white down pointing backhand index
👈 white left pointing backhand index
👉 white right pointing backhand index
👊 fisted hand sign
👋 waving hand sign
👌 ok hand sign
👍 thumbs up sign
👎 thumbs down sign
👏 clapping hands sign
👐 open hands sign
👑 crown
👒 womans hat
👓 eyeglasses
👔 necktie
👕 t-shirt
👖 jeans
👗 dress
👘 kimono
👙 bikini
👚 womans clothes
👛 purse
👜 handbag
👝 pouch
👞 mans shoe
👟 athletic shoe
👠 high-heeled shoe
👡 womans sandal
👢 womans boots
👣 footprints
👤 bust in silhouette
👥 busts in silhouette
👦 boy
👧 girl
👨 man
👩 woman
👪 family
👫 man and woman holding hands
👬 two men holding hands
👭 two women holding hands
👮 police officer
👯 woman with bunny ears
👰 bride with veil
👱 person with blond hair
👲 man with gua pi mao
👳 man with turban
👴 older man
👵 older woman
👶 baby
👷 construction worker
👸 princess
👹 japanese ogre
👺 japanese goblin
👻 ghost
👼 baby angel
👽 extraterrestrial alien
👾 alien monster
👿 imp
💀 skull
💁 information desk person
💂 guardsman
💃 dancer
💄 lipstick
💅 nail polish
💆 face massage
💇 haircut
💈 barber pole
💉 syringe
💊 pill
💋 kiss mark
💌 love letter
💍 ring
💎 gem stone
💏 kiss
💐 bouquet
💑 couple with heart
💒 wedding
💓 beating heart
💔 broken heart
💕 two hearts
💖 sparkling heart
💗 growing heart
💘 heart with arrow
💙 blue heart
💚 green heart
💛 yellow heart
💜 purple heart
💝 heart with ribbon
💞 revolving hearts
💟 heart decoration
💠 diamond shape with a dot inside
💡 electric light bulb
💢 anger symbol
💣 bomb
💤 sleeping symbol
💥 collision symbol
💦 splashing sweat symbol
💧 droplet
💨 dash symbol
💩 pile of poo
💪 flexed biceps
💫 dizzy symbol
💬 speech balloon
💭 thought balloon
💮 white flower
💯 hundred points symbol
💰 money bag
💱 currency exchange
💲 heavy dollar sign
💳 credit card
💴 banknote with yen sign
💵 banknote with dollar sign
💶 banknote with euro sign
💷 banknote with pound sign
💸 money with wings
💹 chart with upwards trend and yen sign
💺 seat
💻 personal computer
💼 briefcase
💽 minidisc
💾 floppy disk
💿 optical disc
📀 dvd
📁 file folder
📂 open file folder
📃 page with curl
📄 page facing up
📅 calendar
📆 tear-off calendar
📇 card index
📈 chart with upwards trend
📉 chart with downwards trend
📊 bar chart
📋 clipboard
📌 pushpin
📍 round pushpin
📎 paperclip
📏 straight ruler
📐 triangular ruler
📑 bookmark tabs
📒 ledger
📓 notebook
📔 notebook with decorative cover
📕 closed book
📖 open book
📗 green book
📘 blue book
📙 orange book
📚 books
📛 name badge
📜 scroll
📝 memo
📞 telephone receiver
📟 pager
📠 fax machine
📡 satellite antenna
📢 public address loudspeaker
📣 cheering megaphone
📤 outbox tray
📥 inbox tray
📦 package
📧 e-mail symbol
📨 incoming envelope
📩 envelope with downwards arrow above
📪 closed mailbox with lowered flag
📫 closed mailbox with raised flag
📬 open mailbox with raised flag
📭 open mailbox with lowered flag
📮 postbox
📯 postal horn
📰 newspaper
📱 mobile phone
📲 mobile phone with rightwards arrow at left
📳 vibration mode
📴 mobile phone off
📵 no mobile phones
📶 antenna with bars
📷 camera
📸 camera with flash
📹 video camera
📺 television
📻 radio
📼 videocassette
📽️ film projector
📿 prayer beads
🔀 twisted rightwards arrows
🔁 clockwise rightwards and leftwards open circle arrows
🔂 clockwise rightwards and leftwards open circle arrows with circled one overlay
🔃 clockwise downwards and upwards open circle arrows
🔄 anticlockwise downwards and upwards open circle arrows
🔅 low brightness symbol
🔆 high brightness symbol
🔇 speaker with cancellation stroke
🔈 speaker
🔉 speaker with one sound wave
🔊 speaker with three sound waves
🔋 battery
🔌 electric plug
🔍 left-pointing magnifying glass
🔎 right-pointing magnifying glass
🔏 lock with ink pen
🔐 closed lock with key
🔑 key
🔒 lock
🔓 open lock
🔔 bell
🔕 bell with cancellation stroke
🔖 bookmark
🔗 link symbol
🔘 radio button
🔙 back with leftwards arrow above
🔚 end with leftwards arrow above
🔛 on with exclamation mark with left right arrow above
🔜 soon with rightwards arrow above
🔝 top with upwards arrow above
🔞 no one under eighteen symbol
🔟 keycap ten
🔠 input symbol for latin capital letters
🔡 input symbol for latin small letters
🔢 input symbol for numbers
🔣 input symbol for symbols
🔤 input symbol for latin letters
🔥 fire
🔦 electric torch
🔧 wrench
🔨 hammer
🔩 nut and bolt
🔪 hocho
🔫 pistol
🔬 microscope
🔭 telescope
🔮 crystal ball
🔯 six pointed star with middle dot
🔰 japanese symbol for beginner
🔱 trident emblem
🔲 black square button
🔳 white square button
🔴 large red circle
🔵 large blue circle
🔶 large orange diamond
🔷 large blue diamond
🔸 small orange diamond
🔹 small blue diamond
🔺 up-pointing red triangle
🔻 down-pointing red triangle
🔼 up-pointing small red triangle
🔽 down-pointing small red triangle
🕉️ om symbol
🕊️ dove of peace
🕋 kaaba
🕌 mosque
🕍 synagogue
🕎 menorah with nine branches
🕐 clock face one oclock
🕑 clock face two oclock
🕒 clock face three oclock
🕓 clock face four oclock
🕔 clock face five oclock
🕕 clock face six oclock
🕖 clock face seven oclock
🕗 clock face eight oclock
🕘 clock face nine oclock
🕙 clock face ten oclock
🕚 clock face eleven oclock
🕛 clock face twelve oclock
🕜 clock face one-thirty
🕝 clock face two-thirty
🕞 clock face three-thirty
🕟 clock face four-thirty
🕠 clock face five-thirty
🕡 clock face six-thirty
🕢 clock face seven-thirty
🕣 clock face eight-thirty
🕤 clock face nine-thirty
🕥 clock face ten-thirty
🕦 clock face eleven-thirty
🕧 clock face twelve-thirty
🕯️ candle
🕰️ mantelpiece clock
🕳️ hole
🕴️ man in business suit levitating
🕵️ sleuth or spy
🕶️ dark sunglasses
🕷️ spider
🕸️ spider web
🕹️ joystick
🕺 man dancing
🖇️ linked paperclips
🖊️ lower left ballpoint pen
🖋️ lower left fountain pen
🖌️ lower left paintbrush
🖍️ lower left crayon
🖐️ raised hand with fingers splayed
🖕 reversed hand with middle finger extended
🖖 raised hand with part between middle and ring fingers
🖤 black heart
🖥️ desktop computer
🖨️ printer
🖱️ three button mouse
🖲️ trackball
🖼️ frame with picture
🗂️ card index dividers
🗃️ card file box
🗄️ file cabinet
🗑️ wastebasket
🗒️ spiral note pad
🗓️ spiral calendar pad
🗜️ compression
🗝️ old key
🗞️ rolled-up newspaper
🗡️ dagger knife
🗣️ speaking head in silhouette
🗨️ left speech bubble
🗯️ right anger bubble
🗳️ ballot box with ballot
🗺️ world map
🗻 mount fuji
🗼 tokyo tower
🗽 statue of liberty
🗾 silhouette of japan
🗿 moyai
🚀 rocket
🚁 helicopter
🚂 steam locomotive
🚃 railway car
🚄 high-speed train
🚅 high-speed train with bullet nose
🚆 train
🚇 metro
🚈 light rail
🚉 station
🚊 tram
🚋 tram car
🚌 bus
🚍 oncoming bus
🚎 trolleybus
🚏 bus stop
🚐 minibus
🚑 ambulance
🚒 fire engine
🚓 police car
🚔 oncoming police car
🚕 taxi
🚖 oncoming taxi
🚗 automobile
🚘 oncoming automobile
🚙 recreational vehicle
🚚 delivery truck
🚛 articulated lorry
🚜 tractor
🚝 monorail
🚞 mountain railway
🚟 suspension railway
🚠 mountain cableway
🚡 aerial tramway
🚢 ship
🚣 rowboat
🚤 speedboat
🚥 horizontal traffic light
🚦 vertical traffic light
🚧 construction sign
🚨 police cars revolving light
🚩 triangular flag on post
🚪 door
🚫 no entry sign
🚬 smoking symbol
🚭 no smoking symbol
🚮 put litter in its place symbol
🚯 do not litter symbol
🚰 potable water symbol
🚱 non-potable water symbol
🚲 bicycle
🚳 no bicycles
🚴 bicyclist
🚵 mountain bicyclist
🚶 pedestrian
🚷 no pedestrians
🚸 children crossing
🚹 mens symbol
🚺 womens symbol
🚻 restroom
🚼 baby symbol
🚽 toilet
🚾 water closet
🚿 shower
🛀 bath
🛁 bathtub
🛂 passport control
🛃 customs
🛄 baggage claim
🛅 left luggage
🛋️ couch and lamp
🛌 sleeping accommodation
🛍️ shopping bags
🛎️ bellhop bell
🛏️ bed
🛐 place of worship
🛑 octagonal sign
🛒 shopping trolley
🛕 hindu temple
🛖 hut
🛗 elevator
🛜 wireless
🛝 playground slide
🛞 wheel
🛟 ring buoy
🛠️ hammer and wrench
🛡️ shield
🛢️ oil drum
🛣️ motorway
🛤️ railway track
🛥️ motor boat
🛩️ small airplane
🛫 airplane departure
🛬 airplane arriving
🛰️ satellite
🛳️ passenger ship
🛴 scooter
🛵 motor scooter
🛶 canoe
🛷 sled
🛸 flying saucer
🛹 skateboard
🛺 auto rickshaw
🛻 pickup truck
🛼 roller skate
↔️ left right arrow
↕️ up down arrow
↖️ north west arrow
↗️ north east arrow
↘️ south east arrow
↙️ south west arrow
↩️ leftwards arrow with hook
↪️ rightwards arrow with hook
⌚ watch
⌛ hourglass
⌨️ keyboard
⏏️ eject symbol
⏩ black right-pointing double triangle
⏪ black left-pointing double triangle
⏫ black up-pointing double triangle
⏬ black down-pointing double triangle
⏭️ black right-pointing double triangle with vertical bar
⏮️ black left-pointing double triangle with vertical bar
⏯️ black right-pointing triangle with double vertical bar
⏰ alarm clock
⏱️ stopwatch
⏲️ timer clock
⏳ hourglass with flowing sand
⏸️ double vertical bar
⏹️ black square for stop
⏺️ black circle for record
Ⓜ️ circled latin capital letter m
▪️ black small square
▫️ white small square
▶️ black right-pointing triangle
◀️ black left-pointing triangle
◻️ white medium square
◼️ black medium square
◽ white medium small square
◾ black medium small square
☀️ black sun with rays
☁️ cloud
☂️ umbrella
☃️ snowman
☄️ comet
☎️ black telephone
☑️ ballot box with check
☔ umbrella with rain drops
☕ hot beverage
☘️ shamrock
☝️ white up pointing index
☠️ skull and crossbones
☢️ radioactive sign
☣️ biohazard sign
☦️ orthodox cross
☪️ star and crescent
☮️ peace symbol
☯️ yin yang
☸️ wheel of dharma
☹️ white frowning face
☺️ white smiling face
♀️ female sign
♂️ male sign
♈ aries
♉ taurus
♊ gemini
♋ cancer
♌ leo
♍ virgo
♎ libra
♏ scorpius
♐ sagittarius
♑ capricorn
♒ aquarius
♓ pisces
♟️ black chess pawn
♠️ black spade suit
♣️ black club suit
♥️ black heart suit
♦️ black diamond suit
♨️ hot springs
♻️ black universal recycling symbol
♾️ permanent paper sign
♿ wheelchair symbol
⚒️ hammer and pick
⚓ anchor
⚔️ crossed swords
⚕️ staff of aesculapius
⚖️ scales
⚗️ alembic
⚙️ gear
⚛️ atom symbol
⚜️ fleur-de-lis
⚠️ warning sign
⚡ high voltage sign
⚧️ male with stroke and male and female sign
⚪ medium white circle
⚫ medium black circle
⚰️ coffin
⚱️ funeral urn
⚽ soccer ball
⚾ baseball
⛄ snowman without snow
⛅ sun behind cloud
⛈️ thunder cloud and rain
⛎ ophiuchus
⛏️ pick
⛑️ helmet with white cross
⛓️ chains
⛔ no entry
⛩️ shinto shrine
⛪ church
⛰️ mountain
⛱️ umbrella on ground
⛲ fountain
⛳ flag in hole
⛴️ ferry
⛵ sailboat
⛷️ skier
⛸️ ice skate
⛹️ person with ball
⛺ tent
⛽ fuel pump
✂️ black scissors
✅ white heavy check mark
✈️ airplane
✉️ envelope
✊ raised fist
✋ raised hand
✌️ victory hand
✍️ writing hand
✏️ pencil
✒️ black nib
✔️ heavy check mark
✖️ heavy multiplication x
✝️ latin cross
✡️ star of david
✨ sparkles
✳️ eight spoked asterisk
✴️ eight pointed black star
❄️ snowflake
❇️ sparkle
❌ cross mark
❎ negative squared cross mark
❓ black question mark ornament
❔ white question mark ornament
❕ white exclamation mark ornament
❗ heavy exclamation mark symbol
❣️ heavy heart exclamation mark ornament
❤️ heavy black heart
➕ heavy plus sign
➖ heavy minus sign
➗ heavy division sign
➡️ black rightwards arrow
➰ curly loop
➿ double curly loop
⤴️ arrow pointing rightwards then curving upwards
⤵️ arrow pointing rightwards then curving downwards
⬅️ leftwards black arrow
⬆️ upwards black arrow
⬇️ downwards black arrow
⬛ black large square
⬜ white large square
⭐ white medium star
⭕ heavy large circle
〰️ wavy dash
〽️ part alternation mark
㊗️ circled ideograph congratulation
㊙️ circled ideograph secret
🀄 mahjong tile red dragon
🃏 playing card black joker
🅰️ negative squared latin capital letter a
🅱️ negative squared latin capital letter b
🅾️ negative squared latin capital letter o
🅿️ negative squared latin capital letter p
🆎 negative squared ab
🆑 squared cl
🆒 squared cool
🆓 squared free
🆔 squared id
🆕 squared new
🆖 squared ng
🆗 squared ok
🆘 squared sos
🆙 squared up with exclamation mark
🆚 squared vs
🈁 squared katakana koko
🈂️ squared katakana sa
🈚 squared cjk unified ideograph-7121
🈯 squared cjk unified ideograph-6307
🈲 squared cjk unified ideograph-7981
🈳 squared cjk unified ideograph-7a7a
🈴 squared cjk unified ideograph-5408
🈵 squared cjk unified ideograph-6e80
🈶 squared cjk unified ideograph-6709
🈷️ squared cjk unified ideograph-6708
🈸 squared cjk unified ideograph-7533
🈹 squared cjk unified ideograph-5272
🈺 squared cjk unified ideograph-55b6
🉐 circled ideograph advantage
🉑 circled ideograph accept
🟠 large orange circle
🟡 large yellow circle
🟢 large green circle
🟣 large purple circle
🟤 large brown circle
🟥 large red square
🟦 large blue square
🟧 large orange square
🟨 large yellow square
🟩 large green square
🟪 large purple square
🟫 large brown square
🟰 heavy equals sign`.split("\n").map((l) => { const i = l.indexOf(" "); return {e: l.slice(0, i), n: l.slice(i + 1)}; });

  // Search by Korean word, English name or the emoji itself. Concept matches (a word the query
  // is part of, or that is part of the query) come first, then names containing a query word.
  function search(q, limit) {
    q = String(q || "").trim().toLowerCase();
    limit = limit || 400;
    if (!q) return ALL.slice(0, limit);
    const out = [], seen = new Set();
    const push = (o) => { if (!seen.has(o.e)) { seen.add(o.e); out.push(o); } };
    const words = new Set(q.split(/\s+/).filter(Boolean));
    CONCEPTS.forEach((c) => {
      if (c[0].some((w) => mention(q, w) || (q.length > 1 && w.includes(q)))) {
        withVs(c[1]).forEach((e) => { const hit = ALL.find((o) => strip(o.e) === strip(e)); push(hit || {e, n: ""}); });
        c[2].split(" ").forEach((w) => words.add(w));
      }
    });
    ALL.forEach((o) => { if (out.length < limit && (o.e === q || o.n.includes(q) || Array.from(words).some((w) => o.n.split(" ").includes(w)))) push(o); });
    return out.slice(0, limit);
  }

  // A name as it reads beside a face (a project's emoji or icon drawn before it): the one emoji the
  // name itself opens with, and the space after it, is left out, whichever emoji it is. One emoji
  // is one picture: a ZWJ sequence, a variation selector, a skin tone, a flag, a keycap. A name
  // that is nothing but the emoji stays as written. Only what is shown: the name itself is kept.
  const LEAD = /^\s*(?:\p{Regional_Indicator}{2}|[#*0-9]\uFE0F?\u20E3|\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier}|[\u{E0020}-\u{E007E}]+\u{E007F})?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?)*)\s*/u;
  function bare(name) {
    const s = String(name == null ? "" : name), r = s.replace(LEAD, "");
    return r ? r : s;
  }

  const api = {suggest, search, bare, ALL, CONCEPTS};
  if (typeof window !== "undefined") window.LOOP_EMOJI = api;
  if (typeof module !== "undefined") module.exports = api;
})();
