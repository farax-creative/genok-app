/* The floating window (플로팅): pinned conversations as a stack of blocks on top of other apps.
   This is the app's own page opened as /?float=1 (floatwin.py makes the window): v2.html marks
   <html class="float">, everything but #fl is hidden, and a card opens its conversation in a panel
   beside the stack with the same chat as the room screen (project.js's pjEmbed), so the message
   box, sending and the live tail are one code path.

   The window is a fixed canvas (stack + gap + the wide panel). The page tells the app which boxes are
   visible (api.layout) and the app clips the window to them, so opening the chat never resizes or
   moves anything. Where the stack and the panel sit inside the canvas (the anchor: panel on the
   right or left, how far down the stack starts) comes from the app, which knows the screen.

   Sizes, smallest first: the blocks alone, a mini chat hung on its block (360 by 330: the last
   lines and one line to answer in), the chat (474 wide), and the chat with a side column (what
   waits on the person, and the results this conversation pushed): 작게 | 보통 | 크게 to the person.
   The blocks themselves shrink the way the session list's rows do (블록 작게: one line a block). Nothing else is ever on
   show: no strip above the blocks, no frame. A block's own menu (right-click) and the two buttons
   it shows under the pointer are where it is sized, kept on top and turned off.
   접기 (the menu) folds the blocks into one line of counts in the first block's place; a press on
   it brings them back. A block whose session only waits for 허용 / 거절 carries those two buttons.
   동그라미만 보기 (the menu, off unless asked for) draws each conversation as its round mark alone:
   the state orb on a disc, a press on it opens its chat, and 허용 / 거절 are then in the chat's head. */
// For the main window too (a session row's menu): what floats, and putting one on or off.
window.GenokFloat = {
  pins: () => get("/api/float").then((v) => ((v && v.cards) || []).map((c) => c.sid)),
  set: (sid, on, meta) => post("/api/float/pin", on ? Object.assign({sid, on: true, open: true}, meta || {}) : {sid, on: false}),
  off: (sid) => post("/api/float/pin", {sid, on: false}),
  offAll: () => post("/api/float/off", {}),
};
// The taskbar (taskbar.py), for the main window: its switches as the app holds them, what is
// pinned there, and whether there is a taskbar to speak of (`native`: the PC app's own window).
window.GenokBar = {
  opts: null, native: false, pins: [], max: 0,
  take(v) { this.opts = v.opts; this.native = !!v.native; this.pins = v.pins || []; this.max = v.max || 0; return v; },
  load() { return get("/api/taskbar").then((v) => this.take(v)); },
  set(o) { return post("/api/taskbar/opts", o).then((v) => this.take(v)); },
  pin(sid, on, meta) { return post("/api/taskbar/pin", Object.assign({sid, on}, on ? meta : null)).then((v) => this.take(v)); },
};
if (!document.documentElement.classList.contains("float")) window.GenokBar.load().catch(() => {});
(function () {
  if (!document.documentElement.classList.contains("float")) return;
  // CSS px, the same numbers as floatwin.py.
  const FL = {sw: 403, ch: 85, gap: 4, pw: 474, side: 320, ph: 687, pgap: 10, r: 12, pad: 12, lift: 10};   // r: the app's --r-card, as a number for the window's cut
  const PWL = FL.pw + FL.side;                                  // the panel with its side column
  const MINI = {w: 360, h: 330};                                // the mini chat (floatwin.MINI_W, MINI_H)
  const DENSE = {sw: 260, ch: 40, gap: 4};                      // the blocks at 작게: the session list's one-line row
  const ASK_W = 124;                                            // room for 거절 and 허용 on a block
  // A conversation pinned to the taskbar opens in a window of its own (taskbar.py): this page with
  // only the chat panel. No blocks to hang a mini chat on there.
  const SOLO = location.hash === "#solo";
  const SIZES = SOLO ? ["s", "l"] : ["m", "s", "l"];
  const ORB_D = 44;                                             // a conversation as its round mark alone (floatwin.ORB_D)
  const SIZE_KEY = SOLO ? "fl-size-solo" : "fl-size", DENSE_KEY = "fl-dense", PILL_KEY = "fl-pill", ORBS_KEY = "fl-orbs", OUT_KEY = "fl-out";
  const POLL = 4000, DRAG = 4, DATA = 15000, ROLL = 140;
  const HOV_W = 112, HOV_W2 = 72;   // what a block's hover buttons cover past its own padding: three of them, two

  const CSS = `
  /* The page paints nothing of its own: only the boxes below are drawn, and the window is cut to them. */
  html.float,html.float body{height:100%;min-height:0;overflow:hidden;background:transparent}
  html.float body>:not(#fl):not(#sheet):not(#toast):not(.pj-pop):not(.cs-scrim){display:none!important}
  /* Dialogs and the toast belong to the panel (or the stack while the chat is closed), not to the
     canvas: the rest of the canvas is clipped away. */
  html.float .sheet,html.float .cs-scrim{inset:auto;left:var(--fl-hx);top:var(--fl-hy);width:var(--fl-hw);height:var(--fl-hh);border-radius:${FL.r}px;overflow:hidden}
  html.float .sheet .sbox{max-height:calc(var(--fl-hh) - 24px)}
  /* The toast is a line of the float's own: under the blocks while the chat is closed (the window
     is cut to let it through, see report()), inside the chat while it is open. It does not slide. */
  html.float .toast{left:var(--fl-tx,0px);right:auto;bottom:auto;top:var(--fl-ty,0px);max-width:var(--fl-tw,${FL.sw}px);box-sizing:border-box;transform:none;transition:opacity .12s;font-size:13px;padding:8px 12px;border-radius:12px;box-shadow:0 8px 10px -8px rgba(0,0,0,.5);text-align:left}
  html.float .toast.act{padding:6px 6px 6px 12px;gap:8px}
  html.float .toast .tt{font-size:13px}
  /* The window is see-through (floatwin.see_through), so a box sets itself off from the app
     underneath as anything on a desk does: an edge line, a lit top edge, and a shadow that falls
     below it. The window is FL.pad bigger all round to hold the shadows, and lets each box through with
     FL.lift (a block) or FL.pad (the chat, a menu) around it: no shadow reaches further than that.
     Only the last block casts one, straight down, so the gaps between blocks stay clear. */
  .fl{position:fixed;left:${FL.pad}px;top:${FL.pad}px;width:${FL.sw + FL.pgap + PWL}px;height:calc(100% - ${2 * FL.pad}px);user-select:none;-webkit-user-select:none;
    --fl-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 10%,transparent),inset 0 1px 0 color-mix(in srgb,var(--t1) 6%,transparent);
    --fl-ring:0 0 0 1px rgba(0,0,0,.16);--fl-lift:0 8px 10px -8px rgba(0,0,0,.5);--fl-deep:0 4px 12px -8px rgba(0,0,0,.6)}
  html[data-theme="light"] .fl{--fl-edge:inset 0 0 0 1px color-mix(in srgb,var(--t1) 14%,transparent);--fl-ring:0 0 0 1px rgba(0,0,0,.06);--fl-lift:0 8px 10px -8px rgba(0,0,0,.22);--fl-deep:0 4px 12px -8px rgba(0,0,0,.3)}
  .fl-stack{position:absolute;left:0;top:0;width:${FL.sw}px;display:flex;flex-direction:column;gap:${FL.gap}px;overscroll-behavior:contain;scrollbar-width:none}
  /* Only a stack with more blocks than fit scrolls (report): a scrolling box would cut its blocks' shadows off. */
  .fl-stack.over{overflow-y:auto}
  .fl-stack>*{--fl-lift:0 0 transparent} .fl-stack>:last-child{--fl-lift:0 8px 10px -8px rgba(0,0,0,.5)}
  html[data-theme="light"] .fl-stack>:last-child{--fl-lift:0 8px 10px -8px rgba(0,0,0,.22)}
  .fl-stack::-webkit-scrollbar{display:none}
  .fl[data-side="left"] .fl-stack{left:${PWL + FL.pgap}px}
  .fl.solo .fl-stack,.fl.solo [data-sz="m"]{display:none}
  /* The pinned chat's window is the panel and nothing more: no room around it for a shadow, and no
     edge to drag (the window is as wide as the size picked). */
  .fl.solo{left:0;top:0;width:100%}
  .fl.solo .fl-panel{box-shadow:none}
  .fl.solo .fl-grip{display:none}
  .fl-cw.hi{animation:fl-hi .5s cubic-bezier(.2,.9,.3,1) var(--hi-d,0ms) both}
  .fl-cw.hi::after{content:"";position:absolute;inset:0;z-index:3;border-radius:inherit;border:2px solid var(--accent);pointer-events:none;opacity:0;animation:fl-ring 1.5s ease-out var(--hi-d,0ms) both}
  @keyframes fl-hi{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:none}}
  @keyframes fl-ring{0%{opacity:0;transform:scale(.97)}18%{opacity:.9;transform:none}55%{opacity:.5}100%{opacity:0;transform:none}}
  @media(prefers-reduced-motion:reduce){.fl-cw.hi{animation:fl-fade .3s ease both}.fl-cw.hi::after{animation:fl-fade 1.2s ease reverse both}}
  @keyframes fl-fade{from{opacity:0}to{opacity:1}}
  .fl-cw.lift{cursor:grabbing}.fl-cw.lift .fl-card{--cb:var(--card-hi)}
  .fl-cw{position:relative;flex:none;border-radius:${FL.r}px;box-shadow:var(--fl-ring),var(--fl-lift)}
  .fl.orbs .fl-cw{border-radius:50%}
  .fl-card{flex:none;display:flex;align-items:center;gap:12px;width:100%;height:${FL.ch}px;padding:0 16px 0 16px;border-radius:${FL.r}px;--cb:var(--card);background:var(--cb);
    box-shadow:var(--fl-edge);text-align:left;cursor:pointer;transition:background-color .12s ease;position:relative;overflow:hidden;isolation:isolate;--orb-ink:var(--sr-ink)}
  /* The same block as a session row of the main window (project.js, the --sr-* tokens): the state
     orb before the title and its light bleeding faintly into the block, one still gradient. */
  .fl-card::before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;
    background:radial-gradient(170px 110px at 36px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),calc(var(--a) * var(--sr-ga) * .35)) 45%,rgba(var(--g),0) 100%)}
  .fl-card.s-ended::before{display:none}
  .fl-card.s-live{--g:var(--sr-gw);--a:.15;--orb-ink:var(--sr-work)} .fl-card.s-idle{--g:var(--sr-g);--a:.03}
  html[data-theme="light"] .fl-card.s-live{--a:.3}
  /* 작업 중: one slow light along the block's top edge, as the session list's rows (transform only). */
  .fl-card.s-live::after{content:"";position:absolute;left:0;top:0;width:42%;height:1px;pointer-events:none;will-change:transform;
    background:linear-gradient(90deg,rgba(var(--sr-gw),0),rgba(var(--sr-gw),.85) 50%,rgba(var(--sr-gw),0));
    transform:translateX(-100%);animation:fl-sheen 5.2s linear infinite}
  html[data-theme="light"] .fl-card.s-live::after{height:2px}
  @keyframes fl-sheen{to{transform:translateX(240%)}}
  @media(prefers-reduced-motion:reduce){.fl-card.s-live::after{animation:none;transform:none;width:60%;
    background:linear-gradient(90deg,rgba(var(--sr-gw),.6),rgba(var(--sr-gw),0))}}
  .fl-card.s-turn{--g:var(--sr-gt);--a:.2;--orb-ink:var(--sr-turn);box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.3)}
  .fl-card.s-stuck{--g:var(--sr-gs);--a:.15;--orb-ink:var(--sr-stuck)}
  @media(hover:hover){.fl-cw:hover .fl-card{--cb:var(--card-hi)}}
  .fl-card:active{--cb:var(--btn)}
  /* The open card is one step brighter than a hovered one, with a lighter edge. */
  .fl-card.open{--cb:var(--btn);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--t1) 20%,transparent)}
  .fl-card:focus-visible,.fl-pill:focus-visible,.fl-seg button:focus-visible,.fl-ib:focus-visible,.fl-btn:focus-visible,.fl-rec:focus-visible,.fl-res:focus-visible,.fl-lnk:focus-visible,.fl-vfs button:focus-visible,.fl-pop button:focus-visible,.fl-meta button:focus-visible{outline:2px solid var(--focus-line);outline-offset:-2px}
  .fl-tile{flex:none;width:44px;height:44px;display:grid;place-items:center}
  .fl-tile rl-orb{display:block}
  .fl-tile .st-dot{width:9px;height:9px;border-radius:50%;background:var(--orb-ink)}
  .fl-card.s-idle .fl-tile rl-orb{opacity:.62}
  .fl-card.s-ended .fl-tile rl-orb{opacity:.42}
  .fl-agd{flex:none;display:inline-block;width:6px;height:6px;border-radius:50%;margin:0 4px 1px 1px;vertical-align:middle;background:var(--ag-claude)}
  .fl-agd.cx{background:var(--ag-codex)}
  .fl-tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
  .fl-t{font-size:16px;font-weight:600;line-height:21px;letter-spacing:-.014em;color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fl-s{display:flex;align-items:center;gap:6px;min-width:0;font-size:13px;line-height:18px;color:var(--t3)}
  .fl-s span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* Before the project name, while the conversation waits on the person. It arrives once. */
  .fl-turn{flex:none;height:18px;padding:0 8px;border-radius:99px;background:rgba(var(--sr-gt),.15);color:var(--sr-turn);font-size:12px;font-weight:700;line-height:18px}
  .fl-turn.ping{animation:fl-ping .45s var(--ease) 1}
  @keyframes fl-ping{from{transform:scale(.8);opacity:0}}
  .fl-rt{flex:none;align-self:stretch;display:flex;flex-direction:column;align-items:flex-end;justify-content:center;gap:6px;min-width:0}
  .fl-at{font-size:12px;line-height:21px;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap}
  /* How many answers are waiting: the app's own count badge (.ib .bcnt), in the row under the time. */
  .fl-n{min-width:18px;height:18px;padding:0 4px;border-radius:99px;background:var(--red);color:#fff;font-size:12px;font-weight:700;line-height:18px;text-align:center;font-variant-numeric:tabular-nums}
  .fl-n:empty{visibility:hidden}
  /* Under the pointer (or the keyboard) a block shows its two buttons where the time was: its size, and off. */
  .fl-hov{position:absolute;right:12px;top:50%;display:flex;gap:4px;transform:translateY(-50%);opacity:0;pointer-events:none;transition:opacity .12s ease}
  .fl-hov .fl-ib{background:var(--btn)}
  .fl-hov .fl-ib:hover{background:var(--btn-hi)}
  .fl-hov .fl-ib svg{width:17px;height:17px}
  /* While the buttons are up the hidden time and count hold their width (three buttons, two on an ended block): the
     title ends before them. Nothing else in the block moves. */
  @media(hover:hover){.fl-cw:hover .fl-hov{opacity:1;pointer-events:auto}.fl-cw:hover .fl-rt{visibility:hidden;min-width:${HOV_W}px}
    .fl-cw:hover .fl-card.gone .fl-rt,.fl.dense .fl-cw:hover .fl-rt{min-width:${HOV_W2}px}}
  .fl-cw:has(:focus-visible) .fl-hov{opacity:1;pointer-events:auto}
  .fl-cw:has(:focus-visible) .fl-rt{visibility:hidden;min-width:${HOV_W}px}
  .fl-cw:has(:focus-visible) .fl-card.gone .fl-rt,.fl.dense .fl-cw:has(:focus-visible) .fl-rt{min-width:${HOV_W2}px}
  /* 작게: one line a block, as the session list's 작게 (project.js .pj-srows.sm). The title, how it is doing, when. */
  .fl.dense .fl-stack{width:${DENSE.sw}px;gap:${DENSE.gap}px}
  .fl.dense .fl-card{height:${DENSE.ch}px;gap:8px;padding:0 12px 0 8px}
  .fl.dense .fl-card::before{background:radial-gradient(90px 50px at 20px 50%,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),0) 100%)}
  .fl.dense .fl-tile{width:24px;height:24px}
  .fl.dense .fl-tx{flex-direction:row;align-items:center;gap:8px}
  .fl.dense .fl-t{flex:0 1 auto;min-width:0;font-size:13px;font-weight:500;line-height:18px;letter-spacing:0}
  .fl.dense .fl-s{flex:none}
  .fl.dense .fl-s .fl-agd{margin:0}
  .fl.dense .fl-rt{flex-direction:row;align-items:center;gap:6px}
  .fl.dense .fl-at{font-size:12px;line-height:18px}
  .fl.dense .fl-n:empty{display:none}
  .fl.dense .fl-hov{right:2px;gap:2px}
  /* 접기: the blocks as one line of counts, where the first block was. As wide as what it says. */
  .fl-pill{flex:none;align-self:flex-start;display:flex;align-items:center;gap:8px;max-width:100%;height:${DENSE.ch}px;padding:0 12px 0 8px;border-radius:${FL.r}px;--cb:var(--card);background:var(--cb);
    box-shadow:var(--fl-edge),var(--fl-lift);font-size:13px;line-height:18px;color:var(--t2);white-space:nowrap;cursor:pointer;transition:background-color .12s ease;--orb-ink:var(--t4)}
  .fl-pill.s-turn{--orb-ink:var(--sr-turn);box-shadow:inset 0 0 0 1px rgba(var(--sr-gt),.3),var(--fl-lift)} .fl-pill.s-live{--orb-ink:var(--sr-work)}
  @media(hover:hover){.fl-pill:hover{--cb:var(--card-hi)}}
  .fl-pill:active{--cb:var(--btn)}
  .fl-pill .fl-tile{width:24px;height:24px}
  .fl-pill b{font-weight:600;color:var(--t1)}
  .fl-pill .fl-n:empty{display:none}
  /* 허용 / 거절 on the block itself, where the time was: all a session that asks to run something needs. */
  .fl-ask{position:absolute;right:12px;top:50%;display:flex;gap:6px;transform:translateY(-50%)}
  .fl-cw.asking .fl-card{padding-right:${ASK_W + 24}px}
  .fl-cw.asking .fl-rt,.fl-cw.asking .fl-hov{display:none}
  /* 동그라미만 보기: a conversation is its state orb on a disc and nothing else. The ring says how it
     is doing (its turn, working), the corner mark that it waits on the person or how much is unread. */
  .fl.orbs .fl-stack{width:${ORB_D}px}
  .fl.orbs .fl-card{width:${ORB_D}px;height:${ORB_D}px;padding:0;gap:0;justify-content:center;border-radius:50%}
  .fl.orbs .fl-card::before{background:radial-gradient(closest-side,rgba(var(--g),calc(var(--a) * var(--sr-ga))) 0,rgba(var(--g),0) 100%)}
  .fl.orbs .fl-card.s-live::after{display:none}
  .fl.orbs .fl-card.s-live{box-shadow:inset 0 0 0 2px rgba(var(--sr-gw),.55)}
  .fl.orbs .fl-card.s-turn{box-shadow:inset 0 0 0 2px rgba(var(--sr-gt),.8)}
  .fl.orbs .fl-card.s-stuck{box-shadow:inset 0 0 0 2px rgba(var(--sr-gs),.6)}
  .fl.orbs .fl-card.open{box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--t1) 45%,transparent)}
  .fl-ob{position:absolute;right:0;top:0;min-width:16px;height:16px;padding:0 4px;border-radius:99px;background:var(--red);color:#fff;font-size:12px;font-weight:700;line-height:16px;text-align:center;font-variant-numeric:tabular-nums;pointer-events:none}
  .fl-ob.turn{width:14px;min-width:0;height:14px;padding:0;background:var(--sr-turn)}
  .fl-ob.ping{animation:fl-ping .45s var(--ease) 1}
  /* What the open conversation waits to be allowed, under the chat's head (동그라미만 보기 has no block to carry it). */
  .fl-pask{flex:none;display:flex;align-items:center;gap:8px;min-height:44px;padding:6px 12px 6px 16px;background:rgba(var(--sr-gt),.1)}
  .fl-pask[hidden]{display:none}
  .fl-pask>span:not(.fl-turn){flex:1;min-width:0;font-size:13px;line-height:18px;color:var(--t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* A block's menu (right-click): its own box, cut out of the window like the blocks. */
  .fl-pop.fl-menu,html[data-theme="light"] .fl-pop.fl-menu{right:auto;left:0;top:0;min-width:212px;box-shadow:var(--fl-deep)}
  .fl-menu button,.fl-pop [role="menuitemcheckbox"]{justify-content:space-between;gap:16px}
  .fl-menu small{font-size:12px;font-weight:500;color:var(--t3)}
  /* An option: its name stays, the mark at the end says whether it is on. */
  .fl-pop [role="menuitemcheckbox"]>span{flex:1}
  .fl-ck{flex:none;display:inline-flex;width:16px;height:16px;color:var(--t1)}
  .fl-ck svg{width:16px;height:16px}
  .fl-pop hr{height:1px;margin:4px 6px;border:0;background:var(--line)}
  /* The hover button that shrinks the blocks: thin lines (to one-line blocks) or two bars (back). Drawn here whole. */
  .fl-hov .pj-mini{display:flex;flex-direction:column;justify-content:center;width:16px;height:16px;gap:2px}
  .fl-hov .pj-mini i{display:block;height:2px;border-radius:2px;background:currentColor;opacity:.75}
  .fl-hov .pj-mini.md{gap:4px}.fl-hov .pj-mini.md i{height:5px;border-radius:2.5px}
  .fl-hov [aria-pressed="true"]{color:var(--t1)}
  .fl-pick .lbl{margin-top:0}
  .fl-card.gone .fl-t{color:var(--t3)}
  /* The project's face before the title, as the session list draws it (project.js .pj-face). */
  .fl-face{display:inline-grid;place-items:center;width:17px;height:17px;margin-right:6px;vertical-align:-2.5px;font-size:14.5px;line-height:1;color:var(--t2)}
  .fl-face .phi{display:block;width:17px;height:17px} .fl-face.hv .phi{width:16px;height:16px}
  .fl-face.tint{color:color-mix(in srgb,var(--em-c) 70%,var(--t1))}
  .fl.dense .fl-face{width:15px;height:15px;font-size:12px;margin-right:4px} .fl.dense .fl-face .phi{width:15px;height:15px} .fl.dense .fl-face.hv .phi{width:14px;height:14px}
  /* Nothing pinned, or the app cannot be reached: one box the size of a card or two. */
  .fl-empty{position:relative;flex:none;padding:16px 16px 16px;border-radius:${FL.r}px;background:var(--card);box-shadow:var(--fl-edge),var(--fl-lift);cursor:default}
  .fl-empty b{display:block;padding-right:40px;font-size:15px;font-weight:600;line-height:20px;color:var(--t1)}
  .fl-empty p{margin:4px 0 0;padding-right:20px;font-size:12px;line-height:1.55;color:var(--t3);word-break:keep-all}
  .fl-empty .lbl{margin:16px 0 6px;font-size:12px;font-weight:600;color:var(--t3)}
  .fl-rec{display:flex;align-items:center;gap:8px;width:100%;height:40px;padding:0 12px;margin:0 0 4px;border-radius:var(--r-md);background:var(--btn);color:var(--t1);text-align:left;cursor:pointer}
  .fl-rec:hover{background:var(--btn-hi)}
  .fl-rec svg{flex:none;width:15px;height:15px;color:var(--t3)}
  .fl-rec b{flex:1;min-width:0;padding:0;font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fl-rec small{flex:0 1 auto;max-width:40%;font-size:12px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fl-acts{display:flex;gap:8px;margin-top:12px}
  /* Buttons are the app's .btn (38 high) and .btn.sm (32): only what the window adds is here. */
  .fl-btn{cursor:pointer;transition:background-color .12s ease}
  .fl-btn:active,.fl-rec:active{background:color-mix(in srgb,var(--btn-hi) 80%,var(--t1))}
  .fl-empty .fl-x{position:absolute;top:8px;right:8px}
  .fl-note{flex:none;display:flex;align-items:center;gap:8px;height:44px;padding:0 6px 0 16px;border-radius:var(--r-lg);background:var(--card);box-shadow:var(--fl-edge),var(--fl-lift);font-size:13px;color:var(--t2)}
  .fl-note span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* The chat panel, attached to the stack. */
  .fl-panel{position:absolute;left:${FL.sw + FL.pgap}px;top:0;width:${FL.pw}px;display:flex;flex-direction:column;border-radius:${FL.r}px;background:var(--card);box-shadow:var(--fl-ring),var(--fl-deep);overflow:hidden}
  /* The edge is drawn over what is inside, so the chat scrolls under it, not across it. */
  .fl-panel::after{content:"";position:absolute;inset:0;z-index:7;border-radius:inherit;box-shadow:var(--fl-edge);pointer-events:none}
  /* On its way out the panel shows what it has: never the loading bars. */
  .fl-panel.out .fl-skel{display:none}
  /* Under the header: the chat, and beside it the side column when it is turned on (the header's button). */
  .fl-row{position:relative;flex:1;min-height:0;display:flex}
  .fl[data-side="left"] .fl-row{flex-direction:row-reverse}
  .fl-chat{position:relative;flex:1 1 0;min-width:0;min-height:0;display:flex;flex-direction:column}
  .fl-side{flex:none;width:${FL.side}px;min-height:0;display:flex;flex-direction:column;border-left:1px solid var(--line);user-select:none;-webkit-user-select:none}
  .fl[data-side="left"] .fl-side{border-left:0;border-right:1px solid var(--line)}
  .fl-side[hidden]{display:none}
  .fl-sc{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:2px 12px 16px}
  .fl-lab{display:flex;align-items:center;gap:6px;margin:16px 6px 6px;font-size:12px;font-weight:600;color:var(--t3)}
  .fl-lab:first-child{margin-top:4px}
  .fl-lab .n{font-variant-numeric:tabular-nums;color:var(--t4)}
  .fl-lab .n.hot{min-width:18px;height:18px;padding:0 4px;border-radius:99px;background:var(--red);color:#fff;font-size:12px;font-weight:700;line-height:18px;text-align:center}
  .fl-none{margin:0 6px;padding:6px 0 2px;font-size:13px;line-height:1.5;color:var(--t3)}
  .fl-res{display:flex;align-items:center;gap:8px;width:100%;min-height:56px;padding:8px 6px;border-radius:var(--r-md);text-align:left;cursor:pointer;transition:background-color .12s ease}
  @media(hover:hover){.fl-res:hover{background:var(--btn)}}
  .fl-res:active,.fl-res.on{background:var(--btn-hi)}
  .fl-res .tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .fl-res .t{font-size:14px;font-weight:600;line-height:19px;color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fl-res .s{font-size:12px;line-height:16px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-variant-numeric:tabular-nums}
  .fl-res .tag{flex:none}
  .fl-lnk{display:block;margin:4px 6px 0;height:32px;font-size:13px;font-weight:600;color:var(--blue-t,var(--blue));cursor:pointer}
  /* The panel's outer edge: drag it to take the side column out or put it away. */
  .fl-grip{position:absolute;top:60px;bottom:20px;right:0;width:14px;z-index:6;cursor:ew-resize;touch-action:none}
  .fl[data-side="left"] .fl-grip{right:auto;left:0}
  .fl-grip::after{content:"";position:absolute;top:50%;right:3px;width:3px;height:36px;margin-top:-16px;border-radius:2px;background:var(--t4);opacity:0;transition:opacity .12s ease}
  .fl[data-side="left"] .fl-grip::after{right:auto;left:3px}
  .fl-grip:hover::after,.fl-grip.on::after{opacity:1}
  /* The corner away from the blocks: the width and the height both follow it. */
  .fl-corner{position:absolute;right:0;bottom:0;width:20px;height:20px;z-index:7;cursor:nwse-resize;touch-action:none}
  .fl[data-side="left"] .fl-corner{right:auto;left:0;cursor:nesw-resize}
  .fl-corner::after{content:"";position:absolute;right:5px;bottom:5px;width:8px;height:8px;border-right:2px solid var(--t4);border-bottom:2px solid var(--t4);border-radius:0 0 5px 0;opacity:0;transition:opacity .12s ease}
  .fl[data-side="left"] .fl-corner::after{right:auto;left:5px;border-right:0;border-left:2px solid var(--t4);border-radius:0 0 0 5px}
  .fl-corner:hover::after,.fl-corner.on::after{opacity:1}
  .fl.solo .fl-corner,.fl-panel.mini .fl-corner,.fl-panel.mini [data-sidetog]{display:none}
  /* The side column's button, in the header: lit while the column is on show, and how much waits in it while it is not. */
  .fl-ib[data-sidetog][aria-pressed="true"]{background:var(--btn);color:var(--t1);box-shadow:inset 0 0 0 1px var(--t4)}
  .fl-ib .fl-n{position:absolute;right:2px;top:2px;min-width:16px;height:16px;padding:0 4px;font-size:12px;line-height:16px}
  .fl-ib .fl-n:empty{display:none}
  .fl-ib{position:relative}
  /* The sizes, in the header: 작게 (the mini chat) | 보통 (the chat) | 크게 (the chat, wider). */
  .fl-seg{flex:none;display:flex;padding:2px;margin-right:2px;border-radius:var(--r-md);background:var(--btn)}
  .fl-seg button{display:flex;align-items:center;height:32px;padding:0 12px;border-radius:calc(var(--r-md) - 2px);font-size:12px;font-weight:600;color:var(--t3);white-space:nowrap;cursor:pointer;transition:background-color .12s ease,color .12s ease}
  .fl-seg button[aria-pressed="true"]{background:var(--card);color:var(--t1)}
  .fl-seg .fl-n{margin-left:4px;min-width:16px;height:16px;padding:0 4px;font-size:12px;line-height:16px}
  .fl-seg .fl-n:empty{display:none}
  /* A result, looked at in the window: over the chat and the side column, under the header. */
  .fl-view{position:absolute;inset:0;z-index:5;display:flex;flex-direction:column;background:var(--card);user-select:none;-webkit-user-select:none}
  .fl-vh{flex:none;display:flex;align-items:center;gap:4px;height:48px;padding:0 12px 0 8px}
  .fl-vh .fl-ht b{font-size:15px;line-height:20px}
  .fl-vh .fl-ht span{font-size:12px;line-height:16px}
  .fl-vs{flex:1;min-height:0;margin:0 12px;border-radius:var(--r-md);background:var(--bg);display:grid;place-items:center;overflow:hidden}
  .fl-vs img,.fl-vs video{display:block;max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain}
  .fl-vs video{width:100%;height:100%}
  .fl-vn{display:grid;justify-items:center;gap:8px;padding:24px;text-align:center;font-size:13px;line-height:1.5;color:var(--t3)}
  .fl-vn svg{width:28px;height:28px;color:var(--t4)}
  .fl-vn img{max-height:220px;border-radius:var(--r-sm)}
  .fl-vfs{flex:none;display:flex;gap:6px;padding:8px 12px 0;overflow-x:auto;scrollbar-width:none}
  .fl-vfs button{flex:none;width:52px;height:40px;border-radius:var(--r-sm);background:var(--btn);color:var(--t3);display:grid;place-items:center;overflow:hidden;cursor:pointer;opacity:.6}
  .fl-vfs button.on{opacity:1;box-shadow:inset 0 0 0 2px var(--blue)}
  .fl-vfs img{width:100%;height:100%;object-fit:cover}
  .fl-vfs svg{width:16px;height:16px}
  .fl-vf{flex:none;display:flex;align-items:center;gap:8px;padding:12px}
  .fl-vin{flex:1;min-width:0;height:38px;padding:0 12px;border-radius:var(--r-md);border:1px solid var(--line);background:var(--bg);color:var(--t1);font:inherit;font-size:14.5px;user-select:text;-webkit-user-select:text}
  .fl-vin:focus{outline:0;border-color:var(--focus-line)}
  .fl-vin::placeholder{color:var(--t3)}
  .fl-vf .btn:disabled{opacity:.45;cursor:default}
  .fl-panel[hidden]{display:none}
  /* 작게 (size "m"): the chat hung on its block. The last lines, an answer cut at four lines
     (더 보기 opens 보통), and one line to answer in. */
  .fl-panel.mini .fl-chat{width:100%}
  .fl-panel.mini .fl-grip,.fl-panel.mini [data-more]{display:none}
  .fl-panel.mini .fl-head{height:48px;gap:2px;padding:0 4px}
  .fl-panel.mini .fl-ht{gap:1px;padding-left:2px}
  .fl-panel.mini .fl-ht b{font-size:14px;line-height:19px;letter-spacing:-.01em}
  .fl-panel.mini .fl-ht span{font-size:12px;line-height:15px}
  .fl-panel.mini .fl-seg{margin-right:0}
  .fl-panel.mini .fl-seg button{padding:0 8px;font-size:12px}
  .fl-panel.mini .fl-body .pj-msgs{padding:8px 12px 8px;gap:8px}
  .fl-panel.mini .fl-body .pj-msg{font-size:13px;line-height:1.5}
  .fl-panel.mini .fl-body .pj-msg.user{padding:6px 12px;border-radius:12px 12px 4px 12px}
  .fl-panel.mini .fl-body .pj-msg.claude{position:relative;max-width:100%;max-height:6em;overflow:hidden}
  .fl-panel.mini .fl-meta{display:none}
  /* The room screen's own copy button hangs past the line's edge: here it would only be cut, and count as text that does not fit. */
  .fl-panel.mini .fl-body .pj-msg.claude>.pj-cp{display:none}
  .fl-body .pj-tm{font-size:12px}
  /* A cut answer dissolves over its last line (the cut can fall through the middle of one), and 더 보기 sits on top of that. */
  .fl-panel.mini .pj-msg.fl-clip::after{content:"";position:absolute;left:0;right:0;bottom:0;height:1.9em;pointer-events:none;background:linear-gradient(to bottom,transparent,var(--card) 80%)}
  .fl-mr{display:none}
  .fl-panel.mini .pj-msg.fl-clip .fl-mr{display:block;position:absolute;z-index:1;right:0;bottom:0;height:1.5em;padding:0 0 0 34px;font-size:12px;font-weight:600;line-height:1.5em;
    color:var(--blue-t,var(--blue));background:linear-gradient(to right,transparent,var(--card) 28px);cursor:pointer;user-select:none;-webkit-user-select:none}
  .fl-mr::after{content:"";position:absolute;inset:-6px -4px -6px 20px}
  .fl-panel.mini .fl-body .pj-in{padding:2px 12px 8px}
  .fl-panel.mini .fl-body .pj-box{flex-wrap:nowrap;align-items:flex-end;gap:4px;padding:4px 4px 4px 12px;border-radius:12px}
  .fl-panel.mini .fl-body .pj-box textarea{order:0;flex:1 1 auto;min-width:0;max-height:66px;padding:8px 0;font-size:13px}
  .fl-panel.mini .fl-body .pj-box .pj-clip:not(.pj-mic):not(.pj-vx),.fl-panel.mini .fl-body .pj-mwrap,.fl-panel.mini .fl-body .pj-agseg{display:none}
  .fl-panel.mini .fl-body .pj-go,.fl-panel.mini .fl-body .pj-box :is(.pj-mic,.pj-vx){width:32px;height:32px;margin-left:0}
  .fl-head{flex:none;display:flex;align-items:center;gap:4px;height:60px;padding:0 8px;cursor:default}
  .fl-ib{flex:none;width:36px;height:36px;border-radius:var(--r-md);color:var(--t2);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:background-color .12s ease,color .12s ease}
  .fl-ib:hover{background:var(--btn);color:var(--t1)}
  .fl-ib:active,.fl-ib[aria-expanded="true"]{background:var(--btn-hi);color:var(--t1)}
  .fl-ib svg{width:20px;height:20px}
  .fl-ht{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;padding-left:4px}
  .fl-ht b{font-size:16px;font-weight:600;line-height:22px;letter-spacing:-.016em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .fl-ht span{display:flex;align-items:center;gap:6px;min-width:0;font-size:13px;line-height:17px;color:var(--t3)}
  .fl-ht span span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  /* The app's menu (the --menu-* tokens of v2.css), out of the button's corner. */
  .fl-pop{position:absolute;right:8px;top:52px;z-index:8;min-width:196px;padding:var(--menu-pad);border:1px solid var(--line);border-radius:var(--menu-r);background:var(--menu-bg);
    box-shadow:var(--menu-shadow);transform-origin:calc(100% - 18px) 0}
  html[data-theme="light"] .fl-pop{box-shadow:0 12px 32px rgba(0,0,0,.14)}
  .fl-pop button{display:flex;align-items:center;width:100%;height:var(--menu-row);padding:var(--menu-row-pad);border-radius:var(--menu-row-r);font-size:var(--menu-fs);font-weight:500;color:var(--t1);text-align:left;white-space:nowrap;cursor:pointer}
  .fl-pop button:active{background:color-mix(in srgb,var(--menu-hover) 80%,var(--t1))}
  @media(hover:hover){.fl-pop button:hover{background:var(--menu-hover)}}
  .fl-body{position:relative;flex:1;min-height:0;display:flex;flex-direction:column;user-select:text;-webkit-user-select:text}
  .fl-body.wait>*{visibility:hidden}
  .fl-skel{position:absolute;left:0;right:0;top:0;bottom:0;display:grid;place-items:center;pointer-events:none}
  .fl-gone{margin:auto;padding:24px;text-align:center;font-size:13px;line-height:1.6;color:var(--t3)}
  .fl-gone .fl-acts{justify-content:center}
  /* The room screen's chat, fitted to the panel: the header above says who it is, so the state
     row, the delivery note, the tip and the "to" line are not repeated here. */
  .fl-body .pj-seg,.fl-body #pj-state,.fl-body .pj-tip,.fl-body .pj-to,.fl-body .pj-pjn,.fl-body .pj-enter{display:none!important}
  .fl-body #pj-note:not(:has(.bad)){display:none}
  .fl-body .pj-conv{flex:1;min-height:0;display:flex!important;flex-direction:column;border-radius:0;background:none}
  .fl-body .pj-wrap{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
  /* No line under the header: the chat fades out where it runs under it, and above the message box. */
  .fl-body .pj-msgs{flex:1 1 auto;height:auto;min-height:0;max-height:none;padding:16px 16px 16px;
    -webkit-mask-image:linear-gradient(to bottom,transparent 0,#000 14px,#000 calc(100% - 12px),transparent 100%);
    mask-image:linear-gradient(to bottom,transparent 0,#000 14px,#000 calc(100% - 12px),transparent 100%)}
  /* The bubbles and the message box are the room screen's own, untouched: only their fit to the panel is set. */
  .fl-body .pj-msg{cursor:text}
  .fl-body .pj-in{border-top:0;padding:4px 12px 12px}
  .fl-body .pj-box textarea{cursor:text}
  /* Under what the session said: when, on which model, how long the answer took (each only when
     the transcript says so), and a copy that shows on hover. One row per answer: its last line. */
  .fl-meta[hidden]{display:none}
  .fl-meta{display:flex;align-items:center;gap:4px;height:24px;margin-top:8px;font-size:12px;line-height:18px;letter-spacing:0;color:var(--t3);font-variant-numeric:tabular-nums;white-space:nowrap;cursor:default;user-select:none;-webkit-user-select:none}
  .fl-meta span{min-width:0;overflow:hidden;text-overflow:ellipsis}
  .fl-body .pj-msg.claude:has(+.pj-msg.claude,+.pj-msg.tool) .fl-meta{display:none}
  /* 24px to look at, 36px to press. */
  .fl-meta button{position:relative;flex:none;height:24px;padding:0 8px;border-radius:var(--r-xs);font-size:12px;font-weight:600;color:var(--t2);opacity:0;cursor:pointer;transition:opacity .12s ease,background-color .12s ease}
  .fl-meta button::after{content:"";position:absolute;inset:-6px -4px}
  .fl-body .pj-msg:hover .fl-meta button,.fl-meta button:focus-visible,.fl-meta button.m-cpt{opacity:1}
  .fl-meta button:hover{background:var(--btn);color:var(--t1)}
  @media(prefers-reduced-motion:reduce){.fl-turn.ping,.fl-ob.ping{animation:none}.fl-card,.fl-hov,.fl-seg button,.fl-btn,.fl-ib,.fl-res,.fl-grip::after,.fl-corner::after,.fl-meta button{transition:none}}
  /* touch: the small buttons keep their look and get a 44px hit area (same layer as v2.css) */
  @media(pointer:coarse){.fl-ib,.fl-btn,.fl-pop button{position:relative}
    .fl-ib::before,.fl-btn::before,.fl-pop button::before{content:"";position:absolute;top:min(0px,calc((100% - 44px)/2));bottom:min(0px,calc((100% - 44px)/2));left:min(0px,calc((100% - 44px)/2));right:min(0px,calc((100% - 44px)/2))}}
  `;

  const api = () => (window.pywebview && window.pywebview.api) || null;
  const enc = encodeURIComponent;
  const STATE = () => ({live: tl("pj.st.live"), idle: tl("pj.st.idle"), stuck: tl("pj.st.stuck"), ended: tl("pj.st.ended")});
  let A = {side: "right", dy: 0, ph: FL.ph, smax: FL.ph, top: true, hotkey: false, key: "", snap: true};   // the anchor (see floatwin.plan)
  let V = null, sig = "", cur = null, off = false, pollT = 0, press = null, dragged = false, sent = "";
  let root, stack, panel, toastEl = null, build = "";
  // `leaving` is the conversation whose panel is on its way out (it can still be called back),
  // `runs` what /api/float/meta says of the open conversation's answers, by their time.
  // `pbox`: what the window is cut to while a smaller size is on its way (the cut goes first).
  // `hold`: nothing is reported for the moment. `szT`: the size change in hand.
  let leaving = null, runs = {}, runsT = 0, pbox = null, hold = false, szT = 0;
  // `menu`: the block menu on show. `turned`: the blocks that were waiting on the person at the last draw.
  // `away`: the app has the window put away.
  // `rolling`: the stack is being scrolled (a timer: it ends ROLL ms after the last move).
  let menu = null, turned = null, away = false, rolling = 0;
  // The panel's size: "m" the mini chat on its block, "s" the chat, "l" the chat wider.
  // `cw`, `chh`: a width and a height pulled by hand (the edge, the corner), which win over the size's own.
  // `sideOn`: the side column is turned on (it shows when the box has room for it beside the chat).
  // `rz`: the pull in hand; `rzWant` the size it asks for next. `lastW` the box's own width. `dense`: the blocks at 작게.
  // `pill`: the blocks are folded into one line of counts. `pillTurn`: how many waited at its last draw.
  // `orbs`: 동그라미만 보기. It wins over the other two: the round marks are neither small blocks nor folded.
  let size = "s", cw = null, chh = null, sideOn = false, rz = null, rzWant = null, rzBusy = false, lastW = FL.pw, dense = false, pill = false, pillTurn = 0, orbs = false, outShut = false, picking = false, blurAfter = 0;
  try { const z = localStorage.getItem(SIZE_KEY); if (SIZES.includes(z)) size = z; dense = localStorage.getItem(DENSE_KEY) === "1"; pill = localStorage.getItem(PILL_KEY) === "1"; orbs = localStorage.getItem(ORBS_KEY) === "1"; outShut = localStorage.getItem(OUT_KEY) === "1"; } catch (e) { /* this visit only */ }
  if (SOLO) dense = pill = orbs = false;                        // the panel stands where full blocks would leave it
  const SIDE_KEY = "fl-side", CW_KEY = "fl-cw", CH_KEY = "fl-ch", W_MIN = 360, H_MIN = 360, SIDE_MIN = FL.side + 360;
  // A pinned chat's own window is as large as its size says (taskbar.py): nothing is pulled there.
  try { sideOn = localStorage.getItem(SIDE_KEY) === "1";
    if (!SOLO) { const w = +localStorage.getItem(CW_KEY), h = +localStorage.getItem(CH_KEY); if (w >= W_MIN && w <= PWL) cw = w; if (h >= H_MIN) chh = h; } } catch (e) { /* this visit only */ }
  const keepFree = () => { if (SOLO) return; try { [[CW_KEY, cw], [CH_KEY, chh]].forEach(([k, v]) => (v == null ? localStorage.removeItem(k) : localStorage.setItem(k, String(v)))); } catch (e) { /* this visit only */ } };
  const restW = () => (size === "m" ? MINI.w : cw != null ? cw : size === "l" ? PWL : FL.pw);
  const sideShown = () => sideOn && size !== "m" && restW() >= SIDE_MIN;
  const SW = () => (round() ? ORB_D : dense ? DENSE.sw : FL.sw);
  lastW = restW();
  // `adding`: the list of conversations to add is open under the blocks. `viewing`: the result on show.
  let adding = false, viewing = null, dataT = 0, sideSig = "";
  const RM = () => { try { return matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; } };

  function boot() {
    const st = document.createElement("style"); st.id = "fl-style"; st.textContent = CSS; document.head.appendChild(st);
    root = document.createElement("div"); root.id = "fl"; root.className = "fl" + (dense ? " dense" : "") + (SOLO ? " solo" : "");
    root.innerHTML = `<div class="fl-stack" role="list" aria-label="${esc(tl("fl.cards"))}"></div><section class="fl-panel" hidden></section>`;
    document.body.appendChild(root);
    stack = root.firstChild; panel = root.lastChild;
    // The blocks are the session rows' look: their tokens (--sr-*, --ag-*) live in the room screen's sheet.
    const css = () => { if (typeof window.pjCss === "function") window.pjCss(); };
    css(); addEventListener("DOMContentLoaded", css, {once: true});
    wire();
    place();
    const ask = () => { const a = api(); if (a && a.anchor) a.anchor().then((x) => { if (x) window.__flAnchor(x, true); }).catch(() => {}); };
    if (api()) ask(); else addEventListener("pywebviewready", ask, {once: true});
    refresh(); loadData();
    document.addEventListener("visibilitychange", () => { if (!document.hidden) { refresh(); loadData(); } });
    document.addEventListener("redact", draw);
    // Another monitor, or another scale on this one: the app sizes the window by what is drawn here.
    addEventListener("resize", () => report());
    // The toast comes and goes: the window is cut again each time.
    toastEl = document.getElementById("toast");
    if (toastEl && window.MutationObserver) new MutationObserver(() => report()).observe(toastEl, {attributes: true, attributeFilter: ["class"], childList: true, subtree: true, characterData: true});
    stamp();
  }
  // Which float.js this page is running, as the app can check it against the file it serves
  // (the diagnostics report says so when the two differ: a page kept from before an update).
  function stamp() {
    const s = document.querySelector('script[src*="float.js"]');
    if (!s || !window.crypto || !crypto.subtle || typeof fetch !== "function") return;
    fetch(s.src, {cache: "force-cache"}).then((r) => r.arrayBuffer()).then((b) => crypto.subtle.digest("SHA-256", b))
      .then((d) => { build = [...new Uint8Array(d)].slice(0, 6).map((x) => x.toString(16).padStart(2, "0")).join(""); report(); }, () => {});
  }

  // ---- where things sit, and telling the app what is visible --------------------------------------
  function place() {
    root.dataset.side = A.side;
    root.style.height = A.ph + "px";
    stack.style.top = A.dy + "px"; stack.style.maxHeight = A.smax + "px";
    fitBox();
    fitPanel(lastW);
    report();
  }
  // The panel's box, `w` wide, against the stack: it grows away from it.
  function fitPanel(w) {
    panel.style.width = w + "px";
    panel.style.left = (SOLO ? 0 : A.side === "left" ? PWL - w : SW() + FL.pgap) + "px";
  }
  // How tall it is and where it starts: the whole canvas, or (the mini chat) from its block's top, kept inside.
  function fitBox() {
    const mini = size === "m", c = mini ? cardEl(cur || (leaving && leaving.sid)) : null;
    const h = mini ? Math.min(MINI.h, A.ph) : Math.min(chh != null ? chh : A.ph, A.ph);
    const y = c ? c.getBoundingClientRect().top - root.getBoundingClientRect().top : A.dy;
    panel.classList.toggle("mini", mini);
    panel.style.height = h + "px";
    panel.style.top = (mini ? Math.round(Math.max(0, Math.min(y, A.ph - h))) : 0) + "px";
  }
  // `s`: how far the box's shadow reaches, which the window lets through with it.
  const box = (el, r, s) => { const q = el.getBoundingClientRect(); return {x: q.left, y: q.top, w: q.width, h: q.height, r, s}; };
  // The panel's box as laid out: what a transform does to it is left out.
  const lay = (r) => { const q = root.getBoundingClientRect(); return {x: q.left + panel.offsetLeft, y: q.top + panel.offsetTop, w: panel.offsetWidth, h: panel.offsetHeight, r}; };
  function report(force) {
    if (!root || hold) return Promise.resolve();
    const open = !panel.hidden, rects = [];
    // Each block is cut on its own, kept inside the stack's box when there are more than fit, so
    // nothing shows between them. Only while the stack scrolls is it one box: the cut cannot keep up.
    stack.classList.toggle("over", stack.scrollHeight > stack.clientHeight + 1);
    const sb = stack.getBoundingClientRect();
    if (rolling) rects.push(box(stack, FL.r, FL.lift));
    else [...stack.children, ...stack.querySelectorAll(".fl-ob")].forEach((n) => { const q = n.getBoundingClientRect(), t = Math.max(q.top, sb.top), b = Math.min(q.bottom, sb.bottom);
      if (b > t) rects.push({x: q.left, y: t, w: q.width, h: b - t, r: round() ? q.height / 2 : FL.r, s: FL.lift}); });
    if (open) {
      // On its way to a smaller box the window is cut to that one first (pbox).
      const b = pbox ? Object.assign({}, pbox) : lay(FL.r);
      b.s = SOLO ? 0 : FL.pad;
      rects.push(b);
    }
    if (menu) rects.push(box(menu.el, 12, FL.pad));
    // Dialogs and the toast go where the panel is, or over the stack while the chat is closed.
    const h = open ? lay() : box(stack), de = document.documentElement.style;
    de.setProperty("--fl-hx", h.x + "px"); de.setProperty("--fl-hy", h.y + "px");
    de.setProperty("--fl-hw", h.w + "px"); de.setProperty("--fl-hh", Math.max(h.h, FL.ch) + "px");
    if (toastEl) {
      // In the open chat: over its lower part. Otherwise a line under the blocks, which the window
      // lets through as a box of its own; with no room under them, over the last block's foot.
      const th = toastEl.offsetHeight || 36, vh = (innerHeight || FL.ph) - FL.pad;
      let tx = h.x + 12, ty = h.y + Math.max(8, h.h - 150), tw = h.w - 24;
      if (!open) {
        tx = h.x; tw = h.w; ty = h.y + h.h + FL.gap;
        if (round()) tw = DENSE.sw;                             // a line of words needs more than a round mark's width
        if (ty + th > vh) { tx = h.x + 8; tw = h.w - 16; ty = Math.max(h.y, h.y + h.h - th - 8); }
      }
      de.setProperty("--fl-tx", tx + "px"); de.setProperty("--fl-ty", ty + "px"); de.setProperty("--fl-tw", tw + "px");
      if (!open && toastEl.classList.contains("on")) rects.push(box(toastEl, 12, FL.lift));
    }
    const wv = (navigator.userAgent.match(/Edg\/([\d.]+)/) || [])[1] || "";
    const info = {rects, panel: open, dense, dpr: devicePixelRatio || 1, vw: innerWidth, vh: innerHeight, wv, build, pill: folded(), orbs, out: outShut}, now = JSON.stringify(info);
    window.__flLayout = info;                                   // what was last reported (tests read it)
    if (now === sent && !force) return Promise.resolve();
    const a = api();
    if (!a || !a.layout) return Promise.resolve();              // not told yet: the next report is not skipped as a repeat
    sent = now;
    return a.layout(info).catch(() => { if (sent === now) sent = ""; });
  }
  window.__flAnchor = (a, first) => {
    if (!a || !a.side) return;
    blurAfter = performance.now() + 500;                        // coming up moves the focus about: not an outside click
    if (away) { away = false; still(); sig = ""; refresh(); loadData(); }   // shown again: as it is now, and moving
    A = {side: a.side === "left" ? "left" : "right", dy: Math.max(0, +a.dy || 0), ph: +a.ph || FL.ph, smax: +a.smax || FL.ph, top: a.top !== false, hotkey: !!a.hotkey, key: a.key || "", snap: a.snap !== false};
    if (SOLO) outShut = a.stay === false;                       // the pinned chat's own switch, which the app remembers
    // The size the app remembers is taken once, when the page comes up.
    if (first && SIZES.includes(a.size) && a.size !== size) setSize(a.size, true, true);
    place(); report(true);
    if (SOLO && a.solo) refresh().then(() => open(a.solo, true));
  };
  // The pinned chat was sent here (floating): its conversation is the one open.
  window.__flOpen = (sid) => refresh().then(() => open(sid, true));
  window.__flRefresh = () => { loadData(); return refresh(); };   // the window is shown again: cards and lists, both fresh
  // The app put the window away (it stays loaded): nothing is asked for and nothing moves until
  // it is shown again. The page cannot tell by itself: a hidden window's page is still "visible".
  window.__flHidden = () => { away = true; clearTimeout(pollT); clearTimeout(dataT); still(); };
  function still() {
    if (!root) return;
    root.classList.toggle("away", away);
    root.querySelectorAll("rl-orb").forEach((o) => { if (away) { if (!o.hasAttribute("paused")) { o.setAttribute("paused", ""); o.dataset.flp = "1"; } } else if (o.dataset.flp) { o.removeAttribute("paused"); delete o.dataset.flp; } });
  }

  // ---- the cards ----------------------------------------------------------------------------------
  async function refresh() {
    clearTimeout(pollT);
    try {
      const v = await get(SOLO ? "/api/taskbar/cards" : "/api/float");
      off = false; V = v;
      if (v && typeof v.top === "boolean") A.top = v.top;
    } catch (e) { off = true; }
    draw();
    if (!away) pollT = setTimeout(() => { if (!document.hidden) refresh(); }, POLL);
  }
  const cards = () => (V && V.cards) || [];
  const AGENT = {claude: "Claude", codex: "Codex"};
  // Waiting on the person: only when the session is blocked on their answer (c.turn, from the
  // server: a permission prompt or a question). A new result or an unread reply is not a turn;
  // those show in the card's count and in the inbox list.
  function myTurn(c) {
    if (c.gone || c.sid === cur) return false;
    return !!c.turn;
  }
  // The project's face before a block's title: its styled icon or its emoji, nothing without one.
  // What a block is called: the session's name as the session list resolves it (floatwin._label).
  const nameOf = (c) => Redact.show(c.label || c.title || c.shown || c.name || "");       // 가림 모드 covers the blocks too
  const faceMk = (c) => {
    const IC = window.LOOP_ICONS, h = IC && c.icon ? IC.html(c.icon) : "", col = /^#[0-9a-f]{6}$/i.test(c.color || "") && h ? ` style="--em-c:${c.color}"` : "";
    return h || c.emoji ? `<span class="fl-face${h && /^(bold|fill)\//.test(c.icon) ? " hv" : ""}${col ? " tint" : ""}"${col} aria-hidden="true">${h || esc(c.emoji)}</span>` : "";
  };
  // The block's state tile: the session row's orb (project.js draws the same one, from the same
  // table), at the block's size. One element, so the two stay one look.
  const ORB = {live: ["working", .5, 30], turn: ["listening", .15, 15], idle: ["breathing", .1, 15], stuck: ["solving", .08, 15]};
  const orbPhase = (id) => { let h = 0; for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return (h % 2110) / 10; };
  function tileHtml(c, k, label) {
    const m = ORB[k];
    // Dense blocks are too small for the orb at full size (a small one looks broken): a still dot there.
    return `<span class="fl-tile" role="img" aria-label="${esc(label)}">${m && dense && k !== "idle" ? `<i class="st-dot"></i>` : m
      ? `<rl-orb state="${m[0]}" size="20" px="${dense ? 18 : 32}" speed="${m[1]}" fps="${m[2]}" phase="${orbPhase(c.sid)}" aria-label=""></rl-orb>`
      : `<rl-orb state="breathing" size="20" px="${dense ? 13 : 24}" paused aria-label=""></rl-orb>`}</span>`;
  }
  const szM = (k) => k === "m" ? tl("fl.mMini") : k === "l" ? tl("fl.mLarge") : tl("fl.mSmall");
  const nextSize = () => SIZES[(SIZES.indexOf(size) + 1) % SIZES.length];
  function cardHtml(c) {
    const st = c.gone ? "ended" : (c.state || "ended"), label = STATE()[st] || "";
    const who = c.shown || c.name || "";
    const mt = myTurn(c), k = mt ? "turn" : ORB[st] ? st : "ended", ag = AGENT[c.agent] || AGENT.claude;
    const dot = `<i class="fl-agd${c.agent === "codex" ? " cx" : ""}"></i>`, dzT = (dense ? tl("fl.blocksMd") : tl("fl.blocksSm"));
    const sub = c.gone ? tl("fl.gone") : [who, ag, label].filter(Boolean).join(" · ");
    const subH = c.gone ? esc(sub) : (who ? esc(who) + " · " : "") + dot + esc(ag + (label ? " · " + label : ""));
    const ping = mt && turned && !turned.has(c.sid);
    // How full the conversation is, only once it is worth a look (the chat's own chip always says it).
    const full = !c.gone && c.context && c.context.pct >= 70 && typeof window.pjCtx === "function" ? window.pjCtx(c.context) : "";
    const szT = szM(c.sid === cur ? nextSize() : size);    // the hover button: the next size up, round again
    // 허용 / 거절 is all it waits for: answered on the block (a one-line block has no room: its chat has them).
    const ask = mt && c.ask && !dense ? c.ask : null;
    if (ask) return `<div class="fl-cw asking" role="listitem"><button class="fl-card s-turn" data-sid="${esc(c.sid)}" aria-label="${esc(Redact.show(c.title || who) + " · " + tl("fl.turn") + " · " + Redact.show(ask.what))}" aria-expanded="false">
      ${tileHtml(c, k, tl("fl.turn"))}
      <span class="fl-tx"><span class="fl-t">${faceMk(c)}${esc(faceMk(c) && window.LOOP_EMOJI && window.LOOP_EMOJI.bare ? window.LOOP_EMOJI.bare(nameOf(c)) : nameOf(c))}</span>
        <span class="fl-s"><span class="fl-turn${ping ? " ping" : ""}">${tl("fl.turn")}</span><span title="${esc(Redact.show(ask.what))}">${esc(Redact.show(ask.what))}</span></span></span></button>
      <div class="fl-ask"><button class="btn sm fl-btn" data-allow="0" data-aid="${esc(ask.id)}">${tl("room.codexDeny")}</button><button class="btn sm fill fl-btn" data-allow="1" data-aid="${esc(ask.id)}">${tl("room.codexAllow")}</button></div></div>`;
    return `<div class="fl-cw" role="listitem"><button class="fl-card s-${k}${c.sid === cur ? " open" : ""}${c.gone ? " gone" : ""}" data-sid="${esc(c.sid)}" aria-label="${esc(Redact.show(c.title || who) + " · " + sub + (mt ? " · " + tl("fl.turn") : "") + (c.unread ? " · " + tl("fl.unread", {n: c.unread}) : ""))}" aria-expanded="${c.sid === cur}"${dense ? ` title="${esc(Redact.show(c.title || who) + " · " + sub)}"` : ""}>
      ${tileHtml(c, k, mt ? tl("fl.turn") : label)}
      <span class="fl-tx"><span class="fl-t">${faceMk(c)}${esc(faceMk(c) && window.LOOP_EMOJI && window.LOOP_EMOJI.bare ? window.LOOP_EMOJI.bare(nameOf(c)) : nameOf(c))}</span>
        <span class="fl-s">${mt ? `<span class="fl-turn${ping ? " ping" : ""}">${tl("fl.turn")}</span>` : ""}${dense ? (c.gone ? "" : dot) : `<span>${subH}</span>`}${full}</span></span>
      <span class="fl-rt"><span class="fl-at">${c.at ? esc(ago(c.at)) : ""}</span><span class="fl-n">${c.unread && c.sid !== cur ? (c.unread > 99 ? "99+" : +c.unread) : ""}</span></span></button>
      <div class="fl-hov">${c.gone || dense ? "" : `<button class="fl-ib" data-hsize="${esc(c.sid)}" aria-label="${esc(szT)}" title="${esc(szT)}">${ic("sidebar")}</button>`}<button class="fl-ib" data-hdense aria-pressed="${dense}" aria-label="${esc(dzT)}" title="${esc(dzT)}"><span class="pj-mini ${dense ? "md" : "sm"}" aria-hidden="true">${dense ? "<i></i><i></i>" : "<i></i><i></i><i></i><i></i>"}</span></button><button class="fl-ib" data-hoff="${esc(c.sid)}" aria-label="${esc(tl("fl.unpin"))}" title="${esc(tl("fl.unpin"))}">${ic("x")}</button></div></div>`;
  }
  // 동그라미만 보기: the conversation as its orb on a disc. Its name is the tooltip (and what a screen
  // reader hears, with how it is doing); the corner mark is its turn, or else how much is unread.
  const round = () => orbs && cards().length > 0;
  function orbHtml(c) {
    const st = c.gone ? "ended" : (c.state || "ended"), label = STATE()[st] || "", who = c.shown || c.name || "";
    const mt = myTurn(c), k = mt ? "turn" : ORB[st] ? st : "ended", m = ORB[k], n = c.unread && c.sid !== cur ? (c.unread > 99 ? "99+" : +c.unread) : "";
    const say = [nameOf(c), who, mt ? tl("fl.turn") : label, mt && c.ask ? Redact.show(c.ask.what) : "", n ? tl("fl.unread", {n: c.unread}) : ""].filter(Boolean).join(" · ");
    const ping = mt && turned && !turned.has(c.sid);
    return `<div class="fl-cw" role="listitem"><button class="fl-card s-${k}${c.sid === cur ? " open" : ""}${c.gone ? " gone" : ""}" data-sid="${esc(c.sid)}" aria-label="${esc(say)}" title="${esc(say)}" aria-expanded="${c.sid === cur}">
      <span class="fl-tile" aria-hidden="true">${m ? `<rl-orb state="${m[0]}" size="20" px="32" speed="${m[1]}" fps="${m[2]}" phase="${orbPhase(c.sid)}" aria-label=""></rl-orb>` : `<rl-orb state="breathing" size="20" px="24" paused aria-label=""></rl-orb>`}</span></button>
      ${mt ? `<span class="fl-ob turn${ping ? " ping" : ""}" aria-hidden="true"></span>` : n ? `<span class="fl-ob" aria-hidden="true">${n}</span>` : ""}</div>`;
  }
  // The folded blocks: how many there are, then only what is not zero - waiting on the person, working, unread.
  const folded = () => pill && !orbs && cards().length > 0;
  function pillHtml(cs) {
    const turn = cs.filter(myTurn).length, live = cs.filter((c) => !c.gone && c.state === "live").length;
    const unread = cs.reduce((n, c) => n + (c.gone ? 0 : +c.unread || 0), 0), k = turn ? "turn" : live ? "live" : "idle";
    const ping = turn > pillTurn; pillTurn = turn;
    const say = [tl("fl.pillN", {n: cs.length}), turn ? tl("fl.pillTurn", {n: turn}) : "", live ? tl("fl.pillLive", {n: live}) : "", unread ? tl("fl.unread", {n: unread}) : ""].filter(Boolean).join(" · ");
    return `<button class="fl-pill s-${k}" data-unfold role="listitem" aria-label="${esc(say + " · " + tl("fl.unfold"))}" title="${esc(tl("fl.unfold"))}">
      <span class="fl-tile" aria-hidden="true"><i class="st-dot"></i></span><b>${esc(tl("fl.pillN", {n: cs.length}))}</b>
      ${turn ? `<span class="fl-turn${ping ? " ping" : ""}">${esc(tl("fl.pillTurn", {n: turn}))}</span>` : ""}${live ? `<span>${esc(tl("fl.pillLive", {n: live}))}</span>` : ""}<span class="fl-n">${unread ? (unread > 99 ? "99+" : unread) : ""}</span></button>`;
  }
  const recent = () => (V && V.recent) || [];
  const canAdd = () => recent().length > 0 && cards().length < ((V && V.max) || 8);
  const recHtml = () => recent().map((r) => `<button class="fl-rec" data-pin="${esc(r.sid)}">${ic("plus")}<b>${esc(r.title || r.shown || r.name)}</b><small>${esc(r.shown || r.name)}</small></button>`).join("");
  function emptyHtml() {
    const x = `<button class="fl-ib fl-x" data-hide aria-label="${esc(tl("fl.close"))}" title="${esc(tl("fl.close"))}">${ic("x")}</button>`;
    const appBtn = `<div class="fl-acts"><button class="btn fl-btn" data-app>${tl("fl.openApp")}</button></div>`;
    if (off && !V) return `<div class="fl-empty">${x}<b>${tl("fl.offline")}</b><p>${tl("fl.offlineD")}</p>
      <div class="fl-acts"><button class="btn fl-btn" data-retry>${tl("fl.retry")}</button></div></div>`;
    if (V.need_consent) return `<div class="fl-empty">${x}<b>${tl("fl.consent")}</b><p>${tl("fl.consentD")}</p>${appBtn}</div>`;
    const rec = recHtml();
    return `<div class="fl-empty">${x}<b>${tl("fl.emptyT")}</b><p>${tl("fl.emptyD")}</p>
      ${rec ? `<div class="lbl">${tl("fl.recent")}</div>${rec}` : ""}${appBtn}</div>`;
  }
  let known = null;
  function draw() {
    if (!V && !off) return;
    if (ord) return;
    const cs = cards();
    if (adding && !(cs.length && canAdd())) adding = false;
    // Only the blocks, and under them what was asked for (one more conversation) or what went wrong.
    if (folded()) adding = false;
    if (round()) adding = false;
    root.classList.toggle("orbs", round()); root.classList.toggle("dense", dense && !round());
    const html = (round() ? cs.map(orbHtml).join("") : folded() ? pillHtml(cs) : cs.length ? cs.map(cardHtml).join("") : emptyHtml())
      + (adding ? `<div class="fl-empty fl-pick"><button class="fl-ib fl-x" data-addx aria-label="${esc(tl("ui.close"))}" title="${esc(tl("ui.close"))}">${ic("x")}</button><div class="lbl">${tl("fl.recent")}</div>${recHtml()}</div>` : "")
      + (off && V && cs.length && !round() ? `<div class="fl-note"><span>${tl("fl.offline")}</span><button class="btn sm fl-btn" data-retry>${tl("fl.retry")}</button></div>` : "");
    turned = new Set(cs.filter(myTurn).map((c) => c.sid));
    if (html !== sig) {
      const had = document.activeElement && document.activeElement.closest(".fl-cw"), top = stack.scrollTop;
      const keep = had && had.querySelector(".fl-card").dataset.sid, sub = had && ["hsize", "hdense", "hoff"].find((k) => k in document.activeElement.dataset);
      sig = html; stack.innerHTML = html; stack.scrollTop = top;
      // A block that was not there a moment ago says where it is: it comes up from a little
      // smaller and a ring of the accent fades off it once. All of them when the window comes up.
      const now = new Set(cs.map((c) => c.sid));
      stack.querySelectorAll(".fl-cw").forEach((w, i) => { const id = w.querySelector(".fl-card")?.dataset.sid;
        if (id && !(known && known.has(id))) { w.style.setProperty("--hi-d", Math.min(i, 6) * 45 + "ms"); w.classList.add("hi"); } });
      known = now;
      if (keep) { const n = cardEl(keep), b = n && sub && n.parentNode.querySelector("[data-" + sub + "]"); if (b || n) (b || n).focus({preventScroll: true}); }
    }
    // The open conversation left the stack (unpinned from the main window): back to the cards.
    if (cur && !cs.some((c) => c.sid === cur)) shut(true);
    else if (cur) { head(); if (size === "m") fitBox(); }
    if (menu && menu.sid && !cs.some((c) => c.sid === menu.sid)) closeMenu();
    if (away) still();
    report();
  }
  const cardEl = (sid) => [...stack.querySelectorAll(".fl-card")].find((n) => n.dataset.sid === sid) || null;

  // ---- a block's menu (right-click, or the menu key) ----------------------------------------------
  function closeMenu(back) {
    if (!menu) return false;
    const m = menu; menu = null; m.el.remove(); report();
    if (back) { const n = m.sid && cardEl(m.sid); if (n) n.focus({preventScroll: true}); }
    return true;
  }
  function openMenu(sid, x, y, deep) {
    closeMenu(); closePop();
    const c = cards().find((z) => z.sid === sid) || null;
    const it = (k, t, sub) => `<button role="menuitem" data-m="${k}"><span>${esc(t)}</span>${sub ? `<small>${esc(sub)}</small>` : ""}</button>`;
    const el = document.createElement("div"); el.className = "fl-pop fl-menu";
    el.setAttribute("role", "menu"); el.setAttribute("aria-label", tl("fl.blockMenu"));
    // An option keeps its name; the mark at its end says whether it is on.
    const opt = (k, t, on, sub) => `<button role="menuitemcheckbox" aria-checked="${!!on}" data-m="${k}"><span>${esc(t)}</span>${sub ? `<small>${esc(sub)}</small>` : ""}<i class="fl-ck" aria-hidden="true">${on ? ic("check") : ""}</i></button>`;
    // The chat's size is picked in its own header (and by a block's hover button): not here as well.
    // As round marks there is nothing to fold or to make small, and no room under them for the list to add from.
    const a = api(), fold = folded(), rd = round();
    const acts = (c ? it("main", tl("fl.inApp")) : "") + (cards().length && canAdd() && !fold && !rd ? it("add", tl("fl.add")) : "");
    // A block's menu is short: what is done to this conversation, and one look. The looks set once
    // (and stopping them all) wait one row down, under 더 보기.
    el.innerHTML = c && !deep ? acts + opt("orbs", tl("fl.orbsOn"), rd) + "<hr>" + it("off", tl("fl.unpin")) + it("more", tl("fl.more"))
      : (cards().length ? opt("orbs", tl("fl.orbsOn"), rd, tl("fl.orbsSub")) : "")
      + (cards().length && !rd ? opt("fold", tl("fl.fold"), fold, tl("fl.foldSub")) : "")
      + (cards().length && !fold && !rd ? opt("dz", tl("fl.blocksSm"), dense, tl("fl.blocksSmSub")) : "")
      + opt("out", tl("fl.out"), outShut)
      + opt("top", tl("fl.top"), A.top)
      + (a && a.snap ? opt("snap", tl("fl.snap"), A.snap) : "")
      + (a && a.hotkey ? opt("key", tl("fl.key"), A.hotkey, A.key) : "") + "<hr>"
      + (cards().length ? it("all", tl("fl.offAll")) : it("hide", tl("fl.close")));
    root.appendChild(el);
    // Inside the canvas, whichever side the stack is on: past its edge nothing can be drawn.
    el.style.left = Math.round(Math.max(0, Math.min(x, root.offsetWidth - el.offsetWidth))) + "px";
    el.style.top = Math.round(Math.max(0, Math.min(y, root.offsetHeight - el.offsetHeight))) + "px";
    menu = {el, sid: c ? sid : null, x, y};
    report();
    el.querySelector("button").focus({preventScroll: true});
  }
  function menuDo(k) {
    const sid = menu && menu.sid, c = cards().find((z) => z.sid === sid), at = menu;
    closeMenu();
    if (k === "more") return openMenu(sid, at.x, at.y, true);
    if (k === "main") return showMain(c ? "#project/" + enc(c.name) + "/" + enc(c.sid) : "#project");
    if (k === "orbs") return setOrbs(!orbs);
    if (k === "fold") return setPill(!folded());
    if (k === "key") return setKey(!A.hotkey);
    if (k === "dz") return setDense(!dense);
    if (k === "add") { adding = true; sig = ""; draw(); const b = stack.querySelector(".fl-pick .fl-rec"); if (b) b.focus({preventScroll: true}); return; }
    if (k === "top") return setTop(!A.top);
    if (k === "snap") return setSnap(!A.snap);
    if (k === "out") return setOut(!outShut);
    if (k === "off" && sid) return offOne(sid);
    if (k === "all") return offAll();
    if (k === "hide") return hide();
  }
  // Above other apps, or behind them like any window. The app remembers it.
  function setTop(on) {
    const a = api(); A.top = on;
    (a && a.top ? a.top(on) : post("/api/float/top", {on}).then((r) => r && r.top)).then((v) => { A.top = v !== false; }, () => {});
  }
  // A block let go beside a screen edge lines up with it, or stays where it was dropped. The app remembers it.
  function setSnap(on) {
    A.snap = on;
    api().snap(on).then((v) => { A.snap = v !== false; }, (e) => toast(e.message));
  }
  // 밖을 누르면 대화 닫기: off unless asked for. The window is told with the next report, as it is of the other looks.
  function setOut(on) {
    outShut = on;
    if (SOLO) { api().stay(!on).catch((e) => toast(e.message)); return; }
    try { localStorage.setItem(OUT_KEY, on ? "1" : "0"); } catch (e) { /* this visit only */ }
    report(true);
  }
  // What must not be lost by closing the chat for a press elsewhere: words being heard, or anything written or
  // attached and not sent (the message box, and the one line under a result).
  function holding() {
    if (window.Dictate && Dictate.on()) return true;
    return !!root.querySelector("#pj-att > *") || [...root.querySelectorAll("#pj-ta, .fl-vin")].some((n) => n.value.trim());
  }
  // The key that shows and hides the blocks from any app. The app asks Windows for it: another app may hold it.
  function setKey(on) {
    api().hotkey(on).then((v) => { A.hotkey = !!v; toast(on ? (v ? tl("fl.keyOk", {k: A.key}) : tl("fl.keyTaken", {k: A.key})) : tl("fl.keyOffD")); }, (e) => toast(e.message));
  }
  // 접기: the blocks become one line of counts where the first block was, or come back. The open
  // chat goes back into its block first. What appears does so in place, on a short fade.
  function setPill(on) {
    if (on === folded()) return;
    if (on && cur) shut(true);
    pill = on; pillTurn = cards().filter(myTurn).length;
    try { localStorage.setItem(PILL_KEY, on ? "1" : "0"); } catch (e) { /* this visit only */ }
    sig = ""; draw(); report(true);
    [...stack.children].forEach((n) => { if (n.animate) n.animate([{opacity: 0.35}, {opacity: 1}], {duration: 140, easing: "ease-out"}); });
    const n = stack.querySelector(".fl-pill,.fl-card"); if (n) n.focus({preventScroll: true});
  }
  // 동그라미만 보기, or the blocks back: in place, on a short fade. The open chat stays, moved to the marks' edge.
  function setOrbs(on) {
    if (on === orbs) return;
    orbs = on;
    try { localStorage.setItem(ORBS_KEY, on ? "1" : "0"); } catch (e) { /* this visit only */ }
    sig = ""; draw(); fitBox(); fitPanel(lastW); report(true);
    [...stack.children].forEach((n) => { if (n.animate) n.animate([{opacity: 0.35}, {opacity: 1}], {duration: 140, easing: "ease-out"}); });
    const n = (cur && cardEl(cur)) || stack.querySelector(".fl-card,.fl-pill"); if (n) n.focus({preventScroll: true});
  }
  // 허용 / 거절 from the block (or, as round marks, from the open chat's head): the same call the
  // chat's own bar makes. The block follows the session's state.
  function answer(btn) {
    const cw = btn.closest(".fl-cw"), sid = cw ? cw.querySelector(".fl-card").dataset.sid : cur;
    btn.parentNode.querySelectorAll("button").forEach((b) => { b.disabled = true; });
    post("/api/session/approve", {sid, id: btn.dataset.aid, allow: btn.dataset.allow === "1"})
      .then((j) => toast((j && j.message) || ""), (e) => toast(e.message)).then(refresh);
  }
  // The blocks, one line each (블록 작게) or as they are: remembered here, like the session list remembers its own.
  function setDense(on) {
    if (on === dense) return;
    dense = on; root.classList.toggle("dense", on);
    try { localStorage.setItem(DENSE_KEY, on ? "1" : "0"); } catch (e) { /* this visit only */ }
    sig = ""; draw(); fitBox(); fitPanel(lastW); report(true);
  }
  // A block is turned off: its chat goes back into it first, then the block fades, then it is unpinned.
  function offOne(sid) {
    const go = () => {
      const n = cardEl(sid), w = n && n.parentNode, end = () => pin(sid, false);
      if (!w || !w.animate) return end();
      w.style.pointerEvents = "none";
      return w.animate([{opacity: 1, transform: "none"}, {opacity: 0, transform: RM() ? "none" : "scale(.96)"}], {duration: 140, easing: "ease-in", fill: "forwards"}).finished.then(end, end);
    };
    if (cur === sid) return shut(true, go);
    return go();
  }
  // Every block off and the window away (the app closes it; in a browser tab the empty box is left).
  function offAll() {
    if (cur) shut(true);
    adding = false;
    return post("/api/float/off", {}).catch((e) => toast(e.message)).then(refresh);
  }

  // ---- the chat panel -------------------------------------------------------------------------------
  function head() {
    const c = cards().find((x) => x.sid === cur), h = panel.querySelector(".fl-ht"); if (!c || !h) return;
    const st = c.gone ? "ended" : (c.state || "ended");
    const html = `<b title="${esc(nameOf(c))}">${esc(nameOf(c))}</b><span><span class="pj-dot ${st}" title="${esc(STATE()[st] || "")}"></span><span>${esc((c.shown || c.name) + " · " + tl("fl.conv"))}</span></span>`;
    if (h.innerHTML !== html) { h.innerHTML = html; askRuns(); }
    // As round marks no block carries 허용 / 거절: the open conversation's are here.
    const pa = panel.querySelector(".fl-pask"), ask = round() && !c.gone && c.turn && c.ask ? c.ask : null;
    const ah = ask ? `<span class="fl-turn">${tl("fl.turn")}</span><span title="${esc(Redact.show(ask.what))}">${esc(Redact.show(ask.what))}</span><button class="btn sm fl-btn" data-allow="0" data-aid="${esc(ask.id)}">${tl("room.codexDeny")}</button><button class="btn sm fill fl-btn" data-allow="1" data-aid="${esc(ask.id)}">${tl("room.codexAllow")}</button>` : "";
    if (pa.dataset.sig !== ah) { pa.dataset.sig = ah; pa.innerHTML = ah; pa.hidden = !ask; }
  }
  // The panel is there or it is not: no travel, no growth, no dim. The window is not see-through
  // and its cut is not animated, so anything played on the panel would be played over bare canvas.
  // What is in it fades in where it stands once the conversation has something to show.
  function show(to) {
    report();
    if (!to) gone();
  }
  // The panel has left: the window is clipped back to the stack first, then the panel is taken
  // out (what was in it stays in it until then), so the empty panel area is never seen.
  function gone() {
    if (cur || leaving == null) return;
    const was = leaving.sid, quiet = leaving.quiet, then = leaving.then; leaving = null;
    panel.hidden = true; const p = report(true); panel.hidden = false;
    const fin = () => { if (cur || leaving) return; panel.hidden = true; panel.innerHTML = ""; panel.classList.remove("out"); viewing = null;
      restSize();
      if (then) then();
      if (SOLO) hide();                                         // nothing is left to show: the window goes
      if (!quiet) { const n = cardEl(was); if (n) n.focus({preventScroll: true}); } };
    Promise.race([p, new Promise((r) => setTimeout(r, 80))]).then(fin, fin);
  }
  function open(sid, focus) {
    const c = cards().find((x) => x.sid === sid); if (!c) return;
    if (cur === sid) { if (focus) typeHere(); return; }
    // Called back before it was taken out: the same panel, with what is in it.
    if (leaving && leaving.sid === sid && !panel.hidden && panel.querySelector(".fl-body")) {
      leaving = null; cur = sid; sig = ""; panel.classList.remove("out"); draw(); show(1); if (focus) typeHere(); return;
    }
    leaving = null; cur = sid; sig = ""; runs = {}; viewing = null; sideSig = ""; draw();
    panel.innerHTML = `<header class="fl-head"><button class="fl-ib" data-back aria-label="${esc(tl("fl.back"))}" title="${esc(tl("fl.back"))}">${ic("back")}</button>
        <div class="fl-ht"></div>
        <div class="fl-seg" role="group" aria-label="${esc(tl("fl.side"))}"><button data-sz="m" title="${esc(tl("fl.miniT"))}">${tl("fl.mini")}</button><button data-sz="s" title="${esc(tl("fl.narrow"))}">${tl("fl.small")}</button><button data-sz="l" title="${esc(tl("fl.wide"))}">${tl("fl.large")}</button></div>
        <button class="fl-ib" data-sidetog aria-pressed="false">${ic("sidebar")}<span class="fl-n"></span></button>
        ${SOLO ? `<button class="fl-ib" data-float aria-label="${esc(tl("fl.pin"))}" title="${esc(tl("fl.pin"))}">${ic("ext")}</button>`
          : `<button class="fl-ib" data-main aria-label="${esc(tl("fl.inApp"))}" title="${esc(tl("fl.inApp"))}">${ic("ext")}</button>`}
        <button class="fl-ib" data-more aria-label="${esc(tl("fl.menu"))}" title="${esc(tl("fl.menu"))}" aria-haspopup="menu">${ic("more")}</button></header>
      <div class="fl-pask" hidden></div>
      <div class="fl-row"><div class="fl-chat"><div class="fl-body wait"></div>
        <div class="fl-skel">${loadingHtml(tl("pj.loading"), {tight: true})}</div></div>
        <aside class="fl-side" aria-label="${esc(tl("fl.side"))}" hidden></aside></div>
      <div class="fl-grip" data-grip title="${esc(tl("fl.grip"))}"></div>
      <div class="fl-corner" data-corner title="${esc(tl("fl.grip"))}"></div>`;
    panel.hidden = false; panel.classList.remove("out"); panel.setAttribute("aria-label", nameOf(c));
    // Nothing is said to the window until show() has put the panel where it starts from: the cut never shows the whole box first.
    hold = true; restSize(); sizeBtn(); drawSide();
    head(); hold = false;
    show(1);
    const body = panel.querySelector(".fl-body");
    body.dataset.ph = tl("fl.ph");
    const gone = () => {
      const n = document.createElement("div"); n.className = "fl-body";      // a new node: the old one's chat loop ends with it
      n.innerHTML = `<div class="fl-gone">${tl("fl.gone")}<div class="fl-acts"><button class="btn fl-btn" data-unpin>${tl("fl.unpin")}</button></div></div>`;
      body.replaceWith(n); const sk = panel.querySelector(".fl-skel"); if (sk) sk.remove();
    };
    if (c.gone || typeof window.pjEmbed !== "function") return gone();
    // The skeleton stands until the conversation has something to show (cached: at once).
    let ready = false;
    const done = () => {
      if (ready || !body.isConnected) return;
      const msgs = body.querySelector("#pj-msgs"); if (!msgs) return;
      const e = msgs.querySelector(".pj-empty");
      if (!msgs.querySelector(".pj-msg") && !(e && e.textContent.trim() === tl("pj.empty"))) return;
      ready = true; body.classList.remove("wait");
      const sk = panel.querySelector(".fl-skel"); if (sk) sk.remove();
      meta(body); msgs.scrollTop = msgs.scrollHeight;
      msgs.querySelectorAll(".pj-msg").forEach((n) => known.add(lineKey(n)));
      if (body.animate) body.animate([{opacity: 0}, {opacity: 1}], {duration: 140, easing: "ease-out"});
      if (focus) typeHere();
    };
    // A line that arrives while the chat is open rises into place; a repaint of lines already
    // seen (the chat redraws itself now and then) does not move.
    const known = new Set();
    const arrive = () => {
      if (!ready) return;
      const fresh = [...body.querySelectorAll("#pj-msgs .pj-msg")].filter((n) => !known.has(lineKey(n)));
      fresh.forEach((n) => known.add(lineKey(n)));
      if (!fresh.length || fresh.length > 3) return;
      const M = window.Motion, sp = M && M.SPRINGS && M.SPRINGS.snap;
      fresh.forEach((n) => { if (!n.animate) return;
        if (RM() || !sp) n.animate([{opacity: 0.3}, {opacity: 1}], {duration: 180, easing: "ease-out"});
        else n.animate([{opacity: 0, transform: "translateY(10px)"}, {opacity: 1, transform: "none"}], {duration: sp.ms, easing: sp.ease}); });
    };
    const ob = new MutationObserver(() => { if (!body.isConnected) return ob.disconnect(); arrive(); meta(body); done(); });
    ob.observe(body, {childList: true, subtree: true});
    // Shown as it is when the usual sign never comes - but only once there is a chat to show: a slow
    // answer keeps the loading line, it does not leave an empty panel.
    const reveal = () => { if (ready || !body.isConnected) return; ready = true; body.classList.remove("wait"); const sk = panel.querySelector(".fl-skel"); if (sk) sk.remove(); if (focus) typeHere(); };
    const late = () => { if (ready || !body.isConnected) return;
      const m = body.querySelector("#pj-msgs"); if (m && m.firstElementChild && !m.querySelector(".pj-wait")) reveal(); else setTimeout(late, 1000); };
    setTimeout(late, 4000);
    // A read that failed is asked again: only an answer that the conversation is not there says gone.
    let tries = 0;
    const load = () => window.pjEmbed(body, {sid, name: c.name}).then((r) => {
      if (cur !== sid || !body.isConnected) return;
      if (!r || !r.session || r.session.id !== sid) return gone();
      meta(body); done();
    }).catch(() => { if (cur === sid && body.isConnected) setTimeout(load, ++tries < 5 ? 2000 : 10000); });
    load();
  }
  function typeHere() { const ta = panel.querySelector("#pj-ta"); if (ta) ta.focus({preventScroll: true}); }
  // A line's own words (not its time row or its "sending" tag), to tell a new line from a redraw.
  function lineKey(n) {
    let t = "";
    n.childNodes.forEach((c) => { if (!(c.classList && (c.classList.contains("fl-meta") || c.classList.contains("fl-mr") || c.classList.contains("tg") || c.classList.contains("pj-tm")))) t += c.textContent; });
    const who = n.classList.contains("user") ? "u" : n.classList.contains("tool") ? "t" : "c";
    return who + "|" + (who === "u" ? "" : n.dataset.at || "") + "|" + t.trim().slice(0, 80);
  }
  // How long an answer took, as a person says it.
  function took(ms) {
    const sec = Math.max(1, Math.round(ms / 1000));
    if (sec < 60) return tl("fl.tookS", {s: sec});
    if (sec < 3600) return tl("fl.tookM", {m: Math.floor(sec / 60), s: sec % 60});
    return tl("fl.tookH", {h: Math.floor(sec / 3600), m: Math.floor((sec % 3600) / 60)});
  }
  // Under each of the session's lines: when it was said, then the model, the effort and the time
  // the answer took - whichever of those the transcript holds, none of them made up - and a copy button.
  function meta(body) {
    body.querySelectorAll(".pj-msg.claude[data-at]").forEach((n) => {
      const r = runs[n.dataset.at] || {};
      // The mini chat (작게) cuts an answer at four lines: the ones that are cut say so, and 더 보기 opens 보통.
      if (!n.querySelector(":scope>.fl-mr")) { const b = document.createElement("button"); b.className = "fl-mr"; b.dataset.sz = "s"; b.textContent = tl("fl.more"); n.appendChild(b); }
      // Cut means at least half a line does not fit: a pixel or two over (a tall glyph) is not.
      n.classList.toggle("fl-clip", size === "m" && n.scrollHeight - n.clientHeight > (parseFloat(getComputedStyle(n).lineHeight) || 20) / 2);
      const txt = [hm(n.dataset.at), r.model, r.effort, r.ms != null ? took(r.ms) : ""].filter(Boolean).join(" · ");
      if (n.dataset.flm === txt) return;
      const fresh = n.dataset.flm == null;
      n.dataset.flm = txt;
      let m = n.querySelector(":scope>.fl-meta");
      if (!m) { m = document.createElement("div"); m.className = "fl-meta"; m.innerHTML = `<span></span><button data-copy>${tl("fl.copy")}</button>`; n.appendChild(m); }
      m.firstChild.textContent = txt;
      if (fresh) askRuns();
    });
  }
  // Asked once things have settled (a burst of new lines is one question), and again when the
  // card's state changes: the time an answer took is known only when it has ended.
  function askRuns() {
    clearTimeout(runsT);
    runsT = setTimeout(async () => {
      const sid = cur; if (!sid) return;
      try {
        const r = await get("/api/float/meta?sid=" + enc(sid));
        if (cur !== sid) return;
        runs = (r && r.runs) || {};
        const body = panel.querySelector(".fl-body"); if (body) meta(body);
      } catch (e) { /* the time alone stays */ }
    }, 300);
  }
  // `then` runs once the panel is out (not if it is called back before that).
  function shut(quiet, then) {
    if (!cur) return;
    leaving = {sid: cur, quiet: !!quiet, then: then || null}; cur = null; sig = ""; clearTimeout(runsT);
    closePop(true); closeRes(true); panel.classList.add("out");
    draw();                                                     // the card is a plain card again at once
    show(0);
  }
  function closePop(now) {
    const p = panel.querySelector(".fl-pop:not(.out)");
    if (p) { p.classList.add("out"); const M = window.Motion; if (now || !M || !M.menuOut) p.remove(); else M.menuOut(p); }
    const m = panel.querySelector("[data-more]"); if (m) m.setAttribute("aria-expanded", "false");
    return !!p;
  }
  function more(btn) {
    if (closePop()) return;
    const c = cards().find((x) => x.sid === cur); if (!c) return;
    const pop = document.createElement("div"); pop.className = "fl-pop"; pop.setAttribute("role", "menu");
    // The pinned chat: the way to the app, whether a press elsewhere puts it away, and its pin.
    pop.innerHTML = SOLO ? `<button role="menuitem" data-main>${tl("fl.inApp")}</button><button role="menuitemcheckbox" aria-checked="${outShut}" data-out><span>${tl("fl.out")}</span><i class="fl-ck" aria-hidden="true">${outShut ? ic("check") : ""}</i></button><hr><button role="menuitem" data-unpin>${tl("bar.unpin")}</button>`
      : `<button role="menuitem" data-unpin>${tl("fl.unpin")}</button><button role="menuitem" data-all>${tl("fl.offAll")}</button>`;
    panel.appendChild(pop); btn.setAttribute("aria-expanded", "true");
    if (window.Motion && Motion.menuIn) Motion.menuIn(pop);     // out of the button's corner
    pop.firstChild.focus({preventScroll: true});
  }
  function showMain(hash) {
    const a = api();
    if (a && a.show_main) a.show_main(hash || "").catch(() => {});
    else window.open("/" + (hash || ""), "_blank", "noopener");
  }
  async function pin(sid, on, r) {
    try { await post(SOLO ? "/api/taskbar/pin" : "/api/float/pin", on ? {sid, on: true, name: r.name, title: r.title, agent: r.agent} : {sid, on: false}); }
    catch (e) { toast(e.message); }
    refresh();
  }
  function hide() {
    const a = api();
    if (a && a.hide) a.hide().catch(() => {}); else post("/api/float/close", {}).catch(() => {});
  }

  // ---- the panel's size: the chat alone, or with the side column ------------------------------------
  // The side column is there when it is turned on and the box has the room for it.
  function sideSync() {
    const sd = panel.querySelector(".fl-side"); if (!sd) return;
    const on = sideShown();
    if (on === !sd.hidden) return;
    sd.hidden = !on;
    if (on) drawSide(); else { sd.innerHTML = ""; sideSig = ""; }
  }
  // At rest: the box is as wide and tall as its size (or the hand) says.
  function restSize() {
    lastW = restW();
    if (panel.hidden) return;
    // Someone reading further up stays there. To and from the mini chat the lines wrap anew, so
    // the last line is kept in sight.
    const body = panel.querySelector(".fl-body"), msgs = body && body.querySelector("#pj-msgs");
    const stay = msgs && panel.classList.contains("mini") === (size === "m") && msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight > 24 ? msgs.scrollTop : null;
    fitBox(); fitPanel(lastW); sideSync();
    // What is cut and what is not depends on the size: said again.
    if (msgs) { meta(body); msgs.scrollTop = stay != null ? stay : msgs.scrollHeight; }
    report(true);
  }
  function sizeBtn() {
    const g = panel.querySelector(".fl-seg"); if (!g) return;
    const free = cw != null || chh != null;                     // pulled to a size of its own: none of the three
    g.querySelectorAll("[data-sz]").forEach((b) => b.setAttribute("aria-pressed", String(!free && b.dataset.sz === size)));
    const sb = panel.querySelector("[data-sidetog]"), on = sideShown();
    if (sb) {
      // While the side column is put away, its button says how much waits in it.
      const n = on ? 0 : turnN() + (cur ? mine(cur).filter((x) => x.new).length : 0);
      sb.querySelector(".fl-n").textContent = n ? (n > 99 ? "99+" : n) : "";
      sb.setAttribute("aria-pressed", String(on)); sb.title = on ? tl("fl.sideOff") : tl("fl.sideOn"); sb.setAttribute("aria-label", sb.title);
    }
    const hb = cur && cardEl(cur) && cardEl(cur).parentNode.querySelector("[data-hsize]");
    if (hb) { hb.title = szM(nextSize()); hb.setAttribute("aria-label", hb.title); }
  }
  // One of the three sizes: the box at that size's own measure, there with a short fade (at once
  // from the keyboard). `keepH`: the height the hand gave stays.
  function setSize(to, now, quiet, keepH) {
    to = SIZES.includes(to) ? to : "m";
    if (to === size && cw == null && (chh == null || keepH)) return;
    const turned = to !== size;
    size = to; cw = null; if (!keepH) chh = null;
    try { localStorage.setItem(SIZE_KEY, to); } catch (e) { /* this visit only */ }
    keepFree();
    const a = api();
    // The app remembers the size, and says if the panel as wide as that belongs on the other side.
    if (turned && !quiet && a && a.size) a.size(to).then((x) => { if (x && x.side && (x.side !== A.side || (+x.dy || 0) !== A.dy)) window.__flAnchor(x); }).catch(() => {});
    sizeBtn();
    if (panel.hidden) return restSize();
    pbox = null;
    const my = ++szT, was = lay(FL.r), st = panel.style, keep = [st.width, st.left, st.height, st.top], wasMini = panel.classList.contains("mini");
    hold = true; restSize(); hold = false;
    const nb = lay(FL.r);
    if (!now && (nb.w < was.w - 1 || nb.h < was.h - 1)) {
      // Smaller: the window is cut to the new box first and the box follows, so the bare canvas is not seen where the panel was.
      [st.width, st.left, st.height, st.top] = keep; panel.classList.toggle("mini", wasMini);
      const x = Math.max(was.x, nb.x), y = Math.max(was.y, nb.y);
      pbox = {x, y, w: Math.min(was.x + was.w, nb.x + nb.w) - x, h: Math.min(was.y + was.h, nb.y + nb.h) - y, r: FL.r};
      const fin = () => { if (my !== szT) return; pbox = null; if (panel.hidden) return; restSize();
        if (panel.animate) panel.animate([{opacity: 0.35}, {opacity: 1}], {duration: 140, easing: "ease-out"}); };
      Promise.race([report(true), new Promise((r) => setTimeout(r, 80))]).then(fin, fin);
      return;
    }
    report(true);
    if (!now && panel.animate) panel.animate([{opacity: 0.35}, {opacity: 1}], {duration: 140, easing: "ease-out"});
  }
  // The header's button: the side column on or put away. Where the box has no room for it beside
  // the chat, it becomes the wide one.
  function sideToggle(now) {
    sideOn = !sideShown();
    try { localStorage.setItem(SIDE_KEY, sideOn ? "1" : "0"); } catch (e) { /* this visit only */ }
    if (sideOn && restW() < SIDE_MIN) return setSize("l", now, false, true);
    sideSync(); sizeBtn(); report(true);
  }
  // Pulled by hand. Getting smaller, the window's cut goes first and the box after it, so the bare
  // canvas is never seen where the panel was; growing, the box is there first.
  async function rzPump() {
    if (rzBusy) return;
    rzBusy = true;
    while (rzWant && !panel.hidden) {
      const {w, h} = rzWant, was = lay(FL.r), nh = h != null ? h : was.h; rzWant = null;
      if (w < was.w - 0.5 || nh < was.h - 0.5) {
        const bw = Math.min(w, was.w);
        pbox = {x: A.side === "left" ? was.x + was.w - bw : was.x, y: was.y, w: bw, h: Math.min(nh, was.h), r: FL.r};
        await Promise.race([report(true), new Promise((r) => setTimeout(r, 80))]).catch(() => {});
        pbox = null;
      }
      cw = w; if (h != null) chh = h;
      lastW = w; fitBox(); fitPanel(w); sideSync(); report(true);
    }
    rzBusy = false;
    if (!rz) rzDone();
  }
  // Let go: the size is remembered, and the app is told which of its two widths it is nearer (for the side it plans).
  function rzDone() {
    if (panel.hidden || (cw == null && chh == null)) return;
    if (chh != null && chh >= A.ph) chh = null;                 // as tall as there is room for: it follows the screen again
    keepFree();
    const to = restW() > FL.pw ? "l" : "s", a = api();
    if (to !== size) {
      size = to;
      try { localStorage.setItem(SIZE_KEY, to); } catch (e) { /* this visit only */ }
      if (a && a.size) a.size(to).then((x) => { if (x && x.side && (x.side !== A.side || (+x.dy || 0) !== A.dy)) window.__flAnchor(x); }).catch(() => {});
    }
    sizeBtn();
    const body = panel.querySelector(".fl-body"); if (body) meta(body);
  }

  // ---- the side column: what waits on the person, and what this conversation pushed ----------------
  // The app's own data (v2.js load) and its own lists (todoSecs), read as they are.
  async function loadData() {
    clearTimeout(dataT);
    try { if (typeof load === "function") await load(); } catch (e) { /* the last copy stays */ }
    sig = ""; draw(); drawSide(); sizeBtn();
    if (!away) dataT = setTimeout(() => { if (!document.hidden) loadData(); }, DATA);
  }
  function turn() {
    try {
      const T = todoSecs(), of = (k) => (T.find((x) => x.k === k) || {L: []}).L;
      return {asks: of("ask").flatMap((g) => g.items), looks: of("look")};
    } catch (e) { return {asks: [], looks: []}; }
  }
  function turnN() { const t = turn(); return t.asks.length + t.looks.length; }
  // The results a conversation pushed, newest first.
  function mine(sid) { try { return (D.items || []).filter((x) => x.to_session === sid).sort(byAt); } catch (e) { return []; } }
  function resRow(x, where) {
    const tag = x.new ? `<span class="tag pending">${(x.count > 1 ? tl("fl.newV") : tl("fl.newR"))}</span>`
      : x.status === "approved" ? `<span class="tag approved">${tl("STATUS_T.4")}</span>`
      : x.status === "changes" ? `<span class="tag changes">${tl("STATUS_T.2")}</span>` : "";
    const sub = [vShort(x.v), x.at ? ago(x.at) : "", where ? pname(gname(x)) : ""].filter(Boolean).join(" · ");
    return `<button class="fl-res" data-res="${esc(iid(x))}">${thumb(x, "ico sm")}<span class="tx"><span class="t">${esc(x.title)}</span><span class="s">${esc(sub)}</span></span>${tag}</button>`;
  }
  // A question is answered in the app, where its choices are: its row goes there.
  function askRow(x) {
    const sub = tl("askCard.3", {esc: esc(pname(gname(x))), asked: x.asked, ago: ago(x.at)});
    return `<button class="fl-res" data-ask="${esc(iid(x))}">${thumb(x, "ico sm")}<span class="tx"><span class="t">${esc(x.title)}</span><span class="s">${sub}</span></span><span class="tag pending">${tl("askCard.4")}</span></button>`;
  }
  function drawSide() {
    const sd = panel.querySelector(".fl-side"); if (!sd || panel.hidden || !sideShown()) return;
    sd.hidden = false;
    // 내 차례 beside a conversation is that conversation's own: another department's question does not belong here.
    const here = (x) => x.to_session === cur, all = turn(), t = {asks: all.asks.filter(here), looks: all.looks.filter(here)};
    const own = cur ? mine(cur) : [], n = t.asks.length + t.looks.length, MORE = 6;
    const lab = (k, c, hot) => `<div class="fl-lab">${k}<span class="n${hot && c ? " hot" : ""}">${c}</span></div>`;
    const html = (n ? lab(tl("fl.turn"), n, true) : "")
      + (n ? t.asks.map((x) => askRow(x)).join("") + t.looks.slice(0, MORE).map((x) => resRow(x, true)).join("")
          + (t.looks.length > MORE ? `<button class="fl-lnk" data-inbox>${tl("fl.turnAll", {n: t.looks.length - MORE})}</button>` : "")
        : "")
      + lab(tl("fl.results"), own.length)
      + (own.length ? own.slice(0, 12).map((x) => resRow(x)).join("") : `<p class="fl-none">${tl("fl.resNone")}</p>`);
    if (html === sideSig && sd.firstChild) return;
    const top = sd.firstChild ? sd.firstChild.scrollTop : 0;
    sideSig = html; sd.innerHTML = `<div class="fl-sc">${html}</div>`; sd.firstChild.scrollTop = top;
  }
  // ---- a result, looked at in the window ------------------------------------------------------------
  async function openRes(id, now) {
    const row = panel.querySelector(".fl-row"); if (!row) return;
    const [p, ...r] = id.split("/"), i = r.join("/");
    closeRes(true);
    const el = document.createElement("div"); el.className = "fl-view"; el.dataset.id = id;
    el.innerHTML = `<div class="fl-vh"><button class="fl-ib" data-vback aria-label="${esc(tl("fl.vBack"))}" title="${esc(tl("fl.vBack"))}">${ic("back")}</button>
        <div class="fl-ht"><b></b><span></span></div><button class="btn sm fl-btn" data-vapp>${tl("fl.inApp")}</button></div>
      <div class="fl-vs"></div>`;
    row.appendChild(el);
    viewing = {id, p, i, files: [], fi: 0};
    // The result's page appears in its place: no rise.
    if (!now && el.animate) el.animate([{opacity: RM() ? 0.35 : 0}, {opacity: 1}], {duration: RM() ? 180 : 140, easing: "ease-out"});
    el.querySelector("[data-vback]").focus({preventScroll: true});
    let d;
    try { d = await get(`/api/item?p=${enc(p)}&i=${enc(i)}`); }
    catch (e) { if (el.isConnected) el.querySelector(".fl-vs").innerHTML = `<div class="fl-vn">${ic("warn")}<p>${esc(e.message)}</p></div>`; return; }
    if (!el.isConnected || !viewing || viewing.id !== id) return;
    const v = (d.versions || []).slice(-1)[0];
    if (!v) { el.querySelector(".fl-vs").innerHTML = `<div class="fl-vn">${ic("doc")}<p>${tl("fl.viewApp")}</p></div>`; return; }
    Object.assign(viewing, {v: v.v, rev: d.rev, status: v.status, files: v.files || [], title: d.title || i, dept: d.dept || v.dept || "", note: v.summary || ""});
    drawView(el);
    // Looked at: the "new" mark goes, as it does when the result is opened in the app.
    post("/api/seen", {p, i, v: v.v}).then(() => loadData()).catch(() => {});
  }
  function drawView(el) {
    const w = viewing, f = w.files[w.fi], ok = w.status === "approved";
    el.querySelector(".fl-ht").innerHTML = `<b>${esc(w.title)}</b><span><span>${esc([vShort(w.v), w.note].filter(Boolean).join(" · "))}</span></span>`;
    const st = el.querySelector(".fl-vs");
    st.innerHTML = f && f.kind === "image" ? `<img src="${esc(f.play || f.url)}" alt="${esc(f.name)}">`
      : f && f.kind === "video" ? `<video src="${esc(f.play || f.url)}" controls playsinline></video>`
      : `<div class="fl-vn">${f && f.thumb ? `<img src="${esc(f.thumb)}" alt="">` : ic("doc")}<p>${tl("fl.viewApp")}</p></div>`;
    el.querySelectorAll(".fl-vfs,.fl-vf").forEach((n) => n.remove());
    if (w.files.length > 1) st.insertAdjacentHTML("afterend", `<div class="fl-vfs">${w.files.map((g, n) => `<button data-vf="${n}" class="${n === w.fi ? "on" : ""}" aria-label="${esc(g.name)}" title="${esc(g.name)}">${g.thumb ? `<img src="${esc(g.thumb)}" alt="">` : ic("doc")}</button>`).join("")}</div>`);
    el.insertAdjacentHTML("beforeend", `<div class="fl-vf"><input class="fl-vin" maxlength="300" placeholder="${esc(tl("fl.vPh"))}" aria-label="${esc(tl("fl.vPh"))}">
      <button class="btn fl-btn" data-vchg disabled>${tl("STATUS_T.2")}</button><button class="btn fill fl-btn" data-vok${ok ? " disabled" : ""}>${(ok ? tl("fl.vOkd") : tl("STATUS_T.4"))}</button></div>`);
    const inp = el.querySelector(".fl-vin"), chg = el.querySelector("[data-vchg]");
    inp.oninput = () => { chg.disabled = !inp.value.trim(); };
    inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229 && inp.value.trim()) { e.preventDefault(); decide(false); } };
  }
  // 승인, or 수정 요청 with a line of what to change: the same calls the result screen makes
  // (status; a comment, the version sent back, and the comment handed to the session).
  async function decide(ok) {
    const w = viewing, el = panel.querySelector(".fl-view"); if (!w || !el || w.busy || !w.v) return;
    const it = {p: w.p, i: w.i, v: w.v, dept: w.dept}, inp = el.querySelector(".fl-vin"), text = inp.value.trim();
    if (!ok && !text) return inp.focus();
    w.busy = true; el.querySelectorAll(".fl-vf button").forEach((b) => { b.disabled = true; });
    try {
      if (ok) { await post("/api/status", {p: w.p, i: w.i, v: w.v, status: "approved", rev: w.rev}); w.status = "approved"; toast(tl("fl.vOkd")); }
      else {
        await post("/api/comment", {p: w.p, i: w.i, v: w.v, text});
        if (!["changes", "approved"].includes(w.status)) { await post("/api/status", {p: w.p, i: w.i, v: w.v, status: "changes"}).catch(() => null); w.status = "changes"; }
        inp.value = "";
        if (typeof sendNow === "function") await sendNow(it); else toast(tl("fl.vSent"));
      }
    } catch (e) { toast(e.message); }
    // The review moved on (this change, or someone else's): read where it stands now.
    try { const d = await get(`/api/item?p=${enc(w.p)}&i=${enc(w.i)}`), v = (d.versions || []).slice(-1)[0]; if (v) Object.assign(w, {rev: d.rev, status: v.status}); } catch (e) { /* as it was */ }
    w.busy = false;
    if (viewing === w && el.isConnected) { const keep = inp.value; drawView(el); el.querySelector(".fl-vin").value = keep; el.querySelector("[data-vchg]").disabled = !keep.trim(); }
    loadData();
  }
  function closeRes(now) {
    const el = panel.querySelector(".fl-view:not(.out)"); viewing = null;
    if (!el) return false;
    el.classList.add("out");
    const was = el.dataset.id, back = () => { el.remove(); const n = [...panel.querySelectorAll("[data-res]")].find((b) => b.dataset.res === was); if (n && !now) n.focus({preventScroll: true}); };
    if (now || RM() || !el.animate) back();
    else el.animate([{opacity: 1}, {opacity: 0}], {duration: 120, easing: "ease-in"}).finished.then(back, back);
    return true;
  }

  // ---- a block's place in the stack -----------------------------------------------------------------
  // The block follows the pointer 1:1, the others make room, and where it is let go is kept
  // (/api/float/order). The stack is not redrawn while a block is held.
  let ord = null;
  function ordStart(row, e) {
    const rows = [...stack.querySelectorAll(".fl-cw")], from = rows.indexOf(row);
    const tops = rows.map((r) => r.getBoundingClientRect()), step = rows.length > 1 ? tops[1].top - tops[0].top : tops[0].height;
    ord = {row, rows, from, to: from, y0: e.clientY, step, lo: tops[0].top - tops[from].top, hi: tops[rows.length - 1].top - tops[from].top};
    row.style.zIndex = 5; row.style.transition = "none"; row.classList.add("lift");
    rows.forEach((r) => { if (r !== row) r.style.transition = RM() ? "none" : "transform .28s cubic-bezier(.2,.9,.3,1)"; });
  }
  function ordMove(e) {
    if (!(e.buttons & 1)) return ordEnd(true);
    const o = ord, dy = Math.max(o.lo - 12, Math.min(o.hi + 12, e.clientY - o.y0));
    o.row.style.transform = `translateY(${dy}px)`;
    o.to = Math.max(0, Math.min(o.rows.length - 1, o.from + Math.round(dy / o.step)));
    o.rows.forEach((r, i) => {
      if (r === o.row) return;
      const s = i > o.from && i <= o.to ? -o.step : i < o.from && i >= o.to ? o.step : 0;
      r.style.transform = s ? `translateY(${s}px)` : "";
    });
  }
  function ordEnd(keep) {
    const o = ord; ord = null; if (!o) return;
    const to = keep ? o.to : o.from, sids = o.rows.map((r) => r.querySelector(".fl-card").dataset.sid);
    sids.splice(to, 0, sids.splice(o.from, 1)[0]);
    const clear = () => { o.rows.forEach((r) => { r.style.transform = r.style.transition = r.style.zIndex = ""; }); o.row.classList.remove("lift"); sig = ""; draw(); };
    if (to === o.from) { o.row.style.transition = RM() ? "none" : "transform .22s cubic-bezier(.2,.9,.3,1)"; o.row.style.transform = ""; return void setTimeout(clear, RM() ? 0 : 230); }
    // Settle into the slot, then redraw in the new order so nothing jumps.
    o.row.style.transition = RM() ? "none" : "transform .18s cubic-bezier(.2,.9,.3,1)";
    o.row.style.transform = `translateY(${(to - o.from) * o.step}px)`;
    if (V && V.cards) V.cards = sids.map((id) => V.cards.find((c) => c.sid === id)).filter(Boolean);
    post("/api/float/order", {sids}).catch((e) => toast(e.message)).then(refresh);
    setTimeout(clear, RM() ? 0 : 190);
  }
  // ---- pointer and keys -----------------------------------------------------------------------------
  function wire() {
    // Shown again after being hidden: the blocks say where they are once more.
    document.addEventListener("visibilitychange", () => { if (!document.hidden) { known = null; sig = ""; draw(); } });
    // A press that moves is a drag of the whole window (the system move loop, 1:1 with the
    // pointer); one that does not is a click. Buttons inside the header and the empty box are
    // not handles.
    root.addEventListener("pointerdown", (e) => {
      dragged = false; press = null;
      if (e.button !== 0) return;
      const h = e.target.closest(".fl-card,.fl-pill,.fl-head,.fl-empty,.fl-note");
      if (!h || (!h.matches(".fl-card,.fl-pill") && e.target.closest("button"))) return;
      press = {x: e.screenX, y: e.screenY, row: h.matches(".fl-card") && !round() && !folded() ? h.closest(".fl-cw") : null};
      const a = api(); if (a && a.press) a.press();           // where the pointer is, as the app sees it
    });
    addEventListener("pointermove", (e) => {
      if (ord) return ordMove(e);
      if (!press) return;
      if (!(e.buttons & 1)) { press = null; return; }
      const dx = e.screenX - press.x, dy = e.screenY - press.y;
      if (Math.hypot(dx, dy) < DRAG) return;
      const row = press.row;
      press = null; dragged = true; closePop(); closeMenu();
      // Straight up or down on a block moves the block among the others; any other way moves the window.
      if (row && Math.abs(dy) > Math.abs(dx) * 1.6 && stack.querySelectorAll(".fl-cw").length > 1) return ordStart(row, e);
      const a = api(); if (a && a.start_move) a.start_move();
    });
    addEventListener("pointerup", () => { press = null; if (ord) ordEnd(true); });
    addEventListener("pointercancel", () => { press = null; if (ord) ordEnd(false); });
    // The panel's outer edge (its width) and its corner (the height too) follow the pointer 1:1,
    // and the box stays the size it was let go at. The three sizes in the header put it back.
    root.addEventListener("pointerdown", (e) => {
      const g = e.target.closest("[data-grip],[data-corner]"); if (!g || e.button !== 0 || size === "m") return;
      e.preventDefault(); closePop();
      rz = {id: e.pointerId, x: e.clientX, y: e.clientY, w: panel.offsetWidth, h: panel.offsetHeight, both: g.hasAttribute("data-corner"), el: g};
      try { g.setPointerCapture(e.pointerId); } catch (er) { /* it still follows inside the window */ }
      g.classList.add("on");
    });
    root.addEventListener("pointermove", (e) => {
      if (!rz || e.pointerId !== rz.id) return;
      const w = Math.round(Math.max(W_MIN, Math.min(PWL, rz.w + (e.clientX - rz.x) * (A.side === "left" ? -1 : 1))));
      rzWant = {w, h: rz.both ? Math.round(Math.max(H_MIN, Math.min(A.ph, rz.h + e.clientY - rz.y))) : null};
      rzPump();
    });
    const drop = (e) => {
      if (!rz || e.pointerId !== rz.id) return;
      rz.el.classList.remove("on"); rz = null;
      if (!rzBusy) rzDone();
    };
    root.addEventListener("pointerup", drop);
    root.addEventListener("pointercancel", drop);
    root.addEventListener("click", (e) => {
      if (dragged) { dragged = false; e.preventDefault(); e.stopPropagation(); return; }
      const t = e.target;
      const mi = t.closest("[data-m]"); if (mi) return menuDo(mi.dataset.m);
      if (!t.closest(".fl-menu")) closeMenu();
      if (!t.closest(".fl-pop,[data-more]")) closePop();
      const card = t.closest(".fl-card"); const key = !e.detail;      // Enter or Space: no travel
      if (t.closest("[data-unfold]")) return setPill(false);
      const al = t.closest("[data-allow]"); if (al) return answer(al);
      const hs = t.closest("[data-hsize]");
      if (hs) { const sid = hs.dataset.hsize; if (cur === sid) setSize(nextSize(), key); sig = ""; return cur === sid ? draw() : open(sid, false); }
      const hd = t.closest("[data-hdense]");
      if (hd) { const sid = hd.closest(".fl-cw").querySelector(".fl-card").dataset.sid; setDense(!dense); const b = cardEl(sid) && cardEl(sid).parentNode.querySelector("[data-hdense]"); if (b && key) b.focus({preventScroll: true}); return; }
      const ho = t.closest("[data-hoff]"); if (ho) return offOne(ho.dataset.hoff);
      if (card) return cur === card.dataset.sid ? shut(false) : open(card.dataset.sid, false);
      if (t.closest("[data-back]")) return shut(false);
      if (t.closest("[data-more]")) return more(t.closest("[data-more]"));
      const sz = t.closest("[data-sz]"); if (sz) { setSize(sz.dataset.sz, key); sig = ""; return draw(); }
      if (t.closest("[data-sidetog]")) return sideToggle(key);
      if (t.closest("[data-addx]")) { adding = false; sig = ""; return draw(); }
      if (t.closest("[data-all]")) { closePop(); return offAll(); }
      if (t.closest("[data-vback]")) return closeRes(key);
      if (t.closest("[data-vapp]")) return viewing && showMain("#item/" + viewing.id);
      if (t.closest("[data-vok]")) return decide(true);
      if (t.closest("[data-vchg]")) return decide(false);
      const vf = t.closest("[data-vf]"); if (vf && viewing) { viewing.fi = +vf.dataset.vf; return drawView(vf.closest(".fl-view")); }
      const rs = t.closest("[data-res]"); if (rs) return openRes(rs.dataset.res, key);
      if (t.closest("[data-inbox]")) return showMain("#inbox");
      const ak = t.closest("[data-ask]"); if (ak) return showMain("#item/" + ak.dataset.ask);
      if (t.closest("[data-retry]")) return refresh();
      // The button, by name: <html> carries a data-hide of its own (panels the person hid in the app),
      // and taken for this one, every press listed below put the window away instead.
      if (t.closest("button[data-hide]")) { closePop(); return hide(); }
      if (t.closest("[data-app]")) return showMain("#project");
      const c = cards().find((x) => x.sid === cur);
      if (t.closest("[data-main]")) { closePop(); return showMain(c ? "#project/" + enc(c.name) + "/" + enc(c.sid) : "#project"); }
      if (t.closest("[data-unpin]")) { const sid = cur; closePop(); return offOne(sid); }
      if (t.closest("[data-out]")) { closePop(); return setOut(!outShut); }
      if (t.closest("[data-float]")) return api().float_out().then((ok) => { if (!ok) toast(tl("fl.openFail")); }, (e) => toast(e.message));
      const p = t.closest("[data-pin]"); if (p) { const r = recent().find((x) => x.sid === p.dataset.pin); adding = false; if (r) pin(r.sid, true, r); return; }
      const cp = t.closest("[data-copy]");
      if (cp) {
        // innerText keeps the line breaks only on a node that is laid out: read the line itself, without its meta row.
        const n = cp.closest(".pj-msg"), mt = [...n.querySelectorAll(":scope>.fl-meta,:scope>.fl-mr")];
        mt.forEach((x) => { x.hidden = true; });
        const txt = n.innerText.trim();
        mt.forEach((x) => { x.hidden = false; });
        (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => { if (!window.Motion) toast(tl("fl.copied")); }, () => toast(tl("fl.copyFail")));
      }
    }, true);
    stack.addEventListener("scroll", () => { closeMenu(); if (size === "m" && cur) fitBox();
      clearTimeout(rolling); rolling = setTimeout(() => { rolling = 0; report(); }, ROLL); report(); }, {passive: true});
    // Right-click (or the menu key) on a block: its menu. Elsewhere on the window: the window's
    // own entries. Where there is text to copy or type, the system's menu is left alone.
    root.addEventListener("contextmenu", (e) => {
      if (e.target.closest(".fl-body,.fl-view,input,textarea")) return;
      e.preventDefault();
      if (e.target.closest(".fl-menu")) return;
      const cw = e.target.closest(".fl-cw"), sid = cw ? cw.querySelector(".fl-card").dataset.sid : e.target.closest(".fl-head") ? cur : null;
      const rr = root.getBoundingClientRect();
      let x = e.clientX - rr.left, y = e.clientY - rr.top;
      if (!e.clientX && !e.clientY) { const q = (cw || e.target).getBoundingClientRect(); x = q.left - rr.left + 44; y = q.top - rr.top + 44; }
      openMenu(sid, x, y);
    });
    // A file being picked for the chat takes the keyboard away too: that is not a press elsewhere.
    root.addEventListener("click", (e) => { if (e.target.matches('input[type="file"]')) picking = true; }, true);
    addEventListener("focus", () => { picking = false; });
    addEventListener("blur", () => { closeMenu(); if (performance.now() >= blurAfter && outShut && cur && !picking && !holding()) shut(false); });
    // Esc closes what is on top (menu, dialog, then the chat); Alt+Up/Down walks the cards and,
    // while a chat is open, takes the chat along.
    addEventListener("keydown", (e) => {
      if (menu && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
        e.preventDefault();
        const bs = [...menu.el.querySelectorAll("button")], i = bs.indexOf(document.activeElement);
        return bs[(i + (e.key === "ArrowDown" ? 1 : bs.length - 1) + bs.length) % bs.length].focus({preventScroll: true});
      }
      if (e.key === "Escape") {
        if (closeMenu(true)) return e.preventDefault();
        if (closePop()) { const m = panel.querySelector("[data-more]"); if (m) m.focus(); return; }
        const sh = document.getElementById("sheet");
        if (sh && sh.classList.contains("on")) return closeSheet();
        if (document.querySelector(".cs-scrim,.pj-pop")) return;
        if (closeRes(true)) return e.preventDefault();
        if (adding) { adding = false; sig = ""; draw(); return; }
        if (cur) { e.preventDefault(); shut(false); }
        return;
      }
      // Alt+Right / Alt+Left: one size up (작게, 보통, 크게), or one down.
      if (e.altKey && (e.key === "ArrowRight" || e.key === "ArrowLeft") && cur) { e.preventDefault();
        return setSize(SIZES[Math.max(0, Math.min(2, SIZES.indexOf(size) + (e.key === "ArrowRight" ? 1 : -1)))], true); }
      if (e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
        const cs = cards(); if (!cs.length) return;
        e.preventDefault();
        const at = document.activeElement && document.activeElement.closest(".fl-card");
        const i = cs.findIndex((c) => c.sid === (cur || (at && at.dataset.sid)));
        const j = i < 0 ? 0 : (i + (e.key === "ArrowDown" ? 1 : cs.length - 1)) % cs.length;
        if (cur) open(cs[j].sid, true);
        else { const n = cardEl(cs[j].sid); if (n) { n.focus(); n.scrollIntoView({block: "nearest"}); } }
      }
    });
  }

  boot();
})();
