// 설정 → 앱 버전 기록: the installed app versions kept for rollback (design, served by updater.py).
// A date-grouped list; each past version has a "이 버전으로 되돌리기" button, the running one is
// marked. Rollback swaps the kept folder back in and restarts; it never touches user data, and
// warns first when the data is newer than that older build understands. Callable object, like
// rules.js / backup.js.
(function () {
  "use strict";

  const clock = (iso) => (iso || "").replace("T", " ").slice(0, 10);

  // Bucket an ISO date into 오늘 / 어제 / 이번 주 / a date. Literal tl() so tests see each key.
  function group(iso) {
    const d = new Date((iso || "").replace(" ", "T"));
    if (isNaN(d)) return tl("day.week");
    const floor = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate());
    const days = Math.round((floor(new Date()) - floor(d)) / 86400000);
    if (days <= 0) return tl("day.1");
    if (days === 1) return tl("day.2");
    if (days < 7) return tl("day.week");
    return `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()}`;
  }

  // Release notes carry each line in Korean and in English: show the reader's language only
  // (all of it when a version's notes have no line in that language).
  function mine(notes) {
    const ko = typeof LANG === "function" && LANG() === "ko";
    const own = String(notes).split("\n").filter((l) => !l.trim() || /[가-힣]/.test(l) === ko);
    return own.some((l) => l.trim()) ? own.join("\n") : notes;
  }
  function rowHTML(v) {
    const notes = v.notes ? esc(mine(v.notes)) : `<span class="c-grey">${tl("history.notes.none")}</span>`;
    const right = v.current
      ? `<span class="tag approved">${tl("history.current")}</span>`
      : (v.can_rollback ? `<button class="btn sm press" data-roll="${esc(v.version)}">${tl("history.rollback")}</button>` : "");
    return `<div class="row" style="flex-wrap:wrap"><span class="tx" style="min-width:190px">
      <div class="t" style="font-size:16px">v${esc(v.version)}</div>
      <div class="s" style="white-space:normal">${tl("history.installed", {d: esc(clock(v.at))})}</div>
      <div class="s" style="white-space:normal">${notes}</div></span>
      <span style="flex:none;display:flex;gap:6px;align-items:center;margin-left:auto;align-self:flex-start">${right}</span></div>`;
  }

  async function rollback(version, needsBackup) {
    if (!await askSheet(tl("history.rollback"), needsBackup ? tl("history.confirm.backup", {v: version}) : tl("history.confirm", {v: version}), false, tl("toggleFav.3"))) return;
    try { await post("/api/rollback", {version}); }
    catch (e) { toastFail(e.message, tl("err.ver.meta")); return; }
    toast(tl("history.rolling"), 30000);
    const t0 = Date.now();
    await new Promise((r) => setTimeout(r, 2000));
    while (Date.now() - t0 < 60000) {
      if (await fetch("/api/health").then((r) => r.ok).catch(() => false)) return location.reload();
      await new Promise((r) => setTimeout(r, 1000));
    }
    toast(tl("history.failed"));
  }

  async function draw(el) {
    let list;
    try { list = await fetch("/api/app-versions").then((r) => r.json()); }
    catch { return; }                             // old server without the endpoint: show nothing
    const card = document.createElement("div");
    card.className = "card";
    let rows = "";
    // Empty: what it is and where the rows come from; its one button is 업데이트 확인 right above.
    if (!list.length && !window.genokBeta?.("pai")) {
      rows = `<div class="row"><span class="tx"><div class="s">${tl("history.empty")}</div></span></div>`;
    } else if (!list.length) {
      rows = `<div class="row"><span class="tx"><div class="t">${tl("history.empty")}</div><div class="s" style="white-space:normal">${tl("history.empty.src")}</div></span></div>`;
    } else {
      let last = null;
      for (const v of list) {
        const g = group(v.at);
        if (g !== last) { rows += `<div class="sec">${esc(g)}</div>`; last = g; }
        rows += rowHTML(v);
      }
    }
    // The update check sits above the list (the same row, ids and box as 설정 › 업데이트, so
    // drawUpdate() paints both): this page is where people look for "is there a newer one?".
    const upd = typeof drawUpdate === "function"
      ? `<div class="srow"><span class="srtx"><span class="srt">${tl("update.1")}</span><span class="srd" id="upds" aria-live="polite">…</span></span><span class="srctl"><button class="btn sm press" id="updchk">${tl("upd.check")}</button></span></div>
      <div class="updbox" id="updbox" hidden></div>` : "";
    card.innerHTML = `${upd}${rows}<div style="height:6px"></div>`;
    el.innerHTML = "";
    el.appendChild(card);
    // The page's title and its one line sit above the card, as on every other settings page.
    card.insertAdjacentHTML("beforebegin", `<h2 class="seth">${tl("history.title")}</h2><p class="setd">${tl("history.desc")}</p>`);
    const chk = card.querySelector("#updchk");
    if (chk) { chk.onclick = () => drawUpdate(true, true); drawUpdate(false); }
    const byV = Object.fromEntries(list.map((v) => [String(v.version), v]));
    card.querySelectorAll("[data-roll]").forEach((b) => b.onclick = () =>
      rollback(b.dataset.roll, !!(byV[b.dataset.roll] || {}).needs_backup));
  }

  const entry = Object.assign(function (el) { draw(el); }, {page: "history", icon: "hist", title: "history.title"});
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(entry);
})();
