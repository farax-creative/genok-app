// Icon styles for the 아이콘 picker: besides emoji, a project can carry a Phosphor icon in one of
// four weights. Pure (no DOM), so node tests can load it: window.LOOP_ICONS in the browser,
// module.exports in node.
//
// A saved icon is "<style>/<name>" ("duotone/rocket-launch"), kept beside the emoji (which stays as
// the fallback for screens and devices that only know emoji). The drawings are one sprite per
// style, web/icons/ph-<style>.svg (tools/gen_phosphor.py), referenced with <use>, so a style is
// fetched only when something on the page shows it. Phosphor Icons, MIT: licenses/phosphor.md.
(function () {
  "use strict";

  const STYLES = ["regular", "bold", "fill", "duotone"];
  const NAMES = (/* NAMES:begin */"acorn address-book address-book-tabs air-traffic-control airplane airplane-in-flight airplane-landing airplane-takeoff airplane-taxiing airplane-tilt airplay alarm alien align-bottom align-bottom-simple align-center-horizontal align-center-horizontal-simple align-center-vertical align-center-vertical-simple align-left align-left-simple align-right align-right-simple align-top align-top-simple amazon-logo ambulance anchor anchor-simple android-logo angle angular-logo aperture app-store-logo app-window apple-logo apple-podcasts-logo approximate-equals archive armchair arrow-arc-left arrow-arc-right arrow-bend-double-up-left arrow-bend-double-up-right arrow-bend-down-left arrow-bend-down-right arrow-bend-left-down arrow-bend-left-up arrow-bend-right-down arrow-bend-right-up arrow-bend-up-left arrow-bend-up-right arrow-circle-down arrow-circle-down-left arrow-circle-down-right arrow-circle-left arrow-circle-right arrow-circle-up arrow-circle-up-left arrow-circle-up-right arrow-clockwise arrow-counter-clockwise arrow-down arrow-down-left arrow-down-right arrow-elbow-down-left arrow-elbow-down-right arrow-elbow-left arrow-elbow-left-down arrow-elbow-left-up arrow-elbow-right arrow-elbow-right-down arrow-elbow-right-up arrow-elbow-up-left arrow-elbow-up-right arrow-fat-down arrow-fat-left arrow-fat-line-down arrow-fat-line-left arrow-fat-line-right arrow-fat-line-up arrow-fat-lines-down arrow-fat-lines-left arrow-fat-lines-right arrow-fat-lines-up arrow-fat-right arrow-fat-up arrow-left arrow-line-down arrow-line-down-left arrow-line-down-right arrow-line-left arrow-line-right arrow-line-up arrow-line-up-left arrow-line-up-right arrow-right arrow-square-down arrow-square-down-left arrow-square-down-right arrow-square-in arrow-square-left arrow-square-out arrow-square-right arrow-square-up arrow-square-up-left arrow-square-up-right arrow-u-down-left arrow-u-down-right arrow-u-left-down arrow-u-left-up arrow-u-right-down arrow-u-right-up arrow-u-up-left arrow-u-up-right arrow-up arrow-up-left arrow-up-right arrows-clockwise arrows-counter-clockwise arrows-down-up arrows-horizontal arrows-in arrows-in-cardinal arrows-in-line-horizontal arrows-in-line-vertical arrows-in-simple arrows-left-right arrows-merge arrows-out arrows-out-cardinal arrows-out-line-horizontal arrows-out-line-vertical arrows-out-simple arrows-split arrows-vertical article article-medium article-ny-times asclepius asterisk asterisk-simple at atom avocado axe baby baby-carriage backpack backspace bag bag-simple balloon bandaids bank barbell barcode barn barricade baseball baseball-cap baseball-helmet basket basketball bathtub battery-charging battery-charging-vertical battery-empty battery-full battery-high battery-low battery-medium battery-plus battery-plus-vertical battery-vertical-empty battery-vertical-full battery-vertical-high battery-vertical-low battery-vertical-medium battery-warning battery-warning-vertical beach-ball beanie bed beer-bottle beer-stein behance-logo bell bell-ringing bell-simple bell-simple-ringing bell-simple-slash bell-simple-z bell-slash bell-z belt bezier-curve bicycle binary binoculars biohazard bird blueprint bluetooth bluetooth-connected bluetooth-slash bluetooth-x boat bomb bone book book-bookmark book-open book-open-text book-user bookmark bookmark-simple bookmarks bookmarks-simple books boot boules bounding-box bowl-food bowl-steam bowling-ball box-arrow-down box-arrow-up boxing-glove brackets-angle brackets-curly brackets-round brackets-square brain brandy bread bridge briefcase briefcase-metal broadcast broom browser browsers bug bug-beetle bug-droid building building-apartment building-office buildings bulldozer bus butterfly cable-car cactus cake calculator calendar calendar-blank calendar-check calendar-dot calendar-dots calendar-heart calendar-minus calendar-plus calendar-slash calendar-star calendar-x call-bell camera camera-plus camera-rotate camera-slash campfire car car-battery car-profile car-simple cardholder cards cards-three caret-circle-double-down caret-circle-double-left caret-circle-double-right caret-circle-double-up caret-circle-down caret-circle-left caret-circle-right caret-circle-up caret-circle-up-down caret-double-down caret-double-left caret-double-right caret-double-up caret-down caret-left caret-line-down caret-line-left caret-line-right caret-line-up caret-right caret-up caret-up-down carrot cash-register cassette-tape castle-turret cat cell-signal-full cell-signal-high cell-signal-low cell-signal-medium cell-signal-none cell-signal-slash cell-signal-x cell-tower certificate chair chalkboard chalkboard-simple chalkboard-teacher champagne charging-station chart-bar chart-bar-horizontal chart-donut chart-line chart-line-down chart-line-up chart-pie chart-pie-slice chart-polar chart-scatter chat chat-centered chat-centered-dots chat-centered-slash chat-centered-text chat-circle chat-circle-dots chat-circle-slash chat-circle-text chat-dots chat-slash chat-teardrop chat-teardrop-dots chat-teardrop-slash chat-teardrop-text chat-text chats chats-circle chats-teardrop check check-circle check-fat check-square check-square-offset checkerboard checks cheers cheese chef-hat cherries church cigarette cigarette-slash circle circle-dashed circle-half circle-half-tilt circle-notch circles-four circles-three circles-three-plus circuitry city clipboard clipboard-text clock clock-afternoon clock-clockwise clock-countdown clock-counter-clockwise clock-user closed-captioning cloud cloud-arrow-down cloud-arrow-up cloud-check cloud-fog cloud-lightning cloud-moon cloud-rain cloud-slash cloud-snow cloud-sun cloud-warning cloud-x clover club coat-hanger coda-logo code code-block code-simple codepen-logo codesandbox-logo coffee coffee-bean coin coin-vertical coins columns columns-plus-left columns-plus-right command compass compass-rose compass-tool computer-tower confetti contactless-payment control cookie cooking-pot copy copy-simple copyleft copyright corners-in corners-out couch court-basketball cow cowboy-hat cpu crane crane-tower credit-card cricket crop cross crosshair crosshair-simple crown crown-cross crown-simple cube cube-focus cube-transparent currency-btc currency-circle-dollar currency-cny currency-dollar currency-dollar-simple currency-eth currency-eur currency-gbp currency-inr currency-jpy currency-krw currency-kzt currency-ngn currency-rub cursor cursor-click cursor-text cylinder database desk desktop desktop-tower detective dev-to-logo device-mobile device-mobile-camera device-mobile-slash device-mobile-speaker device-rotate device-tablet device-tablet-camera device-tablet-speaker devices diamond diamonds-four dice-five dice-four dice-one dice-six dice-three dice-two disc disco-ball discord-logo divide dna dog door door-open dot dot-outline dots-nine dots-six dots-six-vertical dots-three dots-three-circle dots-three-circle-vertical dots-three-outline dots-three-outline-vertical dots-three-vertical download download-simple dress dresser dribbble-logo drone drop drop-half drop-half-bottom drop-simple drop-slash dropbox-logo ear ear-slash egg egg-crack eject eject-simple elevator empty engine envelope envelope-open envelope-simple envelope-simple-open equalizer equals eraser escalator-down escalator-up exam exclamation-mark exclude exclude-square export eye eye-closed eye-slash eyedropper eyedropper-sample eyeglasses eyes face-mask facebook-logo factory faders faders-horizontal fallout-shelter fan farm fast-forward fast-forward-circle feather fediverse-logo figma-logo file file-archive file-arrow-down file-arrow-up file-audio file-c file-c-sharp file-cloud file-code file-cpp file-css file-csv file-dashed file-doc file-html file-image file-ini file-jpg file-js file-jsx file-lock file-magnifying-glass file-md file-minus file-pdf file-plus file-png file-ppt file-py file-rs file-sql file-svg file-text file-ts file-tsx file-txt file-video file-vue file-x file-xls file-zip files film-reel film-script film-slate film-strip fingerprint fingerprint-simple finn-the-human fire fire-extinguisher fire-simple fire-truck first-aid first-aid-kit fish fish-simple flag flag-banner flag-banner-fold flag-checkered flag-pennant flame flashlight flask flip-horizontal flip-vertical floppy-disk floppy-disk-back flow-arrow flower flower-lotus flower-tulip flying-saucer folder folder-dashed folder-lock folder-minus folder-open folder-plus folder-simple folder-simple-dashed folder-simple-lock folder-simple-minus folder-simple-plus folder-simple-star folder-simple-user folder-star folder-user folders football football-helmet footprints fork-knife four-k frame-corners framer-logo function funnel funnel-simple funnel-simple-x funnel-x game-controller garage gas-can gas-pump gauge gavel gear gear-fine gear-six gender-female gender-intersex gender-male gender-neuter gender-nonbinary gender-transgender ghost gif gift git-branch git-commit git-diff git-fork git-merge git-pull-request github-logo gitlab-logo gitlab-logo-simple globe globe-hemisphere-east globe-hemisphere-west globe-simple globe-simple-x globe-stand globe-x goggles golf goodreads-logo google-cardboard-logo google-chrome-logo google-drive-logo google-logo google-photos-logo google-play-logo google-podcasts-logo gps gps-fix gps-slash gradient graduation-cap grains grains-slash graph graphics-card greater-than greater-than-or-equal grid-four grid-nine guitar hair-dryer hamburger hammer hand hand-arrow-down hand-arrow-up hand-coins hand-deposit hand-eye hand-fist hand-grabbing hand-heart hand-palm hand-peace hand-pointing hand-soap hand-swipe-left hand-swipe-right hand-tap hand-waving hand-withdraw handbag handbag-simple hands-clapping hands-praying handshake hard-drive hard-drives hard-hat hash hash-straight head-circuit headlights headphones headset heart heart-break heart-half heart-straight heart-straight-break heartbeat hexagon high-definition high-heel highlighter highlighter-circle hockey hoodie horse hospital hourglass hourglass-high hourglass-low hourglass-medium hourglass-simple hourglass-simple-high hourglass-simple-low hourglass-simple-medium house house-line house-simple hurricane ice-cream identification-badge identification-card image image-broken image-square images images-square infinity info instagram-logo intersect intersect-square intersect-three intersection invoice island jar jar-label jeep joystick kanban key key-return keyboard keyhole knife ladder ladder-simple lamp lamp-pendant laptop lasso lastfm-logo layout leaf lectern lego lego-smiley less-than less-than-or-equal letter-circle-h letter-circle-p letter-circle-v lifebuoy lightbulb lightbulb-filament lighthouse lightning lightning-a lightning-slash line-segment line-segments line-vertical link link-break link-simple link-simple-break link-simple-horizontal link-simple-horizontal-break linkedin-logo linktree-logo linux-logo list list-bullets list-checks list-dashes list-heart list-magnifying-glass list-numbers list-plus list-star lock lock-key lock-key-open lock-laminated lock-laminated-open lock-open lock-simple lock-simple-open lockers log magic-wand magnet magnet-straight magnifying-glass magnifying-glass-minus magnifying-glass-plus mailbox map-pin map-pin-area map-pin-line map-pin-plus map-pin-simple map-pin-simple-area map-pin-simple-line map-trifold markdown-logo marker-circle martini mask-happy mask-sad mastodon-logo math-operations matrix-logo medal medal-military medium-logo megaphone megaphone-simple member-of memory messenger-logo meta-logo meteor metronome microphone microphone-slash microphone-stage microscope microsoft-excel-logo microsoft-outlook-logo microsoft-powerpoint-logo microsoft-teams-logo microsoft-word-logo minus minus-circle minus-square money money-wavy monitor monitor-arrow-up monitor-play moon moon-stars moped moped-front mosque motorcycle mountains mouse mouse-left-click mouse-middle-click mouse-right-click mouse-scroll mouse-simple music-note music-note-simple music-notes music-notes-minus music-notes-plus music-notes-simple navigation-arrow needle network network-slash network-x newspaper newspaper-clipping not-equals not-member-of not-subset-of not-superset-of notches note note-blank note-pencil notebook notepad notification notion-logo nuclear-plant number-circle-eight number-circle-five number-circle-four number-circle-nine number-circle-one number-circle-seven number-circle-six number-circle-three number-circle-two number-circle-zero number-eight number-five number-four number-nine number-one number-seven number-six number-square-eight number-square-five number-square-four number-square-nine number-square-one number-square-seven number-square-six number-square-three number-square-two number-square-zero number-three number-two number-zero numpad nut ny-times-logo octagon office-chair onigiri open-ai-logo option orange orange-slice oven package paint-brush paint-brush-broad paint-brush-household paint-bucket paint-roller palette panorama pants paper-plane paper-plane-right paper-plane-tilt paperclip paperclip-horizontal parachute paragraph parallelogram park password path patreon-logo pause pause-circle paw-print paypal-logo peace pen pen-nib pen-nib-straight pencil pencil-circle pencil-line pencil-ruler pencil-simple pencil-simple-line pencil-simple-slash pencil-slash pentagon pentagram pepper percent person person-arms-spread person-simple person-simple-bike person-simple-circle person-simple-hike person-simple-run person-simple-ski person-simple-snowboard person-simple-swim person-simple-tai-chi person-simple-throw person-simple-walk perspective phone phone-call phone-disconnect phone-incoming phone-list phone-outgoing phone-pause phone-plus phone-slash phone-transfer phone-x phosphor-logo pi piano-keys picnic-table picture-in-picture piggy-bank pill ping-pong pint-glass pinterest-logo pinwheel pipe pipe-wrench pix-logo pizza placeholder planet plant play play-circle play-pause playlist plug plug-charging plugs plugs-connected plus plus-circle plus-minus plus-square poker-chip police-car polygon popcorn popsicle potted-plant power prescription presentation presentation-chart printer prohibit prohibit-inset projector-screen projector-screen-chart pulse push-pin push-pin-simple push-pin-simple-slash push-pin-slash puzzle-piece qr-code question question-mark queue quotes rabbit racquet radical radio radio-button radioactive rainbow rainbow-cloud ranking read-cv-logo receipt receipt-x record rectangle rectangle-dashed recycle reddit-logo repeat repeat-once replit-logo resize rewind rewind-circle road-horizon robot rocket rocket-launch rows rows-plus-bottom rows-plus-top rss rss-simple rug ruler sailboat scales scan scan-smiley scissors scooter screencast screwdriver scribble scribble-loop scroll seal seal-check seal-percent seal-question seal-warning seat seatbelt security-camera selection selection-all selection-background selection-foreground selection-inverse selection-plus selection-slash shapes share share-fat share-network shield shield-check shield-checkered shield-chevron shield-plus shield-slash shield-star shield-warning shipping-container shirt-folded shooting-star shopping-bag shopping-bag-open shopping-cart shopping-cart-simple shovel shower shrimp shuffle shuffle-angular shuffle-simple sidebar sidebar-simple sigma sign-in sign-out signature signpost sim-card siren sketch-logo skip-back skip-back-circle skip-forward skip-forward-circle skull skype-logo slack-logo sliders sliders-horizontal slideshow smiley smiley-angry smiley-blank smiley-meh smiley-melting smiley-nervous smiley-sad smiley-sticker smiley-wink smiley-x-eyes snapchat-logo sneaker sneaker-move snowflake soccer-ball sock solar-panel solar-roof sort-ascending sort-descending soundcloud-logo spade sparkle speaker-hifi speaker-high speaker-low speaker-none speaker-simple-high speaker-simple-low speaker-simple-none speaker-simple-slash speaker-simple-x speaker-slash speaker-x speedometer sphere spinner spinner-ball spinner-gap spiral split-horizontal split-vertical spotify-logo spray-bottle square square-half square-half-bottom square-logo square-split-horizontal square-split-vertical squares-four stack stack-minus stack-overflow-logo stack-plus stack-simple stairs stamp standard-definition star star-and-crescent star-four star-half star-of-david steam-logo steering-wheel steps stethoscope sticker stool stop stop-circle storefront strategy stripe-logo student subset-of subset-proper-of subtitles subtitles-slash subtract subtract-square subway suitcase suitcase-rolling suitcase-simple sun sun-dim sun-horizon sunglasses superset-of superset-proper-of swap swatches swimming-pool sword synagogue syringe t-shirt table tabs tag tag-chevron tag-simple target taxi tea-bag telegram-logo television television-simple tennis-ball tent terminal terminal-window test-tube text-a-underline text-aa text-align-center text-align-justify text-align-left text-align-right text-b text-columns text-h text-h-five text-h-four text-h-one text-h-six text-h-three text-h-two text-indent text-italic text-outdent text-strikethrough text-subscript text-superscript text-t text-t-slash text-underline textbox thermometer thermometer-cold thermometer-hot thermometer-simple threads-logo three-d thumbs-down thumbs-up ticket tidal-logo tiktok-logo tilde timer tip-jar tipi tire toggle-left toggle-right toilet toilet-paper toolbox tooth tornado tote tote-simple towel tractor trademark trademark-registered traffic-cone traffic-sign traffic-signal train train-regional train-simple tram translate trash trash-simple tray tray-arrow-down tray-arrow-up treasure-chest tree tree-evergreen tree-palm tree-structure tree-view trend-down trend-up triangle triangle-dashed trolley trolley-suitcase trophy truck truck-trailer tumblr-logo twitch-logo twitter-logo umbrella umbrella-simple union unite unite-square upload upload-simple usb user user-check user-circle user-circle-check user-circle-dashed user-circle-gear user-circle-minus user-circle-plus user-focus user-gear user-list user-minus user-plus user-rectangle user-sound user-square user-switch users users-four users-three van vault vector-three vector-two vibrate video video-camera video-camera-slash video-conference vignette vinyl-record virtual-reality virus visor voicemail volleyball wall wallet warehouse warning warning-circle warning-diamond warning-octagon washing-machine watch wave-sawtooth wave-sine wave-square wave-triangle waveform waveform-slash waves webcam webcam-slash webhooks-logo wechat-logo whatsapp-logo wheelchair wheelchair-motion wifi-high wifi-low wifi-medium wifi-none wifi-slash wifi-x wind windmill windows-logo wine wrench x x-circle x-logo x-square yarn yin-yang youtube-logo"/* NAMES:end */).split(" ").filter(Boolean);
  const SET = new Set(NAMES);
  const TOK = NAMES.map((n) => n.split("-"));
  const RE = /^(regular|bold|fill|duotone)\/([a-z0-9-]{1,48})$/;

  // "duotone/rocket" -> {style, name}; null for anything this build cannot draw.
  function parse(icon) {
    const m = RE.exec(String(icon || ""));
    return m && SET.has(m[2]) ? {style: m[1], name: m[2]} : null;
  }
  // A sprite's address as the page names it (v2.html "ph-sprites", tagged by the server so it is kept
  // for good); the plain name where there is no such page.
  const TAGGED = {};
  if (typeof document !== "undefined") (document.querySelector('meta[name="ph-sprites"]')?.content || "").split(" ").forEach((u) => { const m = /ph-([a-z]+)\.svg/.exec(u); if (m) TAGGED[m[1]] = u; });
  const href = (style) => TAGGED[style] || `/icons/ph-${style}.svg`;
  const svg = (style, name) => `<svg class="phi" viewBox="0 0 256 256" aria-hidden="true" focusable="false"><use href="${href(style)}#${name}"/></svg>`;
  // The drawing for a saved icon, "" when it is not one (the caller falls back to the emoji).
  function html(icon) { const p = parse(icon); return p ? svg(p.style, p.name) : ""; }

  // Korean (and a few English) everyday words -> words Phosphor names are made of. The emoji
  // set's own concept list (emoji.js CONCEPTS) is read too, so both pickers answer the same words.
  const KO = [
    ["영상 비디오 동영상 촬영 릴스 쇼츠 유튜브 movie reel shorts youtube", "video camera film monitor play youtube"],
    ["영화 필름 편집 렌더 render", "film slate video scissors"],
    ["사진 이미지 그림 포토 photo picture", "image images camera aperture"],
    ["디자인 그래픽 일러스트 브랜드 로고 design graphic logo brand", "palette paint brush pen nib bezier swatches"],
    ["3d 모델링 블렌더 blender 모션 입체", "cube cylinder sphere polygon shapes"],
    ["코드 개발 프로그램 스크립트 프로그래밍 dev script", "code terminal brackets git bug"],
    ["앱 app 서버 server api 백엔드 backend 프론트 frontend", "browser database cloud cpu plugs"],
    ["봇 로봇 자동화 bot ai 에이전트 agent", "robot gear lightning magic brain"],
    ["글 문서 원고 기획 보고서 리포트 doc docs report writing", "file article note notebook pencil"],
    ["메모 노트 필기 memo", "note notepad notebook pencil"],
    ["책 독서 도서 공부 학습 강의 수업 study", "book books bookmark student chalkboard graduation"],
    ["폴더 파일 자료 보관 정리 아카이브", "folder folders file files archive tray"],
    ["돈 결제 정산 매출 수익 가격 비용 예산 재무 회계 세금 pay money finance", "money coin coins wallet bank receipt invoice currency"],
    ["카드 구독 subscription", "cardholder credit repeat"],
    ["차트 통계 분석 데이터 지표 data analytics", "chart graph presentation trend table"],
    ["주식 투자 매매 트레이딩 trading stock", "chart trend coins"],
    ["마케팅 홍보 광고 공지 캠페인 marketing ad promo", "megaphone target trend rocket"],
    ["sns 소셜 인스타 social", "share instagram chats heart hash"],
    ["메일 이메일 편지 뉴스레터 email mail", "envelope mailbox paper"],
    ["채팅 대화 메시지 상담 문의 고객 chat support cs", "chat chats headset lifebuoy"],
    ["전화 통화 call", "phone"],
    ["음악 노래 사운드 오디오 소리 music audio sound", "music headphones speaker vinyl waveform"],
    ["녹음 마이크 팟캐스트 방송 podcast", "microphone broadcast radio"],
    ["게임 game 플레이", "game joystick sword"],
    ["일정 달력 캘린더 날짜 schedule", "calendar"],
    ["시간 시계 알람 타이머 마감 납기 deadline", "clock alarm timer hourglass watch"],
    ["알림 종 notify", "bell"],
    ["아이디어 생각 영감 idea", "lightbulb brain sparkle"],
    ["검색 찾기 조사 리서치 탐색 research search", "magnifying binoculars compass detective"],
    ["목표 타깃 집중 goal", "target crosshair flag"],
    ["우승 상 성과 트로피", "trophy medal crown"],
    ["별 즐겨찾기 중요 star", "star"],
    ["하트 사랑 좋아요 love like", "heart"],
    ["불 인기 핫 fire hot", "fire flame"],
    ["번개 빠른 전기 에너지 fast", "lightning"],
    ["로켓 출시 런칭 배포 릴리스 launch release deploy", "rocket"],
    ["실험 테스트 검증 과학 연구 qa test lab", "flask test atom dna"],
    ["버그 오류 디버그 bug", "bug"],
    ["도구 수리 설정 유지보수 세팅 tool fix settings", "wrench hammer gear toolbox nut"],
    ["보안 안전 방패 security", "shield lock"],
    ["잠금 비밀 암호 열쇠 키 password", "lock key password"],
    ["사람 고객 사용자 팀 회원 인사 채용 hr team user", "user users person identification"],
    ["집 홈 가정 home", "house"],
    ["회사 사무실 건물 빌딩 office", "buildings building briefcase"],
    ["일 업무 작업 work job project", "briefcase kanban check clipboard"],
    ["가게 쇼핑 스토어 상점 판매 커머스 shop store", "storefront shopping bag basket"],
    ["상품 제품 배송 택배 포장 재고 product", "package truck barcode tag"],
    ["선물 이벤트 파티 축하 gift", "gift confetti balloon cake"],
    ["여행 휴가 trip travel", "airplane suitcase map island"],
    ["지도 위치 장소 map", "map compass globe"],
    ["지구 세계 글로벌 해외 world", "globe"],
    ["차 자동차 운전 car", "car"],
    ["기차 지하철 버스 교통", "train bus subway"],
    ["자전거 운동 헬스 스포츠 sport fitness", "bicycle barbell sneaker basketball soccer"],
    ["건강 병원 의료 약 health", "heartbeat pill stethoscope syringe hospital"],
    ["음식 요리 밥 식당 food", "fork cooking bowl hamburger pizza"],
    ["커피 카페 차 coffee", "coffee"],
    ["고양이 cat", "cat"],
    ["강아지 개 dog", "dog"],
    ["동물 펫 animal", "paw cat dog bird fish"],
    ["나무 숲 자연 nature", "tree"],
    ["식물 꽃 정원 잎 plant", "plant flower leaf"],
    ["해 날씨 맑음 sun", "sun"],
    ["달 밤 야간 moon", "moon"],
    ["구름 비 클라우드 cloud", "cloud umbrella"],
    ["눈 보기 시선 리뷰 검토 eye review", "eye eyes"],
    ["손 hand", "hand hands"],
    ["링크 연결 link", "link plugs"],
    ["휴지통 삭제 delete", "trash"],
    ["태그 라벨 tag", "tag"],
    ["깃발 flag", "flag"],
    ["체크 완료 확인 승인 done", "check checks seal"],
    ["경고 주의 위험 warning", "warning siren"],
    ["질문 물음 도움말 help", "question"],
    ["마법 반짝 효과 magic", "magic sparkle"],
    ["옷 패션 fashion", "shirt dress hoodie"],
    ["아기 육아 baby", "baby"],
    ["법 계약 법률 legal", "scales gavel signature"],
    ["번역 언어 language", "translate globe"],
    ["프린터 인쇄 print", "printer"],
    ["와이파이 네트워크 인터넷 network", "wifi network globe"],
    ["퍼즐 조각 puzzle", "puzzle"],
    ["컴퓨터 pc 데스크톱 노트북 laptop", "desktop laptop monitor computer"],
    ["폰 모바일 휴대폰 mobile", "device phone"],
  ].map(([k, v]) => [k.split(" "), v.split(" ")]);

  // A list word fits a query when it is one of the query's words or the query is how it starts;
  // a Korean word of two letters or more also fits inside a longer one ("영상편집" has "영상").
  const fits = (q, qs, w) => qs.includes(w) || (q.length > 1 && w.startsWith(q)) || (w.length > 1 && !/^[a-z0-9]+$/.test(w) && q.includes(w));
  let EM;
  function emoji() {
    if (EM === undefined) {
      EM = null;
      if (typeof window !== "undefined") EM = window.LOOP_EMOJI || null;
      else if (typeof require !== "undefined") { try { EM = require("./emoji.js"); } catch (e) { /* names only */ } }
    }
    return EM;
  }
  // The name words a query stands for: its own, plus what the Korean lists say.
  function words(q) {
    const out = new Set(q.split(/[\s\-_]+/).filter(Boolean));
    const qs = [...out], hit = (ws) => ws.some((w) => fits(q, qs, w));
    KO.forEach(([k, v]) => { if (hit(k)) v.forEach((w) => out.add(w)); });
    const em = emoji();
    if (em) em.CONCEPTS.forEach((c) => { if (hit(c[0])) c[2].split(" ").forEach((w) => out.add(w)); });
    return [...out];
  }
  // Search by Korean word or English name. A whole name word that matches ranks first, then a
  // word that starts with it, then the query anywhere in the name. No query: every icon, by name.
  function search(q, limit) {
    q = String(q || "").trim().toLowerCase();
    limit = limit || 400;
    if (!q) return NAMES.slice(0, limit);
    const ws = words(q), dashed = q.replace(/\s+/g, "-");
    const out = [];
    NAMES.forEach((n, i) => {
      let s = n === dashed ? 100 : 0;
      for (const w of ws) {
        if (TOK[i].includes(w)) s += 10;
        else if (w.length > 2 && TOK[i].some((t) => t.startsWith(w))) s += 3;
      }
      if (!s && dashed.length > 1 && n.includes(dashed)) s = 2;
      if (s) out.push([s - TOK[i].length * 0.1, n]);          // "rocket" before "rocket-launch"
    });
    out.sort((a, b) => b[0] - a[0] || (a[1] < b[1] ? -1 : 1));
    return out.slice(0, limit).map((x) => x[1]);
  }

  const DEFAULTS = ["folder", "folders", "cube", "sparkle", "star", "lightbulb", "rocket-launch", "puzzle-piece", "target", "compass", "flag", "bookmark-simple"];
  // A few icons for a name: what each of its words finds, then the everyday ones.
  function suggest(name, n) {
    n = n || 7;
    const low = String(name || "").trim().toLowerCase();
    const out = [], add = (x) => { if (out.length < n && SET.has(x) && !out.includes(x)) out.push(x); };
    if (low) {
      const parts = low.split(/\s+/).map((w) => search(w, 4));
      for (let i = 0; i < 4; i++) parts.forEach((p) => { if (p[i]) add(p[i]); });
    }
    DEFAULTS.forEach(add);
    return out;
  }

  // What a screen shows for an identity: its styled icon, or the emoji it falls back to (escaped).
  const face = (icon, emoji) => html(icon) || String(emoji || "").replace(/[&<>"']/g, (c) => "&#" + c.charCodeAt(0) + ";");

  const api = {STYLES, NAMES, parse, html, svg, href, face, search, suggest, KO};
  if (typeof window !== "undefined") window.LOOP_ICONS = api;
  if (typeof module !== "undefined") module.exports = api;
})();
