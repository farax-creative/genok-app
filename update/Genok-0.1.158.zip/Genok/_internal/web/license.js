// 설정 → 라이선스: enter/remove a license key, start the local Pro trial, and read the plan.
// It also owns the client-side gate: window.planCan(feature) and the calm inline "Pro" note
// that gated screens (phone.js, ...) show instead of nagging or hiding anything.
//
// The key can be entered in two places that share one wiring (wireActivate): the settings page
// and the Pro sheet. The sheet takes the key right where the locked action was pressed, so the
// flow underneath (the phone wizard, a settings page) stays open and simply continues.
// Uses v2.js globals: tl, post, toast, esc, ic, sheet, closeSheet, SCREENS.
(function () {
  "use strict";

  // Kept in sync with plan.PRO_ONLY. A feature not here is free and always allowed.
  const PRO_ONLY = ["phone", "multiple_accounts", "version_history", "push_notify"];
  // A calm one-liner per gated feature. Literal tl() calls so tests/test_i18n sees each key.
  const PRO_MSG = {
    phone: () => tl("license.pro_phone"),
    multiple_accounts: () => tl("license.pro_multiple_accounts"),
    version_history: () => tl("license.pro_version_history"),
    push_notify: () => tl("license.pro_push_notify"),
  };

  // Fail closed until the plan is known: a free default means Pro switches stay off, never
  // that data is hidden. Refreshed from /api/plan below and after every change.
  window.LOOP_PLAN = window.LOOP_PLAN || {plan: "free", pro: false, features: {}};

  window.planCan = function (feature) {
    if (!PRO_ONLY.includes(feature)) return true;         // free features: always yes
    const f = (window.LOOP_PLAN && window.LOOP_PLAN.features) || {};
    return !!f[feature];
  };

  async function refresh() {
    try { window.LOOP_PLAN = await fetch("/api/plan").then((r) => r.json()); }
    catch { /* old server without the endpoint: keep the free default */ }
    // The plan name in the bottom corner (v2.js drawStatus) follows what the server said.
    try { if (typeof drawStatus === "function") drawStatus(); } catch (e) { /* drawn on the next render */ }
    remind(window.LOOP_PLAN);
    return window.LOOP_PLAN;
  }

  // A key with an end date says so 30 days and 7 days ahead, once each: one toast with a way to
  // the 라이선스 page, then the server remembers it was shown. It waits for a visible page so a
  // background tab does not use the one showing up. The page itself always carries the date.
  let reminding = false;
  function remind(p) {
    const n = p && p.expiry_notice;
    if (!n || reminding || typeof toastAct !== "function" || !document.getElementById("toast")) return;
    if (document.visibilityState !== "visible") return;
    reminding = true;
    setTimeout(() => {
      toastAct(n.days_left > 0 ? tl("license.expiring", {n: n.days_left, d: n.expiry}) : tl("license.expiring_today", {d: n.expiry}),
        tl("license.expiring_open"), () => {
          try { setPage = "license"; setShowPage = true; } catch (e) { /* settings opens on its default page */ }
          if (location.hash === "#settings") SCREENS.settings(); else location.hash = "#settings";
        }, 12000);
      post("/api/license/notice-seen", {}).then((r) => { window.LOOP_PLAN = r; }).catch(() => {}).finally(() => { reminding = false; });
    }, 1500);
  }
  document.addEventListener("visibilitychange", () => remind(window.LOOP_PLAN));
  refresh();

  // The plan changed: tell whoever listens, and repaint an open settings page so its Pro note
  // and locked rows follow at once.
  function planChanged() {
    try { window.dispatchEvent(new CustomEvent("loop:plan", {detail: window.LOOP_PLAN})); } catch (e) { /* old engine */ }
    if (document.getElementById("setpage") && typeof SCREENS === "object" && SCREENS.settings) SCREENS.settings();
  }

  // The key field, its button and the line under it. The answer stays next to the field (a toast
  // alone is gone in two seconds): a wrong key says why in place and keeps the text for fixing.
  function wireActivate(root, done) {
    const key = root.querySelector("[data-lic-key]"), apply = root.querySelector("[data-lic-apply]"), msg = root.querySelector("[data-lic-msg]");
    if (!key || !apply) return;
    const say = (t, bad) => {
      msg.textContent = t || ""; msg.classList.toggle("warn", !!bad);
      key.classList.toggle("bad", !!bad); key.setAttribute("aria-invalid", bad ? "true" : "false");
    };
    const sync = () => { apply.disabled = !(key.value || "").trim(); apply.title = apply.disabled ? tl("license.apply.need") : ""; };
    const go = async () => {
      const v = (key.value || "").trim(); if (!v || apply.dataset.busy) return;
      apply.dataset.busy = "1"; apply.disabled = true; apply.textContent = tl("license.checking"); say("");
      try { window.LOOP_PLAN = await post("/api/license", {key: v}); toast(tl("license.applied")); done(); }
      catch (e) {
        delete apply.dataset.busy; apply.textContent = tl("license.apply"); sync();
        say(e.message, true); key.focus(); key.select();
      }
    };
    key.addEventListener("input", () => { sync(); say(""); });
    key.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); go(); } });
    apply.onclick = go;
    sync();
  }

  async function startTrial(done) {
    try { window.LOOP_PLAN = await post("/api/license/trial", {on: true}); toast(tl("license.trial_started")); done(); }
    catch (e) { toast(e.message); }
  }

  // Why a stored key is not giving Pro, one plain line each with what to do next. Literal tl()
  // calls so tests/test_i18n sees each key. Anything not listed gets the general line.
  const KEY_BAD = {
    expired: (p) => p.expiry ? tl("license.key_expired", {date: p.expiry}) : tl("license.key_bad.expired"),
    polar_expired: () => tl("license.key_bad.polar_expired"),
    polar_revoked: () => tl("license.key_bad.polar_revoked"),
    polar_not_found: () => tl("license.key_bad.polar_not_found"),
    polar_device: () => tl("license.key_bad.polar_device"),
    polar_offline: (p) => tl("license.key_bad.polar_offline", {n: (p.polar && p.polar.grace_days) || 14}),
  };
  // These can change on Polar's side (renewed, a payment recovered, a device slot freed, back
  // online): offer a re-check.
  const RECHECK = ["polar_expired", "polar_revoked", "polar_device", "polar_offline"];

  // A buy link is a plain new-tab link in a browser. The app window has no tabs, so there the
  // click asks the server to open the PC's default browser instead (like 의견 남기기). Only the
  // tier name is sent; the server opens the configured address and nothing else.
  document.addEventListener("click", (e) => {
    const a = e.target.closest?.("[data-lic-buy]");
    if (!a || typeof IN_APP === "undefined" || !IN_APP) return;
    e.preventDefault();
    post("/api/license/checkout", {tier: a.dataset.licBuy}).catch((x) => toast(x.message));
  });

  const canTrial = (p) => { const t = (p && p.trial) || {}; return !p.pro && !t.active && !t.used; };

  // A calm inline block for a locked control: a "Pro" tag, one line, and 라이선스 입력.
  window.proInlineHTML = function (feature) {
    const msg = (PRO_MSG[feature] || (() => tl("license.pro_generic")))();
    return `<div class="pro-note"><span class="pro-tag">${tl("license.pro_tag")}</span>
      <span class="pro-msg">${esc(msg)}</span>
      <button class="btn sm press" data-pro-enter="${esc(feature || "")}">${tl("license.pro_enter")}</button></div>`;
  };

  // Any [data-pro-enter] button opens the key sheet over whatever is on screen.
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-pro-enter]");
    if (b) window.proSheet(b.dataset.proEnter || "");
  });

  // The sheet for a locked action (e.g. pressing 폰 연결 켜기 on free): what is locked, the key
  // field, and the trial when it is still available. Nothing underneath is closed; once Pro is on
  // the action that was pressed carries on.
  window.proSheet = function (feature) {
    const msg = (PRO_MSG[feature] || (() => tl("license.pro_generic")))();
    const p = window.LOOP_PLAN || {};
    sheet(`<h2 class="lic-sh"><span class="pro-tag">${tl("license.pro_tag")}</span><span>${esc(msg)}</span></h2>
      <p class="hint lic-shd">${tl("license.sheet_desc")}</p>
      <input data-lic-key class="tin lic-key" aria-label="${tl("license.key_label")}" placeholder="${tl("license.key_ph")}" autocomplete="off" autocapitalize="off" spellcheck="false">
      <p class="lic-msg" data-lic-msg role="status" aria-live="polite"></p>
      <div class="lic-acts"><button class="btn press" data-sclose>${tl("license.close")}</button>
        <button class="btn fill press" data-lic-apply disabled>${tl("license.apply")}</button></div>
      ${canTrial(p) ? `<div class="lic-try"><span>${tl("license.sheet_trial")}</span>
        <button class="lnk press" data-lic-trial>${tl("license.trial_start")}</button></div>` : ""}`, (box) => {
      const done = () => {
        planChanged();
        // The phone wizard's own button is still there: press it again now that it is unlocked.
        const next = feature === "phone" && window.planCan("phone") && document.getElementById("pw-on");
        if (next) next.click(); else closeSheet();
      };
      wireActivate(box, done);
      box.querySelector("[data-lic-trial]")?.addEventListener("click", (e) => { e.currentTarget.disabled = true; startTrial(done); });
    });
  };

  // ------------------------------------------------------------ settings page
  const PLAN_NAME = {free: () => tl("license.plan_free"), pro: () => tl("license.plan_pro"),
    lifetime: () => tl("license.plan_lifetime"), trial: () => tl("license.plan_trial")};

  // Order: what you have now, then the key field, then manage; prices sit folded at the bottom
  // (nothing can be bought in the app yet, so they must not stand between the person and the key).
  async function draw(c) {
    const p = await refresh();
    const name = (PLAN_NAME[p.plan] || PLAN_NAME.free)();
    const trial = p.trial || {};
    const lines = [];
    if (p.plan === "trial") lines.push(tl("license.trial_active", {days: trial.days_left || 0}));
    else if (p.pro) lines.push(tl("license.status_pro"));
    else lines.push(tl("license.status_free"));
    if (p.seat) lines.push(tl("license.seat", {n: p.seat}));
    if (p.issued) lines.push(tl("license.issued", {d: p.issued}));
    const polar = p.polar || null;                                  // set only for a key checked online
    const soon = p.days_left != null && p.days_left <= 30;         // the last month: say how long is left
    if (p.subscription) lines.push(tl("license.subscribed"));       // no end date: runs while the subscription is paid
    else if (p.source === "license" || p.source === "polar") lines.push(!p.expiry ? tl("license.expiry_none")
      : !soon ? tl("license.expiry", {d: p.expiry})
      : p.days_left > 0 ? tl("license.expiry_left", {d: p.expiry, n: p.days_left}) : tl("license.expiry_today", {d: p.expiry}));
    else if (p.key_reason === "polar_expired" && p.expiry) lines.push(tl("license.expiry", {d: p.expiry}));
    if (p.source === "polar" && polar.checked && !polar.offline) lines.push(tl("license.polar_checked", {d: polar.checked}));
    const bad = p.key_reason ? (KEY_BAD[p.key_reason] || (() => tl("license.key_bad")))(p) : "";
    const recheck = RECHECK.includes(p.key_reason) || (p.source === "polar" && polar.offline);

    const badge = p.plan === "trial" ? tl("license.badge_trial") : p.pro ? tl("license.badge_pro") : tl("license.badge_free");
    const badgeCls = p.plan === "trial" ? "trial" : p.pro ? "pro" : "free";
    const keyed = p.source === "license" || p.source === "polar";   // a working key is in: no field until it is removed

    // [checkout tier key, name, price]. The tier key selects a buy link from p.checkout; when
    // none is configured the button stays disabled ("준비 중").
    const PRICES = [
      ["month", tl("license.plan_month"), tl("license.plan_month_price")],
      ["year", tl("license.plan_year"), tl("license.plan_year_price")],
      ["life", tl("license.plan_life"), tl("license.plan_life_price")],
    ];
    const checkout = (p && p.checkout) || {};
    const buyBtn = (tier) => checkout[tier]
      ? `<a class="btn sm press" data-lic-buy="${esc(tier)}" href="${esc(checkout[tier])}" target="_blank" rel="noopener noreferrer">${tl("license.buy")}</a>`
      : `<button class="btn sm press" disabled>${tl("license.buy_soon")}</button>`;

    c.innerHTML = `<h2 class="seth">${tl("license.title")}</h2><p class="setd">${more1(tl("license.desc"), tl("license.desc.more"))}</p>

      <div class="setsec">${tl("license.status_sec")}</div>
      <div class="setcard lic-plan">
        <div class="lic-planhd">
          <span class="lic-planname">${esc(name)}</span>
          ${badgeCls === "free" ? "" : `<span class="lic-badge ${badgeCls}">${esc(badge)}</span>`}
        </div>
        <div class="lic-planlines">${lines.map(esc).join(" · ")}</div>
        ${bad ? `<div class="srd warn lic-warn">${esc(bad)}</div>` : ""}
        ${p.source === "polar" && polar.offline ? `<div class="srd lic-warn">${esc(polar.grace_until ? tl("license.polar_offline", {d: polar.grace_until}) : tl("license.polar_offline_plain"))}</div>` : ""}
        ${recheck ? `<div class="lic-re"><button class="btn sm press" id="lic-recheck">${tl("license.recheck")}</button></div>` : ""}
      </div>

      ${!keyed && checkout.beta ? setRow(tl("license.beta_title"), tl("license.beta_desc"),
        `<a class="btn sm fill press" data-lic-buy="beta" href="${esc(checkout.beta)}" target="_blank" rel="noopener noreferrer">${tl("license.beta_get")}</a>`) : ""}
      ${keyed ? "" : `<div class="setsec">${tl("license.activate_sec")}</div>
      <p class="setd lic-actd">${tl("license.activate_desc")}</p>
      <div class="lic-row"><input data-lic-key class="setin lic-key" aria-label="${tl("license.key_label")}" placeholder="${tl("license.key_ph")}" autocomplete="off" autocapitalize="off" spellcheck="false">
        <button class="btn fill press lic-apply" data-lic-apply disabled>${tl("license.apply")}</button></div>
      <p class="lic-msg" data-lic-msg role="status" aria-live="polite"></p>`}

      ${p.has_key || !p.pro ? `<div class="setsec">${tl("license.manage_sec")}</div>` : ""}
      ${p.has_key ? setRow(tl("license.key_label"), polar && polar.device ? tl("license.key_device") : keyed ? tl("license.key_set") : "",
        `<button class="btn sm press" id="lic-remove">${polar && polar.device ? tl("license.release") : tl("license.remove")}</button>`) : ""}
      <div class="lic-stuck" id="lic-stuck" role="status" aria-live="polite" hidden><span>${tl("license.release_fail")}</span>
        <button class="btn sm press" id="lic-force">${tl("license.remove_anyway")}</button></div>
      ${!p.pro && !p.has_key ? setRow(tl("license.trial_title"),
        trial.active ? tl("license.trial_active", {days: trial.days_left}) : trial.used ? tl("license.trial_used") : tl("license.trial_desc"),
        canTrial(p) ? `<button class="btn sm press" id="lic-trial">${tl("license.trial_start")}</button>` : "") : ""}

      <details class="lic-plans"><summary>${tl("license.plan_sec")}</summary>
        ${PRICES.map(([tier, t, price]) => setRow(esc(t), esc(price), buyBtn(tier))).join("")}
        <p class="setd lic-note">${PRICES.some(([tier]) => checkout[tier]) ? tl("license.plan_note_buy") : tl("license.plan_note")}</p></details>`;

    wireActivate(c, () => draw(c));
    // Taking a key off also gives its device slot back to the license server. When that cannot
    // be confirmed (offline) the key stays and the choice is shown in place: try again later, or
    // remove it here anyway knowing the slot stays taken.
    const remove = async (btn, force) => {
      if (btn.dataset.busy) return;
      btn.dataset.busy = "1"; btn.disabled = true;
      try {
        const r = await post("/api/license/remove", force ? {force: true} : {});
        window.LOOP_PLAN = r;
        if (r.removed === false) {
          delete btn.dataset.busy; btn.disabled = false;
          const stuck = c.querySelector("#lic-stuck"); if (stuck) stuck.hidden = false;
          return;
        }
        toast(r.slot === "freed" ? tl("license.released") : r.slot === "kept" ? tl("license.removed_kept") : tl("license.removed"));
        planChanged(); draw(c);
      } catch (e) { delete btn.dataset.busy; btn.disabled = false; toast(e.message); }
    };
    c.querySelector("#lic-remove")?.addEventListener("click", (e) => remove(e.currentTarget, false));
    c.querySelector("#lic-force")?.addEventListener("click", (e) => remove(e.currentTarget, true));
    c.querySelector("#lic-recheck")?.addEventListener("click", async (e) => {
      const b = e.currentTarget; b.disabled = true; b.textContent = tl("license.checking");
      try {
        const r = await post("/api/license/recheck", {});
        window.LOOP_PLAN = r;
        toast(r.rechecked === false ? tl("license.recheck_fail") : r.pro ? tl("license.recheck_ok") : tl("license.recheck_same"));
        planChanged(); draw(c);
      } catch (x) { b.disabled = false; b.textContent = tl("license.recheck"); toast(x.message); }
    });
    c.querySelector("#lic-trial")?.addEventListener("click", (e) => { e.currentTarget.disabled = true; startTrial(() => draw(c)); });
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "license", icon: "key", title: "license.title", draw});

  // ------------------------------------------------------------ styles (own file, no v2.css edit)
  // App tokens only (--card, --line, --t1..--t4, --btn, --blue, --orange, --r-*), so the note and
  // the page follow the light theme and the density setting like every other settings section.
  const css = `
  .pro-note { display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
    padding: 12px 16px; margin: 0 0 16px; border-radius: var(--r-lg);
    background: var(--card); border: 1px solid var(--line); }
  .pro-tag { flex: none; font-size: 12px; font-weight: 700; letter-spacing: .03em; line-height: 1; padding: 4px 8px;
    border-radius: 999px; background: var(--blue-w); color: var(--blue-t); }
  /* Pro reads as silver metal on the tag and the badge only (never on buttons), same in both themes. */
  @keyframes gkm-sheen { from { background-position: 0% 0; } to { background-position: 100% 0; } }
  .pro-tag, .lic-badge.pro { background: linear-gradient(115deg,#77746e 0%,#f3f0e8 22%,#a5a29a 40%,#e4e0d6 56%,#77746e 74%,#f3f0e8 92%,#a5a29a 100%);
    background-size: 240% 100%; color: #16161a; text-shadow: 0 1px 0 rgba(255,255,255,.35);
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.32), inset 0 -1px 0 rgba(0,0,0,.28), 0 0 0 1px rgba(0,0,0,.18);
    animation: gkm-sheen 7s ease-in-out infinite alternate; }
  @media (prefers-reduced-motion: reduce) { .pro-tag, .lic-badge.pro { animation: none; } }
  .pro-msg { flex: 1; min-width: 140px; font-size: 14px; line-height: 1.45; color: var(--t2); white-space: normal; }
  /* the settings modal's close button sits in the page's top-right corner: start the note below it */
  @media (min-width: 721px) { .setpage > div > div:first-child > .pro-note:first-child { margin-top: 24px; } }
  /* Pro sheet */
  .sbox .lic-sh { display: flex; align-items: flex-start; gap: 8px; margin: 0 40px 0 0;
    font-size: 16px; font-weight: 600; line-height: 1.35; letter-spacing: -.01em; color: var(--t1); }
  .sbox .lic-sh .pro-tag { margin-top: 4px; }
  .sbox .lic-shd { margin: -2px 0 8px; line-height: 1.5; }
  .sbox .lic-msg { min-height: 0; margin: -2px 2px 0; }
  .sbox .lic-msg:empty { display: none; }
  .lic-acts { display: flex; gap: 8px; margin-top: 4px; }
  .lic-acts .btn { flex: 1; height: 44px; border-radius: var(--r-md); }
  .lic-try { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
    margin-top: 6px; padding-top: 16px; border-top: 1px solid var(--line); font-size: 13px; line-height: 1.45; color: var(--t3); }
  .lic-try .lnk { font-size: 13px; }
  /* the key field: the same input as every other settings field, plus a wrong-key state */
  .lic-key.bad, .sbox input.tin.lic-key.bad { border-color: var(--orange); box-shadow: inset 0 0 0 1px var(--orange); }
  .lic-msg { min-height: 18px; margin: 6px 0 0; font-size: 13px; line-height: 1.4; color: var(--t3); overflow-wrap: anywhere; }
  .lic-msg.warn { color: var(--orange); }
  .lic-row { display: flex; align-items: center; gap: 8px; margin: 8px 0 0; }
  .lic-row .setin { flex: 1; min-width: 0; }
  .lic-row .btn { height: 36px; padding: 0 16px; font-size: 14px; border-radius: var(--r-sm); }
  .lic-row .btn:disabled, .lic-acts .btn:disabled { opacity: .45; cursor: default; }
  /* the shared .btn.fill hover is a fixed blue that ignores the theme's accent: stay on the accent here */
  .lic-row .btn.fill:hover, .lic-acts .btn.fill:hover { background: var(--blue); filter: brightness(1.08); }
  .lic-actd { margin-top: 8px; }
  /* current-plan card (refern License) */
  .lic-planhd { display: flex; align-items: center; gap: 8px; }
  .lic-planname { font-size: 20px; font-weight: 600; letter-spacing: -.01em; color: var(--t1); }
  .lic-badge { margin-left: auto; font-size: 12px; font-weight: 700; letter-spacing: .03em;
    padding: 4px 8px; border-radius: 999px; background: var(--btn); color: var(--t2); white-space: nowrap; }
  .lic-badge.pro { background: var(--blue); color: var(--on-blue); }
  .lic-badge.trial { background: rgba(224,138,47,.18); color: #e0a24f; }
  .lic-planlines { font-size: 13px; color: var(--t3); margin-top: 6px; line-height: 1.5; }
  .lic-warn { margin-top: 8px; line-height: 1.5; overflow-wrap: anywhere; }
  .lic-re { margin-top: 8px; }
  .lic-stuck { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 8px 0 0; padding: 12px 16px;
    border-radius: var(--r-md); border: 1px solid var(--line); background: var(--card);
    font-size: 13px; line-height: 1.5; color: var(--t2); }
  .lic-stuck[hidden] { display: none; }
  .lic-stuck span { flex: 1; min-width: 200px; }
  /* prices: folded, below everything that can be acted on */
  .lic-plans { margin-top: 8px; }
  .lic-plans summary { width: max-content; padding: 8px 0 4px; cursor: pointer; font-size: 13px; font-weight: 500; color: var(--t3); }
  .lic-plans summary:hover { color: var(--t1); }
  .lic-plans[open] summary { color: var(--t2); }
  .lic-note { margin-top: 8px; }
  @media (max-width: 520px) { .lic-row { flex-wrap: wrap; } .lic-row .setin { flex-basis: 100%; } .lic-row .btn { flex: 1; } }`;
  const s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);
})();
