// Long-poll: wake the screen the instant the data changes, instead of the 30s fallback poll in
// v2.js. Loaded from v2.html after v2.js, so it reads v2.js's own globals (load, SCREENS, cur,
// detail, inTab, drawChrome) by name and changes nothing in it. /api/watch blocks up to ~20s and
// returns the moment a session replies or a new version lands; the v2.js interval stays as a
// backstop for anything the watch misses (design v2 §10).
(function () {
  "use strict";

  // decide(prev, next): what the client should do with a new /api/watch reply, given the last
  // one. Pure, so node can test it without a browser. On the first reply prev is null and we do
  // nothing. When the revision differs, reload. When restarts went up, the server was restarted
  // by its watchdog (its rev also reset, so a reload comes with it), so say so once.
  function decide(prev, next) {
    if (!next) return {refresh: false, restarted: false};
    if (prev == null) return {refresh: false, restarted: false};
    return {
      refresh: next.rev !== prev.rev,
      restarted: (next.restarts || 0) > (prev.restarts || 0),
    };
  }

  // arrivals(before, after, here): the versions that landed between two item lists, as
  // [{k: "project/id", v}]. A new item counts, a newer version of a known one counts; the item on
  // screen (`here`) does not, it redraws itself. No baseline (the first load) is no arrival.
  const key = (x) => x.project + "/" + x.id;
  // A delete, trash, or rollback of the newest version lowers v: that is not an arrival.
  const vNum = (v) => parseInt(String(v || "").replace(/^v/i, ""), 10) || 0;
  function arrivals(before, after, here) {
    if (!before || !before.length || !after) return [];
    const was = new Map(before.map((x) => [key(x), x.v]));
    return after.filter((x) => key(x) !== here && (!was.has(key(x)) || vNum(x.v) > vNum(was.get(key(x))))).map((x) => ({k: key(x), v: x.v}));
  }

  // pace(held, fresh, last, now, busy): one arrival toast per GAP. What lands in between, or while
  // the screen is busy (another toast up, the tab not in front), waits and joins the next one, so a
  // burst of pushes is one line, never a flood. -> {show: [...] | null, held: [...], wait: ms}
  const GAP = 30000, BUSY = 4000;
  function pace(held, fresh, last, now, busy) {
    const m = new Map(held.map((a) => [a.k, a]));
    fresh.forEach((a) => { m.delete(a.k); m.set(a.k, a); });   // newest last, its version the latest
    const all = [...m.values()];
    if (!all.length) return {show: null, held: [], wait: 0};
    if (busy) return {show: null, held: all, wait: BUSY};
    if (now - last < GAP) return {show: null, held: all, wait: last + GAP - now};
    return {show: all, held: [], wait: 0};
  }

  if (typeof module !== "undefined" && module.exports) { module.exports = {decide, arrivals, pace, GAP}; return; }

  const WAIT = 25000;   // client-side cap, a little over the server's 20s, so a dead link can't hang forever
  let prev = null;

  // "{부서}에서 v3 올라옴 · 보기": a result finished elsewhere, one press to it. More than one at
  // once is one line that opens the 새로 list (of that department when they share one).
  let held = [], lastAt = 0, paceT = 0;
  const here = () => detail && detail[0] === "item" ? detail[1] : null;
  function arrive(fresh) {
    clearTimeout(paceT);
    const t = document.getElementById("toast"), away = document.hidden || !document.hasFocus();
    // The app window not in front: this PC already raised its notice card for the push, so the
    // toast would only repeat it on return. A browser has no such card and keeps them for then.
    if (away && window.pywebview) fresh = [];
    const busy = away || !t || t.classList.contains("on");
    const r = pace(held, fresh.filter((a) => a.k !== here()), lastAt, Date.now(), busy);
    held = r.held;
    if (held.length) paceT = setTimeout(() => arrive([]), r.wait);
    const L = (r.show || []).filter((a) => a.k !== here()).map((a) => ({...a, x: D.items.find((x) => iid(x) === a.k)}))
      .filter((a) => a.x && !(D.hidden || []).includes(a.x.project));
    if (!L.length) return;
    lastAt = Date.now();
    const g = new Set(L.map((a) => gname(a.x)));
    const one = g.size === 1 ? [...g][0] : "";
    if (L.length === 1) {
      const a = L[0];
      return toastAct(tl("live.arr", {p: pname(one), v: vShort(a.v)}), tl("live.arr.go"), () => nav("item/" + a.k), 6000);
    }
    toastAct(one ? tl("live.arr.n", {p: pname(one), n: L.length}) : tl("live.arr.m", {n: L.length}), tl("live.arr.go"),
      () => nav("lib?f=fresh" + (one ? "&d=" + encodeURIComponent(one) : "")), 6000);
  }

  function refreshScreen() {
    // Same rule the v2.js interval uses: never yank a screen the reader is typing in or reading
    // in detail. load() refreshes the data; the current list redraws itself.
    const before = D.items;
    return load().then(() => {
      if (window.genokBeta?.("pai")) try { arrive(arrivals(before, D.items, here())); } catch (e) { console.error(e); }
      const typing = document.activeElement && document.activeElement.matches &&
        document.activeElement.matches("input,textarea,gk-select");
      const sheet = document.getElementById("sheet");
      if (!typing && !(sheet && sheet.classList.contains("on"))) {
        // redraw() (v2.js) keeps the shown content, scroll and folds; the old direct call rebuilt the page.
        if (typeof redraw === "function") redraw();
        else if (!detail && SCREENS[cur] && cur !== "settings") SCREENS[cur](cur === "inbox" ? inTab : undefined);
      }
      try { drawChrome(); } catch (e) {}
    });
  }

  function restartNote() {
    // One quiet line at the bottom that the server came back. Styled inline so it needs no CSS
    // file (this module owns only live.js); a fade, so reduced-motion is fine.
    let el = document.getElementById("live-note");
    if (!el) {
      el = document.createElement("div");
      el.id = "live-note";
      el.style.cssText = "position:fixed;left:50%;bottom:16px;transform:translateX(-50%);" +
        "z-index:9999;max-width:calc(100vw - 32px);background:var(--t1,#1b1b1b);" +
        "color:var(--bg,#fff);padding:8px 16px;border-radius:999px;font-size:13px;" +
        "box-shadow:0 4px 20px rgba(0,0,0,.22);opacity:0;transition:opacity .35s ease;" +
        "pointer-events:none";
      document.body.appendChild(el);
    }
    el.textContent = window.I18N_LANG === "en" ? "The server restarted" : "서버를 다시 시작했어요";
    el.style.opacity = "1";
    clearTimeout(restartNote._t);
    restartNote._t = setTimeout(() => { el.style.opacity = "0"; }, 6000);
  }

  // A hidden tab must not hold a long-poll: the browser allows about six connections per host
  // across all tabs, so a few background tabs starved the one in front (item pages took 3-8s).
  // Hidden: drop the open watch and sleep until the tab is shown; v2.js's interval still polls.
  let live = null;
  function shown() {
    return new Promise((done) => {
      const on = () => { if (!document.hidden) { document.removeEventListener("visibilitychange", on); done(); } };
      document.addEventListener("visibilitychange", on);
    });
  }
  document.addEventListener("visibilitychange", () => { if (document.hidden && live) live.abort(); });

  async function tick() {
    if (document.hidden) { await shown(); }
    let next = null;
    const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
    live = ac;
    const kill = ac ? setTimeout(() => ac.abort(), WAIT) : null;
    try {
      const q = prev ? "?rev=" + encodeURIComponent(prev.rev) : "";
      const r = await fetch("/api/watch" + q, {cache: "no-store", signal: ac ? ac.signal : undefined});
      if (r.ok) next = await r.json();
    } catch (e) {
      // Aborted, or the server is down (maybe restarting): fall through to the backoff below.
    } finally {
      if (kill) clearTimeout(kill);
    }
    if (next) {
      const act = decide(prev, next);
      prev = next;
      if (act.restarted) restartNote();
      if (act.refresh && !document.hidden) { try { await refreshScreen(); } catch (e) {} }
      setTimeout(tick, 0);
    } else {
      setTimeout(tick, document.hidden ? 0 : 3000);   // no answer yet: wait, then try again
    }
  }

  if (typeof document !== "undefined") tick();
})();
