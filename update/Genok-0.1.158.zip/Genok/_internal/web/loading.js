// The one loading state: an area that is waiting stays empty and shows only the logo mark, its
// ring turning, in the middle of that area. Part of the app core.
//
// loadingHtml(label, opts) returns markup for any innerHTML slot. The mark is the <rl-orb> logo
// ring (orb.js): it owns its rAF loop, pauses offscreen and on a hidden tab, and stops when it
// leaves the DOM, so a replaced placeholder leaks nothing.
//   label  what a screen reader hears (never drawn); empty = the general "loading" line.
//   opts   {size: the mark in CSS px (default 48, matching the first-visit splash),
//           fill: true when the whole screen is waiting - the box grows to the room left under it,
//                 so the mark sits in the middle of what is visible,
//           quiet: true for a small part of a screen that is already up (a home card): no mark,
//                  only the status for a screen reader - one screen never turns several rings,
//           tight: true where the parent already centres it (an overlay on a video): no room of its own,
//           inline: true for a control's own busy state - a 20px ring with the text beside it,
//           cls: extra class}.
// The mark comes in only once the wait passes DELAY (a fast load never flashes it; no canvas is
// made before that) and fades in where it stands. Under prefers-reduced-motion the ring rests on
// its still logo frame and the mark breathes with a slow opacity fade instead.
(function () {
  "use strict";
  if (window.loadingHtml) return;
  const DELAY = 250, SIZE = 48, SPEED = 0.8;      // a wait reads calmer a little under the logo's own pace
  const CSS = `
.ld{display:inline-flex;align-items:center;justify-content:center;gap:8px;color:inherit;vertical-align:middle}
.ld rl-orb{flex:none}
.ld-t{min-width:0}
rl-load{display:flex;align-items:center;justify-content:center;box-sizing:border-box;width:100%;min-height:calc(var(--ld,48px) + 40px);margin:0;padding:0;opacity:0;transition:opacity .22s ease;position:relative;pointer-events:none}
rl-load.on{opacity:.92}
rl-load rl-orb{flex:none;transform:translateY(var(--ld-dy,0px))}
rl-load[tight]{min-height:var(--ld,48px)}
.ld-sr{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
.ld-q{position:relative;display:block;min-height:20px}
@keyframes ldFade{0%,100%{opacity:.45}50%{opacity:1}}
@media (prefers-reduced-motion:reduce){.ld rl-orb,rl-load rl-orb{animation:ldFade 2.4s ease-in-out infinite}rl-load{transition:none}}`;
  const s = document.createElement("style");
  s.id = "ld-style"; s.textContent = CSS; document.head.appendChild(s);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const px = (v) => parseFloat(v) || 0;

  // <rl-load>: the box the mark sits in. It waits DELAY, then puts the ring in and fades it up.
  class RlLoad extends HTMLElement {
    connectedCallback() {
      if (this.hasAttribute("fill")) {
        this._fit();
        this._rs = () => this._fit();
        addEventListener("resize", this._rs);
      }
      clearTimeout(this._t);
      this._t = setTimeout(() => {
        this._t = 0;
        if (!this.querySelector("rl-orb")) {       // markup copied from a shown loader already has one
          const n = px(this.getAttribute("size")) || SIZE, o = document.createElement("rl-orb");
          o.setAttribute("state", "breathing");
          o.setAttribute("size", "64");       // use the splash's detailed geometry at every loading size
          o.setAttribute("px", String(n));
          o.setAttribute("speed", this.getAttribute("speed") || String(SPEED));
          o.setAttribute("aria-label", "");
          this.appendChild(o);
        }
        if (this._rs) this._fit();
        this.classList.add("on");
      }, DELAY);
    }
    disconnectedCallback() {
      clearTimeout(this._t); this._t = 0;
      if (this._rs) { removeEventListener("resize", this._rs); this._rs = null; }
    }
    // fill: take the room between this box and the bottom of what is visible (the screen's own
    // panel when it already reaches there), without making the page any longer than it was. The
    // mark is then moved by what is left, so it is in the middle of the waiting area either way.
    _fit() {
      const se = document.scrollingElement || document.documentElement;
      this.style.minHeight = "0px"; this.style.removeProperty("--ld-dy");
      const was = se.scrollHeight - se.clientHeight;
      const top = this.getBoundingClientRect().top, host = this.closest("#view") || this.parentElement;
      const tb = document.getElementById("tabbar"), tr = tb && tb.getBoundingClientRect();
      const vis = tr && tr.height && tr.top > innerHeight / 2 ? tr.top : innerHeight;
      const hr = host.getBoundingClientRect(), cs = getComputedStyle(host);
      const floor = hr.bottom <= vis + 1 && hr.bottom >= (top + vis) / 2;   // the panel reaches down on its own
      const end = floor ? hr.bottom - px(cs.paddingBottom) : vis - 16;  // how far this box may reach
      // What the eye reads as the waiting area: the whole panel when nothing stands above the mark.
      const a0 = top - hr.top - px(cs.paddingTop) < 2 ? hr.top : top, a1 = floor ? hr.bottom : vis;
      let h = Math.max(120, Math.round(end - top));
      this.style.minHeight = h + "px";
      const over = (se.scrollHeight - se.clientHeight) - Math.max(0, was);
      if (over > 0) { h = Math.max(120, h - over); this.style.minHeight = h + "px"; }
      const dy = (a0 + a1) / 2 - (top + h / 2);
      if (Math.abs(dy) > 0.5) this.style.setProperty("--ld-dy", dy.toFixed(1) + "px");
    }
  }
  if (typeof customElements !== "undefined" && !customElements.get("rl-load")) customElements.define("rl-load", RlLoad);

  // `label` is plain text or trusted markup (i18n / literals), like the strings it replaces.
  window.loadingHtml = (label, opts) => {
    const o = opts || {}, cls = o.cls ? " " + esc(o.cls) : "";
    if (o.inline) return `<span class="ld${cls}" role="status"><rl-orb state="breathing" size="20" aria-label=""></rl-orb>${label ? `<span class="ld-t">${label}</span>` : ""}</span>`;
    const say = esc(String(label || "").replace(/<[^>]*>/g, "")) || (typeof tl === "function" ? esc(tl("load.label")) : "");
    if (o.quiet) return `<span class="ld-q${cls}" role="status" aria-busy="true"><span class="ld-sr">${say}</span></span>`;
    const n = px(o.size) || SIZE;
    return `<rl-load class="ld-c${cls}" role="status" aria-busy="true" size="${n}"${o.fill ? " fill" : ""}${o.tight ? " tight" : ""} style="--ld:${n}px"><span class="ld-sr">${say}</span></rl-load>`;
  };
})();
