// A long press on a touch screen starts picking (as a phone's photo or mail list does): the
// results cards (web/v2.js) and the chat list's rows (web/project.js) say which rows take it, as
// LongPress.add. The row gives under the finger while it is held, a finger that moves more than
// SLOP is a scroll and lets go, and the lift that ended a hold opens nothing. A mouse never
// starts it. The timing is at the top, pure and tested in tests/longpress.test.js.
(function () {
  "use strict";

  const HOLD = 450;             // ms a finger rests before the hold answers
  const SLOP = 10;              // px it may drift meanwhile
  const GIVE = 0.97;            // the row's scale while it is held

  // One finger's hold: down starts the wait, a move past `slop` or a lift ends it, `fire` is the
  // answer. `press`/`release` bracket the wait (the row's give); timers are injectable for tests.
  function track(o) {
    const set = o.set || setTimeout, clear = o.clear || clearTimeout, hold = o.hold || HOLD, slop = o.slop || SLOP;
    let t = 0, at = null;
    const t1 = {
      down(x, y) {
        t1.cancel(); at = [x, y]; if (o.press) o.press();
        t = set(() => { t = 0; at = null; if (o.release) o.release(); o.fire(); }, hold);
      },
      move(x, y) { if (at && Math.hypot(x - at[0], y - at[1]) > slop) t1.cancel(); },
      up() { t1.cancel(); },
      cancel() { const was = !!at; if (t) clear(t); t = 0; at = null; if (was && o.release) o.release(); },
      armed: () => !!at,
    };
    return t1;
  }

  // A picking mode on the history: the back gesture (or Esc's Back in the app) leaves it instead
  // of the page. `out` is called when the step is gone back from; the returned function drops the
  // step when the mode ends some other way, unless something has been stepped to after it.
  let steps = 0;
  function step(out) {
    const id = ++steps; let on = true;
    history.pushState({lp: id}, "");
    const pop = () => { if (!on || (history.state && history.state.lp === id)) return; on = false; removeEventListener("popstate", pop); out(); };
    addEventListener("popstate", pop);
    return () => { if (!on) return; on = false; removeEventListener("popstate", pop);
      setTimeout(() => { if (history.state && history.state.lp === id) history.back(); }, 0); };
  }

  const api = {HOLD, SLOP, GIVE, track, step};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;
  window.LongPress = api;

  // ---- the page -------------------------------------------------------------------------------
  // Each kind: {rows: selector, can(row, e): whether this row takes a hold now, hold(row, e)}.
  const kinds = [];
  api.add = (k) => { kinds.push(k); };
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  let cur = null, held = 0, lift = 0, down = false;   // down: a hold has answered and the finger is still on
  const give = (row) => {
    row.classList.add("lp-hold");
    if (RM() || !window.Motion || !Motion.phys) return null;
    const s = Motion.phys(1, 420, 40, (x) => { row.style.scale = x === 1 ? "" : String(x); });
    s.set(GIVE); return s;
  };
  const tr = track({
    press() { cur.spring = give(cur.row); },
    release() { const c = cur; if (!c) return; c.row.classList.remove("lp-hold"); if (c.spring) c.spring.set(1); else c.row.style.removeProperty("scale"); },
    fire() { const c = cur; cur = null; if (!c.row.isConnected) return;
      held = performance.now(); down = true; if (navigator.vibrate) navigator.vibrate(10);
      c.kind.hold(c.row, c.e); },
  });
  document.addEventListener("pointerdown", (e) => {
    tr.cancel(); cur = null;
    if (e.pointerType === "mouse" || e.button > 0 || !e.isPrimary || !e.target.closest) return;
    for (const kind of kinds) {
      const row = e.target.closest(kind.rows);
      if (row && kind.can(row, e)) { cur = {row, kind, e, spring: null}; tr.down(e.clientX, e.clientY); return; }
    }
  }, true);
  document.addEventListener("pointermove", (e) => { if (cur) tr.move(e.clientX, e.clientY); }, true);
  ["pointerup", "pointercancel"].forEach((k) => document.addEventListener(k, () => {
    if (cur) tr.up();
    if (down) { down = false; lift = performance.now(); } }, true));
  addEventListener("blur", () => tr.cancel());
  addEventListener("scroll", () => tr.cancel(), {capture: true, passive: true});
  // The lift that ended the hold must not also open or toggle what is under it.
  document.addEventListener("click", (e) => {
    if (!e.isTrusted || !lift || performance.now() - lift > 500) return;
    lift = 0; e.preventDefault(); e.stopImmediatePropagation(); }, true);
  // Nor bring up the browser's own long-press menu over it.
  document.addEventListener("contextmenu", (e) => {
    if (cur || down || (held && performance.now() - held < 1500) || (lift && performance.now() - lift < 500)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
})();
