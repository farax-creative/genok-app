// 만든 정보 (makeinfo.py, beta "pai"): what made the version on screen, as a slim strip over the
// picture (under the title on a phone): the prompt (two lines, unfolds), the inputs as small tiles
// (+N past six) and a small table of model, size, length and credits. An input that is another
// result (item@v003) is a link: hovering or focusing it shows it larger, pressing it opens that
// version. The item also lists 이 버전을 쓴 곳 (the results that took this version as an input),
// its header carries the item's credit total, and the project page the project's.
//
// Classic script: it shares v2.js's globals (tl, esc, ic, get, thumb, vShort, pname, wide, nav,
// again, openItem, detail, verPick, V) and attaches through window.LOOP_ITEM_VIEW.
(function () {
  "use strict";
  if (!window.genokBeta?.("pai")) return;      // 설정 → 베타 off: no strip, no list, no totals

  const SHOW = 6;                              // input tiles before "+N"
  const got = {};                              // "p/i" -> {sig, data} from /api/make
  const asking = {};                           // "p/i" -> the sig being fetched
  const shown = new Set();                     // strips already drawn once: a redraw does not fade them again
  const unfolded = new Set(), allIns = new Set();
  let last = null;                             // {box, it, d} of the item on screen

  const fmt = (n) => Number(n).toLocaleString(undefined, {maximumFractionDigits: 2});
  const len = (x) => (typeof x === "number" ? tl("mk.sec", {n: fmt(x)}) : String(x));
  const vkey = (it) => `${it.p}/${it.i}@${it.v}`;

  function tile(x) {
    const pic = thumb({kind: x.kind || "image", thumb: x.thumb}, "ico sm");
    if (x.ref) {
      const name = `${x.title} ${vShort(x.v)}` + (x.as === "ref" ? ` · ${tl("mk.as.ref")}` : "");
      if (x.gone) return `<button class="mkin press" disabled title="${esc(tl("mk.gone"))}" aria-label="${esc(name)}">${pic}<span class="mkv">${esc(vShort(x.v))}</span></button>`;
      return `<button class="mkin press" data-mkrp="${esc(x.p)}" data-mki="${esc(x.i)}" data-mkv="${esc(x.v)}" data-mkl="${esc(x.latest || "")}" data-mkbig="${esc(x.big || "")}" data-mkname="${esc(name)}" aria-label="${esc(tl("mk.open", {t: name}))}">${pic}<span class="mkv">${esc(vShort(x.v))}</span></button>`;
    }
    return `<a class="mkin press" href="${esc(x.url)}" target="_blank" rel="noopener" data-mkbig="${esc(x.big || "")}" data-mkname="${esc(x.name)}" aria-label="${esc(x.name)}">${pic}</a>`;
  }

  // The strip's markup for one version's make-info, "" when there is nothing to show.
  function strip(mk, key) {
    if (!mk) return "";
    const ins = mk.inputs || [], many = ins.length > SHOW && !allIns.has(key);
    const rows = [[tl("mk.model"), mk.model], [tl("mk.size"), mk.resolution], [tl("mk.length"), mk.length != null ? len(mk.length) : null],
      [tl("mk.credits"), mk.credits != null ? fmt(mk.credits) : null]].filter(([, v]) => v != null && v !== "");
    if (!mk.prompt && !ins.length && !rows.length) return "";
    const open = unfolded.has(key);
    return `<section class="mkstrip" data-k="${esc(key)}" aria-label="${esc(tl("mk.made"))}">`
      + (mk.prompt ? `<div class="mkp${open ? " open" : ""}"><p class="mkpt" title="${esc(tl("mk.prompt"))}">${esc(mk.prompt)}</p><button class="lnk press mkpm" data-mkfold aria-expanded="${open}" hidden>${open ? tl("itemView.30") : tl("ui.more")}</button></div>` : "")
      + (ins.length || rows.length ? `<div class="mkrow">`
        + (ins.length ? `<div class="mkins" aria-label="${esc(tl("mk.inputs"))}">${(many ? ins.slice(0, SHOW) : ins).map(tile).join("")}${many ? `<button class="mkin mkmore press" data-mkall aria-label="${esc(tl("mk.all", {n: ins.length}))}">+${ins.length - SHOW}</button>` : ""}</div>` : "")
        + (rows.length ? `<dl class="mkt">${rows.map(([k, v]) => `<div><dt>${k}</dt><dd title="${esc(v)}">${esc(v)}</dd></div>`).join("")}</dl>` : "")
        + `</div>` : "")
      + `</section>`;
  }

  // 이 버전을 쓴 곳: the results that took version v of this item as an input.
  function usedCard(list, v) {
    const rows = (list || []).filter((u) => u.of === v);
    if (!rows.length) return "";
    return `<div class="card mkused"><div class="ch"><h2>${tl("mk.used")}</h2><span class="n num">${rows.length}</span></div>`
      + rows.map((u) => `<button class="row press" data-mkrp="${esc(u.p)}" data-mki="${esc(u.i)}" data-mkv="${esc(u.v)}" data-mkl="${esc(u.latest || "")}" data-mkbig="${esc(u.big || "")}" data-mkname="${esc(u.title + " " + vShort(u.v))}">${thumb({kind: u.kind || "image", thumb: u.thumb}, "ico sm")}<span class="tx"><div class="t">${esc(u.title)}</div><div class="s">${esc(vShort(u.v))} · ${esc(pname(u.p))}${u.as === "ref" ? ` · ${tl("mk.as.ref")}` : ""}</div></span>${ic("chev", "i go")}</button>`).join("")
      + `</div>`;
  }

  const crChip = (cr) => (cr && cr.all > 0 ? `<span class="tag mkcr" title="${esc(tl("mk.cr.month", {n: fmt(cr.month)}))}">${tl("mk.cr", {n: fmt(cr.all)})}</span>` : "");

  function paint() {
    if (!last) return;
    const {box, it} = last, data = got[`${it.p}/${it.i}`]?.data;
    if (!data) return;
    const key = vkey(it), html = strip(data.versions?.[it.v], key);
    const where = wide() ? box.querySelector(".detailcols.item > .media") : box.querySelector(".detailcols.item .iside > .htitle");
    const old = box.querySelector(".mkstrip");
    const sig = key + "|" + html.length + "|" + (wide() ? "w" : "n");
    if (old && old.dataset.sig === sig && (wide() ? old.parentElement === where : old.previousElementSibling === where)) {
      // the same strip in the same place (a kept report column): left as it is
    } else {
      old?.remove();
      if (html && where) {
        const t = document.createElement("div");
        t.innerHTML = html;
        const el = t.firstElementChild;
        el.dataset.sig = sig;
        if (!shown.has(key)) { el.classList.add("fresh"); shown.add(key); }
        if (wide()) where.prepend(el); else where.after(el);
        fold(el);
      }
      // A stage size the user set was fitted before the strip took its room: fit it again.
      if (typeof stageRefit === "function") stageRefit();
    }
    box.querySelector(".mkused")?.remove();
    const used = usedCard(data.used_by, it.v), tabs = box.querySelector(".detailcols.item .iside > .itab");
    if (used && tabs) tabs.insertAdjacentHTML("beforebegin", used);
    box.querySelector(".tag.mkcr")?.remove();
    const p = box.querySelector(".htitle p"), chip = crChip(data.credits);
    if (p && chip) { const more = p.querySelector(".imore"); if (more) more.insertAdjacentHTML("beforebegin", chip); else p.insertAdjacentHTML("beforeend", chip); }
  }

  // The prompt's 더 보기 shows only when two lines do not hold it.
  function fold(el) {
    const t = el.querySelector(".mkpt"), b = el.querySelector("[data-mkfold]");
    if (!t || !b) return;
    b.hidden = !el.querySelector(".mkp.open") && t.scrollHeight <= t.clientHeight + 1;
  }

  function attach(box, it, d) {
    const opened = last?.it.id !== it.id;
    last = {box, it, d};
    const k = `${it.p}/${it.i}`, sig = (d.versions || []).map((w) => w.v).join(",");
    paint();
    // Asked again when the versions change and each time the item is opened (a result that used it may be new).
    if ((got[k]?.sig === sig && !opened) || asking[k] === sig) return;
    asking[k] = sig;
    get(`/api/make?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}`).then((data) => {
      delete asking[k];
      if (!data?.on) return;
      got[k] = {sig, data};
      if (last && `${last.it.p}/${last.it.i}` === k && last.box.isConnected) paint();
    }).catch(() => { delete asking[k]; });
  }

  // ---- the larger look on hover/focus
  let peek = null;
  function showPeek(t) {
    const big = t.dataset.mkbig;
    if (!big) return;
    if (!peek) { peek = document.createElement("div"); peek.className = "mkpeek"; peek.setAttribute("aria-hidden", "true"); document.body.append(peek); }
    peek.innerHTML = `<img src="${esc(big)}" alt=""><div class="mkpk">${esc(t.dataset.mkname || "")}</div>`;
    const r = t.getBoundingClientRect(), place = () => {
      const w = peek.offsetWidth, h = peek.offsetHeight, below = r.bottom + 8 + h <= innerHeight;
      peek.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px";
      peek.style.top = (below ? r.bottom + 8 : Math.max(8, r.top - 8 - h)) + "px";
    };
    peek.querySelector("img").onload = place;
    place();
    peek.classList.add("on");
  }
  const hidePeek = () => peek?.classList.remove("on");
  document.addEventListener("pointerover", (e) => { const t = e.target.closest?.("[data-mkbig]"); if (t && e.pointerType === "mouse") showPeek(t); });
  document.addEventListener("pointerout", (e) => { const t = e.target.closest?.("[data-mkbig]"); if (t && !t.contains(e.relatedTarget)) hidePeek(); });
  document.addEventListener("focusin", (e) => { const t = e.target.closest?.("[data-mkbig]"); if (t && t.matches(":focus-visible")) showPeek(t); else hidePeek(); });
  document.addEventListener("focusout", hidePeek);
  addEventListener("scroll", hidePeek, true);
  addEventListener("hashchange", hidePeek);

  document.addEventListener("click", (e) => {
    // Only the strip's and the used card's own controls: other screens use data-mk* names too (project-new.js).
    const t = e.target.closest?.(".mkstrip [data-mkrp],.mkused [data-mkrp],.mkstrip [data-mkfold],.mkstrip [data-mkall]");
    if (!t || !last) return;
    if (t.dataset.mkfold !== undefined) {
      const key = vkey(last.it), on = !unfolded.has(key);
      on ? unfolded.add(key) : unfolded.delete(key);
      t.closest(".mkp").classList.toggle("open", on);
      t.setAttribute("aria-expanded", on); t.textContent = on ? tl("itemView.30") : tl("ui.more");
      return;
    }
    if (t.dataset.mkall !== undefined) { allIns.add(vkey(last.it)); last.box.querySelector(".mkstrip")?.remove(); paint(); return; }
    e.preventDefault(); hidePeek();
    const id = t.dataset.mkrp + "/" + t.dataset.mki, v = t.dataset.mkv;
    if (v === t.dataset.mkl) delete verPick[id]; else verPick[id] = v;
    if (detail?.[0] === "item" && detail[1] === id) again(); else nav("item/" + id);
  });
  // A phone turned sideways (or a window narrowed past the wide layout) moves the strip.
  matchMedia(WIDE_Q).addEventListener("change", () => { if (last?.box.isConnected) { last.box.querySelector(".mkstrip")?.remove(); paint(); } });

  // ---- the project page: the project's credits under its name
  const totals = {};
  function projectLine() {
    const ph = V()?.querySelector(".deptpage .pagehead .phtx");
    const name = detail?.[0] === "dept" ? detail[1] : null;
    if (!ph || !name || ph.querySelector(".mkproj")) return;
    const put = (t) => {
      if (!t || !(t.all > 0) || ph.querySelector(".mkproj") || !ph.isConnected) return;
      ph.insertAdjacentHTML("beforeend", `<div class="phs mkproj num">${tl("mk.cr", {n: fmt(t.all)})} · ${tl("mk.cr.month", {n: fmt(t.month)})}</div>`);
    };
    const c = totals[name];
    if (c && Date.now() - c.at < 30000) return put(c.data);
    get(`/api/make/totals?p=${encodeURIComponent(name)}`).then((data) => {
      if (!data?.on) return;
      totals[name] = {at: Date.now(), data};
      if (detail?.[0] === "dept" && detail[1] === name) put(data);
    }).catch(() => {});
  }
  const view = V();
  if (view) new MutationObserver(projectLine).observe(view, {childList: true});

  window.LoopMake = {strip, usedCard, crChip};
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(attach);
})();
