// Mermaid diagrams in a markdown answer: the chat, the result viewer and the floating window all
// get them, because markdown.js marks a finished ```mermaid block (div.mmd around its <pre>) and
// this file draws every one that lands on the page.
//   - The renderer is @mermaid-js/tiny (MIT, licenses/mermaid.md), vendored at
//     /vendor/mermaid.tiny.js and fetched the first time such a block is on the page, never before.
//   - What a session wrote is untrusted. Mermaid runs with securityLevel "strict" and plain SVG
//     text labels, and its SVG never becomes markup of this page: it is shown as an <img>, where
//     script, handlers and outside addresses do not run. In the chat that picture opens in the
//     app's own viewer like any other.
//   - Colours are read from the app's CSS variables, so a diagram follows the theme and the style,
//     and is drawn again when either changes.
// Uses v2.js globals: h, tl.
(() => {
  const root = document.documentElement;
  const drawn = new Map();    // look + source -> Promise of {url, w, h}, or of null when it cannot be drawn
  const asCode = new Set();   // sources the reader turned back to code: a repaint of the chat keeps that
  let lib = null, look = "", vars = null, set = "", seq = 0;

  const load = () => lib || (lib = new Promise((ok, no) => { const s = document.createElement("script"); s.src = "/vendor/mermaid.tiny.js";
    s.onload = () => ok(window.mermaid); s.onerror = no; document.head.appendChild(s); }));

  // The colours of the page as mermaid needs them: plain hex, whatever a variable is written as.
  // Each is painted on one canvas pixel over the page colour, so a see-through one comes out solid.
  function theme() {
    const probe = document.body.appendChild(h("i", {hidden: true})), cs = getComputedStyle(probe);
    const cv = document.createElement("canvas").getContext("2d", {willReadFrequently: true});
    const css = (v) => { probe.style.color = v; return cs.color; };
    const hex = (...layers) => {
      for (const [col, a] of layers) { cv.globalAlpha = a; cv.fillStyle = col; cv.fillRect(0, 0, 1, 1); }
      return "#" + [...cv.getImageData(0, 0, 1, 1).data].slice(0, 3).map((n) => n.toString(16).padStart(2, "0")).join("");
    };
    const bg = [css("var(--bg)"), 1], t1 = css("var(--t1)"), key = css("var(--key,var(--blue))");
    const c = {bg: hex(bg), text: hex(bg, [t1, 1]), soft: hex(bg, [css("var(--t2)"), 1]), line: hex(bg, [css("var(--t3)"), 1]), key: hex(bg, [key, 1]),
      fill: hex(bg, [key, .16], [t1, .04]), edge: hex(bg, [key, .7], [t1, .3]), group: hex(bg, [t1, .05]), rule: hex(bg, [t1, .18])};
    probe.remove();
    vars = {darkMode: parseInt(c.bg.slice(1, 3), 16) < 128, background: c.bg, fontFamily: "system-ui,sans-serif", fontSize: "14px",
      primaryColor: c.fill, primaryTextColor: c.text, primaryBorderColor: c.edge, secondaryColor: c.group, secondaryTextColor: c.text,
      secondaryBorderColor: c.rule, tertiaryColor: c.group, tertiaryTextColor: c.text, tertiaryBorderColor: c.rule,
      lineColor: c.line, textColor: c.text, mainBkg: c.fill, nodeBorder: c.edge, clusterBkg: c.group, clusterBorder: c.rule,
      titleColor: c.soft, edgeLabelBackground: c.bg, actorBkg: c.fill, actorBorder: c.edge, actorTextColor: c.text, actorLineColor: c.rule,
      signalColor: c.line, signalTextColor: c.text, labelBoxBkgColor: c.group, labelBoxBorderColor: c.rule, labelTextColor: c.text,
      loopTextColor: c.soft, noteBkgColor: c.group, noteTextColor: c.text, noteBorderColor: c.rule,
      activationBkgColor: c.fill, activationBorderColor: c.edge, sequenceNumberColor: c.bg, dropShadow: "none"};
    return Object.values(c).join();
  }

  // One diagram as a picture. A source mermaid cannot read, or cannot draw, comes back as null.
  function picture(src) {
    return load().then(async (m) => {
      if (set !== look) {
        m.initialize({startOnLoad: false, securityLevel: "strict", suppressErrorRendering: true, htmlLabels: false,
          flowchart: {htmlLabels: false}, look: "classic", theme: "base", themeVariables: vars, fontFamily: vars.fontFamily});
        set = look;
      }
      if (!(await m.parse(src, {suppressErrors: true}))) return null;
      const {svg} = await m.render(`mmd-${++seq}`, src);
      const el = new DOMParser().parseFromString(svg, "image/svg+xml").documentElement;
      const [w, ht] = el.getAttribute("viewBox").split(/\s+/).slice(2).map(Math.ceil);
      el.setAttribute("width", w); el.setAttribute("height", ht);
      el.setAttribute("style", `background:${vars.background}`);   // the viewer shows it on black
      return {url: URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(el)], {type: "image/svg+xml"})), w, h: ht};
    }).catch(() => null);
  }

  function view(box, v) {
    const src = box.querySelector("pre").textContent;
    if (v === "code") asCode.add(src); else asCode.delete(src);
    box.dataset.view = v;
    box.querySelectorAll(".mmd-tog button").forEach((b) => { const on = b.value === v; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  }

  // The code stays until the picture is ready; a block that cannot be drawn keeps it, with one line.
  function draw(box) {
    const pre = box.querySelector("pre"), src = pre.textContent, key = look + "\n" + src;
    box.dataset.look = look;
    if (!drawn.has(key)) drawn.set(key, picture(src));
    drawn.get(key).then((pic) => {
      if (!box.isConnected || box.dataset.look !== look || box.dataset.view) return;
      if (!pic) { box.dataset.view = "bad"; box.append(h("p", {class: "mmd-bad"}, tl("mmd.bad"))); return; }
      pre.before(h("div", {class: "mmd-fig"}, h("img", {class: "mmd-img", src: pic.url, width: pic.w, height: pic.h, style: `--w:${pic.w}px`, alt: tl("mmd.alt"), draggable: "false"})));
      box.prepend(h("div", {class: "mmd-tog", role: "group", "aria-label": tl("mmd.view")},
        h("button", {type: "button", class: "press", value: "fig", onclick: () => view(box, "fig")}, tl("mmd.fig")),
        h("button", {type: "button", class: "press", value: "code", onclick: () => view(box, "code")}, tl("mmd.code"))));
      view(box, asCode.has(src) ? "code" : "fig");
    });
  }

  function scan() {
    const todo = document.querySelectorAll(".mmd:not([data-look])");
    if (!todo.length) return;
    if (!look) look = theme();
    todo.forEach(draw);
  }
  new MutationObserver(scan).observe(document.body, {childList: true, subtree: true});
  scan();

  // Another theme, key colour or style: the diagrams on the page are drawn again in its colours.
  new MutationObserver(() => {
    if (!look || look === (look = theme())) return;
    document.querySelectorAll(".mmd[data-look]").forEach((box) => {
      box.querySelectorAll(".mmd-fig,.mmd-tog,.mmd-bad").forEach((n) => n.remove());
      delete box.dataset.view; delete box.dataset.look;
    });
    scan();
  }).observe(root, {attributes: true, attributeFilter: ["data-theme", "data-skin", "data-key", "style"]});
})();
