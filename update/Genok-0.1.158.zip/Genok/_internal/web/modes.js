// 사용 방식 presets, shared by the settings page (web/custom.js) and the first-run wizard
// (web/onboard.js), so a preset's name, what it is for and what it changes are written once.
//
//   window.LOOP_MODES - the preset table, the names and one-liners, how each knob reads in words,
//                       the card markup (a small diagram + name + one-liner) and the selection ring.
//   window.LOOP_MODE_PICKER(el, current, onPick, opts) - the wizard's picker: the cards, and under
//                       them what the picked preset changes, an example screen and the words it uses.
//     current - "auto" | "parallel" | "team" | "head" | "custom"
//     onPick  - called with the picked key
//     opts    - {custom: {base, n}}: also offer the 커스텀 card (only when one exists already)
//
// PRESETS is custom.py PRESETS verbatim (a Python test holds the two together). Like the other
// feature scripts it borrows v2.js's globals (tl, esc, ic, M, MENUS, RM) by name.
(function () {
  "use strict";

  const PRESETS = /*PRESETS*/{
   "auto": {"unit": "project", "names": {}, "lib_group": "unit", "role_card": false, "notify": "all", "start": "home", "inspector": "right", "menu_hide": ["routines", "retro", "search"], "menu_order": [], "starter": "auto"},
   "parallel": {"unit": "project", "names": {}, "lib_group": "session", "role_card": false, "notify": "all", "start": "mine", "inspector": "right", "menu_hide": ["routines", "retro", "search"], "menu_order": ["project"], "starter": "parallel"},
   "team": {"unit": "dept", "names": {}, "lib_group": "unit", "role_card": false, "notify": "all", "start": "home", "inspector": "right", "menu_hide": ["routines", "retro", "search"], "menu_order": ["depts"], "starter": "team"},
   "head": {"unit": "project", "names": {}, "lib_group": "role", "role_card": true, "notify": "main", "start": "home", "inspector": "right", "menu_hide": ["routines", "retro", "search"], "menu_order": ["lib"], "starter": "head"}
  }/*END*/;
  const KEYS = ["auto", "parallel", "team", "head"];
  const MENU_KEYS = () => (typeof MENUS !== "undefined" ? MENUS.map((m) => m.k)
    : ["home", "lib", "project", "depts", "routines", "retro", "search", "settings"]);

  const E = (s) => (typeof esc === "function" ? esc(s) : String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c])));

  // Every key is a literal tl() call, so the i18n test sees each one.
  const NAME = {auto: () => tl("modes.auto"), parallel: () => tl("modes.parallel"), team: () => tl("modes.team"),
    head: () => tl("modes.head"), custom: () => tl("modes.custom")};
  const GOOD = {auto: () => tl("modes.auto.good"), parallel: () => tl("modes.parallel.good"),
    team: () => tl("modes.team.good"), head: () => tl("modes.head.good"), custom: () => tl("modes.custom.good")};
  const WHAT = {auto: () => tl("modes.auto.what"), parallel: () => tl("modes.parallel.what"),
    team: () => tl("modes.team.what"), head: () => tl("modes.head.what")};
  const MORE = {auto: () => tl("modes.auto.more"), parallel: () => tl("modes.parallel.more"),
    team: () => tl("modes.team.more"), head: () => tl("modes.head.more")};
  const name = (k) => (NAME[k] || NAME.auto)();

  // ---- a knob in words ----------------------------------------------------------------------
  const unitWord = (p) => (p.names && p.names.unit) || tl("ui.projects");
  const LIB = {unit: (p) => tl("LIB_ORD.3", {u: unitWord(p)}), session: () => tl("LIB_ORD.4"),
    role: () => tl("LIB_ORD.5"), date: () => tl("LIB_ORD.1")};
  const libName = (p, v) => (LIB[v || p.lib_group] || LIB.unit)(p);
  const NOTIFY = {all: () => tl("mode.v.all"), main: () => tl("mode.v.main"), asks: () => tl("mode.v.asks")};
  const notifyName = (v) => (NOTIFY[v] || NOTIFY.all)();
  const START = {home: () => tl("custom.start.home"), mine: () => tl("custom.start.mine"), last: () => tl("custom.start.last")};
  const startName = (v) => (START[v] || START.home)();
  const menuName = (k, p) => (k === "depts" ? unitWord(p) : (typeof M === "function" && M(k) ? M(k).n : k));
  const fullOrder = (o) => (o || []).concat(MENU_KEYS().filter((k) => !(o || []).includes(k)));
  // Which menus a custom order moved: the ones outside the longest run still in natural order
  // (so dragging one row names that row, not every row it pushed along), each up or down.
  function moved(p) {
    const hid = p.menu_hide || [], nat = MENU_KEYS().filter((k) => !hid.includes(k));
    const eff = fullOrder(p.menu_order).filter((k) => nat.includes(k)), idx = eff.map((k) => nat.indexOf(k));
    const len = idx.map(() => 1), prev = idx.map(() => -1);
    for (let i = 0; i < idx.length; i++) for (let j = 0; j < i; j++) if (idx[j] < idx[i] && len[j] + 1 > len[i]) { len[i] = len[j] + 1; prev[i] = j; }
    let best = 0; for (let i = 1; i < idx.length; i++) if (len[i] > len[best]) best = i;
    const keep = new Set(); for (let i = idx.length ? best : -1; i >= 0; i = prev[i]) keep.add(eff[i]);
    return eff.filter((k) => !keep.has(k)).map((k) => [k, eff.indexOf(k) < nat.indexOf(k)]);
  }
  function menuSummary(p) {
    const mv = moved(p), up = mv.filter((m) => m[1]), down = mv.filter((m) => !m[1]);
    const names = (L) => L.map((m) => menuName(m[0], p)).join(", ");
    const out = [];
    if (up.length) out.push(tl("mode.menu.top", {n: names(up)}));
    if (down.length) out.push(tl("mode.menu.down", {n: names(down)}));
    if ((p.menu_hide || []).length) out.push(tl("mode.menu.hidden", {n: p.menu_hide.map((k) => menuName(k, p)).join(", ")}));
    return out.length ? out.join(" · ") : tl("mode.menu.plain");
  }
  const sameMenus = (a, b) => JSON.stringify([...(a.menu_hide || [])].sort()) === JSON.stringify([...(b.menu_hide || [])].sort())
    && fullOrder(a.menu_order).join() === fullOrder(b.menu_order).join();
  // The six things a preset sets that a person can feel, each with its value in words and whether
  // it differs from `ref` (기본, or the preset a 커스텀 set was made from).
  function rows(p, ref) {
    ref = ref || PRESETS.auto;
    const same = {
      unit: p.unit === ref.unit && unitWord(p) === unitWord(ref),
      lib_group: p.lib_group === ref.lib_group, role_card: p.role_card === ref.role_card,
      notify: p.notify === ref.notify, start: p.start === ref.start, menus: sameMenus(p, ref),
    };
    return [
      ["unit", tl("mode.k.unit"), unitWord(p)],
      ["lib_group", tl("mode.k.lib"), libName(p)],
      ["role_card", tl("mode.k.role"), p.role_card ? tl("mode.v.on") : tl("mode.v.off")],
      ["notify", tl("mode.k.notify"), notifyName(p.notify)],
      ["start", tl("custom.screen.start"), startName(p.start)],
      ["menus", tl("mode.k.menus"), menuSummary(p)],
    ].map(([k, label, value]) => ({k, label, value, diff: !same[k]}));
  }
  // The live knob values (web/custom.js), for describing a 커스텀 set; null before they load.
  function live() {
    if (typeof window.LOOP_PREF !== "function") return null;
    const o = {};
    for (const k of Object.keys(PRESETS.auto)) { const v = LOOP_PREF(k); if (v === undefined) return null; o[k] = v; }
    return o;
  }

  // ---- cards --------------------------------------------------------------------------------
  // Small diagrams, not screenshots: w1 = a quiet bar, w2 = the part that lights up when picked,
  // wk = a connecting line, wf = an app window's frame.
  const svg = (body) => `<svg viewBox="0 0 120 60" aria-hidden="true" focusable="false">${body}</svg>`;
  const WIRE = {
    // 기본: one project list beside the results.
    auto: svg(`<rect class="wf" x="1" y="1" width="118" height="58" rx="7"/><path class="wk" d="M36 2v56"/>
      <rect class="w2" x="8" y="10" width="21" height="5" rx="2.5"/><rect class="w1" x="8" y="20" width="16" height="5" rx="2.5"/><rect class="w1" x="8" y="30" width="19" height="5" rx="2.5"/>
      <rect class="w1" x="43" y="9" width="20" height="19" rx="3"/><rect class="w1" x="68" y="9" width="20" height="19" rx="3"/><rect class="w1" x="93" y="9" width="20" height="19" rx="3"/>
      <rect class="w1" x="43" y="33" width="20" height="19" rx="3"/><rect class="w1" x="68" y="33" width="20" height="19" rx="3"/><rect class="w1" x="93" y="33" width="20" height="19" rx="3"/>`),
    // 병렬 작업: one repo, several sessions on their own branch, each at its own pace.
    parallel: svg(`<path class="wk" d="M14 8v44M14 14h8M14 30h8M14 46h8"/>
      <circle class="w2" cx="14" cy="14" r="3.5"/><circle class="w2" cx="14" cy="30" r="3.5"/><circle class="w2" cx="14" cy="46" r="3.5"/>
      <rect class="w2" x="26" y="11" width="62" height="6" rx="3"/><rect class="w1" x="26" y="27" width="44" height="6" rx="3"/><rect class="w1" x="26" y="43" width="80" height="6" rx="3"/>`),
    // 부서: named sessions side by side, each with its own pile.
    team: svg(`<circle class="w2" cx="15" cy="11" r="5"/><rect class="w1" x="23" y="9" width="14" height="4" rx="2"/><rect class="w1" x="8" y="21" width="30" height="15" rx="3"/><rect class="w1" x="8" y="40" width="30" height="12" rx="3"/>
      <circle class="w2" cx="52" cy="11" r="5"/><rect class="w1" x="60" y="9" width="12" height="4" rx="2"/><rect class="w1" x="45" y="21" width="30" height="15" rx="3"/><rect class="w1" x="45" y="40" width="30" height="12" rx="3"/>
      <circle class="w2" cx="89" cy="11" r="5"/><rect class="w1" x="97" y="9" width="15" height="4" rx="2"/><rect class="w1" x="82" y="21" width="30" height="15" rx="3"/>`),
    // 메인 + 서브에이전트: one main session hands work down to three.
    head: svg(`<path class="wk" d="M60 20v7M22 27h76M22 27v8M60 27v8M98 27v8"/>
      <rect class="w2" x="43" y="6" width="34" height="14" rx="4"/>
      <rect class="w1" x="8" y="36" width="28" height="16" rx="4"/><rect class="w1" x="46" y="36" width="28" height="16" rx="4"/><rect class="w1" x="84" y="36" width="28" height="16" rx="4"/>`),
    // 커스텀: the same knobs, set by hand.
    custom: svg(`<path class="wk" d="M14 15h92M14 30h92M14 45h92"/>
      <circle class="w2" cx="42" cy="15" r="5"/><circle class="w2" cx="84" cy="30" r="5"/><circle class="w2" cx="60" cy="45" r="5"/>`),
  };
  // o: {sel, base (the preset a 커스텀 set came from), sub (replaces the one-liner)}
  function card(k, o) {
    o = o || {};
    const ok = typeof ic === "function" ? ic("check") : "";
    return `<button type="button" class="mw-card press${k === "custom" ? " mw-cust" : ""}${o.sel ? " on" : ""}${o.base ? " base" : ""}" role="radio" aria-checked="${!!o.sel}" data-pick="${k}">`
      + `<span class="mw-wire">${WIRE[k] || ""}</span>`
      + `<span class="mw-tx"><span class="mw-name">${E(name(k))}<span class="mw-ok" aria-hidden="true">${ok}</span></span>`
      + `<span class="mw-good">${E(o.sub || (GOOD[k] || GOOD.auto)())}</span></span></button>`;
  }

  // The ring that marks the picked card. It travels between cards on a critically damped spring
  // (response .34s) that can be retargeted mid-flight with its velocity kept, so a second pick
  // while it moves bends the path instead of restarting it. Reduced motion (or 차분한 모션): a
  // quiet fade out and back in at the new card, no travel.
  function ring(grid) {
    let el = grid.querySelector(".mw-ring");
    if (!el) { el = document.createElement("span"); el.className = "mw-ring"; el.setAttribute("aria-hidden", "true"); grid.appendChild(el); }
    grid.classList.add("ringed");
    const A = ["x", "y", "w", "h"], S = {x: 0, y: 0, w: 0, h: 0}, V = {x: 0, y: 0, w: 0, h: 0}, T = {x: 0, y: 0, w: 0, h: 0};
    const K = Math.pow(2 * Math.PI / 0.34, 2), C = 4 * Math.PI / 0.34;
    let raf = 0, last = 0, card = null, shown = false, fadeT = 0;
    const calm = () => (typeof RM === "function" ? RM() : matchMedia("(prefers-reduced-motion: reduce)").matches)
      || document.body.classList.contains("calm");
    const paint = () => { el.style.transform = `translate(${S.x}px,${S.y}px)`; el.style.width = S.w + "px"; el.style.height = S.h + "px"; };
    const measure = (c) => ({x: c.offsetLeft, y: c.offsetTop, w: c.offsetWidth, h: c.offsetHeight});
    const snap = () => { cancelAnimationFrame(raf); raf = 0; A.forEach((a) => { S[a] = T[a]; V[a] = 0; }); paint(); };
    function step(t) {
      if (!el.isConnected) { raf = 0; return; }
      const dt = Math.min(0.05, Math.max(0, (t - last) / 1000)) / 4; last = t;
      for (let i = 0; i < 4; i++) A.forEach((a) => { V[a] += (-K * (S[a] - T[a]) - C * V[a]) * dt; S[a] += V[a] * dt; });
      if (A.every((a) => Math.abs(S[a] - T[a]) < 0.25 && Math.abs(V[a]) < 2)) { A.forEach((a) => { S[a] = T[a]; V[a] = 0; }); raf = 0; }
      else raf = requestAnimationFrame(step);
      paint();
    }
    if (window.ResizeObserver) {
      // A new layout (the window resized, a fold opened) puts the ring straight on its card.
      const ro = new ResizeObserver(() => {
        if (!grid.isConnected) { ro.disconnect(); return; }
        if (card && card.isConnected) { Object.assign(T, measure(card)); snap(); }
      });
      ro.observe(grid);
    }
    return {
      to(c, now) {
        card = c;
        if (!c) { el.style.opacity = "0"; shown = false; return; }
        Object.assign(T, measure(c));
        clearTimeout(fadeT);
        if (now || !shown) { snap(); el.style.opacity = "1"; shown = true; return; }
        if (calm()) { el.style.opacity = "0"; fadeT = setTimeout(() => { snap(); el.style.opacity = "1"; }, 140); return; }
        el.style.opacity = "1";
        if (!raf) { last = performance.now(); raf = requestAnimationFrame(step); }
      },
    };
  }

  // ---- the detail under the wizard's cards ----------------------------------------------------
  const pile = (t) => `<div class="mw-mh">${t}</div>`;
  const row = (t, tag) => `<div class="mw-mr"><span>${t}</span><em>${tag}</em></div>`;
  const mock = (side, main) => `<div class="mw-mock" aria-hidden="true">${side ? `<div class="mw-ms">${side}</div>` : ""}<div class="mw-mm">${main}</div></div>`;
  // Sample names, not real data.
  const eg = (ko, en) => (LANG() === "en" ? en : ko);
  const EG = {
    auto: () => mock(`<b>${E(tl("ui.projects"))}</b><i class="on">${E(eg("브랜드 사이트", "Brand site"))}</i><i>${E(eg("앱 출시", "App launch"))}</i><i>${E(eg("여름 캠페인", "Summer campaign"))}</i>`,
      pile(eg("브랜드 사이트", "Brand site")) + row(eg("메인 배너", "Main banner"), "v2") + row(eg("상세 페이지", "Detail page"), "v1") + pile(eg("앱 출시", "App launch")) + row(eg("스토어 이미지", "Store image"), "v3")),
    parallel: () => mock(`<b>${E(tl("ui.projects"))}</b><i class="on">${E(eg("쇼핑몰", "Shop"))}</i><i>${E(eg("앱 출시", "App launch"))}</i>`,
      pile("worktrees/header") + row(eg("헤더 시안", "Header draft"), "v2") + row(eg("모바일 헤더", "Mobile header"), "v1") + pile("worktrees/pricing") + row(eg("가격표", "Price table"), "v3")),
    team: () => mock(`<b>${E(tl("ui.projects"))}</b><i class="on">${E(eg("영상팀", "Video team"))}</i><i>${E(eg("디자인팀", "Design team"))}</i><i>${E(eg("카피팀", "Copy team"))}</i>`,
      pile(eg("영상팀", "Video team")) + row(eg("숏폼 영상", "Short video"), "v2") + row(eg("오프닝 컷", "Opening cut"), "v1") + pile(eg("디자인팀", "Design team")) + row(eg("메인 배너", "Main banner"), "v3")),
    head: () => mock("", `<div class="mw-chips"><span class="on">${E(tl("mode.main"))} <em>2</em></span><span>${E(eg("표지 역할", "Cover role"))} <em>1</em></span><span>${E(eg("영상 역할", "Video role"))} <em>2</em></span></div>`
      + pile(eg("표지 역할", "Cover role")) + row(eg("메인 배너", "Main banner"), "v2") + pile(eg("영상 역할", "Video role")) + row(eg("숏폼 영상", "Short video"), "v1") + row(eg("오프닝 컷", "Opening cut"), "v1")),
  };
  function glossary() {
    const G = [[tl("modes.gl.session"), tl("modes.gl.session.d")], [tl("modes.gl.wt"), tl("modes.gl.wt.d")],
      [tl("modes.gl.dept"), tl("modes.gl.dept.d")], [tl("modes.gl.role"), tl("modes.gl.role.d")]];
    return `<div class="mw-gloss"><div class="mw-lab">${E(tl("modes.gloss"))}</div>`
      + G.map(([t, d]) => `<div class="mw-gl"><b>${E(t)}</b><span>${E(d)}</span></div>`).join("") + "</div>";
  }
  function detail(k, cust) {
    const isC = k === "custom" && cust;
    const p = isC ? (live() || PRESETS[cust.base]) : PRESETS[k] || PRESETS.auto;
    const ref = isC ? PRESETS[cust.base] : PRESETS.auto;
    const R = rows(p, ref), marks = k !== "auto" && R.some((r) => r.diff);
    return `<p class="mw-what">${isC ? E(tl("modes.custom.what", {m: name(cust.base)})) : more1(E((WHAT[k] || WHAT.auto)()), E((MORE[k] || MORE.auto)()))}</p>`
      + `<div class="mw-lab">${E(tl("mode.sec"))}</div>`
      + `<div class="mw-drows">${R.map((r) => `<div class="mw-drow${marks && r.diff ? " d" : ""}"><span class="mw-dk">${E(r.label)}</span><span class="mw-dv">${E(r.value)}</span></div>`).join("")}</div>`
      + (marks ? `<p class="mw-key">${E(isC ? tl("modes.diff.from", {m: name(cust.base)}) : tl("modes.diff"))}</p>` : "")
      + (EG[k] ? `<div class="mw-eg"><div class="mw-lab">${E(tl("modes.egtitle"))}</div>${EG[k]()}</div>` : "")
      + glossary();
  }

  const CSS = `
  .mw{container:mw/inline-size;--mw-card:var(--ob-panel,var(--card-hi));--mw-bg2:var(--ob-panel2,var(--bg));
    --mw-line:var(--ob-line,var(--line));--mw-line-hi:var(--ob-line-hi,var(--t4));--mw-t1:var(--ob-text,var(--t1));
    --mw-t3:var(--ob-dim,var(--t3));--mw-t2:color-mix(in srgb,var(--mw-t1) 70%,var(--mw-t3));--mw-accent:var(--ob-accent,var(--blue));
    --mw-accent-w:color-mix(in srgb,var(--mw-accent) 12%,transparent);--mw-on:var(--ob-bg,var(--on-blue));
    --mw-wire:color-mix(in srgb,var(--mw-t3) 42%,transparent);--mw-wire2:color-mix(in srgb,var(--mw-t3) 70%,transparent)}
  .mw-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;position:relative}
  .mw-grid .mw-cust{grid-column:1/-1}
  @container mw (min-width:560px){.mw-grid.n5{grid-template-columns:repeat(3,minmax(0,1fr))}.mw-grid.n5 .mw-cust{grid-column:span 2}}
  @container mw (min-width:660px){.mw-grid.n4{grid-template-columns:repeat(4,minmax(0,1fr))}}
  .mw-card{position:relative;display:flex;flex-direction:column;gap:8px;min-width:0;padding:8px 12px 12px;text-align:left;
    font:inherit;color:var(--mw-t1);background:var(--mw-card);border:1.5px solid var(--mw-line);border-radius:12px;cursor:pointer;
    transition:border-color .2s,background-color .2s,transform .18s var(--ease,ease)}
  .mw-card:hover{border-color:var(--mw-line-hi)}
  .mw-card.press:active{transform:scale(.985)}
  .mw-card:focus-visible{outline:2px solid var(--mw-accent);outline-offset:2px}
  .mw-card.on{border-color:var(--mw-accent);background:var(--mw-accent-w)}
  .mw-grid.ringed .mw-card.on{border-color:transparent}
  .mw-card.base{border-style:dashed;border-color:var(--mw-line-hi)}
  .mw-wire{display:grid;place-items:center;height:64px;border-radius:8px;background:var(--mw-bg2);overflow:hidden}
  .mw-wire svg{height:52px;width:auto;max-width:100%;display:block}
  .mw-wire .wf{fill:var(--mw-card);stroke:var(--mw-line-hi);stroke-width:1}
  .mw-wire .w1{fill:var(--mw-wire)}
  .mw-wire .w2{fill:var(--mw-wire2);transition:fill .25s}
  .mw-wire .wk{fill:none;stroke:var(--mw-wire2);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}
  .mw-card.on .w2{fill:var(--mw-accent)}
  .mw-tx{display:flex;flex-direction:column;gap:4px;min-width:0}
  .mw-name{display:flex;align-items:center;gap:6px;font-size:15px;font-weight:600;letter-spacing:-.01em;line-height:1.3}
  .mw-ok{margin-left:auto;flex:none;width:20px;height:20px;border-radius:50%;display:grid;place-items:center;background:var(--mw-accent);
    color:var(--mw-on);opacity:0;transform:scale(.4);transition:opacity .15s,transform .5s linear(0,.02,.09 3.2%,.32 7.4%,.72 13.6%,.94 18.2%,1.04 22.6%,1.06 26.5%,1.04 31.6%,1.01 38.5%,.995 48%,1)}
  .mw-ok svg{width:12px;height:12px;stroke-width:3.4}
  .mw-card.on .mw-ok{opacity:1;transform:none}
  .mw-good{font-size:12px;line-height:1.45;color:var(--mw-t3)}
  .mw-cust{flex-direction:row;align-items:center;gap:12px}
  .mw-cust .mw-wire{flex:none;width:88px;height:56px}
  .mw-cust .mw-wire svg{height:44px}
  .mw-cust .mw-tx{flex:1}
  .mw-ring{position:absolute;left:0;top:0;z-index:1;box-sizing:border-box;border:2px solid var(--mw-accent);border-radius:12px;
    pointer-events:none;opacity:0;transition:opacity .16s;will-change:transform}
  .mw-detail{margin-top:12px;padding:16px 16px;background:var(--mw-card);border:1px solid var(--mw-line);border-radius:12px}
  .mw-what{margin:0 0 16px;font-size:13px;line-height:1.6;color:var(--mw-t1)}
  .mw-lab{margin:0 0 8px;font-size:12px;font-weight:700;letter-spacing:.07em;color:var(--mw-t3)}
  .mw-drows{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 16px}
  @container mw (max-width:480px){.mw-drows{grid-template-columns:minmax(0,1fr)}}
  .mw-drow{display:flex;gap:8px;align-items:baseline;min-width:0;font-size:13px;line-height:1.45}
  .mw-dk{position:relative;flex:none;width:86px;padding-left:12px;font-size:12px;color:var(--mw-t3)}
  .mw-dv{min-width:0;color:var(--mw-t2)}
  .mw-drow.d .mw-dv{color:var(--mw-t1);font-weight:600}
  .mw-drow.d .mw-dk::before{content:"";position:absolute;left:0;top:.5em;width:5px;height:5px;border-radius:50%;background:var(--mw-accent)}
  .mw-key{margin:8px 0 0 12px;font-size:12px;color:var(--mw-t3)}
  .mw-eg,.mw-gloss{margin-top:16px;padding-top:12px;border-top:1px solid var(--mw-line)}
  .mw-mock{display:flex;border:1px solid var(--mw-line);border-radius:8px;overflow:hidden;background:var(--mw-bg2);font-size:11.5px;line-height:1.3}
  .mw-ms{width:34%;min-width:0;padding:8px 6px;border-right:1px solid var(--mw-line);display:flex;flex-direction:column;gap:2px}
  .mw-ms b{padding:2px 8px 4px;font-size:10px;font-weight:700;letter-spacing:.06em;color:var(--mw-t3)}
  .mw-ms i{display:block;padding:4px 8px;border-radius:6px;font-style:normal;color:var(--mw-t3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .mw-ms i.on{background:var(--mw-line);color:var(--mw-t1)}
  .mw-mm{flex:1;min-width:0;padding:8px 12px;display:flex;flex-direction:column;gap:4px}
  .mw-mh{margin:4px 0 1px;font-size:10.5px;font-weight:600;color:var(--mw-t3)}
  .mw-mh:first-child{margin-top:0}
  .mw-mr{display:flex;align-items:center;gap:8px;min-width:0;padding:4px 6px;border-radius:6px;background:var(--mw-card)}
  .mw-mr::before{content:"";flex:none;width:18px;height:12px;border-radius:2px;background:var(--mw-wire)}
  .mw-mr span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--mw-t1)}
  .mw-mr em{flex:none;font-style:normal;font-size:10.5px;color:var(--mw-t3)}
  .mw-chips{display:flex;flex-wrap:wrap;gap:4px;margin:0 0 6px}
  .mw-chips span{padding:4px 8px;border-radius:99px;border:1px solid var(--mw-line);color:var(--mw-t2);white-space:nowrap}
  .mw-chips span.on{border-color:var(--mw-accent);color:var(--mw-t1)}
  .mw-chips em{font-style:normal;color:var(--mw-t3);margin-left:2px}
  .mw-gloss{display:grid;gap:6px}
  .mw-gloss .mw-lab{margin:0 0 2px}
  .mw-gl{display:flex;gap:8px;font-size:12px;line-height:1.5;color:var(--mw-t3)}
  .mw-gl b{flex:none;width:56px;font-weight:600;color:var(--mw-t1)}
  @media (prefers-reduced-motion:reduce){.mw-card,.mw-wire .w2{transition:border-color .2s,background-color .2s}
    .mw-card.press:active{transform:none}.mw-ok{transform:none;transition:opacity .2s}}
  `;
  function injectCSS() {
    if (document.getElementById("mw-css")) return;
    const s = document.createElement("style");
    s.id = "mw-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }

  window.LOOP_MODES = {keys: KEYS, presets: PRESETS, name, what: (k) => (WHAT[k] || WHAT.auto)(), card, ring, rows,
    glossary, unitWord, libName, notifyName, startName, menuName, menuSummary, fullOrder, css: injectCSS};

  window.LOOP_MODE_PICKER = function (el, current, onPick, opts) {
    if (!el) return;
    injectCSS();
    const cust = opts && opts.custom && PRESETS[opts.custom.base] ? opts.custom : null;
    const keys = cust ? KEYS.concat("custom") : KEYS;
    let sel = keys.includes(current) ? current : "auto";
    el.innerHTML = `<div class="mw"><div class="mw-grid ${cust ? "n5" : "n4"}" role="radiogroup" aria-label="${E(tl("custom.mode.title"))}">`
      + keys.map((k) => card(k, {sel: k === sel, base: !!cust && k === cust.base,
        sub: k === "custom" ? tl("modes.custom.from", {m: name(cust.base), n: cust.n}) : ""})).join("")
      + `</div><div class="mw-detail"></div></div>`;
    const grid = el.querySelector(".mw-grid"), box = el.querySelector(".mw-detail"), R = ring(grid);
    const paint = (first) => {
      grid.querySelectorAll("[data-pick]").forEach((b) => { const on = b.dataset.pick === sel; b.classList.toggle("on", on); b.setAttribute("aria-checked", on); });
      R.to(grid.querySelector(".mw-card.on"), first);
      box.innerHTML = detail(sel, cust);
      if (!first && box.animate) box.animate([{opacity: 0.35}, {opacity: 1}], {duration: 200, easing: "ease-out"});
    };
    grid.addEventListener("click", (e) => {
      const b = e.target.closest("[data-pick]");
      if (!b || b.dataset.pick === sel) return;
      sel = b.dataset.pick; paint(false);
      if (typeof onPick === "function") try { onPick(sel); } catch (er) { /* the caller's problem */ }
    });
    paint(true);
    return {get: () => sel};
  };
})();
