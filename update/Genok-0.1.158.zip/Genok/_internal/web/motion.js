// Motion: small animated icons and micro-interactions for the moments people repeat every day
// (approve, copy, send, finish, undo, favourite, empty lists). Nothing here is drawn from scratch:
//   - icon shapes: Phosphor Icons, regular weight (MIT) - the app's one icon set (ic() in v2.js)
//   - icon motion: lucide-animated by pqoqubbw (MIT) - https://github.com/pqoqubbw/icons, recipes
//     ported from its motion/react variants to CSS keyframes
//   - empty-state art: Microsoft Fluent Emoji, flat style (MIT) - https://github.com/microsoft/fluentui-emoji
//   - "in flight" text sheen: Magic UI Animated Shiny Text (MIT) - https://github.com/magicuidesign/magicui
//   - finish burst: canvas-confetti by Kiril Vatev (ISC), vendored at /motion/confetti.js, loaded on first use
//   - in-flight orb: thinking-orbs from Libraries.dev (MIT), already shipped as <rl-orb>
//   - gooey tab indicator: the merge-by-blur idea of Libraries.dev Gooey (MIT), a small SVG goo filter here
//   - Pro button sheen: a canvas rendition of the Libraries.dev Liquid Metal look (MIT; its material is
//     Paper Shaders liquidMetal, Apache-2.0). Not WebGL: a tiny software canvas, see metal() below.
// Licences: licenses/phosphor.md, lucide-animated.md, fluent-emoji.md, magicui.md, canvas-confetti.md,
// libraries-dev.md, liquid-metal.md.
//
// One table, MOMENTS, maps each UI moment to the asset it shows, so a different choice is a
// one-line change. Spring curves are computed (damping ratio + response, Apple's two knobs) and
// handed to CSS as linear() easings, so keyframes and transitions both move on real springs.
// prefers-reduced-motion: CSS swaps every flourish for a short fade; JS skips transforms.
(function () {
  "use strict";
  const RM = () => { try { return matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; } };

  // ---- springs -------------------------------------------------------------------------
  // Position of a unit step response for damping ratio z and response r (seconds).
  function springAt(z, r, t) {
    const w = 2 * Math.PI / r;
    if (z >= 1) return 1 - Math.exp(-w * t) * (1 + w * t);
    const wd = w * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t));
  }
  // linear() easing + settle time. Settled = within 0.1% for 60ms straight (capped at 1.6s).
  function spring(z, r) {
    let t = 0, calm = 0; const dt = 1 / 240;
    while (t < 1.6) { t += dt; calm = Math.abs(1 - springAt(z, r, t)) < 0.001 ? calm + dt : 0; if (calm >= 0.06) break; }
    const n = 40, pts = [];
    for (let i = 0; i <= n; i++) pts.push(i === n ? "1" : (+springAt(z, r, (t * i) / n).toFixed(4)).toString());
    return {ease: `linear(${pts.join(",")})`, ms: Math.round(t * 1000)};
  }
  const SPRINGS = {snap: spring(1, 0.32), soft: spring(0.82, 0.4), pop: spring(0.55, 0.42)};
  try {
    const s = document.documentElement.style;
    for (const k in SPRINGS) { s.setProperty(`--m-${k}`, SPRINGS[k].ease); s.setProperty(`--m-${k}-d`, SPRINGS[k].ms + "ms"); }
  } catch (e) {}

  // ---- a spring that is stepped, not timed (stiffness k, damping c) ---------------------------
  // For what a hand can catch mid-way: set() only moves the target, so position and velocity carry
  // over and a motion turns round from where it is. One rAF loop steps every live spring.
  // Reduced motion: set() lands at once (the caller adds the fade).
  const physLive = new Set(); let physRaf = 0, physLast = 0;
  function physFrame(t) {
    const dt = Math.min(0.032, Math.max(0.001, (t - physLast) / 1000)); physLast = t;
    physLive.forEach((s) => { if (!s.step(dt)) { physLive.delete(s); if (s.rest) s.rest(); } });
    physRaf = physLive.size ? requestAnimationFrame(physFrame) : 0;
  }
  function phys(x, k, c, on, eps = 0.001) {
    const s = {x, v: 0, to: x, k, c, rest: null,
      step(dt) {
        for (let n = Math.ceil(dt / 0.004), h = dt / n; n > 0; n--) { s.v += (-s.k * (s.x - s.to) - s.c * s.v) * h; s.x += s.v * h; }
        const done = Math.abs(s.v) < eps * 20 && Math.abs(s.x - s.to) < eps;
        if (done) { s.x = s.to; s.v = 0; }
        on(s.x); return !done;
      },
      live: () => physLive.has(s),
      set(to, v) {
        s.to = to;
        if (RM()) return s.jump(to);
        if (v != null) s.v = v;
        physLive.add(s); if (!physRaf) { physLast = performance.now(); physRaf = requestAnimationFrame(physFrame); }
      },
      jump(to) { s.x = s.to = to; s.v = 0; physLive.delete(s); on(to); }};
    return s;
  }
  const fadeIn = (el, from = 0.4) => { try { el.animate([{opacity: from}, {opacity: 1}], {duration: 200, easing: "ease-out"}); } catch (e) {} };

  // ---- a spring stepped frame by frame (for things a finger moves) -------------------------
  // The linear() springs above start at rest and run to the end. A panel that is dragged, let go,
  // caught again and sent back needs the same model (damping ratio z, response r) run from wherever
  // it is, at whatever speed it has. drive() does that: step(x) every frame, done() once settled,
  // stop() hands back the position and velocity it had so the next drive() can carry on from there.
  function drive(o) {
    const w = 2 * Math.PI / (o.r || 0.36), z = o.z == null ? 1 : o.z, eps = o.eps || 0.0005;
    let x = o.from, v = o.v || 0, raf = 0, last = 0;
    const tick = (ts) => {
      let dt = Math.min(0.064, last ? (ts - last) / 1000 : 1 / 60); last = ts;
      for (; dt > 1e-6; dt -= 0.002) { const h = Math.min(0.002, dt); v += (-w * w * (x - o.to) - 2 * z * w * v) * h; x += v * h; }
      if (Math.abs(x - o.to) < eps && Math.abs(v) < eps * 20) { raf = 0; x = o.to; v = 0; o.step(x); if (o.done) o.done(); return; }
      o.step(x); raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return {stop() { cancelAnimationFrame(raf); raf = 0; return {x, v}; }};
  }
  // Where a flick would coast to (scroll deceleration): distance travelled from velocity v in px/s.
  const project = (v, d = 0.998) => (v / 1000) * d / (1 - d);

  // ---- icons (Phosphor regular, the same set as ic() in v2.js) --------------------------------
  // The app's icon table holds each glyph as one filled outline, which cannot be drawn in or moved
  // part by part. These are the same Phosphor regular icons in their stroked source form (256 grid,
  // stroke 16), split into the parts the motion classes move. Icon name after each line.
  const ICONS = {
    circleCheck: '<circle class="mp-ring" cx="128" cy="128" r="96" pathLength="1"/><polyline class="mp-draw" points="88 136 112 160 168 104" pathLength="1"/>',   // check-circle
    check: '<polyline class="mp-draw" points="40 144 96 200 224 72" pathLength="1"/>',   // check
    // copy, plus the check glyph scaled onto the front sheet (stroke 40 x .4 = 16)
    copy: '<rect class="mp-front" x="40" y="88" width="128" height="128"/><polyline class="mp-back" points="168 168 216 168 216 40 88 40 88 88"/><polyline class="mp-draw" points="40 144 96 200 224 72" pathLength="1" transform="translate(51 97) scale(.4)" stroke-width="40"/>',
    send: '<g class="mp-plane"><path d="M223.69,42.18a8,8,0,0,0-9.87-9.87l-192,58.22a8,8,0,0,0-1.25,14.93L108,148l42.54,87.42a8,8,0,0,0,14.93-1.25Z"/><line x1="108" y1="148" x2="160" y2="96"/></g>',   // paper-plane-tilt
    undo: '<g class="mp-swing"><polyline points="24 56 24 104 72 104"/><path d="M67.59,192A88,88,0,1,0,65.77,65.77L24,104"/></g>',   // arrow-counter-clockwise
    archive: '<rect class="mp-lid" x="24" y="56" width="208" height="40" rx="8"/><path d="M216,96v96a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V96"/><line class="mp-draw" x1="104" y1="136" x2="152" y2="136" pathLength="1"/>',   // archive
    x: '<line class="mp-draw" x1="200" y1="56" x2="56" y2="200" pathLength="1"/><line class="mp-draw mp-late" x1="56" y1="56" x2="200" y2="200" pathLength="1"/>',   // x
    bell: '<g class="mp-ring-bell"><path d="M56,104a72,72,0,0,1,144,0c0,35.82,8.3,64.6,14.9,76A8,8,0,0,1,208,192H48a8,8,0,0,1-6.88-12C47.71,168.6,56,139.81,56,104Z"/><path d="M96,192a32,32,0,0,0,64,0"/></g>',   // bell
    refresh: '<g class="mp-spin"><polyline points="168 96 216 96 216 48"/><path d="M216,96,187.72,67.72A88,88,0,0,0,64,67"/><polyline points="88 160 40 160 40 208"/><path d="M40,160l28.28,28.28A88,88,0,0,0,192,189"/></g>',   // arrows-clockwise
    star: '<path class="mp-pop" d="M128,189.09l54.72,33.65a8.4,8.4,0,0,0,12.52-9.17l-14.88-62.79,48.7-42A8.46,8.46,0,0,0,224.27,94L160.36,88.8,135.74,29.2a8.36,8.36,0,0,0-15.48,0L95.64,88.8,31.73,94a8.46,8.46,0,0,0-4.79,14.83l48.7,42L60.76,213.57a8.4,8.4,0,0,0,12.52,9.17Z"/>',   // star
    message: '<path class="mp-wobble" d="M79.93,211.11a96,96,0,1,0-35-35h0L32.42,213.46a8,8,0,0,0,10.12,10.12l37.39-12.47Z"/>',   // chat-circle
    link: '<g class="mp-tug"><path d="M141.38,64.68l11-11a46.62,46.62,0,0,1,65.94,0h0a46.62,46.62,0,0,1,0,65.94L193.94,144,183.6,154.34a46.63,46.63,0,0,1-66-.05h0A46.48,46.48,0,0,1,104,120.06"/><path d="M114.62,191.32l-11,11a46.63,46.63,0,0,1-66-.05h0a46.63,46.63,0,0,1,.06-65.89L72.4,101.66a46.62,46.62,0,0,1,65.94,0h0A46.45,46.45,0,0,1,152,135.94"/></g>',   // link
    upload: '<polyline points="216 144 216 208 40 208 40 144"/><g class="mp-lift"><polyline points="88 72 128 32 168 72"/><line x1="128" y1="144" x2="128" y2="32"/></g>',   // upload-simple
    eye: '<path class="mp-blink" d="M128,56C48,56,16,128,16,128s32,72,112,72,112-72,112-72S208,56,128,56Z"/><circle class="mp-blink" cx="128" cy="128" r="40"/>',   // eye
    search: '<circle class="mp-draw" cx="112" cy="112" r="80" pathLength="1"/><line class="mp-draw mp-late" x1="168.57" y1="168.57" x2="224" y2="224" pathLength="1"/>',   // magnifying-glass
    inbox: '<path class="mp-draw mp-late" d="M40,160H76.69a8,8,0,0,1,5.65,2.34l19.32,19.32a8,8,0,0,0,5.65,2.34h41.38a8,8,0,0,0,5.65-2.34l19.32-19.32a8,8,0,0,1,5.65-2.34H216" pathLength="1"/><rect class="mp-draw" x="40" y="40" width="176" height="176" rx="8" pathLength="1"/>',   // tray
  };
  // Fluent Emoji (flat) files under /motion/.
  const EMOJI = {inbox: "inbox_tray", search: "magnifying_glass_tilted_left", done: "sparkles", party: "party_popper",
    check: "check_mark_button", letter: "envelope_with_arrow", bell: "bell", wait: "hourglass_done", sleep: "sleeping_face",
    star: "glowing_star", mail: "open_mailbox_with_raised_flag", rocket: "rocket", files: "card_file_box", calendar: "spiral_calendar"};

  // ---- the one table: which asset each moment shows ----------------------------------------
  // "icon:<name>" (+ ":tone"), "emoji:<name>", "orb:<state>", "" = no icon.
  const MOMENTS = {
    approve: "icon:circleCheck:ok", confirm: "icon:check:ok", copied: "icon:copy:ok", failed: "icon:x:bad",
    sending: "orb:connecting", delivered: "icon:check", later: "icon:message", resent: "icon:refresh",
    undo: "icon:undo", finish: "icon:archive:ok", fav: "icon:star:fav", unfav: "icon:star", synced: "icon:refresh",
    alert: "icon:bell", snooze: "icon:bell", restore: "icon:undo", link: "icon:link", archive: "icon:archive",
    // Empty screens: line icons drawn in once ("emoji:<name>" brings the Fluent art back).
    emptyInbox: "icon:inbox:empty", emptySearch: "icon:search:empty", emptyDone: "icon:circleCheck:empty",
    // Live buttons, not toasts: "pop", "rays", both ("pop+rays") or "" for none.
    favOn: "pop", tabOn: "pop",
    // Phone tab bar: "goo" = a blob that slides and stretches to the chosen tab, "" = none.
    tabGoo: "off",
    // Pro buttons (.m-metal): "metal" = Liquid Metal sheen, "" = plain buttons.
    proBtn: "metal",
    // Per-session avatar: "orb" = orbit-sphere derived from the session id, "" = none.
    avatar: "orb",
  };
  // Extra flourish after a moment's icon (finish = small token-tinted confetti burst).
  const AFTER = {finish: "confetti"};
  // Text treatment while the moment is still in flight (Magic UI shiny text).
  const TEXT = {sending: "m-shiny"};

  function svg(name, tone) {
    const inner = ICONS[name]; if (!inner) return "";
    return `<svg class="mi mi-${name}${tone ? " mt-" + tone : ""}" viewBox="0 0 256 256" aria-hidden="true">${inner}</svg>`;
  }
  function emoji(name, cls) {
    const f = EMOJI[name]; if (!f) return "";
    const src = typeof window.MOTION_SRC === "function" ? window.MOTION_SRC(f) : `/motion/${f}.svg`;   // a standalone preview inlines them
    return `<img class="me${cls ? " " + cls : ""}" src="${src}" alt="" aria-hidden="true" draggable="false">`;
  }
  function render(spec) {
    const [kind, name, tone] = String(spec || "").split(":");
    if (kind === "icon") return svg(name, tone);
    if (kind === "emoji") return emoji(name);
    if (kind === "orb") return `<rl-orb state="${name || "working"}" size="20" aria-label=""></rl-orb>`;
    return "";
  }
  // Markup for a moment (or a bare "icon:..." spec). Empty string when the moment has none.
  function tip(moment) { return render(MOMENTS[moment] != null ? MOMENTS[moment] : moment); }
  function after(moment, el) { if (AFTER[moment] === "confetti") burst(el); }

  // Empty-state art: an emoji that settles in, above the existing message.
  function empty(moment) { const m = MOMENTS[moment] || ""; return m ? `<div class="m-empty">${render(m)}</div>` : ""; }

  // ---- WAAPI pop on a live element (interruptible: a new one cancels the old) ---------------
  function pop(el, from = 0.82) {
    if (!el || !el.animate) return;
    try { el.getAnimations().forEach((a) => a.id === "m-pop" && a.cancel()); } catch (e) {}
    if (RM()) { const a = el.animate([{opacity: 0.4}, {opacity: 1}], {duration: 180, easing: "ease-out"}); a.id = "m-pop"; return; }
    const a = el.animate([{transform: `scale(${from})`}, {transform: "scale(1)"}], {duration: SPRINGS.pop.ms, easing: SPRINGS.pop.ease});
    a.id = "m-pop";
  }
  // Short rays around a button that just switched on (the "like" burst).
  function rays(host) {
    if (!host || RM()) return;
    const r = document.createElement("span"); r.className = "m-rays"; r.setAttribute("aria-hidden", "true");
    r.innerHTML = '<svg viewBox="0 0 40 40">' + [0, 60, 120, 180, 240, 300].map((d) =>
      `<g transform="rotate(${d} 20 20)"><line x1="20" y1="6" x2="20" y2="2"/></g>`).join("") + "</svg>";
    host.appendChild(r); setTimeout(() => r.remove(), 700);
  }

  // ---- confetti (canvas-confetti, loaded once on first use) ---------------------------------
  let confettiP = null;
  function loadConfetti() {
    if (window.confetti) return Promise.resolve(window.confetti);
    if (!confettiP) confettiP = new Promise((ok, no) => { const s = document.createElement("script"); s.src = "/motion/confetti.js";
      s.onload = () => ok(window.confetti); s.onerror = no; document.head.appendChild(s); });
    return confettiP;
  }
  // One 2D canvas, gone when the particles settle; never started for a hidden tab.
  function burst(el) {
    if (RM() || document.hidden) return;
    const r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    const x = r ? (r.left + r.width / 2) / innerWidth : 0.5, y = r ? (r.top + r.height / 2) / innerHeight : 0.8;
    loadConfetti().then((c) => c && c({particleCount: 36, spread: 64, startVelocity: 22, gravity: 0.9, ticks: 110, scalar: 0.7,
      origin: {x, y}, colors: ["#5e6ad2", "#8f98ff", "#1fc67a", "#ececef"], disableForReducedMotion: true, zIndex: 10000})).catch(() => {});
  }

  // After a click re-renders, find the new node by its data key on the next frame.
  function later(fn) { requestAnimationFrame(() => requestAnimationFrame(fn)); }

  // ---- gooey tab indicator (phone tab bar) -------------------------------------------------
  // Two blobs share one SVG goo filter (blur, then a hard alpha curve) so they fuse while they travel.
  // The head springs fast, the tail slow, so the blob stretches toward the new tab and then settles.
  // The layer lives outside #tabbar on purpose: setHTML() compares #tabbar's children, and a foreign
  // child would force a full re-render on every draw.
  function ensureGoo() {
    let L = document.getElementById("m-goo"); if (L) return L;
    const f = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    f.setAttribute("width", "0"); f.setAttribute("height", "0"); f.setAttribute("aria-hidden", "true"); f.style.position = "absolute";
    f.innerHTML = '<defs><filter id="m-goo-f" color-interpolation-filters="sRGB"><feGaussianBlur in="SourceGraphic" stdDeviation="5"/>'
      + '<feColorMatrix values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7"/></filter></defs>';
    document.body.appendChild(f);
    L = document.createElement("div"); L.id = "m-goo"; L.setAttribute("aria-hidden", "true");
    L.innerHTML = '<i class="mg-t"></i><i class="mg-h"></i>'; document.body.appendChild(L); return L;
  }
  const GOO = {head: spring(0.72, 0.3), tail: spring(0.86, 0.52)};
  let gooAt = "";
  // Move a blob to (x,y) from wherever it is right now (so a tap mid-flight redirects it, not restarts it).
  function slide(el, x, y, sp) {
    let fx = x, fy = y;
    try { const cs = getComputedStyle(el).transform; if (cs && cs !== "none") { const m = new DOMMatrix(cs); fx = m.m41; fy = m.m42; } } catch (e) {}
    el.getAnimations().forEach((a) => a.cancel());
    el.style.transform = `translate(${x}px,${y}px)`;
    if (RM() || (Math.abs(fx - x) < 0.5 && Math.abs(fy - y) < 0.5)) return;
    el.animate([{transform: `translate(${fx}px,${fy}px)`}, {transform: `translate(${x}px,${y}px)`}], {duration: sp.ms, easing: sp.ease});
  }
  function goo() {
    if ((MOMENTS.tabGoo || "") !== "goo") return;
    const bar = document.getElementById("tabbar"); if (!bar) return;
    const L = ensureGoo(), on = bar.querySelector("button.on"), ico = on && on.querySelector("svg"), br = bar.getBoundingClientRect();
    if (!ico || !br.width || !br.height) { L.style.display = "none"; gooAt = ""; return; }
    const r = ico.getBoundingClientRect(), x = r.left - br.left + r.width / 2, y = r.top - br.top + r.height / 2;
    const first = L.style.display === "none" || !gooAt, key = on.dataset.go || "";
    L.style.cssText = `left:${br.left}px;top:${br.top}px;width:${br.width}px;height:${br.height}px`;
    const h = L.querySelector(".mg-h"), t = L.querySelector(".mg-t");
    if (first || gooAt === key) [h, t].forEach((e) => { e.getAnimations().forEach((a) => a.cancel()); e.style.transform = `translate(${x}px,${y}px)`; });
    else { slide(h, x, y, GOO.head); slide(t, x, y, GOO.tail); }
    gooAt = key;
  }
  function watchGoo() {
    const bar = document.getElementById("tabbar"); if (!bar || !window.MutationObserver) return;
    new MutationObserver(() => later(goo)).observe(bar, {childList: true, subtree: true});
    addEventListener("resize", () => later(goo)); later(goo);
  }
  watchGoo();

  // ---- Pro buttons: Liquid Metal sheen on a tiny canvas ------------------------------------
  // A port of the look of Libraries.dev Liquid Metal (Paper Shaders "liquidMetal": flowing chrome
  // stripes, noise-warped, red/blue dispersion at the stripe edges, a lit rim). The original is a
  // WebGL2 shader; here the same recipe runs per pixel on a canvas a third of the button's size,
  // ~24 fps, only while the button is on screen and the tab is visible. Reduced motion: one still frame.
  const METAL = new Map();            // host element -> {cv, cx, w, h, vis}
  let metalRaf = 0, metalLast = 0, metalT0 = 0;
  const sstep = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  function metalDraw(m, t) {
    const {cx, w, h, img} = m, d = img.data, asp = w / h;
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const u = (i + 0.5) / w * asp, v = (j + 0.5) / h;
      const warp = Math.sin(u * 3.1 + t * 0.55) * Math.cos(v * 4.3 - t * 0.4) + 0.5 * Math.sin(u * 7.3 - v * 5.1 + t * 0.9);
      const s = (u * 0.8 + v * 0.5) * 2.4 + warp * 0.55 + t * 0.12;
      // rim: distance to the nearest edge, lit toward the border (the shader's "contour")
      const e = Math.min(i + 0.5, j + 0.5, w - i - 0.5, h - j - 0.5) / h, rim = 1 - sstep(0, 0.28, e), o = (j * w + i) * 4;
      for (let c = 0; c < 3; c++) {
        const k = 0.5 + 0.5 * Math.sin(6.2832 * (s + (c === 0 ? 0.035 : c === 2 ? -0.035 : 0)));
        // silver range, so dark button text stays readable on every stripe
        d[o + c] = Math.min(255, (0.62 + 0.34 * sstep(0.25, 0.75, k) + 0.1 * rim) * (c === 2 ? 255 : 250));
      }
      d[o + 3] = 255;
    }
    cx.putImageData(img, 0, 0);
  }
  function metalSize(m) {
    const r = m.host.getBoundingClientRect(); if (!r.width || !r.height) return false;
    const w = Math.max(8, Math.min(120, Math.round(r.width / 3))), h = Math.max(4, Math.min(48, Math.round(r.height / 3)));
    if (w !== m.w || h !== m.h) { m.w = m.cv.width = w; m.h = m.cv.height = h; m.img = m.cx.createImageData(w, h); metalDraw(m, 3); }
    return true;
  }
  function metalTick(ts) {
    metalRaf = 0; if (document.hidden) return;
    const due = ts - metalLast >= 41; let live = false;
    for (const m of METAL.values()) { if (!m.vis || !m.host.isConnected) continue; live = true; if (due && metalSize(m)) metalDraw(m, (ts - metalT0) / 1000); }
    if (due) metalLast = ts;
    if (live) metalRaf = requestAnimationFrame(metalTick);
  }
  function metalKick() { if (!metalRaf && !RM() && !document.hidden) metalRaf = requestAnimationFrame(metalTick); }
  const metalIO = typeof IntersectionObserver === "function" ? new IntersectionObserver((es) => {
    for (const e of es) { const m = METAL.get(e.target); if (m) m.vis = e.isIntersecting; } metalKick(); }) : null;
  function metal(host) {
    if (!host || host.dataset.mm || (MOMENTS.proBtn || "") !== "metal") return;
    host.dataset.mm = "1";
    const cv = document.createElement("canvas"); cv.className = "m-metal-cv"; cv.setAttribute("aria-hidden", "true");
    const cx = cv.getContext("2d"); if (!cx) return;
    host.insertBefore(cv, host.firstChild);
    const m = {host, cv, cx, w: 0, h: 0, vis: !metalIO, img: null};
    METAL.set(host, m); if (!metalT0) metalT0 = performance.now();
    metalSize(m);                                    // a first still frame, also the whole effect under reduced motion
    if (metalIO) metalIO.observe(host);
    metalKick();
  }
  function metalScan() { document.querySelectorAll(".m-metal:not([data-mm])").forEach(metal); for (const [h] of METAL) if (!h.isConnected) { METAL.delete(h); metalIO && metalIO.unobserve(h); } }
  document.addEventListener("visibilitychange", metalKick);
  if (window.MutationObserver) new MutationObserver(() => { metalScan(); segScan(); scanSoon(); }).observe(document.documentElement, {childList: true, subtree: true});
  metalScan();

  // ---- per-session avatar -------------------------------------------------------------------
  // A small orb-sphere in the family of the Genok mark (sphere + orbit rings), not a dot grid:
  // the session id picks a hue pair, the tilt and count of the orbit rings and where the satellite
  // sits. Same id, same avatar, on every screen. Pure SVG, nothing animates.
  function hash32(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function avatar(id, px) {
    if ((MOMENTS.avatar || "") !== "orb") return "";
    const h = hash32(String(id || "?")), size = px || 32, n = (k, m) => Math.floor(h / k) % m;
    const hue = h % 360, hue2 = (hue + 40 + n(7, 70)) % 360, tilt = [-60, -30, 0, 30, 60, 90][n(11, 6)] + (n(13, 2) ? 12 : -12);
    const rings = 1 + n(17, 2), sat = n(19, 360), lit = 56 + n(23, 12), gid = "av" + h.toString(36);
    const ring = (rot, o) => `<ellipse cx="16" cy="16" rx="14.4" ry="5.2" transform="rotate(${rot} 16 16)" fill="none" stroke="#fff" stroke-opacity="${o}" stroke-width="1.2"/>`;
    const a = sat * Math.PI / 180, sx = 16 + 14.4 * Math.cos(a), sy = 16 + 5.2 * Math.sin(a);
    return `<svg class="m-av" width="${size}" height="${size}" viewBox="0 0 32 32" aria-hidden="true"><defs>`
      + `<radialGradient id="${gid}" cx="34%" cy="28%" r="80%"><stop offset="0" stop-color="hsl(${hue2} 85% ${lit + 22}%)"/><stop offset=".55" stop-color="hsl(${hue} 70% ${lit - 8}%)"/><stop offset="1" stop-color="hsl(${hue} 66% ${lit - 30}%)"/></radialGradient></defs>`
      + `<circle cx="16" cy="16" r="11.5" fill="url(#${gid})"/>`
      + ring(tilt, 0.85) + (rings > 1 ? ring(tilt + 62, 0.45) : "")
      + `<circle cx="${sx.toFixed(2)}" cy="${sy.toFixed(2)}" r="1.9" transform="rotate(${tilt} 16 16)" fill="#fff"/></svg>`;
  }

  // ---- delegated micro-interactions (no edits at the call sites) ----------------------------
  document.addEventListener("click", (e) => {
    const t = e.target && e.target.closest ? e.target : null; if (!t) return;
    // Favourite / pin star turned on: the star pops and throws a few rays.
    const f = t.closest("[data-fav],[data-pin]");
    if (f) { const key = f.dataset.fav != null ? "fav" : "pin", v = f.dataset[key];
      const fx = MOMENTS.favOn || "";
      return later(() => document.querySelectorAll(`[data-${key}="${CSS.escape(v)}"].on`).forEach((b) => {
        if (fx.includes("pop")) pop(b.querySelector("svg"), 0.6); if (fx.includes("rays")) rays(b); })); }
    // Tab / rail switch: the new tab's icon springs in.
    const g = t.closest("[data-go]");
    if (g && g.closest("#tabbar,.rail,nav") && (MOMENTS.tabOn || "").includes("pop")) { const k = g.dataset.go;
      later(() => document.querySelectorAll(`[data-go="${CSS.escape(k)}"].on > svg`).forEach((s) => pop(s, 0.78))); }
  }, true);

  // ---- first-run replay ---------------------------------------------------------------------
  // See the first-run flow again without touching any data: the logo splash, then the setup
  // wizard (which hands over to the tour) reopened on the saved values. Entry points:
  //   /?firstrun=1                 a link, also usable for review recordings
  //   LOOP_FIRSTRUN.replay()       settings > "첫 설정 다시 보기"
  // The splash is normally shown once per tab (v2.html drops it when sessionStorage has "v2-in"),
  // so replay() clears that mark before reloading; a pasted link in a tab that already has it
  // gets the same markup put back here, before v2.js looks for it.
  const firstRun = (() => { try { return new URLSearchParams(location.search).has("firstrun"); } catch (e) { return false; } })();
  if (firstRun) {
    if (!document.getElementById("splash")) {
      const s = document.createElement("div");
      s.className = "splash"; s.id = "splash"; s.setAttribute("role", "status"); s.setAttribute("aria-busy", "true");
      s.innerHTML = `<div class="sp-logo"><div class="sp-in"><rl-orb state="idle" size="64" px="48" aria-label=""></rl-orb></div></div>`;
      document.body.prepend(s);
    }
    // Drop the flag from the address so a reload or a shared link does not replay it again.
    try { const u = new URL(location.href); u.searchParams.delete("firstrun"); history.replaceState(history.state, "", u.pathname + u.search + u.hash); } catch (e) {}
    // The wizard opens once the logo has left (it would sit under the splash otherwise). Every
    // deferred script has run by DOMContentLoaded, so LOOP_ONBOARD exists when it is installed.
    document.addEventListener("DOMContentLoaded", () => {
      const t0 = performance.now();
      const wait = () => {
        if (document.getElementById("splash") && performance.now() - t0 < 8000) return requestAnimationFrame(wait);
        try { window.LOOP_ONBOARD && window.LOOP_ONBOARD.open(); } catch (e) {}
      };
      wait();
    });
  }
  window.LOOP_FIRSTRUN = {
    active: firstRun,
    replay() {
      try { sessionStorage.removeItem("v2-in"); } catch (e) {}
      const u = new URL(location.href); u.searchParams.set("firstrun", "1"); u.hash = "";
      location.assign(u.pathname + u.search);
    },
  };

  // ---- segmented control: one marker under the chosen chip, its two ends on their own springs --
  // (C10, in place of A1's slide.) The end facing the new chip is stiff and leaves first, the other
  // end is soft and catches up, so the marker stretches toward where it is going. The strips are
  // redrawn (innerHTML) on every choice, so the springs are kept per strip kind and draw on whichever
  // marker is in the page: a press mid-flight carries on from that spot, at that speed.
  const SEGS = [".pj-sfil", ".stabs", "#itabs"], segSt = new Map();
  const segKey = (s) => SEGS.find((q) => s.matches(q)) || "";
  const segBox = (b) => ({x: b.offsetLeft, y: b.offsetTop, w: b.offsetWidth, h: b.offsetHeight});
  function segState(key) {
    let st = segSt.get(key); if (st) return st;
    st = {i: null, w: 1, y: 0, at: -1e9};
    const draw = () => { const i = st.i; if (!i || !i.isConnected) return;
      i.style.transform = `translate(${st.L.x}px,${st.y}px) scaleX(${Math.max(0.5, (st.R.x - st.L.x) / st.w)})`; };
    st.draw = draw; st.L = phys(0, 110, 17, draw, 0.01); st.R = phys(1, 110, 17, draw, 0.01);
    segSt.set(key, st); return st;
  }
  function segSync(s, to, still) {
    const on = to || s.querySelector(":scope>button.on"), st = segState(segKey(s)); let i = s.querySelector(":scope>.m-segi");
    if (!on) { if (i) i.remove(); s.classList.remove("m-seg"); return; }
    const fresh = !i;
    if (fresh) {
      i = document.createElement("i"); i.className = "m-segi"; i.setAttribute("aria-hidden", "true"); s.appendChild(i); s.classList.add("m-seg");
      i.style.borderRadius = getComputedStyle(on).borderRadius;
      // Re-measured when the strip itself changes width (an observer also reports once on being set up - not that one).
      let w0 = s.offsetWidth;
      if (window.ResizeObserver) new ResizeObserver(() => { const w = s.offsetWidth; if (w !== w0 && s.isConnected) { w0 = w; segSync(s, null, true); } }).observe(s);
    }
    const p = segBox(on);                               // measured once the strip is the offset parent (.m-seg)
    // A strip that was not just pressed (a screen opening) shows its marker in place; so does a resize.
    const jump = still || (fresh && performance.now() - st.at > 700) || !p.w;
    const same = st.i === i && Math.abs(st.L.to - p.x) < 0.5 && Math.abs(st.R.to - p.x - p.w) < 0.5;
    st.i = i; st.w = p.w || 1; st.y = p.y; i.style.width = st.w + "px"; i.style.height = p.h + "px";
    if (jump) { st.L.jump(p.x); st.R.jump(p.x + p.w); return; }
    if (same) return st.draw();
    const right = p.x + p.w / 2 > (st.L.x + st.R.x) / 2, lead = right ? st.R : st.L, trail = right ? st.L : st.R;
    lead.k = 420; lead.c = 32; trail.k = 110; trail.c = 17;
    if (RM()) fadeIn(i);
    st.L.set(p.x); st.R.set(p.x + p.w);
  }
  function segScan() { document.querySelectorAll(SEGS.map((q) => q + ":not(.m-seg)").join(",")).forEach((s) => segSync(s)); }
  const segOf = (e) => { const b = e.target && e.target.closest ? e.target.closest("button") : null, s = b && b.parentNode;
    return s && s.matches && s.matches(SEGS.join(",")) ? [s, b] : null; };
  const segBack = () => later(() => document.querySelectorAll(".m-seg").forEach((s) => segSync(s)));
  // It leaves on the press, not on the release; a press that ends elsewhere sends it back.
  document.addEventListener("pointerdown", (e) => { const x = segOf(e); if (x && x[0].classList.contains("m-seg")) { segState(segKey(x[0])).at = performance.now(); segSync(x[0], x[1]); } }, true);
  document.addEventListener("click", (e) => { const x = segOf(e); if (x) { segState(segKey(x[0])).at = performance.now(); segBack(); } }, true);
  document.addEventListener("pointerup", segBack, true); document.addEventListener("pointercancel", segBack, true);
  document.addEventListener("DOMContentLoaded", segScan);

  // ---- copy: the pressed button itself says it worked ----------------------------------------
  // Every copy in the app ends in navigator.clipboard.writeText, so the answer is given there once
  // instead of at each call site: an icon button shows a check for 1.6s, a "복사" label reads
  // 복사했어요 (its width held so nothing beside it moves). Toasts stay as they are.
  const CHECK = '<svg class="i m-cpk" viewBox="0 0 256 256" aria-hidden="true"><polyline points="40 144 96 200 224 72"/></svg>';
  let cpBtn = null, cpAt = 0;
  document.addEventListener("click", (e) => { const b = e.target && e.target.closest ? e.target.closest("button,[role=button],a") : null; if (b) { cpBtn = b; cpAt = performance.now(); } }, true);
  function copied(b) {
    if (!b || !b.isConnected) return;
    if (b._cp) { clearTimeout(b._cp.t); b._cp.t = setTimeout(b._cp.back, 1600); return; }
    const svg = b.querySelector(":scope>svg");
    let back;
    if (svg) {
      const t = document.createElement("template"); t.innerHTML = CHECK; const ck = t.content.firstChild;
      const c = getComputedStyle(svg); ck.style.width = c.width; ck.style.height = c.height;
      svg.replaceWith(ck); back = () => { if (ck.isConnected) { ck.replaceWith(svg); svg.classList.add("m-cpin"); setTimeout(() => svg.classList.remove("m-cpin"), 300); } };
    } else if (!b.children.length && /복사|copy/i.test(b.textContent)) {
      const was = b.textContent, mw = b.style.minWidth; b.style.minWidth = b.getBoundingClientRect().width + "px";
      const said = /^ko/i.test(document.documentElement.lang || "ko") ? "복사했어요" : "Copied";
      b.textContent = said; b.classList.add("m-cpt");
      back = () => { if (b.textContent === said) b.textContent = was; b.style.minWidth = mw; b.classList.remove("m-cpt"); };
    } else return;
    b._cp = {back: () => { b._cp = null; back(); }}; b._cp.t = setTimeout(b._cp.back, 1600);
  }
  try {
    const cb = navigator.clipboard, w0 = cb && cb.writeText;
    if (w0) cb.writeText = function (t) { const b = cpBtn, near = performance.now() - cpAt < 1500, p = w0.call(cb, t);
      if (b && near) p.then(() => copied(b), () => {}); return p; };
  } catch (e) {}

  // ---- menus: appear at the button's corner (a hair smaller, for 140ms), leave faster still ----
  function menuIn(pop) { pop.animate(RM() ? [{opacity: 0}, {opacity: 1}] : [{opacity: 0, transform: "scale(.98)"}, {opacity: 1, transform: "none"}], {duration: RM() ? 200 : 140, easing: RM() ? "ease" : "ease-out"}); }
  function menuOut(pop) {                               // from wherever the opening had got to
    if (!pop.isConnected || !pop.animate) return pop.remove();
    const c = getComputedStyle(pop), from = {opacity: c.opacity, transform: c.transform};
    pop.getAnimations().forEach((a) => a.cancel()); pop.style.pointerEvents = "none";
    const to = RM() ? {opacity: 0, transform: from.transform} : {opacity: 0, transform: "scale(.94)"};
    const a = pop.animate([from, to], {duration: 120, easing: "ease-in", fill: "forwards"});
    a.onfinish = a.oncancel = () => pop.remove();
  }

  // ---- C9 drag to reorder: the row rides the pointer 1:1, the others give way on springs -------
  // sel picks the rows inside box, idOf names one, done(ids) is told the new order once every row
  // has come to rest. The order lives here while it moves, so a row can be caught again mid-settle
  // and carries on from where it is. Past either end it gives like a rubber band, 14px at most; on
  // release the row keeps the hand's speed (capped at 500px/s). Alt+Up / Alt+Down move the focused row.
  function sort(box, sel, done, idOf) {
    if (!box || box._msort) return; box._msort = true;
    let rows = null, order = null, d = null;
    const swallow = (e) => { e.stopPropagation(); e.preventDefault(); box.removeEventListener("click", swallow, true); };
    function build() {
      const L = [...box.querySelectorAll(sel)]; if (L.length < 2) return false;
      rows = L.map((el, i) => { const r = {el, i, top: el.offsetTop};
        const draw = () => { el.style.transform = `translateY(${r.y.x}px) scale(${r.s.x})`; };
        r.y = phys(0, 260, 24, draw, 0.05); r.s = phys(1, 300, 22, draw); r.y.rest = r.s.rest = rest;
        el.classList.add("m-srow"); return r; });
      order = rows.slice(); return true;
    }
    const slotOf = (r) => rows[order.indexOf(r)].top - r.top;
    const settle = (skip) => order.forEach((r) => { if (r !== skip) r.y.set(slotOf(r)); });
    // Everything still: hand the order over and let go of the rows.
    function rest() {
      if (!rows || d || rows.some((r) => r.y.live() || r.s.live())) return;
      if (!rows[0].el.isConnected) { rows = order = null; return; }      // the list was redrawn underneath: nothing to hand over
      const moved = order.some((r, j) => r.i !== j), ids = order.map((r) => idOf(r.el));
      rows.forEach((r) => { r.el.style.transform = ""; r.el.classList.remove("m-srow", "m-lift"); });
      box.classList.remove("m-sorting"); rows = order = null;
      if (moved) done(ids);
    }
    function lift() {
      const r = d.r; d.on = true; r.y.jump(r.y.x); box.classList.add("m-sorting"); r.el.classList.add("m-lift");
      if (!RM()) r.s.set(1.04);
      try { r.el.setPointerCapture(d.id); } catch (e) {}
      box.addEventListener("click", swallow, true);       // the click that ends a drag is not a press on the row
    }
    function move(e) {
      if (!d || e.pointerId !== d.id) return;
      if (!d.r.el.isConnected) return up({pointerId: d.id, type: "pointercancel", timeStamp: e.timeStamp});
      if (!d.on) { if (Math.abs(e.clientY - d.y0) < 6) return; lift(); }
      const r = d.r, lo = rows[0].top - r.top, hi = rows[rows.length - 1].top - r.top;
      let y = d.off + e.clientY - d.y0;
      if (y < lo) y = lo - Math.min(14, (lo - y) * 0.3); else if (y > hi) y = hi + Math.min(14, (y - hi) * 0.3);
      r.y.jump(y);
      const dt = Math.max(1, e.timeStamp - d.pt); d.v = d.v * 0.6 + ((e.clientY - d.py) / dt * 1000) * 0.4; d.py = e.clientY; d.pt = e.timeStamp;
      let slot = 0, best = Infinity;
      rows.forEach((q, j) => { const a = Math.abs(q.top - r.top - y); if (a < best) { best = a; slot = j; } });
      if (order[slot] !== r) { order.splice(order.indexOf(r), 1); order.splice(slot, 0, r); settle(r); }
    }
    function up(e) {
      if (!d || e.pointerId !== d.id) return;
      removeEventListener("pointermove", move); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
      const q = d; d = null;
      if (!q.on) return rest();
      setTimeout(() => box.removeEventListener("click", swallow, true), 0);
      if (e.type === "pointercancel") order = rows.slice();            // a drag taken away goes back where it came from
      const v = e.type === "pointercancel" || e.timeStamp - q.pt > 90 ? 0 : Math.max(-500, Math.min(500, q.v));
      settle(q.r); q.r.s.set(1); q.r.y.set(slotOf(q.r), v);
      if (RM()) rest();
    }
    box.addEventListener("pointerdown", (e) => {
      if (d || e.button !== 0 || e.pointerType !== "mouse") return;
      const el = e.target.closest(sel); if (!el || !box.contains(el)) return;
      if (!rows && !build()) return;
      const r = rows.find((q) => q.el === el); if (!r) return;
      d = {r, id: e.pointerId, y0: e.clientY, off: r.y.x, on: false, py: e.clientY, pt: e.timeStamp, v: 0};
      if (r.y.live()) lift();                                // caught while it was still settling
      addEventListener("pointermove", move); addEventListener("pointerup", up); addEventListener("pointercancel", up);
    });
    box.addEventListener("keydown", (e) => {
      const dir = !e.altKey || d ? 0 : e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : 0; if (!dir) return;
      const el = e.target.closest(sel); if (!el || !box.contains(el) || (!rows && !build())) return;
      const r = rows.find((q) => q.el === el); if (!r) return;
      e.preventDefault();
      const at = order.indexOf(r), to = Math.max(0, Math.min(rows.length - 1, at + dir));
      if (to !== at) { order.splice(at, 1); order.splice(to, 0, r); if (RM()) { fadeIn(r.el); fadeIn(order[at].el); } }
      settle(); if (RM() || to === at) rest();
    });
  }

  // ---- C15 the drawing tools swell under the cursor (mouse only) ------------------------------
  // The icon grows, not the button, so neighbours 2px apart never overlap and the bar keeps its
  // height. Nearest tool 1.38x, falling off as exp(-d^2/1900); each icon on its own spring.
  function dockScan() {
    document.querySelectorAll(".dtools:not([data-md])").forEach((bar) => {
      bar.dataset.md = "1";
      const T = [...bar.querySelectorAll("button>svg")].map((g) => ({b: g.parentNode, s: phys(1, 260, 20, (x) => { g.style.transform = x === 1 ? "" : `scale(${x})`; })}));
      const mag = (e) => { if (e.pointerType !== "mouse" || RM()) return;
        T.forEach(({b, s}) => { const r = b.getBoundingClientRect(), dx = e.clientX - r.left - r.width / 2; s.set(b.disabled ? 1 : 1 + 0.38 * Math.exp(-dx * dx / 1900)); }); };
      const calm = () => T.forEach(({s}) => s.set(1));
      bar.addEventListener("pointermove", mag); bar.addEventListener("pointerdown", mag);
      bar.addEventListener("pointerleave", calm); bar.addEventListener("pointercancel", calm);
    });
  }

  // ---- C3 the wordmark on the start screen: one band of light crosses it, once ----------------
  (function sheen() {
    const n = document.querySelector("#splash .sp-name"); if (!n || RM()) return;
    n.classList.add("m-sheen");
    const s = phys(-0.3, 60, 14, (x) => { n.style.backgroundPosition = (75 - 50 * x) + "% 0"; });
    s.jump(-0.3); setTimeout(() => s.set(1.3), 300);
  })();

  // ---- result cards: C11 a beam runs round the edge while a session works on the item, C13 the
  // thumbnail turns over once when a new version lands, C2 an English title decodes itself ------
  // Read from the app's own data (D.items, iid, stK of v2.js) by the card's data-item, so the card
  // markup stays as it is. The lists are rebuilt on every refresh: the beam's phase comes from the
  // clock (a rebuilt card picks up where the old one was), and a turning thumbnail is found again.
  const CARDS = ".gi[data-item],.ht[data-item]", BEAM_MS = 3400;
  const beamOn = new Set(), vSeen = new Map(), vNew = new Map(), flips = new Map();
  let cardOf = null, cardBy = new Map(), cardT0 = 0;
  const vNum = (v) => parseInt(String(v || "").replace(/\D/g, ""), 10) || 0;
  const vTxt = (v) => "v" + vNum(v);
  function cardScan() {
    let items; try { items = D.items; } catch (e) { return; }
    if (!items) return;
    if (items !== cardOf) {
      cardOf = items; cardBy = new Map(); const now = performance.now();
      if (items.length && !cardT0) cardT0 = now;
      for (const x of items) { let k; try { k = iid(x); } catch (e) { return; } cardBy.set(k, x);
        const was = vSeen.get(k); vSeen.set(k, x.v);
        // Not during the first seconds: the saved copy giving way to fresh data is not an arrival.
        if (was && vNum(x.v) > vNum(was) && now - cardT0 > 2500) vNew.set(k, {old: was, at: now}); }
    }
    document.querySelectorAll(CARDS).forEach((c) => {
      const k = c.dataset.item, x = cardBy.get(k); let work = false;
      try { work = !!x && stK(x) === "work"; } catch (e) {}
      if (work && !c.classList.contains("m-beam")) { c.style.setProperty("--m-bd", -Math.round(performance.now() % BEAM_MS) + "ms"); c.classList.add("m-beam"); beamOn.add(k); }
      else if (!work && (c.classList.contains("m-beam") || beamOn.has(k))) {          // done: the beam fades out over 0.4s
        if (!c.style.getPropertyValue("--m-bd")) c.style.setProperty("--m-bd", -Math.round(performance.now() % BEAM_MS) + "ms");
        beamOn.delete(k); c.classList.remove("m-beam"); c.classList.add("m-beam-off"); setTimeout(() => c.classList.remove("m-beam-off"), 450);
      }
      const nv = vNew.get(k);
      if (nv && !nv.done && x && !document.hidden) { nv.done = true; if (performance.now() - nv.at < 4000) { flip(k, nv.old, x.v); } }
    });
  }
  const thumbOf = (k) => { for (const c of document.querySelectorAll(CARDS)) if (c.dataset.item === k) return c.querySelector(".th,.hth"); return null; };
  function flip(k, oldV, newV) {
    let th = thumbOf(k); if (!th || flips.has(k)) return;
    const face = document.createElement("span"); face.className = "m-flipf num"; face.setAttribute("aria-hidden", "true"); face.textContent = vTxt(oldV);
    const chip = document.createElement("span"); chip.className = "m-flipv num"; chip.setAttribute("aria-hidden", "true"); chip.textContent = vTxt(newV);
    const bye = () => { const a = chip.animate([{opacity: 1}, {opacity: 0}], {duration: 300, easing: "ease-out", fill: "forwards"}); a.onfinish = a.oncancel = () => chip.remove(); };
    if (RM()) {                                              // no turn: the old number fades away over the new picture
      th.append(chip, face); const a = face.animate([{opacity: 1}, {opacity: 0}], {duration: 200, easing: "ease", fill: "forwards"});
      a.onfinish = a.oncancel = () => face.remove(); setTimeout(bye, 2000); return;
    }
    const a = phys(180, 120, 13, (x) => {
      if (!th || !th.isConnected) { th = thumbOf(k); if (!th) return; th.append(chip, face); }
      th.style.transform = `perspective(700px) rotateX(${x}deg)`; face.style.visibility = Math.abs(x) > 90 ? "visible" : "hidden";
    }, 0.05);
    a.rest = () => { flips.delete(k); if (th) th.style.transform = ""; face.remove(); setTimeout(bye, 1600); };
    flips.set(k, a); th.append(chip, face); a.jump(180); a.set(0);
  }
  // Each letter keeps its own width while it is a stand-in, so the line does not shiver.
  const GLYPHS = "<>/[]{}=+*#%&01";
  function scramble(el) {
    const txt = el ? el.textContent : ""; if (!el || el.children.length || txt.length < 2 || !/^[\x20-\x7e]+$/.test(txt)) return;
    if (RM()) return fadeIn(el);
    const n = txt.length, at = [...txt].map((_, i) => i / n * 0.7 + Math.random() * 0.3), cur = [], t0 = performance.now();
    el.textContent = ""; const say = document.createElement("span"); say.className = "m-vh"; say.textContent = txt;
    const box = document.createElement("span"); box.setAttribute("aria-hidden", "true");
    const cs = [...txt].map((ch) => { const c = document.createElement("span"); c.textContent = ch; box.appendChild(c); return c; });
    el.append(say, box);
    cs.map((c) => c.getBoundingClientRect().width).forEach((w, i) => { if (txt[i] !== " ") { cs[i].className = "m-scr"; cs[i].style.width = w + "px"; } });
    let f = 0;
    (function step(t) {
      if (!el.isConnected) return;
      const p = (t - t0) / 1000;
      if (p >= 1) { el.textContent = txt; return; }
      for (let i = 0; i < n; i++) { if (txt[i] === " ") continue;
        if (p >= at[i]) { if (cur[i] !== txt[i]) cs[i].textContent = cur[i] = txt[i]; }
        else if (f % 3 === 0 || !cur[i]) cs[i].textContent = cur[i] = GLYPHS[Math.random() * GLYPHS.length | 0]; }
      f++; requestAnimationFrame(step);
    })(t0);
  }
  // ---- B12 a count that rolls over: the old number leaves upward, the new one comes up --------
  // The bell's and the phone tab bar's "my turn" counts. The bars are rebuilt on change, so the
  // last number is kept here by badge kind; a rebuild in the middle simply shows the latest one.
  const COUNTS = ".bcnt,.tcnt", countWas = new Map(), countAt = new WeakMap();
  function countScan() {
    const live = new Set();
    document.querySelectorAll(COUNTS).forEach((el) => {
      const key = el.classList.contains("bcnt") ? "bcnt" : "tcnt"; live.add(key);
      if (el.classList.contains("m-roll")) return;
      const now = el.textContent, was = countAt.has(el) ? countAt.get(el) : countWas.get(key);
      countAt.set(el, now); countWas.set(key, now);
      if (was == null || was === now) return;
      if (RM()) return fadeIn(el);
      const ease = getComputedStyle(el).getPropertyValue("--ease").trim() || "cubic-bezier(.2,.9,.25,1)", opt = {duration: 280, easing: ease, fill: "both"};
      const o = document.createElement("span"), n = document.createElement("span"); o.className = "m-ro"; o.setAttribute("aria-hidden", "true"); o.textContent = was; n.textContent = now;
      el.textContent = ""; el.classList.add("m-roll"); el.append(n, o);
      try {
        o.animate([{transform: "none", opacity: 1, filter: "blur(0)"}, {transform: "translateY(-100%)", opacity: 0, filter: "blur(3px)"}], opt);
        const a = n.animate([{transform: "translateY(100%)", opacity: 0}, {transform: "none", opacity: 1}], opt);
        a.onfinish = a.oncancel = () => { if (el.classList.contains("m-roll")) { el.classList.remove("m-roll"); el.textContent = now; } };
      } catch (e) { el.classList.remove("m-roll"); el.textContent = now; }
    });
    for (const k of countWas.keys()) if (!live.has(k)) countWas.delete(k);
  }

  // ---- B7 a tag that trails the cursor where dragging does something (mouse only) -------------
  // Over the wipe comparison (cmpview.js): "drag to compare". It appears in place, then eases after the cursor.
  const TAGS = [["#cvstage .cvw,#cmp.m-wipe", () => tl("motion.wipe")]];
  let tagEl = null, tagOn = false, tagRaf = 0, tx = 0, ty = 0, tgx = 0, tgy = 0;
  function tagDraw() { tagEl.style.transform = `translate(${Math.round(tx * 10) / 10}px,${Math.round(ty * 10) / 10}px)`; }
  function tagStep() { tagRaf = 0; if (!tagOn) return;
    tx += (tgx - tx) * 0.2; ty += (tgy - ty) * 0.2; tagDraw();
    if (Math.abs(tgx - tx) + Math.abs(tgy - ty) > 0.2) tagRaf = requestAnimationFrame(tagStep); }
  function tagHide() { if (tagOn) { tagOn = false; tagEl.classList.remove("on"); } }
  addEventListener("pointermove", (e) => {
    const hit = e.pointerType === "mouse" && !e.buttons && e.target.closest ? TAGS.find(([q]) => e.target.closest(q)) : null;
    if (!hit) return tagHide();
    if (!tagEl) { tagEl = document.createElement("div"); tagEl.className = "m-ctag"; tagEl.setAttribute("aria-hidden", "true"); document.body.appendChild(tagEl); }
    let txt = ""; try { txt = hit[1](); } catch (er) {}
    if (!txt || txt === "motion.wipe") return tagHide();
    if (tagEl.textContent !== txt) tagEl.textContent = txt;
    tgx = Math.min(e.clientX + 12, innerWidth - tagEl.offsetWidth - 6); tgy = Math.min(e.clientY + 12, innerHeight - tagEl.offsetHeight - 6);
    if (!tagOn || RM()) { tx = tgx; ty = tgy; tagDraw(); }
    if (!tagOn) { tagOn = true; tagEl.classList.add("on"); }
    if (!tagRaf && !RM()) tagRaf = requestAnimationFrame(tagStep);
  }, {passive: true});
  addEventListener("pointerdown", tagHide, {passive: true});
  document.addEventListener("pointerleave", tagHide); addEventListener("blur", tagHide);

  let scanRaf = 0;
  function scanSoon() { if (!scanRaf) scanRaf = requestAnimationFrame(() => { scanRaf = 0; dockScan(); cardScan(); countScan(); }); }

  const textClass = (moment) => TEXT[moment] || "";
  window.Motion ={MOMENTS, AFTER, TEXT, ICONS, EMOJI, SPRINGS, spring, drive, project, icon: svg, emoji, tip, after, textClass, empty, pop, rays, burst, avatar, metal, goo, copied, menuIn, menuOut, phys, sort, flip, scramble};
})();
