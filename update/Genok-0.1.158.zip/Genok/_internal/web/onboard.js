// First-run wizard + the empty-home guide. Shown while settings has no `onboarded` flag. It borrows
// v2.js's globals (tl, post, toast, esc, ic) but keeps its own look, so restyling it never touches
// the app.
//
// One decision per screen: one title, at most one dim line, one main button and at most one quiet
// second one. The main button never moves between screens.
//   1) 이름           - the only thing typed. The data folder keeps its default; "저장 위치 바꾸기"
//                      (the quiet button) opens the folder screen for the few who want another one.
//   2) 에이전트 연결  - Claude Code and Codex, equal. A screen shows only when there is something to
//                      press: an agent already connected is passed, and one that is not installed is
//                      passed when the other one is. Nothing is written to an agent's settings
//                      before the [연결] press on the screen that says what it writes.
//   3) 둘러보기       - the sample tour is offered, never started by itself.
// Left to 설정 (not asked here): the work mode (auto), viewing on a phone, reading past
// conversations (asked in the chat list, where it matters), other accounts.
(function () {
  "use strict";

  // ---------------------------------------------------------------- styling (adjust here)
  const CSS = `
  .ob-scrim{position:fixed;inset:0;z-index:9000;display:flex;overflow:auto;
    --ob-bg:#131314;--ob-panel:#1c1c1e;--ob-panel2:#252528;--ob-line:#343437;--ob-line-hi:#5c5c61;
    --ob-text:#f4f4f4;--ob-dim:#a3a3aa;--ob-faint:#6e6e75;--ob-input:#1c1c1e;--ob-btn:#f1f1f1;--ob-btnfg:#141414;
    --ob-accent:#6ea8fe;--ob-ok:#43c17a;--ob-danger:#e0616b;--ob-warn:#d9a441;
    color:var(--ob-text);background:var(--ob-bg);font:inherit;opacity:0;transition:opacity .2s ease;}
  html[data-theme="light"] .ob-scrim{--ob-bg:#f5f5f3;--ob-panel:#fff;--ob-panel2:#ebebe8;--ob-line:#dadad6;--ob-line-hi:#a6a6a1;
    --ob-text:#17171a;--ob-dim:#5f5f67;--ob-faint:#96969c;--ob-input:#fff;--ob-btn:#17171a;--ob-btnfg:#fff;
    --ob-accent:#2f6fde;--ob-ok:#1c9455;--ob-danger:#c63f4a;--ob-warn:#9a6a10;}
  .ob-scrim.in{opacity:1;}
  /* One centred column, the same width and height on every screen: the top row, the stage (icon,
     title, one dim line, the body) and the buttons, which sit on the column's bottom edge. */
  .ob-col{width:min(400px,calc(100vw - 32px));min-height:min(560px,calc(100dvh - 56px));margin:auto;padding:28px 0;
    display:flex;flex-direction:column;box-sizing:content-box;}
  @media (max-width:560px){.ob-col{min-height:calc(100dvh - 40px);padding:12px 0 28px;}}
  /* The app's own window buttons (.wtbar, 36px, top right) sit over the column's top row once the window is this narrow. */
  @media (max-width:680px){body:has(.wtbar) .ob-scrim{padding-top:36px;}body:has(.wtbar) .ob-col{min-height:min(560px,calc(100dvh - 92px));}}
  @media (max-width:560px){body:has(.wtbar) .ob-col{min-height:calc(100dvh - 76px);}}
  /* Each screen appears in place: a short fade, no slide. */
  @keyframes ob-fade{from{opacity:0}to{opacity:1}}
  .ob-stage.in{animation:ob-fade .16s ease-out;}
  .ob-top{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;min-height:36px;margin-bottom:40px;}
  .ob-top>:last-child{justify-self:end;}
  .ob-ibtn{width:36px;height:36px;margin:0 -8px;padding:0;border:0;border-radius:999px;background:none;color:var(--ob-dim);
    display:grid;place-items:center;cursor:pointer;transition:background .15s,color .15s;}
  .ob-ibtn:hover{background:var(--ob-panel2);color:var(--ob-text);}
  .ob-ibtn svg.i{width:20px;height:20px;}
  @media (pointer:coarse){.ob-top{min-height:44px;}.ob-ibtn{width:44px;height:44px;margin:0 -12px;}}
  /* The small step indicator: the current step is the long one. */
  .ob-dots{display:flex;align-items:center;gap:6px;}
  .ob-dots i{width:6px;height:6px;border-radius:999px;background:var(--ob-line);transition:width .2s ease,background .2s ease;}
  .ob-dots i.ok{background:var(--ob-faint);}
  .ob-dots i.on{width:18px;background:var(--ob-text);}
  /* The quiet 한국어 / English switch at the header's end: a small pill pair, not a step. */
  .ob-top .ob-lang{flex:none;padding:2px;gap:0;border-radius:999px;background:transparent;border:1px solid var(--ob-line);}
  .ob-top .ob-lang button{height:22px;padding:0 8px;border-radius:999px;font-size:12px;font-weight:500;}
  .ob-top .ob-lang button.on{font-weight:600;}
  .ob-stage{flex:1 0 auto;display:flex;flex-direction:column;min-width:0;}
  .ob-ico{width:48px;height:48px;border-radius:12px;background:var(--ob-panel2);color:var(--ob-text);
    display:grid;place-items:center;margin:0 0 24px;flex:none;}
  .ob-ico svg.i{width:24px;height:24px;}
  .ob-ico.ok{color:var(--ob-ok);background:color-mix(in srgb,var(--ob-ok) 14%,transparent);}
  .ob-ico.brand{width:auto;background:none;border-radius:0;justify-content:start;}
  /* The welcome has nothing to type: the mark and its one line stand in the middle, not top left over an empty page. */
  .ob-stage:has(.ob-ico.brand){justify-content:center;align-items:center;text-align:center;padding-bottom:40px;}
  .ob-stage:has(.ob-ico.brand) .ob-ico.brand{justify-content:center;}
  .ob-stage:has(.ob-ico.brand) .ob-orb{margin-left:0;}
  /* Brand lockup (G-003): the ring's outer diameter is the cap height of the G (.69em) and sits on
     its centre. The small ring fills .843 of its box, so the box is .82em. */
  .ob-orb{display:block;width:.82em;height:.82em;margin:0 .14em 0 -.065em;flex:none;}
  .ob-mark{font-family:Georgia,"Times New Roman",serif;font-size:30px;letter-spacing:-.01em;white-space:nowrap;display:inline-flex;align-items:center;}
  .ob-h{font-size:26px;font-weight:700;letter-spacing:-.022em;line-height:1.32;margin:0;word-break:keep-all;text-wrap:balance;}
  .ob-h label{display:block;}
  .ob-desc{color:var(--ob-dim);font-size:15px;line-height:1.55;margin:8px 0 0;word-break:keep-all;}
  /* The agent's key colour, as the dot the chat list uses (.agd / .agd.cx). */
  .ob-scrim .agd{display:inline-block;width:9px;height:9px;border-radius:50%;margin:0 10px .14em 1px;vertical-align:middle;
    flex:none;background:var(--ag-claude,#c9805a);}
  .ob-scrim .agd.cx{background:var(--ag-codex,#5b9bd5);}
  .ob-body{margin-top:24px;display:flex;flex-direction:column;gap:8px;min-width:0;}
  .ob-body:empty{display:none;}
  .ob-in{width:100%;height:52px;box-sizing:border-box;background:var(--ob-input);color:var(--ob-text);
    border:1px solid var(--ob-line);border-radius:12px;padding:0 16px;font:inherit;font-size:16px;outline:none;
    transition:border-color .15s,box-shadow .15s;}
  .ob-in:focus{border-color:var(--ob-accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--ob-accent) 26%,transparent);}
  .ob-in::placeholder{color:var(--ob-faint);}
  /* Required-name feedback: a red edge + a short shake + an inline line, never an alert. */
  .ob-in.bad{border-color:var(--ob-danger);box-shadow:0 0 0 3px color-mix(in srgb,var(--ob-danger) 22%,transparent);}
  .ob-in.shake{animation:ob-shake .32s cubic-bezier(.36,.07,.19,.97);}
  @keyframes ob-shake{10%,90%{transform:translateX(-1px)}20%,80%{transform:translateX(2px)}
    30%,50%,70%{transform:translateX(-5px)}40%,60%{transform:translateX(5px)}}
  .ob-hint{font-size:13px;color:var(--ob-danger);margin:0;min-height:20px;line-height:20px;opacity:0;transition:opacity .2s ease;}
  .ob-hint.show{opacity:1;}
  /* The buttons: the main one, and one reserved row under it for the quiet one (kept even when
     empty, so the main button stands at the same place on every screen). */
  .ob-acts{margin-top:24px;display:flex;flex-direction:column;gap:6px;flex:none;}
  .ob-acts[hidden]{display:flex;visibility:hidden;}
  .ob-btn{width:100%;height:52px;box-sizing:border-box;border:0;border-radius:12px;background:var(--ob-btn);color:var(--ob-btnfg);
    font:inherit;font-size:16px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;
    text-decoration:none;transition:transform .12s cubic-bezier(.22,1,.36,1),filter .12s,opacity .15s;}
  .ob-btn:hover{filter:brightness(1.06);}
  html[data-theme="light"] .ob-btn:hover{filter:brightness(1.35);}
  .ob-btn:active{transform:scale(.985);}
  .ob-btn:focus-visible,.ob-link:focus-visible,.ob-ibtn:focus-visible,.ob-row:focus-visible,.ob-mini:focus-visible,.ob-adv summary:focus-visible{
    outline:2px solid var(--ob-accent);outline-offset:2px;}
  .ob-btn[disabled]{opacity:.55;cursor:default;}
  .ob-btn svg.i{width:18px;height:18px;}
  /* Not ready yet (no name typed): the same button, faint. It stays pressable, so an empty press nudges. */
  .ob-btn.dim{opacity:.38;}
  .ob-btn.busy,.ob-mini.busy{cursor:progress;}
  .ob-sec{height:44px;display:flex;align-items:center;justify-content:center;gap:4px;}
  .ob-link{height:36px;padding:0 16px;border:0;border-radius:999px;background:none;color:var(--ob-dim);font:inherit;font-size:14px;
    cursor:pointer;transition:background .15s,color .15s;}
  .ob-link:hover{color:var(--ob-text);background:var(--ob-panel2);}
  .ob-link[disabled]{opacity:.5;cursor:default;}
  @media (pointer:coarse){.ob-link{height:44px;min-width:44px;}}
  @media (prefers-reduced-motion:reduce){.ob-in.shake{animation:none;}.ob-btn,.ob-dots i{transition:none;}.ob-btn:active{transform:none;}}
  /* One plain row in the body: the signed-in account, or an agent to install. */
  .ob-row{display:flex;align-items:center;gap:8px;min-height:52px;box-sizing:border-box;padding:0 16px;border-radius:12px;
    background:var(--ob-panel);border:1px solid var(--ob-line);color:var(--ob-text);font-size:15px;text-decoration:none;min-width:0;}
  .ob-row .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
  .ob-row .go{flex:none;display:inline-flex;align-items:center;gap:4px;color:var(--ob-dim);font-size:13px;}
  .ob-row .go svg.i{width:14px;height:14px;}
  .ob-row .agd{margin:0 2px 0 0;width:8px;height:8px;}
  a.ob-row{cursor:pointer;transition:border-color .15s;}
  a.ob-row:hover{border-color:var(--ob-line-hi);}
  a.ob-row:hover .go{color:var(--ob-text);}
  .ob-row.acct{color:var(--ob-dim);font-size:14px;min-height:44px;}
  .ob-row.acct svg.i{width:16px;height:16px;flex:none;}
  .ob-connecting{display:flex;align-items:center;gap:8px;color:var(--ob-dim);font-size:15px;margin:0;}
  .ob-connecting rl-orb{flex:none;}
  .ob-note{color:var(--ob-dim);font-size:13px;line-height:1.5;margin:0;}
  .ob-bad{color:var(--ob-danger);}
  .ob-seclabel{font-size:12px;font-weight:600;color:var(--ob-dim);margin:0;}
  .ob-mini{height:34px;padding:0 16px;border-radius:8px;border:1px solid var(--ob-line);
    background:var(--ob-panel2);color:var(--ob-text);font:inherit;font-size:13px;font-weight:600;cursor:pointer;
    transition:border-color .15s;}
  .ob-mini:hover{border-color:var(--ob-line-hi);}
  .ob-mini[disabled]{opacity:.5;cursor:default;}
  .ob-mini.pri{background:var(--ob-btn);color:var(--ob-btnfg);border-color:transparent;}
  .ob-mini.wide{width:100%;height:38px;display:inline-flex;align-items:center;justify-content:center;text-decoration:none;}
  .ob-agdone{width:100%;height:38px;border-radius:8px;background:var(--ob-panel2);color:var(--ob-text);
    display:flex;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:600;}
  .ob-agdone span{color:var(--ob-ok);display:grid;}
  .ob-agdone svg.i,.ob-lt .lts .mk svg.i{width:14px;height:14px;}
  .ob-aghint{font-size:13px;color:var(--ob-dim);line-height:1.5;margin:0;}
  .ob-aghint a{color:var(--ob-accent);}
  .ob-aghint.ok{color:var(--ob-text);}
  .ob-aghint.warn{color:var(--ob-text);border-left:2px solid var(--ob-warn);padding-left:12px;white-space:pre-line;}
  .ob-body .cnterm{margin:0;max-height:120px;overflow:auto;font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere;}
  /* 자세히: the technical part waits here, closed. Its body scrolls by itself, so opening it never
     pushes the buttons off a normal window. */
  .ob-adv summary{cursor:pointer;color:var(--ob-dim);font-size:13px;list-style:none;user-select:none;
    display:inline-flex;align-items:center;gap:6px;min-height:32px;border-radius:8px;}
  .ob-adv summary::-webkit-details-marker{display:none;}
  .ob-adv summary::after{content:"\\203A";display:inline-block;color:var(--ob-faint);transition:transform .15s;}
  .ob-adv[open]>summary::after{transform:rotate(90deg);}
  .ob-adv summary:hover{color:var(--ob-text);}
  .ob-adv[open]>:not(summary){animation:ob-fade .14s ease-out;}
  .ob-xbody{display:flex;flex-direction:column;gap:8px;padding:6px 0 2px;}
  .ob-body>.ob-adv>.ob-xbody{max-height:min(34vh,250px);overflow:auto;padding-right:4px;}
  .ob-adv .ob-adv{border-top:1px solid var(--ob-line);padding-top:4px;}
  .ob-xrow{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:24px;}
  .ob-xrow .ct{font-size:13px;color:var(--ob-text);}
  .ob-xrow .xst{font-size:12px;color:var(--ob-dim);white-space:nowrap;}
  .ob-xrow .xst.on{color:var(--ob-ok);}
  .ob-pathrow{display:flex;gap:8px;align-items:center;}
  .ob-pathrow .ob-in{flex:1;min-width:0;}
  .ob-pathrow .ob-mini{flex:none;}
  .ob-pathrow.big .ob-in{font-size:14px;padding:0 16px;}
  .ob-pathrow.big .ob-mini{height:52px;border-radius:12px;padding:0 16px;}
  @media (max-width:420px){.ob-pathrow.big{flex-direction:column;align-items:stretch;}.ob-pathrow.big .ob-in{flex:none;}}
  /* Other accounts (설정 > 에이전트 연결 opens the agent screens with these). */
  .ob-acctag{font-size:12px;color:var(--ob-dim);white-space:nowrap;flex:none;}
  .ob-accrow{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 0;}
  .ob-accrow .ob-mini{flex:none;}
  .ob-accrow .nm{min-width:0;overflow:hidden;}
  .ob-accrow .nm .ct{font-size:13px;font-weight:600;display:block;}
  .ob-accrow .nm .cs{font-size:12px;color:var(--ob-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;}
  .ob-accnew{border-top:1px solid var(--ob-line);margin-top:4px;padding-top:8px;display:flex;flex-direction:column;gap:8px;}
  .ob-accnew .ob-in{height:38px;min-width:0;font-size:14px;border-radius:8px;padding:0 12px;}
  .ob-accnew .ob-mini{height:38px;flex:none;}
  .ob-accnew .ob-in.bad{border-color:var(--ob-danger);}
  .ob-accstep{display:flex;flex-direction:column;gap:8px;}
  /* Loop test: per-step ticks. */
  .ob-lt{display:flex;flex-direction:column;gap:4px;}
  .ob-lt .lts{display:flex;gap:8px;align-items:baseline;font-size:12px;color:var(--ob-dim);}
  .ob-lt .lts .mk{flex:none;width:14px;display:grid;place-items:center;align-self:center;}
  .ob-lt .lts.on .mk{color:var(--ob-ok);} .ob-lt .lts.on .lb{color:var(--ob-text);}
  .ob-lt .lts.off .mk{color:var(--ob-danger);} .ob-lt .lts.pend .mk{color:var(--ob-dim);}
  .ob-ltfix{font-size:12px;color:var(--ob-danger);margin:2px 0 0;}
  /* What [연결] writes (behind 자세히): one row per file, the backup path, the raw lines. */
  .ob-sumrow{background:var(--ob-panel);border:1px solid var(--ob-line);border-radius:8px;padding:8px 12px;}
  .ob-sumrow .fp{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:var(--ob-text);
    word-break:break-all;overflow-wrap:anywhere;margin:0 0 4px;}
  .ob-sumrow .ef{font-size:12px;color:var(--ob-dim);line-height:1.5;margin:0;}
  .ob-sumrow .keep{color:var(--ob-ok);}
  .ob-bkp{display:flex;gap:8px;align-items:center;background:var(--ob-panel2);border-radius:8px;padding:8px 12px;font-size:12px;}
  .ob-bkp .bk{flex:1;min-width:0;}
  .ob-bkp .bk .p{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:var(--ob-text);word-break:break-all;overflow-wrap:anywhere;}
  .ob-bkp .bk .l{color:var(--ob-dim);}
  .ob-diff{white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;font-family:ui-monospace,Consolas,monospace;
    font-size:12px;line-height:1.5;background:var(--ob-panel2);border-radius:8px;padding:8px 12px;margin:0;}
  /* Lock the page behind the full-screen wizard so its content can't add a second scrollbar; the
     scrim itself scrolls (overflow:auto) when a screen is taller than the window. */
  body.ob-open,html:has(body.ob-open){overflow:hidden;}
  body.ob-open .sheet,body.ob-open .pw{z-index:9500;}
  .ob-mini.done{color:var(--ob-ok);border-color:var(--ob-ok);}
  /* Empty-home guide: lives in the app (not in the scrim), so it uses the app's own tokens. */
  .oh{max-width:520px;margin:8px auto 12px;padding:16px 24px 16px;overflow-wrap:anywhere;}
  /* The home page lets its cards span the column; one sentence at a time reads better narrow. */
  .home.first .card.oh{max-width:520px;}
  .oh-top{display:flex;align-items:center;gap:12px;min-height:28px;}
  .oh-h{margin:0;font-size:13px;line-height:1.4;font-weight:600;color:var(--t2);letter-spacing:0;}
  .oh-dots{display:flex;gap:4px;margin-left:auto;}
  .oh-dots i{width:6px;height:6px;border-radius:999px;background:var(--btn-hi);}
  .oh-dots i.ok{background:var(--t3);}
  .oh-dots i.on{background:var(--t1);}
  .oh-q{flex:none;width:28px;height:28px;border-radius:999px;background:var(--btn);color:var(--t2);
    font-size:13px;font-weight:600;display:grid;place-items:center;}
  .oh-q:hover,.oh-q[aria-expanded="true"]{background:var(--btn-hi);color:var(--t1);}
  /* One step at a time. The stage keeps one height, so the card does not jump between steps; a new
     step fades in where it stands (3px, 140ms). It is swapped at once, so a click is never locked out. */
  .oh-stage{min-height:172px;margin-top:8px;display:flex;flex-direction:column;}
  .oh-stage.oh-in{animation:ohIn .14s ease-out;}
  @keyframes ohIn{from{opacity:0;transform:translateY(3px);}to{opacity:1;transform:none;}}
  @keyframes ohFade{from{opacity:0;}to{opacity:1;}}
  @media (prefers-reduced-motion:reduce){.oh-stage.oh-in{animation-name:ohFade;}}
  .oh-trail{display:flex;flex-wrap:wrap;gap:2px 16px;min-height:22px;margin-bottom:4px;}
  .oh-trail:empty{display:none;}
  .oh-ok{display:inline-flex;align-items:center;gap:4px;min-height:22px;font-size:13px;color:var(--t2);border-radius:6px;}
  .oh-ok svg{flex:none;width:13px;height:13px;color:#43c17a;}
  button.oh-ok:hover{color:var(--t1);}
  .oh-t{margin:0;font-size:22px;line-height:1.3;font-weight:700;letter-spacing:-.02em;color:var(--t1);
    word-break:keep-all;text-wrap:balance;}
  .oh-d{margin:6px 0 0;font-size:14px;line-height:1.5;color:var(--t2);word-break:keep-all;}
  .oh-d .oh-ok{font-size:14px;color:var(--t2);}
  .oh-say{margin-top:12px;background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:8px 16px;
    font-size:15px;line-height:1.5;color:var(--t1);user-select:all;}
  .oh-go{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin-top:auto;padding-top:16px;}
  .oh-go .btn{min-width:112px;}
  .oh-go .btn.done{color:#43c17a;}
  /* The last step has nothing to press: where the button would be, it says what is happening. */
  .oh-wait{display:inline-flex;align-items:center;height:38px;margin-right:6px;font-size:14px;color:var(--t2);}
  .oh-back{height:38px;min-width:52px;padding:0 12px;border-radius:var(--r-btn);font-size:14px;color:var(--t3);}
  .oh-back:hover{color:var(--t1);background:var(--btn);}
  .oh-help{margin-top:16px;padding:12px 16px;border-radius:8px;background:var(--btn);font-size:13px;line-height:1.6;color:var(--t2);}
  .oh-help b{color:var(--t1);font-weight:600;}
  .oh-help p{margin:0;}
  .oh-help p+p{margin-top:8px;}
  .oh-code{margin-top:6px;background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:8px 12px;}
  .oh-code code{display:block;min-width:0;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;
    font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.55;color:var(--t1);}
  .oh-btns{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;}
  .oh-btns .btn{flex:none;}
  .oh-btns .btn.done{color:#43c17a;}
  .oh-act{display:flex;margin-top:16px;padding-top:8px;border-top:1px solid var(--line);}
  .oh-lnk{min-height:28px;font-size:13px;color:var(--t3);border-radius:6px;}
  .oh-lnk:hover{color:var(--t1);}
  @media (pointer:coarse),(max-width:520px){.oh-go .btn,.oh-back,.oh-wait{height:44px;}.oh-back{min-width:60px;}.oh-q{width:44px;height:44px;}.oh-ok,.oh-lnk{min-height:44px;}
    .oh-stage{min-height:200px;}}
  .ob-home{max-width:560px;margin:8px auto;}
  .ob-home .ob-steps{display:grid;gap:8px;margin:16px 0;}
  .ob-home .ob-step{display:flex;gap:12px;align-items:flex-start;}
  .ob-home .ob-num{flex:none;width:26px;height:26px;border-radius:999px;background:var(--fg,#222);color:#fff;
    display:grid;place-items:center;font-size:13px;font-weight:600;}
  @media (prefers-reduced-motion:reduce){
    .ob-scrim{transition:opacity .2s ease;}
    .ob-adv summary::after{transition:none;}
  }`;

  function injectCSS() {
    if (document.getElementById("ob-css")) return;
    const s = document.createElement("style");
    s.id = "ob-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }

  // ---------------------------------------------------------------- helpers
  const E = (s) => (window.esc ? esc(s) : String(s == null ? "" : s)
    .replace(/[&<>"]/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c])));
  const say = (m) => { if (window.toast) toast(m); };
  const I = (k) => (typeof ic === "function" ? ic(k) : "");     // the app's Phosphor set (v2.js)
  let cliPrefix = "loop";                          // real path of the CLI, from /api/onboard
  const PUSH_CMD = () => cliPrefix + " " + tl("onboard.pushargs");
  const SAY_CLAUDE = () => tl("onboard.tellsent");

  // step: "name" | "folder" | "agent". agk: the agent screen on show ("claude", "codex",
  // or "none" while neither is installed). only: the agent screens opened on their own (home card,
  // 설정). again: the wizard replayed from 설정 on a PC that finished it before.
  let state = {step: "name", agk: null, profile: "", root: "", work_mode: "auto", only: null, again: false};
  let keyHandler = null;
  // The sample's name, cached from /api/onboard so nothing here hard-codes it (the motion-graphic
  // sample may rename it). Falls back until the API answers.
  let sampleProject = "샘플", sampleItem = "Genok 로고 타이틀";
  function cacheSample(st) {
    if (st && st.sample_project) sampleProject = st.sample_project;
    if (st && st.sample_item) sampleItem = st.sample_item;
    if (st && st.cli) cliPrefix = st.cli;
  }

  // ---------------------------------------------------------------- wizard shell
  function buildScrim() {
    injectCSS();
    const scrim = document.createElement("div");
    scrim.className = "ob-scrim"; scrim.id = "ob-wizard";
    document.body.appendChild(scrim);
    document.body.classList.add("ob-open");
    // The wizard owns the keyboard: Tab used to walk out into the screen behind the scrim. The
    // window buttons, toasts and sheets opened on top of it stay reachable.
    scrim.setAttribute("role", "dialog"); scrim.setAttribute("aria-modal", "true");
    scrim._held = [...document.body.children].filter((c) => c !== scrim && !c.inert && !c.matches("#toast,.sheet,.wtbar,.cs-scrim,script"));
    scrim._held.forEach((c) => { c.inert = true; });
    const gone = new MutationObserver(() => { if (!scrim.isConnected) { gone.disconnect(); scrim._held.forEach((c) => { c.inert = false; }); } });
    gone.observe(document.body, {childList: true});
    // Esc = the previous screen (it closes only what can be closed: the agent screens opened on
    // their own, or a replay). Enter = the main button, from a text field or from nothing.
    keyHandler = (e) => {
      if (!document.body.contains(scrim) || e.defaultPrevented) return;
      if (document.querySelector(".cs-scrim,.sheet.on")) return;      // a dialog above answers first
      const t = e.target && e.target.closest ? e.target : null;
      if (e.key === "Escape") {
        e.preventDefault();
        if (!goBack(scrim) && (state.only || state.again)) dismiss(scrim);
      } else if (e.key === "Enter" && !e.isComposing) {
        if (t && t.closest("button,a,summary,textarea,select")) return;
        if (t && t.matches("input") && !t.hasAttribute("data-ob-enter")) return;
        const pri = scrim.querySelector("[data-ob-pri]");
        if (pri && !pri.disabled) { e.preventDefault(); pri.click(); }
      }
    };
    document.addEventListener("keydown", keyHandler);
    requestAnimationFrame(() => scrim.classList.add("in"));
    return scrim;
  }

  function openWizard(st) {
    cacheSample(st);
    Object.assign(state, {profile: st.profile || "", root: st.location || "", work_mode: st.work_mode || "auto",
      step: "name", agk: null, only: null, again: !!st.onboarded});
    seen.clear();
    agReady = readAgents(false).catch(() => {});      // asked while the welcome shows
    drawStep(buildScrim());
  }

  // The top row: back (an icon, absent on the first screen), the step dots, and the language
  // switch - or the close button where closing is possible.
  const DOT_AT = {name: 0, folder: 0, agent: 1};
  function top() {
    const back = canBack()
      ? `<button class="ob-ibtn" data-ob-back aria-label="${E(tl("onboard.back"))}" title="${E(tl("onboard.back"))}">${I("back")}</button>` : `<span></span>`;
    let n = DOT_AT[state.step], total = 2;
    if (state.only) { total = route().length; n = Math.max(0, route().indexOf(state.agk)); }
    const dots = total > 1 ? `<span class="ob-dots" role="img" aria-label="${n + 1}/${total}">${Array.from({length: total}, (_, i) =>
      `<i class="${i === n ? "on" : i < n ? "ok" : ""}"></i>`).join("")}</span>` : `<span></span>`;
    const end = state.only || state.again
      ? `<button class="ob-ibtn" data-ob-close aria-label="${E(tl("ui.close"))}" title="${E(tl("ui.close"))}">${I("x")}</button>`
      : (typeof langSeg === "function" ? langSeg("ob-lang") : `<span></span>`);
    return `<div class="ob-top">${back}${dots}${end}</div>`;
  }

  // Draw one screen. `v`: {key, icon, cls, title, sub, body, pri, sec} - title/sub/body/pri/sec are
  // HTML. The same screen drawn again with nothing changed is left alone (typed text, open folds
  // and focus stay); only a change of screen fades.
  function shell(scrim, v) {
    const html = `<div class="ob-col">${top()}
      <div class="ob-stage"><div class="ob-ico ${v.cls || ""}">${v.icon || ""}</div>
        <h1 class="ob-h">${v.title || ""}</h1>${v.sub ? `<p class="ob-desc">${v.sub}</p>` : ""}
        <div class="ob-body">${v.body || ""}</div></div>
      <div class="ob-acts"${v.pri ? "" : " hidden"}>${v.pri || `<span class="ob-btn"></span>`}<div class="ob-sec">${v.sec || ""}</div></div></div>`;
    if (scrim._html === html) return false;
    const moved = scrim.dataset.obKey !== v.key;
    const had = moved || scrim.contains(document.activeElement);
    scrim._html = html; scrim.dataset.obKey = v.key;
    scrim.innerHTML = html;
    if (moved) scrim.querySelector(".ob-stage").classList.add("in");
    wireChrome(scrim);
    if (moved) scrim.scrollTop = 0;
    if (had) {
      const f = scrim.querySelector("[data-ob-focus]") || scrim.querySelector("[data-ob-pri]");
      if (f) { try { f.focus({preventScroll: true}); } catch { /* not focusable yet */ } }
    }
    return true;
  }

  function canBack() {
    if (state.step === "folder") return true;
    if (state.step !== "agent") return false;
    return !state.only || route().indexOf(state.agk) > 0;
  }

  // Back walks the same screens in reverse. false: there is nothing before this one.
  function goBack(scrim) {
    if (!canBack()) return false;
    if (state.step === "folder") state.step = "name";
    else {
      const r = route(), i = r.indexOf(state.agk);
      if (i > 0) { state.step = "agent"; state.agk = r[i - 1]; }
      else state.step = "name";
    }
    drawStep(scrim);
    return true;
  }

  function wireChrome(scrim) {
    const back = scrim.querySelector("[data-ob-back]");
    if (back) back.onclick = () => goBack(scrim);
    const close = scrim.querySelector("[data-ob-close]");
    if (close) close.onclick = () => dismiss(scrim);
  }

  function drawStep(scrim) {
    if (state.step === "name") return stepName(scrim);
    if (state.step === "folder") return stepFolder(scrim);
    return stepAgents(scrim);
  }

  // Screen 1 - the welcome. Nothing is typed: the name it used to ask for only fed the greeting,
  // and an empty box kept people from going on (user, 2026-10-13).
  function stepName(scrim) {
    shell(scrim, {key: "name", cls: "brand",
      icon: `<span class="ob-mark"><rl-orb class="ob-orb" state="breathing" size="26" px="24" aria-label=""></rl-orb>Genok</span>`,
      title: E(tl("onboard.hello")),
      pri: `<button class="ob-btn" id="ob-next" data-ob-pri>${E(tl("onboard.next"))}</button>`,
      sec: `<button class="ob-link" id="ob-root">${E(tl("onboard.rootchange"))}</button>`});
    const next = scrim.querySelector("#ob-next");
    scrim.querySelector("#ob-root").onclick = () => { state.step = "folder"; drawStep(scrim); };
    next.onclick = async () => {
      // The agents were asked when the wizard opened; the answer decides which screens come next.
      const old = next.textContent;
      next.disabled = true; next.classList.add("busy");
      const slow = setTimeout(() => { next.textContent = tl("connect.checking"); }, 400);
      await within(agReady, 9000);
      clearTimeout(slow);
      next.disabled = false; next.classList.remove("busy"); next.textContent = old;
      if (state.step !== "name" || !document.body.contains(next)) return;
      state.step = "agent"; state.agk = null;
      drawStep(scrim);
    };
  }

  // The data folder. Not a step: it keeps its default (Documents/Genok) unless the person opens
  // this from the name screen's quiet button. [확인] saves and goes back there.
  function stepFolder(scrim) {
    const hasPicker = !!(window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder);
    shell(scrim, {key: "folder", icon: I("folder"),
      title: `<label for="ob-path">${E(tl("onboard.s2label"))}</label>`,
      body: `<div class="ob-pathrow big">
        <input class="ob-in" id="ob-path" data-ob-focus data-ob-enter autocomplete="off" spellcheck="false" placeholder="${E(tl("onboard.pathph"))}" value="${E(state.root)}">
        <button class="ob-mini" id="ob-pick">${E(tl("onboard.pick"))}</button></div>`,
      pri: `<button class="ob-btn" id="ob-next" data-ob-pri>${E(tl("onboard.rootok"))}</button>`});
    const path = scrim.querySelector("#ob-path");
    // A long folder path cut at the front hides the part that matters (its last folder).
    requestAnimationFrame(() => { path.scrollLeft = path.scrollWidth; });
    scrim.querySelector("#ob-pick").onclick = async () => {
      if (hasPicker) {
        // Nothing came back (cancelled, or the dialog could not open): the field takes a typed
        // or pasted path too, so put the caret there.
        let p = null;
        try { p = await window.pywebview.api.pick_folder(); } catch { /* no dialog */ }
        if (p) path.value = p; else path.focus();
      } else path.focus();
    };
    scrim.querySelector("#ob-next").onclick = async (e) => {
      const btn = e.currentTarget, root = path.value.trim();
      if (root && root !== state.root) {
        btn.disabled = true;
        try { const r = await post("/api/onboard/location", {root}); state.root = r.root; }
        catch (err) { say(err.message); btn.disabled = false; return; }
      }
      state.step = "name"; drawStep(scrim);
    };
  }

  // ---------------------------------------------------------------- 에이전트 연결
  // Agent-neutral: Claude Code and Codex are equal, one per screen. Detection, the consent and the
  // result all live inside the wizard; nothing opens behind the scrim.
  // Every read here gives up after a while (null): a CLI that hangs must not hold the step.
  const timedJson = (url, ms) => {
    const c = new AbortController(), k = setTimeout(() => c.abort(), ms);
    return fetch(url, {cache: "no-store", signal: c.signal}).then((r) => r.json()).catch(() => null)
      .finally(() => clearTimeout(k));
  };
  const within = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r(null), ms))]);
  const cliStatus = (agent, dir) =>
    timedJson("/api/cli/status?agent=" + agent + (dir ? "&dir=" + encodeURIComponent(dir) : ""), 10000);

  // Text only, no vendor logos: Anthropic's and OpenAI's trademark guidelines both require prior
  // written permission to show their marks (see the m8-connectui commit message).
  const AGENTS = [
    {k: "claude", name: () => tl("onboard.claude"), install: "https://code.claude.com/docs/en/setup",
     installBtn: () => tl("onboard.ccinstall"), sub: () => tl("onboard.agsub_claude")},
    {k: "codex", name: () => tl("onboard.codex"), install: "https://developers.openai.com/codex/cli",
     installBtn: () => tl("onboard.codexinstall"), sub: () => tl("onboard.agsub_codex")},
  ];
  const agentOf = (k) => AGENTS.find((a) => a.k === k);
  const dot = (k) => `<span class="agd${k === "codex" ? " cx" : ""}" aria-hidden="true"></span>`;

  let agScrim = null;                        // the live agent step, for focus re-check
  let agReady = null;                        // the read started when the wizard opened
  let agKnown = false;                       // agInfo holds an answer
  const agSt = {};                           // last real CLI answer per agent
  const agInfo = {};                         // per agent: {st, det, pending, step, plan}
  const seen = new Set();                    // agent screens this run has shown (they stay in the route)
  const just = {};                           // per agent: what [연결] answered (undo token, checks)
  let applying = false;                      // an [연결] / 되돌리기 press is running: no redraw under it

  // Coming back from a terminal (focus) re-checks so a completed login/connect updates the screen.
  // One check at a time and at most one per 1.5 s: a burst of focus events (a window that opens,
  // closes, flashes) queues a single re-check instead of stacking CLI calls.
  window.addEventListener("focus", () => {
    if (!agScrim || !document.body.contains(agScrim) || state.step !== "agent") return;
    if (!agBusy && Date.now() - agDoneAt < 1500) return;
    renderAgents(agScrim, true);
  });

  // The one step an agent is on: install -> login -> connect (Claude Code) / check (Codex) -> done.
  // "unsure" = the CLI did not answer, so we do not claim logged out.
  function agentStep(a, st, pending) {
    if (!st.installed) return "install";
    if (st.unsure && !st.logged_in) return "unsure";
    if (!st.logged_in) return "login";
    // Codex: signed in is enough to talk; 연결됨 only after the pressed test turn got a reply.
    if (a.k === "codex") return st.talked ? "done" : "check";
    if (!(pending && pending.length === 0)) return "connect";
    return "done";
  }

  // Which agent screens there are, in order. Opened on its own: both. In the first run only what
  // needs a press: a connected agent is passed, and so is one that is not installed while the other
  // is (it can be added later in 설정). Neither installed: one screen that offers both.
  function agentRoute(info, only, shown) {
    const ks = AGENTS.map((a) => a.k);
    if (only) return ks;
    const step = (k) => (info[k] || {}).step;
    if (ks.every((k) => step(k) === "install")) return ["none"];
    return ks.filter((k) => shown.has(k) || (step(k) !== "done" && step(k) !== "install"));
  }
  const route = () => agentRoute(agInfo, state.only, seen);

  // Both agents' status side by side, each bounded. No answer (or "the CLI was slow") keeps the
  // last real answer; with none yet the screen says the check is late - never "설치 안 됨" for
  // something we could not ask.
  async function readAgents(fresh) {
    const conn = window.LOOP_CONNECT;
    const [claude, codex] = await Promise.all([
      cliStatus("claude"), cliStatus("codex"),
      fresh && conn ? within(conn.refresh(), 12000) : null,
    ]);
    const byAgent = {claude, codex};
    for (const a of AGENTS) {
      const got = byAgent[a.k];
      if (got && !(got.unsure && agSt[a.k] && !agSt[a.k].unsure)) agSt[a.k] = got;
      const st = agSt[a.k] || {installed: true, logged_in: false, unsure: "slow"};
      const det = conn && st.installed ? await within(conn.detected(a.k), 12000) : null;
      const pending = conn && st.installed && st.logged_in ? ((await within(conn.pendingPieces(a.k), 12000)) || []) : null;
      const step = agentStep(a, st, pending);
      // What [연결] would write, read ahead (a dry run) so the screen that asks can say it.
      let plan = (agInfo[a.k] || {}).plan || null;
      if (step !== "connect") plan = null;
      else if (!plan || fresh) { try { plan = await within(post("/api/connect/plan", {agent: a.k}), 8000); } catch { plan = null; } }
      agInfo[a.k] = {st, det, pending, step, plan};
    }
    agKnown = true;
  }

  function stepAgents(scrim) {
    agScrim = scrim;
    if (!agKnown) shell(scrim, {key: "ag-wait", icon: I("plug"),
      title: `<span class="ob-connecting"><rl-orb state="connecting" size="20" aria-label=""></rl-orb><span>${E(tl("onboard.connecting"))}</span></span>`});
    else paintAgent(scrim);
    // A login window opened from here: the shared watch (web/connect.js) re-checks, the screen follows.
    if (window.LOOP_CONNECT) window.LOOP_CONNECT.onwatch = () => { if (agScrim && document.body.contains(agScrim) && state.step === "agent") renderAgents(agScrim); };
    renderAgents(scrim);
  }

  let agBusy = false, agAgain = false, agDoneAt = 0;   // one re-check at a time
  let accData = null, accAt = 0, accBusy = false;      // other accounts: read in the background

  // One pass at a time. A call that arrives mid-check asks for one more pass afterwards; the
  // [다시 확인] buttons always come back, whatever the check did.
  async function renderAgents(scrim, fresh) {
    agScrim = scrim;
    if (agBusy) { agAgain = true; return; }
    agBusy = true;
    try {
      await readAgents(fresh);
      if (state.only) loadAccounts();
      if (document.body.contains(scrim) && state.step === "agent" && !applying) paintAgent(scrim);
    }
    catch (e) { /* keep what is on screen */ }
    finally {
      agBusy = false; agDoneAt = Date.now();
      scrim.querySelectorAll("[data-ag-recheck]").forEach((b) => { b.disabled = false; b.textContent = tl("connect.recheck"); });
      if (agAgain) { agAgain = false; setTimeout(() => { if (document.body.contains(agScrim) && state.step === "agent") renderAgents(agScrim, true); }, 0); }
    }
  }

  // The accounts list asks each account folder's CLI who is signed in. It is never waited on:
  // the screen draws from the last list and is redrawn if a new one differs.
  function loadAccounts() {
    if (accBusy || Date.now() - accAt < 15000) return;
    accBusy = true;
    timedJson("/api/cli/accounts", 20000).then((d) => {
      accAt = Date.now();
      if (!d || JSON.stringify(d) === JSON.stringify(accData)) return;
      accData = d;
      if (agScrim && document.body.contains(agScrim) && state.step === "agent") renderAgents(agScrim);
    }).finally(() => { accBusy = false; });
  }

  // Show the current agent screen - or walk on when nothing is left to show.
  function paintAgent(scrim) {
    const r = route();
    if (!r.includes(state.agk)) state.agk = r[0] || null;
    if (!state.agk) return setupDone(scrim);
    if (state.agk !== "none") seen.add(state.agk);
    if (shell(scrim, agentView(state.agk))) wireAgents(scrim);
  }

  function goNext(scrim) {
    const r = route(), i = r.indexOf(state.agk);
    if (i >= 0 && i < r.length - 1) { state.agk = r[i + 1]; return paintAgent(scrim); }
    if (state.only) return dismiss(scrim);
    setupDone(scrim);
  }

  // One agent screen. The title names the agent (with its colour dot), the dim line says the one
  // thing this press does, and the technical names (hook, skill, MCP, file paths) wait behind 자세히.
  function agentView(k) {
    const last = state.only && route().indexOf(k) === route().length - 1;
    const fwd = (quiet) => quiet
      ? `<button class="ob-link" data-ob-fwd>${E(state.only ? (last ? tl("ui.close") : tl("onboard.next")) : tl("onboard.nextnoconn"))}</button>`
      : `<button class="ob-btn" data-ob-fwd data-ob-pri>${E(last ? tl("ui.close") : tl("onboard.next"))}</button>`;
    const recheck = (pri) => pri
      ? `<button class="ob-btn" data-ag-recheck data-ob-pri>${E(tl("connect.recheck"))}</button>`
      : `<button class="ob-link" data-ag-recheck>${E(tl("connect.recheck"))}</button>`;
    if (k === "none") {
      // Neither agent is on this PC. Both are offered, equal; one is enough.
      return {key: "ag-none", icon: I("dl"), title: E(tl("onboard.needT")), sub: E(tl("onboard.needD")),
        body: AGENTS.map((a) => `<a class="ob-row" href="${a.install}" target="_blank" rel="noopener">${dot(a.k)}<span class="nm">${E(a.name())}</span>
          <span class="go">${E(a.installBtn())}${I("ext")}</span></a>`).join(""),
        pri: recheck(true), sec: fwd(true)};
    }
    const a = agentOf(k), {st, det, pending, step, plan} = agInfo[k];
    const name = a.name(), conn = window.LOOP_CONNECT;
    const title = (text) => dot(k) + E(text);
    const tk = (k === "codex" && conn && conn.talk) || {};
    // The signed-in account, as the CLI itself reports it. "ChatGPT로 로그인" → "ChatGPT".
    const planName = (st.label || "").replace(/\s*(으로|로)?\s*로그인$/, "").trim();
    const who = st.installed && st.logged_in ? [st.account, planName].filter(Boolean) : [];
    const acct = who.length ? `<div class="ob-row acct"${st.account ? ` title="${E(st.account)}"` : ""}>${I("people")}<span class="nm">${who.map(E).join(" · ")}</span></div>` : "";
    const more = state.only ? agentMore(a, st, det, step === "done") : "";
    const v = {key: "ag-" + k + "-" + step, icon: I("plug")};
    if (step === "install") {
      const guide = conn && conn.installGuide ? conn.installGuide(k, false, false) : "";
      Object.assign(v, {icon: I("dl"), title: title(tl("onboard.instT", {name})), sub: E(tl("onboard.instD")),
        body: guide ? `<details class="ob-adv" data-keep="how-${k}"><summary>${E(tl("connect.how"))}</summary><div class="ob-xbody">${guide}</div></details>` : "",
        pri: `<a class="ob-btn" data-ob-pri href="${a.install}" target="_blank" rel="noopener">${E(a.installBtn())}${I("ext")}</a>`,
        sec: recheck(false) + fwd(true)});
    } else if (step === "unsure") {
      // The CLI did not answer in time. Say that, and offer the one thing that helps.
      Object.assign(v, {icon: I("clock"), title: title(tl("onboard.agq", {name})), sub: E(tl("onboard.agslowhint")),
        body: more, pri: recheck(true), sec: fwd(true)});
    } else if (step === "login") {
      // data-cnlogin is pressed through web/connect.js: bounded, never left disabled.
      Object.assign(v, {icon: I("lock"), title: title(tl("onboard.loginT", {name})),
        sub: E(k === "codex" ? tl("onboard.cxloginhint") : tl("onboard.ccloginhint")), body: more,
        pri: `<button class="ob-btn" data-cnlogin="${k}" data-ob-pri>${E(tl("onboard.cclogin"))}</button>`,
        sec: (state.only ? recheck(false) : "") + fwd(true)});
    } else if (step === "check") {
      // Signed in. One press sends one short line to Codex (web/connect.js presses it, bounded);
      // 연결됨 comes only from a reply. A failed press says why, with Codex's own line.
      const err = tk.error ? `<p class="ob-aghint warn">${E(tk.error)}</p>${tk.detail ? `<pre class="cnterm">${E(tk.detail)}</pre>` : ""}` : "";
      Object.assign(v, {title: title(tl("onboard.agq", {name})), sub: E(tl("connect.cx_note")), body: acct + (conn && conn.permissionIntro ? conn.permissionIntro() : "") + err + more,
        pri: `<button class="ob-btn" data-cxcheck data-ob-perms="1" data-ob-pri>${E(tl("connect.cx_btn"))}</button>`, sec: fwd(true)});
    } else if (step === "connect") {
      // The consent, on the screen that has the button: how many files, that the originals are
      // backed up, and every path and line behind 자세히. Nothing is written before [연결].
      const files = (plan && plan.files) || [];
      const allNew = files.length > 0 && files.every((f) => f.effect === "new");
      const sub = !files.length ? tl("onboard.agdesc")
        : (allNew ? tl("onboard.cxnewn", {n: files.length}) : tl("onboard.cxone", {n: files.length}))
          + (files.some((f) => f.backup_path) ? " " + tl("onboard.cxsub") : "");
      Object.assign(v, {title: title(tl("onboard.agq", {name})), sub: E(sub),
        body: acct + (conn && conn.permissionIntro ? conn.permissionIntro() : "") + planFold(a, plan) + `<p class="ob-note ob-bad" id="ob-cxerr" role="alert" hidden></p>` + more,
        pri: `<button class="ob-btn" id="ob-apply" data-ag-apply="${k}" data-ob-pri>${E(tl("onboard.cxapply"))}</button>`,
        sec: fwd(true)});
    } else {
      // Connected. Right after a press here: what was checked, and a one-press undo.
      const res = just[k], ver = (res && res.verify) || {};
      const verified = res ? [ver.backup_saved !== false ? tl("onboard.cxvbackup") : "",
        ver.kept_count ? tl("onboard.cxvkept", {n: ver.kept_count}) : ""].filter(Boolean).join(" · ") : "";
      const test = state.only && k === "claude"
        ? `<button class="ob-link" data-ag-test="${k}">${E(tl("connect.test"))}</button>` : "";
      Object.assign(v, {icon: I("check"), cls: "ok", title: title(tl("onboard.cxdone", {name})),
        sub: E(verified || (k === "codex" && tk.just ? tl("connect.cx_just") : "")),
        body: acct + `<div class="ob-lt" data-ag-lt="${k}" hidden></div>` + more, pri: fwd(false),
        sec: (res && res.undo_token ? `<button class="ob-link" id="ob-undo" data-ag-undo="${k}">${E(tl("onboard.cxundo"))}</button>` : "") + test});
    }
    return v;
  }

  // What [연결] writes, closed behind 자세히: one row per file, the backup path (shown BEFORE
  // applying), what the added lines do, and the raw lines themselves (read when it is opened).
  function planFold(a, plan) {
    const files = (plan && plan.files) || [];
    const bkp = files.find((f) => f.backup_path);
    const rows = files.map((f) => {
      let eff;
      if (f.effect === "new") eff = E(tl("onboard.cxnew"));
      else {
        eff = E(tl("onboard.cxappend", {n: f.added_lines || 0}));
        if (f.existing_count) {
          const names = (f.existing_kept || []).slice(0, 4).map(E).join(", ");
          eff += `<br><span class="keep">${E(tl("onboard.cxkeep", {n: f.existing_count}))}${names ? " (" + names + ")" : ""}</span>`;
        }
      }
      return `<div class="ob-sumrow"><p class="fp">${E(f.path)}</p><p class="ef">${eff}</p></div>`;
    }).join("");
    const backup = bkp ? `<div class="ob-bkp"><span class="bk">
      <div class="l">${E(tl("onboard.cxbackup"))}</div><div class="p">${E(bkp.backup_path)}</div></span>
      <button class="ob-mini" data-ob-reveal="${E(bkp.backup_path)}">${E(tl("onboard.cxopen"))}</button></div>` : "";
    return `<details class="ob-adv" data-keep="plan-${a.k}" data-ag-plan="${a.k}"><summary>${E(tl("onboard.cxmore"))}</summary><div class="ob-xbody">
      ${plan && plan.reassure ? `<p class="ob-note">${E(tl("onboard.reassure"))}</p>` : ""}${rows}${backup}
      <p class="ob-note">${E(tl("onboard.cxscope", {name: a.name()}))} ${E(a.k === "codex" ? tl("onboard.cxwarncodex") : tl("onboard.cxwarn"))}</p>
      <pre class="ob-diff" data-ag-diff hidden></pre></div></details>`;
  }

  // Opened on its own (home card, 설정): the parts, reading past conversations and the other
  // accounts, all behind one fold. The first run shows none of this.
  function agentMore(a, st, det, connected) {
    if (!st.installed) return "";
    const pcs = (det && det.pieces) || {};
    const guide = a.k === "claude" ? "skill" : "agents_md";
    const onOff = (k) => (pcs[k] || {}).present === true;
    const prow = (label, k, opt) => `<div class="ob-xrow"><span class="ct">${E(label)}</span>
      <span class="xst ${onOff(k) ? "on" : ""}">${E(opt && !onOff(k) ? tl("onboard.optional") : onOff(k) ? tl("onboard.pon") : tl("onboard.poff"))}</span></div>`;
    // Reading this agent's past conversations (pressed through web/connect.js): without it a
    // signed-in agent's conversations do not show in the app.
    const rd = window.LOOP_CONNECT && window.LOOP_CONNECT.reads ? window.LOOP_CONNECT.reads(a.k) : null;
    const reads = st.logged_in && rd !== null ? `<div class="ob-xrow"><span class="ct">${E(tl("connect.flow.read"))}</span>${rd
      ? `<span class="xst on">${E(tl("connect.flow.granted"))}</span>`
      : `<button class="ob-mini" data-cncons="grant/${a.k}">${E(tl("connect.flow.grant"))}</button>`}</div>` : "";
    const accounts = `<details class="ob-adv" data-acc-box="${a.k}" data-keep="acc-${a.k}"><summary>${E(tl("onboard.agaccounts"))}</summary>
      <div class="ob-xbody">${accountsBody(a, st, connected, accData, det)}</div></details>`;
    return `<details class="ob-adv" data-keep="det-${a.k}"><summary>${E(tl("onboard.agdetails"))}</summary><div class="ob-xbody">
      <p class="ob-aghint">${E(a.sub())}</p>
      ${det ? prow(tl("onboard.pc_hook"), "hook") + prow(tl("onboard.pc_guide"), guide) : ""}
      ${pcs.mcp ? prow(tl("onboard.agextras"), "mcp", true) + `<p class="ob-aghint">${E(tl("onboard.mcpextra_d"))}</p>` : ""}
      ${reads}
      ${st.version || (det && det.version) ? `<p class="ob-aghint">v${E(st.version || det.version)}</p>` : ""}
      ${accounts}</div></details>`;
  }

  // 다른 계정: the main account as a friendly row, other config dirs found on this PC with one-click
  // [추가], and a guided two-step "새 계정 추가" (name → log in → 연결하기). Paths only in tooltips.
  function accountsBody(a, st, connected, accData, det) {
    const home = (det && det.home) || "";
    const same = (p, q) => !!p && !!q && p.replace(/[\/]+$/, "").toLowerCase() === q.replace(/[\/]+$/, "").toLowerCase();
    const mine = ((accData && accData.accounts) || []).filter((x) => x.agent === a.k && !same(x.dir, home));
    const mainBits = [st.account || "", connected ? tl("connect.on") : tl("onboard.badge_detected")].filter(Boolean);
    const main = `<div class="ob-accrow" title="${E(home)}"><span class="nm"><span class="ct">${E(tl("onboard.accmain"))}</span>
      <span class="cs">${mainBits.map(E).join(" · ")}</span></span></div>`;
    const rows = mine.map((x) => `<div class="ob-accrow" title="${E(x.dir)}"><span class="nm">
        <span class="ct">${E(x.name.replace(/^\./, ""))}</span><span class="cs">${E(x.account || tl("onboard.accnotlogged"))}</span></span>
        ${x.registered ? `<span class="ob-acctag">${E(tl("onboard.accregistered"))}</span>`
          : `<button class="ob-mini" data-acc-reg data-agent="${E(x.agent)}" data-dir="${E(x.dir)}">${E(tl("onboard.accregister"))}</button>`}</div>`).join("");
    return `<p class="ob-aghint">${E(tl("onboard.accdesc"))}</p>
      ${main}${rows || `<p class="ob-aghint dim2">${E(tl("onboard.accnone"))}</p>`}
      <div class="ob-accnew" data-acc-new="${a.k}">
        <p class="ob-seclabel">${E(tl("onboard.accadd"))}</p>
        <div class="ob-pathrow">
          <input class="ob-in" data-acc-name="${a.k}" placeholder="${E(tl("onboard.accaddname"))}" autocomplete="off" spellcheck="false">
          <button class="ob-mini" data-acc-next="${a.k}">${E(tl("onboard.accnext"))}</button>
        </div>
        <p class="ob-aghint" data-acc-namehint="${a.k}">${E(tl("onboard.accaddhint", {dir: "~/." + a.k + "-work"}))}</p>
        <div class="ob-accstep" data-acc-step="${a.k}" hidden></div>
      </div>`;
  }

  function wireAgents(scrim) {
    // (The login button is data-cnlogin and Codex's check is data-cxcheck, pressed through web/connect.js.)
    scrim.querySelectorAll("[data-ob-fwd]").forEach((b) => b.onclick = () => goNext(scrim));
    scrim.querySelectorAll("[data-ag-recheck]").forEach((b) => b.onclick = async () => {
      b.disabled = true; b.textContent = tl("connect.checking");
      accAt = 0;                                      // a pressed re-check re-reads the accounts too
      await renderAgents(scrim, true);                // bounded; its finally brings the button back
    });
    scrim.querySelectorAll("[data-ag-apply]").forEach((b) => b.onclick = () => applyAgent(scrim, b));
    scrim.querySelectorAll("[data-ag-undo]").forEach((b) => b.onclick = () => undoAgent(scrim, b));
    scrim.querySelectorAll("[data-ag-test]").forEach((b) => b.onclick = () => runLoopTest(scrim, b.dataset.agTest));
    const reveal = scrim.querySelector("[data-ob-reveal]");
    if (reveal) reveal.onclick = () => post("/api/connect/reveal", {path: reveal.dataset.obReveal}).catch(() => {});
    // The raw lines are read when 자세히 is first opened (a preview; it writes nothing).
    scrim.querySelectorAll("[data-ag-plan]").forEach((d) => d.addEventListener("toggle", async () => {
      const pre = d.querySelector("[data-ag-diff]"), conn = window.LOOP_CONNECT;
      if (!d.open || !pre || pre.dataset.read || !(conn && conn.previewAll)) return;
      pre.dataset.read = "1";
      let diff = "";
      try { diff = await conn.previewAll(d.dataset.agPlan); } catch { /* the rows above still say it */ }
      if (diff) { pre.textContent = diff; pre.hidden = false; }
    }));
    // Account register / add (Pro-gated on the server; the settings write asks consent first).
    scrim.querySelectorAll("[data-acc-reg]").forEach((b) => b.onclick = async () => {
      b.disabled = true;
      try {
        const r = await send2("/api/cli/account/register", {agent: b.dataset.agent, dir: b.dataset.dir});
        if (r && r.declined) { b.disabled = false; return; }
        b.textContent = tl("onboard.accregistered");
      } catch (err) { say(err.message); b.disabled = false; }
    });
    // Keep a fold open (and a started "새 계정 추가") across a redraw.
    scrim.querySelectorAll("[data-keep]").forEach((d) => d.addEventListener("toggle", () => {
      if (d.open) accOpen.add(d.dataset.keep); else accOpen.delete(d.dataset.keep);
    }));
    accOpen.forEach((k) => { const d = scrim.querySelector(`[data-keep="${k}"]`); if (d) d.open = true; });
    // Step 1: a name → the folder it will use (nothing is created yet).
    scrim.querySelectorAll("[data-acc-next]").forEach((b) => b.onclick = async () => {
      const k = b.dataset.accNext, name = scrim.querySelector(`[data-acc-name="${k}"]`);
      // An email here is the common mix-up: the sign-in comes in the next step, this is a folder.
      if (name && name.value.includes("@")) {
        name.classList.add("bad"); name.focus();
        const h = scrim.querySelector(`[data-acc-namehint="${k}"]`);
        if (h) { h.textContent = tl("onboard.accnoemail"); h.classList.add("warn"); }
        return;
      }
      b.disabled = true;
      try {
        const r = await post("/api/cli/account/add", {agent: k, name: (name && name.value.trim()) || "", dry: true});
        accFlow = {agent: k, dir: r.dir, name: r.name, phase: "ready"};
        drawAccStep(scrim);
      } catch (err) { say(err.message); }
      b.disabled = false;
    });
    drawAccStep(scrim);
  }

  // Step 2 of "새 계정 추가": open a login terminal scoped to the new folder, poll until that folder
  // has a signed-in account, then [연결하기] installs the hook there (same as [추가]).
  let accFlow = null, accPoll = 0;
  const accOpen = new Set();
  function drawAccStep(scrim) {
    const f = accFlow;
    if (!f) return;
    const box = scrim.querySelector(`[data-acc-step="${f.agent}"]`);
    if (!box) return;
    box.hidden = false;
    const folder = `<p class="ob-aghint" title="${E(f.dir)}">${E(tl("onboard.accfolder", {dir: "~/" + f.name}))}</p>`;
    const act = f.phase === "ready"
      ? `<button class="ob-mini pri wide" data-acc-open>${E(tl("onboard.accloginopen"))}</button>`
      : f.phase === "wait"
      ? `<p class="ob-aghint">${E(tl("onboard.accwait"))}</p><button class="ob-mini wide" data-acc-open>${E(tl("onboard.accloginopen"))}</button>`
      : f.phase === "in"
      ? `<p class="ob-aghint ok">${E(tl("onboard.accloginok"))}${f.account ? " · " + E(f.account) : ""}</p>
         <button class="ob-mini pri wide" data-acc-conn>${E(tl("onboard.agconnect"))}</button>`
      : `<div class="ob-agdone"><span aria-hidden="true">${ic("check")}</span>${E(tl("connect.on"))}</div>`;
    box.innerHTML = folder + act;
    const open = box.querySelector("[data-acc-open]");
    if (open) open.onclick = async () => {
      open.disabled = true;
      try {
        const r = await send2("/api/cli/account/add", {agent: f.agent, name: f.name.replace(/^\.[a-z]+-/, "")});
        if (r && r.declined) { open.disabled = false; return; }
        f.dir = r.dir || f.dir; f.phase = "wait"; drawAccStep(scrim); pollAcc(scrim);
      } catch (err) { say(err.message); open.disabled = false; }
    };
    const conn = box.querySelector("[data-acc-conn]");
    if (conn) conn.onclick = async () => {
      conn.disabled = true;
      try {
        const r = await send2("/api/cli/account/register", {agent: f.agent, dir: f.dir});
        if (r && r.declined) { conn.disabled = false; return; }
        f.phase = "done"; drawAccStep(scrim);
      } catch (err) { say(err.message); conn.disabled = false; }
    };
  }
  const send2 = (url, json) => window.loopFetch ? window.loopFetch(url, {json}) : post(url, json);
  function pollAcc(scrim) {
    const f = accFlow, my = ++accPoll;
    const tick = async () => {
      if (my !== accPoll || !f || f.phase !== "wait" || !document.body.contains(scrim)) return;
      const st = await cliStatus(f.agent, f.dir);
      if (st && st.logged_in) { f.phase = "in"; f.account = st.account || ""; drawAccStep(scrim); return; }
      setTimeout(tick, 3000);
    };
    setTimeout(tick, 3000);
  }

  // O7 — a real, per-agent loop test with a ✓/✗ per step. The server runs it entirely in a hidden
  // sandbox: it never wakes or messages a real session, never spends the wake cap, never touches
  // real items. On failure it shows the failing step and a one-line fix.
  async function runLoopTest(scrim, agent) {
    const box = scrim.querySelector(`[data-ag-lt="${agent}"]`);
    if (!box) return;
    box.hidden = false;
    box.innerHTML = `<div class="lts pend"><span class="mk">…</span><span class="lb">${E(tl("connect.testing"))}</span></div>`;
    let r;
    try { r = await post("/api/connect/looptest", {agent}); }
    catch (e) { box.innerHTML = `<div class="lts off"><span class="mk">${ic("x")}</span><span class="lb">${E(e.message || tl("connect.testfail"))}</span></div>`; return; }
    const steps = (r && r.steps) || [];
    const rows = steps.map((s) => {
      const cls = s.ok === true ? "on" : s.ok === false ? "off" : "pend";
      const mk = s.ok === true ? ic("check") : s.ok === false ? ic("x") : "·";
      return `<div class="lts ${cls}"><span class="mk">${mk}</span><span class="lb">${E(s.label)}${s.detail ? " · " + E(s.detail) : ""}</span></div>`;
    }).join("");
    const failed = steps.find((s) => s.ok === false);
    box.innerHTML = rows + (failed && failed.fix ? `<p class="ob-ltfix">${E(failed.fix)}</p>` : "");
    // A fix that is "connect again": the screen re-reads, and shows [연결] if a part is missing.
    if (failed && failed.fix_action === "connect") renderAgents(scrim, true);
  }

  // ---------------------------------------------------------------- [연결] (O10 / O11)
  // The press that writes. The server backs up, applies, verifies and restores on failure; the
  // screen then proves nothing was lost (backup saved, earlier items still there) and offers a
  // one-press 되돌리기.
  async function applyAgent(scrim, btn) {
    const agent = btn.dataset.agApply, conn = window.LOOP_CONNECT, old = btn.textContent;
    const err = scrim.querySelector("#ob-cxerr");
    const others = scrim.querySelectorAll(".ob-sec button");
    applying = true;
    btn.disabled = true; btn.classList.add("busy"); btn.textContent = tl("onboard.cxapplying");
    others.forEach((b) => { b.disabled = true; });
    if (err) err.hidden = true;
    const fail = (msg) => {
      applying = false;
      say(msg);
      if (err) { err.textContent = msg; err.hidden = false; }
      btn.disabled = false; btn.classList.remove("busy"); btn.textContent = old;
      others.forEach((b) => { b.disabled = false; });
    };
    let res;
    try { res = await applyConnect(agent); }
    catch (x) { return fail(x.message); }
    if (res && res.ok === false) {
      if (conn && conn.seed) conn.seed(res.state);
      applying = false;
      say(tl("onboard.cxfail"));
      return renderAgents(scrim, true);
    }
    try { await settleConnected(agent, res && res.state); }
    catch (x) { return fail(x.message); }
    just[agent] = res || {};
    applying = false;
    // First run: no "connected" screen. One line says it, the restore moves to 설정 › 연결, and the
    // walk goes on. Opened from 설정 the done screen stays (it is where the check lives).
    if (!state.only) {
      if (conn && conn.keepUndo) conn.keepUndo(agent, res && res.undo_token);
      say(tl("onboard.cxdoneat", {name: agentOf(agent).name()}));
      return goNext(scrim);
    }
    await renderAgents(scrim);
  }

  async function undoAgent(scrim, btn) {
    const agent = btn.dataset.agUndo, res = just[agent];
    if (!res || !res.undo_token) return;
    applying = true; btn.disabled = true;
    try {
      const r = await post("/api/connect/undo", {token: res.undo_token});
      if (window.LOOP_CONNECT && window.LOOP_CONNECT.seed) window.LOOP_CONNECT.seed(r && r.state);
      delete just[agent];
      say(tl("onboard.cxundone"));
    }
    catch (err) { say(err.message); }
    applying = false;
    if (document.body.contains(btn)) btn.disabled = false;
    await renderAgents(scrim, true);
  }

  // The screen used to be drawn from the detect cached BEFORE the change, so it read 연결 안 됨 and
  // only flipped on the next focus re-check. Adopt apply-all's own fresh detect, then re-detect until
  // this agent really reads connected; the caller keeps its loading state all the while.
  async function settleConnected(agent, fresh, ms = 12000) {
    const conn = window.LOOP_CONNECT;
    if (!conn) return;
    if (fresh && conn.seed) conn.seed(fresh);
    const until = Date.now() + ms;
    for (;;) {
      const left = await conn.pendingPieces(agent);
      if (Array.isArray(left) && left.length === 0) return;
      if (Date.now() > until) throw new Error(tl("onboard.cxslow"));
      await new Promise((r) => setTimeout(r, 600));
      await conn.refresh();
    }
  }

  // Prefer the safety-checked apply-all (backs up, verifies, restores on failure). Fall back to the
  // per-piece applyAll if the endpoint is not there yet.
  async function applyConnect(agent) {
    let result;
    try { result = await post("/api/connect/apply-all", {agent}); }
    catch (e) {
      if (!window.LOOP_CONNECT || !window.LOOP_CONNECT.applyAll) throw e;
      await window.LOOP_CONNECT.applyAll(agent);
      result = {ok: true};
    }
    if (result && result.ok === false) return result;
    await post("/api/connect/perms", {agent, all: 1});
    return result;
  }

  // The agent screens were the last ones: setup is saved and the home takes over. Its first-use
  // card is where the sample tour is offered.
  async function setupDone(scrim) {
    await finish();
    closeScrim(scrim, () => refreshHome());
  }

  // Setup is over: the home greets by the name just typed.
  async function refreshHome() {
    try { if (typeof load === "function") await load(); if (typeof render === "function") render(); } catch { /* the next refresh shows it */ }
  }

  // The sample in the guided tour (it re-creates the sample if it is missing). `then` runs when
  // the tour ends or is skipped.
  function startTour(then) {
    const after = () => { if (typeof then === "function") then(); };
    if (window.LOOP_TOUR && window.LOOP_TOUR.start) {
      try { window.LOOP_TOUR.start({onExit: after}); return; } catch { /* fall through */ }
    }
    after();
  }

  // Persist "done". Called only by setupDone.
  async function finish() {
    obMemo = null;
    try { await post("/api/onboard/done", {profile: state.profile, work_mode: state.work_mode}); }
    catch (err) { say(err.message); }
  }

  // Close without finishing: only where that is possible - the agent screens opened on their own
  // (setup is already done), or a replay from 설정.
  function dismiss(scrim) {
    closeScrim(scrim, () => fillConnState());
  }

  function closeScrim(scrim, then) {
    if (keyHandler) { document.removeEventListener("keydown", keyHandler); keyHandler = null; }
    document.body.classList.remove("ob-open");
    (scrim._held || []).forEach((c) => { c.inert = false; });
    if (window.LOOP_REPAINT) window.LOOP_REPAINT.rescueBody(document);
    scrim.classList.remove("in");
    let ran = false;
    const done = () => { if (ran) return; ran = true; if (scrim.parentNode) scrim.remove(); if (then) then(); };
    scrim.addEventListener("transitionend", done, {once: true});
    setTimeout(done, 400);                    // in case transitionend never fires
  }

  // A language switch (the header's 한국어 / English) redraws the open screen in place.
  window.addEventListener("loop-lang", () => {
    const scrim = document.getElementById("ob-wizard");
    if (scrim) drawStep(scrim);
  });

  // Re-open the wizard on demand (the 시작하기 chips in 설정 call this).
  window.LOOP_ONBOARD = {
    open() {
      if (document.getElementById("ob-wizard")) return;
      fetch("/api/onboard").then((r) => r.json()).then(openWizard).catch(() => openWizard({}));
    },
    // The home card's [연결하기]: the same agent screens (and the same fresh detection) as setup,
    // opened at once so the click always shows something; closing returns to the card.
    connect(opts) {
      if (document.getElementById("ob-wizard")) return;
      // From settings > connect > accounts: land with the "other accounts" folds already open.
      if (opts && opts.accounts) ["det-claude", "acc-claude", "det-codex", "acc-codex"].forEach((k) => accOpen.add(k));
      Object.assign(state, {step: "agent", agk: null, only: "agents", again: false});
      drawStep(buildScrim());
    },
    // /api/onboard, shared for 10s: the boot check below and tour.js's home card read the same answer.
    state() {
      if (!obMemo || Date.now() - obAt > 10000) {
        obAt = Date.now();
        obMemo = fetch("/api/onboard").then((r) => r.json());
        obMemo.catch(() => { obMemo = null; });
      }
      return obMemo;
    },
    // For tests: which agent screens a first run shows.
    route: agentRoute, step: agentStep,
  };
  let obMemo = null, obAt = 0;

  // The button itself says "복사됨" for a moment, so the click is never silent.
  async function copyText(b, text) {
    let ok = true;
    try { await navigator.clipboard.writeText(text); } catch { ok = false; say(text); }
    if (!ok) return false;
    const old = b.dataset.label || b.textContent;
    b.dataset.label = old; b.textContent = tl("onboard.copiedbtn"); b.classList.add("done");
    clearTimeout(b._t);
    b._t = setTimeout(() => { b.textContent = old; b.classList.remove("done"); }, 1600);
    return true;
  }

  // The guide used to end the moment the first result landed, before the person had left a
  // comment - the one thing the app is for. Home keeps one line until that result is opened.
  window.LOOP_HOME_FIRST = function () {
    // One result only: a guide step left over on a PC that has long been in use must not bring this back.
    const items = D.items.filter((x) => x.sample !== true);
    if (items.length !== 1 || ohStored() !== OH_STEPS - 1) return "";
    const x = items[0];
    return `<section class="permcard" aria-label="${E(tl("onboard.firstT"))}"><div class="permit"><div class="tx"><span class="t">${E(tl("onboard.firstT"))}</span><span class="s">${E(tl("onboard.firstD"))}</span></div>
      <div class="acts"><button class="btn sm fill press" data-item="${E(iid(x))}" data-oh-first>${E(tl("onboard.firstGo"))}</button></div></div></section>`;
  };
  document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("[data-oh-first]")) { ohAt = 0; ohSave(0); } }, true);

  // ---------------------------------------------------------------- empty-home fallback
  window.LOOP_HOME_EMPTY = function () {
    injectCSS();
    const items = (window.D && D.items) || [];
    // Old installs may still hold the previous sample ("표지 시안").
    const sampleTitles = [sampleItem, "Genok 로고 타이틀", "Genok logo title", "Genok 소개 영상", "리뷰 루프 소개 영상", "표지 시안"];
    const sample = items.find((x) => x.sample === true || (sampleTitles.includes(x.title)
      && (x.project === sampleProject || x.dept === sampleProject || String(x.id || "").indexOf(sampleProject) === 0)));
    // Real work is present: leave the app's own quiet empty card alone. The guide is over, so a
    // later empty home starts it from the top.
    if (items.length && !(items.length === 1 && sample)) { if (ohStored() !== 0) { ohAt = 0; ohSave(0); } return null_card(); }
    const btn = sample
      ? `<button class="oh-lnk press" data-ob-sample="remove">${E(tl("onboard.sampleremove"))}</button>`
      : `<button class="oh-lnk press" data-ob-sample="add">${E(tl("onboard.sampleadd"))}</button>`;
    const known = window.LOOP_CONNECT && window.LOOP_CONNECT.cached ? window.LOOP_CONNECT.cached() : null;
    const n = ohStep(known);
    fillConnState();
    // The long parts (what a session is, the terminal command) wait behind the "?" button.
    return `<div class="card oh"><div class="oh-top"><h2 class="oh-h">${E(tl("onboard.homeTitle"))}</h2>
        <span class="oh-dots" data-oh-dots role="img" aria-label="${n + 1}/${OH_STEPS}">${ohDots(n)}</span>
        <button class="oh-q press" data-oh-q aria-expanded="${ohHelp}" aria-label="${E(tl("onboard.ohMore"))}">?</button></div>
      <div class="oh-stage" data-oh-stage data-oh-key="${E(ohKey(known))}" aria-live="polite">${ohStage(known)}</div>
      <div class="oh-help" data-oh-help${ohHelp ? "" : " hidden"}><p><b>${E(tl("onboard.ohOldT"))}</b> ${E(tl("onboard.ohOldD"))}</p>
        <div class="oh-code"><code>${E(SAY_CLAUDE())}</code>
          <div class="oh-btns"><button class="btn sm press" data-ob-copy="${E(SAY_CLAUDE())}">${E(tl("onboard.copy"))}</button></div></div>
        <p>${E(tl("onboard.bycmd"))}</p><div class="oh-code"><code>${E(PUSH_CMD())}</code>
          <div class="oh-btns"><button class="btn sm press" data-ob-copy="${E(PUSH_CMD())}">${E(tl("onboard.copy"))}</button></div></div></div>
      <div class="oh-act">${btn}</div></div>`;
  };
  // ---- one step at a time, all inside this app: connect -> start a chat here with the first line -> the result shows up here.
  // The step is remembered in this browser; the connection itself is always read fresh.
  const OH_STEPS = 3, OH_ROOM = "genok-guide-room", OH_KEY = "genok-guide-step";
  const OH_CHECK = `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7"/></svg>`;
  let ohAt = null;        // the step the person is on (null until first read)
  let ohHeld = false;     // stepped back to "connect" on purpose: do not jump ahead again
  let ohFail = false;     // the detect did not answer
  let ohHelp = false;     // the "?" panel is open
  function ohStored() {
    try { return Math.min(OH_STEPS - 1, Math.max(0, parseInt(localStorage.getItem(OH_KEY), 10) || 0)); } catch { return 0; }
  }
  function ohRoom() { try { return localStorage.getItem(OH_ROOM) || ""; } catch { return ""; } }
  // The last step waits for a result. After OH_LATE without one it stops saying "waiting" and
  // says where to look, so a session that never pushed does not leave the person watching dots.
  const OH_SINCE = "genok-guide-wait", OH_LATE = 180000;
  let ohLateTimer = 0;
  function ohLate(n) {
    try {
      if (n !== OH_STEPS - 1) { localStorage.removeItem(OH_SINCE); return false; }
      const at = parseInt(localStorage.getItem(OH_SINCE), 10) || Date.now();
      localStorage.setItem(OH_SINCE, String(at));
      const left = at + OH_LATE - Date.now();
      if (left <= 0) return true;
      clearTimeout(ohLateTimer); ohLateTimer = setTimeout(() => ohDraw(), left + 300);
    } catch { /* private window: it keeps saying waiting */ }
    return false;
  }
  function ohSave(n) { try { localStorage.setItem(OH_KEY, String(n)); } catch { /* private window: this page only */ } }
  // Codex is on this PC and Claude Code is not: the paste step must not send the person to a Claude app.
  function codexOnly(d) {
    return !!(d && d.codex && d.codex.installed && d.claude && !d.claude.installed);
  }
  // Real connection state (read from the config files, not guessed). "Connected" means what the
  // setup cards mean: logged in and every REQUIRED piece present. MCP is an optional extra, so
  // counting it (as this once did) read a connected Claude Code as not connected.
  function connOn(d) {
    return ["claude", "codex"].filter((k) => {
      const a = d && d[k];
      if (!a || !a.installed || a.logged_in === false) return false;
      // Codex is up once signed in and a test turn got a reply (v2.js connKind says the same).
      if (k === "codex") return a.logged_in === true && !!a.talked;
      const req = a.required || Object.keys(a.pieces || {}).filter((p) => p !== "mcp");
      return req.every((p) => ((a.pieces || {})[p] || {}).present === true);
    });
  }
  const connNames = (on) => on.map((k) => tl(k === "claude" ? "connect.claude" : "connect.codex")).join(", ");
  // Which step to show. Known to be unconnected: nothing after "connect" can work, so it stays there.
  // Already connected: "connect" is passed without a click.
  function ohStep(d) {
    if (ohAt === null) ohAt = ohStored();
    if (!d) return ohAt;
    if (!connOn(d).length) return 0;
    if (ohAt === 0 && !ohHeld) { ohAt = 1; ohSave(1); }
    return ohAt;
  }
  const ohDots = (n) => Array.from({length: OH_STEPS}, (_, i) => `<i class="${i === n ? "on" : i < n ? "ok" : ""}"></i>`).join("");
  // What the stage shows depends on exactly this; the same key means nothing to redraw.
  function ohKey(d) {
    return [ohStep(d), ohLate(ohStep(d)) ? "late" : "", d ? connOn(d).join("+") || "off" : "?", codexOnly(d) ? "cx" : "", ohFail ? "fail" : "", window.I18N_LANG || ""].join("|");
  }
  function ohStage(d) {
    const n = ohStep(d), on = d ? connOn(d) : null, cx = codexOnly(d);
    const linked = on && on.length ? tl("onboard.hsOn", {names: connNames(on)}) : "";
    // Steps already passed: one short line each, pressed to go back there.
    const ok = (to, text) => `<button class="oh-ok press" data-oh-go="${to}">${OH_CHECK}${E(text)}</button>`;
    const trail = (n > 0 && linked ? ok(0, n === 1 ? linked : tl("onboard.ohLinked")) : "") + (n > 1 ? ok(1, tl("onboard.ohStarted")) : "");
    const main = (attr, text) => `<button class="btn fill press" ${attr}>${E(text)}</button>`;
    const back = n > 0 ? `<button class="oh-back press" data-oh-go="${n - 1}">${E(tl("onboard.ohBack"))}</button>` : "";
    let t = "", dsc = "", body = "", go = "";
    if (n === 0) {
      t = tl("onboard.ohConnT");
      if (linked) { dsc = `<span class="oh-ok">${OH_CHECK}${E(linked)}</span>`; go = main('data-oh-go="1"', tl("onboard.ohNext")); }
      else if (ohFail) { dsc = E(tl("onboard.hsFail")); go = main("data-oh-recheck", tl("connect.recheck")); }
      else { dsc = d ? "" : E(tl("onboard.hsChecking")); go = main("data-oh-goconnect", tl("onboard.ohConnect")); }
    } else if (n === 1) {
      // The composer opens with this line already in the box; sending it there is what moves on.
      t = tl("onboard.ohSayT");
      dsc = E(tl("onboard.ohSayD"));
      body = `<div class="oh-say">${E(SAY_CLAUDE())}</div>`;
      go = main(`data-oh-start="${cx ? "codex" : "claude"}"`, tl("onboard.ohStart"));
    } else {
      t = tl("onboard.ohSeeT");
      dsc = E(tl("onboard.ohSeeD"));
      // true: the home redraws by itself when a result lands. Until then the chat is one press away.
      go = (ohRoom() ? main("data-oh-room", tl("onboard.ohRoom")) : "") + `<span class="oh-wait">${E(ohLate(n) ? tl("onboard.ohLate") : tl("onboard.ohWait"))}</span>`;
    }
    return `<div class="oh-trail">${trail}</div><h3 class="oh-t">${E(t)}</h3>${dsc ? `<p class="oh-d">${dsc}</p>` : ""}${body}
      <div class="oh-go">${go}${back}</div>`;
  }
  // Redraw the stage in place. Only a change of step fades; a late detect answer on the same step
  // (확인 중 -> 연결하기) just lands. Focus follows to the new step's button, so Enter keeps going.
  function ohDraw(focus) {
    const d = window.LOOP_CONNECT && window.LOOP_CONNECT.cached ? window.LOOP_CONNECT.cached() : null;
    document.querySelectorAll("[data-oh-stage]").forEach((st) => {
      const key = ohKey(d);
      if (st.dataset.ohKey === key) return;
      const moved = st.dataset.ohKey.split("|")[0] !== key.split("|")[0], had = focus || st.contains(document.activeElement);
      st.dataset.ohKey = key;
      st.innerHTML = ohStage(d);
      const dots = st.parentNode.querySelector("[data-oh-dots]");
      if (dots) { dots.innerHTML = ohDots(ohStep(d)); dots.setAttribute("aria-label", `${ohStep(d) + 1}/${OH_STEPS}`); }
      if (moved) { st.classList.remove("oh-in"); void st.offsetWidth; st.classList.add("oh-in"); }
      if (had) { const f = st.querySelector(".oh-go .btn") || st.querySelector(".oh-back"); if (f) f.focus({preventScroll: true}); }
    });
  }
  function ohGo(n, focus) {
    ohAt = Math.min(OH_STEPS - 1, Math.max(0, n));
    ohHeld = ohAt === 0;
    ohSave(ohAt);
    ohDraw(focus);
  }
  // The card is returned as a string, so the stage is corrected once it is in the page. It draws
  // the last known state at once, then always re-detects (a connect elsewhere may have changed it);
  // a timeout turns a detect that never answers into a visible line with 다시 확인, never an endless 확인 중.
  function fillConnState(tries = 0) {
    if (!document.querySelector("[data-oh-stage]")) { if (tries < 40) setTimeout(() => fillConnState(tries + 1), 50); return; }
    const conn = window.LOOP_CONNECT;
    const fail = () => {
      ohFail = !(conn && conn.cached && conn.cached());                // a known state is kept as it is
      ohDraw();
    };
    if (!conn) return fail();
    let timer = 0;
    const late = new Promise((r) => { timer = setTimeout(() => r(null), 15000); });
    Promise.race([conn.refresh(), late]).then((d) => {
      clearTimeout(timer);
      if (!d) return fail();
      ohFail = false; ohDraw();
    });
  }
  function null_card() {
    return `<div class="card plan none"><p>${E(tl("inboxDo.3"))}</p></div>`;
  }

  // ---------------------------------------------------------------- delegated actions (home guide)
  document.addEventListener("click", async (e) => {
    const copy = e.target.closest("[data-ob-copy]");
    if (copy && !copy.closest(".ob-scrim")) {   // scrim copies are wired directly
      await copyText(copy, copy.dataset.obCopy);
      return;
    }
    const to = e.target.closest("[data-oh-go]");
    if (to) { ohGo(+to.dataset.ohGo); return; }
    const q = e.target.closest("[data-oh-q]");
    if (q) {
      ohHelp = !ohHelp;
      q.setAttribute("aria-expanded", String(ohHelp));
      const h = q.closest(".oh").querySelector("[data-oh-help]");
      if (h) h.hidden = !ohHelp;
      return;
    }
    const go = e.target.closest("[data-oh-goconnect]");
    if (go) {
      // Answer within the frame: the pressed state, then the agent step itself (it shows its own
      // loading line while it detects). `window.nav` never existed, so this used to do nothing.
      go.disabled = true; go.classList.add("busy");
      try { if (window.LOOP_ONBOARD && window.LOOP_ONBOARD.connect) window.LOOP_ONBOARD.connect(); }
      finally { setTimeout(() => { go.disabled = false; go.classList.remove("busy"); }, 600); }
      return;
    }
    const again = e.target.closest("[data-oh-recheck]");
    if (again) {
      ohFail = false; ohDraw();                 // back to 확인 중 while it asks again
      fillConnState();
      return;
    }
    const st = e.target.closest("[data-oh-start]");
    if (st) {
      // The app's own composer, with the first line in it. Nothing is sent until the person sends it.
      if (typeof window.LOOP_FIRST_LINE !== "function") return;
      st.disabled = true; st.classList.add("busy");
      try { await window.LOOP_FIRST_LINE(SAY_CLAUDE(), st.dataset.ohStart); }
      finally { setTimeout(() => { st.disabled = false; st.classList.remove("busy"); }, 600); }
      return;
    }
    const rm = e.target.closest("[data-oh-room]");
    if (rm) { location.hash = "project/" + encodeURIComponent(ohRoom()); return; }
    const sam = e.target.closest("[data-ob-sample]");
    if (sam) {
      // The sample has no session behind it, so it is only ever shown inside the tour, which
      // builds it on the way in and removes it on every way out.
      if (sam.dataset.obSample === "add") { startTour(); return; }
      const old = sam.textContent;
      sam.disabled = true; sam.classList.add("busy");
      try {
        await post("/api/onboard/sample/remove", {});
        say(tl("onboard.samgone"));
        location.hash = "inbox";
        location.reload();
      } catch (err) {
        say(err.message); sam.textContent = old; sam.disabled = false; sam.classList.remove("busy");
      }
    }
  });

  // A session really took the first line (project.js says so): the guide waits for the result.
  window.addEventListener("loop:session-new", (e) => {
    if (ohAt !== 1) return;
    try { localStorage.setItem(OH_ROOM, (e.detail && e.detail.name) || ""); } catch { /* private window */ }
    ohGo(2);
  });

  // Enter on the guide card itself (not on one of its buttons) presses the step's button.
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.defaultPrevented || !e.target.closest) return;
    const card = e.target.closest(".oh");
    if (!card || e.target.closest("button,a,summary,input,textarea")) return;
    const b = card.querySelector(".oh-go .btn");
    if (b) { e.preventDefault(); b.click(); }
  });

  // ---------------------------------------------------------------- boot: show the wizard once
  (async () => {
    try {
      const st = await window.LOOP_ONBOARD.state();
      // A sample still here on a fresh page is a leftover (the window closed mid-tour): no tour is
      // running, and nothing would answer a comment on it, so it goes before anyone opens it.
      if (st.has_sample) {
        try { await post("/api/onboard/sample/remove", {}); obMemo = null;
          if (typeof load === "function") await load(); if (typeof render === "function") render(); } catch { /* next start clears it */ }
      }
      // A phone that is not registered yet gets a refusal here, not a state: that is not a
      // first run. Show the code entry instead of the PC's setup (which it cannot fill in anyway).
      if (st.need_pair) { try { window.LOOP_PHONE.open({pair: true}); } catch {} return; }
      if (st.error) return;
      cacheSample(st);
      // Setup (name, data folder, agents) is the PC's business: never on a phone over serve.
      const onPc = ["127.0.0.1", "localhost", "::1", ""].includes(location.hostname);
      if (!st.onboarded && onPc) openWizard(st);
    } catch { /* offline or old server: no wizard, the app still runs */ }
  })();
})();
