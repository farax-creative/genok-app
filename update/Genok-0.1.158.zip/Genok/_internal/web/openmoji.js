// OpenMoji dual set: department emoji are drawn from OpenMoji artwork instead of the system emoji
// font, in two looks that swap together. "color" is the full-colour set, "black" the outline set
// (drawn as a mask in the text colour, so it follows the theme). The DOM keeps the original emoji
// text inside <span class="emo">, so copy, search and textContent readers (bulkstart.js) still see
// the character. Emoji without an OpenMoji file are left alone.
//
// Mode: dark theme -> black outlines, light theme -> colour, unless localStorage "v2-emoji" says
// "color" or "black". window.loopEmoji.set(mode|"") changes it; "" goes back to following the theme.
// Artwork: CC BY-SA 4.0, see licenses/openmoji.md. Files: web/emoji/{color,black}/<HEX>.svg.
(function () {
  "use strict";
  const HAVE = new Set("1F0CF 1F195 1F22F 1F300 1F305 1F308 1F310 1F31E 1F31F 1F327 1F331 1F338 1F33F 1F34E 1F35C 1F370 1F373 1F389 1F393 1F399 1F39E 1F3A4 1F3A5 1F3A7 1F3A8 1F3AC 1F3AE 1F3AF 1F3B2 1F3B4 1F3B5 1F3B9 1F3BC 1F3C3 1F3C6 1F3CB 1F3D6 1F3DE 1F3EB 1F3F7 1F408 1F415 1F41B 1F429 1F431 1F436 1F43E 1F440 1F465 1F47E 1F48C 1F4A1 1F4AA 1F4AC 1F4B0 1F4B3 1F4BB 1F4C1 1F4C3 1F4C4 1F4C5 1F4C8 1F4C9 1F4CA 1F4CB 1F4CE 1F4D0 1F4DA 1F4DD 1F4DE 1F4E2 1F4E3 1F4E6 1F4F0 1F4F7 1F4F8 1F4F9 1F4FD 1F501 1F50A 1F50D 1F50E 1F510 1F511 1F512 1F514 1F516 1F524 1F525 1F527 1F529 1F52C 1F52D 1F52E 1F575 1F579 1F58C 1F5A5 1F5BC 1F5C2 1F5C3 1F5C4 1F5D2 1F5D3 1F5E3 1F5FA 1F63A 1F64B 1F64C 1F680 1F686 1F6A8 1F6D2 1F6E0 1F6E1 1F6F0 1F916 1F91D 1F981 1F9B4 1F9CA 1F9D1 1F9E0 1F9E9 1F9EA 1F9ED 1F9EF 1F9F0 1F9F1 1F9F3 1F9F5 1F9FE 1FA79 1FA7A 1FA9F 1FAA7 2328 23F0 2615 2699 26A0 26A1 2705 2708 270F 2728 2757 2764".split(" "));
  const SEL = ".dc-ico,.pjico,.dmk,.vwc-e,.pemo,.dp-emo,.dp-grid button,.dp-sug button,.srt,.tag";
  const root = document.documentElement;
  const RE = new RegExp("(" + [...HAVE].map((h) => String.fromCodePoint(parseInt(h, 16))).join("|") + ")\uFE0F?", "gu");

  const stored = () => { try { const v = localStorage.getItem("v2-emoji"); return v === "color" || v === "black" ? v : ""; } catch { return ""; } };
  const themeDark = () => {
    const t = root.getAttribute("data-theme");
    return t ? t !== "light" : !(window.matchMedia && matchMedia("(prefers-color-scheme: light)").matches);
  };
  const applyMode = () => { root.setAttribute("data-emoji", stored() || (themeDark() ? "black" : "color")); };

  function wrapText(node) {
    const s = node.nodeValue;
    RE.lastIndex = 0;
    if (!RE.test(s)) return;
    RE.lastIndex = 0;
    const frag = document.createDocumentFragment();
    let last = 0, m;
    while ((m = RE.exec(s))) {
      if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
      const hex = m[1].codePointAt(0).toString(16).toUpperCase();
      const sp = document.createElement("span");
      sp.className = "emo";
      sp.setAttribute("aria-hidden", "true");
      sp.style.setProperty("--emo-c", 'url("/emoji/color/' + hex + '.svg")');
      sp.style.setProperty("--emo-k", 'url("/emoji/black/' + hex + '.svg")');
      sp.textContent = m[0];
      frag.appendChild(sp);
      last = m.index + m[0].length;
    }
    if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
    node.parentNode.replaceChild(frag, node);
  }

  function scan(el) {
    if (!el || el.nodeType !== 1) return;
    const hosts = el.matches(SEL) ? [el] : [];
    el.querySelectorAll(SEL).forEach((h) => hosts.push(h));
    for (const h of hosts) {
      const w = document.createTreeWalker(h, NodeFilter.SHOW_TEXT, {
        acceptNode: (n) => (n.parentNode.closest(".emo") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
      });
      const list = [];
      while (w.nextNode()) list.push(w.currentNode);
      list.forEach(wrapText);
    }
  }

  let queued = new Set(), raf = 0;
  const flush = () => { raf = 0; const q = queued; queued = new Set(); q.forEach((n) => { if (n.isConnected) scan(n.nodeType === 1 ? n : n.parentElement); }); };
  const queue = (n) => { queued.add(n); if (!raf) raf = requestAnimationFrame(flush); };

  function start() {
    applyMode();
    new MutationObserver(applyMode).observe(root, { attributes: true, attributeFilter: ["data-theme"] });
    if (window.matchMedia) { try { matchMedia("(prefers-color-scheme: light)").addEventListener("change", applyMode); } catch {} }
    scan(document.body);
    new MutationObserver((muts) => {
      for (const m of muts) {
        if (m.type === "characterData") { if (!(m.target.parentNode && m.target.parentNode.closest(".emo"))) queue(m.target); }
        else m.addedNodes.forEach((n) => { if (n.nodeType === 1 && !n.classList.contains("emo")) queue(n); else if (n.nodeType === 3) queue(n); });
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  window.loopEmoji = {
    has: (ch) => HAVE.has(String(ch).codePointAt(0).toString(16).toUpperCase()),
    set(mode) { try { if (mode) localStorage.setItem("v2-emoji", mode); else localStorage.removeItem("v2-emoji"); } catch {} applyMode(); },
    mode: () => root.getAttribute("data-emoji"),
  };
  if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);
})();
