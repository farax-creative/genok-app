// Thinking-orbs: dotted 3D "thought" orbs that mark what Claude is doing — working, searching,
// listening, connecting, and so on. A vanilla-JS port of thinking-orbs (React canvas component)
// for this app's plain ES-module web/, faithful to the upstream geometry: honestly 3D dots,
// depth-shaded and z-sorted, painted with plain 2D-canvas fills (no ctx.filter, no SVG filters)
// so every mode renders identically across engines.
//
// Ported from thinking-orbs by Jakub Antalik — https://github.com/Jakubantalik/thinking-orbs
//
//   MIT License. Copyright (c) 2026 Jakub Antalik
//   Permission is hereby granted, free of charge, to any person obtaining a copy of this
//   software and associated documentation files (the "Software"), to deal in the Software
//   without restriction, including without limitation the rights to use, copy, modify, merge,
//   publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
//   to whom the Software is furnished to do so, subject to the following conditions:
//   The above copyright notice and this permission notice shall be included in all copies or
//   substantial portions of the Software.
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See licenses/thinking-orbs.md.
//
// Usage in the browser: <rl-orb state="working" size="20"></rl-orb> survives innerHTML and
// self-manages its rAF loop (pausing offscreen / on hidden tabs), reduced-motion (one static
// frame), auto theme (reads the app's data-theme / prefers-color-scheme, live), and aria-label.
// window.Orb also exposes the pure engine (STATES, resolvePreset, computeFrame) and a create()
// factory. In node the pure engine is exported for tests/orb.test.js — no DOM is touched.

(function () {
  "use strict";

  // ---- core primitives (no DOM / no canvas), shared by the renderer and the tests ----------

  function lerp(a, b, f) { return a + (b - a) * f; }
  function frac(x) { return x - Math.floor(x); }

  // Deterministic hash in [0, 1).
  function hashD(a, b) {
    const h = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453;
    return h - Math.floor(h);
  }

  // Value noise on a 2D lattice — smooth, deterministic, cheap.
  function vnoise(x, y) {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    let fx = x - xi;
    let fy = y - yi;
    fx = fx * fx * (3 - 2 * fx);
    fy = fy * fy * (3 - 2 * fy);
    const a = hashD(xi, yi);
    const b = hashD(xi + 1, yi);
    const c = hashD(xi, yi + 1);
    const d = hashD(xi + 1, yi + 1);
    return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
  }

  // Stable directions on a unit sphere (Fibonacci lattice).
  function fibDir(i, n) {
    const golden = Math.PI * (3 - Math.sqrt(5));
    const y = 1 - (2 * (i + 0.5)) / n;
    const rad = Math.sqrt(1 - y * y);
    const a = i * golden;
    return [rad * Math.cos(a), y, rad * Math.sin(a)];
  }

  // Shortest signed angular distance, wrapped to (-π, π].
  function angleDelta(a, b) { return Math.atan2(Math.sin(a - b), Math.cos(a - b)); }

  // Shared spin + tilt + orthographic projection.
  function makeProj(yaw, tilt, cx, cy, scale) {
    const st = Math.sin(tilt);
    const ct = Math.cos(tilt);
    const sy = Math.sin(yaw);
    const cyw = Math.cos(yaw);
    return (x, y, z) => {
      const x1 = x * cyw + z * sy;
      const z1 = -x * sy + z * cyw;
      const y1 = y * ct - z1 * st;
      const z2 = y * st + z1 * ct;
      return [cx + x1 * scale, cy - y1 * scale, z2];
    };
  }

  // Dot radii were tuned for a 300pt frame; sub-linear scaling keeps small orbs legible.
  function radiusScale(size, pow) { return (size / 300) ** pow; }

  // Turn raw mode output into a finished frame: drop invisible marks, clamp radii to the mode's
  // floor, and z-sort far→near into draw order.
  function finalizeFrame(dots, lines, rMin) {
    const floor = rMin == null ? 0.3 : rMin;
    const visible = [];
    for (const d of dots) {
      if ((d.a == null ? 1 : d.a) < 0.02) continue;
      d.r = Math.max(floor, d.r);
      visible.push(d);
    }
    visible.sort((a, b) => a.z - b.z);
    return { dots: visible, lines: lines.filter((l) => (l.a == null ? 1 : l.a) >= 0.02) };
  }

  // ---- density profiles + the multiplier machinery that scales them -------------------------

  const COUNT_PAIRS = [["latRings", "lonDensity"], ["rings", "lonDensity"], ["lanes", "segs"]];
  const COUNT_KEYS = ["orbitN", "ghostN", "nodeN", "strandN", "signals"];
  const ICON_DENSITY_KEYS = ["iconD"];
  const RADIUS_KEYS = ["rBase", "rDepth", "rActive", "rDot", "ghostR", "partR", "partRDepth", "nodeR", "nodeRDepth"];

  function scaleCounts(opts, scale) {
    const out = Object.assign({}, opts);
    const done = new Set();
    const rt = Math.sqrt(scale);
    for (const [a, b] of COUNT_PAIRS) {
      const va = out[a];
      const vb = out[b];
      if (va != null && vb != null && !done.has(a) && !done.has(b)) {
        out[a] = Math.max(2, Math.round(va * rt));
        out[b] = Math.max(2, Math.round(vb * rt));
        done.add(a);
        done.add(b);
      }
    }
    for (const k of COUNT_KEYS) {
      const v = out[k];
      if (v != null && v !== 0 && !done.has(k)) out[k] = Math.max(1, Math.round(v * scale));
    }
    for (const k of ICON_DENSITY_KEYS) {
      const v = out[k];
      if (v != null) out[k] = Math.max(0.02, v * scale);
    }
    return out;
  }

  function scaleRadii(opts, scale) {
    const out = Object.assign({}, opts);
    for (const k of RADIUS_KEYS) {
      const v = out[k];
      if (v != null) out[k] = v * scale;
    }
    out.rSizeMul = (out.rSizeMul == null ? 1 : out.rSizeMul) * scale;
    return out;
  }

  const BASE_PROFILES = {
    globe: { latRings: 17, lonDensity: 44, rBase: 0.6, rDepth: 1.7, rBoost: 1.0, inkFar: 0.62, inkSpan: 0.54, rsPow: 0.6, rMin: 0.3 },
    orbits: { orbitN: 12, ghostN: 40, ghostR: 0.9, ghostA: 0.5, particles: 3, partR: 1.2, partRDepth: 1.6, rsPow: 0.6, rMin: 0.3 },
    rubik: { latRings: 15, lonDensity: 40, moveCount: 14, rBase: 0.6, rDepth: 1.7, rActive: 0.3, inkFar: 0.62, inkSpan: 0.54, rsPow: 0.6, rMin: 0.3 },
    wave: { rings: 15, lonDensity: 40, rBase: 0.6, rDepth: 1.7, rsPow: 0.6, rMin: 0.3 },
    web: { nodeN: 30, thr: 0.72, signals: 5, nodeR: 1.4, nodeRDepth: 1.8, lineW: 0.8, rsPow: 0.6, rMin: 0.3 },
    braid: { strandN: 52, turns: 3.0, ghostN: 150, rBase: 1.2, rDepth: 1.8, rsPow: 0.6, rMin: 0.3 },
    ribbon: { lanes: 5, segs: 88, ghostN: 150, rBase: 1.1, rDepth: 1.7, rsPow: 0.6, rMin: 0.3 },
    ring: { lanes: 5, segs: 88, ghostN: 0, faceOn: 1, rBase: 1.1, rDepth: 1.7, rsPow: 0.6, rMin: 0.3 },
    morph: { rDot: 0.021, iconD: 1, rMin: 0.25 },
  };

  // ---- the mode frames: pure geometry over (size, t, opts) ----------------------------------

  // Orbits: particles on tilted orbits — "working".
  function frameOrbits(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.82;
    const pt = makeProj(t * 0.12, 0.3, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const dots = [];
    const orbitN = o.orbitN == null ? 12 : o.orbitN;
    const ghostN = o.ghostN == null ? 40 : o.ghostN;
    const particles = o.particles == null ? 3 : o.particles;
    for (let orb = 0; orb < orbitN; orb++) {
      const h1 = hashD(orb, 1.7);
      const h2 = hashD(orb, 5.2);
      const h3 = hashD(orb, 8.9);
      const ro = R * (0.45 + 0.52 * h1);
      const th = h1 * 2 * Math.PI;
      const phi = Math.acos(2 * h2 - 1);
      const nx = Math.sin(phi) * Math.cos(th);
      const ny = Math.cos(phi);
      const nz = Math.sin(phi) * Math.sin(th);
      let ux = -ny;
      let uy = nx;
      const uz = 0;
      const ul = Math.max(1e-6, Math.sqrt(ux * ux + uy * uy));
      ux /= ul;
      uy /= ul;
      const vx = ny * uz - nz * uy;
      const vy = nz * ux - nx * uz;
      const vz = nx * uy - ny * ux;
      const speed = (0.25 + 0.55 * h3) * (h3 > 0.5 ? 1 : -1);
      for (let k = 0; k < ghostN; k++) {
        const a = (k / ghostN) * 2 * Math.PI;
        const [px, py, z] = pt(
          (ux * Math.cos(a) + vx * Math.sin(a)) * ro,
          (uy * Math.cos(a) + vy * Math.sin(a)) * ro,
          (uz * Math.cos(a) + vz * Math.sin(a)) * ro
        );
        const depth = (z / ro + 1) / 2;
        dots.push({ x: px, y: py, z, r: (o.ghostR == null ? 0.9 : o.ghostR) * rs, white: 0.72, a: (o.ghostA == null ? 0.5 : o.ghostA) * (0.4 + 0.6 * depth) });
      }
      for (let m = 0; m < particles; m++) {
        const a = t * speed + (m / particles) * 2 * Math.PI + h2 * 6;
        const [px, py, z] = pt(
          (ux * Math.cos(a) + vx * Math.sin(a)) * ro,
          (uy * Math.cos(a) + vy * Math.sin(a)) * ro,
          (uz * Math.cos(a) + vz * Math.sin(a)) * ro
        );
        const depth = (z / ro + 1) / 2;
        dots.push({ x: px, y: py, z, r: ((o.partR == null ? 1.2 : o.partR) + (o.partRDepth == null ? 1.6 : o.partRDepth) * depth) * rs, white: 0.3 - 0.22 * depth });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  // --- shared solver heartbeat (rubik) ---
  function solveCycle(time, count, slotDur, rest) {
    const cyc = 2 * count * slotDur + rest;
    const tc = time % cyc;
    const amount = new Array(count).fill(0);
    let active = -1;
    if (tc < 2 * count * slotDur) {
      const slot = Math.floor(tc / slotDur);
      const p = (tc - slot * slotDur) / slotDur;
      const cl = Math.min(1, p / 0.7);
      const ep = 1 - (1 - cl) ** 3;
      if (slot < count) {
        for (let i = 0; i < slot; i++) amount[i] = 1;
        amount[slot] = ep;
        active = slot;
      } else {
        const u = 2 * count - 1 - slot;
        for (let i = 0; i < u; i++) amount[i] = 1;
        amount[u] = 1 - ep;
        active = u;
      }
    }
    return { amount, active };
  }

  function applyMoves(pt3, moves, sc) {
    let [x, y, z] = pt3;
    let inActive = false;
    for (let i = 0; i < moves.length; i++) {
      if (sc.amount[i] <= 0) continue;
      const mv = moves[i];
      const coord = mv.axis === 0 ? x : mv.axis === 1 ? y : z;
      if (coord < mv.lo || coord >= mv.hi) continue;
      if (i === sc.active) inActive = true;
      const a = mv.ang * sc.amount[i];
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      if (mv.axis === 0) {
        const y2 = y * ca - z * sa;
        z = y * sa + z * ca;
        y = y2;
      } else if (mv.axis === 1) {
        const x2 = x * ca + z * sa;
        z = -x * sa + z * ca;
        x = x2;
      } else {
        const x2 = x * ca - y * sa;
        y = x * sa + y * ca;
        x = x2;
      }
    }
    return [x, y, z, inActive];
  }

  function makeMoves(count) {
    const moves = [];
    for (let i = 0; i < count; i++) {
      const axis = Math.min(2, Math.floor(hashD(i, 2.3) * 3));
      const lo = -1.0 + 0.5 * Math.min(3, Math.floor(hashD(i, 5.9) * 4));
      const dir = hashD(i, 7.7) < 0.5 ? 1 : -1;
      moves.push({ axis, lo, hi: lo + 0.5, ang: (dir * Math.PI) / 2 });
    }
    return moves;
  }

  // Globe: lat/long field, a scan meridian sweeps — "searching".
  function frameGlobe(size, t, o) {
    const spin = 0.5;
    const cx = size / 2;
    const cy = size / 2;
    const radius = (size / 2) * 0.82;
    const tilt = 0.4 + 0.06 * Math.sin(t * 0.35);
    const pt = makeProj(t * spin, tilt, cx, cy, radius);
    const scan = t * (spin + (1.7 - spin) * (o.scanMul == null ? 1 : o.scanMul));
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const dimBase = o.dimBase == null ? 1 : o.dimBase;
    const dots = [];
    const latRings = o.latRings == null ? 17 : o.latRings;
    const lonDensity = o.lonDensity == null ? 44 : o.lonDensity;
    for (let li = 0; li <= latRings; li++) {
      const lat = -Math.PI / 2 + (li / latRings) * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = (lj / lonCount) * 2 * Math.PI;
        const [px, py, z] = pt(cosLat * Math.cos(lon), sinLat, cosLat * Math.sin(lon));
        const depth = (z + 1) / 2;
        const d = angleDelta(lon + t * spin, scan);
        const boost = Math.exp(-(d * d) / 0.18) * Math.max(0, z);
        dots.push({
          x: px, y: py, z,
          r: ((o.rBase == null ? 0.6 : o.rBase) + (o.rDepth == null ? 1.7 : o.rDepth) * depth + (o.rBoost == null ? 1 : o.rBoost) * boost) * rs,
          white: (o.inkFar == null ? 0.62 : o.inkFar) - (o.inkSpan == null ? 0.54 : o.inkSpan) * depth,
          a: dimBase + (1 - dimBase) * Math.min(1, boost),
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  // Rubik: bands twist in quarter turns, scramble → solve — "solving".
  function frameRubik(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.82;
    const pt = makeProj(t * 0.55, 0.35 + 0.1 * Math.sin(t * 0.9), cx, cy, R);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const moveCount = o.moveCount == null ? 14 : o.moveCount;
    const moves = makeMoves(moveCount);
    const sc = solveCycle(t, moveCount, 0.42, 1.2);
    const dots = [];
    const latRings = o.latRings == null ? 15 : o.latRings;
    const lonDensity = o.lonDensity == null ? 40 : o.lonDensity;
    for (let li = 0; li <= latRings; li++) {
      const lat = -Math.PI / 2 + (li / latRings) * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = (lj / lonCount) * 2 * Math.PI;
        const [x, y, z, inActive] = applyMoves([cosLat * Math.cos(lon), sinLat, cosLat * Math.sin(lon)], moves, sc);
        const [px, py, zr] = pt(x, y, z);
        const depth = (zr + 1) / 2;
        dots.push({
          x: px, y: py, z: zr,
          r: ((o.rBase == null ? 0.6 : o.rBase) + (o.rDepth == null ? 1.7 : o.rDepth) * depth + (inActive ? (o.rActive == null ? 0.3 : o.rActive) : 0)) * rs,
          white: (o.inkFar == null ? 0.62 : o.inkFar) - (o.inkSpan == null ? 0.54 : o.inkSpan) * depth - (inActive ? 0.14 : 0),
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  // Wave: a waveform rolls through the rings — "listening".
  function frameWave(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.874;
    const pt = makeProj(t * 0.18, 0.38, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const dots = [];
    const rings = o.rings == null ? 15 : o.rings;
    const lonDensity = o.lonDensity == null ? 40 : o.lonDensity;
    for (let ri = 0; ri <= rings; ri++) {
      const lat = -Math.PI / 2 + (ri / rings) * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const w = 0.62 * Math.sin(t * 2.1 - ri * 0.52) + 0.38 * Math.sin(t * 1.27 + ri * 0.83);
      const rr = R * (0.88 + 0.105 * w);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = (lj / lonCount) * 2 * Math.PI;
        const [px, py, z] = pt(cosLat * Math.cos(lon) * rr, sinLat * rr, cosLat * Math.sin(lon) * rr);
        const depth = (z / R + 1) / 2;
        const crest = Math.max(0, w);
        dots.push({
          x: px, y: py, z,
          r: ((o.rBase == null ? 0.6 : o.rBase) + (o.rDepth == null ? 1.7 : o.rDepth) * depth) * (1 + 0.4 * crest) * rs,
          white: 0.66 - 0.56 * depth - 0.1 * crest,
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  // Web: a constellation wires itself — "connecting".
  function frameWeb(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.8 * (o.spread == null ? 1 : o.spread);
    const pt = makeProj(t * 0.12, 0.32, cx, cy, R);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const nodeN = o.nodeN == null ? 30 : o.nodeN;
    const thr = o.thr == null ? 0.72 : o.thr;
    const nodeR = o.nodeR == null ? 1.4 : o.nodeR;
    const nodeRDepth = o.nodeRDepth == null ? 1.8 : o.nodeRDepth;
    const nodes = [];
    for (let i = 0; i < nodeN; i++) {
      const d = fibDir(i, nodeN);
      const x = d[0] + 0.3 * (vnoise(i * 0.31 + 9, t * 0.24) - 0.5) * 2;
      const y = d[1] + 0.3 * (vnoise(i * 0.53 + 27, t * 0.21) - 0.5) * 2;
      const z = d[2] + 0.3 * (vnoise(i * 0.77 + 55, t * 0.27) - 0.5) * 2;
      const l = Math.sqrt(x * x + y * y + z * z);
      nodes.push([x / l, y / l, z / l]);
    }
    const lines = [];
    const dots = [];
    for (let i = 0; i < nodeN; i++) {
      for (let j = i + 1; j < nodeN; j++) {
        const dx = nodes[i][0] - nodes[j][0];
        const dy = nodes[i][1] - nodes[j][1];
        const dz = nodes[i][2] - nodes[j][2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist >= thr) continue;
        const [x1, y1, z1] = pt(nodes[i][0], nodes[i][1], nodes[i][2]);
        const [x2, y2, z2] = pt(nodes[j][0], nodes[j][1], nodes[j][2]);
        const depth = ((z1 + z2) / 2 + 1) / 2;
        lines.push({ x1, y1, x2, y2, white: 0.42, a: (1 - dist / thr) * (0.3 + 0.55 * depth), w: Math.max(0.6, (o.lineW == null ? 0.8 : o.lineW) * rs) });
      }
    }
    for (let i = 0; i < nodeN; i++) {
      const [px, py, z] = pt(nodes[i][0], nodes[i][1], nodes[i][2]);
      const depth = (z + 1) / 2;
      const pulse = 1 + 0.25 * Math.sin(t * 1.4 + i * 2.7);
      dots.push({ x: px, y: py, z, r: (nodeR + nodeRDepth * depth) * pulse * rs, white: 0.55 - 0.45 * depth });
    }
    const signals = o.signals == null ? 5 : o.signals;
    for (let s = 0; s < signals; s++) {
      const seg = Math.floor(t * 0.55 + s * 7.31);
      const a = Math.floor(hashD(seg, s * 3.1 + 1.7) * nodeN);
      const b = Math.floor(hashD(seg, s * 5.7 + 4.2) * nodeN);
      if (a === b) continue;
      const f = frac(t * 0.55 + s * 7.31);
      const x = lerp(nodes[a][0], nodes[b][0], f);
      const y = lerp(nodes[a][1], nodes[b][1], f);
      const z = lerp(nodes[a][2], nodes[b][2], f);
      const l = Math.max(1e-6, Math.sqrt(x * x + y * y + z * z));
      const [px, py, zr] = pt(x / l, y / l, z / l);
      const depth = (zr + 1) / 2;
      dots.push({ x: px, y: py, z: zr, r: (nodeR * 1.5 + nodeRDepth * depth) * rs, white: 0.05, a: 0.5 + 0.5 * depth });
    }
    return finalizeFrame(dots, lines, o.rMin);
  }

  // Braid: three strands plait around the sphere — "weaving".
  function frameBraid(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.76;
    const pt = makeProj(t * 0.4, 0.3, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const dots = [];
    const ghostN = o.ghostN == null ? 150 : o.ghostN;
    for (let i = 0; i < ghostN; i++) {
      const d = fibDir(i, ghostN);
      const [px, py, z] = pt(d[0] * R, d[1] * R, d[2] * R);
      const depth = (z / R + 1) / 2;
      dots.push({ x: px, y: py, z, r: 0.8 * rs, white: 0.78, a: 0.1 + 0.22 * depth });
    }
    const strandN = o.strandN == null ? 52 : o.strandN;
    const turns = o.turns == null ? 3 : o.turns;
    for (let s = 0; s < 3; s++) {
      const phase = (s / 3) * 2 * Math.PI;
      for (let i = 0; i < strandN; i++) {
        const u = (frac(i / strandN + t * 0.045) * 2 - 1) * 0.96;
        const surf = Math.sqrt(Math.max(0, 1 - u * u));
        const endFade = Math.min(1, (1 - Math.abs(u)) / 0.1);
        const a = u * Math.PI * turns + phase;
        const weave = 1 + 0.075 * Math.sin(u * Math.PI * turns * 2 + phase * 2 + t * 0.8);
        const rr = surf * R * weave;
        const [px, py, zr] = pt(Math.cos(a) * rr, u * R * weave, Math.sin(a) * rr);
        const depth = (zr / R + 1) / 2;
        dots.push({ x: px, y: py, z: zr, r: ((o.rBase == null ? 1.2 : o.rBase) + (o.rDepth == null ? 1.8 : o.rDepth) * depth) * rs, white: 0.55 - 0.45 * depth, a: endFade * (0.45 + 0.55 * depth) });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  // Ribbon: an undulating sash rides a great circle — "composing"; also drives "breathing" (ring)
  // via the faceOn flag.
  function frameRibbon(size, t, o) {
    const cx = size / 2;
    const cy = size / 2;
    const R = (size / 2) * 0.78;
    const spin = o.spin == null ? 1 : o.spin;
    const camTilt = 0.3;
    const pt = makeProj(t * 0.1 * spin, camTilt, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow == null ? 0.6 : o.rsPow);
    const dots = [];
    const ghostN = o.ghostN == null ? 150 : o.ghostN;
    for (let i = 0; i < ghostN; i++) {
      const d = fibDir(i, ghostN);
      const [px, py, z] = pt(d[0] * R, d[1] * R, d[2] * R);
      const depth = (z / R + 1) / 2;
      dots.push({ x: px, y: py, z, r: 0.8 * rs, white: 0.78, a: 0.1 + 0.22 * depth });
    }
    const ya = t * 0.24 * spin;
    const ta = o.faceOn ? -camTilt : 0.55 + 0.3 * Math.sin(t * 0.18) * spin;
    const ux = Math.cos(ya);
    const uy = 0;
    const uz = Math.sin(ya);
    const vx = -uz * Math.sin(ta);
    const vy = Math.cos(ta);
    const vz = ux * Math.sin(ta);
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const wobAmp = 0.23 * (o.wobMul == null ? 1 : o.wobMul);
    const baseR = o.faceOn ? R / (1 + 0.85 * wobAmp) : R;
    const baseLanes = o.lanes == null ? 5 : o.lanes;
    // segMul: more streaks around the ring (the logo's finished density); each keeps its motion.
    const segs = Math.max(2, Math.round((o.segs == null ? 88 : o.segs) * (o.segMul == null ? 1 : o.segMul)));
    const lanes = Math.max(1, Math.round(baseLanes * (o.bandMul == null ? 1 : o.bandMul)));
    // Stroke mode: each radial streak is kept as its chain of lane dots, later drawn as one
    // continuous tapered stroke instead of a pile of overlapping discs.
    const chains = o.stroke ? [] : null;
    for (let w = 0; w < lanes; w++) {
      const laneOff = (w - (lanes - 1) / 2) * 0.075;
      const edge = Math.abs(w - (lanes - 1) / 2) / Math.max(1, (lanes - 1) / 2);
      for (let k = 0; k < segs; k++) {
        const a = (k / segs) * 2 * Math.PI;
        const wob = (0.16 * Math.sin(a * 3 - t * 1.7 + w * 0.22) + 0.07 * Math.sin(a * 5 + t * 1.1)) * (o.wobMul == null ? 1 : o.wobMul);
        const radial = o.faceOn ? 1 + wob : 1;
        const off = o.faceOn ? laneOff : laneOff + wob;
        const x = ux * Math.cos(a) + vx * Math.sin(a) + nx * off;
        const y = uy * Math.cos(a) + vy * Math.sin(a) + ny * off;
        const z = uz * Math.cos(a) + vz * Math.sin(a) + nz * off;
        const l = Math.sqrt(x * x + y * y + z * z);
        const rr = baseR * radial;
        const [px, py, zr] = pt((x / l) * rr, (y / l) * rr, (z / l) * rr);
        const depth = (zr / R + 1) / 2;
        dots.push({
          x: px, y: py, z: zr,
          r: ((o.rBase == null ? 1.1 : o.rBase) + (o.rDepth == null ? 1.7 : o.rDepth) * depth) * (1 - 0.25 * edge) * rs,
          white: 0.52 - 0.44 * depth + 0.18 * edge,
          a: 0.4 + 0.6 * depth,
        });
        if (chains) (chains[k] || (chains[k] = [])).push(dots[dots.length - 1]);
      }
    }
    const frame = finalizeFrame(dots, [], o.rMin);
    if (!chains) return frame;
    const band = new Set();
    const strokes = [];
    for (const ch of chains) {
      if (!ch) continue;
      for (const d of ch) band.add(d);
      // The lanes fold into two halves (either side of the ring's plane); the near half is the
      // visible streak and covers the far one, so it alone defines the stroke.
      const h = ch.length >> 1;
      const lo = ch.slice(0, h).reverse();
      const hi = ch.slice(h);
      const mz = (arr) => arr.reduce((acc, d) => acc + d.z, 0) / Math.max(1, arr.length);
      const near = h === 0 ? ch : (mz(hi) >= mz(lo) ? hi : lo);
      const st = streakStroke(near, cx, cy, o);
      if (st) strokes.push(st);
    }
    strokes.sort((a, b) => a.z - b.z);
    frame.dots = frame.dots.filter((d) => !band.has(d));
    frame.strokes = strokes;
    return frame;
  }

  // One streak (a chain of discs, centre + radius) -> the outline of their smooth envelope: the
  // centre line is the discs' principal axis, the radius follows a least-squares cubic of the
  // discs' radii (keeps the engine's taper, drops the bead-to-bead ripple), and both ends close
  // with true round caps. Colour stops ride along the centre line (0..1) for a linear gradient.
  function streakStroke(chain, cx, cy, o) {
    const n = chain.length;
    if (!n) return null;
    const zAvg = chain.reduce((acc, d) => acc + d.z, 0) / n;
    // The streak's axis: principal direction of the disc centres (the lanes are near-collinear),
    // so the stroke is dead straight and both caps face exactly along it.
    let mx = 0;
    let my = 0;
    for (const d of chain) { mx += d.x / n; my += d.y / n; }
    let sxx = 0;
    let sxy = 0;
    let syy = 0;
    for (const d of chain) { const ex = d.x - mx; const ey = d.y - my; sxx += ex * ex; sxy += ex * ey; syy += ey * ey; }
    const th = 0.5 * Math.atan2(2 * sxy, sxx - syy);
    let ux = Math.cos(th);
    let uy = Math.sin(th);
    const first = chain[0];
    const last = chain[n - 1];
    if ((last.x - first.x) * ux + (last.y - first.y) * uy < 0) { ux = -ux; uy = -uy; }
    const proj = chain.map((d) => (d.x - mx) * ux + (d.y - my) * uy).sort((p, q) => p - q);
    const byS = chain.map((d) => [(d.x - mx) * ux + (d.y - my) * uy, d]).sort((p, q) => p[0] - q[0]);
    const s0 = proj[0];
    const L = proj[n - 1] - s0;
    const rmin = Math.min.apply(null, chain.map((d) => d.r));
    const at = (t) => [mx + ux * (s0 + t), my + uy * (s0 + t)];
    const a0 = at(0);
    const a1 = at(Math.max(L, 1e-3));
    // Ink lift: the finished logo reads brighter than the raw depth shading (white toward 0 =
    // full key colour, alpha toward 1), keeping the engine's near/far ordering.
    const inkLift = o && o.inkLift ? o.inkLift : 0;
    const alphaLift = o && o.alphaLift ? o.alphaLift : 0;
    const stops = byS.map(([sv, d]) => {
      const a = d.a == null ? 1 : d.a;
      return [L > 0 ? (sv - s0) / L : 0, d.white * (1 - inkLift), a + (1 - a) * alphaLift];
    });
    if (n < 2 || L < rmin * 0.05) {
      const r = Math.max.apply(null, chain.map((d) => d.r)) * (o && o.widthMul ? o.widthMul : 1);
      const pts = [];
      for (let i = 0; i < 32; i++) { const q = (i / 32) * 2 * Math.PI; pts.push([mx + Math.cos(q) * r, my + Math.sin(q) * r]); }
      return { pts, a0, a1, stops, z: zAvg };
    }
    const rFit = fitPoly(byS.map((e) => (e[0] - s0) / L), byS.map((e) => e[1].r));
    // Radial taper: the width follows the distance from the ring's centre, so every streak keeps
    // the same share of its angular slot from rim to inner tip and the lines never crowd inward.
    // widthMul: the stroke's width against the discs it replaces (thinner when segMul adds streaks).
    const widthMul = o && o.widthMul ? o.widthMul : 1;
    let rhoMax = 0;
    for (const e of byS) rhoMax = Math.max(rhoMax, Math.hypot(e[1].x - cx, e[1].y - cy));
    const radAt = (t) => {
      const [qx, qy] = at(t);
      const g = rhoMax > 0 ? Math.min(1, Math.hypot(qx - cx, qy - cy) / rhoMax) : 1;
      return Math.max(1e-3, rFit.v(t / L) * g * widthMul);
    };
    const N = Math.max(12, Math.ceil(L / (rmin * 0.2)));
    const left = [];
    const right = [];
    let head = null;
    let tail = null;
    for (let j = 0; j <= N; j++) {
      const t = (j / N) * L;
      const [px, py] = at(t);
      const r = radAt(t);
      const hh = L * 1e-3;
      const dr = Math.max(-0.95, Math.min(0.95, (radAt(Math.min(L, t + hh)) - radAt(Math.max(0, t - hh))) / (Math.min(L, t + hh) - Math.max(0, t - hh))));
      const q = Math.sqrt(1 - dr * dr);
      const lx = -dr * ux - q * uy;
      const ly = -dr * uy + q * ux;
      const rx = -dr * ux + q * uy;
      const ry = -dr * uy - q * ux;
      left.push([px + r * lx, py + r * ly]);
      right.push([px + r * rx, py + r * ry]);
      const rec = { l: [lx, ly], r: [rx, ry], c: [px, py], rad: r };
      if (j === 0) head = rec;
      if (j === N) tail = rec;
    }
    const pts = left.slice();
    capArc(pts, tail.c, tail.rad, tail.l, tail.r, [ux, uy]);
    for (let j = right.length - 1; j >= 0; j--) pts.push(right[j]);
    capArc(pts, head.c, head.rad, head.r, head.l, [-ux, -uy]);
    return { pts, a0, a1, stops, z: zAvg };
  }

  // Round cap: arc of radius r about ctr from normal `from` to normal `to`, sweeping through `via`.
  function capArc(out, ctr, r, from, to, via) {
    const a0 = Math.atan2(from[1], from[0]);
    const a1 = Math.atan2(to[1], to[0]);
    const av = Math.atan2(via[1], via[0]);
    const TAU = 2 * Math.PI;
    const pos = (x) => ((x % TAU) + TAU) % TAU;
    let sweep = pos(a1 - a0);
    if (pos(av - a0) > sweep) sweep -= TAU;
    const m = 16;
    for (let i = 1; i < m; i++) {
      const a = a0 + (sweep * i) / m;
      out.push([ctr[0] + Math.cos(a) * r, ctr[1] + Math.sin(a) * r]);
    }
  }

  // Least-squares polynomial y(x), cubic at most (lower for short chains); value + derivative.
  function fitPoly(xs, ys) {
    const m = Math.min(3, xs.length - 1) + 1;
    const A = [];
    for (let i = 0; i < m; i++) A.push(new Array(m + 1).fill(0));
    for (let k = 0; k < xs.length; k++) {
      for (let i = 0; i < m; i++) {
        for (let j = 0; j < m; j++) A[i][j] += Math.pow(xs[k], i + j);
        A[i][m] += ys[k] * Math.pow(xs[k], i);
      }
    }
    for (let i = 0; i < m; i++) {
      let p = i;
      for (let r = i + 1; r < m; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
      const tmp = A[i]; A[i] = A[p]; A[p] = tmp;
      const piv = A[i][i] || 1e-12;
      for (let r = 0; r < m; r++) {
        if (r === i) continue;
        const f = A[r][i] / piv;
        for (let j = i; j <= m; j++) A[r][j] -= f * A[i][j];
      }
    }
    const co = A.map((row, i) => row[m] / (row[i] || 1e-12));
    return {
      v: (x) => co.reduce((acc, cf, i) => acc + cf * Math.pow(x, i), 0),
      d: (x) => co.reduce((acc, cf, i) => acc + (i ? i * cf * Math.pow(x, i - 1) : 0), 0),
    };
  }

  // Morph: a dotted outline cycling circle → triangle → square → circle — "shaping".
  function smoothE(x) { return x * x * (3 - 2 * x); }

  function polyPath(verts) {
    const V = verts.length;
    const L = [];
    let total = 0;
    for (let i = 0; i < V; i++) {
      const a = verts[i];
      const b = verts[(i + 1) % V];
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
      L.push(l);
      total += l;
    }
    return (f) => {
      let target = f * total;
      let i = 0;
      while (target > L[i] && i < V - 1) {
        target -= L[i];
        i++;
      }
      const a = verts[i];
      const b = verts[(i + 1) % V];
      const ff = L[i] ? Math.min(1, target / L[i]) : 0;
      return [a[0] + (b[0] - a[0]) * ff, a[1] + (b[1] - a[1]) * ff];
    };
  }

  const CIRCLE = (f) => {
    const a = -Math.PI / 2 + f * 2 * Math.PI;
    return [Math.cos(a) * 0.24, Math.sin(a) * 0.24];
  };
  const TRIANGLE = polyPath([[0.0, -0.26], [0.24, 0.16], [-0.24, 0.16]]);
  const SQUARE = polyPath([[0, -0.2], [0.2, -0.2], [0.2, 0.2], [-0.2, 0.2], [-0.2, -0.2]]);
  const CYCLE = [CIRCLE, TRIANGLE, SQUARE];

  function morphN(d) { return Math.max(6, Math.round(34 * d)); }

  const HOLD = 1.4;
  const MORPH = 0.9;
  const SEG = HOLD + MORPH;

  function frameMorph(size, t, o) {
    const K = CYCLE.length;
    const tc = t % (SEG * K);
    const k = Math.floor(tc / SEG);
    const local = tc - k * SEG;
    const m = local > HOLD ? smoothE((local - HOLD) / MORPH) : 0;
    const sprd = o.spread == null ? 1 : o.spread;
    const pA = CYCLE[k];
    const pB = CYCLE[(k + 1) % K];
    const M = 160;
    const pts = [];
    for (let i = 0; i < M; i++) {
      const f = i / M;
      const a = pA(f);
      const b = pB(f);
      pts.push([(a[0] + (b[0] - a[0]) * m) * sprd, (a[1] + (b[1] - a[1]) * m) * sprd]);
    }
    const L = [];
    let total = 0;
    for (let i = 0; i < M; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % M];
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
      L.push(l);
      total += l;
    }
    const n = morphN(o.iconD == null ? 1 : o.iconD);
    const re = (o.rDot == null ? 0.021 : o.rDot) * 1.35 * sprd;
    const pulse = 1 + 0.02 * Math.sin(local * 3.1);
    const dots = [];
    const c2 = size / 2;
    let seg = 0;
    let acc = 0;
    for (let k2 = 0; k2 < n; k2++) {
      const target = (k2 / n) * total;
      while (acc + L[seg] < target && seg < M - 1) {
        acc += L[seg];
        seg++;
      }
      const a = pts[seg];
      const b = pts[(seg + 1) % M];
      const f = L[seg] ? Math.min(1, (target - acc) / L[seg]) : 0;
      const x = (a[0] + (b[0] - a[0]) * f) * pulse;
      const y = (a[1] + (b[1] - a[1]) * f) * pulse;
      dots.push({ x: c2 + x * size, y: c2 + y * size, z: 0, r: Math.max(0.35, re * size), white: 0.1 });
    }
    return finalizeFrame(dots, [], o.rMin);
  }

  const MODE_FRAMES = {
    orbits: frameOrbits,
    globe: frameGlobe,
    rubik: frameRubik,
    wave: frameWave,
    web: frameWeb,
    braid: frameBraid,
    ribbon: frameRibbon,
    ring: frameRibbon,
    morph: frameMorph,
  };

  // ---- state → mode + shipped tunings (nine states × two sizes) -----------------------------

  const STATES = ["working", "searching", "solving", "listening", "connecting", "weaving", "composing", "breathing", "shaping"];
  const SIZES = [64, 20];

  const STATE_TO_MODE = {
    working: "orbits",
    searching: "globe",
    solving: "rubik",
    listening: "wave",
    connecting: "web",
    weaving: "braid",
    composing: "ribbon",
    breathing: "ring",
    shaping: "morph",
  };

  const PRESETS = {
    orbits: { 64: { speed: 1.885, count: 1, size: 1 }, 20: { speed: 3.9, count: 0.238, size: 2.4 } },
    globe: {
      64: { speed: 2.015, count: 0.42, size: 1.15, extra: { scanMul: 4.08, dimBase: 0.45 } },
      20: { speed: 2.665, count: 0.105, size: 1.75, extra: { scanMul: 4.335, dimBase: 0.45 } },
    },
    rubik: { 64: { speed: 1.82, count: 0.35, size: 1.05 }, 20: { speed: 1.95, count: 0.088, size: 1.9 } },
    wave: { 64: { speed: 4.388, count: 0.341, size: 1 }, 20: { speed: 3.998, count: 0.105, size: 1.6 } },
    web: { 64: { speed: 3.315, count: 1.35, size: 0.95 }, 20: { speed: 6.63, count: 0.25, size: 1.52 } },
    braid: { 64: { speed: 1.625, count: 0.5, size: 1 }, 20: { speed: 2.75, count: 0.1125, size: 1.36 } },
    ribbon: {
      64: { speed: 2.34, count: 0.25, size: 0.85, extra: { spin: 0, bandMul: 3.9, wobMul: 1 } },
      20: { speed: 3.12, count: 0.051, size: 1.073, extra: { spin: 0, bandMul: 4.94, wobMul: 1 } },
    },
    // Streak widths here are the base ones (0.92 in the 20 box, 1.11 in the 64 box); where a ring is
    // drawn, smallTick() / ringTick() pick the brand width for its size (G-003).
    ring: {
      64: { speed: 3.24, count: 0.25, size: 0.956, extra: { spin: 0, bandMul: 7.254, wobMul: 0.368, stroke: 1, segMul: 1.5, widthMul: 0.75, inkLift: 0.7, alphaLift: 0.75 } },
      20: { speed: 3.78, count: 0.028, size: 1.622, extra: { spin: 0, bandMul: 7.936, wobMul: 0.565, stroke: 1, segMul: 1.5, widthMul: 0.75, inkLift: 0.7, alphaLift: 0.75 } },
    },
    morph: { 64: { speed: 2.405, count: 0.702, size: 0.395, extra: { spread: 1.45 } }, 20: { speed: 2.08, count: 0.53, size: 1.011, extra: { spread: 1.45 } } },
  };

  const _presetCache = new Map();

  // Resolve a (state, size) pair to its mode + fully-scaled draw options + clock speed.
  function resolvePreset(state, size) {
    const st = STATE_TO_MODE[state] ? state : "working";
    const sz = size === 20 ? 20 : 64;
    const key = st + "-" + sz;
    const hit = _presetCache.get(key);
    if (hit) return hit;
    const mode = STATE_TO_MODE[st];
    const preset = PRESETS[mode][sz];
    let opts = Object.assign({}, BASE_PROFILES[mode]);
    if (preset.count !== 1) opts = scaleCounts(opts, preset.count);
    if (preset.size !== 1) opts = scaleRadii(opts, preset.size);
    if (preset.extra) opts = Object.assign(opts, preset.extra);
    const resolved = { mode, speed: preset.speed, opts };
    _presetCache.set(key, resolved);
    return resolved;
  }

  // The app's three moods, each drawn by one upstream state (the brand decision): idle breathes
  // (the logo ring), thinking is the listening waves, working is the orbits. <rl-orb state="thinking">
  // resolves through this, so a screen names the mood and the look is chosen here, once.
  const MOODS = { idle: "breathing", thinking: "listening", working: "working" };
  function moodState(s) { return MOODS[s] || s; }

  // The one still frame shown per state under prefers-reduced-motion (upstream uses 0.6). The
  // breathing ring is also the app's logo, so it rests on the logo's frame (t=9.90) instead.
  const STATIC_T = { breathing: 9.9 };
  function staticT(state) { return STATIC_T[state] != null ? STATIC_T[state] : 0.6; }

  // The portable convenience: (state, size, tSec) → a finished frame ({dots, lines}).
  function computeFrame(state, size, tSec) {
    const { mode, opts } = resolvePreset(state, size);
    return MODE_FRAMES[mode](size, tSec, opts);
  }

  // Brand tick rule for the 64 ring (G-003). `devPx` is the ring box in device pixels: 90 or more
  // keeps the thin 1.11 streaks, smaller thickens them to 1.9 so they close into a ring, and dark
  // ink on a light surface never goes under 1.4. Returns the width in the 64 box.
  const RING_W = 1.11;
  function ringTick(devPx, dark) {
    const w = devPx >= 90 ? RING_W : 1.9;
    return dark ? w : Math.max(1.4, w);
  }
  // The 64 ring's draw options at a given streak width.
  function ringOpts(opts, tick) {
    return tick === RING_W ? opts : Object.assign({}, opts, { widthMul: (opts.widthMul || 1) * tick / RING_W });
  }
  // The small (23-streak) ring: bold 1.2 when drawn at 24 CSS px or less, its base 0.92 above
  // that (25-32px). `px` is the drawn box. Returns the draw options for that size.
  const SMALL_BOLD = 1.3;       // 1.2 / 0.923
  function smallBold(px) { return px <= 24; }
  function smallOpts(opts, px) {
    return smallBold(px) ? Object.assign({}, opts, { widthMul: (opts.widthMul || 1) * SMALL_BOLD }) : opts;
  }

  const ENGINE = {
    STATES, SIZES, STATE_TO_MODE, PRESETS, BASE_PROFILES, MODE_FRAMES, STATIC_T, MOODS,
    resolvePreset, computeFrame, staticT, moodState, finalizeFrame, radiusScale, makeProj,
    scaleCounts, scaleRadii, streakStroke, ringTick, ringOpts, smallBold, smallOpts,
  };

  // In node (tests) export the pure engine and stop before any DOM/canvas.
  if (typeof module !== "undefined" && module.exports) { module.exports = ENGINE; return; }

  // ---- browser: painter + the <rl-orb> custom element ---------------------------------------

  // Key-colour ink (the app's brand colour, --key on <html>): upstream's dark-substrate grey
  // (1 - white) becomes the key colour's intensity, the same mapping as the approved logo page.
  // On a light substrate (`light`) the same intensity mixes the ink towards white instead.
  function tintInk(c, g, a, light) {
    const m = Math.min(1, g * 1.15);
    if (light) return "rgba(" + Math.round(c[0] * m + 255 * (1 - m)) + "," + Math.round(c[1] * m + 255 * (1 - m)) + ","
      + Math.round(c[2] * m + 255 * (1 - m)) + "," + a + ")";
    const w = 255 * Math.max(0, g - 0.85);
    return "rgba(" + Math.round(Math.min(255, c[0] * m + w)) + "," + Math.round(Math.min(255, c[1] * m + w)) + ","
      + Math.round(Math.min(255, c[2] * m + w)) + "," + a + ")";
  }

  function parseHex(v) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(v || "").trim());
    if (!m) return null;
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  // Painter: near dots read bright on dark substrates (ink mirrored), matte grayscale fills.
  // With a key colour (`tint`, [r,g,b]) on a dark substrate the grey becomes that colour; `both`
  // tints on a light substrate too (an ink chosen for both themes: --orb-ink).
  function paintFrame(ctx, frame, dark, tint, both) {
    const tinted = !!(tint && (dark || both)), lt = !dark;
    for (const l of frame.lines) {
      const alpha = l.a == null ? 1 : l.a;
      const wv = Math.min(1, Math.max(0, l.white));
      const g = Math.round((dark ? 1 - wv : wv) * 255);
      ctx.strokeStyle = tinted ? tintInk(tint, 1 - wv, alpha, lt) : "rgba(" + g + "," + g + "," + g + "," + alpha + ")";
      ctx.lineWidth = l.w;
      ctx.beginPath();
      ctx.moveTo(l.x1, l.y1);
      ctx.lineTo(l.x2, l.y2);
      ctx.stroke();
    }
    for (const st of frame.strokes || []) {
      const gr = ctx.createLinearGradient(st.a0[0], st.a0[1], st.a1[0], st.a1[1]);
      for (const [f, white, alpha] of st.stops) {
        const wv = Math.min(1, Math.max(0, white));
        const g = Math.round((dark ? 1 - wv : wv) * 255);
        gr.addColorStop(Math.min(1, Math.max(0, f)), tinted ? tintInk(tint, 1 - wv, alpha, lt) : "rgba(" + g + "," + g + "," + g + "," + alpha + ")");
      }
      ctx.fillStyle = gr;
      ctx.beginPath();
      ctx.moveTo(st.pts[0][0], st.pts[0][1]);
      for (let i = 1; i < st.pts.length; i++) ctx.lineTo(st.pts[i][0], st.pts[i][1]);
      ctx.closePath();
      ctx.fill();
    }
    for (const d of frame.dots) {
      const alpha = d.a == null ? 1 : d.a;
      const wv = Math.min(1, Math.max(0, d.white));
      const g = Math.round((dark ? 1 - wv : wv) * 255);
      ctx.fillStyle = tinted ? tintInk(tint, 1 - wv, alpha, lt) : "rgba(" + g + "," + g + "," + g + "," + alpha + ")";
      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Resolve the effective dark/light substrate for an element: nearest data-theme / .dark|.light
  // ancestor (the app sets html[data-theme]), else prefers-color-scheme. Matches the app's own
  // theme mechanism (v2.html sets html.dataset.theme; custom.css keys off it).
  function ancestorTheme(el) {
    let node = el;
    while (node) {
      const attr = node.getAttribute && node.getAttribute("data-theme");
      if (attr === "dark") return true;
      if (attr === "light") return false;
      if (node.classList && node.classList.contains("dark")) return true;
      if (node.classList && node.classList.contains("light")) return false;
      node = node.parentElement;
    }
    return null;
  }

  function systemDark() {
    return typeof matchMedia === "undefined" || matchMedia("(prefers-color-scheme: dark)").matches;
  }

  function prefersReduced() {
    return typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  // Default aria-labels in the page's language. Callers can override with the aria-label attr.
  const LABELS = {
    working: "작업 중", searching: "검색 중", solving: "해결 중", listening: "듣는 중",
    connecting: "연결 중", weaving: "짜는 중", composing: "작성 중", breathing: "생각 중", shaping: "구성 중",
  };
  const LABELS_EN = {
    working: "Working", searching: "Searching", solving: "Solving", listening: "Listening",
    connecting: "Connecting", weaving: "Weaving", composing: "Composing", breathing: "Thinking", shaping: "Shaping",
  };

  // One animation frame for every running orb (a list of thirty used to be thirty loops), and one
  // IntersectionObserver for all of them. An orb may ask for fewer frames a second (`fps`).
  const RUN = new Set();
  let RAF = 0;
  function tick() {
    RAF = 0;
    const t = now();
    for (const o of RUN) {
      if (o._gap && t - o._last < o._gap - 2) continue;
      o._last = t;
      o._frame((t / 1000 + o._phase) * o._effSpeed);
    }
    if (RUN.size) RAF = requestAnimationFrame(tick);
  }
  let IO = null;
  function watch(el) {
    if (typeof IntersectionObserver === "undefined") return false;
    if (!IO) IO = new IntersectionObserver((entries) => {
      for (const e of entries) {
        const o = e.target;
        o._visible = e.isIntersecting;
        if (o._visible && document.visibilityState !== "hidden") o._start();
        else o._stop();
      }
    });
    IO.observe(el);
    return true;
  }

  class RlOrb extends HTMLElement {
    static get observedAttributes() { return ["state", "size", "px", "theme", "speed", "paused", "aria-label", "ink", "phase", "fps"]; }

    constructor() {
      super();
      this._canvas = null;
      this._ctx = null;
      this._raf = 0;
      this._running = false;
      this._visible = true;
      this._io = null;
      this._mo = null;
      this._mqTheme = null;
      this._mqReduce = null;
      this._onVis = null;
      this._onMq = null;
      this._onReduce = null;
    }

    connectedCallback() {
      if (!this._canvas) {
        // Markup copied from a drawn orb carries its dead canvas; a second one would push the live one aside.
        this.querySelectorAll("canvas").forEach((c) => c.remove());
        this._canvas = document.createElement("canvas");
        this._canvas.setAttribute("role", "img");
        this._canvas.style.display = "block";
        this.style.display = this.style.display || "inline-flex";
        this.appendChild(this._canvas);
        this._ctx = this._canvas.getContext("2d");
      }
      // live theme + reduced-motion + visibility
      this._mqTheme = typeof matchMedia !== "undefined" ? matchMedia("(prefers-color-scheme: dark)") : null;
      this._onMq = () => this._draw();
      if (this._mqTheme) this._mqTheme.addEventListener("change", this._onMq);

      this._mqReduce = typeof matchMedia !== "undefined" ? matchMedia("(prefers-reduced-motion: reduce)") : null;
      this._onReduce = () => this._configure();
      if (this._mqReduce) this._mqReduce.addEventListener("change", this._onReduce);

      if (typeof MutationObserver !== "undefined") {
        // theme and key colour both live on <html>; a change repaints (the key recolours live)
        this._mo = new MutationObserver(() => { this._tint = this._readTint(); this._draw(); });
        this._mo.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "data-theme", "data-key", "style"], subtree: false });
      }
      this._io = watch(this);
      this._onVis = () => {
        if (document.visibilityState === "hidden") this._stop();
        else if (this._visible) this._start();
      };
      document.addEventListener("visibilitychange", this._onVis);

      this._configure();
      if (!this._io) this._start();
    }

    disconnectedCallback() {
      this._stop();
      if (this._io && IO) IO.unobserve(this);
      this._io = null;
      if (this._mo) { this._mo.disconnect(); this._mo = null; }
      if (this._mqTheme && this._onMq) this._mqTheme.removeEventListener("change", this._onMq);
      if (this._mqReduce && this._onReduce) this._mqReduce.removeEventListener("change", this._onReduce);
      if (this._onVis) document.removeEventListener("visibilitychange", this._onVis);
    }

    attributeChangedCallback() {
      if (this._canvas) this._configure();
    }

    _dark() {
      const theme = this.getAttribute("theme") || "auto";
      if (theme === "dark") return true;
      if (theme === "light") return false;
      const fromTree = ancestorTheme(this);
      return fromTree == null ? systemDark() : fromTree;
    }

    // The ink: an `ink` attribute (#rrggbb, or "none" for upstream grey), else the app's --key.
    // --orb-ink (CSS, #rrggbb) comes before --key and is an ink for both themes: it tints on a
    // light surface as well, where --key alone stays upstream grey.
    _readTint() {
      this._both = false;
      const own = this.getAttribute("ink");
      if (own === "none") return null;
      if (own) return parseHex(own);
      if (typeof getComputedStyle === "undefined") return null;
      const cs = getComputedStyle(this), ink = parseHex(cs.getPropertyValue("--orb-ink"));
      if (ink) { this._both = true; return ink; }
      return parseHex(cs.getPropertyValue("--key"));
    }

    // Recompute size / preset from the current attributes, then draw (static when reduced).
    _configure() {
      this._tint = this._readTint();
      this._size = this.getAttribute("size") === "20" ? 20 : 64;
      this._speed = parseFloat(this.getAttribute("speed")) || 1;
      // `phase`: seconds added to this orb's clock, so orbs side by side do not move in step.
      // `fps`: the most frames a second it is drawn at (unset: every animation frame).
      this._phase = parseFloat(this.getAttribute("phase")) || 0;
      const fps = parseFloat(this.getAttribute("fps"));
      this._gap = fps > 0 && fps < 60 ? 1000 / fps : 0;
      this._last = 0;
      const want = moodState(this.getAttribute("state"));
      this._state = STATE_TO_MODE[want] ? want : "working";
      const resolved = resolvePreset(this._state, this._size);
      this._mode = resolved.mode;
      this._opts = resolved.opts;
      this._bold = null;
      this._effSpeed = resolved.speed * this._speed;

      const dpr = Math.min(2, (typeof devicePixelRatio !== "undefined" && devicePixelRatio) || 1);
      this._dpr = dpr;
      // `px`: the drawn size in CSS px when it is not the preset's own (the wordmark ring is sized
      // from the type beside it); the preset still picks the detail level.
      const px = parseFloat(this.getAttribute("px"));
      this._px = px > 0 ? px : this._size;
      this._canvas.width = Math.round(this._px * dpr);
      this._canvas.height = Math.round(this._px * dpr);
      this._canvas.style.width = this._px + "px";
      this._canvas.style.height = this._px + "px";
      const label = this.getAttribute("aria-label");
      if (label === "") {                     // aria-label="" → purely decorative, hide from a11y tree
        this._canvas.setAttribute("aria-hidden", "true");
        this._canvas.removeAttribute("role");
      } else {
        this._canvas.setAttribute("role", "img");
        this._canvas.removeAttribute("aria-hidden");
        this._canvas.setAttribute("aria-label", label != null ? label : (((document.documentElement.lang || "").startsWith("en") ? LABELS_EN : LABELS)[this._state] || ""));
      }

      this._reduced = prefersReduced();
      if (this._reduced) { this._stop(); this._draw(); return; }   // one static, deterministic frame
      // paused attribute keeps a single live frame without animating
      this._draw();
      if (this.hasAttribute("paused")) this._stop();
      else if (this._visible && (typeof document === "undefined" || document.visibilityState !== "hidden")) this._start();
    }

    _frame(tSec) {
      const ctx = this._ctx;
      if (!ctx) return;
      const k = this._dpr * this._px / this._size;
      ctx.setTransform(k, 0, 0, k, 0, 0);
      ctx.clearRect(0, 0, this._size, this._size);
      const dark = this._isDark;
      let opts = this._opts;
      if (this._mode === "ring" && this._size === 64) {
        const real = (typeof devicePixelRatio !== "undefined" && devicePixelRatio) || 1;
        opts = ringOpts(opts, ringTick(this._px * real, dark));
      } else if (this._mode === "ring" && smallBold(this._px)) {
        opts = this._bold || (this._bold = smallOpts(opts, this._px));
      }
      paintFrame(ctx, MODE_FRAMES[this._mode](this._size, tSec, opts), dark, this._tint, this._both);
    }

    // The theme is looked up here (on configure and on a theme change), not on every frame.
    _draw() {
      this._isDark = this._dark();
      if (this._reduced) { this._frame(staticT(this._state)); return; }
      this._frame((now() / 1000 + this._phase) * this._effSpeed);
    }

    _start() {
      if (this._running || this._reduced || this.hasAttribute("paused")) return;
      this._running = true;
      RUN.add(this);
      if (!RAF) RAF = requestAnimationFrame(tick);
    }

    _stop() {
      this._running = false;
      RUN.delete(this);
      if (!RUN.size && RAF) { cancelAnimationFrame(RAF); RAF = 0; }
    }
  }

  function now() { return typeof performance !== "undefined" && performance.now ? performance.now() : Date.now(); }

  if (typeof customElements !== "undefined" && !customElements.get("rl-orb")) {
    customElements.define("rl-orb", RlOrb);
  }

  // A small factory for programmatic use, plus the pure engine on the global.
  function create(opts) {
    const el = document.createElement("rl-orb");
    if (opts) {
      if (opts.state) el.setAttribute("state", opts.state);
      if (opts.size) el.setAttribute("size", String(opts.size));
      if (opts.theme) el.setAttribute("theme", opts.theme);
      if (opts.speed) el.setAttribute("speed", String(opts.speed));
      if (opts.label) el.setAttribute("aria-label", opts.label);
      if (opts.paused) el.setAttribute("paused", "");
    }
    return el;
  }

  // The logo as a static inline SVG: the breathing ring's logo frame (t=9.90), dots filled with
  // currentColor so CSS (color: var(--key)) recolours it. Upstream's grey intensity becomes
  // opacity, which on the app's dark surfaces reads as the painted orb does. px <= 32 uses the
  // small-size preset (bold at 24px and under, smallOpts); larger follows ringTick().
  // `px` is the size the mark is drawn at.
  const _markCache = new Map();
  function markSVG(px) {
    const pre = px <= 32 ? 20 : 64;
    let tick = 0;
    if (pre === 64) {
      const light = document.documentElement.getAttribute("data-theme") === "light";
      tick = ringTick(px * (window.devicePixelRatio || 1), !light);
    }
    const key = pre + "/" + (pre === 20 ? smallBold(px) : tick);
    let body = _markCache.get(key);
    if (!body) {
      const rp = resolvePreset("breathing", pre);
      const fr = MODE_FRAMES[rp.mode](pre, STATIC_T.breathing, pre === 20 ? smallOpts(rp.opts, px) : ringOpts(rp.opts, tick));
      body = fr.dots.map((d) => {
        const g = 1 - Math.min(1, Math.max(0, d.white));
        const o = Math.min(1, g * 1.15) * (d.a == null ? 1 : d.a);
        return '<circle cx="' + d.x.toFixed(2) + '" cy="' + d.y.toFixed(2) + '" r="' + d.r.toFixed(2) + '" fill-opacity="' + o.toFixed(3) + '"/>';
      }).join("") + (fr.strokes || []).map((st) => {
        let o = 0;
        for (const [, white, alpha] of st.stops) o += Math.min(1, (1 - Math.min(1, Math.max(0, white))) * 1.15) * alpha;
        o /= Math.max(1, st.stops.length);
        const d = "M" + st.pts.map((q) => q[0].toFixed(2) + " " + q[1].toFixed(2)).join("L") + "Z";
        return '<path d="' + d + '" fill-opacity="' + o.toFixed(3) + '"/>';
      }).join("");
      _markCache.set(key, body);
    }
    return '<svg class="rlmark" viewBox="0 0 ' + pre + " " + pre + '" width="' + px + '" height="' + px
      + '" fill="currentColor" aria-hidden="true" focusable="false">' + body + "</svg>";
  }

  window.Orb = Object.assign({ create, paintFrame, markSVG }, ENGINE);
})();
