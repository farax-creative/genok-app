// 설정 → 오픈소스 라이선스: the components the app bundles, each with its license and the
// full notice text (fetched from /api/oss, rendered read-only through markdown.js). Its own
// small file + one LOOP_SETTINGS entry, so v2.js/v2.css stay untouched.
// Uses v2.js globals: tl, esc, ic, toast, renderMarkdown.
(function () {
  "use strict";

  async function draw(c) {
    c.innerHTML = `<h2 class="seth">${tl("oss.title")}</h2>
      <p class="setd">${tl("oss.desc")}</p>
      <div class="setsec">${tl("oss.list")}</div>
      <div id="oss-list" class="oss-list"></div>`;
    const list = c.querySelector("#oss-list");
    let data;
    try { data = await fetch("/api/oss").then((r) => r.json()); }
    catch { list.innerHTML = `<div class="card"><div class="row"><span class="tx"><div class="s warn">${tl("oss.err")}</div></span></div></div>`; return; }
    const items = (data && data.components) || [];
    if (!items.length) { list.innerHTML = `<div class="card"><div class="row"><span class="tx"><div class="s">${tl("oss.err")}</div></span></div></div>`; return; }

    const FIRST = 6;
    list.innerHTML = items.map((it, i) => `<div class="card oss-item"${i >= FIRST ? " hidden" : ""}>
      <div class="row oss-head press" data-i="${i}" role="button" tabindex="0" aria-expanded="false">
        <span class="tx"><div class="t">${esc(it.name)}</div>
          <div class="s">${esc(it.license)}</div></span>
        <span class="oss-chev">${ic("chev")}</span></div>
      <div class="oss-body" hidden><div class="oss-doc"></div>
        ${it.url ? `<a class="oss-link" href="${esc(it.url)}" target="_blank" rel="noreferrer noopener">${esc(it.url)}</a>` : ""}
      </div></div>`).join("")
      + (items.length > FIRST ? `<button type="button" class="btn weak press oss-more" aria-expanded="false">${tl("ui.more")} <b class="num">${items.length - FIRST}</b></button>` : "");
    const moreB = list.querySelector(".oss-more");
    if (moreB) moreB.onclick = () => {
      list.querySelectorAll(".oss-item[hidden]").forEach((el) => { el.hidden = false; el.classList.add("in"); });
      moreB.remove();
    };

    const toggle = (head) => {
      const card = head.closest(".oss-item");
      const body = card.querySelector(".oss-body");
      const open = body.hidden;
      body.hidden = !open;
      head.setAttribute("aria-expanded", open ? "true" : "false");
      card.classList.toggle("on", open);
      const doc = body.querySelector(".oss-doc");
      if (open && !doc.dataset.filled) {           // render the notice once, on first open
        const it = items[+head.dataset.i];
        if (it && it.text && typeof renderMarkdown === "function") doc.appendChild(renderMarkdown(it.text));
        else doc.textContent = (it && it.text) || "";
        doc.dataset.filled = "1";
      }
    };
    list.querySelectorAll(".oss-head").forEach((h) => {
      h.addEventListener("click", () => toggle(h));
      h.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(h); } });
    });
  }

  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push({page: "oss", icon: "book", title: "oss.title", draw});

  // ------------------------------------------------------------ styles (own file, no v2.css edit)
  const css = `
  .oss-list { display: flex; flex-direction: column; gap: 8px; }
  .oss-item { padding: 0; }
  .oss-item.in { animation: more1in .14s ease-out; }
  @media (prefers-reduced-motion: reduce) { .oss-item.in { animation: none; } }
  .oss-more { width: 100%; justify-content: center; }
  .oss-more .num { margin-left: 2px; color: var(--t3); font-weight: 500; }
  .oss-head { cursor: pointer; }
  .oss-head .s { white-space: normal; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  .oss-chev { color: var(--dim, #9aa0a6); transition: transform .18s ease; display: inline-flex; }
  .oss-item.on .oss-chev { transform: rotate(90deg); }
  .oss-body { padding: 2px 0 12px; border-top: 1px solid var(--line, #2a2d33); }
  .oss-doc { font-size: 13px; line-height: 1.55; color: var(--dim, #c3c7cc); overflow-wrap: anywhere; }
  .oss-doc h1 { font-size: 15px; margin: 8px 0 6px; }
  .oss-link { display: inline-block; margin-top: 6px; font-size: 12px; color: var(--acc, #7aa2f7);
    overflow-wrap: anywhere; }`;
  const s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);
})();
