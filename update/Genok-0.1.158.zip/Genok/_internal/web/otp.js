// One-time-code field: one real <input> lying unseen over a row of boxes that show it, so the
// keyboard, paste and the phone's one-time-code fill work as in any field while every digit sits
// in the middle of its own box. Structure and behaviour after input-otp by Guilherme Rodz (MIT,
// https://github.com/guilhermerodz/input-otp), rewritten without React; see licenses/input-otp.md.

// What each box shows: its digit, whether the cursor or selection is on it, and whether it draws
// the blinking stand-in cursor (an empty box under the cursor).
function otpSlots(value, start, end, focused, length) {
  const out = [];
  for (let i = 0; i < length; i++) {
    const ch = value[i] || "";
    const on = !!focused && i >= start && i < Math.max(end, start + 1);
    out.push({ch, on, caret: on && !ch});
  }
  return out;
}

// A pasted text put into the value at the selection: digits only, cut to the length.
function otpPaste(value, start, end, text, length) {
  return (value.slice(0, start) + String(text).replace(/\D/g, "") + value.slice(end)).slice(0, length);
}

// Where the selection should rest for a bare cursor at `pos`: on a filled box the digit is
// selected, so the next key replaces it; past the last box it is the last digit.
function otpRest(value, pos, length, prev, left) {
  // Left arrow on a selected digit only folds the selection onto its start: step to the box before.
  if (left && prev && prev[1] - prev[0] === 1 && pos === prev[0] && pos > 0) pos -= 1;
  if (pos >= length) return [length - 1, length];
  if (pos < value.length) return [pos, pos + 1];
  return [pos, pos];
}

function otpCss() {
  if (document.getElementById("otp-css")) return;
  const s = document.createElement("style"); s.id = "otp-css";
  s.textContent = `
  .otp { position: relative; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)) 10px repeat(3, minmax(0, 1fr)); gap: 8px; height: 60px; }
  .otp-slot { position: relative; display: flex; align-items: center; justify-content: center; box-sizing: border-box; border-radius: 12px;
    border: 1px solid var(--t4); background: var(--card); color: var(--t1); font-size: 28px; line-height: 1; font-weight: 600;
    font-variant-numeric: tabular-nums; transition: border-color .12s ease, box-shadow .12s ease; }
  .otp-sep { align-self: center; height: 2px; border-radius: 1px; background: var(--t4); }
  .otp-slot.on { border-color: var(--focus-line); box-shadow: 0 0 0 3px var(--focus-glow); }
  .otp-slot.caret::after { content: ""; width: 2px; height: 26px; border-radius: 1px; background: var(--t1); animation: otp-blink 1.1s steps(1) infinite; }
  .otp.bad .otp-slot { border-color: var(--red); box-shadow: none; }
  .otp.bad { animation: otp-shake .32s ease; }
  /* The field itself: over the boxes, unseen. 16px so iOS does not zoom in on it. */
  .otp .otp-in { position: absolute; inset: 0; width: 100%; height: 100%; margin: 0; padding: 0; border: 0; border-radius: 12px;
    background: none; opacity: 0; font-size: 16px; z-index: 1; }
  @keyframes otp-blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
  @keyframes otp-shake { 20% { transform: translateX(-6px); } 45% { transform: translateX(5px); } 70% { transform: translateX(-3px); } 90% { transform: translateX(2px); } }
  @media (prefers-reduced-motion: reduce) { .otp.bad, .otp-slot.caret::after { animation: none; } .otp-slot { transition: none; } }`;
  document.head.appendChild(s);
}

// {id, label, describedby, length, onChange(value)} -> {el, input, bad(on)}
function otpField(o) {
  otpCss();
  const length = o.length || 6, half = length / 2;
  const el = document.createElement("div"); el.className = "otp";
  let cells = "";
  for (let i = 0; i < length; i++) cells += (i === half ? `<span class="otp-sep" aria-hidden="true"></span>` : "") + `<span class="otp-slot" aria-hidden="true"></span>`;
  el.innerHTML = cells;
  const inp = document.createElement("input");
  inp.className = "otp-in"; inp.type = "text"; inp.maxLength = length;
  if (o.id) inp.id = o.id;
  const attrs = {inputmode: "numeric", pattern: "[0-9]*", autocomplete: "one-time-code", autocapitalize: "off", autocorrect: "off", spellcheck: "false",
    enterkeyhint: "done", "aria-label": o.label || "", "aria-describedby": o.describedby || "",
    // Password managers leave it alone: their badge would sit on the last box.
    "data-1p-ignore": "", "data-lpignore": "true", "data-bwignore": "", "data-form-type": "other"};
  for (const k in attrs) if (attrs[k] !== "" || k.startsWith("data-")) inp.setAttribute(k, attrs[k]);
  el.appendChild(inp);
  const slots = [...el.querySelectorAll(".otp-slot")];

  let prev = null, left = false;
  const draw = () => {
    const focused = document.activeElement === inp;
    let s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
    if (focused && s === e) {
      const r = otpRest(inp.value, s, length, prev, left);
      if (r[0] !== s || r[1] !== e) { try { inp.setSelectionRange(r[0], r[1]); } catch {} }
      s = r[0]; e = r[1];
    }
    prev = [s, e]; left = false;
    otpSlots(inp.value, s, e, focused, length).forEach((st, i) => {
      const c = slots[i];
      if (c.textContent !== st.ch) c.textContent = st.ch;
      c.classList.toggle("on", st.on); c.classList.toggle("caret", st.caret);
    });
  };
  inp.addEventListener("input", () => {
    const v = inp.value.replace(/\D/g, "").slice(0, length);
    if (v !== inp.value) inp.value = v;
    draw();
    if (o.onChange) o.onChange(v);
  });
  inp.addEventListener("keydown", (e) => { left = e.key === "ArrowLeft"; });
  // The field's own length limit would cut a pasted "123 456" before the space is taken out.
  inp.addEventListener("paste", (e) => {
    const t = e.clipboardData && e.clipboardData.getData("text");
    if (!t) return;
    e.preventDefault();
    const v = otpPaste(inp.value, inp.selectionStart || 0, inp.selectionEnd || 0, t, length);
    inp.value = v; try { inp.setSelectionRange(v.length, v.length); } catch {}
    draw();
    if (o.onChange) o.onChange(v);
  });
  for (const ev of ["focus", "blur", "click", "keyup", "select"]) inp.addEventListener(ev, draw);
  // Arrow keys and touch handles move the selection without any event on the field itself.
  const onSel = () => { if (!inp.isConnected) return document.removeEventListener("selectionchange", onSel); if (document.activeElement === inp) draw(); };
  document.addEventListener("selectionchange", onSel);
  draw();
  return {el, input: inp, bad: (on) => el.classList.toggle("bad", !!on), draw};
}

if (typeof module !== "undefined") module.exports = {otpSlots, otpRest, otpPaste};
