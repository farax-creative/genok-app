// Live session state from Claude Code's own hooks (hookhttp.py), with no polling: a long-poll on
// /api/hooks/watch answers the moment a hook posts. It does three things with each answer:
//   - a permission request just arrived or ended: the 허용 card is fetched at once (refreshPerm in
//     v2.js), instead of on its 4 s round;
//   - each department row on 부서 gets one quiet status: a dot, a word, and how long (HookDot);
//   - the session rail and the right column's faces take the hook's state over the slower
//     `claude agents` reading for the sessions the hooks know (HookS).
// Loaded after v2.js, it reads v2.js's globals (tl, esc, permAt, refreshPerm, cur, detail,
// SCREENS, drawChrome) by name; its stylesheet (ovh-hooks.css) goes in after glass.css.
(function () {
  "use strict";

  // The most pressing session stands for its department: a permission wait first.
  const ORD = {perm: 0, ask: 1, stuck: 2, work: 3, idle: 4};
  const kindOf = (r) => r.state === "wait" ? (r.kind === "perm" ? "perm" : "ask") : r.state;
  function pick(rooms, dept) {
    let best = null;
    for (const r of rooms) {
      if (r.dept !== dept || !(kindOf(r) in ORD)) continue;
      if (!best || ORD[kindOf(r)] < ORD[kindOf(best)] ||
          (ORD[kindOf(r)] === ORD[kindOf(best)] && r.since > best.since)) best = r;
    }
    return best;
  }
  // Time in state as one short word: 방금, 12분, 3시간.
  function span(sec) {
    const m = Math.floor(Math.max(0, sec) / 60);
    return m < 1 ? {k: "now"} : m < 60 ? {k: "m", n: m} : {k: "h", n: Math.floor(m / 60)};
  }
  // The rail's four states (v2.js SR_ORD).
  const RAIL = {perm: "ask", ask: "ask", stuck: "stuck", work: "work", idle: "idle"};

  if (typeof module !== "undefined" && module.exports) { module.exports = {pick, span, kindOf, RAIL}; return; }

  let rooms = [], skew = 0, rev = null, live = null;
  const nowS = () => Date.now() / 1e3 - skew;
  // Spelled out so the i18n check can see every key in use.
  const SPAN = {now: () => tl("hook.now"), m: (n) => tl("hook.m", {n}), h: (n) => tl("hook.h", {n})};
  const WORD = {perm: () => tl("hook.perm"), ask: () => tl("hook.ask"), work: () => tl("hook.work"), idle: () => tl("hook.idle"), stuck: () => tl("hook.stuck")};
  const spanText = (since) => { const s = span(nowS() - since); return SPAN[s.k](s.n); };

  window.HookS = (r) => { const h = rooms.find((x) => x.sid === r.key); return h ? RAIL[kindOf(h)] || "" : ""; };
  window.HookDot = (dept) => {
    const h = pick(rooms, dept); if (!h) return "";
    const k = kindOf(h);
    // How long only where it counts: a wait or a stop. Work and rest read fine without a clock,
    // and the row's own result age sits right after.
    const t = k === "work" || k === "idle" ? "" : `<b class="num" data-hst="${h.since}">${esc(spanText(h.since))}</b>`;
    return `<span class="hst" data-s="${k}"><i aria-hidden="true"></i>${esc(WORD[k] ? WORD[k]() : "")}${t}</span>`;
  };
  // The minutes move on their own; only the words that changed are touched.
  setInterval(() => document.querySelectorAll("[data-hst]").forEach((b) => {
    const t = spanText(+b.dataset.hst); if (b.textContent !== t) b.textContent = t; }), 15e3);

  function apply(d, first) {
    const sig = JSON.stringify(rooms);
    rooms = Array.isArray(d.rooms) ? d.rooms : [];
    skew = d.now ? Date.now() / 1e3 - d.now : 0;
    if (!first) { try { permAt = 0; refreshPerm(); } catch (e) { /* v2.js not ready */ } }
    if (JSON.stringify(rooms) === sig) return;
    try {
      const typing = document.activeElement?.matches?.("input,textarea");
      if (!detail && cur === "dept" && !typing) SCREENS.dept();
      drawChrome();
    } catch (e) { /* v2.js not ready: its first draw reads rooms */ }
  }

  const shown = () => new Promise((done) => {
    const on = () => { if (!document.hidden) { document.removeEventListener("visibilitychange", on); done(); } };
    document.addEventListener("visibilitychange", on);
  });
  document.addEventListener("visibilitychange", () => { if (document.hidden && live) live.abort(); });

  async function tick() {
    if (document.hidden) await shown();
    const ac = new AbortController(); live = ac;
    const kill = setTimeout(() => ac.abort(), 25e3);
    let d = null;
    try {
      const r = await fetch("/api/hooks/watch" + (rev == null ? "" : "?rev=" + rev), {cache: "no-store", signal: ac.signal});
      if (r.ok) d = await r.json();
    } catch (e) { /* aborted or the server is restarting */ }
    clearTimeout(kill);
    if (!d) return setTimeout(tick, document.hidden ? 0 : 3000);
    const first = rev == null;
    if (first || d.rev !== rev) apply(d, first);
    rev = d.rev;
    setTimeout(tick, 0);
  }

  const css = document.createElement("link"); css.rel = "stylesheet"; css.href = "/ovh-hooks.css";
  document.head.appendChild(css);
  tick();
})();
