// pack.js: show the exact path a session runs to push (loop.exe push ...). loop.exe lives inside
// _internal so the install folder shows only Genok.exe; the PATH is left untouched, so this
// card is where the full path is shown. Only the installed Windows build has a loop.exe; elsewhere
// /api/cli-path returns null and the card stays hidden. Uses tl, esc, toast from v2.js.
window.LOOP_SETTINGS = window.LOOP_SETTINGS || [];
window.LOOP_SETTINGS.push(async (ext) => {
  const d = await fetch("/api/cli-path").then((r) => r.json()).catch(() => null);
  if (!d || !d.path) return;
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `<div class="row"><span class="tx"><div class="t" style="font-size:16px">${tl("pack.1")}</div><div class="s" style="white-space:normal">${tl("pack.2")}</div></span></div>
    <div class="row" style="align-items:center;gap:8px"><code style="flex:1;min-width:0;word-break:break-all;font-size:12px;background:rgba(127,127,127,.12);padding:8px 12px;border-radius:8px">${esc(d.path)}</code><button class="btn sm press" data-copy>${tl("pack.3")}</button></div><div style="height:6px"></div>`;
  ext.appendChild(card);
  card.querySelector("[data-copy]").onclick = async () => {
    try { await navigator.clipboard.writeText(d.path); toast(tl("pack.4")); }
    catch { toast(tl("pack.5")); }
  };
});
