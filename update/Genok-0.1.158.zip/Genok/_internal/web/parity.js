// Read-only session log + uncommitted changes for the open item, as two collapsible
// sections in the item's right inspector column - refern's grammar (small gray section
// label, bordered card, a chevron that turns) on the app's own .card / <details> idiom, so
// T7's shell restyle carries. Item-level, never a separate page. Both sections are collapsed
// and load nothing until first opened. Attached through window.LOOP_ITEM_VIEW (the per-item
// slot, mirroring window.LOOP_SETTINGS). Globals tl, get, esc, ic come from v2.js.

(function () {
  const STYLE = `
  .plog{margin-top:12px}
  .plog summary{list-style:none;cursor:pointer;user-select:none}
  .plog summary::-webkit-details-marker{display:none}
  .plog summary.ch{padding:16px 16px}
  .plog .plbl{font-size:12px;font-weight:600;letter-spacing:.06em;color:var(--t3);text-transform:uppercase}
  .plog .plog-ag{font-size:12px;color:var(--t3);font-weight:500}
  .plog summary .i.dn{width:20px;height:20px;color:var(--t3);transition:transform .25s var(--ease)}
  .plog[open] summary .i.dn{transform:rotate(-90deg)}
  .plog-body{padding:2px 16px 16px}
  .plog-e{margin:0 0 12px}
  .plog-e b{display:block;font-size:12px;color:var(--t3);margin-bottom:4px;font-weight:600}
  .plog-e.user b{color:var(--blue-t)}
  .plog-tx{white-space:pre-wrap;word-break:break-word;color:var(--t1);font-size:14px;line-height:1.55}
  .plog-e.tool{display:flex;gap:8px;align-items:baseline;color:var(--t3);font-size:12px;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;margin-bottom:8px}
  .plog-e.tool svg{width:14px;height:14px;flex:0 0 auto;opacity:.7}
  .plog-scroll{max-height:52vh;overflow:auto}
  .plog-dim{color:var(--t3);font-size:13px;margin:0}
  .plog-f{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:var(--t2);
    display:flex;gap:8px;padding:4px 0}
  .plog-f .p{flex:1;word-break:break-all;color:var(--t1)}
  .plog .ins{color:var(--green);font-weight:600}
  .plog .del{color:var(--red);font-weight:600}
  .plog-diffwrap{margin-top:8px}
  .plog-diffwrap summary{color:var(--t3);font-size:13px;padding:4px 0}
  .plog-diff{white-space:pre;overflow:auto;background:var(--bg);border-radius:var(--r-btn);
    padding:8px 12px;margin-top:6px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;
    color:var(--t2);max-height:44vh}
  .plog-diff .a{color:var(--green)}
  .plog-diff .d{color:var(--red)}`;

  let styled = false;
  function ensureStyle() {
    if (styled) return;
    const s = document.createElement("style");
    s.textContent = STYLE;
    document.head.appendChild(s);
    styled = true;
  }

  function entryHTML(e) {
    if (e.kind === "sub" || e.kind === "res" || e.kind === "think") return "";   // parts of a call's line, and thoughts: the chat's own to show
    if (e.kind === "tool") return `<div class="plog-e tool">${ic("tool")}<span>${esc(e.text)}</span></div>`;
    const who = e.kind === "user" ? tl("sess.me") : (e.agent === "codex" ? "Codex" : "Claude");
    return `<div class="plog-e ${e.kind === "user" ? "user" : "ai"}"><b>${e.kind === "user" ? "" : agDot(e.agent === "codex" ? "codex" : "claude")}${esc(who)}</b><div class="plog-tx">${esc(e.text)}</div></div>`;
  }

  // A diff line coloured by its lead character, so + and - read at a glance.
  function diffHTML(text) {
    return esc(text).split("\n").map((l) =>
      l.startsWith("+") && !l.startsWith("+++") ? `<span class="a">${l}</span>`
      : l.startsWith("-") && !l.startsWith("---") ? `<span class="d">${l}</span>` : l).join("\n");
  }

  function changesHTML(c) {
    if (!c || c.repo === false) return `<p class="plog-dim">${tl("sess.norepo")}</p>`;
    const files = c.files || [], untracked = c.untracked || [];
    if (!files.length && !untracked.length) return `<p class="plog-dim">${tl("sess.clean")}</p>`;
    const flist = files.map((f) => `<div class="plog-f"><span class="p">${esc(f.path)}</span><span class="ins">+${f.ins}</span><span class="del">-${f.del}</span></div>`).join("");
    const ulist = untracked.map((p) => `<div class="plog-f"><span class="p">${esc(p)}</span><span class="plog-dim">${tl("sess.untracked")}</span></div>`).join("")
      + (c.untracked_more ? `<div class="plog-f"><span class="plog-dim">${tl("sess.more", {n: c.untracked_more})}</span></div>` : "");
    const diff = c.text ? `<details class="plog-diffwrap"><summary>diff${c.truncated ? " · " + tl("sess.difftrunc") : ""}</summary><div class="plog-diff">${diffHTML(c.text)}</div></details>` : "";
    return flist + ulist + diff;
  }

  // ---- section shell (refern grammar: small gray label + chevron on a .card) ----
  function section(cls, label) {
    const d = document.createElement("details");
    d.className = "card plog " + cls;
    d.innerHTML = `<summary class="ch"><span class="plbl">${esc(label)}</span>`
      + `<span class="plog-ag"></span><span class="sp"></span>${ic("chev", "i dn")}</summary>`
      + `<div class="plog-body"></div>`;
    return d;
  }

  // ---- the session-log section: loads on first open, follows a live session while open ----
  function wireLog(sec, it) {
    const q = `p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}&v=${encodeURIComponent(it.v)}`;
    const body = sec.querySelector(".plog-body"), ag = sec.querySelector(".plog-ag");
    let scroll = null, offset = null, timer = 0, started = false, done = false;

    async function poll(first) {
      let data;
      try {
        data = await get(`/api/session?${q}${offset != null ? "&offset=" + offset : ""}`);
      } catch (e) {
        if (first) body.innerHTML = `<p class="plog-dim">${esc(e.message || tl("sess.err"))}</p>`;
        clearInterval(timer);
        return;
      }
      if (first) {
        if (!data.found) { clearInterval(timer); done = true; body.innerHTML = `<p class="plog-dim">${tl("sess.none")}</p>`; return; }
        ag.textContent = (data.agent === "codex" ? "Codex" : "Claude") + (data.guessed ? " · ?" : "");
        body.innerHTML = (data.guessed ? `<p class="plog-dim">${tl("sess.guessed")}</p>` : "") + `<div class="plog-scroll"></div>`;
        scroll = body.querySelector(".plog-scroll");
      }
      const near = scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 60;
      const html = (data.entries || []).map(entryHTML).join("");
      if (html) { scroll.insertAdjacentHTML("beforeend", html); if (near) scroll.scrollTop = scroll.scrollHeight; }
      else if (first && !scroll.querySelector(".plog-e")) scroll.innerHTML = `<p class="plog-dim">${tl("sess.empty")}</p>`;
      offset = data.offset;
    }

    sec.addEventListener("toggle", () => {
      if (sec.open) {
        if (!started) { started = true; body.innerHTML = `<p class="plog-dim">${loadingHtml(tl("sess.loading"))}</p>`; poll(true); }
        if (!done) timer = setInterval(() => poll(false), 4000);   // the session may still be writing
      } else {
        clearInterval(timer);
      }
    });
  }

  // ---- the changes section: a one-shot snapshot, loaded on first open ----
  function wireChanges(sec, it) {
    const q = `p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}&v=${encodeURIComponent(it.v)}`;
    const body = sec.querySelector(".plog-body");
    let started = false;
    sec.addEventListener("toggle", async () => {
      if (!sec.open || started) return;
      started = true;
      body.innerHTML = `<p class="plog-dim">${loadingHtml(tl("sess.loading"))}</p>`;
      try {
        const c = await get(`/api/changes?${q}`);
        const ins = c && c.ins ? ` <span class="ins">+${c.ins}</span>` : "";
        const del = c && c.del ? ` <span class="del">-${c.del}</span>` : "";
        sec.querySelector(".plog-ag").innerHTML = (c && c.repo !== false) ? (ins + del) : "";
        body.innerHTML = changesHTML(c);
      } catch (e) {
        body.innerHTML = `<p class="plog-dim">${esc(e.message || tl("sess.err"))}</p>`;
      }
    });
  }

  function attach(box, it) {
    if (!it || !it.p) return;
    const col = box.querySelector(".htitle") && box.querySelector(".htitle").parentElement;
    if (!col || col.querySelector(".plog-log")) return;
    ensureStyle();
    const log = section("plog-log", tl("sess.title"));
    const chg = section("plog-chg", tl("sess.changesTitle"));
    wireLog(log, it);
    wireChanges(chg, it);
    // Sit with the other inspector sections, just after the tabs card.
    // With the item's other upkeep, in the one fold at the foot of the panel.
    const fold = col.querySelector("#ixtra") || col;
    fold.appendChild(log); fold.appendChild(chg);
  }

  window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || [];
  window.LOOP_ITEM_VIEW.push(attach);
})();
