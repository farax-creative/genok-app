// 폰으로 보기: which ONE screen to show. The setup is one step at a time, and the step is read
// off what the PC really is (the server's /api/phone), never off what the person pressed - so
// a step is done when it is done, and the screen moves on by itself.
// Kept apart from phone.js so it can be tested without a page: node --test tests/phonestep.test.js
//
//   d: the /api/phone payload {state, phone, devices, ...}
//   o: what this page knows {locked, remote, paired, adding, skipApp, showApp}
//
// The steps, in the order a new person meets them:
//   pro      phone access is a Pro feature and the plan does not allow it yet
//   install  1/3  Tailscale is not on this PC
//   login    2/3  installed, not signed in
//   start    2/3  signed in, but Tailscale is switched off
//   https    3/3  the tailnet has no HTTPS certificates yet (a setting on the Tailscale site)
//   on       3/3  everything is ready: one press turns phone access on
//   app      on, and none of the person's phones is in the tailnet: install Tailscale there
//   scan     on: the QR and the address to open on the phone
//   done     a phone registered itself while this was open
//   live     on, with a phone already registered: the address, add a phone, turn off
function phoneStep(d, o) {
  d = d || {}; o = o || {};
  const devs = (d.devices || []).length;
  if (d.state === "on") {
    if (o.remote) return "live";                 // seen from the phone itself: it plainly works
    if (o.paired) return "done";
    if (devs && !o.adding) return "live";
    if (o.showApp) return "app";
    // No phone of this account in the tailnet, and none ever registered here: it needs the app.
    if (d.phone === "none" && !devs && !o.skipApp) return "app";
    return "scan";
  }
  if (o.locked) return "pro";
  if (d.state === "ready") return "on";
  if (d.state === "no_https") return "https";
  if (d.state === "stopped") return "start";
  if (d.state === "logged_out") return "login";
  return "install";                              // not_installed, or anything unknown: start over
}

// The "n / 3" of a PC step; the other screens carry no count.
const PHONE_STEP_N = {install: 1, login: 2, start: 2, https: 3, on: 3};
const PHONE_STEP_OF = 3;

if (typeof module !== "undefined") module.exports = {phoneStep, PHONE_STEP_N, PHONE_STEP_OF};
