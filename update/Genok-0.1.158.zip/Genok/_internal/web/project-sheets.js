// Genok web UI, cut from project.js: the small panels over a sheet: folder chooser, icon picker, 보기, 담당 세션, 묶음 지정.
// A classic script in the page's shared scope; v2.html loads the project*.js parts in order.
"use strict";
  // ---- small panels that open over a sheet: the folder chooser and the icon picker -----------------
  // One appears at the button that opened it (a hair smaller, 140ms) and goes back into it; closed half-way,
  // it leaves from where the opening had got to. Reduced motion: a fade. A scroll inside it keeps
  // it open, and Tab stays inside it. off(false) closes without taking the focus back.
  function popFrom(pop, btn, o = {}) {
    document.body.appendChild(pop);
    // Below the button, else above it, else wherever it fits whole; fit() again when its size changes.
    const fit = () => {
      if (!btn.isConnected) return;
      const b = btn.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight, m = 8;
      const below = b.bottom + 6 + h <= innerHeight - m, above = b.top - 6 - h >= m;
      const left = Math.max(m, Math.min(o.align === "left" ? b.left : b.right - w, innerWidth - w - m));
      const top = below ? b.bottom + 6 : above ? b.top - 6 - h : Math.max(m, innerHeight - h - m);
      pop.style.left = Math.round(left) + "px"; pop.style.top = Math.round(top) + "px";
      pop.style.transformOrigin = `${Math.round(b.left + b.width / 2 - left)}px ${Math.round(b.top + b.height / 2 - top)}px`;
    };
    fit();
    if (pop.animate) pop.animate(RM() ? [{opacity: 0}, {opacity: 1}] : [{opacity: 0, transform: "scale(.98)"}, {opacity: 1, transform: "none"}],
      RM() ? {duration: 180, easing: "ease"} : {duration: 140, easing: "ease-out"});
    btn.setAttribute("aria-expanded", "true");
    let gone = false;
    const off = (refocus) => {
      if (gone) return; gone = true;
      if (btn.isConnected) btn.setAttribute("aria-expanded", "false");
      document.removeEventListener("pointerdown", out, true); document.removeEventListener("keydown", key, true);
      removeEventListener("resize", size); removeEventListener("hashchange", away);
      if (window.Motion && Motion.menuOut) Motion.menuOut(pop); else pop.remove();
      if (refocus !== false && btn.isConnected) btn.focus({preventScroll: true});
      if (o.onOff) o.onOff();
    };
    const away = () => off(false);
    const out = (e) => { if (!pop.contains(e.target)) off(false); };
    const size = () => { if (!pop.contains(document.activeElement)) off(false); };   // a phone keyboard coming up is not a reason to close
    const key = (e) => {
      if (!pop.isConnected) return off(false);
      if (e.key === "Escape") { e.stopPropagation(); e.preventDefault(); if (!(o.onEsc && o.onEsc(e))) off(); return; }
      if (e.key !== "Tab") return;
      const f = [...pop.querySelectorAll("button,input")].filter((x) => !x.disabled && x.tabIndex >= 0 && x.offsetParent !== null);
      if (!f.length) return;
      const a = f[0], z = f[f.length - 1], at = document.activeElement;
      if (!pop.contains(at)) { e.preventDefault(); a.focus(); }
      else if (e.shiftKey && at === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && at === z) { e.preventDefault(); a.focus(); }
    };
    setTimeout(() => { if (gone) return; document.addEventListener("pointerdown", out, true); document.addEventListener("keydown", key, true);
      addEventListener("resize", size); addEventListener("hashchange", away); }, 0);
    off.fit = fit;
    return off;
  }
  // Arrow keys move along a row or a grid of buttons; only the one in use takes Tab.
  function rove(box, sel = "button") {
    const cells = () => [...box.querySelectorAll(sel)].filter((x) => !x.disabled);
    const mark = (to) => { cells().forEach((c) => { c.tabIndex = c === to ? 0 : -1; }); };
    box.addEventListener("keydown", (e) => {
      const d = {ArrowLeft: -1, ArrowRight: 1, ArrowUp: "u", ArrowDown: "d", Home: "h", End: "e"}[e.key];
      if (d === undefined) return;
      const list = cells(), i = list.indexOf(document.activeElement); if (i < 0) return;
      const top = list[0].offsetTop, cols = Math.max(1, list.filter((c) => c.offsetTop === top).length);
      const j = d === "h" ? 0 : d === "e" ? list.length - 1 : i + (d === "u" ? -cols : d === "d" ? cols : d);
      if (j < 0 || j >= list.length) return;
      e.preventDefault(); e.stopPropagation(); mark(list[j]); list[j].focus();
    });
    return () => { const list = cells(); mark(list.find((c) => c.classList.contains("on")) || list[0]); };
  }

  const typedPath = (s) => String(s || "").trim().replace(/^"+|"+$/g, "").trim();
  const onThisPc = () => ["127.0.0.1", "localhost", "::1", "[::1]", ""].includes(location.hostname);
  // The system's own folder chooser: only the app window has it (app_main._Api.pick_folder).
  const sysPick = () => (window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder) ? window.pywebview.api.pick_folder : null;
  // A path as two parts, so a long one gives way in the middle: everything up to the last folder,
  // and the last folder itself.
  const splitPath = (p) => { p = String(p || "").replace(/[\\/]+$/, ""); const i = Math.max(p.lastIndexOf("\\"), p.lastIndexOf("/"));
    return i < 0 ? ["", p] : [p.slice(0, i), p.slice(i)]; };

  // 위치 바꾸기: where the new folder goes. Folders of this PC, one level at a time (the server
  // sends folder names only and refuses any place nothing may be made in). pick(path) on 여기로 정하기.
  // none() when Explorer's own chooser gave nothing back (closed, or it could not open): the caller
  // puts the caret in its path field, so that button never does nothing.
  async function folderPop(btn, start, name, pick, none) {
    document.querySelectorAll(".pj-pop,.pj-ov").forEach((p) => p.remove());
    let v;
    try { v = await post("/api/depts/folders", {path: start || ""}); } catch (e) { return toast(e.message); }
    if (!btn.isConnected) return;
    const pop = document.createElement("div");
    pop.className = "pj-ov pj-fp"; pop.tabIndex = -1; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.loc.change"));
    pop.innerHTML = `<div class="fp-side"><div class="fp-sh" aria-hidden="true">${tl("room.loc.places")}</div>
        <div class="fp-pl" data-pl role="group" aria-label="${esc(tl("room.loc.places"))}"></div></div>
      <div class="fp-main">
        <div class="fp-bar"><button type="button" class="fp-up press" data-up aria-label="${esc(tl("room.loc.up"))}" title="${esc(tl("room.loc.up"))}">${ic("up")}</button>
          <div class="fp-ad" data-addr><nav class="fp-cr" data-cr aria-label="${esc(tl("room.loc.path"))}"></nav>
            <input class="fp-ad-in" data-in type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.addrPh"))}" aria-label="${esc(tl("room.loc.edit"))}" hidden>
            <button type="button" class="fp-ed press" data-ed aria-label="${esc(tl("room.loc.edit"))}" title="${esc(tl("room.loc.editTip"))}">${ic("pen")}</button></div></div>
        <p class="fp-er" data-er role="alert" hidden></p>
        <div class="fp-ls" data-ls></div>
      </div>
      <div class="fp-ft"><p class="fp-say" data-say></p>
        <button type="button" class="fp-txt press" data-nf>${ic("plus")}<span>${tl("room.loc.newFolder")}</span></button>
        ${sysPick() ? `<button type="button" class="fp-txt fp-nat press" data-nat>${ic("ext")}<span>${tl("room.loc.explorer")}</span></button>` : ""}
        <span class="sp"></span><button type="button" class="btn sm fill press" data-ok>${tl("room.loc.here")}</button></div>`;
    const q = (s) => pop.querySelector(s);
    const pl = q("[data-pl]"), cr = q("[data-cr]"), ls = q("[data-ls]"), say = q("[data-say]"), ok = q("[data-ok]"), nf = q("[data-nf]"), up = q("[data-up]");
    const addr = q("[data-addr]"), inp = q("[data-in]"), er = q("[data-er]");
    const placeName = (p) => p.kind === "docs" ? tl("room.loc.docs") : p.kind === "desktop" ? tl("room.loc.desktop") : p.label;
    const placeIcon = (p) => ic(p.kind === "recent" ? "clock" : p.kind === "default" ? "home" : "folder");
    const fail = (text) => { er.textContent = text || ""; er.hidden = !text; off.fit && off.fit(); };
    let seq = 0;
    const paint = (focus) => {
      const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
      pl.innerHTML = (v.places || []).map((p) => `<button type="button" class="fp-pc press${same(p.path, v.path) ? " on" : ""}" data-p="${esc(p.path)}" title="${esc(p.path)}">${placeIcon(p)}<span>${esc(placeName(p))}</span></button>`).join("")
        + `<button type="button" class="fp-pc press${v.path ? "" : " on"}" data-p="pc">${ic("server")}<span>${tl("room.loc.pc")}</span></button>`;
      cr.innerHTML = `<button type="button" class="press" data-p="pc"${v.path ? "" : ' aria-current="true"'}>${tl("room.loc.pc")}</button>`
        + (v.crumbs || []).map((c, i, a) => `<i aria-hidden="true">${ic("chev")}</i><button type="button" class="press" data-p="${esc(c.path)}"${i === a.length - 1 ? ' aria-current="true"' : ""}>${esc(c.name)}</button>`).join("");
      cr.scrollLeft = cr.scrollWidth; cr.classList.toggle("cut", cr.scrollWidth > cr.clientWidth + 1);
      up.disabled = !v.up;
      ls.innerHTML = ((v.dirs || []).map((d) => `<button type="button" class="fp-row press" data-p="${esc(d.path)}">${ic(v.path ? "folder" : "server")}<span>${esc(d.name)}</span>${ic("chev")}</button>`).join("")
          || `<p class="fp-none">${tl("room.loc.empty")}</p>`)
        + (v.more ? `<p class="fp-none more">${tl("room.loc.more")}</p>` : "");
      ls.scrollTop = 0;
      ok.disabled = nf.disabled = !v.can;
      say.textContent = !v.can ? tl("room.loc.sayPc") : name ? tl("room.loc.say", {n: name}) : tl("room.loc.sayNew");
      fail(v.why);
      if (focus) (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    };
    const go = async (path, focus = true) => {
      const my = ++seq;
      try { const got = await post("/api/depts/folders", {path}); if (my !== seq || !pop.isConnected) return; v = got; paint(focus); off.fit(); }
      catch (e) { if (my === seq) toast(e.message); }
    };
    // The address bar. A press on a folder name goes there; a press on the empty part of the bar,
    // the pen, Ctrl+L, F4 or Alt+D turns it into a field holding the whole path, selected: copy it,
    // or paste or type another and press Enter. The server checks what was typed ({typed}); a path
    // it cannot open is said under the bar and the chooser stays where it was. Esc or leaving the
    // field brings the folder names back.
    const editing = () => addr.classList.contains("ed");
    const edit = () => {
      if (editing()) return inp.select();
      addr.classList.add("ed"); inp.hidden = false; inp.value = v.path || "";
      inp.focus({preventScroll: true}); inp.select();
    };
    const unedit = (focus) => {
      if (!editing()) return;
      addr.classList.remove("ed"); inp.hidden = true; fail(v.why);
      cr.scrollLeft = cr.scrollWidth;
      if (focus) (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    };
    const typed = async () => {
      const text = inp.value, my = ++seq;
      addr.classList.add("busy");
      let got = null;
      try { got = await post("/api/depts/folders", {path: text, typed: true}); }
      catch (e) { got = {err: "x", why: e.message}; }
      addr.classList.remove("busy");
      if (my !== seq || !pop.isConnected) return;
      if (got.err) {
        // The server's own sentence for a protected folder says which kind it is (Korean only).
        const said = {missing: tl("room.loc.err.missing"), network: tl("room.loc.err.network"), slow: tl("room.loc.err.slow"), form: tl("room.loc.err.form"),
          blocked: (window.I18N_LANG || "ko") === "ko" ? "" : tl("room.loc.err.blocked")}[got.err];
        fail(said || got.why);
        if (editing()) { inp.focus({preventScroll: true}); inp.select(); }
        return;
      }
      v = got; unedit(false); paint(true); off.fit();
    };
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); e.stopPropagation(); typed(); }
      else if (e.key !== "Escape" && e.key !== "Tab") e.stopPropagation();   // Backspace and the arrows are the field's own here
    });
    inp.addEventListener("input", () => { if (!er.hidden) fail(""); });
    inp.addEventListener("blur", () => setTimeout(() => { if (pop.isConnected && document.activeElement !== inp && document.hasFocus()) unedit(false); }, 0));
    addr.addEventListener("click", (e) => { if (!e.target.closest("button") && !editing()) edit(); });
    q("[data-ed]").onclick = (e) => { e.stopPropagation(); edit(); };
    pop.addEventListener("click", (e) => { const b = e.target.closest("[data-p]"); if (b && !b.closest(".fp-new")) go(b.dataset.p); });
    up.onclick = () => { if (v.up) go(v.up); };
    // Ctrl+L, F4, Alt+D: the path field, from anywhere in the chooser. Backspace goes up one unless
    // a field has the caret. In the list ↑↓ Home End walk the folders, ← goes up, → or Enter opens.
    pop.addEventListener("keydown", (e) => {
      const k = e.key, field = e.target.tagName === "INPUT";
      if (k === "F4" || ((k === "l" || k === "L") && (e.ctrlKey || e.metaKey) && !e.altKey) || ((k === "d" || k === "D") && e.altKey && !e.ctrlKey)) { e.preventDefault(); e.stopPropagation(); return edit(); }
      if (field) return;
      if (k === "Backspace" && v.up) { e.preventDefault(); return go(v.up); }
      if (!ls.contains(e.target)) return;
      const rows = [...ls.querySelectorAll(".fp-row")], i = rows.indexOf(document.activeElement);
      const to = {ArrowDown: i + 1, ArrowUp: i - 1, Home: 0, End: rows.length - 1}[k];
      if (to !== undefined) { e.preventDefault(); const t = rows[Math.max(0, Math.min(rows.length - 1, to))]; if (t) { t.focus({preventScroll: true}); t.scrollIntoView({block: "nearest"}); } }
      else if (k === "ArrowLeft" && v.up) { e.preventDefault(); go(v.up); }
      else if (k === "ArrowRight" && i >= 0) { e.preventDefault(); go(rows[i].dataset.p); }
    });
    // 새 폴더: a name typed in place, made on Enter, and the chooser steps into it.
    const endNew = () => { const r = ls.querySelector(".fp-new"); if (r) r.remove(); };
    nf.onclick = () => {
      if (ls.querySelector(".fp-new")) return ls.querySelector(".fp-new input").focus();
      const row = document.createElement("div");
      row.className = "fp-new";
      row.innerHTML = `${ic("folder")}<input type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.newPh"))}" aria-label="${esc(tl("room.loc.newPh"))}"><button type="button" class="btn sm fill press" disabled>${tl("room.loc.newMake")}</button>`;
      ls.prepend(row); ls.scrollTop = 0;
      const inp = row.querySelector("input"), mk = row.querySelector("button");
      inp.oninput = () => { mk.disabled = !inp.value.trim(); };
      const make = async () => {
        if (mk.disabled) return; mk.disabled = true;
        try { const r = await post("/api/depts/mkdir", {path: v.path, name: inp.value.trim()}); if (pop.isConnected) go(r.path); }
        catch (e) { toast(e.message); mk.disabled = false; inp.focus(); }
      };
      mk.onclick = make;
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } });
      inp.focus({preventScroll: true});
    };
    const nat = q("[data-nat]");
    if (nat) nat.onclick = async () => {
      nat.disabled = true;
      let p = null;
      try { p = await sysPick()(v.path || ""); } catch (e) { /* no dialog */ }
      nat.disabled = false;
      if (p) { if (pop.isConnected) await go(String(p)); } else if (none) { off(); none(); }
    };
    let off = {};   // paint() asks for a fit before the panel is on the page
    paint(false);
    off = popFrom(pop, btn, {onEsc: () => {
      if (editing()) { unedit(true); return true; }
      if (!ls.querySelector(".fp-new")) return false; endNew(); nf.focus(); return true; }});
    ok.onclick = () => { if (!v.can) return; pick(v.path); off(); };
    cr.scrollLeft = cr.scrollWidth;   // the first paint ran before it was on the page: the folder in hand is the end that shows
    (ls.querySelector(".fp-row") || ok).focus({preventScroll: true});
    return off;
  }

  // 아이콘·색: the picture a project shows in the lists and the colour behind it. The pictures are
  // the app's emoji set (web/emoji.js); the colours are the app's own swatches (custom.js COLORS,
  // the yellow ones left out). An emoji is a picture and cannot be tinted, so the colour is a soft
  // tile behind it. st = {name, emoji, auto, color}; change({emoji?, color?}) on every pick
  // ("" = back to automatic).
  const TINTS = ["#e0563b", "#e08a2f", "#4caf6a", "#2fb8a8", "#2f9bd9", "#3d82f2", "#5e6ad2", "#7c5cff", "#b05fd9", "#d24b8f", "#8a8f98"];
  const tintAttr = (c) => /^#[0-9a-f]{6}$/i.test(c || "") ? ` style="--em-c:${c}"` : "";
  let randPool = null;
  function randomEmoji(not) {
    const EM = window.LOOP_EMOJI;
    if (!randPool) {
      const seg = window.Intl && Intl.Segmenter ? new Intl.Segmenter() : null;
      const all = EM ? EM.CONCEPTS.flatMap((c) => seg ? [...seg.segment(c[1])].map((x) => x.segment) : []) : [];
      randPool = [...new Set(all)];
      if (!randPool.length) randPool = EM ? EM.ALL.slice(0, 400).map((o) => o.e) : ["🗂"];
    }
    let e = not;
    for (let i = 0; i < 8 && e === not; i++) e = randPool[Math.floor(Math.random() * randPool.length)];
    return e;
  }
  // 스타일: emoji, or the Phosphor set in one of four weights (web/icons.js). The tab last used is
  // the person's default on this device; an icon already saved opens in the style it was saved in.
  const ICON_STYLES = ["regular", "bold", "fill", "duotone", "emoji"];
  const iconStyle = () => { try { const v = localStorage.getItem("v2-icon-style"); return ICON_STYLES.includes(v) ? v : "regular"; } catch (e) { return "regular"; } };
  function iconPop(btn, st, change, o = {}) {
    document.querySelectorAll(".pj-pop,.pj-ov").forEach((p) => p.remove());
    const EM = window.LOOP_EMOJI, IC = window.LOOP_ICONS;
    const had = IC && IC.parse(st.icon);
    let style = !IC ? "emoji" : had ? had.style : st.emoji ? "emoji" : iconStyle();
    const names = {emoji: tl("room.icon.st.emoji"), regular: tl("room.icon.st.regular"), bold: tl("room.icon.st.bold"), fill: tl("room.icon.st.fill"), duotone: tl("room.icon.st.duotone")};
    const pop = document.createElement("div");
    pop.className = "pj-ov pj-ip"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.icon.change"));
    pop.innerHTML = `<div class="ip-top"><span class="ip-h">${tl("room.icon.icon")}</span><span class="sp"></span>
        <button type="button" class="btn sm press" data-rand>${ic("dice")}<span>${tl("room.icon.random")}</span></button>
        <button type="button" class="btn sm press" data-auto>${tl("room.icon.auto")}</button></div>
      <div class="ip-sug" data-sug role="group" aria-label="${esc(tl("room.icon.suggest"))}"></div>
      <input class="ip-q" data-q type="search" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.icon.search"))}" aria-label="${esc(tl("room.icon.search"))}">
      ${IC ? `<div class="ip-seg" data-seg role="group" aria-label="${esc(tl("room.icon.style"))}">${ICON_STYLES.map((k) => `<button type="button" class="press" data-st="${k}">${names[k]}</button>`).join("")}</div>` : ""}
      <div class="ip-grid" data-grid role="group" aria-label="${esc(tl("room.icon.all"))}"></div>
      <div class="ip-top"><span class="ip-h">${tl("room.icon.color")}</span></div>
      <div class="ip-cols" data-cols role="group" aria-label="${esc(tl("room.icon.color"))}"></div>
      <div class="ip-foot"><button type="button" class="btn sm fill press" data-ipdone>${tl("lib.fil.done")}</button></div>`;
    const q = (s) => pop.querySelector(s);
    const sug = q("[data-sug]"), grid = q("[data-grid]"), cols = q("[data-cols]"), qEl = q("[data-q]"), seg = q("[data-seg]");
    const shown = () => st.emoji || st.auto || "";
    const isE = (e) => !st.icon && e === shown(), isI = (n) => st.icon === style + "/" + n;
    const kind = () => (style === "emoji" ? "e" : "i");
    const cell = (e, n) => `<button type="button" class="press${isE(e) ? " on" : ""}" data-e="${esc(e)}" title="${esc(n || e)}" aria-label="${esc(n || e)}" aria-pressed="${isE(e)}">${esc(e)}</button>`;
    const cellI = (n) => `<button type="button" class="press${isI(n) ? " on" : ""}" data-i="${n}" title="${n.replace(/-/g, " ")}" aria-label="${n.replace(/-/g, " ")}" aria-pressed="${isI(n)}">${IC.svg(style, n)}</button>`;
    const seatS = rove(sug), seatG = rove(grid), seatC = rove(cols), seatT = seg ? rove(seg) : () => {};
    const drawSeg = () => { if (seg) { seg.querySelectorAll("[data-st]").forEach((b) => { const on = b.dataset.st === style; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); }); seatT(); } };
    const drawSug = () => {
      sug.innerHTML = kind() === "e" ? (EM ? EM.suggest(st.name || "", [], 7) : []).map((e) => cell(e)).join("") : IC.suggest(st.name || "", 7).map(cellI).join("");
      seatS();
    };
    // The first screenful at once and the rest after the picker has been painted: some 1,400
    // cells in one go held the opening back by a third of a second. seat() is where the grid
    // should be scrolled to, asked again once the rest is in.
    let drawN = 0, seat = null;
    const drawGrid = () => {
      const my = ++drawN, FIRST = 160; seat = null;
      const v = qEl.value, res = kind() === "e" ? (EM ? EM.search(v, v.trim() ? 400 : 2000) : []).map((x) => cell(x.e, x.n)) : IC.search(v, 2000).map(cellI);
      grid.innerHTML = res.length ? res.slice(0, FIRST).join("") : `<p class="fp-none">${tl("depts.emoji.none")}</p>`;
      seatG();
      if (res.length > FIRST) requestAnimationFrame(() => setTimeout(() => {
        if (my !== drawN || !grid.isConnected) return;
        grid.insertAdjacentHTML("beforeend", res.slice(FIRST).join("")); seatG();
        if (seat) seat();
      }, 0));
    };
    const scrollTo = (fn) => { fn(); seat = fn; };
    const drawCols = () => {
      cols.innerHTML = `<button type="button" class="ip-c auto press${st.color ? "" : " on"}" data-c="" aria-pressed="${!st.color}">${tl("room.icon.auto")}</button>`
        + TINTS.map((c, i) => `<button type="button" class="ip-c press${c === st.color ? " on" : ""}" data-c="${c}" style="--em-c:${c}" aria-label="${esc(tl("room.icon.colorN", {n: i + 1}))}" aria-pressed="${c === st.color}"></button>`).join("");
      seatC();
    };
    const mark = () => pop.querySelectorAll("[data-e],[data-i]").forEach((b) => { const on = b.dataset.i ? isI(b.dataset.i) : isE(b.dataset.e); b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
    const setEmoji = (e) => { st.emoji = e; st.icon = ""; mark(); change({emoji: e, icon: ""}); };
    const setIcon = (n) => { st.icon = style + "/" + n; mark(); change({icon: st.icon}); };
    // The picked one in the middle of the grid, so a tab opens on what is in use.
    const reveal = () => { const on = grid.querySelector(".on"); grid.scrollTop = on ? Math.max(0, on.offsetTop - grid.offsetTop - (grid.clientHeight - on.offsetHeight) / 2) : 0; };
    // Another style: between two drawn sets the same icons stay where they are (only the drawing
    // changes, and the icon in use changes with it); emoji and icons each keep their own place.
    const tops = {};
    const setStyle = (k) => {
      if (k === style || !ICON_STYLES.includes(k)) return;
      const was = kind(), cur = IC.parse(st.icon);
      tops[was] = grid.scrollTop; style = k;
      try { localStorage.setItem("v2-icon-style", k); } catch (e) { /* this time only */ }
      drawSeg();
      if (was === "i" && kind() === "i") {
        pop.querySelectorAll("[data-i]").forEach((b) => b.firstElementChild.firstElementChild.setAttribute("href", `${IC.href(k)}#${b.dataset.i}`));
        if (cur) { st.icon = k + "/" + cur.name; change({icon: st.icon}); }
        return mark();
      }
      drawSug(); drawGrid();
      if (kind() in tops) { const y = tops[kind()]; scrollTo(() => { grid.scrollTop = y; }); } else if (st.icon || st.emoji) scrollTo(reveal);
    };
    grid.addEventListener("scroll", () => { seat = null; }, {passive: true});   // the person's own scrolling is not undone
    pop.addEventListener("click", (ev) => {
      const t = ev.target.closest("[data-st]"); if (t) return setStyle(t.dataset.st);
      const i = ev.target.closest("[data-i]"); if (i) return setIcon(i.dataset.i);
      const b = ev.target.closest("[data-e]"); if (b) return setEmoji(b.dataset.e);
      const c = ev.target.closest("[data-c]"); if (c) { st.color = c.dataset.c; drawCols(); cols.querySelector(".on").focus({preventScroll: true}); change({color: st.color}); }
    });
    q("[data-rand]").onclick = () => {
      if (kind() === "e") return setEmoji(randomEmoji(shown()));
      let n = ""; for (let i = 0; i < 8 && (!n || isI(n)); i++) n = IC.NAMES[Math.floor(Math.random() * IC.NAMES.length)];
      setIcon(n); reveal();
    };
    q("[data-auto]").onclick = () => { st.emoji = ""; st.icon = ""; mark(); change({emoji: "", icon: ""}); if (o.autoCloses) off(); };
    let qT = 0; qEl.oninput = () => { clearTimeout(qT); qT = setTimeout(() => { delete tops.e; delete tops.i; drawGrid(); grid.scrollTop = 0; }, 120); };
    drawSeg(); drawSug(); drawGrid(); drawCols();
    const off = popFrom(pop, btn, {align: o.align || "left", onOff: o.onOff});
    q("[data-ipdone]").onclick = () => off();
    if (st.icon || st.emoji) scrollTo(reveal);       // a pick of the person's own; an automatic one opens at the top
    if (wide()) q("[data-rand]").focus({preventScroll: true});
    return off;
  }
  // A header button says it is open for as long as its menu is in the page, across redraws of
  // the header (the list is read again every few seconds).
  const popOpen = (k) => !!(railPops[k] && railPops[k].isConnected);
  const popBusy = (k) => popOpen(k) || performance.now() - (railPops[k + "@"] || 0) < 320;
  function expanded(k, q, pop) {
    railPops[k] = pop;
    const say = (v) => document.querySelectorAll(q).forEach((b) => b.setAttribute("aria-expanded", v));
    say("true");
    const mo = new MutationObserver(() => { if (pop.isConnected) return; mo.disconnect(); if (railPops[k] === pop) railPops[k] = null; railPops[k + "@"] = performance.now(); say("false"); });
    mo.observe(pop.parentNode, {childList: true});
  }
  // 보기: how the list looks, chosen in one place. Beside the button with a pointer, a sheet from
  // the bottom on a phone. A choice shows at once and the menu stays for the next one.
  // 작게 | 크게 marks, on the icon set's 256 grid with its 16-unit line.
  const SZI = (() => { const bar = (y) => `<rect x="32" y="${y - 8}" width="192" height="16" rx="8"/>`, pic = (d) => `<svg class="i" viewBox="0 0 256 256" aria-hidden="true">${d}</svg>`;
    return {sm: pic(bar(56) + bar(104) + bar(152) + bar(200)),
      md: pic(`<path d="M208,136H48a16,16,0,0,0-16,16v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,56H48V152H208v40Zm0-144H48A16,16,0,0,0,32,64v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V64A16,16,0,0,0,208,48Zm0,56H48V64H208v40Z"/>`)}; })();
  function viewMenu(btn, again) {
    if (popBusy("view")) return;
    // Marks from the app's icon set (Phosphor, regular weight); the three it has no key for are
    // drawn on the same 256 grid with the same 16-unit line.
    const bar = (y, w) => `<rect x="32" y="${y - 8}" width="${w || 192}" height="16" rx="8"/>`, pic = (d) => `<svg class="i" viewBox="0 0 256 256" aria-hidden="true">${d}</svg>`;
    const VI = {flat: ic("list"), folder: ic("folder"), proj: ic("grid"), sm: pic(bar(56) + bar(104) + bar(152) + bar(200)),
      md: pic(`<path d="M208,136H48a16,16,0,0,0-16,16v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V152A16,16,0,0,0,208,136Zm0,56H48V152H208v40Zm0-144H48A16,16,0,0,0,32,64v40a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V64A16,16,0,0,0,208,48Zm0,56H48V64H208v40Z"/>`),
      name: pic(bar(64) + bar(128, 136) + bar(192, 80)), recent: ic("clock"), reset: ic("sync")};
    const opt = (attr, v, on, label) => `<button class="press${on ? " on" : ""}" data-${attr}="${v}" aria-pressed="${on}">${VI[v]}<span>${label}</span></button>`;
    const act1 = (attr, v, label) => `<button class="va press" data-${attr}="${v}">${VI[v]}<span>${label}</span></button>`;
    const body = () => { const v = listView(), sm = folded("dense");
      return `<div class="vr"><span class="vl" id="pj-vm1">${tl("room.view")}</span><div class="seg" role="group" aria-labelledby="pj-vm1">${opt("view", "flat", v === "flat", tl("room.vFlat"))}${opt("view", "folder", v === "folder", tl("room.vFolder"))}${opt("view", "proj", v === "proj", tl("room.vGroup"))}</div></div>
        <div class="vr"><span class="vl" id="pj-vm2">${tl("room.size")}</span><div class="seg" role="group" aria-labelledby="pj-vm2">${opt("size", "sm", sm, tl("room.zSm"))}${opt("size", "md", !sm, tl("room.zMd"))}</div></div>
        <hr><div class="vr"><span class="vl" id="pj-vm3">${tl("ord.once")}</span><div class="vo" role="group" aria-labelledby="pj-vm3">${act1("once", "name", tl("ord.byName"))}${act1("once", "recent", tl("ord.byRecent"))}</div></div>
        <button class="vrs" data-reset="reset"${ordPlaced() ? "" : " disabled"}>${tl("ord.reset")}</button>`; };
    const wire = (host) => { const vm = host.querySelector(".pj-vm");
      const paint = (focus) => { vm.innerHTML = body(); vm.querySelectorAll("button").forEach((b) => b.onclick = (e) => { e.stopPropagation(); const d = b.dataset;
        if (d.view) setView(d.view); else if (d.size) setFold("dense", d.size === "sm");
        else if (d.once) { if (ordOnce(d.once)) toast(tl("ord.onceDone")); }
        else { listOrd = {depts: [], sess: {}, flat: []}; ordSave(null); toast(tl("ord.resetDone")); }
        again(!!d.view); paint(Object.keys(d)[0] + "=" + Object.values(d)[0]); });
        if (focus) { const [k, v] = focus.split("="), f = vm.querySelector(`[data-${k}="${v}"]`); if (f) f.focus({preventScroll: true}); } };
      paint(); };
    if (!wide()) return sheet(`<div class="pj-dlg"><h3>${tl("room.view")}</h3><div class="pj-vm"></div></div>`, wire);
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop vm"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", tl("room.view"));
    pop.innerHTML = `<div class="pj-vm"></div>`;
    wire(pop); popAt(pop, btn); expanded("view", "[data-viewmenu]", pop);
    // Opened from the keyboard: the keys carry on inside it.
    if (btn.matches(":focus-visible")) { const f = pop.querySelector("button.on"); if (f) f.focus({preventScroll: true}); }
    // Wider than what is left of its button: it stays over the list it changes, not over the menu beside it.
    const col = btn.closest(".pj-rail");
    if (col) pop.style.left = Math.max(parseFloat(pop.style.left), Math.min(col.getBoundingClientRect().left, innerWidth - pop.offsetWidth - 8)) + "px";
  }

  // 담당 세션 만들기: one named session to keep talking to, in a new folder of its own. The sheet
  // makes the project only; where the folder goes is shown (and can be changed on this PC) before
  // anything is made, with the icon it will carry in the lists. Its chat opens empty, and the
  // first line typed there opens the session that keeps the name. `from` is the button it was
  // opened with: on the PC the dialog grows from that side.
  async function newStanding(from) {
    let agents = {}, defRoot = "", parent = "";
    try { const d = await get("/api/depts"); agents = d.agents || {}; defRoot = d.default_root || ""; parent = d.parent || defRoot; } catch (e) { /* offer Claude alone */ }
    let agent = !agents.claude && agents.codex ? "codex" : "claude", seq = 0, ready = "", busy = false, timer = 0, made = "";
    const here = onThisPc(), st = {name: "", emoji: "", auto: "", color: "", icon: ""};
    const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
    sheet(`<h3>${tl("room.fixed.new")}</h3><p class="hint">${tl("room.fixed.lead")}</p>
      <div class="lbl">${tl("room.fixed.name")}</div>
      <div class="fx-nm"><button type="button" class="fx-ico press" data-ico aria-haspopup="dialog" aria-expanded="false" aria-label="${esc(tl("room.icon.change"))}" title="${esc(tl("room.icon.change"))}"><span class="pj-em" data-em></span><i class="fx-pen" aria-hidden="true">${ic("pen")}</i></button>
        <input class="tin" data-n type="text" maxlength="60" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.fixed.namePh"))}" aria-label="${esc(tl("room.fixed.name"))}"></div>
      <div class="lbl">${tl("room.fixed.task")}</div>
      <input class="tin" data-t type="text" maxlength="200" autocomplete="off" placeholder="${esc(tl("room.fixed.taskPh"))}" aria-label="${esc(tl("room.fixed.task"))}">
      ${agents.claude && agents.codex ? `<div class="lbl">${tl("depts.agent")}</div>
      <div class="seg wide" data-ag role="group" aria-label="${esc(tl("depts.agent"))}">${[["claude", "Claude Code"], ["codex", "Codex"]].map(([v, l]) =>
        `<button type="button" class="press${v === agent ? " on" : ""}" data-v2="${v}" aria-pressed="${v === agent}">${window.agDot(v)}${l}</button>`).join("")}</div>` : ""}
      <div class="lbl">${tl("room.loc.label")}</div>
      ${here ? `<div class="fx-loc ed"><input class="tin" data-pin type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("room.loc.label"))}"><button type="button" class="btn sm press" data-loc aria-haspopup="dialog" aria-expanded="false">${ic("folder")}<span>${tl("room.loc.pick")}</span></button></div>
      <div class="fx-new fx-res" data-path>${ic("folder")}<b data-pn></b></div>`
      : `<div class="fx-loc"><div class="fx-path" data-path><div class="fx-par"><span class="h" data-ph></span><span class="t" data-pt></span></div><div class="fx-new">${ic("folder")}<b data-pn></b></div></div></div>`}
      <p class="hint fx-note">${tl("room.loc.note")}${here ? ` <button type="button" class="fx-reset press" data-reset hidden>${tl("room.loc.reset")}</button>` : " " + tl("room.loc.onPc")}</p>
      <div data-pv aria-live="polite"></div>
      <button type="button" class="btn xl fill press" data-go disabled>${tl("depts.pv.make")}</button>`, (box) => {
      box.classList.add("pj-fx");
      if (from && from.isConnected && wide()) {              // grows from the side its button is on
        const b = from.getBoundingClientRect(), r = box.getBoundingClientRect();
        box.style.transformOrigin = `${Math.round(b.left + b.width / 2 - r.left)}px ${Math.round(b.top + b.height / 2 - r.top)}px`;
      }
      const q = (s) => box.querySelector(s);
      const nameEl = q("[data-n]"), taskEl = q("[data-t]"), pv = q("[data-pv]"), go = q("[data-go]"), ico = q("[data-ico]"), emEl = q("[data-em]");
      const loc = q("[data-loc]"), reset = q("[data-reset]"), pin = q("[data-pin]");
      const body = (dry) => Object.assign({name: nameEl.value.trim(), task: taskEl.value.trim(), agent},
        here ? {parent: same(parent, defRoot) ? "" : parent} : {}, st.emoji ? {emoji: st.emoji} : {}, st.color ? {color: st.color} : {}, st.icon ? {icon: st.icon} : {}, dry ? {dry_run: true} : {});
      const key = () => nameEl.value.trim() + "|" + agent + "|" + parent;
      const sync = () => { go.disabled = busy || !ready || ready !== key(); };
      // Where it goes: the place in a quiet line (a long one gives way in the middle), the new
      // folder's own name under it.
      const place = () => {
        const [h, t] = splitPath(parent), n = made || nameEl.value.trim();
        // The field is the person's while the caret is in it; otherwise it shows the place in use.
        if (pin) { if (document.activeElement !== pin) pin.value = parent; } else { q("[data-ph]").textContent = h; q("[data-pt]").textContent = t; }
        q("[data-pn]").textContent = n || tl("room.loc.nameSlot"); q("[data-pn]").classList.toggle("none", !n);
        q("[data-path]").title = parent + (n ? "\\" + n : "");
        if (reset) reset.hidden = same(parent, defRoot);
      };
      // Before a name is typed there is nothing to draw an emoji from: a plain line icon stands in.
      const face = () => emPut(emEl, st.emoji || st.auto || "🗂", st.color, st.icon || (st.emoji || st.auto ? "" : "regular/folder"));
      // The folder that would be made and the icon the name gets, asked of the server (nothing
      // is written by this).
      const preview = async () => {
        const my = ++seq, k = key(), n = nameEl.value.trim();
        st.name = n; made = "";
        if (!n) { ready = ""; st.auto = ""; pv.innerHTML = ""; face(); place(); return sync(); }
        get("/api/depts/emoji?name=" + enc(n)).then((r) => { if (my === seq && box.isConnected) { st.auto = r.emoji || ""; face(); } }).catch(() => {});
        try {
          // A typed place is checked the chooser's way first: it answers with the reason instead of a failed request.
          if (here && !same(parent, defRoot)) { const f = await post("/api/depts/folders", {path: parent}); if (my !== seq || !box.isConnected) return; if (f.why) throw new Error(f.why); }
          const p = (await post("/api/session/standing", body(true))).preview;
          if (my !== seq || !box.isConnected) return;
          made = splitPath(p.folder)[1].slice(1);
          if (p.parent && !here) parent = p.parent;
          pv.innerHTML = (p.warnings || []).map((w) => `<p class="hint">${esc(w)}</p>`).join("");
          ready = k;
        } catch (err) {
          if (my !== seq || !box.isConnected) return;
          pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = "";
        }
        place(); sync();
      };
      const later = () => { ready = ""; sync(); made = ""; place(); clearTimeout(timer); timer = setTimeout(preview, 220); };
      nameEl.oninput = later;
      box.querySelectorAll("[data-v2]").forEach((b) => b.onclick = () => {
        agent = b.dataset.v2;
        box.querySelectorAll("[data-v2]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        later();
      });
      ico.onclick = () => { if (ico.getAttribute("aria-expanded") === "true") return; iconPop(ico, st, face); };
      // A typed or pasted path is as good as a picked one (Explorer's "경로로 복사" wraps it in
      // quotes); the server checks it either way and says why not under the form.
      if (pin) pin.oninput = () => { parent = typedPath(pin.value) || defRoot; later(); };
      if (loc) loc.onclick = () => { if (loc.getAttribute("aria-expanded") === "true") return;
        folderPop(loc, parent, made || nameEl.value.trim(), (p) => { parent = p; if (pin) pin.value = p; place(); clearTimeout(timer); ready = ""; sync(); preview(); },
          () => { if (pin) { pin.focus(); pin.select(); } }); };
      if (reset) reset.onclick = () => { parent = defRoot; if (pin) pin.value = parent; place(); ready = ""; sync(); preview(); if (loc) loc.focus({preventScroll: true}); };
      const make = async () => {
        if (go.disabled) return;
        busy = true; sync();
        try {
          const r = await act("/api/session/standing", body(false));
          roomsCache = null; closeSheet();
          toast(tl("room.fixed.made", {n: r.title || r.name}));
          nav("project/" + enc(r.name));
        } catch (err) {
          busy = false; sync();
          if (err.message !== "cancelled") { pv.innerHTML = `<div class="dp-err" role="alert">${esc(err.message)}</div>`; ready = ""; sync(); }
        }
      };
      go.onclick = make;
      [nameEl, taskEl, pin].forEach((i) => i && i.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); make(); } }));
      face(); place(); preview();
      if (wide()) setTimeout(() => { if (nameEl.isConnected) nameEl.focus({preventScroll: true}); }, 60);
    });
  }

  // 아이콘·색 바꾸기 for a project that already exists: the same picker, saved as the person's
  // own choice (/api/custom/identity) on every pick; the lists are drawn again when it closes.
  function iconOf(btn, name, again) {
    const r = (roomsCache || []).find((x) => x.name === name) || {};
    const st = {name: pname(name), emoji: r.emoji || emoOf(name), auto: "", color: r.color || "", icon: r.icon || icoOf(name)};
    // The face beside the button that opened this; a row of the rail is drawn by k3FaceSet.
    const face = btn.dataset.k3n ? null : btn.querySelector(".pj-em,.em") || (btn.parentElement && btn.parentElement.querySelector(".pj-em,.em"));
    // A pick shows at once and is saved after: the face used to wait for the save, and five quick
    // picks waited for five saves in a row. Picks made while one is being saved go as one.
    let dirty = false, pend = Promise.resolve(), want = null;
    const show = (auto) => {
      if (typeof window.k3FaceSet === "function") window.k3FaceSet(name);
      if (face && face.isConnected) emPut(face, st.emoji || auto || face.textContent, st.color, st.icon);
    };
    iconPop(btn, st, (ch) => {
      dirty = true;
      if (ch.emoji) r.emoji = ch.emoji;
      if ("color" in ch) r.color = ch.color;
      if ("icon" in ch) r.icon = ch.icon;
      D.ident = Object.assign({}, D.ident, {[name]: Object.assign({}, D.ident && D.ident[name], ch)});
      show();
      const first = !want; want = Object.assign(want || {}, ch);
      if (first) pend = pend.then(async () => {
        const send = want; want = null;
        try {
          const got = await post("/api/custom/identity", Object.assign({project: name}, send));
          if (got.identity && !want) { D.ident = Object.assign({}, D.ident, {[name]: got.identity}); show(got.identity.emoji); }
        } catch (e) { toast(e.message); }
      });
    }, {align: "right", autoCloses: true, onOff: () => { if (dirty) pend.then(() => { roomsCache = null; if (again) again(); if (typeof drawChrome === "function") drawChrome(); }); }});
  }

  // 묶음 지정: which group a folder is shown under in 묶음별. One of the groups there are, a new
  // name, or back to the folder's own. Choosing one turns 묶음별 on, so what it did is seen.
  function grpPop(btn, name, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const rs = roomsCache || roomsSeen || [], r = rs.find((x) => x.name === name) || {name}, cur = grpOf(r);
    const all = [...new Set(rs.map(grpOf).filter(Boolean))].sort((a, b) => gpname(a).localeCompare(gpname(b)));
    const pop = document.createElement("div");
    pop.className = "pj-pop cm pj-gp";
    pop.innerHTML = `<div class="gp-l">${all.map((g) => `<button data-g2="${esc(g)}"${g === cur ? ` class="on" aria-pressed="true"` : ""}>${ic(g === cur ? "check" : "grid")}<span>${esc(gpname(g))}</span></button>`).join("")}</div>
      <input class="pj-search" data-gnew type="text" maxlength="40" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.grpNew"))}" aria-label="${esc(tl("room.grpNew"))}">`
      + (name in grpMap() ? `<hr><button data-g2r>${ic("sync")}<span>${tl("room.grpReset")}</span></button>` : "");
    popAt(pop, btn);
    const put = (g) => { setGrp(name, g); setView("proj"); pop.remove(); toast(g == null ? tl("room.grpBack") : tl("room.grpDone", {n: gpname(g)})); if (again) again(); };
    pop.querySelectorAll("[data-g2]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); put(b.dataset.g2); });
    const back = pop.querySelector("[data-g2r]"); if (back) back.onclick = (e) => { e.stopPropagation(); put(null); };
    const inp = pop.querySelector("[data-gnew]");
    inp.onclick = (e) => e.stopPropagation();
    inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229 && inp.value.trim()) { e.preventDefault(); put(inp.value.trim()); } else if (e.key === "Escape") pop.remove(); };
  }

  // The department header's own menu: open a terminal session (this PC), 정리 like the hub.
  function headMenu(btn, name, registered, again) {
    document.querySelectorAll(".pj-pop").forEach((p) => p.remove());
    const pop = document.createElement("div");
    pop.className = "pj-pop cm";
    const it = (a, icon, label, cls) => `<button data-a="${a}"${cls ? ` class="${cls}"` : ""}>${ic(icon)}<span>${label}</span></button>`;
    // Rename, regroup, archive and remove act on Genok's own folder list; a folder known only from
    // elsewhere (r.own false) has none of them.
    const own = !!((roomsCache || roomsSeen || []).find((x) => x.name === name) || {}).own;
    // The last one ENDS sessions (it was called 정리, the same word as hiding one from the list);
    // the server asks before it does.
    pop.innerHTML = it("sheet", "plus", tl("mn.new")) + (phoneList() ? "" : it("multi", "grid", tl("room.toMulti")))
      + moreRow((registered ? it("open", "code", tl("room.openTerm")) : "") + it("icon", "pen", tl("mn.icon")) + it("pgrp", "grid", tl("room.grpSet"))
        + (own && window.LOOP_DEPT ? it("rename", "pen", tl("depts.menu.rename")) + it("group", "folder", tl("depts.menu.group")) + it("roles", "people", tl("depts.menu.roles")) + it("archive", "archive", tl("depts.menu.archive")) + it("remove", "minus", tl("room.offList")) : "")
        + ordItems(btn.closest(".pj-sgl,.pj-srow")))
      + `<hr>` + it("tidy", "stop", tl("room.tidyDept"), "dz");
    const ordRow = btn.closest(".pj-sgl,.pj-srow");
    popAt(pop, btn);
    ordWire(pop, ordRow); moreWire(pop);
    pop.querySelectorAll("[data-a]").forEach((b) => b.onclick = async (e) => {
      e.stopPropagation(); pop.remove();
      if (b.dataset.a === "open") return openDept(name);
      if (b.dataset.a === "icon") return iconOf(btn, name, again);
      if (b.dataset.a === "pgrp") return grpPop(btn, name, again);
      if (b.dataset.a === "sheet") return newChat(name);
      if (["rename", "group", "roles", "archive", "remove"].includes(b.dataset.a)) return window.LOOP_DEPT(name, b.dataset.a, () => { roomsCache = null; if (again) again(); });
      if (b.dataset.a === "multi") {
        const r = (roomsCache || []).find((x) => x.name === name);
        return pickPanes(r && r.sid ? [r.sid] : [], goMulti);
      }
      const was = btn.innerHTML;
      try {
        const r = await act("/api/session/tidy-dept", {name}, 0, (on) => { btn.disabled = on; btn.innerHTML = on ? loadingHtml("", {inline: true}) : was; }); showTidied = "";
        toast(r.message || tl("room.tidied")); if (r.stopped && again) again();
      }
      catch (err) { if (err.message !== "cancelled") toast(err.message); }
      finally { btn.disabled = false; btn.innerHTML = was; }
    });
  }

  // "← 대화" goes back to the list the room was opened from: 프로젝트별 (#project) or 최근 순
  // (#sessions). The origin is noted when the address moves from a list into a room and kept while
  // moving between rooms; it lives in sessionStorage so a reload keeps it. A room opened by its
  // address alone (a link, a new tab) has no origin and falls back to 프로젝트별.
  const isRoom = (h) => /^project\/./.test(h) && h !== "project/" + ALL;
  let lastHash = location.hash.slice(1), roomFrom = "project";
  try { if (isRoom(lastHash) && sessionStorage.getItem("v2-roomfrom") === "sessions") roomFrom = "sessions"; } catch {}
  addEventListener("hashchange", () => {
    const h = location.hash.slice(1);
    if (isRoom(h) && !isRoom(lastHash)) {
      roomFrom = lastHash.split(/[/?]/)[0] === "sessions" ? "sessions" : "project";
      try { sessionStorage.setItem("v2-roomfrom", roomFrom); } catch {}
    }
    lastHash = h;
  });
  const backToList = () => nav(roomFrom === "sessions" ? roomFrom : listHash());
  // A phone's list page (#project) and the chat opened from it. `listAt`: this draw is the list
  // page. A chat opened from the list is one step ahead of it, so going back to the list is the
  // browser's own Back (and its back swipe); a chat reached any other way puts the list in its place.
  let listAt = false, lastChat = {name: "", sid: ""}, pjListY = 0, listHop = "", seenPrev = "";
  const fromList = (hash) => { pjListY = scrollY; nav(hash); listHop = location.hash; };
  const toList = () => { if (listHop && listHop === location.hash && history.length > 1) history.back(); else location.replace("#project"); };

