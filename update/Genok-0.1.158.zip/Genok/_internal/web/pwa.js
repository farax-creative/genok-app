// The home-screen app (PWA) on a phone: Android's "add to home screen" row in Settings, the
// iPhone step after pairing (phone.js), the iPhone note under notifications (v2.js), and the
// language web/offline.html speaks when the PC is not reached.
// Uses v2.js globals at call time: tl, ic. Run: node --test tests/pwa.test.js

// An iPhone or iPad. iPadOS asks for desktop pages and says "Macintosh"; touch gives it away.
function pwaIOS(ua, touch) {
  ua = String(ua || "");
  return /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && touch > 1);
}
// Safari itself. The home-screen app is made from Safari and takes Safari's cookies (the
// pairing) only at the moment it is added; Chrome, Firefox or another app's browser on iOS
// keep their own.
const PWA_NOT_SAFARI = /CriOS|FxiOS|EdgiOS|OPiOS|GSA\/|YaBrowser|DuckDuckGo|KAKAOTALK|Instagram|FBAN|FBAV|\bLine\/|NAVER\(inapp|DaumApps/;
function pwaIOSSafari(ua, touch) {
  ua = String(ua || "");
  return pwaIOS(ua, touch) && /Safari\//.test(ua) && !PWA_NOT_SAFARI.test(ua);
}
// Opened from the home screen (no address bar).
function pwaHome() {
  try { return matchMedia("(display-mode: standalone)").matches || navigator.standalone === true; } catch { return false; }
}

// After pairing on an iPhone in Safari: the one thing left is adding it to the home screen,
// and it must happen now, after pairing, for the app to open paired.
function pwaIOSStepWanted(ua, touch, home) {
  return pwaIOSSafari(ua, touch) && !home;
}
function pwaIOSStepHtml() {
  return `<div class="pw-ok" role="img" aria-label="${tl("phone.paired")}">${ic("check")}</div>`
    + `<h2 class="pw-h" id="pw-pair-h" role="status">${tl("pwa.ios_t")}</h2>`
    + `<p class="pw-d">${tl("pwa.ios_s")}</p>`
    + `<button class="pw-btn press" id="pw-ios-go">${tl("pwa.ios_go")}</button>`;
}

// ---------------------------------------------------------------- Android: install row
// Chrome offers the install once it judges the page installable. Its own bar over the content is
// held back (preventDefault); the offer waits in Settings as one quiet row instead. A prompt can
// be shown once: after any answer the row goes until Chrome offers again.
let pwaPrompt = null;
const pwaTouch = () => { try { return matchMedia("(pointer:coarse)").matches; } catch { return false; } };
const pwaCanInstall = () => !!pwaPrompt && !pwaHome() && pwaTouch();
function pwaRowHtml() {
  return `<div class="srow pwainst" id="pwainst"${pwaCanInstall() ? "" : " hidden"}><span class="srtx"><span class="srt">${tl("pwa.add_t")}</span>`
    + `<span class="srd">${tl("pwa.add_d")}</span></span><span class="srctl"><button class="btn sm press" id="pwainstb">${tl("pwa.add_b")}</button></span></div>`;
}
function pwaRow() {
  const r = document.getElementById("pwainst"); if (!r) return;
  const on = pwaCanInstall();
  if (on && r.hidden) { r.hidden = false; r.classList.add("pwain"); }
  else if (!on) r.hidden = true;
}
function pwaWire(box) {
  const b = box && box.querySelector("#pwainstb"); if (!b) return;
  b.onclick = async () => {
    const p = pwaPrompt; if (!p) return pwaRow();
    b.disabled = true; pwaPrompt = null;
    try { await p.prompt(); await p.userChoice; } catch { /* the browser's own sheet said why */ }
    b.disabled = false; pwaRow();
  };
}
if (typeof window !== "undefined" && typeof addEventListener === "function") {
  addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); pwaPrompt = e; pwaRow(); });
  addEventListener("appinstalled", () => { pwaPrompt = null; pwaRow(); });
  try { matchMedia("(display-mode: standalone)").addEventListener("change", pwaRow); } catch { /* old Safari */ }
  // offline.html cannot load /i18n.js: it reads the app's language from here.
  const keep = () => { try { if (window.I18N_LANG) localStorage.setItem("genok-lang", window.I18N_LANG); } catch { /* private mode */ } };
  addEventListener("DOMContentLoaded", keep);
  addEventListener("loop-lang", keep);
  // A row that appears fades in where it is; nothing moves.
  const st = document.createElement("style");
  st.textContent = ".pwainst.pwain{animation:pwain .22s ease both}@keyframes pwain{from{opacity:0}to{opacity:1}}"
    + "@media (prefers-reduced-motion:reduce){.pwainst.pwain{animation:none}}";
  document.head.appendChild(st);
  window.LOOP_PWA = {row: pwaRowHtml, wire: pwaWire, ios: () => pwaIOS(navigator.userAgent, navigator.maxTouchPoints),
    iosStep: () => pwaIOSStepWanted(navigator.userAgent, navigator.maxTouchPoints, pwaHome()), iosStepHtml: pwaIOSStepHtml};
}

if (typeof module !== "undefined") module.exports = {pwaIOS, pwaIOSSafari, pwaIOSStepWanted};
