// 지금 필요한 일: the pure rules of the one queue (no DOM, no globals), shared by web/queue.js
// and tests/queue_core.test.js.
//   결정 (0): a session or a result cannot move until the person answers - a permission prompt,
//             an open --ask question, a session waiting on input, a result its session waits on.
//   검토 (1): something new to look at, nobody blocked.
//   참고 (2): news and finished work, for the record.
// Only 결정 counts on the bell and the app badge.
(function (root) {
  const TIER = {perm: 0, gate: 0, ask: 0, wait: 0, look: 1, fix: 1, send: 1, lost: 1, stuck: 1, dup: 1, fail: 1, news: 2, done: 2};
  // Inside 결정 the hardest stop first: a permission prompt times out, then a result a session sits on.
  const RANK = {perm: 0, gate: 1, ask: 2, wait: 3, stuck: 0, lost: 1, fail: 2, fix: 3, look: 4, send: 5, dup: 6, news: 0, done: 1};
  const ms = (t) => typeof t === "number" ? (t < 1e12 ? t * 1e3 : t) : Date.parse(t || "") || 0;

  const tierOf = (e) => TIER[e.kind] ?? 2;

  // Snoozed while the store holds the key with the same mark it was put aside on. Anything new on
  // the item or session (a version, a comment, a question, a session line) changes the mark, and
  // the entry is back on its own. `until` is epoch seconds. An entry from the older 나중에 (no
  // mark) keeps its old rule: until its time, or until the next version when it names one.
  const snoozedBy = (store, e, now = Date.now()) => {
    const s = store && store[e.key];
    if (!s || !(s.until * 1e3 > now)) return false;
    return s.mark != null ? s.mark === e.mark : !s.v || s.v === e.v;
  };
  // Keys whose snooze no longer holds because their entry moved on: the store can drop them.
  const released = (store, entries, now = Date.now()) => entries.filter((e) => store && store[e.key] && !snoozedBy(store, e, now)).map((e) => e.key);

  // One entry per thing: a session already in the queue as a permission prompt, a question or a gated result
  // is not listed again as "waiting".
  function dedupe(entries) {
    const held = new Set(entries.filter((e) => (e.kind === "perm" || e.kind === "gate" || e.kind === "ask") && e.sid).map((e) => e.sid)), seen = new Set();
    return entries.filter((e) => {
      if (e.kind === "wait" && e.sid && held.has(e.sid)) return false;
      if (seen.has(e.key)) return false; seen.add(e.key); return true;
    });
  }

  // 오래된 순: the longest wait first, whatever its kind; a wait with no time goes last.
  const oldest = (a, b) => (!ms(a.at) && !ms(b.at)) ? 0 : (ms(a.at) || Infinity) - (ms(b.at) || Infinity);

  // entries: [{key, kind, mark, at, sid?}] -> {tiers: [[], [], []], aside: [], count}
  // old: 오래된 순 on 결정 and 검토 instead of their kind order.
  function build(entries, store, now = Date.now(), old = false) {
    const tiers = [[], [], []], aside = [];
    dedupe(entries).forEach((e) => (snoozedBy(store, e, now) ? aside : tiers[tierOf(e)]).push(e));
    // 결정 oldest first (the longest wait is the most overdue); 검토 and 참고 newest first.
    tiers[0].sort(old ? oldest : (a, b) => RANK[a.kind] - RANK[b.kind] || ms(a.at) - ms(b.at));
    tiers[1].sort(old ? oldest : (a, b) => RANK[a.kind] - RANK[b.kind] || ms(b.at) - ms(a.at));
    tiers[2].sort((a, b) => ms(b.at) - ms(a.at));
    aside.sort((a, b) => tierOf(a) - tierOf(b) || ms(b.at) - ms(a.at));
    return {tiers, aside, count: tiers[0].length};
  }

  // The mark an item stands on: its version, how many comments and how many open questions.
  const itemMark = (x) => [x.v || "", x.comments || 0, x.asked || 0].join("|");

  // Focus walking: J/K or arrows move within the flat list of visible keys, clamped at the ends.
  const step = (keys, at, d) => { if (!keys.length) return ""; const i = keys.indexOf(at);
    return keys[i < 0 ? (d > 0 ? 0 : keys.length - 1) : Math.max(0, Math.min(keys.length - 1, i + d))]; };

  // 다음 (N): the entry after the one on screen, round to the first; the first when nothing of the
  // list is on screen.
  const after = (keys, at) => keys.length ? keys[(keys.indexOf(at) + 1) % keys.length] : "";

  // How long something has waited, in calendar days (0 = today, local time); null with no time.
  const age = (at, now = Date.now()) => { const t = ms(at); if (!t) return null;
    const day = (x) => { const d = new Date(x); return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()); };
    return Math.max(0, Math.round((day(now) - day(t)) / 864e5)); };

  // 미루기 · 내일 아침: epoch seconds of the next 9:00 after `now`, local time.
  const morning = (now = Date.now()) => { const t = new Date(now); t.setDate(t.getDate() + 1); t.setHours(9, 0, 0, 0); return Math.floor(t / 1000); };

  // Option keys: 1-9 pick the first nine choices of a card, anything else is not an option key.
  const optKey = (k, n) => /^[1-9]$/.test(k) && +k <= n ? +k - 1 : -1;

  const api = {TIER, tierOf, snoozedBy, released, dedupe, build, itemMark, step, after, morning, optKey, age};
  if (typeof module === "object" && module.exports) module.exports = api; else root.GQCore = api;
})(typeof window === "undefined" ? globalThis : window);
