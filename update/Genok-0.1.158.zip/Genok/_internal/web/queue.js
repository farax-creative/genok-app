// 지금 필요한 일: one ordered queue in three tiers (rules in web/queue-core.js).
// It is the default tab of 알림 (#inbox) and, cut to its 결정 tier, the top of home: the two places
// that used to draw "what waits" each their own way. 결정 cards are answered inside the card with
// their buttons. On the 알림 tabs only (not home), J/K or the arrows move the focus, 1-4 press the
// focused card's buttons and Enter opens it.
// 미루기 puts a card aside until something new arrives on its item or session, or until tomorrow
// 9:00 (whichever comes first); what is put aside stays out of sight under one 다시 알림 N line.
// N (Ctrl+Shift+J anywhere) jumps to the next 결정 across every folder; on a phone a small 다음
// button stands above the tab bar while anything waits.
// Reads v2.js's state and helpers (D, PERM, attL, todo kinds, snooze, sendNow ...) by name.
(function () {
  const C = window.GQCore;
  // After the lab layers v2.js has already put in <head>, so these rules win over glass.css.
  const css = document.createElement("link"); css.rel = "stylesheet"; css.href = "/ovh-queue.css"; document.head.appendChild(css);
  const T_NAME = () => [tl("gq.t0"), tl("gq.t1"), tl("gq.t2")];
  let focus = "", shown = [12, 6], pick = "", showAside = false;

  const room = (sid) => attL("rooms").find((r) => r.key === sid);
  const hid = (k) => typeof turnHid === "function" && turnHid(k);

  // Every thing that may want the person, as queue entries. Kinds switched off in 알림 고르기 stay out.
  function entries() {
    const out = [], turn = new Set(attL("rooms").filter((r) => r.turn).map((r) => r.key)), inItems = new Set();
    PERM.forEach((p) => out.push({kind: "perm", key: "p:" + p.id, sid: p.sid, mark: String(p.id), at: p.at, p}));
    D.items.forEach((x) => {
      if (libHide.has(iid(x)) || x.finished) return;
      const base = {key: iid(x), mark: C.itemMark(x), v: x.v, at: x.at, sid: x.session || "", x};
      if (askQ(x) && !hid("ask")) { out.push({...base, kind: "ask"}); inItems.add(iid(x)); }
      else if (stMine(x) && !hid("look")) { out.push({...base, kind: x.session && turn.has(x.session) ? "gate" : "look"}); inItems.add(iid(x)); }
    });
    const fixes = new Map(); claimedDirs().forEach((c) => { const k = iid(c.it); if (!inItems.has(k)) (fixes.get(k) || fixes.set(k, []).get(k)).push(c); });
    fixes.forEach((L, k) => out.push({kind: "fix", key: "x:" + k, mark: L.map((c) => c.id).join(","), at: L[0].it.at, x: L[0].it, L}));
    if (!hid("unsent")) D.items.filter((x) => x.unsent > 0).forEach((x) => out.push({kind: "send", key: "u:" + iid(x), mark: x.v + "|" + x.unsent, at: x.at, x}));
    if (!hid("blocked")) blockedL().forEach((a) => { const r = room(a.session) || {};
      out.push({kind: "wait", key: "s:" + (a.session || a.dept), sid: a.session, mark: a.needs + "|" + (r.active || a.mark || ""), at: r.active || "", a, r}); });
    if (!hid("lost")) attL("lost").forEach((r) => out.push({kind: "lost", key: "l:" + r.dept + "/" + (r.session || ""), mark: r.n + "|" + r.at, at: r.at, r}));
    if (!hid("stuck")) attL("stuck").forEach((r) => out.push({kind: "stuck", key: "k:" + r.key, mark: String(r.stuck || ""), at: r.active || "", r}));
    if (!hid("dup")) attL("dup").forEach((r) => out.push({kind: "dup", key: "d:" + r.dept, mark: String(r.extra), at: r.active || "", r}));
    if (!hid("fail")) attL("fail").forEach((t) => out.push({kind: "fail", key: "f:" + t.id, mark: String(t.last || ""), at: t.last || "", t}));
    newsList().filter((a) => newsNew(a) && !inItems.has(a.item)).forEach((a) => out.push({kind: "news", key: "n:" + newsKey(a), mark: "1", at: a.at, a}));
    unreadRooms().forEach((r) => out.push({kind: "done", key: "r:" + r.key, mark: String(r.active || ""), at: r.active || "", r}));
    return out;
  }
  // 오래된 순 (the 할 것 toggle, v2-inbox.js oldFirst) orders 결정 and 검토 by the longest wait.
  const state = () => C.build(entries(), D.snooze || {}, Date.now(), oldFirst());

  // ---- what each kind says, leads with, offers and opens ----
  const sub = (...b) => b.filter(Boolean).join(" · ");
  const where = (x) => pname(gname(x));
  function face(e) {
    const x = e.x, q = x && x.ask_next;
    switch (e.kind) {
      // A told-only prompt (info) is answered in the Claude window: no buttons, as the old permCard.
      case "perm": return {lead: `<span class="ico sm gq-ic">${ic("shield")}</span>`, t: permWho(e.p) + " · " + e.p.tool, s: e.p.info ? sub(e.p.text, tl("hook.info")) : e.p.text, mono: 1,
        acts: e.p.info ? [] : [tl("perm.allow"), tl("perm.deny")], end: e.p.end};
      case "ask": return {lead: thumb(x, "ico sm"), t: q ? q.q : x.title, s: sub(x.title, where(x), q && q.of > 1 ? tl("gq.ask.of", {n: q.n, of: q.of}) : ""),
        acts: q && q.options.length ? q.options : [tl("home.v.answer")], rec: q && q.options.length ? q.rec : null};
      case "gate": return {lead: thumb(x, "ico sm"), t: x.title, s: sub(tl("gq.gate.s"), where(x)), acts: [tl("STATUS_T.4"), tl("gq.fix")]};
      case "wait": return {lead: deptIco(e.r.dept ? e.r : e.a, "ico sm"), t: pname(e.a.dept), s: sub(needsText(e.a.needs, e.a.agent), e.at ? ago(e.at) : ""), acts: [tl("search.3")]};
      case "look": return {lead: thumb(x, "ico sm"), t: x.title, s: window.genokBeta?.("pai") ? where(x) : sub(where(x), ago(x.at))};   // with beta "pai" its wait is the age at the end
      case "fix": return {lead: thumb(x, "ico sm"), t: x.title, s: tl("fixCard.s", {v: e.L[0].fixed_in || "", n: e.L.length})};
      case "send": return {lead: thumb(x, "ico sm"), t: x.title, s: tl("inboxDo.1", {esc: pname(x.dept), unsent: x.unsent}).replace(/^\s*·\s*/, "")};
      case "lost": return {lead: `<span class="ico sm gq-ic">${ic("chat")}</span>`, t: pname(e.r.dept), s: sub(tl("att.lost.n", {n: e.r.n}), ago(e.r.at))};
      case "stuck": return {lead: `<span class="ico sm gq-ic">${ic("warn")}</span>`, t: pname(e.r.dept), s: e.r.stuck_hint || e.r.stuck || ""};
      case "dup": return {lead: `<span class="ico sm gq-ic">${ic("copy")}</span>`, t: pname(e.r.dept), s: tl("att.dup.s", {n: e.r.extra + 1})};
      case "fail": return {lead: `<span class="ico sm gq-ic">${ic("clock")}</span>`, t: e.t.name, s: sub(e.t.last ? ago(e.t.last) : "", e.t.note || "")};
      case "news": return {lead: `<span class="ico sm gq-ic">${ic(e.a.i)}</span>`, t: e.a.t, s: sub(e.a.s, ago(e.a.at))};
      case "done": return {lead: deptIco(e.r, "ico sm"), t: pname(e.r.dept), s: sub(tl("gq.done.s"), ago(e.r.active))};
    }
    return {lead: "", t: e.key, s: ""};
  }
  function go(e) {
    const x = e.x;
    if (e.kind === "fix") dirsOpenOf = iid(x);
    if (x) return "item/" + iid(x);
    if (e.kind === "perm") { const r = room(e.p.sid); return r ? roomGo(r.dept, e.p.sid) : "project"; }
    if (e.kind === "wait") return roomGo(e.a.dept, e.a.session);
    if (e.kind === "lost") return roomGo(e.r.dept, e.r.session);
    if (e.kind === "stuck" || e.kind === "done") return roomGo(e.r.dept, e.r.key);
    if (e.kind === "dup") return roomGo(e.r.dept);
    if (e.kind === "fail") return "routines";
    if (e.kind === "news") return e.a.item ? "item/" + e.a.item : "inbox/news";
    return "inbox";
  }

  // ---- markup ----
  const clock = (e, back) => back
    ? `<button class="gq-snz press" data-gqback aria-label="${tl("toggleFav.3")}" title="${tl("toggleFav.3")}">${ic("undo")}</button>`
    : `<button class="gq-snz press" data-gqsnz aria-label="${tl("gq.snooze")}" title="${tl("gq.snooze")} (H)">${ic("clock")}</button>`;
  // 미루기 asks how long in the card itself: until tomorrow morning or until something new.
  const picker = () => `<span class="gq-pk" role="group" aria-label="${tl("gq.snooze")}"><button class="gq-a press" data-gqsz="m"><span>${tl("gq.snz.morning")}</span></button><button class="gq-a press" data-gqsz="o"><span>${tl("gq.snz.open")}</span></button><button class="gq-snz press" data-gqsz="x" aria-label="${tl("rv.close")}" title="${tl("rv.close")} (Esc)">${ic("x")}</button></span>`;
  // When a put-aside entry comes back by itself.
  const wakes = (e) => { const z = (D.snooze || {})[e.key]; return z && z.until < SNZ_OPEN ? tl("gq.snz.at", {t: snzWhen(z)}) : tl("gq.snz.open"); };
  // 오늘 / N일: how long a result in 결정 or 검토 has waited; three days and more stand out. Prompts and
  // sessions keep their minutes in the sub line, where a day says nothing.
  const ageEm = (e) => { const n = !window.genokBeta?.("pai") || !e.x || C.tierOf(e) > 1 ? null : C.age(e.at);
    return n == null ? "" : `<em class="gq-age num${n >= 3 ? " old" : ""}">${esc(waitAge(e.at))}</em>`; };
  function card(e, back) {
    const f = face(e), acts = (f.acts || []).map((a, i) => `<button class="gq-a press${i === f.rec ? " rec" : ""}${i === 0 && f.rec == null ? " pri" : ""}" data-gqa="${i}" title="${esc(a)}">${i < 9 ? `<kbd class="num">${i + 1}</kbd>` : ""}<span>${esc(a)}</span></button>`).join("");
    // Three choices or long ones do not fit beside the title: they go under it.
    const wide = !back && ((f.acts || []).length > 2 || (f.acts || []).join("").length > 22);
    return `<article class="gq-c${wide ? " gq-w" : ""}${focus === e.key ? " gq-f" : ""}" data-gq="${esc(e.key)}" data-kind="${e.kind}">
      <button class="gq-h press" data-gqopen>${f.lead}<span class="gq-tx"><b class="gq-t">${esc(f.t)}</b><span class="gq-s${f.mono ? " mono" : ""}">${esc(f.s)}${f.end ? ` · <span class="num" data-perm-end="${Math.round(f.end)}">${permLeft(f.end)}</span>` : ""}</span></span>${ageEm(e)}</button>
      <div class="gq-acts">${back ? `<span class="gq-when">${esc(wakes(e))}</span>` : pick === e.key ? picker() : acts}${pick === e.key && !back ? "" : clock(e, back)}</div></article>`;
  }
  function row(e, back) {
    const f = face(e), unread = e.kind === "news" || e.kind === "done";
    return `<div class="gq-r${focus === e.key ? " gq-f" : ""}${pick === e.key ? " gq-pick" : ""}" data-gq="${esc(e.key)}" data-kind="${e.kind}"><button class="gq-h press" data-gqopen>${f.lead}<span class="gq-tx"><b class="gq-t">${esc(f.t)}</b><span class="gq-s">${esc(back ? sub(f.s, wakes(e)) : f.s)}</span></span>${ageEm(e)}</button>${pick === e.key && !back ? picker() : unread && !back ? "" : clock(e, back)}</div>`;
  }
  const head = (i, n, tool = "") => `<div class="gq-th" data-tier="${i}"><span>${T_NAME()[i]}</span><em class="num">${n}</em><span class="sp"></span>${tool}</div>`;
  const moreBtn = (i, n) => n > 0 ? `<button class="gq-more press" data-gqmore="${i}">${tl("gq.more", {n})}</button>` : "";

  // 다시 알림 N: what was put aside, out of sight until asked for.
  const asideBit = (S) => !S.aside.length ? "" : `<section class="gq-tier gq-z" data-tier="z"><button class="gq-more gq-zt press" data-gqaside aria-expanded="${showAside}">${ic("clock")}<span>${tl("gq.aside.n", {n: S.aside.length})}</span>${ic("chev", "i dn")}</button>`
    + (showAside ? `<div class="gq-list gq-in">${S.aside.map((e) => row(e, true)).join("")}</div>` : "") + `</section>`;
  function body(S) {
    const [d, r, n] = S.tiers, cut = (L, i) => L.slice(0, shown[i - 1]);
    if (!d.length && !r.length && !n.length) return neverLoaded() ? `<div class="gq-empty notload">${notLoadedHtml()}</div>` : `<div class="gq-empty"><b>${tl("gq.empty")}</b></div>` + asideBit(S);
    return `<section class="gq-tier" data-tier="0">${head(0, d.length)}${d.length ? d.map((e) => card(e)).join("") : `<div class="gq-none">${tl("gq.none")}</div>`}</section>`
      + (r.length ? `<section class="gq-tier" data-tier="1">${head(1, r.length)}<div class="gq-list">${cut(r, 1).map((e) => row(e)).join("")}</div>${moreBtn(1, r.length - shown[0])}</section>` : "")
      + (n.length ? `<section class="gq-tier" data-tier="2">${head(2, n.length, `<button class="ib press" data-gqread aria-label="${tl("sx.allread")}" title="${tl("sx.allread")}">${icl("read")}</button>`)}<div class="gq-list">${cut(n, 2).map((e) => row(e)).join("")}</div>${moreBtn(2, n.length - shown[1])}</section>` : "")
      + asideBit(S);
  }

  // ---- actions ----
  let S = null;
  const byKey = (k) => S && [...S.tiers.flat(), ...S.aside].find((e) => e.key === k);
  const again = () => { if (typeof redrawTurn === "function") redrawTurn(); };
  function fold(el, then) { if (!el) return then(); el.classList.add("gq-going"); setTimeout(then, RM() ? 0 : 160); }
  async function choose(e, i, el) {
    const x = e.x;
    if (e.kind === "perm") {
      el && el.querySelectorAll("button").forEach((b) => b.disabled = true);
      // A refused press keeps the card: the request may still be waiting in the terminal.
      try { await post("/api/permission/answer", {id: e.p.id, allow: i === 0}); }
      catch (err) { toast(err.message); el && el.querySelectorAll("button").forEach((b) => b.disabled = false); return; }
      PERM = PERM.filter((p) => p.id !== e.p.id); return fold(el, permDrawn);
    }
    if (e.kind === "ask") {
      const q = x.ask_next;
      if (!q || !q.options.length || q.options[i] == null) return nav(go(e));
      el && el.querySelectorAll("button").forEach((b) => b.disabled = true);
      try {
        await post("/api/comment", {p: x.project, i: x.id, v: x.v, text: `[답]\n${q.n}. ${q.q} → ${q.options[i]}`});
        await sendNow({p: x.project, i: x.id, v: x.v, dept: x.dept});
        fold(el, async () => { await load(); again(); });
      } catch (err) { toast(err.message); el && el.querySelectorAll("button").forEach((b) => b.disabled = false); }
      return;
    }
    if (e.kind === "gate") return i === 0 ? fold(el, () => approveMany([x])) : rejectSheet(itemIt(x));
    nav(go(e));
  }
  function open(e) {
    if (e.kind === "news") readNews([newsKey(e.a)]);
    nav(go(e));
  }
  // Either way it also comes back the moment something new arrives (the mark changes).
  const putAside = (e, morning) => { pick = ""; snooze(e.key, morning ? C.morning() : SNZ_OPEN, e.mark); };
  const pickOn = (k) => { pick = k; again(); };
  const takeBack = (e) => snooze(e.key, null);
  async function readAll() {
    const N = S.tiers[2]; readNews(N.filter((e) => e.kind === "news").map((e) => newsKey(e.a)));
    await roomsRead(N.filter((e) => e.kind === "done").map((e) => e.r.key));
    toast(tl("sx.allread.done")); again();
  }

  // One listener for every host (the queue tab, 나중에, home's strip).
  document.addEventListener("click", (ev) => {
    const host = ev.target.closest?.("[data-gqhost]"); if (!host) return;
    const el = ev.target.closest("[data-gq]"), m = ev.target.closest("[data-gqmore]");
    if (m) { const i = +m.dataset.gqmore; shown[i - 1] += 40; return again(); }
    if (ev.target.closest("[data-gqread]")) return readAll();
    if (ev.target.closest("[data-gqaside]")) { showAside = !showAside; return again(); }
    const e = el && byKey(el.dataset.gq); if (!e) return;
    const a = ev.target.closest("[data-gqa]");
    if (a) return choose(e, +a.dataset.gqa, el);
    const z = ev.target.closest("[data-gqsz]");
    if (z) return z.dataset.gqsz === "x" ? pickOn("") : fold(el, () => putAside(e, z.dataset.gqsz === "m"));
    if (ev.target.closest("[data-gqsnz]")) return pickOn(e.key);
    if (ev.target.closest("[data-gqback]")) return takeBack(e);
    if (ev.target.closest("[data-gqopen]")) return open(e);
  });
  function mark(host) {
    host.querySelectorAll(".gq-f").forEach((el) => el.classList.remove("gq-f"));
    const el = focus && host.querySelector(`[data-gq="${CSS.escape(focus)}"]`);
    if (el) el.classList.add("gq-f");
    return el;
  }

  // ---- the screens ----
  // #inbox, 지금 필요한 일 tab: all three tiers.
  function inbox(top) {
    S = state();
    V().innerHTML = top + `<div class="gq" data-gqhost>${body(S)}</div>`;
  }
  // #inbox, 나중에 tab: what was put aside, each with its way back.
  function aside(top) {
    S = state();
    V().innerHTML = top + `<div class="gq" data-gqhost>${S.aside.length ? `<div class="gq-list">${S.aside.map((e) => C.tierOf(e) === 0 ? card(e, true) : row(e, true)).join("")}</div>` : `<div class="gq-empty"><b>${tl("later.none")}</b></div>`}</div>`;
  }
  // Home: the 결정 tier only (up to three), and one line to the rest.
  function home() {
    S = state();
    const [d, r, n] = S.tiers;
    if (!d.length && !r.length && !n.length) return "";
    const rest = sub(r.length ? T_NAME()[1] + " " + r.length : "", n.length ? T_NAME()[2] + " " + n.length : "");
    return `<section class="gq gq-home" data-gqhost aria-label="${tl("gq.tab")}">${d.slice(0, 3).map((e) => card(e)).join("")}
      <button class="gq-link press" data-go="inbox"><span>${d.length > 3 ? tl("gq.more", {n: d.length - 3}) + (rest ? " · " + rest : "") : rest || tl("gq.tab")}</span>${ic("chev", "i go")}</button></section>`;
  }

  // Keys on the queue tabs. Typing, a sheet or a viewer keeps them.
  let over = null;
  document.addEventListener("pointerover", (ev) => { over = ev.target.closest?.("[data-gqhost] [data-gq]") || over; });
  const busy = (ev) => ev.ctrlKey || ev.metaKey || ev.altKey || ev.target.closest?.("input,textarea,gk-select,[contenteditable]")
    || document.querySelector(".vw,.stk,.jd,.rdview,#ov.on,#sheet.on");
  // Home: 1-9 answer the 결정 card under the pointer or holding the focus (no J/K walk there).
  addEventListener("keydown", (ev) => {
    if (detail || cur !== "home" || busy(ev)) return;
    const el = document.activeElement?.closest?.(".gq-home [data-gq]") || (over?.isConnected && over.matches(".gq-home [data-gq]:hover") ? over : null);
    if (!el) return;
    const bs = el.querySelectorAll("[data-gqa]"), i = C.optKey(ev.key, bs.length);
    if (i >= 0) { ev.preventDefault(); bs[i].click(); }
  });
  addEventListener("keydown", (ev) => {
    if (detail || cur !== "inbox" || !["do", "later"].includes(inTab) || busy(ev)) return;
    const host = V().querySelector("[data-gqhost]"); if (!host || !S) return;
    const k = ev.key, keys = [...host.querySelectorAll("[data-gq]")].map((el) => el.dataset.gq);
    const d = k === "j" || k === "J" || k === "ArrowDown" ? 1 : k === "k" || k === "K" || k === "ArrowUp" ? -1 : 0;
    if (d) { ev.preventDefault(); focus = C.step(keys, focus, d); mark(host)?.scrollIntoView({block: "nearest", behavior: RM() ? "auto" : "smooth"}); return; }
    if (k === "Escape" && pick) { pick = ""; return again(); }
    const el = (focus && mark(host)) || (/^[1-9]$/.test(k) && over?.isConnected && host.contains(over) && over.matches(":hover") ? over : null), e = el && byKey(el.dataset.gq); if (!e) return;
    if (k === "Escape") { focus = ""; mark(host); return; }
    const bs = el.querySelectorAll("[data-gqa]"), oi = C.optKey(k, bs.length);
    if (oi >= 0) { ev.preventDefault(); bs[oi].click(); return; }
    if (/^[1-9]$/.test(k)) return;
    if (k === "Enter") { if (document.activeElement?.closest?.("button") && !el.contains(document.activeElement)) return; ev.preventDefault(); return open(e); }
    // H until something new, Shift+H until tomorrow morning.
    if (k === "h" || k === "H") { ev.preventDefault(); return inTab === "later" || el.closest(".gq-z") ? takeBack(e) : fold(el, () => putAside(e, ev.shiftKey)); }
  });

  // ---- 다음: the next 결정, wherever it is ----
  let lastNext = "";
  function next() {
    const L = state().tiers[0], keys = L.map((e) => e.key);
    if (!L.length) { lastNext = ""; return toast(tl("gq.next.none"), 2200); }
    // On a result's page that result is "here"; elsewhere the one jumped to last.
    const at = detail?.[0] === "item" ? detail[1] : lastNext, k = C.after(keys, at);
    if (k === at && detail?.[0] === "item") return toast(tl("gq.next.only"), 2200);
    lastNext = k; closeSheet(); nav(go(L.find((e) => e.key === k)));
  }
  addEventListener("keydown", (ev) => {
    if (FLOAT || window.Judge?.on?.()) return;
    // Ctrl+Shift+J from anywhere, typing included (Ctrl J alone is the next unread chat).
    if ((ev.ctrlKey || ev.metaKey) && ev.shiftKey && !ev.altKey && (ev.key === "j" || ev.key === "J")) { ev.preventDefault(); return next(); }
    // N on the list screens; a result's own page keeps N for its next result.
    if ((ev.key === "n" || ev.key === "N") && !ev.shiftKey && !busy(ev) && detail?.[0] !== "item" && !ev.repeat) { ev.preventDefault(); next(); }
  });
  // Phone: 다음 floats above the tab bar while anything waits, on the list screens only.
  let fabEl = null;
  function fab() {
    const n = wide() || detail || FLOAT ? 0 : state().count;
    if (!fabEl) {
      if (!n) return;
      fabEl = document.createElement("button");
      fabEl.type = "button"; fabEl.className = "gqfab press";
      fabEl.addEventListener("click", next);
      document.body.appendChild(fabEl);
      // Out of the way while the list moves, so it never sits on a button being reached for.
      let still = 0;
      document.addEventListener("scroll", () => {
        fabEl.classList.add("away"); clearTimeout(still);
        still = setTimeout(() => fabEl.classList.remove("away"), 700);
      }, {capture: true, passive: true});
    }
    fabEl.innerHTML = `<span>${tl("gq.next")}</span><b class="num">${n}</b>${ic("chev")}`;
    fabEl.setAttribute("aria-label", tl("gq.next") + " " + n);
    fabEl.classList.toggle("on", n > 0);
    document.body.classList.toggle("gqfab-on", n > 0);
    fabEl.tabIndex = n ? 0 : -1;
    fabEl.setAttribute("aria-hidden", String(!n));
  }

  window.GQ = {inbox, aside, home, next, fab, count: () => state().count, tiers: () => state().tiers.map((t) => t.length), asideCount: () => state().aside.length};
})();
