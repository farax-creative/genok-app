// Del on a result (beta "pai"): puts the open result away (정리, the archive) and moves on to the
// next one waiting, as an approval does; 되돌리기 in the toast takes it back out and returns to it.
// Works on the item page and in the full-screen viewer over it, never while typing, a sheet is up
// or a drawing is on. Space (play/pause) and Esc (close/back) are the pages' own keys already.
(function () {
  "use strict";
  if (!window.genokBeta?.("pai")) return;

  let busy = false;
  async function putAway() {
    const it = openItem;
    if (busy || !it || it.archived) return;
    busy = true;
    const n = nextOf(it.id);
    try { await post("/api/archive", {p: it.p, i: it.i, on: true}); }
    catch (e) { busy = false; return toast(e.message); }
    toastAct(tl("libOff.2", {n: 1}), tl("toggleFav.3"), async () => {
      try { await post("/api/archive", {p: it.p, i: it.i, on: false, undo: true}); }
      catch (e) { return toast(e.message); }
      await load(); nav("item/" + it.id); toast(tl("libOff.3"), 2200, "restore");
    }, 6000, "archive");
    await load();
    busy = false;
    if (detail?.[0] !== "item" || detail[1] !== it.id) return;       // moved on meanwhile
    if (n && D.items.some((x) => iid(x) === iid(n))) { autoPlay = true; nav("item/" + iid(n)); }
    else back();
  }

  addEventListener("keydown", (e) => {
    if (e.key !== "Delete" || e.repeat || e.defaultPrevented) return;
    const vw = document.querySelector(".vw");
    // The viewer over the item page: same gates as the page's keys, the viewer aside.
    const free = vw ? !!openItem && detail?.[0] === "item" && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && !typingIn(e.target)
      && !document.getElementById("sheet")?.classList.contains("on") && !drawing
      : itemKeysFree(e) && !e.shiftKey;
    if (!free || wrLive()) return;
    e.preventDefault();
    if (vw && vwClose) vwClose();
    putAway();
  });
})();
