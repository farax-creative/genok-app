// 가림 모드: what must not be read over a shoulder or land in a screenshot (e-mail addresses, API
// keys and tokens, JWTs) is drawn as dots. Display only: the record and what is sent stay as they
// are; the chat and the floating window pass the text they draw through here while the switch is
// on, so what is copied from the screen is the masked text too. mask() is pure and is tested in
// tests/redact.test.js; window.Redact in the browser, module.exports in node.
(function () {
  "use strict";

  const DOTS = "••••••••";                 // one length for every secret: how long it was is not shown either
  const count = (s, re) => (s.match(re) || []).length;
  // Letters and digits mixed the way a generated secret is, not the way a word or a name is.
  const mixed = (s) => count(s, /[0-9]/g) >= 3 && count(s, /[A-Z]/g) >= 3 && count(s, /[a-z]/g) >= 3;

  // In this order: a token inside a header goes with the header, a key with a known prefix keeps
  // the prefix (which service it was stays readable), and the open-ended rules come last.
  const RULES = [
    [/\b(Bearer|Basic)(\s+)([A-Za-z0-9._~+\/=-]{16,})/g, (m, k, sp, tok) => /[0-9]/.test(tok) || tok.length >= 24 ? k + sp + DOTS : m],
    [/\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g, () => "eyJ" + DOTS],
    [/\b(sk-(?:ant-|proj-|live-|test-)?|gh[pousr]_|github_pat_|glpat-|xox[abprs]-)([A-Za-z0-9_-]{16,})/g, (m, p, rest) => /[0-9]/.test(rest) ? p + DOTS : m],
    [/\b(AKIA|ASIA)[0-9A-Z]{16}\b/g, (m, p) => p + DOTS],
    [/\b(AIza)[0-9A-Za-z_-]{35}/g, (m, p) => p + DOTS],
    // An address, not "icon@2x.png" and not the user every git remote names.
    [/([A-Za-z0-9._%+-]+)@((?:[A-Za-z0-9-]+\.)+)([A-Za-z]{2,})\b/g, (m, who, host, tld) => who === "git" || /^\dx\.$/.test(host) ? m : "•••@•••." + tld],
    // Hex from 48 characters: a commit id (7 to 40) stays readable.
    [/\b[0-9a-fA-F]{48,}\b/g, () => DOTS],
    // A long run of base64. One with "/" in it and neither "+" nor "=" is a path and stays.
    [/(^|[^A-Za-z0-9+\/_.\\=-])([A-Za-z0-9+\/_-]{40,}={0,2})(?![A-Za-z0-9+\/_.\\=-])/g,
      (m, pre, run) => mixed(run) && (!run.includes("/") || /[+=]/.test(run)) ? pre + DOTS : m],
  ];

  function mask(text) {
    let out = String(text == null ? "" : text);
    for (const [re, to] of RULES) out = out.replace(re, to);
    return out;
  }

  const api = {mask};
  if (typeof module !== "undefined" && module.exports) { module.exports = api; return; }

  // The switch is kept on this device (the same key settings' own switches use) and is the same
  // in every window of the app: the floating window follows the main one through "storage".
  // Whoever draws text listens for "redact" on the document and draws again.
  const KEY = "v2-redact";
  const read = () => { try { return localStorage.getItem(KEY) === "1"; } catch (e) { return false; } };
  let on = read();
  const tell = () => document.dispatchEvent(new Event("redact"));
  api.on = () => on;
  api.set = (v) => { on = !!v; try { localStorage.setItem(KEY, on ? "1" : "0"); } catch (e) { /* kept for this visit */ } tell(); };
  api.show = (t) => on ? mask(t) : t;
  addEventListener("storage", (e) => { if (e.key === KEY) { on = read(); tell(); } });
  window.Redact = api;
})();
