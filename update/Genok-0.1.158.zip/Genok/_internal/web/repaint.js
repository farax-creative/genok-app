// Repaint nudge for a browser that drops its compositor layer (see nudgeRepaint in v2.js), and the
// guard that keeps <body> from ever staying hidden. Pure DOM logic, so node can test it.
//
// Why a guard: a first-run bug left <body style="display:none"> behind (black window, nothing
// clickable). The cause was a home-card shell lookup that hid host.parentElement, which on a soft
// redraw IS <body>; the card then returned early and never showed it again. Whatever hides the body
// next time, the app must not stay black, so rescueBody() undoes it and the nudge cannot leave it.
(function () {
  "use strict";

  // Undo a leftover inline display:none on <body>. True when something had to be undone.
  function rescueBody(doc) {
    const b = doc && doc.body;
    if (!b || !b.style || b.style.display !== "none") return false;
    b.style.display = "";
    return true;
  }

  // Force a reflow so a stuck compositor layer repaints. The display is restored even if the reflow
  // throws, and a body already stuck on none comes back to "" instead of being kept.
  function nudgeRepaint(doc) {
    const b = doc && doc.body;
    if (!b || !b.style) return;
    const prev = b.style.display === "none" ? "" : b.style.display;
    try {
      b.style.display = "none";
      void b.offsetHeight;
    } finally {
      b.style.display = prev;
    }
  }

  const api = {nudgeRepaint, rescueBody};
  if (typeof window !== "undefined") window.LOOP_REPAINT = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
