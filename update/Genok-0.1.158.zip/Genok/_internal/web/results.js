// 결과물 › 용량: what the results take on disk, the clean-up suggestions, the trash and the folder
// check. The screen #storage has no menu row of its own: it is the second tab of 결과물 (v2.js
// MOVED maps it onto that row), served by results.py (/api/storage/*).
//
// Words, one ladder: 정리 = off the lists, files untouched (state 정리됨). 휴지통으로 = the files
// move into the data folder's _trash and can be put back (state 휴지통에 있음). 비우기 = the only
// step that deletes (state 비움), behind a typed confirmation that shows the count and the size,
// and only on this PC.
//
// Sizes come from a background measurement on the server; this page never waits for a walk. While
// one runs it shows what is known and fills in ("계산 중"), and says so when the numbers are old.
// Motion: bars are CSS transitions on transform (a new draw mid-way just retargets them), the
// drill-down bar opens from the segment that was pressed, and reduced motion turns it all into fades.
(function () {
  "use strict";

  Object.assign(P, {
    trash: '<path d="M216,48H176V40a24,24,0,0,0-24-24H104A24,24,0,0,0,80,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM96,40a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96Zm96,168H64V64H192ZM112,104v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Zm48,0v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Z"/>',
  });

  const SEGS = 7;                 // projects drawn as their own segment; the rest fold into "그 밖"
  const STALE_DAYS = 60;          // mirrors results.STALE_DAYS (the label only)
  let ov = null;                  // GET /api/storage
  let list = null;                // rows of the level on screen (project's items / item's versions)
  let listFor = "";               // the route `list` was loaded for
  let trash = null, check = null;
  let sel = new Map();            // key -> {p, i, vs, bytes}: what would go to the trash
  let tsel = new Set();           // trash entry ids picked
  let lastIdx = null;             // anchor for shift-range
  let openSug = null;             // the suggestion group unfolded
  let barAt = 0;                  // when it started opening
  let selAt = "";                 // the level the current picks were made on
  let barFor = null;              // the level whose bar has already opened
  let origin = 50;                // where the bar opens from, in % of its width
  let pollT = 0, sizeMap = null, sizeAt = 0;
  // Labels by kind, as literal keys (tests/test_i18n.py reads them from the source).
  const SUG = () => ({old_versions: tl("res.s.old_versions"), test: tl("res.s.test"), hidden: tl("res.s.hidden"),
    stale: tl("res.s.stale", {d: STALE_DAYS}), large: tl("res.s.large")});
  const KIND = () => ({missing: tl("res.k.missing"), unlisted: tl("res.k.unlisted"), preparing: tl("res.k.preparing"),
    empty_item: tl("res.k.empty_item"), bad_meta: tl("res.k.bad_meta"), ref: tl("res.k.ref"), trash_gone: tl("res.k.trash_gone"),
    orphan_trash: tl("res.k.orphan_trash"), stale_index: tl("res.k.stale_index"), stale_pending: tl("res.k.stale_pending"), stash: tl("res.k.stash")});
  const KIND2 = () => ({half_moved: tl("res.k.half_moved"), trash_unlisted: tl("res.k.trash_unlisted")});
  const FIX = () => ({missing: tl("res.f.missing"), preparing: tl("res.toTrash"), empty_item: tl("res.toTrash"),
    stale_index: tl("res.f.rebuild"), stale_pending: tl("res.f.rebuild"), half_moved: tl("res.undo")});
  const pn = (p) => (typeof pname === "function" ? pname(p) : p);
  // What became of a version whose files are not in place: in the trash, emptied, or just missing.
  const goneTag = (g) => tag(g.purged ? tl("res.gone") : g.external ? tl("res.noFile") : tl("res.inTrash"));
  // 결과물 has three tabs: the list (#lib), every result on one board (#board, v2.js) and this screen;
  // with the "board" beta on, 릴 (#reel, web/board-spread.js) sits after 보드.
  // v2.js draws the same switch on the other two.
  window.resTabs = (at) => `<div class="seg rs-sw" role="tablist" aria-label="${esc(tl("res.nav"))}">${[["lib", tl("res.tab.list")], ...(window.BoardView ? [["board", tl("board.board")]] : []), ...(window.genokBeta?.("board") ? [["reel", tl("bdx.reel")]] : []), ["storage", tl("res.tab.size")]].map(([k, n]) =>
    `<button class="press ${k === at ? "on" : ""}" role="tab" aria-selected="${k === at}" data-go="${k}">${esc(n)}</button>`).join("")}</div>`;

  // ---- small helpers ----------------------------------------------------
  const fmt = (b) => { if (!b) return "0 MB"; const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0, n = b;
    while (n >= 1000 && i < 4) { n /= 1024; i++; } return (n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)) + " " + u[i]; };
  const route = () => { let h = location.hash.slice(1); try { h = decodeURIComponent(h); } catch (e) {}
    const a = h.split("/"); return {on: a[0] === "storage", tab: ["tidy", "trash", "check"].includes(a[1]) ? a[1] : "size",
      p: a[1] === "p" ? a[2] || "" : "", i: a[1] === "p" ? a.slice(3).join("/") : ""}; };
  const href = (p, i) => "storage" + (p ? "/p/" + encodeURIComponent(p) + (i ? "/" + encodeURIComponent(i) : "") : "");
  const q = (o) => Object.entries(o).map(([k, v]) => k + "=" + encodeURIComponent(v)).join("&");
  const vnum = (v) => (typeof vShort === "function" ? vShort(v) : v);
  const selBytes = () => [...sel.values()].reduce((n, x) => n + x.bytes, 0);

  // ---- data -------------------------------------------------------------
  async function loadOverview() { ov = await get("/api/storage"); return ov; }
  async function loadLevel(r) {
    const key = r.p + "/" + r.i;
    if (r.i) list = await get("/api/storage/item?" + q({p: r.p, i: r.i}));
    else if (r.p) list = await get("/api/storage/items?" + q({p: r.p}));
    else list = null;
    listFor = key;
  }
  function poll() {
    clearTimeout(pollT);
    if (!ov || !(ov.computing || ov.stale)) return;
    pollT = setTimeout(async () => { const r = route(); if (!r.on) return;
      try { await loadOverview(); if (r.tab === "size") await loadLevel(r); } catch (e) { return; }
      if (route().on) draw(true); }, 1000);
  }

  // ---- shared pieces ----------------------------------------------------
  function tabs(r) {
    const n = ov && ov.trash.count, sg = ov ? ov.reclaim || 0 : 0;
    const T = [["size", tl("res.tab.by"), ""], ["tidy", tl("res.tab.tidy"), sg ? fmt(sg) : ""],
      ["trash", tl("res.tab.trash"), n ? String(n) : ""], ["check", tl("res.tab.check"), ""]];
    return `<div class="rs-top">${resTabs("storage")}<div class="rs-tabs" role="tablist">${T.map(([k, t, em]) =>
      `<button class="chip press${r.tab === k ? " on" : ""}" role="tab" aria-selected="${r.tab === k}" data-rsgo="storage${k === "size" ? "" : "/" + k}">${t}${em ? ` <em class="num">${em}</em>` : ""}</button>`).join("")}</div></div>`;
  }
  function status() {
    if (!ov) return "";
    if (ov.computing) { const [a, b] = ov.progress;
      return `<span class="rs-st busy" role="status"><i style="--w:${b ? a / b : 0}"></i>${tl("res.computing", {a, b})}</span>`; }
    if (ov.stale) return `<span class="rs-st" role="status">${tl("res.stale")}</span>`;
    return `<span class="rs-st">${tl("res.asof", {t: ago(ov.at)})} · <button class="lnk press" data-rsrescan>${tl("res.rescan")}</button></span>`;
  }
  // One proportional bar. parts: [{name, bytes, go?, n}] largest first; the tail folds into one.
  function bar(parts, total) {
    const shown = parts.filter((x) => x.bytes > 0).slice(0, SEGS), rest = parts.filter((x) => x.bytes > 0).slice(SEGS);
    const restB = rest.reduce((a, x) => a + x.bytes, 0);
    if (!total) return `<div class="rs-bar empty" aria-hidden="true"></div>`;
    return `<div class="rs-bar pre" style="--ox:${origin}%" role="img" aria-label="${esc(shown.map((x) => x.name + " " + fmt(x.bytes)).join(", "))}">${shown.map((x, n) =>
      `<${x.go ? "button" : "span"} class="rs-seg${x.go ? " press" : ""}${n >= 4 ? " far" : ""}" style="flex-grow:${x.bytes};--k:${tone(n)}%" ${x.go ? `data-rsgo="${esc(x.go)}"` : ""} title="${esc(x.name)} · ${fmt(x.bytes)}">${x.bytes / total >= 0.08 ? `<span>${esc(x.name)}</span>` : ""}</${x.go ? "button" : "span"}>`).join("")}${
      restB ? `<span class="rs-seg rest" style="flex-grow:${restB}" title="${tl("res.rest", {n: rest.length})} · ${fmt(restB)}">${restB / total >= 0.08 ? `<span>${tl("res.rest", {n: rest.length})}</span>` : ""}</span>` : ""}</div>`;
  }
  const dot = (n) => `<i class="rs-dot" style="--k:${n < SEGS ? tone(n) : 22}%"></i>`;
  // One row: an optional checkbox, a main part (a button when it leads somewhere), actions, size.
  const TONES = [90, 76, 63, 51, 41, 33, 27, 22];
  const tone = (n) => TONES[Math.min(n, TONES.length - 1)];
  function row(o) {
    const picked = o.key && sel.has(o.key);
    const ck = o.key === undefined ? "" : o.locked
      ? `<span class="rs-ck locked" title="${tl("res.locked")}" aria-hidden="true">${ic("pin")}</span>`
      : `<button class="rs-ck press" role="checkbox" aria-checked="${!!picked}" aria-label="${esc(o.title)}" data-rsck="${esc(o.key)}" data-idx="${o.idx}">${ic("check")}</button>`;
    const main = `<span class="rs-t">${o.dot !== undefined ? dot(o.dot) : ""}<b>${esc(o.title)}</b>${o.tags || ""}</span>${o.sub ? `<span class="rs-s">${o.sub}</span>` : ""}`;
    return `<div class="rs-row${picked ? " sel" : ""}${o.dim ? " dim" : ""}${o.key === undefined ? " nock" : ""}" style="--w:${o.w || 0}">
      <i class="rs-fill" aria-hidden="true"${o.part ? ` style="--r:${o.part}"` : ""}></i>${ck}
      ${o.go ? `<button class="rs-main press" data-rsgo="${esc(o.go)}">${main}</button>` : `<span class="rs-main">${main}</span>`}
      ${o.acts ? `<span class="rs-acts">${o.acts}</span>` : ""}
      <span class="rs-sz num">${fmt(o.bytes)}</span></div>`;
  }
  const tag = (t, c = "") => `<em class="rs-tag ${c}">${t}</em>`;
  function selBar() {
    if (!sel.size) return "";
    return `<div class="rs-selbar" role="region" aria-live="polite"><span class="num">${tl("res.sel", {n: sel.size, s: fmt(selBytes())})}</span>
      <button class="lnk press" data-rsclear>${tl("res.selClear")}</button><button class="btn sm press" data-rstrash>${ic("trash")}${tl("res.toTrash")}</button></div>`;
  }

  // ---- 용량 --------------------------------------------------------------
  function sizeView(r) {
    const crumb = `<nav class="rs-crumb" aria-label="${tl("res.nav")}"><button class="lnk press" data-rsgo="storage"${r.p ? "" : " aria-current=\"page\""}>${tl("res.all")}</button>${
      r.p ? `${ic("chev")}<button class="lnk press" data-rsgo="${esc(href(r.p))}"${r.i ? "" : " aria-current=\"page\""}>${esc(pn(r.p))}</button>` : ""}${
      r.i ? `${ic("chev")}<span aria-current="page">${esc((list && list.title) || r.i)}</span>` : ""}</nav>`;
    let parts = [], total = 0, rows = "", headline = "", tools = "";
    if (!r.p) {
      total = ov.bytes;
      parts = ov.projects.map((p) => ({name: pn(p.name), bytes: p.bytes, go: href(p.name)}));
      const top = ov.projects[0] ? ov.projects[0].bytes : 0;
      rows = ov.projects.map((p, n) => row({title: parts[n].name, dot: n, bytes: p.bytes, w: top ? p.bytes / top : 0, go: href(p.name),
        part: p.bytes && p.reclaim ? p.reclaim / p.bytes : 0,
        sub: tl("res.items", {n: p.items}) + " · " + tl("res.versions", {n: p.versions}) + (p.reclaim ? ` · <span class="rs-can num">${tl("res.reclaim", {s: fmt(p.reclaim)})}</span>` : "")})).join("");
      headline = `<b class="num">${fmt(ov.bytes)}</b><span>${tl("res.items", {n: ov.items})}</span>`;
    } else if (!r.i) {
      const its = (list && list.items) || [];
      total = its.reduce((a, x) => a + x.bytes, 0);
      parts = its.map((x) => ({name: x.title, bytes: x.bytes, go: href(x.p, x.i)}));
      const top = its[0] ? its[0].bytes : 0;
      rows = its.map((x, n) => row({key: "i|" + x.p + "|" + x.i, idx: n, title: x.title, dot: n, bytes: x.bytes, w: top ? x.bytes / top : 0, go: href(x.p, x.i), part: x.bytes && x.reclaim ? Math.min(1, x.reclaim / x.bytes) : 0,
        tags: (x.final ? tag(tl("res.final") + " " + vnum(x.final), "fin") : "") + (x.hidden ? tag(x.auto ? tl("res.autoHidden") : tl("res.hiddenTag")) : "") + (x.removed ? tag(tl("res.noFile") + " " + x.removed) : ""),
        sub: tl("res.versions", {n: x.versions}) + " · " + ago(x.activity || x.at) + (x.reclaim ? ` · <span class="rs-can num">${tl("res.reclaim", {s: fmt(x.reclaim)})}</span>` : "")})).join("");
      headline = `<b class="num">${fmt(total)}</b><span>${tl("res.items", {n: its.length})}</span>`;
    } else {
      const vs = (list && list.versions) || [];
      const live = vs.filter((v) => !v.removed);
      total = live.reduce((a, x) => a + x.bytes, 0);
      parts = live.slice().sort((a, b) => b.bytes - a.bytes).map((x) => ({name: x.v, bytes: x.bytes}));
      const top = Math.max(0, ...live.map((x) => x.bytes));
      const order = parts.map((x) => x.name);
      const newer = list && list.final && vs.length && vs[0].v !== list.final && !vs[0].removed;
      rows = vs.map((x, n) => { const gone = x.removed, was = gone ? gone.bytes : x.bytes;
        return row({key: gone ? undefined : "v|" + r.p + "|" + r.i + "|" + x.v, idx: n, locked: x.final || x.keep, title: x.v, dot: gone ? undefined : order.indexOf(x.v),
          bytes: was, w: !gone && top ? x.bytes / top : 0, dim: !!gone,
          tags: (x.latest ? tag(tl("res.latest")) : "") + (x.final ? tag(tl("res.final"), "fin") : "") + (x.keep ? tag(tl("res.keep")) : "")
            + (gone ? goneTag(gone) : ""),
          sub: ago(gone ? gone.at : x.at) + (x.note ? " · " + esc(String(x.note).slice(0, 60)) : ""),
          acts: gone ? "" : `<button class="btn sm weak press" data-rsfinal="${x.v}" data-on="${!x.final}">${x.final ? tl("res.unFinal") : tl("res.markFinal")}</button>`
            + `<button class="btn sm weak press" data-rskeep="${x.v}" data-on="${!x.keep}">${x.keep ? tl("res.unKeep") : tl("res.markKeep")}</button>`}); }).join("");
      headline = `<b class="num">${fmt(total)}</b><span>${tl("res.versions", {n: live.length})}</span>${newer ? `<span class="rs-note">${tl("res.newer")}</span>` : ""}`;
      tools = `<div class="rs-tools"><button class="btn sm weak press" data-item="${esc(r.p + "/" + r.i)}">${tl("res.open")}</button>${
        list && list.final ? `<button class="btn sm weak press" data-rsonly="final">${tl("res.onlyFinal")}</button>` : ""}${
        live.length > 1 ? `<button class="btn sm weak press" data-rsonly="latest">${tl("res.onlyLatest")}</button>` : ""}</div>`;
    }
    const d = ov.disk, used = d ? d.total - d.free : 0;
    const disk = !r.p && d ? `<div class="rs-disk" title="${tl("res.disk", {u: fmt(used), f: fmt(d.free)})}"><i style="--w:${ov.bytes / d.total}"></i><i class="o" style="--w:${Math.max(0, used - ov.bytes) / d.total}"></i></div>
      <div class="rs-diskt"><span class="a">${tl("res.used", {s: fmt(ov.bytes)})}</span><span class="o num">${tl("res.other", {s: fmt(Math.max(0, used - ov.bytes))})}</span><span class="num">${tl("res.free", {s: fmt(d.free)})}</span></div>` : "";
    // At a glance, on the top level: what could go, and what emptying the trash would free.
    const glance = !r.p && (ov.reclaim || ov.trash.bytes) ? `<div class="rs-glance">${
      ov.reclaim ? `<button class="press" data-rsgo="storage/tidy"><i class="rs-key" aria-hidden="true"></i><span>${tl("res.g.tidy")}</span><b class="num">${fmt(ov.reclaim)}</b>${ic("chev")}</button>` : ""}${
      ov.trash.bytes ? `<button class="press" data-rsgo="storage/trash"><span>${tl("res.g.trash")}</span><b class="num">${fmt(ov.trash.bytes)}</b>${ic("chev")}</button>` : ""}</div>` : "";
    return `<div class="rs-head"><div class="rs-total">${headline}</div>${status()}</div>
      ${bar(parts, total)}${disk}${glance}${crumb}${tools}
      <div class="rs-list" data-rslist>${rows || (ov.computing ? loadingHtml(tl("res.loading")) : `<p class="rs-none">${tl("res.none")}</p>`)}</div>${selBar()}`;
  }

  // ---- 정리할 만한 것 ------------------------------------------------------
  function tidyView() {
    if (!ov.suggest.length) return ov.computing ? loadingHtml(tl("res.loading"), {fill: true}) : `<div class="plan mid"><span class="ico c-grey">${ic("checkCircle")}</span><p>${tl("res.sugNone")}</p></div>`;
    // Two piles: what was already decided about (safe to send off), and what is only worth a look.
    const safe = ov.suggest.filter((s) => s.safe), look = ov.suggest.filter((s) => !s.safe);
    const sec = (t, d, n) => `<div class="rs-sech"><b>${t}</b>${n ? `<em class="num">${fmt(n)}</em>` : ""}<span>${d}</span></div>`;
    return (safe.length ? sec(tl("res.sec.safe"), tl("res.sec.safeD"), ov.reclaim) + safe.map(group).join("") : "")
      + (look.length ? sec(tl("res.sec.look"), tl("res.sec.lookD"), 0) + look.map(group).join("") : "") + selBar();
  }
  function group(s) { { const open = openSug === s.kind, top = s.rows[0] ? s.rows[0].bytes : 0;
      const all = s.rows.every((x) => sel.has("s|" + s.kind + "|" + x.p + "|" + x.i));
      return `<section class="rs-sug${open ? " open" : ""}"><div class="rs-sugh"${s.safe && ov.reclaim ? ` style="--w:${s.net / ov.reclaim}"` : ""}>${s.safe ? `<i class="rs-gbar" aria-hidden="true"></i>` : ""}
        <button class="rs-sugt press" data-rssug="${s.kind}" aria-expanded="${open}">${ic("chev")}<span><b>${SUG()[s.kind] || esc(s.kind)}</b><i class="num">${tl("res.items", {n: s.count})}</i></span></button>
        <span class="rs-rec num">${s.safe ? tl("res.reclaim", {s: fmt(s.net)}) : tl("res.uses", {s: fmt(s.bytes)})}</span>
        ${s.safe ? `<button class="btn sm weak press" data-rssugall="${s.kind}">${all ? tl("res.selClear") : tl("res.sugAll")}</button>` : ""}</div>
        ${open ? `<div class="rs-list" data-rslist>${s.rows.map((x, n) => row({key: "s|" + s.kind + "|" + x.p + "|" + x.i, idx: n, title: x.title, bytes: x.bytes, w: top ? x.bytes / top : 0,
          go: href(x.p, x.i), tags: (x.final ? tag(tl("res.final") + " " + vnum(x.final), "fin") : "") + (x.hidden ? tag(tl("res.hiddenTag")) : ""),
          sub: esc(pn(x.p)) + " · " + tl("res.planGo") + " " + (x.vs ? x.vs.map(vnum).join(" ") : tl("res.all")) + " · " + ago(x.at)})).join("")}</div>` : ""}</section>`; }
  }

  // ---- 휴지통 --------------------------------------------------------------
  function trashView() {
    if (!trash) return loadingHtml(tl("res.loading"), {fill: true});
    const freed = ov ? ov.trash.freed : 0;
    const stuck = trash.stuck ? `<p class="rs-warn" role="note">${tl("res.stuck", {n: trash.stuck})} <button class="lnk press" data-rsgo="storage/check">${tl("res.tab.check")}</button></p>` : "";
    if (!trash.entries.length) return stuck + `<div class="plan mid"><span class="ico c-grey">${ic("trash")}</span><p>${tl("res.trashEmpty")}</p>${freed ? `<p class="rs-s num">${tl("res.freedLog", {s: fmt(freed)})}</p>` : ""}</div>`;
    const top = Math.max(...trash.entries.map((e) => e.bytes));
    const picked = trash.entries.filter((e) => tsel.has(e.id)), pb = picked.reduce((a, e) => a + e.bytes, 0);
    // Emptying deletes for good, so it is offered on this PC only; a phone sees why instead.
    const can = trash.can_empty !== false;
    return stuck + `<div class="rs-head"><div class="rs-total"><b class="num">${fmt(trash.bytes)}</b><span>${tl("res.trashHead", {n: trash.count})}</span></div>
        ${can ? `<button class="btn sm quiet press" data-rsempty="all">${tl("res.empty")}</button>` : `<span class="rs-st">${tl("res.pcOnly")}</span>`}</div>
      <div class="rs-list" data-rslist>${trash.entries.map((e, n) => `<div class="rs-row${tsel.has(e.id) ? " sel" : ""}" style="--w:${top ? e.bytes / top : 0}"><i class="rs-fill" aria-hidden="true"></i>
        <button class="rs-ck press" role="checkbox" aria-checked="${tsel.has(e.id)}" aria-label="${esc(e.title)}" data-rstck="${e.id}" data-idx="${n}">${ic("check")}</button>
        <span class="rs-main"><span class="rs-t"><b>${esc(e.title)}</b></span><span class="rs-s">${esc(pn(e.project))}${e.versions.length ? " · " + e.versions.map(vnum).join(" ") : ""} · ${ago(e.at)}</span></span>
        <span class="rs-acts"><button class="btn sm weak press" data-rsback="${e.id}">${tl("res.undo")}</button></span>
        <span class="rs-sz num">${fmt(e.bytes)}</span></div>`).join("")}</div>
      ${picked.length ? `<div class="rs-selbar" role="region" aria-live="polite"><span class="num">${tl("res.sel", {n: picked.length, s: fmt(pb)})}</span>
        <button class="lnk press" data-rstclear>${tl("res.selClear")}</button><button class="btn sm weak press" data-rsback="sel">${tl("res.undo")}</button>
        ${can ? `<button class="btn sm quiet press" data-rsempty="sel">${tl("res.emptySel")}</button>` : ""}</div>` : ""}`;
  }

  // ---- 점검 ----------------------------------------------------------------
  function checkView() {
    const c = check || {};
    const head = `<div class="rs-head"><p class="rs-desc">${tl("res.checkD")}</p><button class="btn sm press" data-rscheck ${c.running ? "disabled" : ""}>${c.running ? tl("res.checking") : tl("res.checkRun")}</button></div>`;
    if (!c.findings) return head;
    if (!c.findings.length) return head + `<div class="plan mid"><span class="ico c-green">${ic("checkCircle")}</span><p>${tl("res.checkOk")}</p><p class="rs-s">${ago(c.at)}</p></div>`;
    return head + `<p class="rs-s rs-cnt">${tl("res.checkN", {n: c.findings.length})} · ${ago(c.at)}</p><div class="rs-list">${c.findings.map((f, n) => {
      const where = [f.project && pn(f.project), f.item, f.kind === "half_moved" ? "" : f.v].filter(Boolean).join(" › ");
      return `<div class="rs-row nock"><span class="rs-main"><span class="rs-t"><b>${KIND()[f.kind] || KIND2()[f.kind] || esc(f.kind)}</b>${f.n > 1 ? tag(String(f.n)) : ""}</span>
        <span class="rs-s">${esc(where)}${f.detail ? (where ? " · " : "") + esc(f.detail) : ""}</span></span>
        <span class="rs-acts">${f.fix && FIX()[f.kind] ? `<button class="btn sm weak press" data-rsfix="${n}">${FIX()[f.kind]}</button>` : `<span class="rs-s">${tl("res.f.manual")}</span>`}</span>
        <span class="rs-sz num">${f.bytes ? fmt(f.bytes) : ""}</span></div>`; }).join("")}</div>`;
  }

  // ---- draw ---------------------------------------------------------------
  function draw(soft) {
    const el = V(), r = route(); if (!el || !r.on) return;
    if (!ov) { el.innerHTML = loadingHtml(tl("res.loading"), {fill: true}); return; }
    const body = r.tab === "tidy" ? tidyView() : r.tab === "trash" ? trashView() : r.tab === "check" ? checkView() : sizeView(r);
    // Bars start from where they were (a redraw mid-way retargets the transition) - or from
    // nothing on a first draw - and settle on the next frame.
    const old = new Map([...el.querySelectorAll(".rs-row")].map((x, n) => [n, x.style.getPropertyValue("--w")]));
    el.innerHTML = `<div class="rs"${soft ? ' style="animation:none"' : ""}>${tabs(r)}${body}</div>`;
    const rowsEl = [...el.querySelectorAll(".rs-row")], want = rowsEl.map((x) => x.style.getPropertyValue("--w"));
    const b = el.querySelector(".rs-bar");
    // The bar opens once per level: the first draw of a level often has no parts yet (they are
    // still loading), so the opening waits for the draw that brings them, soft or not.
    const key = r.tab + "|" + r.p + "|" + r.i, filled = !!(b && b.querySelector(".rs-seg"));
    const open = filled && barFor !== key && !RM();
    // A redraw that lands while it is still opening (the load finishing, a poll) picks the
    // opening up where it was instead of snapping it open.
    const into = filled && !open && !RM() ? performance.now() - barAt : 1e9;
    if (filled) barFor = key; else if (!soft) barFor = null;
    if (open) barAt = performance.now();
    if (into < 400) b.style.transitionDelay = -Math.round(into) + "ms";
    if ((open && soft) || into < 400) requestAnimationFrame(() => requestAnimationFrame(() => b.classList.remove("pre")));
    else if (!open && b) b.classList.remove("pre");
    if (!soft && !RM()) { rowsEl.forEach((x, n) => x.style.setProperty("--w", old.get(n) || 0));
      requestAnimationFrame(() => requestAnimationFrame(() => { rowsEl.forEach((x, n) => x.style.setProperty("--w", want[n])); if (b) b.classList.remove("pre"); })); }
    poll();
  }

  async function screen() {
    const r = route();
    if (r.p + "/" + r.i !== listFor) { list = null; lastIdx = null; }
    const at = r.tab + "|" + r.p + "|" + r.i;
    if (at !== selAt) { sel.clear(); tsel.clear(); selAt = at; }
    draw();
    try {
      await loadOverview();
      if (r.tab === "size") await loadLevel(r);
      if (r.tab === "trash") trash = await get("/api/storage/trash");
      if (r.tab === "check") check = await get("/api/storage/check");
    } catch (e) { toast(e.message); }
    if (route().on) { draw(!!V().querySelector(".rs")); if (check && check.running) pollCheck(); }
  }
  async function reload() { await screen(); try { sizeMap = null; fillSizes(); } catch (e) {} }

  // ---- actions --------------------------------------------------------------
  // Selection -> the rows POST /api/storage/trash takes: versions of one item fold into one row.
  function payload() {
    const by = new Map();
    for (const x of sel.values()) { const k = x.p + "|" + x.i, cur = by.get(k);
      if (!x.vs) by.set(k, {p: x.p, i: x.i});
      else if (!cur) by.set(k, {p: x.p, i: x.i, vs: x.vs.slice()});
      else if (cur.vs) cur.vs = [...new Set(cur.vs.concat(x.vs))]; }
    return [...by.values()];
  }
  async function moveToTrash(rows, expect) {
    try {
      const out = await post("/api/storage/trash", {rows, expect});
      sel.clear(); closeSheet();
      if (out.errors.length && !out.count) return toast(out.errors[0].error, 4200);
      // Undo for six seconds, the way 정리 does; after that it is still in 휴지통.
      toastAct(tl("res.moved", {n: out.count, s: fmt(out.bytes)}) + (out.errors.length ? " · " + tl("res.partial", {n: out.errors.length}) : ""), tl("res.undo"), async () => {
        try { await post("/api/storage/restore", {ids: out.ids}); toast(tl("res.restored")); } catch (e) { toast(e.message); }
        trash = null; reload(); }, 6000, "archive");
      trash = null; await reload();
    } catch (e) { closeSheet(); toast(e.message, 4200); reload(); }
  }
  // The confirmation before anything moves. Quiet until here: this is where it says what leaves.
  // The server says exactly which versions would go and how big each is (it moves nothing yet);
  // the sheet lists every one, and the move is refused if that changed in between.
  async function confirmTrash(rows) {
    let plan;
    try { plan = await post("/api/storage/plan", {rows}); } catch (e) { return toast(e.message, 4200); }
    if (!plan.rows.length) return toast(plan.errors[0] ? plan.errors[0].error : tl("res.onlyNone"), 4200);
    // One line per result (name + size); only a result that keeps some versions says which ones go.
    const body = plan.rows.slice().sort((a, b) => b.bytes - a.bytes).map((x) => `<li><div class="rs-pt"><span>${esc(x.title)}</span><b class="num">${fmt(x.bytes)}</b></div>
      ${x.stay.length ? `<div class="rs-pv"><span>${tl("res.planPart")}</span>${x.go.map((v) => `<i>${vnum(v.v)}</i>`).join("")}</div>` : ""}</li>`).join("");
    const whole = plan.rows.filter((x) => !x.stay.length).length, all = whole === plan.rows.length;
    const line = [whole && !all ? tl("res.planWhole", {n: whole}) : "", tl("res.confirmB"), plan.errors.length ? tl("res.partial", {n: plan.errors.length}) : ""].filter(Boolean).join(" · ");
    sheet(`<h3>${all ? tl("res.confirmT", {n: plan.rows.length}) : tl("res.confirmTv", {n: plan.versions})}</h3>
      <p class="rs-sum"><b class="num">${fmt(plan.bytes)}</b><span>${line}</span></p>
      <button type="button" class="more1 rs-show press" aria-expanded="false">${tl("res.planShow")}</button><ul class="rs-plan more1x" hidden>${body}</ul>
      <div class="cf-acts"><button class="btn xl danger press" id="rs-go">${tl("res.confirmGo")}</button><button class="btn xl press" data-sclose>${tl("res.cancel")}</button></div>`, (el) => {
      const b = el.querySelector("#rs-go"); b.onclick = () => { b.disabled = true; moveToTrash(rows, {versions: plan.versions, bytes: plan.bytes}); }; });
  }
  const trashSelected = () => confirmTrash(payload());
  function emptySheet(ids) {
    const es = trash.entries.filter((e) => !ids || ids.includes(e.id)), bytes = es.reduce((a, e) => a + e.bytes, 0), word = tl("res.emptyWord");
    const big = es.slice().sort((a, b) => b.bytes - a.bytes).slice(0, 3);
    sheet(`<h3>${tl("res.emptyT", {n: es.length})}</h3><p class="rs-sum"><b class="num">${fmt(bytes)}</b><span>${tl("res.emptyB")}</span></p>
      <button type="button" class="more1 rs-show press" aria-expanded="false">${tl("res.planShow")}</button><div class="more1x" hidden>
        <p class="rs-bigh">${tl("res.emptyBig")}</p><ul class="rs-big">${big.map((e) => `<li><span>${esc(e.title)}</span><b class="num">${fmt(e.bytes)}</b></li>`).join("")}</ul>
        <p class="hint rs-cf">${tl("res.emptyKeep")}</p></div>
      <label class="rs-type"><span>${tl("res.emptyType", {w: word})}</span><input id="rs-word" autocomplete="off" spellcheck="false" aria-label="${tl("res.emptyType", {w: word})}"></label>
      <div class="cf-acts"><button class="btn xl danger press" id="rs-go" disabled>${tl("res.emptyGo")}</button><button class="btn xl press" data-sclose>${tl("res.cancel")}</button></div>`, (el) => {
      const b = el.querySelector("#rs-go"), w = el.querySelector("#rs-word");
      w.oninput = () => { b.disabled = w.value.trim() !== word; };
      b.onclick = async () => { b.disabled = true;
        try { const out = await post("/api/storage/empty", {ids: ids || null, count: es.length, bytes, confirm: true, root: trash.root});
          closeSheet(); tsel.clear(); trash = null; toast(tl("res.emptied", {s: fmt(out.bytes)}), 3000); await reload();
        } catch (e) { toast(e.message, 4200); closeSheet(); trash = null; reload(); } }; });
  }
  async function pollCheck() {
    try { check = await get("/api/storage/check"); } catch (e) { return; }
    if (!route().on || route().tab !== "check") return;
    draw(true);
    if (check.running) setTimeout(pollCheck, 700);
  }
  function range(listEl, idx, on, pick) {
    const cks = [...listEl.querySelectorAll("[data-idx]")];
    const a = Math.min(lastIdx, idx), b = Math.max(lastIdx, idx);
    cks.forEach((c) => { const n = +c.dataset.idx; if (n >= a && n <= b) pick(c, on); });
  }
  function entryFor(key) {
    const a = key.split("|");
    if (a[0] === "i") { const x = (list.items || []).find((y) => y.p === a[1] && y.i === a.slice(2).join("|")); return x && {p: x.p, i: x.i, vs: null, bytes: x.bytes, title: x.title}; }
    if (a[0] === "v") { const v = a[a.length - 1], x = (list.versions || []).find((y) => y.v === v); return x && {p: list.p, i: list.i, vs: [v], bytes: x.bytes, title: list.title + " " + v}; }
    const s = ov.suggest.find((y) => y.kind === a[1]), x = s && s.rows.find((y) => y.p === a[2] && y.i === a.slice(3).join("|"));
    return x && {p: x.p, i: x.i, vs: x.vs || null, bytes: x.bytes, title: x.title};
  }
  const toggle = (key, on) => { if (!on) return sel.delete(key); const e = entryFor(key); if (e) sel.set(key, e); };

  document.addEventListener("click", async (e) => {
    if (!route().on) return;
    const a = e.target.closest("[data-rsgo],[data-rsck],[data-rstck],[data-rsclear],[data-rstclear],[data-rstrash],[data-rsfinal],[data-rskeep],[data-rsonly],[data-rssug],[data-rssugall],[data-rsback],[data-rsempty],[data-rscheck],[data-rsfix],[data-rsrescan]");
    if (!a) return;
    const d = a.dataset, r = route();
    if (d.rsgo !== undefined) {
      // The bar of the next level opens from the segment (or row) that was pressed.
      const bEl = V().querySelector(".rs-bar"), rc = a.getBoundingClientRect(), br = bEl && bEl.getBoundingClientRect();
      origin = a.classList.contains("rs-seg") && br && br.width ? Math.round(((rc.left + rc.width / 2 - br.left) / br.width) * 100) : 0;
      sel.clear(); lastIdx = null;
      return nav(d.rsgo);
    }
    if (d.rsck !== undefined) {
      const on = a.getAttribute("aria-checked") !== "true", idx = +d.idx, box = a.closest("[data-rslist]");
      if (e.shiftKey && lastIdx !== null) range(box, idx, on, (c, v) => toggle(c.dataset.rsck, v)); else toggle(d.rsck, on);
      lastIdx = idx; return draw(true);
    }
    if (d.rstck !== undefined) {
      const on = !tsel.has(d.rstck), idx = +d.idx, box = a.closest("[data-rslist]");
      const set = (id, v) => (v ? tsel.add(id) : tsel.delete(id));
      if (e.shiftKey && lastIdx !== null) range(box, idx, on, (c, v) => set(c.dataset.rstck, v)); else set(d.rstck, on);
      lastIdx = idx; return draw(true);
    }
    if (d.rsclear !== undefined) { sel.clear(); return draw(true); }
    if (d.rstclear !== undefined) { tsel.clear(); return draw(true); }
    if (d.rstrash !== undefined) return trashSelected();
    if (d.rssug) { openSug = openSug === d.rssug ? null : d.rssug; lastIdx = null; return draw(true); }
    if (d.rssugall) { const s = ov.suggest.find((x) => x.kind === d.rssugall), keys = s.rows.map((x) => "s|" + s.kind + "|" + x.p + "|" + x.i);
      const all = keys.every((k) => sel.has(k)); keys.forEach((k) => toggle(k, !all)); openSug = s.kind; return draw(true); }
    if (d.rsfinal || d.rskeep) {
      const v = d.rsfinal || d.rskeep, on = d.on === "true";
      try { await post(d.rsfinal ? "/api/storage/final" : "/api/storage/keep", {p: r.p, i: r.i, v, on});
        sel.delete("v|" + r.p + "|" + r.i + "|" + v);
        if (d.rsfinal) toast(on ? tl("res.finalSet", {v: vnum(v)}) : tl("res.finalOff"), 2200, on ? "confirm" : undefined);
        await reload(); } catch (err) { toast(err.message, 4200); }
      return;
    }
    if (d.rsonly) return confirmTrash([{p: r.p, i: r.i, mode: d.rsonly}]);
    if (d.rsback) { const ids = d.rsback === "sel" ? [...tsel] : [d.rsback];
      try { const out = await post("/api/storage/restore", {ids}); tsel.clear(); trash = null;
        toast(out.errors.length ? out.errors[0].error : tl("res.restored"), out.errors.length ? 4200 : 2200, out.errors.length ? undefined : "restore"); await reload(); } catch (err) { toast(err.message); }
      return; }
    if (d.rsempty) return emptySheet(d.rsempty === "sel" ? [...tsel] : null);
    if (d.rscheck !== undefined) { try { await post("/api/storage/check", {}); check = Object.assign({}, check, {running: true}); draw(true); setTimeout(pollCheck, 400); } catch (err) { toast(err.message); } return; }
    if (d.rsfix !== undefined) { const f = check.findings[+d.rsfix]; a.disabled = true;
      try { await post("/api/storage/repair", {kind: f.kind, p: f.project || null, i: f.item, v: f.v}); toast(tl("res.fixed"), 2200, "confirm"); trash = null; await reload(); }
      catch (err) { toast(err.message, 4200); a.disabled = false; } return; }
    if (d.rsrescan !== undefined) { try { await post("/api/storage/rescan", {force: true}); await loadOverview(); draw(true); } catch (err) { toast(err.message); } }
  });

  if (typeof SCREENS !== "undefined") SCREENS.storage = function () { screen(); return {}; };

  // ---- the rest of the app --------------------------------------------------
  // Result cards: v2.js leaves a <span data-rsz="project/item"> in each card's meta line; it is
  // filled here once the sizes are known (one small request, kept for a minute).
  async function fillSizes() {
    const els = document.querySelectorAll("[data-rsz]:empty"); if (!els.length) return;
    if (!sizeMap || Date.now() - sizeAt > 60000) { sizeAt = Date.now();
      try { sizeMap = (await get("/api/storage/sizes")).versions || {}; } catch (e) { sizeMap = sizeMap || {}; } }
    document.querySelectorAll("[data-rsz]:empty").forEach((x) => { const b = sizeMap[x.dataset.rsz]?.[x.dataset.rver]; if (b) x.textContent = " · " + fmt(b); });
  }
  window.resMeta = (x) => (x && x.project && x.id ? `<span class="num" data-rsz="${esc(x.project + "/" + x.id)}" data-rver="${esc(x.v || "")}"></span>` : "")
    + (x && x.final ? ` <em class="rs-tag fin">${tl("res.final")} ${vnum(x.final)}</em>` : "");
  new MutationObserver(() => { clearTimeout(fillSizes.t); fillSizes.t = setTimeout(fillSizes, 120); })
    .observe(document.getElementById("view") || document.body, {childList: true, subtree: true});

  // The item view: mark the version on screen as 최종본 / 남기기, and its size, in the inspector.
  function attach(box, it, d) {
    if (!it || !it.p || !it.i || !d || !d.versions) return;
    const col = (box.querySelector(".htitle") && box.querySelector(".htitle").parentElement) || box;
    col.querySelector(".rs-item")?.remove();
    const v = d.versions.find((x) => x.v === it.v) || d.versions[0]; if (!v) return;
    const isFinal = d.final === v.v, kept = (d.keep || []).includes(v.v), gone = v.removed;
    const card = document.createElement("details");
    card.className = "rs-item card";
    card.innerHTML = `<summary class="rs-ih"><b>${tl("res.versionTools")}</b><span class="rs-s">${v.v}</span>${isFinal ? tag(tl("res.final"), "fin") : ""}${kept ? tag(tl("res.keep")) : ""}${gone ? goneTag(gone) : ""}
        ${d.final && !isFinal ? `<span class="rs-s">${tl("res.final")} ${vnum(d.final)}</span>` : ""}<span class="sp"></span><span class="rs-sz num" data-rsv></span>${ic("chev")}</summary>
      ${gone ? `<p class="rs-s">${tl("res.goneD")}</p>` : `<div class="rs-ia"><button class="btn sm weak press" data-f>${isFinal ? tl("res.unFinal") : tl("res.markFinal")}</button><button class="btn sm weak press" data-k>${kept ? tl("res.unKeep") : tl("res.markKeep")}</button></div>`}
      <button class="lnk press rs-il" data-go="${esc(href(it.p, it.i))}">${tl("res.inStorage")}</button>`;
    const act = (url, on, msg) => async () => { try { await post(url, {p: it.p, i: it.i, v: v.v, on}); if (msg) toast(msg, 2200, on ? "confirm" : undefined);
      if (typeof again === "function") again(); } catch (e) { toast(e.message, 4200); } };
    const f = card.querySelector("[data-f]"), k = card.querySelector("[data-k]");
    if (f) f.onclick = act("/api/storage/final", !isFinal, isFinal ? tl("res.finalOff") : tl("res.finalSet", {v: vnum(v.v)}));
    if (k) k.onclick = act("/api/storage/keep", !kept, "");
    (col.querySelector("#ixtra") || col).appendChild(card);
    get("/api/storage/item?" + q({p: it.p, i: it.i})).then((s) => { const x = s.versions.find((y) => y.v === v.v), el = card.querySelector("[data-rsv]");
      if (x && el) el.textContent = fmt(gone ? gone.bytes : x.bytes); }).catch(() => {});
  }
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(attach);
})();
