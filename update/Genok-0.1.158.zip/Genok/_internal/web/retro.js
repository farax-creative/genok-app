// 회고 from the status log (H21). v2.js paints the week from each item's current status and
// its newest push time, which misses an old version approved this week and counts a change that
// was later overturned. This file asks the server (/api/retro: the decisions made in the window,
// last one per version) and repaints the same screen with those numbers. v2.js's own screen
// stays as the first paint and as the fallback when the server cannot answer.
// Loaded after v2.js, so it uses v2.js's globals (SCREENS, V, get, esc, ic, tl, itemRow, gname...).
(function () {
  "use strict";
  if (typeof SCREENS === "undefined" || typeof SCREENS.retro !== "function") return;
  const first = SCREENS.retro;
  let seq = 0;

  const row = (r) => {
    const x = D.items.find((i) => i.project === r.project && i.id === r.item);
    return x ? itemRow(x, false) : "";
  };

  function paint(d) {
    const wk = retroWk, label = retroLabel(wk);
    const start = new Date(d.start).getTime(), end = new Date(d.end).getTime();
    const inWk = (x) => x.at && new Date(x.at) > start && new Date(x.at) <= end;
    const by = {};
    D.items.filter(inWk).forEach((x) => { const k = gname(x); by[k] = (by[k] || 0) + 1; });
    const depts = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 8), top = depts[0]?.[1] || 1;
    const pick = (s) => d.decisions.filter((r) => r.status === s);
    const done = pick("approved"), asked = pick("changes"), held = pick("hold");
    const none = `<div class="fun">${tl("retro.none", {wk: label})}</div>`;
    const list = (title, rows, max) => rows.length ? `<div class="card"><div class="ch"><h2>${title}</h2><span class="n num">${rows.length}</span></div>${rows.slice(0, max).map(row).join("")}<div style="height:8px"></div></div>` : "";
    V().innerHTML = `<div class="wknav"><button class="ib press" data-wk="1" aria-label="${tl("retro.prev")}">${ic("back")}</button>
      <div class="wkl"><b>${label}</b><span>${mdShort(start + 864e5)} – ${mdShort(end)}</span></div>
      <button class="ib press" data-wk="-1" aria-label="${tl("retro.next")}" ${wk === 0 ? `disabled title="${tl("retro.next.none")}"` : ""}>${ic("chev")}</button></div>
    <div class="grid2">
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.ok", {wk: label})}</div><div class="v num" style="font-size:28px">${done.length}</div><div class="s">${tl("retro.of", {n: d.pushed})}</div></span></div></div>
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.changes")}</div><div class="v num" style="font-size:28px">${asked.length}</div><div class="s">${asked.length ? tl("retro.fixing") : tl("retro.clear")}</div></span></div></div></div>
    <div class="card"><div class="ch"><h2>${tl("retro.bydept")}</h2></div><div class="bars">${depts.map(([n, c]) => `<div class="bar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(pname(n))}</span><span class="tr"><i style="width:${c / top * 100}%"></i></span><span class="num">${c}</span></div>`).join("") || none}</div></div>
    ${done.length ? list(tl("retro.done"), done, 12) : `<div class="card"><div class="ch"><h2>${tl("retro.done")}</h2><span class="n num">0</span></div>${none}<div style="height:8px"></div></div>`}
    ${list(tl("retro.asked"), asked, 8)}${list(tl("retro.held"), held, 8)}`;
    V().querySelectorAll("[data-wk]").forEach((b) => b.onclick = () => { retroWk = Math.max(0, retroWk + (+b.dataset.wk)); SCREENS.retro(); scrollTo(0, 0); });
  }

  SCREENS.retro = function () {
    first();
    const my = ++seq;
    get("/api/retro?week=" + retroWk).then((d) => {
      if (my === seq && cur === "retro" && !detail && d && Array.isArray(d.decisions)) paint(d);
    }, () => {});
  };
})();
