// 루틴: recurring instructions the hub sends on a schedule, or a personal daily checklist.
// Unlike a /loop this never expires - it is kept in the data folder and served by routines.py.
// A core screen (MENUS key "routines"), not an extension. It reuses the app's own classes and
// the sheet() editor, so it inherits the spring motion and the reduced-motion fallbacks and adds
// no animation of its own.
(function () {
  "use strict";

  let rows = [];           // routines, as the server last gave them (each carries next_run)

  const onScreen = () => location.hash.slice(1).split("/")[0] === "routines";

  // ---- wording ----------------------------------------------------------
  const KINDS = () => [["daily", tl("routines.kind.daily")], ["weekdays", tl("routines.kind.weekdays")], ["everyN", tl("routines.kind.everyN")]];
  const scheduleText = (r) => r.kind === "everyN" ? tl("routines.every", {n: r.hours || 6})
    : (r.kind === "weekdays" ? tl("routines.at.weekdays", {t: r.at || "09:00"}) : tl("routines.at.daily", {t: r.at || "09:00"}));
  // A near-future stamp: "오늘 14:00" / "내일 09:00" / "3/12 09:00".
  function whenText(iso) {
    if (!iso) return "";
    const d = new Date(iso), now = new Date();
    const hm = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - day0) / 86400000);
    if (days === 0) return tl("routines.today", {t: hm});
    if (days === 1) return tl("routines.tomorrow", {t: hm});
    return `${d.getMonth() + 1}/${d.getDate()} ${hm}`;
  }

  async function refresh() {
    try { rows = (await get("/api/routines")).routines || []; }
    catch (e) { rows = []; }
  }

  // ---- the list ---------------------------------------------------------
  function itemLine(r, i) {
    const it = (r.items || [])[i] || {}, on = !!it.done;
    return `<button class="row press" data-rck="${esc(r.id)}" data-idx="${i}" style="min-height:44px">
      <span class="ico sm ${on ? "c-green" : "c-grey"}">${ic(on ? "check" : "rect")}</span>
      <span class="tx"><div class="t" style="font-size:15px;${on ? "opacity:.5;text-decoration:line-through" : ""}">${esc(it.text)}</div></span></button>`;
  }

  function card(r) {
    const last = (r.runs || [])[r.runs.length - 1];
    const sub = r.checklist
      ? tl("routines.checklist") + (r.items && r.items.length ? " · " + tl("routines.doneOf", {d: r.items.filter((x) => x.done).length, n: r.items.length}) : "")
      : `${scheduleText(r)}${r.target ? " · " + esc(r.target) : ""}`;
    const nextline = !r.paused && !r.checklist && r.next_run
      ? `<div class="row" style="padding:0 4px 8px"><span class="s">${tl("routines.next", {w: whenText(r.next_run)})}</span>${last ? `<span class="sp"></span><span class="s">${tl("routines.lastrun", {w: whenText(last.at)})}</span>` : ""}</div>`
      : "";
    return `<div class="card">
      <div class="row" style="padding-top:16px">
        <span class="ico c-orange">${ic(r.checklist ? "check" : "clock")}</span>
        <span class="tx"><div class="t big">${esc(r.title)}</div><div class="s">${sub}</div></span>
        ${r.paused ? `<span class="tag">${tl("routines.paused")}</span>` : ""}
      </div>
      ${nextline}
      ${r.checklist && r.items && r.items.length ? r.items.map((_, i) => itemLine(r, i)).join("") : ""}
      <div class="row" style="gap:8px;padding:2px 4px 14px">
        ${r.checklist ? "" : `<button class="btn sm press" data-rrun="${esc(r.id)}">${tl("routines.runnow")}</button>`}
        <button class="btn sm weak press" data-redit="${esc(r.id)}">${tl("routines.edit")}</button>
        <button class="btn sm weak press" data-rpause="${esc(r.id)}">${r.paused ? tl("routines.resume") : tl("routines.pause")}</button>
        <span class="sp"></span>
        <button class="btn sm weak press" data-rdel="${esc(r.id)}">${tl("routines.delete")}</button>
      </div>
    </div>`;
  }

  function draw() {
    const el = V(); if (!el) return;
    const add = document.querySelector(".ib[data-rnew]"); if (add) add.hidden = !rows.length;
    el.innerHTML = rows.length ? rows.map(card).join("")
      // Borderless, centered empty state that sits directly on the panel (no card-in-panel box),
      // with one real action that opens the create flow (same data-rnew as the toolbar +).
      : `<div class="plan mid"><span class="ico c-orange">${ic("clock")}</span><h2>${tl("routines.emptyTitle")}</h2><p>${tl("routines.empty")}</p>`
        + `<button class="btn fill xl press" data-rnew>${tl("routines.makecta")}</button></div>`;
  }

  async function screen() {
    if (rows.length) draw(); else V().innerHTML = loadingHtml(tl("routines.loading"), {fill: true});
    await refresh();
    if (onScreen()) draw();
  }

  // ---- the editor (a bottom sheet, styled by .sbox) ---------------------
  function editorHtml(r) {
    r = r || {};
    const depts = (typeof projects === "function" ? projects() : []).map((g) => g.name);
    if (r.target && !depts.includes(r.target)) depts.unshift(r.target);
    const checklist = !!r.checklist, kind = r.kind || "daily";
    return `<h3>${r.id ? tl("routines.editing") : tl("routines.new")}</h3>
      <input type="hidden" id="rt-id" value="${esc(r.id || "")}">
      <div class="lbl">${tl("routines.f.title")}</div>
      <input class="tin" id="rt-title" type="text" maxlength="120" spellcheck="false" value="${esc(r.title || "")}" placeholder="${tl("routines.f.title.ph")}">
      <div class="lbl">${tl("routines.f.kindq")}</div>
      <div class="seg wide" id="rt-type">
        <button type="button" class="press ${checklist ? "" : "on"}" data-cl="0">${tl("routines.type.send")}</button>
        <button type="button" class="press ${checklist ? "on" : ""}" data-cl="1">${tl("routines.type.check")}</button></div>
      <div id="rt-send" ${checklist ? "hidden" : ""}>
        <div class="lbl">${tl("routines.f.target")}</div>
        <gk-select id="rt-target" aria-label="${esc(tl("routines.f.target"))}">${depts.length ? depts.map((d) => `<option value="${esc(d)}" ${d === r.target ? "selected" : ""}>${esc(d)}</option>`).join("") : `<option value="">${tl("routines.notarget")}</option>`}</gk-select>
        <div class="lbl">${tl("routines.f.text")}</div>
        <textarea id="rt-text" rows="3" maxlength="5000" spellcheck="false" placeholder="${tl("routines.f.text.ph")}">${esc(r.text || "")}</textarea>
        <div class="lbl">${tl("routines.f.kind")}</div>
        <gk-select id="rt-kind" aria-label="${esc(tl("routines.f.kind"))}">${KINDS().map(([k, n]) => `<option value="${k}" ${k === kind ? "selected" : ""}>${esc(n)}</option>`).join("")}</gk-select>
        <div id="rt-atwrap" ${kind === "everyN" ? "hidden" : ""}>
          <div class="lbl">${tl("routines.f.at")}</div>
          <input class="tin" id="rt-at" type="time" value="${esc(r.at || "09:00")}"></div>
        <div id="rt-hourswrap" ${kind === "everyN" ? "" : "hidden"}>
          <div class="lbl">${tl("routines.f.hours")}</div>
          <input class="tin" id="rt-hours" type="number" min="1" max="168" value="${r.hours || 6}"></div>
      </div>
      <div id="rt-check" ${checklist ? "" : "hidden"}>
        <div class="lbl">${tl("routines.f.items")}</div>
        <textarea id="rt-items" rows="4" spellcheck="false" placeholder="${tl("routines.f.items.ph")}">${esc((r.items || []).map((x) => x.text).join("\n"))}</textarea>
      </div>
      <button class="btn xl fill press" id="rt-save">${tl("routines.save")}</button>`;
  }

  function wireEditor(box) {
    const q = (s) => box.querySelector(s);
    q("#rt-type").querySelectorAll("[data-cl]").forEach((b) => b.onclick = () => {
      const on = b.dataset.cl === "1";
      q("#rt-type").querySelectorAll("[data-cl]").forEach((x) => x.classList.toggle("on", (x.dataset.cl === "1") === on));
      q("#rt-send").hidden = on; q("#rt-check").hidden = !on;
    });
    q("#rt-kind").onchange = () => {
      const n = q("#rt-kind").value === "everyN";
      q("#rt-atwrap").hidden = n; q("#rt-hourswrap").hidden = !n;
    };
    q("#rt-save").onclick = async (e) => {
      const checklist = q("#rt-type").querySelector('[data-cl="1"]').classList.contains("on");
      const body = {
        id: q("#rt-id").value,
        title: q("#rt-title").value,
        checklist,
        target: checklist ? "" : q("#rt-target").value,
        text: checklist ? "" : q("#rt-text").value,
        kind: q("#rt-kind").value,
        at: q("#rt-at").value || "09:00",
        hours: +q("#rt-hours").value || 6,
        items: checklist ? q("#rt-items").value.split("\n").map((t) => ({text: t.trim()})).filter((x) => x.text) : [],
      };
      e.currentTarget.disabled = true;
      try { await post("/api/routine", body); closeSheet(); await refresh(); draw(); toast(tl("routines.saved")); }
      catch (err) { toast(err.message); e.currentTarget.disabled = false; }
    };
  }

  const openEditor = (r) => sheet(editorHtml(r), wireEditor);

  // ---- list controls (delegated) ---------------------------------------
  document.addEventListener("click", async (e) => {
    if (!onScreen()) return;
    const a = e.target.closest("[data-rnew],[data-redit],[data-rrun],[data-rpause],[data-rdel],[data-rck]");
    if (!a) return;
    if (a.hasAttribute("data-rnew")) return openEditor(null);
    if (a.dataset.redit) return openEditor(rows.find((r) => r.id === a.dataset.redit));
    if (a.dataset.rpause) {
      const r = rows.find((x) => x.id === a.dataset.rpause);
      try { await post("/api/routine-pause", {id: a.dataset.rpause, paused: !(r && r.paused)}); await refresh(); draw(); } catch (err) { toast(err.message); } return;
    }
    if (a.dataset.rrun) { a.disabled = true;
      try { const d = await post("/api/routine-run", {id: a.dataset.rrun}); toast(d.note || tl("routines.saved")); await refresh(); draw(); } catch (err) { toast(err.message); a.disabled = false; } return;
    }
    if (a.dataset.rck) { const r = rows.find((x) => x.id === a.dataset.rck), i = +a.dataset.idx;
      const done = !((r.items || [])[i] || {}).done;
      try { await post("/api/routine-check", {id: a.dataset.rck, idx: i, done}); await refresh(); draw(); } catch (err) { toast(err.message); } return;
    }
    if (a.dataset.rdel) { const id = a.dataset.rdel;
      toastAct(tl("routines.delAsk"), tl("routines.delete"), async () => {
        try { await post("/api/routine-delete", {id}); await refresh(); draw(); } catch (err) { toast(err.message); } }); return;
    }
  });

  // Register the core screen. render() titles the bar from the MENUS entry and puts our returned
  // `right` markup in it (the + button); the delegated handler above catches its click.
  if (typeof SCREENS !== "undefined") {
    SCREENS.routines = function () {
      screen();
      return {right: `<button class="ib press" data-rnew aria-label="${tl("routines.add")}" title="${tl("routines.add")}"${rows.length ? "" : " hidden"}>${ic("plus")}</button>`};
    };
  }

  // A small next-run line on home, through the home-card hook. One tappable row, no header.
  // Home draws its cards twice on boot, so the list is shared for a few seconds.
  let homeMemo = null, homeAt = 0;
  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({
    id: "routines-next", title: "",
    draw: async (host) => {
      if (!homeMemo || Date.now() - homeAt > 5000) {
        homeAt = Date.now();
        homeMemo = get("/api/routines");
        homeMemo.catch(() => { homeMemo = null; });
      }
      let list = [];
      try { list = (await homeMemo).routines || []; } catch { return; }
      const live = list.filter((r) => r.next_run && !r.checklist && !r.paused).sort((a, b) => a.next_run.localeCompare(b.next_run));
      const el = document.createElement("button");
      el.className = "row press"; el.style.width = "100%"; el.setAttribute("data-go", "routines");
      el.innerHTML = live.length
        ? `<span class="ico sm c-orange">${ic("clock")}</span><span class="tx"><div class="t" style="font-size:15px">${esc(live[0].title)}</div><div class="s">${tl("routines.next", {w: whenText(live[0].next_run)})}</div></span>`
        : `<span class="ico sm c-grey">${ic("clock")}</span><span class="tx"><div class="t" style="font-size:15px">${tl("routines.nav")}</div><div class="s">${tl("routines.emptyshort")}</div></span>`;
      host.appendChild(el);
    },
  });
})();
