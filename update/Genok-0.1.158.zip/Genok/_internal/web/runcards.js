// Running-work cards (runcards.py, docs/running-cards.md; beta "pai"). What a session said it is
// making (`loop pending --item X --eta 5m`) stands as the first card of the result list - who makes
// it, how long it has run, how far its ETA has gone - until the push it promised lands in that same
// spot. A failure (`--failed "reason"`) stands there with its reason and one button that sends it to
// the department as a fix to make. Read from GET /api/running every few seconds while a list is on
// screen. Nothing is toasted but the answer to that button: a card is the whole notice.
(function () {
  "use strict";
  if (!window.genokBeta?.("pai")) return;
  const view = document.getElementById("view");
  if (!view) return;
  const css = document.createElement("link"); css.rel = "stylesheet"; css.href = "/runcards.css"; document.head.appendChild(css);
  const POLL = 5000;
  let jobs = [], sig = "", skew = 0, pollT = 0, tickT = 0;
  const seen = new Set();               // cards already shown once: a redraw does not fade them in again
  const key = (j) => j.project + "/" + j.item;
  const now = () => Date.now() / 1000 + skew;
  const vNum = (v) => parseInt(String(v || "").replace(/\D/g, ""), 10) || 0;

  // 40초 · 3분 · 1시간 5분
  function dur(s) {
    s = Math.max(0, Math.round(s));
    if (s < 60) return tl("rc.s", {n: s});
    const m = Math.round(s / 60);
    if (m < 60) return tl("rc.m", {n: m});
    return m % 60 ? tl("rc.hm", {h: Math.floor(m / 60), m: m % 60}) : tl("rc.h", {h: m / 60});
  }
  // The one line under the title, and how far the bar goes (null: no ETA, no bar).
  function progress(j, t) {
    const ran = t - j.started, who = j.dept ? pname(j.dept) : "";
    let line = tl("rc.ran", {t: dur(ran)}), f = null;
    if (j.eta) {
      f = Math.min(1, ran / j.eta);
      line += " · " + (ran < j.eta ? tl("rc.left", {t: dur(j.eta - ran)}) : tl("rc.over", {t: dur(ran - j.eta)}));
    }
    return {line: (who ? who + " · " : "") + line, f};
  }

  // The list on screen and where its cards start: the results list (lab layout) on its 전체 or 신규
  // tab, or a project's page in its list mode. null when neither is up.
  function place() {
    if (detail) {
      if (detail[0] !== "dept" || !["all", "fresh"].includes(typeof deptF === "string" ? deptF : "all")) return null;
      // Grouped by scene (scenes.js): the cards stand in their own grid above the scenes, not in the first one.
      const scns = view.querySelector(".deptpage .scns");
      const box = scns ? null : view.querySelector(".deptpage .dgal"), none = scns || view.querySelector(".deptpage > .card.plan.none");
      return box || none ? {want: (j) => gname(j) === detail[1], box, none} : null;
    }
    if (cur !== "lib" || typeof k3f === "undefined" || (k3f && k3f !== "fresh")) return null;
    const box = view.querySelector(".k3lib .rdgrid, .k3lib .k3grid, .k3lib .content-table-body"), none = view.querySelector(".k3lib .k3none");
    return box || none ? {want: (j) => !libD || gname(j) === libD, box, none, row: !!box && !box.matches(".rdgrid, .k3grid")} : null;
  }
  // A landed card goes once its result is on the list it was standing in for.
  const arrived = (j) => j.state === "landed" && D.items.some((x) => iid(x) === key(j) && vNum(x.v) >= vNum(j.v));
  const listed = (j) => D.items.some((x) => iid(x) === key(j));

  function card(j, row) {
    const k = key(j), t = now(), p = progress(j, t), fresh = !seen.has(k);
    seen.add(k);
    if (j.state === "failed") return failed(j, row, fresh);
    const landed = j.state === "landed";
    const sub = landed ? tl("rc.landed", {v: j.v}) : p.line;
    const art = `<span class="rcth" aria-hidden="true">${landed ? ic("check") : loadingHtml("", {inline: true})}${!landed && p.f != null ? `<i class="rcbar"><b style="transform:scaleX(${p.f.toFixed(3)})"></b></i>` : ""}</span>`;
    const text = `<span class="rctx"><span class="ld-sr">${esc(landed ? tl("rc.done") : tl("rc.making"))}</span><b class="rct">${esc(j.title)}</b><span class="rcs num" data-rcs>${esc(sub)}</span>${j.note && !landed ? `<span class="rcn">${esc(j.note)}</span>` : ""}</span>`;
    const body = listed(j) || landed ? `<button type="button" class="rcopen press" data-item="${esc(k)}">${art}${text}</button>` : `<div class="rcopen">${art}${text}</div>`;
    return `<div class="rcard${row ? " rcrow" : ""}${fresh ? " rcin" : ""}" data-rc="${esc(k)}" data-st="${esc(j.state)}">${body}</div>`;
  }

  // The reason on one line (whole on hover), then 에이전트에게 보내기, and 닫기 in the corner - both
  // outside the open button, as a button cannot hold buttons.
  function failed(j, row, fresh) {
    const k = key(j), who = j.dept ? pname(j.dept) : "";
    const art = `<span class="rcth" aria-hidden="true">${ic("warn")}</span>`;
    const text = `<span class="rctx"><b class="rct">${esc(j.title)}</b><span class="rcr" title="${esc(j.reason)}">${esc(j.reason)}</span><span class="rcs num">${esc([tl("rc.failed"), who, j.v].filter(Boolean).join(" · "))}</span></span>`;
    const body = listed(j) ? `<button type="button" class="rcopen press" data-item="${esc(k)}">${art}${text}</button>` : `<div class="rcopen">${art}${text}</div>`;
    const act = `<span class="rcact"><button type="button" class="btn sm weak press" data-rcsend>${tl("rc.send")}</button></span><button type="button" class="ib rcx press" data-rcx aria-label="${tl("ui.close")}">${ic("x")}</button>`;
    return `<div class="rcard bad${row ? " rcrow" : ""}${fresh ? " rcin" : ""}" data-rc="${esc(k)}" data-st="failed">${body}${act}</div>`;
  }

  // Where keyboard focus sits among the cards, so a redraw can put it back: the same control on the
  // same card, or - when that card is gone - the card now at its index, else into the list.
  function focusOf(el) {
    const c = el?.closest?.(".rcard");
    if (!c || !view.contains(c)) return null;
    const w = el.matches("[data-rcsend]") ? "[data-rcsend]" : el.matches("[data-rcx]") ? "[data-rcx]" : "button.rcopen";
    return {k: c.dataset.rc, w, i: [...view.querySelectorAll(".rcard")].indexOf(c)};
  }
  function refocus(f, box) {
    const cards = [...view.querySelectorAll(".rcard")], same = cards.find((c) => c.dataset.rc === f.k);
    const c = same || cards[Math.min(f.i, cards.length - 1)];
    const el = (same && same.querySelector(f.w)) || c?.querySelector("button")
      || box?.querySelector("button, a[href], [tabindex]:not([tabindex='-1'])");
    el?.focus({preventScroll: true});
  }

  function mount(f = focusOf(document.activeElement)) {
    view.querySelectorAll(".rcard, .rcgrid").forEach((e) => e.remove());
    const p = place(), L = p ? jobs.filter((j) => p.want(j) && !arrived(j)) : [];
    if (L.length) {
      const html = L.map((j) => card(j, p.row)).join("");
      if (p.box) p.box.insertAdjacentHTML("afterbegin", html);
      else { p.none.insertAdjacentHTML("beforebegin", `<div class="rcgrid">${html}</div>`); alignScenes(); }
    }
    if (f) refocus(f, p?.box || p?.none);
    clearInterval(tickT);
    if (L.some((j) => j.state === "running")) tickT = setInterval(tick, 1000);
  }
  // Above the scenes (scenes.js) the cards take as many columns as an open scene's grid, so they line
  // up with it; the count is read again on a resize, and the columns themselves stay fluid.
  function alignScenes() {
    const r = view.querySelector(".deptpage .rcgrid"), g = r?.nextElementSibling?.matches(".scns") && r.nextElementSibling.querySelector(".scn > .gal:not([hidden])");
    if (!g) return;
    const n = getComputedStyle(g).gridTemplateColumns.split(" ").filter(Boolean).length;
    r.style.gridTemplateColumns = `repeat(${n},minmax(0,1fr))`;
    r.style.gap = getComputedStyle(g).gap;
  }
  addEventListener("resize", alignScenes);
  // Each second: the times and the bar, in place.
  function tick() {
    if (document.hidden) return;
    const t = now();
    view.querySelectorAll('.rcard[data-st="running"]').forEach((c) => {
      const j = jobs.find((x) => key(x) === c.dataset.rc); if (!j) return;
      const p = progress(j, t), s = c.querySelector("[data-rcs]"), b = c.querySelector(".rcbar b");
      if (s && s.textContent !== p.line) s.textContent = p.line;
      if (b && p.f != null) b.style.transform = `scaleX(${p.f.toFixed(3)})`;
    });
  }

  const listOn = () => detail ? detail[0] === "dept" : cur === "lib";
  async function poll() {
    clearTimeout(pollT);
    if (!document.hidden && listOn()) {
      try {
        const r = await get("/api/running");
        skew = r.now - Date.now() / 1000;
        const s = JSON.stringify(r.jobs);
        if (s !== sig) { sig = s; jobs = r.jobs; mount(); }
      } catch (e) { /* offline or restarting: the next round asks again, the top bar says what is wrong */ }
    }
    pollT = setTimeout(poll, POLL);
  }

  // 에이전트에게 보내기 / 닫기: the card leaves at once; on an error it comes back with the next poll.
  view.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-rcsend], [data-rcx]"), c = b?.closest(".rcard");
    if (!c || b.disabled) return;
    const [p, ...rest] = c.dataset.rc.split("/"), send = "rcsend" in b.dataset, f = focusOf(b);
    b.disabled = true;
    try {
      await post(send ? "/api/running/send" : "/api/running/dismiss", {p, i: rest.join("/")});
      jobs = jobs.filter((j) => key(j) !== c.dataset.rc); sig = JSON.stringify(jobs); mount(f);
      if (send) toast(tl("rc.sent"));
    } catch (err) { b.disabled = false; toast(err.message); }
  });

  // A list redraw takes the cards out with it, and the page's focus keeper (restoreView) then hands
  // focus to whatever stands at the card's index in the new drawing - a version row. Remember the
  // card control that lost focus with nowhere to go, so the redraw below can give it back.
  let lost = null;
  view.addEventListener("focusout", (e) => {
    const f = e.relatedTarget ? null : focusOf(e.target);
    lost = f && {f, el: e.target, at: performance.now()};
  });
  // Every draw of a list replaces #view's content: the cards go back in at its head.
  new MutationObserver(() => {
    const f = lost && !lost.el.isConnected && performance.now() - lost.at < 100 ? lost.f : undefined;
    lost = null;
    if (jobs.length) mount(f);
  }).observe(view, {childList: true});
  addEventListener("hashchange", () => setTimeout(poll, 0));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) poll(); });
  poll();
  window.RunCards = {dur, progress};
})();
