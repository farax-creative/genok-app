// Scenes on the project list (beta "pai", scenes.py): with "장면별" on, the list view groups its
// results under a scene name, each group behind a header that folds it away. The name is read from
// the title (SOUL_025 -> SOUL, SC01_SH010 -> SC01, ep01_sc02_sh030 -> ep01_sc02) unless one was set
// by hand: in the list's pick mode, "장면으로 묶기" names a scene for the picked results.
// The board keeps its own layout; this only changes the list.
(function () {
  "use strict";

  // ---- pure (tests/scenes.test.js) ----
  // A shot token: SH010, C3, CUT12, or a bare number of two digits or more (025). A one-digit number
  // is a shot only when it is joined on (SOUL_9, SOUL-9), not after a space ("Render 2").
  const SHOT = /^(?:(?:sh|shot|c|cut)\d+|\d{2,})[a-z]?$/i;
  const SHOT1 = /^\d[a-z]?$/i;
  const LETTER = /[^\d\s_.-]/;
  function sceneOf(title) {
    const s = String(title || "").trim(), toks = [...s.matchAll(/[^\s_.-]+/g)];
    const parts = toks.map((m) => m[0]);
    for (let n = 1; n < parts.length; n++) {
      const joined = !/\s/.test(s.slice(toks[n - 1].index + parts[n - 1].length, toks[n].index));
      if (!SHOT.test(parts[n]) && !(joined && SHOT1.test(parts[n]))) continue;
      const name = parts.slice(0, n).join("_");
      return LETTER.test(name) ? name : "";
    }
    const m = /^([a-z]{2,})\d{2,}[a-z]?$/i.exec(parts[0] || "");   // SOUL025
    return m ? m[1] : "";
  }
  const coll = new Intl.Collator(undefined, {numeric: true, sensitivity: "base"});
  // [{key, name, items}] in natural order, the results without a scene last (key ""). Names that
  // differ only in case are one scene; the first spelling met names it. `tag(x)` is a hand-set name.
  function group(items, titleOf, tag) {
    const by = new Map();
    for (const x of items) {
      const name = tag(x) || sceneOf(titleOf(x)), key = name.toLowerCase();
      if (!by.has(key)) by.set(key, {key, name, items: []});
      by.get(key).items.push(x);
    }
    const out = [...by.values()];
    out.forEach((g) => g.items.sort((a, b) => coll.compare(titleOf(a), titleOf(b))));
    return out.sort((a, b) => (!a.key) - (!b.key) || coll.compare(a.name, b.name));
  }
  const pure = {sceneOf, group};
  if (typeof module !== "undefined" && module.exports) { module.exports = pure; return; }
  if (!window.genokBeta?.("pai")) return;

  const enc = encodeURIComponent;
  const store = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch { return null; } };
  const on = () => store("v2-scn") === "1";
  // Folded scenes, per device: "<page>\u0001<scene key>".
  let shut;
  try { shut = new Set(JSON.parse(store("v2-scn-shut") || "[]")); } catch { shut = new Set(); }
  const saveShut = () => store("v2-scn-shut", JSON.stringify([...shut].slice(-400)));

  // Hand-set names by result (iid), loaded once per project and kept current by every change here.
  const tags = new Map(), loaded = new Set(), loading = new Set();
  const tagOf = (x) => tags.get(iid(x)) || "";
  function load(projects) {
    const want = projects.filter((p) => !loaded.has(p) && !loading.has(p));
    if (!want.length) return;
    want.forEach((p) => loading.add(p));
    Promise.all(want.map((p) => get(`/api/scenes?p=${enc(p)}`).then((r) => {
      Object.entries(r.scenes || {}).forEach(([i, s]) => tags.set(p + "/" + i, s));
    }).catch(() => { /* the names from the titles still group the list */ })
      .finally(() => { loading.delete(p); loaded.add(p); })))
      .then(() => { if (on()) redrawDept(); });
  }
  const fold = (page, key) => shut.has(page + "\u0001" + key);

  // The list view's results, grouped; null when grouping is off (the page draws its plain grid).
  function list(page, its, card) {
    if (!on()) return null;
    load([...new Set(its.map((x) => x.project))]);
    const groups = group(its, (x) => x.title || x.id, tagOf);
    return `<div class="scns">${groups.map((g) => { const f = fold(page, g.key);
      return `<section class="scn"><button class="scnh press" type="button" data-scnh="${esc(g.key)}" aria-expanded="${!f}">${ic("chev")}<b>${g.key ? esc(g.name) : tl("scene.none")}</b><span class="n num">${g.items.length}</span></button>
        <div class="gal z-m dgal"${f ? " hidden" : ""}>${g.items.map(card).join("")}</div></section>`; }).join("")}</div>`;
  }
  // The switch beside 목록 · 보드 (list view only).
  const toggle = (brd, n) => brd || n < 2 ? ""
    : `<button class="btn sm weak press scnbtn${on() ? " on" : ""}" type="button" data-scnon aria-pressed="${on()}" aria-label="${tl("scene.by")}">${ic("folder")}<span>${tl("scene.by")}</span></button>`;
  // In pick mode, beside "N개 승인".
  const tagBtn = (n) => n ? `<button class="btn sm weak press" type="button" data-scntag>${tl("scene.tag")}</button>` : "";

  // Every scene the page already has is one press away, so a name is not typed twice two ways.
  function tagSheet(all, picked) {
    const now = [...new Set(picked.map(tagOf))];
    const names = group(all, (x) => x.title || x.id, tagOf).filter((g) => g.key).map((g) => g.name).slice(0, 24);
    sheet(`<h3>${tl("scene.tag")}</h3>
      <p class="hint">${tl("scene.tag.h", {n: picked.length})}</p>
      <input class="tin" id="scn-in" type="text" maxlength="60" spellcheck="false" enterkeyhint="done" value="${esc(now.length === 1 ? now[0] : "")}" placeholder="${esc(names[0] || "SOUL")}" aria-label="${esc(tl("scene.name"))}">
      ${names.length ? `<div class="scnsug" role="group" aria-label="${esc(tl("scene.have"))}">${names.map((s) => `<button class="btn sm weak press" type="button" data-scns="${esc(s)}">${esc(s)}</button>`).join("")}</div>` : ""}
      <button type="button" class="btn xl fill press" id="scn-ok">${tl("depts.group.save")}</button>
      ${now.some(Boolean) ? `<button type="button" class="btn xl weak press" id="scn-off">${tl("scene.off")}</button>` : ""}`, (box) => {
      const inp = box.querySelector("#scn-in");
      box.querySelectorAll("[data-scns]").forEach((b) => b.onclick = () => { inp.value = b.dataset.scns; inp.focus(); });
      const send = async (scene) => {
        const byP = new Map();
        picked.forEach((x) => { if (!byP.has(x.project)) byP.set(x.project, []); byP.get(x.project).push(x.id); });
        try {
          for (const [p, items] of byP) {
            const r = await post("/api/scenes", {p, items, scene});
            items.forEach((i) => tags.delete(p + "/" + i));
            Object.entries(r.scenes || {}).forEach(([i, s]) => tags.set(p + "/" + i, s));
          }
        } catch (e) { return toast(e.message); }
        closeSheet(); deptSel = null; selOff("dept");
        store("v2-scn", "1");                       // show where the picked results went
        redrawDept();
        toast(scene ? tl("scene.done", {s: scene}) : tl("scene.cleared"));
      };
      box.querySelector("#scn-ok").onclick = () => { const s = inp.value.trim(); if (!s) return inp.focus(); send(s); };
      inp.onkeydown = (e) => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); box.querySelector("#scn-ok").click(); } };
      box.querySelector("#scn-off")?.addEventListener("click", () => send(""));
    });
  }

  document.addEventListener("click", (e) => {
    const t = e.target.closest?.("[data-scnon],[data-scnh],[data-scntag]");
    if (!t || !detail || detail[0] !== "dept") return;
    if (t.hasAttribute("data-scnon")) { store("v2-scn", on() ? "0" : "1"); return redrawDept(); }
    if (t.hasAttribute("data-scntag")) {
      const all = projects().find((x) => x.name === detail[1])?.items || [];
      return tagSheet(all, all.filter((x) => deptSel?.has(iid(x))));
    }
    // Fold or open one scene in place: the rest of the page stays as it is.
    const k = detail[1] + "\u0001" + t.dataset.scnh, gal = t.nextElementSibling, open = gal.hidden;
    open ? shut.delete(k) : shut.add(k); saveShut();
    t.setAttribute("aria-expanded", String(open)); gal.hidden = !open;
    if (open && !RM()) { gal.classList.remove("scnin"); void gal.offsetWidth; gal.classList.add("scnin"); }
  });

  window.Scenes = {list, toggle, tagBtn};
})();
