// One dropdown for every choice field (feedback I2). <gk-select> stands where a native <select>
// stood: the same <option value selected disabled> children, the same .value / .selectedIndex /
// .options / .disabled, and it fires input + change when the person picks - so a screen swaps the
// tag and keeps its code. The list is the app's own menu surface (the --menu-* tokens in v2.css),
// never the browser's or the phone's picker.
// Keys, closed: Enter / Space / ↑ / ↓ open it, a letter opens it on the next match.
// Keys, open: ↑ ↓ Home End PgUp PgDn move, Enter / Space / Tab choose, Esc closes and keeps the
// old value, letters jump to the next row that starts with what was typed.
// Nothing is chosen until the person commits: a screen that redraws on change would otherwise drop
// the focus on the first arrow press.
(function () {
  if (!window.customElements || customElements.get("gk-select")) return;
  const CARET = '<svg part="caret" viewBox="0 0 256 256" aria-hidden="true"><path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z"/></svg>';
  const CHECK = '<svg class="ck" viewBox="0 0 256 256" aria-hidden="true"><path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"/></svg>';
  const SHADOW = "<style>:host{-webkit-tap-highlight-color:transparent}"
    + ".l{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left}"
    + "svg{flex:none;width:14px;height:14px;fill:currentColor;color:var(--gksel-caret,var(--t3));transition:transform .22s cubic-bezier(.2,.9,.25,1)}"
    + ":host([aria-expanded=true]) svg{transform:rotate(180deg)}"
    + "@media (prefers-reduced-motion:reduce){svg{transition:none}}</style>"
    + '<span class="l" part="label"></span>' + CARET;
  const calm = () => document.body.classList.contains("calm") || matchMedia("(prefers-reduced-motion:reduce)").matches;
  let seq = 0, open = null;       // the one select whose list is showing

  class GkSelect extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({mode: "open"}).innerHTML = SHADOW;
      this._v = null; this._act = -1; this._pop = null; this._buf = ""; this._bufAt = 0;
      this._mo = new MutationObserver(() => this._sync(true));
      this.addEventListener("keydown", (e) => this._key(e));
      // A press on the control must not start a text selection or move focus off it.
      this.addEventListener("pointerdown", (e) => { if (e.button) return; e.preventDefault(); if (!this.disabled) this.focus({preventScroll: true}); });
      this.addEventListener("click", (e) => { e.preventDefault(); if (!this.disabled) this._toggle(); });
      this.addEventListener("focusout", () => { if (!this._hold) this._close(); });
    }
    static get observedAttributes() { return ["disabled"]; }
    attributeChangedCallback() { this._aria(); }
    connectedCallback() {
      if (!this.id) this.id = "gksel" + (++seq);
      this.setAttribute("role", "combobox"); this.setAttribute("aria-haspopup", "listbox"); this.setAttribute("aria-expanded", "false");
      this._mo.observe(this, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["selected", "value", "disabled", "label"]});
      this._sync(true);
    }
    disconnectedCallback() { this._mo.disconnect(); this._close(); }

    // ---- the <select> surface the screens already use ----
    get options() { return [...this.querySelectorAll("option")]; }
    get value() { this._settle(); return this._v == null ? "" : this._v; }
    set value(v) { this._settle(); v = String(v); this._v = this.options.some((o) => o.value === v) ? v : null; this._paint(); }
    get selectedIndex() { const v = this.value; return this._v == null ? -1 : this.options.findIndex((o) => o.value === v); }
    set selectedIndex(n) { const o = this.options[n]; this._v = o ? o.value : null; this._paint(); }
    get disabled() { return this.hasAttribute("disabled"); }
    set disabled(v) { this.toggleAttribute("disabled", !!v); }
    // What the closed control reads: the chosen row's words.
    get label() { const o = this.options[this.selectedIndex]; return o ? this._text(o) : ""; }

    _text(o) { return (o.getAttribute("label") || o.textContent || "").replace(/\s+/g, " ").trim(); }
    // Changes made to the children are seen at once by a reader (the observer runs a tick later).
    _settle() { if (this._mo.takeRecords().length) this._sync(true); }
    // The children changed: a row marked selected wins (as the parser does for a select), else the
    // value held stays if it still exists, else the first row that can be chosen.
    _sync(fromDom) {
      const O = this.options;
      const marked = fromDom ? O.filter((o) => o.hasAttribute("selected")).pop() : null;
      const sig = O.map((o) => o.value + "\u0001" + (o.hasAttribute("selected") ? 1 : 0)).join("\u0002");
      if (marked && sig !== this._sig) this._v = marked.value;
      else if (this._v == null || !O.some((o) => o.value === this._v)) { const f = O.find((o) => !o.disabled) || O[0]; this._v = f ? f.value : null; }
      this._sig = sig;
      this._paint();
      if (this._pop) this._fill();
    }
    _paint() {
      const t = this.label;
      this.shadowRoot.querySelector(".l").textContent = t || " ";
      this._aria();
    }
    _aria() {
      this.tabIndex = this.disabled ? -1 : 0;
      if (this.disabled) this.setAttribute("aria-disabled", "true"); else this.removeAttribute("aria-disabled");
      if (this.disabled) this._close();
    }

    // ---- the list ----
    _toggle() { if (this._pop) this._close(); else this._open(); }
    _open(at) {
      if (this._pop || this.disabled || !this.options.length) return;
      if (open && open !== this) open._close();
      const p = document.createElement("div");
      p.className = "gksel-pop"; p.id = this.id + "-list"; p.setAttribute("role", "listbox");
      const name = this.getAttribute("aria-label"); if (name) p.setAttribute("aria-label", name);
      // Inside a sheet the list joins the sheet (it is above everything else there); the control
      // owns it either way, so a screen reader finds it under the field.
      (this.closest(".sheet") || document.body).appendChild(p);
      this._pop = p; open = this;
      this.setAttribute("aria-expanded", "true"); this.setAttribute("aria-controls", p.id); this.setAttribute("aria-owns", p.id);
      this._act = at == null ? Math.max(0, this.selectedIndex) : at;
      this._fill(); this._place();
      // Focus stays on the control while a row is pressed (a touch press may still take it away:
      // the list then waits for the release instead of closing under the finger).
      p.addEventListener("pointerdown", (e) => { e.preventDefault(); this._hold = true; });
      p.addEventListener("click", (e) => { this._hold = false; const r = e.target.closest(".gksel-o");
        if (r && r.getAttribute("aria-disabled") !== "true") { this._choose(+r.dataset.n); this.focus({preventScroll: true}); } });
      this._up = () => setTimeout(() => { this._hold = false; if (this._pop && document.activeElement !== this) this.focus({preventScroll: true}); }, 0);
      p.addEventListener("pointermove", (e) => { const r = e.target.closest(".gksel-o"); if (r && +r.dataset.n !== this._act && r.getAttribute("aria-disabled") !== "true") this._mark(+r.dataset.n, false); });
      // A press outside only puts the list away, like a native one: the click that follows it is
      // dropped, so dismissing never also opens whatever happened to be under the finger.
      this._away = (e) => {
        if (this.contains(e.target) || e.target === this || p.contains(e.target)) return;
        this._close();
        const eat = (c) => { c.preventDefault(); c.stopPropagation(); off(); };
        const off = () => { removeEventListener("click", eat, true); clearTimeout(t); };
        const t = setTimeout(off, 700);
        addEventListener("click", eat, true);
      };
      this._scroll = (e) => { if (e.target !== p && !p.contains(e.target)) this._close(); };
      this._resize = () => this._close();
      document.addEventListener("pointerdown", this._away, true);
      addEventListener("pointerup", this._up, true); addEventListener("pointercancel", this._up, true);
      addEventListener("scroll", this._scroll, true); addEventListener("resize", this._resize);
      if (calm()) p.classList.add("on"); else requestAnimationFrame(() => p.classList.add("on"));
    }
    _fill() {
      const p = this._pop, cur = this.selectedIndex;
      p.innerHTML = this.options.map((o, n) => `<div class="gksel-o" role="option" id="${this.id}-o${n}" data-n="${n}" aria-selected="${n === cur}"${o.disabled ? ' aria-disabled="true"' : ""}><span class="t"></span>${CHECK}</div>`).join("");
      this.options.forEach((o, n) => { p.children[n].firstChild.textContent = this._text(o) || " "; });
      this._mark(Math.min(this._act, p.children.length - 1), true);
    }
    // Under the control, as wide as it at least; above it when there is no room below.
    _place() {
      const p = this._pop, r = this.getBoundingClientRect(), gap = 6, edge = 8;
      p.style.minWidth = Math.round(r.width) + "px";
      p.style.maxHeight = "";
      const below = innerHeight - r.bottom - gap - edge, above = r.top - gap - edge;
      const want = Math.min(p.scrollHeight + 2, 336), up = below < Math.min(want, 160) && above > below;
      p.style.maxHeight = Math.max(96, Math.min(want, up ? above : below)) + "px";
      const w = p.offsetWidth, h = p.offsetHeight;
      const left = Math.max(edge, Math.min(r.left, innerWidth - w - edge));
      p.style.left = left + "px";
      p.style.top = Math.max(edge, up ? r.top - gap - h : r.bottom + gap) + "px";
      p.style.transformOrigin = (up ? "bottom " : "top ") + (r.left - left < 24 ? "left" : "center");
      p.classList.toggle("up", up);
      this._mark(this._act, true);
    }
    _mark(n, scroll) {
      const p = this._pop; if (!p) return;
      [...p.children].forEach((c, i) => c.classList.toggle("act", i === n));
      this._act = n;
      const row = p.children[n];
      if (row) { this.setAttribute("aria-activedescendant", row.id); if (scroll) row.scrollIntoView({block: "nearest"}); }
    }
    _close() {
      const p = this._pop; if (!p) return;
      this._pop = null; if (open === this) open = null;
      document.removeEventListener("pointerdown", this._away, true);
      removeEventListener("pointerup", this._up, true); removeEventListener("pointercancel", this._up, true); this._hold = false;
      removeEventListener("scroll", this._scroll, true); removeEventListener("resize", this._resize);
      this.setAttribute("aria-expanded", "false"); this.removeAttribute("aria-activedescendant"); this.removeAttribute("aria-owns"); this.removeAttribute("aria-controls");
      if (calm()) return p.remove();
      p.classList.remove("on"); p.style.pointerEvents = "none"; setTimeout(() => p.remove(), 140);
    }
    _choose(n) {
      const o = this.options[n]; this._close();
      if (!o || o.disabled || o.value === this._v) return;
      this._v = o.value; this._paint();
      this.dispatchEvent(new Event("input", {bubbles: true}));
      this.dispatchEvent(new Event("change", {bubbles: true}));
    }
    // The next row that can be chosen, `d` rows away (stops at the ends, as a native list does).
    _step(from, d) {
      const O = this.options; let n = from;
      for (let i = from + d; i >= 0 && i < O.length; i += d) if (!O[i].disabled) { n = i; break; }
      return n;
    }
    _edge(last) { const O = this.options; for (let i = last ? O.length - 1 : 0; i >= 0 && i < O.length; i += last ? -1 : 1) if (!O[i].disabled) return i; return -1; }
    _type(ch) {
      const now = Date.now(), O = this.options;
      this._buf = now - this._bufAt < 700 ? this._buf + ch : ch; this._bufAt = now;
      const same = this._buf.split("").every((c) => c === this._buf[0]);
      const q = (same ? this._buf[0] : this._buf).toLowerCase();
      const from = this._pop ? this._act : this.selectedIndex;
      // One repeated letter walks the rows that start with it; a longer word searches from here.
      const start = same || this._buf.length === 1 ? from + 1 : from;
      for (let i = 0; i < O.length; i++) {
        const n = (start + i + O.length) % O.length;
        if (!O[n].disabled && this._text(O[n]).toLowerCase().startsWith(q)) return n;
      }
      return -1;
    }
    _key(e) {
      if (this.disabled || e.ctrlKey || e.metaKey || e.altKey && e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
      const k = e.key, isOpen = !!this._pop;
      const eat = () => { e.preventDefault(); e.stopPropagation(); };
      if (k === "Tab") { if (isOpen) this._choose(this._act); return; }
      if (k === "Escape") { if (isOpen) { eat(); this._close(); } return; }
      // A space in the middle of a typed name ("my project") is part of the name, not a choice.
      const typing = k === " " && this._buf && Date.now() - this._bufAt < 700;
      if (!typing && (k === "Enter" || k === " ")) { eat(); if (e.repeat) return; return isOpen ? this._choose(this._act) : this._open(); }
      if (k === "ArrowDown" || k === "ArrowUp") { eat(); if (!isOpen) return this._open(); return this._mark(this._step(this._act, k === "ArrowDown" ? 1 : -1), true); }
      if (k === "Home" || k === "End") { if (!isOpen) return; eat(); return this._mark(this._edge(k === "End"), true); }
      if (k === "PageDown" || k === "PageUp") { if (!isOpen) return; eat(); let n = this._act; for (let i = 0; i < 8; i++) n = this._step(n, k === "PageDown" ? 1 : -1); return this._mark(n, true); }
      // A letter is the field's own (a jump to the row), never a page shortcut.
      if (k.length === 1) { eat(); const n = this._type(k); if (n < 0) return; if (isOpen) this._mark(n, true); else this._open(n); }
    }
  }
  customElements.define("gk-select", GkSelect);
})();
