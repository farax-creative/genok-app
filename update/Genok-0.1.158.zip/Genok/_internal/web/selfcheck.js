// 설정 → 자동 점검 (design v2 §14 M3, served by selfcheck.py): a small status card with a
// "지금 점검" button, plus a quiet one-time notice on home when the last check failed. State is
// owned by the server; this file only shows it. Globals from v2.js: tl, get, post, toast, esc, ic,
// setPage. Registered like backup.js/wake.js (a settings page) and routines.js (a home card).
(function () {
  "use strict";

  if (!document.getElementById("selfcheck-css")) {
    const st = document.createElement("style");
    st.id = "selfcheck-css";
    st.textContent = `
      .sc-status{display:flex;align-items:center;gap:8px;font-size:14px}
      .sc-dot{width:8px;height:8px;border-radius:50%;flex:none;background:var(--muted,#9aa0aa)}
      .sc-dot.ok{background:#1f8a4c}
      .sc-dot.bad{background:#d08017}
      .sc-hint{margin:6px 0 0;font-size:13px;color:var(--sub,#6b7280);line-height:1.45}
      .sc-alert{display:flex;align-items:center;gap:8px}
      .sc-alert .tx{flex:1;min-width:0}
      @media (prefers-color-scheme:dark){
        .sc-dot{background:#6b7280}
        .sc-dot.ok{background:#79d7a1}
        .sc-dot.bad{background:#e0a44a}}`;
    document.head.appendChild(st);
  }

  const pad = (x) => String(x).padStart(2, "0");
  function localToday() {
    const n = new Date();
    return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`;
  }
  // now_iso() from the server is local ISO with no tz, e.g. "2026-09-30T09:00:12".
  function whenStr(iso) {
    if (!iso) return "";
    const date = iso.slice(0, 10), hm = iso.slice(11, 16);
    return (date === localToday() ? tl("day.1") : date.slice(5)) + " " + hm;
  }
  // A literal tl() per step so the i18n check can see every key is used (no dynamic key building).
  const STEP_LABEL = {
    push: () => tl("selfcheck.step.push"),
    comment: () => tl("selfcheck.step.comment"),
    hook: () => tl("selfcheck.step.hook"),
    delivery: () => tl("selfcheck.step.delivery"),
    verify: () => tl("selfcheck.step.verify"),
    done: () => tl("selfcheck.step.done"),
  };
  const stepLabel = (s) => (STEP_LABEL[s] || STEP_LABEL.done)();

  // One /api/selfcheck per few seconds: home is drawn twice on boot and the settings page reuses it.
  // force=true after "지금 점검" so the fresh result shows.
  let memo = null, memoAt = 0;
  function state(force) {
    if (force || !memo || Date.now() - memoAt > 10000) {
      memoAt = Date.now();
      memo = get("/api/selfcheck");
      memo.catch(() => { memo = null; });
    }
    return memo;
  }

  function statusHtml(last) {
    if (!last) return `<div class="sc-status"><span class="sc-dot"></span>${tl("selfcheck.never")}</div>`;
    if (last.ok) return `<div class="sc-status"><span class="sc-dot ok"></span>${tl("selfcheck.lastOk", {w: whenStr(last.at)})}</div>`;
    return `<div class="sc-status"><span class="sc-dot bad"></span>${tl("selfcheck.lastFail", {w: whenStr(last.at), step: stepLabel(last.step)})}</div>`
      + `<div class="sc-hint">${esc(last.hint || "")}</div>`;
  }

  // ---- settings page --------------------------------------------------------
  async function draw(el, force) {
    let d;
    try { d = await state(force); }
    catch { return; }
    const last = d.last;
    const card = document.createElement("div");
    // The settings page's own parts (title, one line, a row with its button), as every other page.
    card.innerHTML = `<h2 class="seth">${tl("selfcheck.title")}</h2><p class="setd">${tl("selfcheck.desc")}</p>
      <div class="srow"><span class="srtx">${statusHtml(last)}</span>
        <span class="srctl"><button class="btn sm press" id="sc-run"${d.running ? " disabled" : ""}>${d.running ? tl("selfcheck.running") : tl("selfcheck.run")}</button></span></div>`;
    el.appendChild(card);
    const btn = card.querySelector("#sc-run");
    btn.onclick = async () => {
      btn.disabled = true;
      btn.textContent = tl("selfcheck.running");
      try {
        const r = await post("/api/selfcheck-run", {});
        if (r && r.running) toast(tl("selfcheck.running"));
        else toast(r && r.ok ? tl("selfcheck.toastOk") : tl("selfcheck.toastFail", {step: stepLabel(r && r.step)}));
      } catch (e) { toast(e.message); }
      el.innerHTML = "";
      draw(el, true);
    };
  }
  (window.LOOP_SETTINGS = window.LOOP_SETTINGS || [])
    .push(Object.assign(draw, {page: "selfcheck", icon: "gauge", title: "selfcheck.title"}));

  // ---- home: a quiet notice, once per failure -------------------------------
  // v2.js wraps this in a .homecard shell and hands us its body; we keep the shell hidden unless
  // the last check failed, so a healthy loop shows nothing on home.
  (window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || []).push({
    id: "selfcheck-alert", title: "",
    draw: async (host) => {
      // The .homecard shell v2.js created. closest(), not parentElement: a soft redraw draws into a
      // detached host first, and hiding a bare parent there could hide <body>.
      const sec = host.closest(".homecard");
      if (sec) sec.style.display = "none";                // stay out of the way until we know
      let d;
      try { d = await state(); }
      catch { return; }
      const last = d && d.last;
      if (!last || last.ok) return;                       // only when the last check failed
      let dismissed = "";
      try { dismissed = localStorage.getItem("sc-dismiss") || ""; } catch { /* private mode */ }
      if (dismissed === last.at) return;                  // this failure was already dismissed
      const el = document.createElement("div");
      el.className = "sc-alert";
      el.innerHTML = `<span class="ico sm c-orange">${ic("warn")}</span>
        <span class="tx"><div class="t" style="font-size:15px">${tl("selfcheck.homeFail")}</div>
          <div class="s">${esc(last.hint || "")}</div></span>
        <button class="btn sm press" data-go="settings" data-scopen>${tl("selfcheck.open")}</button>
        <button class="ib press" data-scx aria-label="${tl("ui.close")}">${ic("x")}</button>`;
      host.appendChild(el);
      if (sec) sec.style.display = "";                    // reveal now that there is something to show
      // Deep-link to the 자동 점검 settings page (data-go="settings" does the navigation).
      el.querySelector("[data-scopen]").addEventListener("click", () => {
        try { setPage = "selfcheck"; } catch { /* settings opens on the default page */ }
      });
      el.querySelector("[data-scx]").onclick = () => {
        try { localStorage.setItem("sc-dismiss", last.at); } catch { /* ignore */ }
        if (sec) sec.remove(); else el.remove();
      };
    },
  });
})();
