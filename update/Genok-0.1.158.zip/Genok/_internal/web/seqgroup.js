// Numbered images shown as one sequence: shot_0001.png ... shot_0300.png pushed as files (not as a
// folder, which push already turns into one video) were hundreds of tiles under the stage. Runs of
// them become one tile with a count and a scrub bar; the files and the stored data stay as they
// are. The name rule is push_review.SEQ_RE's. Tested in tests/seqgroup.test.js.
(function () {
  "use strict";

  const RE = /^(.*?)(\d+)\.(png|jpe?g|exr|tiff?|tga|dpx|webp)$/i;
  // Under a row of tiles, a few numbered files read fine one by one.
  const MIN = 8;

  // Runs of consecutive files (in the order given) whose names differ only by the trailing
  // number: [{start, end, count, prefix, digits, ext}], `start`/`end` being indices into `files`.
  function runs(files, min = MIN) {
    const out = [];
    let cur = null;
    (files || []).forEach((f, i) => {
      const m = f && f.kind !== "video" && RE.exec(f.name || "");
      const key = m ? `${m[1]}\u0000${m[2].length}\u0000${m[3].toLowerCase()}` : null;
      if (cur && key && key === cur.key) { cur.end = i; return; }
      if (cur && cur.end - cur.start + 1 >= min) out.push(cur);
      cur = key ? {key, start: i, end: i, prefix: m[1], digits: m[2].length, ext: m[3]} : null;
    });
    if (cur && cur.end - cur.start + 1 >= min) out.push(cur);
    return out.map(({key, ...r}) => ({...r, count: r.end - r.start + 1}));
  }

  // The run that index `n` falls in, or null.
  const at = (rs, n) => rs.find((r) => n >= r.start && n <= r.end) || null;

  // The trailing number of a file name in a run, for its label ("0001").
  const num = (name) => (RE.exec(name || "") || [])[2] || "";

  const api = {runs, at, num, MIN};
  if (typeof module !== "undefined") module.exports = api;
  if (typeof window !== "undefined") window.SeqGroup = api;
})();
