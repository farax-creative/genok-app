// Reference mode (design §4.2): a big original (video, or anything >=100MB) is kept in place, not
// copied into the version folder. When that original is later moved or overwritten the version can
// no longer show it - the server refuses to serve mismatched bytes - so the file tile must say so
// plainly instead of showing a broken picture. This paints a small "원본 없음 / 원본이 바뀜" badge
// on the affected tiles (the stage slide and, when shown, the file-grid thumb) and offers 위치 찾기,
// which reveals the path meta recorded. Attached through window.LOOP_ITEM_VIEW (the per-item slot);
// globals tl, esc, toast come from v2.js.

(function () {
  "use strict";
  if (typeof window === "undefined") return;

  const STYLE = `
  .srcbad{position:absolute;left:8px;top:8px;z-index:6;display:inline-flex;align-items:center;gap:8px;
    max-width:calc(100% - 16px);padding:4px 12px;border-radius:8px;font-size:12px;font-weight:600;
    color:#fff;background:rgba(178,42,42,.94);box-shadow:0 1px 4px rgba(0,0,0,.35)}
  .srcbad button{all:unset;cursor:pointer;text-decoration:underline}
  .srcbad button:focus-visible{outline:2px solid #fff;outline-offset:2px;border-radius:4px}
  .sg .srcbad{left:50%;transform:translateX(-50%);top:4px;padding:4px 8px;font-size:12px;gap:0}
  .sg .srcbad button{display:none}`;   // the grid thumb is tiny: badge only, the action is on the stage

  let styled = false;
  function ensureStyle() {
    if (styled) return;
    const s = document.createElement("style"); s.textContent = STYLE; document.head.appendChild(s);
    styled = true;
  }

  // A file whose referenced original no longer matches. `overwritten` is the record a later push
  // left (§4.2 overwrite guard); ref_state is the live re-check the server made.
  function state(f) {
    if (!f) return null;
    if (f.ref_state === "missing") return "missing";
    if (f.overwritten || f.ref_state === "changed") return "changed";
    return null;
  }
  const label = (st) => st === "missing" ? tl("src.1") : tl("src.2");   // 원본 없음 / 원본이 바뀜

  function reveal(f) {
    const p = f.ref && f.ref.path;
    if (!p) { toast(tl("src.4")); return; }
    // A local app: show where the original was and copy the path so the user can open its folder.
    try { if (navigator.clipboard) navigator.clipboard.writeText(p); } catch (e) {}
    toast(tl("src.3", {p: p}), 6000);
  }

  function badge(st, f, withAction) {
    const b = document.createElement("div");
    b.className = "srcbad"; b.setAttribute("role", "status");
    b.appendChild(Object.assign(document.createElement("span"), {textContent: label(st)}));
    if (withAction) {
      const btn = document.createElement("button");
      btn.type = "button"; btn.textContent = tl("src.5");   // 위치 찾기
      btn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); reveal(f); };
      b.appendChild(btn);
    }
    return b;
  }

  // The shown version's files line up with the stage slides (.sl) and the file grid (.sg) by index,
  // both built from `pics` in v2.js. it.pics is that same list.
  function paint(box, it, d) {
    const pics = (it && it.pics) || [];
    if (!pics.length) return;
    let any = false;
    const sls = box.querySelectorAll("#stage .strk .sl");
    pics.forEach((f, n) => {
      const st = state(f);
      if (!st) return;
      any = true;
      const sl = sls[n];
      if (sl && !sl.querySelector(".srcbad")) sl.appendChild(badge(st, f, true));
      const sg = box.querySelector('.sg[data-sg="' + n + '"]');
      if (sg && !sg.querySelector(".srcbad")) sg.appendChild(badge(st, f, false));
    });
    if (any) ensureStyle();
  }

  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(function (box, it, d) { paint(box, it, d); });
})();
