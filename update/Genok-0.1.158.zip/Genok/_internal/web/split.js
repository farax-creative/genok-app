// Conversations side by side on the chat screen (PC only): up to 3 columns, 2 stacked in each.
// This file owns: the layout arithmetic (pure, tested in tests/split.test.js), the drag of a
// session row out of the list with its drop zones, the dividers between panes, and their CSS.
// project.js draws the panes themselves (each one is its ordinary chat) and decides what fits:
// it hands this file a `host` (PjSplit.host) with the few things only it knows.
(function () {
  "use strict";
  const MIN = 300, MINH = 220, GAP = 10, MAXC = 3, MAXR = 2, MAX = MAXC, KEY = "rl-pj-split";

  // ---- layout: {panes: [{id, p}], rows: [panes per column], w: [fraction per column],
  //               h: [the top pane's share per column], focus: pane index} -----------------------
  // `id` is the session, `p` the project it was opened from. The panes are listed column by
  // column, top first. At most MAXC columns side by side and MAXR panes stacked in one (3 x 2):
  // every function that changes a layout refuses a 4th column and a 3rd row by handing back the
  // layout it was given. A layout only exists with two panes or more: one conversation is the
  // ordinary screen. A layout saved before the rows existed has no `rows`: one pane per column.
  const equal = (n) => Array.from({length: n}, () => 1 / n);
  function widths(w, n) {
    if (!Array.isArray(w) || w.length !== n || w.some((x) => !(x > 0) || !isFinite(x))) return equal(n);
    const sum = w.reduce((a, b) => a + b, 0);
    return w.map((x) => x / sum);
  }
  const share = (x) => (x > 0 && x < 1 ? x : 0.5);
  const ints = (r, n) => Array.isArray(r) && r.length > 0 && r.every((x) => Number.isInteger(x) && x >= 1) && r.reduce((a, b) => a + b, 0) === n;
  const rowsOf = (L) => (ints(L.rows, L.panes.length) ? L.rows : L.panes.map(() => 1));
  // The same layout as columns: [{w, h, ps: [pane, ...]}], and back (null under two panes).
  function unpack(L) {
    const rows = rowsOf(L), w = widths(L.w, rows.length);
    let i = 0;
    return {fid: L.panes[L.focus] ? L.panes[L.focus].id : "", cols: rows.map((n, c) => ({w: w[c], h: share(L.h && L.h[c]), ps: L.panes.slice(i, i += n)}))};
  }
  function pack(cols, fid) {
    const panes = [].concat(...cols.map((c) => c.ps));
    if (panes.length < 2) return null;
    return {panes, rows: cols.map((c) => c.ps.length), w: widths(cols.map((c) => c.w), cols.length), h: cols.map((c) => (c.ps.length > 1 ? c.h : 0.5)),
      focus: Math.max(0, panes.findIndex((p) => p.id === fid))};
  }
  // Take a pane out of the columns; a column left empty goes with it ({c: its column, gone}).
  function take(cols, id) {
    for (let c = 0; c < cols.length; c++) {
      const r = cols[c].ps.findIndex((p) => p.id === id); if (r < 0) continue;
      cols[c].ps.splice(r, 1); cols[c].h = 0.5;
      const gone = !cols[c].ps.length;
      if (gone) cols.splice(c, 1);
      return {c, gone};
    }
    return null;
  }
  // What is read from storage (or handed over by anything else) is brought inside the limits
  // without dropping a session quietly: a pane past the 3rd column or the 2nd row moves to a new
  // column while there is room for one, then under the rightmost column that still has one pane.
  // Only what is left once all six places are taken is not opened: `out` names those panes (they
  // stay in the list, nothing is closed on the server) so the page can say so.
  function clamp(raw) {
    if (!raw || !Array.isArray(raw.panes)) return {L: null, out: []};
    const seen = new Set(), flat = [];
    raw.panes.forEach((p) => {
      const ok = !!p && typeof p.id === "string" && !!p.id && !seen.has(p.id);
      if (ok) seen.add(p.id);
      flat.push(ok ? {id: p.id, p: typeof p.p === "string" ? p.p : ""} : null);
    });
    const rows = ints(raw.rows, flat.length) ? raw.rows : flat.map(() => 1);
    const rw = Array.isArray(raw.w) ? raw.w : [], rh = Array.isArray(raw.h) ? raw.h : [];
    let i = 0;
    const cols = rows.map((n, c) => ({w: rw[c], h: share(rh[c]), ps: flat.slice(i, i += n).filter(Boolean)})).filter((c) => c.ps.length);
    const ids = [].concat(...cols.map((c) => c.ps)), f = Math.floor(Number(raw.focus)) || 0;
    const fid = ids.length ? ids[Math.max(0, Math.min(ids.length - 1, f))].id : "";
    const extra = [], out = [];
    cols.forEach((c) => { if (c.ps.length > MAXR) { extra.push(...c.ps.splice(MAXR)); c.h = 0.5; } });
    cols.splice(MAXC).forEach((c) => extra.push(...c.ps));
    if (cols.some((c) => !(c.w > 0) || !isFinite(c.w))) cols.forEach((c) => { c.w = 1; });
    extra.forEach((p) => {
      if (cols.length < MAXC) { cols.push({w: cols.reduce((a, c) => a + c.w, 0) / (cols.length || 1) || 1, h: 0.5, ps: [p]}); return; }
      const c = cols.slice().reverse().find((x) => x.ps.length < MAXR);
      if (c) { c.ps.push(p); c.h = 0.5; } else out.push(p);
    });
    const L = pack(cols, fid);
    if (L && L.panes[L.focus].id !== fid) L.focus = L.panes.length - 1;
    return {L, out: L ? out : []};
  }
  const norm = (raw) => clamp(raw).L;
  // How many columns fit in `width` px (each at least MIN, GAP between them), and how many rows
  // in `height` px (each at least MINH).
  const cap = (width) => Math.max(1, Math.min(MAXC, Math.floor((width + GAP) / (MIN + GAP))));
  const need = (n) => n * MIN + Math.max(0, n - 1) * GAP;
  const capRows = (height) => Math.max(1, Math.min(MAXR, Math.floor((height + GAP) / (MINH + GAP))));
  const indexOf = (L, id) => (L ? L.panes.findIndex((p) => p.id === id) : -1);
  // Where a pane is: {c: column, r: row}.
  function where(L, id) {
    const i = indexOf(L, id); if (i < 0) return null;
    const rows = rowsOf(L);
    for (let c = 0, a = 0; c < rows.length; a += rows[c++]) if (i < a + rows[c]) return {c, r: i - a};
    return null;
  }
  const focusCol = (L) => (where(L, (L.panes[L.focus] || {}).id) || {c: 0}).c;
  // The columns that are drawn when fewer fit than the layout holds: a run that keeps the focused one.
  function shown(L, fit) {
    const cols = rowsOf(L).length, n = Math.max(1, Math.min(cols, fit));
    return {from: Math.min(Math.max(0, focusCol(L) - n + 1), cols - n), n};
  }
  // What is drawn in a window that fits `fitC` columns and `fitR` rows: {from, n, cols: [[pane]],
  // panes}. A stacked column with room for one row shows its focused pane, else its top one.
  function view(L, fitC, fitR) {
    const S = unpack(L), win = shown(L, fitC);
    const cols = S.cols.slice(win.from, win.from + win.n).map((c) => (c.ps.length <= fitR ? c.ps : [c.ps.find((p) => p.id === S.fid) || c.ps[0]]));
    return {from: win.from, n: win.n, cols, panes: [].concat(...cols)};
  }
  // Put a pane in a column of its own at column position `at` (0 = far left). One that is already
  // open moves there. The newcomer takes an equal share and the others keep their proportions.
  // Refused (the same layout comes back) when that would be a 4th column.
  function insert(L, pane, at) {
    const S = unpack(L), was = take(S.cols, pane.id);
    if (was && was.gone && was.c < at) at--;
    if (S.cols.length >= MAXC) return L;
    at = Math.max(0, Math.min(S.cols.length, at));
    const n = S.cols.length + 1, rest = S.cols.reduce((a, c) => a + c.w, 0) || 1;
    S.cols.forEach((c) => { c.w = c.w / rest * (n - 1) / n; });
    S.cols.splice(at, 0, {w: 1 / n, h: 0.5, ps: [{id: pane.id, p: pane.p || ""}]});
    return pack(S.cols, pane.id);
  }
  // Put a pane above or below the pane `target`, in its column; the two share the height equally.
  // Refused when that would be a 3rd row.
  function stack(L, pane, target, below) {
    if (pane.id === target) return L;
    const S = unpack(L); take(S.cols, pane.id);
    const col = S.cols.find((c) => c.ps.some((p) => p.id === target));
    if (!col || col.ps.length >= MAXR) return L;
    col.ps.splice(below ? col.ps.length : 0, 0, {id: pane.id, p: pane.p || ""}); col.h = 0.5;
    return pack(S.cols, pane.id);
  }
  // A drop on one side of the pane `target`: "l" | "r" a column of its own beside that pane's
  // column, "t" | "b" stacked with it.
  function drop(L, pane, target, side) {
    const t = where(L, target); if (!t) return L;
    if (side === "t" || side === "b") return stack(L, pane, target, side === "b");
    return insert(L, pane, t.c + (side === "r" ? 1 : 0));
  }
  const sig = (L) => unpack(L).cols.map((c) => c.ps.map((p) => p.id).join(",")).join("|");
  // May `id` be dropped there? "" yes, "same" it would change nothing, "cols" | "rows" that side
  // is full (a 4th column, a 3rd row).
  function can(L, id, target, side) {
    if (!L || !where(L, target)) return "same";   // no layout yet (nothing open): nothing to split
    const N = drop(L, {id}, target, side);
    if (N !== L) return sig(N) === sig(L) ? "same" : "";
    return id === target ? "same" : side === "t" || side === "b" ? "rows" : "cols";
  }
  // Would insert() change anything? (dropping a pane on its own column's edge does not)
  function moves(L, id, at) {
    const t = where(L, id);
    return !t || rowsOf(L)[t.c] > 1 || (at !== t.c && at !== t.c + 1);
  }
  // Open one more without saying where (the menu): a column right of the focused one while a
  // column fits (`fitC`), else under the nearest column that has one pane (when `fitR` is 2).
  // The same layout comes back when every place is taken.
  function add(L, pane, fitC, fitR) {
    if (indexOf(L, pane.id) >= 0) return L;
    const fc = focusCol(L);
    if (rowsOf(L).length < Math.min(MAXC, fitC)) return insert(L, pane, fc + 1);
    if (Math.min(MAXR, fitR) < 2) return L;
    const S = unpack(L), c = S.cols.map((x, i) => i).sort((a, b) => Math.abs(a - fc) - Math.abs(b - fc) || a - b).find((i) => S.cols[i].ps.length < MAXR);
    return c === undefined ? L : stack(L, pane, S.cols[c].ps[S.cols[c].ps.length - 1].id, true);
  }
  // Close a pane. Its room goes to the others (its column's width in proportion, or the whole
  // height to the pane it was stacked with); null once a single one is left.
  function remove(L, id) {
    const i = indexOf(L, id); if (i < 0) return L;
    const S = unpack(L); take(S.cols, id);
    const N = pack(S.cols, S.fid); if (!N) return null;
    if (i === L.focus) N.focus = Math.min(L.focus, N.panes.length - 1);
    return N;
  }
  // A conversation opened the ordinary way (a click in the list, a link): an open one is focused,
  // any other takes the focused pane's place.
  function open(L, pane) {
    const i = indexOf(L, pane.id);
    if (i >= 0) return i === L.focus ? L : Object.assign({}, L, {focus: i});
    const panes = L.panes.slice(); panes[L.focus] = {id: pane.id, p: pane.p || ""};
    return Object.assign({}, L, {panes});
  }
  // The divider after pane i moved by d (a fraction of the whole): both neighbours keep `min`.
  function drag(w, i, d, min) {
    const out = w.slice(), sum = w[i] + w[i + 1];
    if (sum < 2 * min) return out;
    const a = Math.max(min, Math.min(sum - min, w[i] + d));
    out[i] = a; out[i + 1] = sum - a;
    return out;
  }
  // A point (page px) that is not over a page `w` by `h`: where a dragged row has left the window.
  const outside = (x, y, w, h) => x < 0 || y < 0 || x > w || y > h;
  const api = {MIN, MINH, GAP, MAX, MAXC, MAXR, KEY, equal, norm, clamp, cap, capRows, need, shown, view, indexOf, where, rowsOf, insert, stack, drop, can, add, moves, remove, open, drag, outside};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined" || typeof document === "undefined") return;

  // ---- on this device -------------------------------------------------------------------------
  // A stored layout past the limits is brought inside them (clamp) and kept that way; the panes
  // that found no place wait in `spilled` for the page to name them once.
  api.spilled = null;
  api.load = () => {
    try {
      const raw = localStorage.getItem(KEY); if (!raw) return null;
      const r = clamp(JSON.parse(raw));
      if (r.out.length) { api.spilled = (api.spilled || []).concat(r.out); api.save(r.L); }
      return r.L;
    } catch (e) { return null; }
  };
  api.save = (L) => { try { L = L && norm(L); if (L) localStorage.setItem(KEY, JSON.stringify(L)); else localStorage.removeItem(KEY); } catch (e) { /* this visit only */ } };
  api.host = null;                                   // set by project.js
  window.PjSplit = api;

  const RM = () => { try { return matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; } };
  // Phosphor "columns" (regular), the same family as ic() in v2.js.
  api.icon = `<svg class="i" viewBox="0 0 256 256" aria-hidden="true"><path d="M104,32H64A16,16,0,0,0,48,48V208a16,16,0,0,0,16,16h40a16,16,0,0,0,16-16V48A16,16,0,0,0,104,32Zm0,176H64V48h40ZM192,32H152a16,16,0,0,0-16,16V208a16,16,0,0,0,16,16h40a16,16,0,0,0,16-16V48A16,16,0,0,0,192,32Zm0,176H152V48h40Z"/></svg>`;

  const CSS = `
  html.pj3 .pj-cols.pj-sp>.pj-g.l{z-index:3}
  .pj-split{display:flex;align-items:stretch;min-width:0;min-height:0}
  .pj-col{flex:1 1 0;min-width:${MIN}px;min-height:0;display:flex;flex-direction:column}
  .pj-pane{position:relative;flex:1 1 0;min-width:0;min-height:0;display:flex;flex-direction:column}
  .pj-col>.pj-pane:not(:only-child){min-height:${MINH}px}
  .pj-pane>.pj-conv{flex:1 1 auto;min-height:0}
  /* The ring is drawn over the pane: an inset shadow on the card itself is covered by what is in it. */
  .pj-pane::after{content:"";position:absolute;inset:0;z-index:3;pointer-events:none;border-radius:var(--r-card);box-shadow:inset 0 0 0 1.5px transparent;transition:box-shadow .16s}
  .pj-pane.focus::after{box-shadow:inset 0 0 0 1.5px color-mix(in srgb,var(--blue) 78%,transparent)}
  .pj-pane>.pj-empty{flex:1;display:grid;place-items:center;background:var(--card);border-radius:var(--r-card)}
  .pj-pane .pj-nth{padding:8px 8px 8px 16px;gap:8px;min-height:50px}
  .pj-pane .pj-nth .t{font-size:15px;line-height:1.4;color:var(--t2)}
  .pj-pane.focus .pj-nth .t{color:var(--t1)}
  .pj-pane .pj-nth .k{flex:none;min-width:18px;height:18px;padding:0 4px;border-radius:6px;background:var(--btn);color:var(--t3);
    font-size:12px;font-weight:600;line-height:18px;text-align:center;font-variant-numeric:tabular-nums}
  .pj-pane.focus .pj-nth .k{background:var(--blue);color:var(--on-blue,#fff)}
  .pj-pane .pj-px{margin:0;width:30px;height:30px}
  .pj-pane.in{animation:pj-pin var(--m-snap-d,.4s) var(--m-snap,cubic-bezier(.2,.9,.25,1)) backwards}
  .pj-pane.in.r{--pj-pfrom:14px} .pj-pane.in.l{--pj-pfrom:-14px}
  @keyframes pj-pin{from{opacity:0;transform:translate3d(var(--pj-pfrom,0),0,0)}}
  .pj-split.eq>.pj-col,.pj-col.eq>.pj-pane{transition:flex-grow var(--m-snap-d,.4s) var(--m-snap,cubic-bezier(.2,.9,.25,1))}
  .pj-dv{position:relative;flex:none;width:${GAP}px;cursor:col-resize;touch-action:none;outline:none}
  .pj-dv::before{content:"";position:absolute;left:-3px;right:-3px;top:0;bottom:0}
  .pj-dv::after{content:"";position:absolute;left:50%;top:50%;width:4px;height:36px;margin:-16px 0 0 -2px;border-radius:2px;background:var(--t4);opacity:.7;
    transition:background .15s,height .15s,margin-top .15s,opacity .15s}
  .pj-dv:hover::after,.pj-dv:focus-visible::after,.pj-dv.on::after{background:var(--blue);opacity:1;height:72px;margin-top:-36px}
  .pj-dh{position:relative;flex:none;height:${GAP}px;cursor:row-resize;touch-action:none;outline:none}
  .pj-dh::before{content:"";position:absolute;top:-3px;bottom:-3px;left:0;right:0}
  .pj-dh::after{content:"";position:absolute;left:50%;top:50%;width:36px;height:4px;margin:-2px 0 0 -16px;border-radius:2px;background:var(--t4);opacity:.7;
    transition:background .15s,width .15s,margin-left .15s,opacity .15s}
  .pj-dh:hover::after,.pj-dh:focus-visible::after,.pj-dh.on::after{background:var(--blue);opacity:1;width:72px;margin-left:-36px}
  /* a row that is open in a pane: .vis, drawn with the rows (project.js) */
  /* the row in the hand */
  .sp-src:not(.pj-ghost){opacity:0!important;pointer-events:none!important}
  .pj-ghost{position:fixed!important;left:0;top:0;z-index:600;margin:0 !important;pointer-events:none;will-change:transform;transition:none!important;
    background:var(--card-hi,var(--panel))!important;opacity:1;filter:none!important;color:var(--t1);border-color:var(--line)!important;box-shadow:0 16px 32px rgba(0,0,0,.32),0 3px 8px rgba(0,0,0,.18),0 0 0 1px color-mix(in srgb,var(--t1) 12%,transparent);cursor:grabbing;overflow:visible!important}
  .pj-grab-hint{position:absolute;left:8px;top:-27px;padding:3px 9px;border-radius:7px;background:var(--blue);color:var(--on-blue,#fff);font:600 11px/18px var(--font,system-ui);white-space:nowrap;pointer-events:none}
  .pj-ghost.back .pj-grab-hint{display:none}
  .pj-ghost.back{pointer-events:auto;cursor:grab}
  /* a project in the hand: its name on top of the edge of its sessions */
  .pj-gbox{display:contents}
  .pj-ghost.pj-sgl,.pj-ghost.pj-multi{border-radius:var(--r-md,10px)}
  .pj-ghost.pj-sgl::before,.pj-ghost.pj-sgl::after,.pj-ghost.pj-multi::before,.pj-ghost.pj-multi::after{content:"";position:absolute;top:100%;height:7px;border-radius:0 0 8px 8px;background:var(--btn-hi,var(--card-hi));box-shadow:0 0 0 1.5px color-mix(in srgb,var(--blue) 55%,transparent);z-index:-1}
  .pj-ghost.pj-sgl::before,.pj-ghost.pj-multi::before{left:10px;right:10px;margin-top:-1px;opacity:.85}
  .pj-ghost.pj-sgl::after,.pj-ghost.pj-multi::after{left:22px;right:22px;margin-top:4px;opacity:.55}
  .pj-ghost.pj-n2::after{content:none}
  .pj-ghost.pj-multi{overflow:visible!important}
  /* how many are in the hand */
  .pj-ghost .pj-gn{position:absolute;top:-8px;right:-8px;z-index:2;min-width:22px;height:22px;padding:0 6px;box-sizing:border-box;border-radius:11px;background:var(--blue)!important;color:var(--on-blue,#fff)!important;
    font:700 12px/22px var(--font,inherit);font-style:normal;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,.35)}
  body.pj-dragging,body.pj-dragging *{cursor:grabbing!important;user-select:none!important}
  /* where it may land: each pane's left and right (a column beside it) and, between them, its
     top and bottom (stacked with it); only the sides it can go to are drawn, the one under the pointer lit */
  .pj-dz{position:fixed;z-index:590;pointer-events:none;display:flex;gap:8px;padding:8px;box-sizing:border-box;animation:pj-dzin .14s ease-out}
  @keyframes pj-dzin{from{opacity:0}}
  .pj-dz .h{flex:1 1 0;min-width:0;border-radius:calc(var(--r-card) - 4px);border:1.5px dashed transparent;display:grid;place-items:center;color:transparent;
    transition:background .14s,border-color .14s,color .14s,flex-grow var(--m-snap-d,.4s) var(--m-snap,cubic-bezier(.2,.9,.25,1))}
  .pj-dz .h.can{border-color:color-mix(in srgb,var(--blue) 62%,transparent);background:color-mix(in srgb,var(--blue) 6%,transparent);color:color-mix(in srgb,var(--blue) 55%,transparent)}
  .pj-dz .h.on{flex-grow:1.35;border-style:solid;border-color:var(--blue);background:color-mix(in srgb,var(--blue) 22%,transparent);color:var(--blue-t,var(--blue))}
  .pj-dz .h svg{width:30px;height:30px;fill:currentColor}
  .pj-dz .m{flex:2 1 0;min-width:0;display:flex;flex-direction:column;gap:8px}
  .pj-dz .m .h{min-height:0}
  .pj-dz .m .h svg{transform:rotate(90deg)}
  .pj-dz .h:not(.can),.pj-dz .m.off{display:none}
  .pj-dz.nope{background:color-mix(in srgb,var(--bg) 62%,transparent);border-radius:var(--r-card);transition:background .14s}
  .pj-dz .no{margin:auto;max-width:calc(100% - 24px);padding:12px 16px;border-radius:12px;background:var(--btn-hi,var(--card-hi));color:var(--t1);
    box-shadow:var(--menu-shadow,0 8px 24px rgba(0,0,0,.3)),0 0 0 1px var(--line);font-size:15px;font-weight:600;line-height:1.4;text-align:center}
  @media(prefers-reduced-motion:reduce){
    .pj-pane.in{animation:pj-pfade .18s ease-out backwards}
    @keyframes pj-pfade{from{opacity:0}}
    .pj-split.eq>.pj-col,.pj-col.eq>.pj-pane,.pj-dz .h{transition:none}
  }`;
  function ensureCss() {
    if (document.getElementById("pj-split-css")) return;
    const s = document.createElement("style"); s.id = "pj-split-css"; s.textContent = CSS; document.head.appendChild(s);
  }
  api.ensureCss = ensureCss;

  // ---- dividers --------------------------------------------------------------------------------
  // The divider follows the pointer 1:1 between its two neighbours (each keeps MIN, or MINH for
  // two panes stacked in a column: `down`). A double click (or Enter) makes them equal; the arrow
  // keys move it 16px. `save(fractions)` is told the shares of what is drawn, in order.
  api.dividers = function (box, save, down) {
    const kids = down ? ":scope>.pj-pane" : ":scope>.pj-col", min = down ? MINH : MIN;
    const size = (n) => { const r = n.getBoundingClientRect(); return down ? r.height : r.width; };
    const at = (e) => (down ? e.clientY : e.clientX);
    const panes = () => [...box.querySelectorAll(kids)];
    const grow = () => panes().map((p) => parseFloat(p.style.flexGrow) || 1);
    const done = () => { const g = grow(), s = g.reduce((x, y) => x + y, 0) || 1; save(g.map((x) => x / s)); };
    box.querySelectorAll(down ? ":scope>.pj-dh" : ":scope>.pj-dv").forEach((dv) => {
      const pa = dv.previousElementSibling, pb = dv.nextElementSibling;
      // The two neighbours as they stand: their grow shares and what one px is worth in them.
      const now = () => { const g = grow(), i = panes().indexOf(pa), px = size(pa) + size(pb); return {g, i, per: (g[i] + g[i + 1]) / px}; };
      const put = (o, dx) => { const g = drag(o.g, o.i, dx * o.per, min * o.per); pa.style.flexGrow = g[o.i].toFixed(5); pb.style.flexGrow = g[o.i + 1].toFixed(5); };
      let d = null;
      dv.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        e.preventDefault(); box.classList.remove("eq");
        d = Object.assign(now(), {id: e.pointerId, x: at(e)});
        try { dv.setPointerCapture(e.pointerId); } catch (err) { /* a synthetic pointer */ }
        dv.classList.add("on"); document.body.classList.add("gripping");
      });
      dv.addEventListener("pointermove", (e) => { if (d && e.pointerId === d.id) put(d, at(e) - d.x); });
      const up = (e) => { if (!d || e.pointerId !== d.id) return; d = null; dv.classList.remove("on"); document.body.classList.remove("gripping"); done(); };
      dv.addEventListener("pointerup", up); dv.addEventListener("pointercancel", up);
      const even = () => { if (!RM()) { box.classList.add("eq"); setTimeout(() => box.classList.remove("eq"), 700); } panes().forEach((p) => { p.style.flexGrow = "1"; }); done(); };
      dv.addEventListener("dblclick", even);
      dv.addEventListener("keydown", (e) => {
        if (e.key === "Enter") { e.preventDefault(); return even(); }
        const dir = e.key === (down ? "ArrowUp" : "ArrowLeft") ? -1 : e.key === (down ? "ArrowDown" : "ArrowRight") ? 1 : 0; if (!dir) return;
        e.preventDefault(); put(now(), dir * 16); done();
      });
    });
  };

  // ---- drag a row out of the list ----------------------------------------------------------------
  // host: {rows (selector), ok(), pick(row) -> {id, p}, targets() -> [{el, id}],
  //        check(pane, target, side) -> {ok: true} | {hint} | null, drop(pane, target, side),
  //        out: {can(row), drop(row)} a row let go outside the window (the row is captured, so the
  //        pointer is still heard out there)}
  // `side` is "l" | "r" | "t" | "b" of the pane `target`. A side the layout has no room for (a 4th
  // column, a 3rd row) is not drawn and a drop there does nothing; a pane with no side left says why.
  // A press that moves 6px lifts a copy of the row; it rides the pointer 1:1 (a plain click still
  // opens the conversation). Over a conversation its sides show where it would land. Let go
  // anywhere else and the copy springs back to its row with the hand's speed; it can be caught
  // again on the way. Reduced motion: it fades out where it is.
  let d = null, back = null, swallowAt = 0;
  const host = () => api.host;
  const SIDES = ["l", "t", "b", "r"];
  const place = (g, x, y) => { g.style.transform = `translate3d(${x.toFixed(2)}px,${y.toFixed(2)}px,0)`; g._x = x; g._y = y; };
  function zonesUp() {
    zonesDown();
    const h = host(); if (!h || !d.pane) return;      // a row that only changes places: no pane to land in
    d.zones = h.targets().map((t) => {
      const r = t.el.getBoundingClientRect(), z = document.createElement("div");
      const c = {}; let hint = "";
      SIDES.forEach((k) => { c[k] = h.check(d.pane, t.id, k); if (c[k] && c[k].hint && !hint) hint = c[k].hint; });
      const any = SIDES.some((k) => c[k] && c[k].ok), half = (k) => `<div class="h ${k}${c[k] && c[k].ok ? " can" : ""}" data-k="${k}">${api.icon}</div>`;
      z.className = "pj-dz";
      z.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
      // Only the sides it may land on are drawn. None, and there is a reason: the reason instead.
      z.innerHTML = any || !hint ? `${half("l")}<div class="m${(c.t && c.t.ok) || (c.b && c.b.ok) ? "" : " off"}">${half("t")}${half("b")}</div>${half("r")}` : `<div class="no" hidden></div>`;
      if (!any && hint) z.firstChild.textContent = hint;
      document.body.appendChild(z);
      // Where each side is, before the one under the pointer grows.
      const at = any ? [...z.querySelectorAll(".h.can")].map((n) => ({n, k: n.dataset.k, r: n.getBoundingClientRect()})) : [];
      return {z, r, id: t.id, at, hint: any ? "" : hint};
    });
  }
  function zonesDown() { if (d && d.zones) d.zones.forEach((o) => o.z.remove()); document.querySelectorAll(".pj-dz").forEach((z) => z.remove()); if (d) d.zones = null; }
  function hover(x, y) {
    let hit = null;
    (d.zones || []).forEach((o) => {
      const inside = x >= o.r.left && x <= o.r.right && y >= o.r.top && y <= o.r.bottom;
      if (o.hint) { o.z.firstChild.hidden = !inside; o.z.classList.toggle("nope", inside); return; }
      // The side whose box is nearest the pointer (the gaps between them belong to a neighbour).
      let best = null, bd = Infinity;
      if (inside) o.at.forEach((s) => {
        const dx = Math.max(s.r.left - x, 0, x - s.r.right), dy = Math.max(s.r.top - y, 0, y - s.r.bottom), q = dx * dx + dy * dy;
        if (q < bd) { bd = q; best = s; }
      });
      o.at.forEach((s) => s.n.classList.toggle("on", s === best));
      if (best) hit = {id: o.id, side: best.k};
    });
    d.hit = hit;
  }
  // The copy goes, and the box it stood in.
  function gone(g) { if (g._lift) g._lift.jump(1); const w = g.parentNode; g.remove(); if (w && w.classList && w.classList.contains("pj-gbox")) w.remove(); }
  function lift(e) {
    const r = d.row.getBoundingClientRect(), g = d.row.cloneNode(true);
    ensureCss();
    g.classList.remove("on", "vis", "press", "pj-holding", "sp-src"); g.style.removeProperty("scale"); g.classList.add("pj-ghost"); g.removeAttribute("id");
    g.querySelectorAll("[id]").forEach((n) => n.removeAttribute("id"));
    // The row may be pressed in (.press scales it): the copy is its full size, centred on it.
    const w = d.row.offsetWidth || r.width, hh = d.row.offsetHeight || r.height;
    g.style.width = w + "px"; g.style.height = hh + "px";
    // The copy lives on the body, outside the list: the list's own rules (.pj-srows .sr-q, the
    // compact size) only reach a row inside it, so it stands in a box that carries those classes.
    const lst = d.row.closest(".pj-srows"), box = document.createElement("div");
    box.className = "pj-gbox" + (lst ? " " + lst.className : "");
    box.appendChild(g); document.body.appendChild(box);
    // Several picked rows in the hand: the copy is a small stack with their count on it.
    const S0 = host() && host().sort, many = S0 && S0.multi ? S0.multi(d.row) : 0;
    if (many > 1) {
      g.classList.add("pj-multi"); if (many === 2) g.classList.add("pj-n2");
      const c = document.createElement("i"); c.className = "pj-gn"; c.textContent = String(many); g.appendChild(c);
    }
    d.g = g; d.gx = r.left - (w - r.width) / 2; d.gy = r.top - (hh - r.height) / 2; d.on = true;
    const hint = document.createElement("span"); hint.className = "pj-grab-hint"; hint.textContent = tl("drag.grabbed"); g.appendChild(hint);
    d.hint = hint; d.out = !!(host().out && host().out.can(d.row));
    if (!RM() && window.Motion && Motion.phys) {
      g._lift = Motion.phys(.985, 420, 34, (x) => { g.style.scale = String(x); });
      g._lift.set(1.025);
    }
    d.row.classList.add("sp-src"); document.body.classList.add("pj-dragging");
    try { d.row.setPointerCapture(d.id); } catch (err) { /* a synthetic pointer */ }
    zonesUp();
    // host.sort: the same copy also changes the row's place in its list (web/listorder.js).
    const S = host() && host().sort; if (S) d.sort = S.start(d.row);
  }
  function move(e) {
    if (!d || e.pointerId !== d.id) return;
    if (!d.on) { if (Math.hypot(e.clientX - d.x0, e.clientY - d.y0) < 6) return; lift(e); }
    if (!d.moved) { if (d.still && Math.hypot(e.clientX - d.x0, e.clientY - d.y0) < 6) return; d.moved = true; }
    e.preventDefault();
    place(d.g, d.gx + e.clientX - d.x0, d.gy + e.clientY - d.y0);
    const dt = Math.max(1, e.timeStamp - d.pt);
    d.vx = d.vx * 0.6 + ((e.clientX - d.px) / dt * 1000) * 0.4; d.vy = d.vy * 0.6 + ((e.clientY - d.py) / dt * 1000) * 0.4;
    d.px = e.clientX; d.py = e.clientY; d.pt = e.timeStamp;
    hover(e.clientX, e.clientY);
    // Past the window's edge: the copy says what letting go there does.
    const far = d.out && outside(e.clientX, e.clientY, innerWidth, innerHeight);
    if (d.hint && far !== !!d.far) { d.far = far; d.hint.textContent = far ? tl("drag.float") : tl("drag.grabbed"); }
    if (d.sort) host().sort.move(d.sort, e.clientX, e.clientY, d.g._y, d.g.offsetHeight);
  }
  function unhook() { removeEventListener("pointermove", move, true); removeEventListener("pointerup", up, true); removeEventListener("pointercancel", up, true); removeEventListener("keydown", esc, true); }
  function esc(e) { if (e.key === "Escape" && d && d.on) { e.preventDefault(); e.stopPropagation(); up({pointerId: d.id, type: "pointercancel", timeStamp: e.timeStamp}); } }
  function up(e) {
    if (!d || e.pointerId !== d.id) return;
    unhook();
    const q = d; d = null;
    if (!q.on) return;
    swallowAt = Date.now();
    document.body.classList.remove("pj-dragging");
    (q.zones || []).forEach((o) => o.z.remove());
    const h = host(), hit = e.type === "pointerup" ? q.hit : null;
    // Held (a finger) and let go without moving: not a drag. The host answers the hold instead.
    if (q.still && !q.moved) { sortEnd(q, false); swallowAt = 0; goBack(q, 0, 0); if (e.type === "pointerup") q.still(); return; }
    if (e.type === "pointerup" && q.out && h && h.out && outside(e.clientX, e.clientY, innerWidth, innerHeight)) {
      // Let go outside the window: the list stays as it was and the host takes the row from here.
      sortEnd(q, false);
      q.row.classList.remove("sp-src");
      gone(q.g);
      h.out.drop(q.row);
      return;
    }
    if (hit && h) {
      // Landed: the copy lets go where it is while the pane comes in under it.
      sortEnd(q, false);
      q.row.classList.remove("sp-src");
      const a = q.g.animate([{opacity: 1}, {opacity: 0}], {duration: 140, easing: "ease-out", fill: "forwards"});
      a.onfinish = a.oncancel = () => gone(q.g);
      h.drop(q.pane, hit.id, hit.side);
      return;
    }
    const stale = e.type === "pointercancel" || e.timeStamp - q.pt > 90;
    const cl = (v) => Math.max(-2400, Math.min(2400, v));
    // Changing places: the copy settles into the gap the other rows made (its own row when given up).
    const to = q.sort && h && h.sort ? h.sort.drop(q.sort, e.type === "pointerup") : null;
    goBack(q, stale ? 0 : cl(q.vx), stale ? 0 : cl(q.vy), to);
  }
  // The list is put back and told where the row landed (once; `ok` false: nowhere new).
  function sortEnd(q, ok) {
    const S = host() && host().sort, st = q.sort; if (!st || !S) return;
    q.sort = null; if (!ok) S.drop(st, false); S.done(st);
  }
  function goBack(q, vx, vy, to) {
    if (q.g._lift) q.g._lift.set(1);
    const row = q.row.isConnected ? q.row : (host() && host().find && q.pane ? host().find(q.pane) : null);
    const end = () => { gone(q.g); if (q.row) q.row.classList.remove("sp-src"); if (row) row.classList.remove("sp-src"); if (back && back.q === q) back = null; sortEnd(q, true); };
    if (RM() || (!row && !to) || !window.Motion || !Motion.phys) {
      const a = q.g.animate([{opacity: 1}, {opacity: 0}], {duration: 180, easing: "ease-out", fill: "forwards"});
      a.onfinish = a.oncancel = end; return;
    }
    const r = to || row.getBoundingClientRect();
    const draw = () => place(q.g, sx.x, sy.x);
    const sx = Motion.phys(q.g._x, 260, 26, draw, 0.3), sy = Motion.phys(q.g._y, 260, 26, draw, 0.3);
    back = {q, sx, sy};
    q.g.classList.add("back");
    sx.rest = sy.rest = () => { if (!sx.live() && !sy.live() && back && back.q === q) end(); };
    sx.set(r.left, vx); sy.set(r.top, vy);
  }
  function begin(e, row, pane, caught) {
    d = {row, pane, id: e.pointerId, x0: e.clientX, y0: e.clientY, on: false, px: e.clientX, py: e.clientY, pt: e.timeStamp, vx: 0, vy: 0, g: null, zones: null, hit: null};
    if (caught) {                                    // caught on its way back: it carries on from where it is
      const q = caught.q; caught.sx.rest = caught.sy.rest = null; caught.sx.jump(caught.sx.x); caught.sy.jump(caught.sy.x); back = null;
      q.g.classList.remove("back");
      d.g = q.g; d.gx = q.g._x; d.gy = q.g._y; d.on = true; d.row = q.row.isConnected ? q.row : row;
      d.sort = q.sort; q.sort = null; d.moved = true;  // the gap it was heading for stays open under it
      d.row.classList.add("sp-src"); document.body.classList.add("pj-dragging");
      zonesUp();
    }
    addEventListener("pointermove", move, true); addEventListener("pointerup", up, true); addEventListener("pointercancel", up, true); addEventListener("keydown", esc, true);
  }
  document.addEventListener("pointerdown", (e) => {
    const h = host();
    if (d || !h || e.button !== 0 || e.pointerType === "touch") return;
    if (back && back.q.g.contains(e.target)) { e.preventDefault(); return begin(e, back.q.row, back.q.pane, back); }
    // A row goes to a pane (while panes can be opened) and to another place in its list (host.sort).
    const S = h.sort, row = e.target.closest && (e.target.closest(h.rows) || (S && e.target.closest(S.rows)));
    if (!row || e.target.closest("[data-more],[data-sm],.pj-more,input,a")) return;
    const pane = h.ok() && row.matches(h.rows) ? h.pick(row) : null;
    if (!pane && !(S && S.can(row)) && !(h.out && h.out.can(row))) return;
    begin(e, row, pane, null);
  });
  // A finger that held a row still (the host times the hold): the row is in the hand from here.
  // `still` is called if it is let go without having moved.
  api.grab = function (e, row, still) {
    const h = host(); if (d || !h || !h.sort || !h.sort.can(row)) return false;
    begin(e, row, h.ok() && row.matches(h.rows) ? h.pick(row) : null, null);
    d.still = still || null; lift(e); place(d.g, d.gx, d.gy);
    return true;
  };
  // The click that ends a drag is not a press on the row.
  document.addEventListener("click", (e) => { if (Date.now() - swallowAt < 350) { swallowAt = 0; e.stopPropagation(); e.preventDefault(); } }, true);
  addEventListener("hashchange", () => { if (d && d.on) up({pointerId: d.id, type: "pointercancel", timeStamp: 0}); });
  api.dragging = () => !!(d && d.on);
})();
