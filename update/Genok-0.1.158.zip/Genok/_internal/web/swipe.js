// A phone's sideways gestures on the chat screens (web/project.js says what they act on, as
// PjSwipe.host): a session row is pulled left to show its buttons or right to hide it from the
// list, and the open chat is pulled from the screen's left edge to show the list under it (from
// the right edge to bring it back). What is pulled follows the finger 1:1, is let go with the
// finger's speed into a spring, and can be caught again while it moves. The arithmetic is at the
// top, pure and tested in tests/swipe.test.js.
(function () {
  "use strict";

  const SLOP = 10;              // px the finger travels before the gesture takes a direction
  const PERIOD = 0.32;          // s, the app's "snap" response (critically damped)
  const BTN = 56, GAP = 6, PAD = 8;   // px: a button of the tray, the space between two, the tray's own edge
  const trayW = (n) => n ? 2 * PAD + n * BTN + (n - 1) * GAP : 0;   // px a row opens to for `n` buttons
  const TRAY = trayW(2);
  const OVER = 56;              // px a row gives past its stop
  const EDGE = 24;              // px from the screen edge a pull of the chat starts in

  // Which way a gesture goes once it has moved `slop`: "" not yet, "y" a scroll, "x" a swipe.
  // A scroll wins unless the travel is clearly sideways.
  function lock(dx, dy, slop) {
    const ax = Math.abs(dx), ay = Math.abs(dy);
    if (Math.max(ax, ay) < (slop == null ? SLOP : slop)) return "";
    return ax > ay * 1.2 ? "x" : "y";
  }

  // The give past a stop: `d` px of finger become less and less, never more than `limit`.
  function rubber(d, limit) {
    return d <= 0 ? 0 : limit * (1 - 1 / (d * 0.55 / limit + 1));
  }

  // Where the row stands for `d` px of finger travel (left is negative). 1:1 between its stops:
  // `tray` px to the left, the row's `width` to the right when it may be thrown out (`full`).
  function rowAt(d, o) {
    const lo = -o.tray, hi = o.full ? o.width : 0;
    if (d < lo) return lo - rubber(lo - d, OVER);
    if (d > hi) return hi + rubber(d - hi, OVER);
    return d;
  }

  // Finger speed in px/s from the last samples [{x, t(ms)}]; 0 when the finger had stopped.
  function velocity(pts, now) {
    if (!pts || pts.length < 2) return 0;
    const b = pts[pts.length - 1];
    if (now - b.t > 80) return 0;
    let a = pts[0];
    for (const p of pts) { if (b.t - p.t <= 100) { a = p; break; } }
    return b.t > a.t ? (b.x - a.x) / (b.t - a.t) * 1000 : 0;
  }

  // Where a thing let go at `x` with `v` px/s would come to rest by itself (deceleration .998/ms).
  function rest(x, v) {
    return x + v / 1000 * 0.998 / (1 - 0.998);
  }

  // What a row does when let go: {to, fire}. It opens to its buttons, shuts, or (thrown right far
  // enough, `full`) leaves and `fire`s its action. `commit` is how far right counts as meant.
  function rowEnd(x, v, o) {
    const r = rest(x, v), commit = o.commit || Math.min(160, o.width * 0.42);
    if (x > 0 || (x === 0 && v > 0)) {
      if (o.full && (x >= commit || (x > 48 && r >= o.width * 0.7))) return {to: o.width + 24, fire: true};
      return {to: 0, fire: false, deny: !o.full && x >= OVER * 0.45};
    }
    return {to: r < -o.tray / 2 ? -o.tray : 0, fire: false};
  }

  // Where the pulled chat settles: 0 (the chat) or `w` (off the screen: the list).
  function edgeEnd(x, v, w) {
    return rest(x, v) > w / 2 ? w : 0;
  }

  // One step of the spring: [x, v] after `dt` s on the way to `to`.
  function step(x, v, to, dt, period) {
    const w = 2 * Math.PI / (period || PERIOD);
    v += (-w * w * (x - to) - 2 * w * v) * dt;
    return [x + v * dt, v];
  }
  const still = (x, v, to) => Math.abs(x - to) < 0.5 && Math.abs(v) < 20;

  // How far the buttons are out, 0..1.
  const shown = (x, tray) => Math.max(0, Math.min(1, Math.abs(x) / tray));

  const api = {SLOP, TRAY, trayW, OVER, EDGE, PERIOD, lock, rubber, rowAt, velocity, rest, rowEnd, edgeEnd, step, still, shown, host: null};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window === "undefined") return;
  window.PjSwipe = api;

  // ---- in the page ------------------------------------------------------------------------------
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const ROW = ".pj-rail .pj-srow[data-sid]";
  let drag = null;              // the finger that is down: {id, kind, el, sx, sy, axis, base, x0, pts}
  let row = null;               // the row that is out of place: {el, tray, x, v, raf, o, info, sid, st}
  let pane = null;              // the chat being pulled: {el, x, v, raf, w, st, side}
  let guardAt = -1e9, waiting = [];

  function css() {
    if (document.getElementById("pj-sw-css")) return;
    const s = document.createElement("style"); s.id = "pj-sw-css";
    s.textContent = `@media (pointer:coarse) and (max-width:1023px){.pj-rail .pj-srow[data-sid]{touch-action:pan-y}body:has(.pj-cols.pj-listonly){touch-action:pan-y}body.pjchat .pj-conv .pj-msgs{touch-action:pan-y}}
      .sw-on.sw-on{z-index:1;will-change:translate;transition:none}
      .sw-tray{position:absolute;z-index:0;display:flex;align-items:center;gap:${GAP}px;padding:0 ${PAD}px;box-sizing:border-box;border-radius:var(--r-lg,14px);pointer-events:none}
      .sw-tray.r{justify-content:flex-end}
      .sw-tray.open{pointer-events:auto}
      /* A button of the tray: an outline icon over one short word, no tile - the colour says what it
         does (이어서 = accent and brighter than the rest, 끝내기 = caution, the rest a quiet neutral). 56x50 stays the finger's target. */
      .sw-b,.sw-h{flex:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;width:${BTN}px;height:50px;padding:1px 0 0;border-radius:12px;
        background:none;color:color-mix(in srgb,var(--t1) 50%,transparent);font-size:12px;font-weight:500;line-height:14px;letter-spacing:-.01em;white-space:nowrap;transform:scale(var(--sw-s,1));opacity:var(--sw-o,1)}
      .sw-b svg,.sw-h svg{flex:none;width:22px;height:22px}
      .sw-b span,.sw-h span{color:inherit}
      .sw-b.go{color:var(--blue-t,#8f98ff);font-weight:600}
      .sw-b.dz{color:color-mix(in srgb,var(--red,#f04452) 86%,transparent)}
      .sw-b:active{background:color-mix(in srgb,var(--t1) 8%,transparent)}
      .sw-h{color:var(--t2);transition:color .12s}
      .sw-tray.arm .sw-h,.sw-tray.arm .sw-h span{color:var(--t1)}
      .sw-tray.no .sw-h{opacity:calc(var(--sw-o,1) * .45)}
      .sw-tray.fade{background:var(--bg);transition:opacity .16s ease-out}
      body.pjchat.pj-peek .tabbar,body.pjchat.pj-peek:not(.inapp) #top{display:flex}
      body.pjchat.pj-peek .pj-fab{display:inline-flex}
      body.pjchat.pj-peek #m-goo{display:block}
      body.pjchat.pj-peek{overflow:visible}
      body.pjchat.pj-peek .pj-conv{z-index:12}
      body.pjchat.pj-peek .pj-conv{box-shadow:-1px 0 0 var(--line),-16px 0 40px rgba(0,0,0,.28)}
      @media (prefers-reduced-motion:reduce){body.pjchat.pj-peek .pj-conv{box-shadow:none}}`;
    document.head.appendChild(s);
  }

  css();

  // ---- a session row ----------------------------------------------------------------------------
  function rowMake(el) {
    const H = api.host, sid = el.dataset.sid, info = H && H.row ? H.row(sid) : null;
    if (!info) return null;
    css();
    const par = el.parentNode, tray = document.createElement("div");
    if (getComputedStyle(par).position === "static") par.style.position = "relative";
    tray.className = "sw-tray";
    tray.style.cssText = `left:${el.offsetLeft}px;top:${el.offsetTop}px;width:${el.offsetWidth}px;height:${el.offsetHeight}px`;
    par.insertBefore(tray, el);
    el.classList.add("sw-on");
    const o = {tray: trayW(info.left.length), width: el.offsetWidth, full: !!(info.right && !info.right.off)};
    const r = {el, tray, x: 0, v: 0, raf: 0, o, info, sid, st: "drag", side: ""};
    tray.onclick = (e) => {
      const b = e.target.closest("[data-swa]"); if (!b) return;
      e.stopPropagation();
      rowGo(r, 0, 0, () => rowDrop(r));
      api.host.act(b.dataset.swa, sid);
    };
    return r;
  }
  // What the tray shows for the side the row is pulled to: its buttons (pulled left) or the mark
  // of what a throw to the right does.
  function rowSide(r, side) {
    if (r.side === side) return;
    r.side = side;
    const t = r.tray, I = r.info;
    t.className = "sw-tray " + (side === "l" ? "r" : "l") + (RM() ? " fade" : "") + (side === "r" && I.right && I.right.off ? " no" : "");
    t.innerHTML = side === "l" ? I.left.map((b) => `<button type="button" class="sw-b${b.dz ? " dz" : b.go ? " go" : ""}" data-swa="${b.a}" aria-label="${b.label}" title="${b.label}" tabindex="-1">${b.icon}<span aria-hidden="true">${b.text || ""}</span></button>`).join("")
      : I.right ? `<span class="sw-h" role="img" aria-label="${I.right.label}">${I.right.icon}<span aria-hidden="true">${I.right.text || ""}</span></span>` : "";
  }
  function rowSet(r, x) {
    r.x = x;
    const rm = RM(), ax = Math.abs(x), t = r.tray;
    if (ax < 0.5) { r.el.style.translate = ""; t.style.clipPath = "inset(0 100% 0 0)"; t.classList.remove("open", "arm"); return; }
    rowSide(r, x < 0 ? "l" : "r");
    const p = x < 0 ? shown(x, r.o.tray || 1) : Math.min(1, x / 64);
    t.style.setProperty("--sw-s", rm ? "1" : (0.6 + 0.4 * p).toFixed(3));
    t.style.setProperty("--sw-o", rm ? "1" : p.toFixed(3));
    t.classList.toggle("arm", x > 0 && r.o.full && x >= Math.min(160, r.o.width * 0.42));
    if (rm) {
      // Nothing slides: the buttons come up over the row's end where it stands.
      r.el.style.translate = "";
      const w = x < 0 ? r.o.tray : 60;
      t.style.clipPath = x < 0 ? `inset(0 0 0 calc(100% - ${w}px) round var(--r-lg,14px))` : `inset(0 calc(100% - ${w}px) 0 0 round var(--r-lg,14px))`;
      t.style.opacity = p.toFixed(3); t.style.zIndex = "2";
      r.el.style.opacity = x > 0 && r.st === "fire" ? "0" : "";
      return;
    }
    r.el.style.translate = `${x.toFixed(1)}px 0`;
    const gap = Math.max(0, ax - 6);
    t.style.clipPath = x < 0 ? `inset(0 0 0 calc(100% - ${gap.toFixed(1)}px))` : `inset(0 calc(100% - ${gap.toFixed(1)}px) 0 0)`;
  }
  function rowDrop(r) {
    cancelAnimationFrame(r.raf);
    r.el.style.translate = ""; r.el.style.opacity = ""; r.el.classList.remove("sw-on");
    r.tray.remove();
    if (row === r) row = null;
    flush();
  }
  // Let go: the spring carries it to `to` from the finger's speed. Reduced motion: it is there
  // at once and the buttons fade.
  function rowGo(r, v, to, done) {
    cancelAnimationFrame(r.raf);
    r.st = r.st === "fire" ? "fire" : "anim";
    const end = () => { r.v = 0; rowSet(r, to); r.st = to ? (r.st === "fire" ? "fire" : "open") : "shut"; r.tray.classList.toggle("open", r.st === "open"); if (done) done(); else if (!to) rowDrop(r); };
    if (RM()) { rowSet(r, to); r.raf = requestAnimationFrame(() => setTimeout(end, to ? 0 : 170)); if (!to) r.tray.style.opacity = "0"; return; }
    let x = r.x, last = performance.now();
    const tick = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      [x, v] = step(x, v, to, dt); r.v = v;
      if (still(x, v, to)) return end();
      rowSet(r, x); r.raf = requestAnimationFrame(tick);
    };
    r.raf = requestAnimationFrame(tick);
  }
  const rowShut = () => { if (row && row.st !== "fire") rowGo(row, 0, 0); };

  // ---- the chat, pulled from the edge -----------------------------------------------------------
  function paneSet(p, x) {
    p.x = x;
    const el = p.el;
    if (RM()) { el.style.transform = ""; el.style.opacity = (1 - Math.max(0, Math.min(1, x / p.w))).toFixed(3); el.style.pointerEvents = x > p.w / 2 ? "none" : ""; return; }
    el.style.transform = `translate3d(${Math.max(0, x).toFixed(1)}px,0,0)`;
  }
  function paneClear(el) { el.style.transform = ""; el.style.opacity = ""; el.style.pointerEvents = ""; el.style.transition = ""; }
  function paneGo(p, v, to) {
    cancelAnimationFrame(p.raf); clearTimeout(p.tm);
    p.st = "anim";
    const end = () => { const q = p; if (pane === p) pane = null; q.st = "done"; paneSet(q, to); api.host.edge.end(to > 0 ? "list" : "chat", q.el); flush(); };
    if (RM()) { p.el.style.transition = "opacity .16s ease-out"; paneSet(p, to); p.tm = setTimeout(end, 170); return; }
    let x = p.x, last = performance.now();
    const tick = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      [x, v] = step(x, v, to, dt); p.v = v;
      if (still(x, v, to)) return end();
      paneSet(p, x); p.raf = requestAnimationFrame(tick);
    };
    p.raf = requestAnimationFrame(tick);
  }

  // The list is not drawn again under a finger or a row that is out of place: it waits.
  api.live = () => !!((drag && drag.axis === "x") || row || (pane && pane.st !== "done"));
  api.later = (fn) => { if (!waiting.includes(fn)) waiting.push(fn); };
  api.clear = paneClear;
  function flush() { if (api.live()) return; const L = waiting; waiting = []; L.forEach((f) => { try { f(); } catch (e) { /* the page it belonged to is gone */ } }); }

  const on = () => { const H = api.host; return !!(H && H.ok && H.ok()); };

  addEventListener("pointerdown", (e) => {
    if (drag || !e.isPrimary || (e.pointerType === "mouse" && e.button !== 0) || !on()) return;
    const t = e.target;
    if (t.closest && t.closest(".sw-tray")) return;
    const H = api.host;
    // A chat on its way is caught where it is.
    if (pane && pane.st === "anim") {
      cancelAnimationFrame(pane.raf); clearTimeout(pane.tm); pane.el.style.transition = ""; pane.st = "drag";
      drag = {id: e.pointerId, kind: "edge", sx: e.clientX, sy: e.clientY, axis: "x", base: e.clientX - pane.x, pts: []};
      return;
    }
    const side = e.clientX <= EDGE ? "l" : e.clientX >= innerWidth - 16 ? "r" : "";
    if (side && H.edge && H.edge.can(side)) {
      if (row) rowShut();
      drag = {id: e.pointerId, kind: "edge", side, sx: e.clientX, sy: e.clientY, axis: "", pts: []};
      return;
    }
    const el = t.closest ? t.closest(ROW) : null;
    if (row && row.el !== el && row.st !== "fire") rowShut();
    if (!el || el.closest(".pj-rail.picking") || (row && row.el !== el)) return;
    if (row && row.st === "fire") return;
    drag = {id: e.pointerId, kind: "row", el, sx: e.clientX, sy: e.clientY, axis: "", pts: []};
    if (row && row.st === "anim") { cancelAnimationFrame(row.raf); row.st = "drag"; drag.axis = "x"; drag.base = e.clientX - row.x; guardAt = performance.now(); }
  }, {capture: true, passive: true});

  addEventListener("pointermove", (e) => {
    const d = drag; if (!d || e.pointerId !== d.id) return;
    if (window.PjSplit && PjSplit.dragging()) { drag = null; if (d.kind === "row") rowShut(); return; }   // a row is being carried
    if (!d.axis) {
      const a = lock(e.clientX - d.sx, e.clientY - d.sy);
      if (!a) return;
      if (a === "y") { drag = null; if (d.kind === "row") rowShut(); return; }
      if (d.kind === "edge") {
        if ((d.side === "l") !== (e.clientX > d.sx)) { drag = null; return; }       // pulled the wrong way
        const el = api.host.edge.begin(d.side); if (!el) { drag = null; return; }
        css();
        pane = {el, x: d.side === "l" ? 0 : innerWidth, v: 0, raf: 0, w: innerWidth, st: "drag", side: d.side};
        paneSet(pane, pane.x);
        d.base = e.clientX - pane.x;
      } else {
        if (!row) { row = rowMake(d.el); if (!row) { drag = null; return; } }
        row.st = "drag";
        d.x0 = row.x; d.base = e.clientX;
      }
      d.axis = "x";
      try { (d.kind === "edge" ? pane.el : d.el).setPointerCapture(d.id); } catch (err) { /* the finger is already up */ }
    }
    if (d.kind === "edge") {
      const x = Math.max(0, Math.min(pane.w, e.clientX - d.base));
      paneSet(pane, x); d.pts.push({x, t: e.timeStamp});
    } else {
      // Caught on its way: it carries on from where it is, by the finger's own travel.
      const raw = d.x0 != null ? d.x0 + (e.clientX - d.base) : e.clientX - d.base;
      rowSet(row, d.x0 != null && d.x0 < 0 && raw < 0 && raw >= -row.o.tray ? raw : rowAt(raw, row.o));
      d.pts.push({x: raw, t: e.timeStamp});
    }
    if (d.pts.length > 8) d.pts.shift();
  }, {capture: true, passive: true});

  const up = (e) => {
    const d = drag; if (!d || e.pointerId !== d.id) return;
    drag = null;
    if (d.axis !== "x") { flush(); return; }
    guardAt = performance.now();
    const v = e.type === "pointerup" ? velocity(d.pts, e.timeStamp) : 0;
    if (d.kind === "edge") { paneGo(pane, v, e.type === "pointerup" ? edgeEnd(pane.x, v, pane.w) : pane.side === "l" ? 0 : pane.w); return; }
    const r = row, end = e.type === "pointerup" ? rowEnd(r.x, v, r.o) : {to: r.x < -r.o.tray / 2 ? -r.o.tray : 0};
    if (end.deny) api.host.act(r.info.right.a, r.sid);              // says why it cannot be hidden
    if (!end.fire) return rowGo(r, v, end.to);
    r.st = "fire";
    rowGo(r, v, end.to, () => Promise.resolve(api.host.act(r.info.right.a, r.sid)).catch(() => {}).then(() => rowDrop(r)));
  };
  addEventListener("pointerup", up, {capture: true, passive: true});
  addEventListener("pointercancel", up, {capture: true, passive: true});

  // The press that ends a swipe opens nothing; a press on a row that stands open shuts it.
  addEventListener("click", (e) => {
    const t = e.target;
    if (!t.closest || t.closest(".sw-tray")) return;
    const el = t.closest(ROW);
    if (el && performance.now() - guardAt < 350) { e.preventDefault(); e.stopPropagation(); return; }
    if (row && row.st === "open") { if (el === row.el) { e.preventDefault(); e.stopPropagation(); } rowShut(); }
  }, true);
  addEventListener("scroll", () => { if (row && row.st === "open") rowShut(); }, {capture: true, passive: true});
  addEventListener("hashchange", () => { if (row) rowDrop(row); });
})();
