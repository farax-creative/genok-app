// Extension hooks: window.LOOP_TABS (a whole extra screen) and window.LOOP_HOME_CARDS (a
// card on the home dashboard). A user extension or a built-in feature module pushes entries;
// v2.js reads them back through loopTabs()/loopHomeCards() to route and render. The pure
// normalisers live here so the contract is testable without a DOM (see tests/tabs.test.js).
//
//   window.LOOP_TABS.push({id, label, icon, draw(el)})       -> sidebar + phone tab, hash-routed
//   window.LOOP_HOME_CARDS.push({id, title, draw(el)})       -> a card under the home stat grid
//
// Rules: an entry needs a non-empty string id and a draw() function, or it is dropped; the
// first entry wins if two share an id, and an id that already names a built-in screen (passed
// in `taken`) is refused, so an extension can never shadow home/lib/inbox/settings.
// A {key, render} entry is accepted as an alias of {id, draw} (key -> id, render -> draw).
(function () {
  "use strict";

  function normTabs(list, taken) {
    const seen = new Set(taken || []);
    const out = [];
    for (const t of Array.isArray(list) ? list : []) {
      if (!t) continue;
      const id = typeof t.id === "string" && t.id ? t.id
        : (typeof t.key === "string" && t.key ? t.key : "");
      const draw = typeof t.draw === "function" ? t.draw
        : (typeof t.render === "function" ? t.render : null);
      if (!id || !draw) continue;
      if (seen.has(id)) continue;
      seen.add(id);
      const tab = {
        id: id,
        label: typeof t.label === "string" && t.label ? t.label : id,
        icon: typeof t.icon === "string" && t.icon ? t.icon : "tool",
        draw: draw,
      };
      // Optional: the screen keeps its page up and updates it in place (v2.js asks before clearing).
      if (typeof t.keeps === "function") tab.keeps = t.keeps;
      out.push(tab);
    }
    return out;
  }

  function normCards(list) {
    const out = [], seen = new Set();
    for (const c of Array.isArray(list) ? list : []) {
      if (!c || typeof c.id !== "string" || !c.id || typeof c.draw !== "function") continue;
      if (seen.has(c.id)) continue;
      seen.add(c.id);
      out.push({id: c.id, title: typeof c.title === "string" ? c.title : "", draw: c.draw});
    }
    return out;
  }

  // window.LOOP_ITEM_VIEW: a block drawn inside the item screen. Each entry is a draw
  // function(box, item, detail). Non-functions are dropped and the same function is kept once
  // (first wins), so a bad or duplicated entry can neither run nor shadow the core item view.
  function normItemView(list) {
    const out = [], seen = new Set();
    for (const f of Array.isArray(list) ? list : []) {
      if (typeof f !== "function" || seen.has(f)) continue;
      seen.add(f);
      out.push(f);
    }
    return out;
  }

  // window.LOOP_SETTINGS: a settings page. Two shapes, both giving each page its own menu entry:
  //   - {page, icon, title, draw}                        the object form, and
  //   - Object.assign(draw, {page, title, icon})         a draw function carrying its own page.
  // A bare function with no page keeps the old contract and is returned in `misc`, to be collected
  // onto one 기타 page. `taken` names core-owned page keys an extension must not shadow; the first
  // entry wins on a duplicated page key.
  function normSettings(list, taken) {
    const seen = new Set(taken || []);
    const pages = [], misc = [];
    for (const f of Array.isArray(list) ? list : []) {
      const isObj = f && typeof f === "object" && typeof f.draw === "function";
      const isPageFn = typeof f === "function" && !!f.page;
      if (isObj || isPageFn) {
        const page = typeof f.page === "string" ? f.page : "";
        if (page && seen.has(page)) continue;              // first wins / never shadow a core page
        if (page) seen.add(page);
        pages.push({page, icon: typeof f.icon === "string" ? f.icon : "",
          title: typeof f.title === "string" ? f.title : "", draw: isObj ? f.draw : f});
      } else if (typeof f === "function") {
        misc.push(f);
      }
    }
    return {pages, misc};
  }

  const api = {normTabs, normCards, normItemView, normSettings};

  if (typeof window !== "undefined") {
    window.LOOP_TABS = window.LOOP_TABS || [];
    window.LOOP_HOME_CARDS = window.LOOP_HOME_CARDS || [];
    // The built-in screen keys an extension tab must never take (kept on window so v2.js sets it).
    window.loopTabs = () => normTabs(window.LOOP_TABS, window.LOOP_CORE_SCREENS || []);
    window.loopHomeCards = () => normCards(window.LOOP_HOME_CARDS);
    window.loopItemView = () => normItemView(window.LOOP_ITEM_VIEW);
    // general·misc·update·about are drawn by the app itself, so an extension can never take them.
    window.loopSettings = () => normSettings(window.LOOP_SETTINGS, ["general", "misc", "update", "about"]);
  }

  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
