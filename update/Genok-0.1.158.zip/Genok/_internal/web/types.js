// Typed viewers for Genok: code, unified diffs, documents and spreadsheets, shown at the
// same quality as the image/video stage. It hooks the item screen through window.LOOP_ITEM_VIEW
// (no core dispatch edits) and fills the .media area for a version whose lead file is one of these
// kinds. The pure math (line/word/sheet diff, highlight, CSV parse, patch parse) lives in vdiff.js
// so it can be tested; this file is the DOM and the interaction.
//
// Comments anchor to a place in the file: a line (src/app.py:42), a cell (B7) or a quoted
// selection. The anchor is handed to v2.js through window.LOOP_ANCHOR as plain text, so it rides
// in the comment's leading [...] tag exactly like an image pin does, and reaches the session
// through the same directive/feedback pipeline with the anchor in the text.
(function () {
  "use strict";
  var CODE = new Set([".py", ".pyw", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx", ".json", ".c",
    ".h", ".cpp", ".cc", ".hpp", ".cs", ".java", ".kt", ".swift", ".go", ".rs", ".rb", ".php",
    ".css", ".scss", ".less", ".sh", ".bash", ".zsh", ".sql", ".yaml", ".yml", ".toml", ".ini",
    ".xml", ".log"]);
  var DOC = new Set([".md", ".markdown", ".txt", ".rst", ".pdf"]);
  var SHEET = new Set([".csv", ".tsv", ".xlsx"]);
  var TEXTED = new Set([".csv", ".tsv"]);        // sheets we parse in the browser (xlsx goes to the server)
  var MAX_LINES = 6000;                          // cap the DOM for a very large file

  function extOf(name) { return "." + String(name || "").split(".").pop().toLowerCase(); }
  // Which typed viewer a file wants, or null when it is not ours (image/video/html/binary).
  function classify(f) {
    var ext = extOf(f.name), k = f.kind;
    if (k === "diff" || ext === ".diff" || ext === ".patch") return "diff";
    if (k === "sheet" || SHEET.has(ext)) return "sheet";
    if (k === "doc" || DOC.has(ext)) return "doc";
    if (k === "code" || CODE.has(ext)) return "code";
    if (k === "text") return SHEET.has(ext) ? "sheet" : DOC.has(ext) ? "doc" : "code";   // old data
    return null;
  }

  // --- per-item view state (kept across re-renders) ---
  var fileIdx = {};     // item@v -> which typed file is shown
  var cmpOn = {};       // item@v -> compare on?
  var cmpFrom = {};     // item@v -> the older version compared against
  var layout = {};      // item@v -> "side" | "unified" for code diffs
  var sheetSel = {};    // item@v@name -> chosen xlsx sheet index
  var anchor = null;    // {id, text} — the pending comment anchor for the item on screen
  var cache = {};       // url -> Promise<text>

  window.LOOP_ANCHOR = function (it) { return anchor && anchor.id === it.id ? anchor.text : ""; };

  function fetchText(url) {
    if (!cache[url]) cache[url] = fetch(url).then(function (r) { if (!r.ok) throw new Error(String(r.status)); return r.text(); });
    return cache[url];
  }
  function fetchXlsx(p, i, v, name, sheet) {
    var u = "/api/xlsx?p=" + encodeURIComponent(p) + "&i=" + encodeURIComponent(i) + "&v=" +
      encodeURIComponent(v) + "&name=" + encodeURIComponent(name) + (sheet != null ? "&sheet=" + encodeURIComponent(sheet) : "");
    return fetch(u).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || "err"); return j; }); });
  }

  var TK = {kw: "tk-kw", str: "tk-str", com: "tk-com", num: "tk-num", txt: ""};
  function hlHtml(tokens) {
    return tokens.map(function (t) { return t.t === "txt" ? esc(t.v) : '<span class="' + TK[t.t] + '">' + esc(t.v) + "</span>"; }).join("");
  }
  function olderVers(d, curV) { return (d.versions || []).filter(function (w) { return w.v < curV; }).reverse(); }
  function fileIn(ver, name) { return (ver.files || []).find(function (f) { return f.name === name; }); }

  // Move to the comment box and focus it, so a picked anchor leads straight into writing. The
  // tabs and textarea are document-unique (v2.js uses the same selectors), so this is not scoped
  // to a container: the comment box sits beside .media, not inside it.
  function toComment() {
    if (typeof cmShow === "function") cmShow();
    var t = document.getElementById("cm");
    if (t) { t.focus(); t.scrollIntoView({block: "nearest", behavior: RM_() ? "auto" : "smooth"}); }
  }
  function RM_() { try { return matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; } }
  // `host` is any element inside .media; the anchor chip is found from it.
  function setAnchor(it, host, text) {
    anchor = {id: it.id, text: text};
    var media = host.closest(".media") || host, chip = media.querySelector(".tv-anchor");
    if (chip) { chip.hidden = false; chip.querySelector(".tv-anchor-t").textContent = text; }
    toComment();
  }
  function clearAnchor(box) { anchor = null; var chip = box.querySelector(".tv-anchor"); if (chip) chip.hidden = true; }

  // ---- the hook: fill .media for a typed version ----
  function draw(box, it, d) {
    anchor = null;                                 // a fresh item render starts with no pending anchor
    var media = box.querySelector(".media"); if (!media) return;
    var ver = (d.versions || []).find(function (w) { return w.v === it.v; }); if (!ver) return;
    var typed = (ver.files || []).filter(classify); if (!typed.length) return;
    var key = it.id + "@" + it.v;
    var idx = Math.min(fileIdx[key] || 0, typed.length - 1);
    var f = typed[idx], kind = classify(f);
    media.classList.add("tv-host");

    var older = olderVers(d, it.v);
    var canCmp = older.length > 0 && kind !== "diff";
    // Default the compare-from to the nearest older version that has a file of the same name,
    // else the newest older one. Only meaningful when there IS an older version.
    var from = null;
    if (older.length) {
      from = cmpFrom[key];
      if (!older.some(function (w) { return w.v === from; })) from = null;
      if (!from) { var m = older.find(function (w) { return fileIn(w, f.name); }); from = (m || older[0]).v; }
    }
    var on = canCmp && !!cmpOn[key];

    var head = '<div class="tv-head">' +
      (typed.length > 1 ? '<div class="tv-files">' + typed.map(function (g, n) {
        return '<button class="tv-file' + (n === idx ? " on" : "") + '" data-tf="' + n + '">' + esc(g.name) + "</button>"; }).join("") + "</div>"
        : '<span class="tv-name">' + esc(f.name) + "</span>") +
      '<span class="tv-grow"></span>' +
      (canCmp ? '<div class="seg tv-mode"><button data-tm="view" class="' + (on ? "" : "on") + '">' + tl("types.1") + '</button>' +
        '<button data-tm="cmp" class="' + (on ? "on" : "") + '">' + tl("types.2") + "</button></div>" : "") +
      "</div>";

    var subhead = "";
    if (on) {
      subhead = '<div class="tv-sub">' +
        '<span class="tv-from">' + tl("types.3") + " " +
        '<gk-select class="tv-fromv" aria-label="' + esc(tl("types.3")) + '">' + older.map(function (w) {
          return '<option value="' + esc(w.v) + '"' + (w.v === from ? " selected" : "") + ">" + esc(w.v) + "</option>"; }).join("") + "</gk-select>" +
        " → <b>" + esc(it.v) + "</b></span>" +
        (kind === "code" ? '<span class="tv-grow"></span><div class="seg tv-lay"><button data-tl="side" class="' +
          (lay(key) === "unified" ? "" : "on") + '">' + tl("types.4") + '</button><button data-tl="unified" class="' +
          (lay(key) === "unified" ? "on" : "") + '">' + tl("types.5") + "</button></div>" : "") +
        "</div>";
    } else if (kind === "sheet" && extOf(f.name) === ".xlsx") {
      subhead = '<div class="tv-sub tv-sheetpick" hidden></div>';   // filled after the workbook loads
    }

    var anchTip = kind === "sheet" ? tl("types.6") : kind === "doc" ? tl("types.7") : tl("types.8");
    media.innerHTML = head + subhead +
      '<div class="tv-anchor" hidden><span class="tv-anchor-l">' + tl("types.9") + '</span><span class="tv-anchor-t"></span>' +
      '<button class="tv-anchor-x" aria-label="' + tl("types.10") + '">' + ic("x") + "</button></div>" +
      '<div class="tv-hint fun">' + anchTip + "</div>" +
      '<div class="tv-body" id="tvbody"><div class="tv-load">' + loadingHtml(tl("types.11")) + "</div></div>";

    // header wiring
    media.querySelectorAll("[data-tf]").forEach(function (b) { b.onclick = function () { fileIdx[key] = +b.dataset.tf; draw(box, it, d); }; });
    media.querySelectorAll("[data-tm]").forEach(function (b) { b.onclick = function () { cmpOn[key] = b.dataset.tm === "cmp"; draw(box, it, d); }; });
    media.querySelectorAll("[data-tl]").forEach(function (b) { b.onclick = function () { layout[key] = b.dataset.tl; draw(box, it, d); }; });
    var sel = media.querySelector(".tv-fromv"); if (sel) sel.onchange = function () { cmpFrom[key] = sel.value; draw(box, it, d); };
    var x = media.querySelector(".tv-anchor-x"); if (x) x.onclick = function () { clearAnchor(media); };

    var body = media.querySelector("#tvbody");
    var live = function () { return media.isConnected && media.querySelector("#tvbody") === body; };
    var fromVer = older.find(function (w) { return w.v === from; });
    var oldF = fromVer && fileIn(fromVer, f.name);

    if (kind === "code") on ? renderCodeDiff(body, live, it, from, oldF, f, key) : renderCode(body, live, it, f, box);
    else if (kind === "diff") renderPatch(body, live, it, f, box);
    else if (kind === "doc") on ? renderDocDiff(body, live, it, from, oldF, f) : renderDoc(body, live, it, f, box);
    else if (kind === "sheet") on ? renderSheetDiff(body, live, it, from, oldF, f, key) : renderSheet(body, live, it, f, box, media, key);
  }
  function lay(key) { return layout[key] || "side"; }

  // ---- code (single version): line numbers + syntax highlight; click a line to anchor ----
  function renderCode(body, live, it, f, box) {
    fetchText(f.url).then(function (text) {
      if (!live()) return;
      var lang = langOf(f.name), lines = highlight(text, lang), cut = lines.length > MAX_LINES;
      if (cut) lines = lines.slice(0, MAX_LINES);
      var html = '<div class="tv-code">' + lines.map(function (toks, n) {
        return '<div class="tv-row" data-ln="' + (n + 1) + '"><button class="tv-ln" data-ln="' + (n + 1) + '" title="' + tl("types.8") + '">' + (n + 1) +
          '</button><code class="tv-src">' + (hlHtml(toks) || "&nbsp;") + "</code></div>"; }).join("") + "</div>" +
        (cut ? '<div class="tv-cut fun">' + tl("types.12", {n: MAX_LINES}) + "</div>" : "");
      body.innerHTML = html;
      body.querySelectorAll(".tv-ln").forEach(function (ln) { ln.onclick = function () {
        body.querySelectorAll(".tv-row.sel").forEach(function (r) { r.classList.remove("sel"); });
        ln.closest(".tv-row").classList.add("sel");
        setAnchor(it, box, f.name + ":" + ln.dataset.ln); }; });
    }).catch(function () { if (live()) body.innerHTML = '<div class="tv-err">' + tl("types.13") + "</div>"; });
  }

  // ---- code compare: line diff, side-by-side or unified ----
  function renderCodeDiff(body, live, it, from, oldF, f, key) {
    if (!oldF) { body.innerHTML = '<div class="tv-err">' + tl("types.14") + "</div>"; return; }
    Promise.all([fetchText(oldF.url), fetchText(f.url)]).then(function (r) {
      if (!live()) return;
      var lang = langOf(f.name), rows = lineDiff(r[0], r[1]), st = diffStat(rows);
      var stat = '<div class="tv-stat"><span class="tv-add-n">+' + st.add + '</span> <span class="tv-del-n">-' + st.del + "</span></div>";
      var src = function (t) { return hlHtml((highlight(t, lang)[0]) || []); };
      var html;
      if (lay(key) === "unified") {
        html = '<div class="tv-code tv-uni">' + rows.map(function (rw) {
          var sign = rw.type === "add" ? "+" : rw.type === "del" ? "-" : " ";
          return '<div class="tv-row d-' + rw.type + '"><span class="tv-ln">' + (rw.a || "") + '</span><span class="tv-ln">' + (rw.b || "") +
            '</span><code class="tv-src"><span class="tv-sign">' + sign + "</span>" + (src(rw.text) || "&nbsp;") + "</code></div>"; }).join("") + "</div>";
      } else {
        var sbs = sideBySide(rows);
        html = '<div class="tv-code tv-sxs">' + sbs.map(function (l) {
          var lc = l.left ? '<span class="tv-ln">' + (l.left.no || "") + '</span><code class="tv-src">' + (src(l.left.text) || "&nbsp;") + "</code>" : '<span class="tv-ln"></span><code class="tv-src tv-empty"></code>';
          var rc = l.right ? '<span class="tv-ln">' + (l.right.no || "") + '</span><code class="tv-src">' + (src(l.right.text) || "&nbsp;") + "</code>" : '<span class="tv-ln"></span><code class="tv-src tv-empty"></code>';
          return '<div class="tv-drow t-' + l.type + '"><div class="tv-half l">' + lc + '</div><div class="tv-half r">' + rc + "</div></div>"; }).join("") + "</div>";
      }
      body.innerHTML = stat + html + (st.add || st.del ? "" : '<div class="tv-cut fun">' + tl("types.15") + "</div>");
    }).catch(function () { if (live()) body.innerHTML = '<div class="tv-err">' + tl("types.13") + "</div>"; });
  }

  // ---- a pushed .diff/.patch: paint the unified diff by line ----
  function renderPatch(body, live, it, f, box) {
    fetchText(f.url).then(function (text) {
      if (!live()) return;
      var rows = parsePatch(text);
      body.innerHTML = '<div class="tv-code tv-uni">' + rows.map(function (rw) {
        return '<div class="tv-row d-' + rw.type + '" data-ln="' + (rw.b || "") + '"><button class="tv-ln" data-ln="' + (rw.b || rw.a || "") + '">' +
          (rw.a || "") + '</button><button class="tv-ln" data-ln="' + (rw.b || rw.a || "") + '">' + (rw.b || "") +
          '</button><code class="tv-src">' + esc(rw.type === "hunk" || rw.type === "meta" ? rw.text : (rw.type === "add" ? "+" : rw.type === "del" ? "-" : " ") + rw.text) + "</code></div>"; }).join("") + "</div>";
      body.querySelectorAll(".tv-ln[data-ln]").forEach(function (ln) { if (!ln.dataset.ln) return; ln.onclick = function () {
        body.querySelectorAll(".tv-row.sel").forEach(function (r) { r.classList.remove("sel"); });
        ln.closest(".tv-row").classList.add("sel");
        setAnchor(it, box, f.name + ":" + ln.dataset.ln); }; });
    }).catch(function () { if (live()) body.innerHTML = '<div class="tv-err">' + tl("types.13") + "</div>"; });
  }

  // ---- document (single version): markdown / text / pdf; anchor to a selection ----
  function renderDoc(body, live, it, f, box) {
    var ext = extOf(f.name);
    if (ext === ".pdf") { body.innerHTML = '<iframe class="tv-pdf" src="' + esc(f.url) + '" title="' + esc(f.name) + '"></iframe>'; return; }
    fetchText(f.url).then(function (text) {
      if (!live()) return;
      if (ext === ".md" || ext === ".markdown") { body.innerHTML = '<div class="tv-doc"></div>'; body.querySelector(".tv-doc").appendChild(renderMarkdown(text)); }
      else { var pre = document.createElement("pre"); pre.className = "tv-doc tv-plain"; pre.textContent = text; body.innerHTML = '<div class="tv-doc-w"></div>'; body.querySelector(".tv-doc-w").appendChild(pre); }
      wireSelect(body, it, box);
    }).catch(function () { if (live()) body.innerHTML = '<div class="tv-err">' + tl("types.13") + "</div>"; });
  }

  // A selection inside the document becomes a quoted anchor. A floating button appears by the
  // selection; pressing it quotes the text (trimmed) and jumps to the comment box.
  function wireSelect(body, it, box) {
    var btn = document.createElement("button");
    btn.className = "tv-selbtn press"; btn.hidden = true; btn.textContent = tl("types.7");
    body.appendChild(btn);
    var show = function () {
      var s = window.getSelection(); if (!s || s.isCollapsed || !s.rangeCount) { btn.hidden = true; return; }
      var r = s.getRangeAt(0); if (!body.contains(r.commonAncestorContainer)) { btn.hidden = true; return; }
      var rect = r.getBoundingClientRect(), br = body.getBoundingClientRect();
      btn.style.top = (rect.bottom - br.top + body.scrollTop + 6) + "px";
      btn.style.left = Math.max(4, rect.left - br.left) + "px"; btn.hidden = false;
    };
    body.addEventListener("mouseup", function () { setTimeout(show, 0); });
    body.addEventListener("keyup", function () { setTimeout(show, 0); });
    btn.onclick = function () {
      var q = (window.getSelection().toString() || "").replace(/\s+/g, " ").trim();
      if (!q) { toast(tl("types.16")); return; }
      if (q.length > 40) q = q.slice(0, 40) + "…";
      btn.hidden = true; setAnchor(it, box, '"' + q + '"');
    };
  }

  // ---- document compare: word-level diff on the raw text ----
  function renderDocDiff(body, live, it, from, oldF, f) {
    var ext = extOf(f.name);
    if (ext === ".pdf" || !oldF) { body.innerHTML = '<div class="tv-err">' + (ext === ".pdf" ? tl("types.17") : tl("types.14")) + "</div>"; return; }
    Promise.all([fetchText(oldF.url), fetchText(f.url)]).then(function (r) {
      if (!live()) return;
      var runs = wordDiff(r[0], r[1]);
      var same = runs.every(function (x) { return x.type === "same"; });
      body.innerHTML = '<div class="tv-doc tv-wdiff">' + runs.map(function (x) {
        return x.type === "same" ? esc(x.text) : '<span class="w-' + x.type + '">' + esc(x.text) + "</span>"; }).join("") + "</div>" +
        (same ? '<div class="tv-cut fun">' + tl("types.15") + "</div>" : "");
    }).catch(function () { if (live()) body.innerHTML = '<div class="tv-err">' + tl("types.13") + "</div>"; });
  }

  // ---- spreadsheet (single version): A1 grid with sticky header/gutter; click a cell to anchor ----
  function loadRows(it, ver, f, sheetIndex) {
    if (extOf(f.name) === ".xlsx") return fetchXlsx(it.p, it.i, ver, f.name, sheetIndex).then(function (j) { return j; });
    return fetchText(f.url).then(function (t) { return {rows: parseDSV(t, extOf(f.name) === ".tsv" ? "\t" : ","), names: null}; });
  }
  function renderSheet(body, live, it, f, box, media, key) {
    var skey = key + "@" + f.name, si = sheetSel[skey] || 0;
    loadRows(it, it.v, f, extOf(f.name) === ".xlsx" ? si : null).then(function (data) {
      if (!live()) return;
      // xlsx sheet picker
      var pick = media.querySelector(".tv-sheetpick");
      if (pick && data.names && data.names.length > 1) {
        pick.hidden = false;
        pick.innerHTML = tl("types.18") + ' <gk-select class="tv-sheetv" aria-label="' + esc(tl("types.18")) + '">' + data.names.map(function (nm, n) {
          return '<option value="' + n + '"' + (n === si ? " selected" : "") + ">" + esc(nm) + "</option>"; }).join("") + "</gk-select>";
        pick.querySelector(".tv-sheetv").onchange = function (e) { sheetSel[skey] = +e.target.value; draw(box, it, JSON_D(box)); };
      }
      body.innerHTML = sheetTable(data.rows);
      body.querySelectorAll(".tv-c[data-ref]").forEach(function (c) { c.onclick = function () {
        body.querySelectorAll(".tv-c.sel").forEach(function (o) { o.classList.remove("sel"); });
        c.classList.add("sel"); setAnchor(it, box, c.dataset.ref); }; });
    }).catch(function (e) { if (live()) body.innerHTML = '<div class="tv-err">' + esc((e && e.message) || tl("types.13")) + "</div>"; });
  }
  // draw() needs the raw /api/item payload again for the sheet-picker re-render; stash it on the box.
  function JSON_D(box) { return box.__tvD; }

  function sheetTable(rows) {
    var cols = rows.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
    var head = '<tr><th class="tv-corner"></th>' + range(cols).map(function (c) { return "<th>" + colName(c) + "</th>"; }).join("") + "</tr>";
    var body = rows.map(function (r, ri) {
      return '<tr><th class="tv-rownum">' + (ri + 1) + "</th>" + range(cols).map(function (c) {
        return '<td class="tv-c" data-ref="' + cellRef(ri, c) + '">' + esc(r[c] == null ? "" : r[c]) + "</td>"; }).join("") + "</tr>"; }).join("");
    return '<div class="tv-sheet-w"><table class="tv-sheet"><thead>' + head + "</thead><tbody>" + body + "</tbody></table></div>";
  }

  // ---- spreadsheet compare: cell-by-cell, changed/added/removed highlighted ----
  function renderSheetDiff(body, live, it, from, oldF, f, key) {
    if (!oldF) { body.innerHTML = '<div class="tv-err">' + tl("types.14") + "</div>"; return; }
    var xlsx = extOf(f.name) === ".xlsx", skey = key + "@" + f.name, si = sheetSel[skey] || 0;
    Promise.all([loadRows(it, from, oldF, xlsx ? si : null), loadRows(it, it.v, f, xlsx ? si : null)]).then(function (r) {
      if (!live()) return;
      var dd = sheetDiff(r[0].rows, r[1].rows), cols = dd.cols;
      var head = '<tr><th class="tv-corner"></th>' + range(cols).map(function (c) { return "<th>" + colName(c) + "</th>"; }).join("") + "</tr>";
      var rowsHtml = dd.rows.map(function (row, ri) {
        return '<tr class="rs-' + row.status + '"><th class="tv-rownum">' + (ri + 1) + "</th>" + row.cells.map(function (c) {
          var show = c.status === "removed" ? c.a : c.b;
          return '<td class="tv-c cs-' + c.status + '" data-ref="' + c.ref + '" title="' +
            (c.status === "changed" ? esc(c.a) + " → " + esc(c.b) : "") + '">' + esc(show == null ? "" : show) + "</td>"; }).join("") + "</tr>"; }).join("");
      var stat = '<div class="tv-stat">' + tl("types.19", {n: dd.changed}) +
        (dd.addedRows || dd.removedRows ? " · " + tl("types.20", {a: dd.addedRows, d: dd.removedRows}) : "") + "</div>";
      body.innerHTML = stat + '<div class="tv-sheet-w"><table class="tv-sheet tv-sheetd"><thead>' + head + "</thead><tbody>" + rowsHtml + "</tbody></table></div>" +
        (dd.changed || dd.addedRows || dd.removedRows ? "" : '<div class="tv-cut fun">' + tl("types.15") + "</div>");
      body.querySelectorAll(".tv-c[data-ref]").forEach(function (c) { c.onclick = function () {
        body.querySelectorAll(".tv-c.sel").forEach(function (o) { o.classList.remove("sel"); });
        c.classList.add("sel"); setAnchor(it, body.closest(".media"), c.dataset.ref); }; });
    }).catch(function (e) { if (live()) body.innerHTML = '<div class="tv-err">' + esc((e && e.message) || tl("types.13")) + "</div>"; });
  }

  function range(n) { var a = []; for (var i = 0; i < n; i++) a.push(i); return a; }

  // Register the hook. Stash the payload on the box so a sheet-picker re-render can reuse it.
  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(function (box, it, d) {
    box.__tvD = d;
    try { draw(box, it, d); } catch (e) { console.error(e); }
  });

  // Styles: a dark, quiet reading surface (design §3.3), refern-like. Injected once.
  var css = document.createElement("style");
  css.textContent = [
    ".tv-host{display:flex;flex-direction:column;overflow:hidden;background:#161616;color:#e6e6e6}",
    ".tv-head,.tv-sub{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid #2a2a2a;font-size:13px;flex-wrap:wrap}",
    ".tv-grow{flex:1}",
    ".tv-name{font-weight:600;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}",
    ".tv-files{display:flex;gap:4px;flex-wrap:wrap}",
    ".tv-file{padding:4px 8px;border-radius:8px;border:1px solid #333;background:#1e1e1e;color:#bbb;font-family:ui-monospace,monospace;font-size:12px;cursor:pointer}",
    ".tv-file.on{background:#2d2d2d;color:#fff;border-color:#444}",
    ".tv-host .seg{display:inline-flex;border:1px solid #333;border-radius:8px;overflow:hidden}",
    ".tv-host .seg button{padding:4px 12px;background:#1e1e1e;color:#bbb;border:0;cursor:pointer;font-size:12px}",
    ".tv-host .seg button.on{background:#3a6df0;color:#fff}",
    ".tv-fromv,.tv-sheetv{height:28px;gap:6px;padding:0 8px 0 12px;font-size:12px}",
    // A finger gets 8px more above and below the compact field (as the compare bar's pickers do).
    "@media (max-width:719px){.tv-fromv,.tv-sheetv{position:relative}.tv-fromv::after,.tv-sheetv::after{content:'';position:absolute;inset:-8px 0}}",
    ".tv-anchor{display:flex;align-items:center;gap:8px;padding:8px 12px;background:#20304d;color:#dce6ff;font-size:13px;border-bottom:1px solid #2a2a2a}",
    ".tv-anchor-t{font-family:ui-monospace,monospace;font-weight:600}",
    ".tv-anchor-x{margin-left:auto;background:none;border:0;color:#9fb4e0;cursor:pointer;display:inline-flex}",
    ".tv-anchor-x svg{width:16px;height:16px}",
    ".tv-hint{padding:4px 12px;color:#8a8a8a;font-size:12px;border-bottom:1px solid #222}",
    ".tv-body{overflow:auto;max-height:min(72vh,900px);position:relative}",
    ".tv-load,.tv-err,.tv-cut{padding:16px;color:#9a9a9a;font-size:13px}",
    ".tv-err{color:#e6a0a0}",
    ".tv-stat{padding:6px 12px;font-size:12px;font-family:ui-monospace,monospace;border-bottom:1px solid #222}",
    ".tv-add-n{color:#5fd07a}.tv-del-n{color:#ec6a6a}",
    /* code */
    ".tv-code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;line-height:1.7}",
    ".tv-row{display:flex;white-space:pre}",
    ".tv-ln{flex:0 0 auto;min-width:44px;text-align:right;padding:0 12px;color:#8a8a8a;background:#141414;border:0;font:inherit;cursor:pointer;user-select:none;position:sticky;left:0}",
    ".tv-row:hover .tv-ln{color:#aaa;background:#1c1c1c}",
    ".tv-src{padding:0 12px;white-space:pre;flex:1}",
    ".tv-row.sel{background:#2a2f22;outline:1px solid #4a5a2a}",
    ".tk-kw{color:#c08cf0}.tk-str{color:#8fd08f}.tk-com{color:#6f6f6f;font-style:italic}.tk-num{color:#e0a060}",
    ".tv-uni .d-add{background:#16301c}.tv-uni .d-del{background:#331717}.tv-uni .d-hunk,.tv-uni .d-meta{background:#182430;color:#87a8c8}",
    ".tv-uni .d-add .tv-sign{color:#5fd07a}.tv-uni .d-del .tv-sign{color:#ec6a6a}.tv-sign{display:inline-block;width:12px;color:#666}",
    ".tv-drow{display:flex}.tv-half{display:flex;flex:1;min-width:0;border-right:1px solid #222}.tv-half.r{border-right:0}",
    ".tv-drow.t-chg .l{background:#331717}.tv-drow.t-chg .r{background:#16301c}",
    ".tv-drow.t-del .l{background:#331717}.tv-drow.t-add .r{background:#16301c}",
    ".tv-empty{background:#1a1a1a}",
    ".tv-cut{border-top:1px solid #222}",
    /* document */
    ".tv-doc{padding:20px 24px;max-width:820px;line-height:1.7}",
    ".tv-doc.tv-plain,.tv-doc-w pre{white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;font-size:13px}",
    ".tv-doc-w{padding:20px 24px}",
    ".tv-wdiff{white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;font-size:13px}",
    ".tv-wdiff .w-add{background:#16301c;color:#9ff0b0}.tv-wdiff .w-del{background:#331717;color:#f0a0a0;text-decoration:line-through}",
    ".tv-pdf{width:100%;height:min(75vh,900px);border:0;background:#fff}",
    ".tv-selbtn{position:absolute;z-index:5;background:#3a6df0;color:#fff;border:0;border-radius:8px;padding:4px 12px;font-size:12px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.4)}",
    /* sheet */
    ".tv-sheet-w{overflow:auto;max-width:100%}",
    ".tv-sheet{border-collapse:separate;border-spacing:0;font-size:12px;font-family:ui-monospace,monospace}",
    ".tv-sheet th,.tv-sheet td{border-right:1px solid #262626;border-bottom:1px solid #262626;padding:4px 8px;white-space:nowrap;max-width:320px;overflow:hidden;text-overflow:ellipsis}",
    ".tv-sheet thead th{position:sticky;top:0;background:#242424;color:#cfcfcf;z-index:2;text-align:center;font-weight:600}",
    ".tv-rownum,.tv-corner{position:sticky;left:0;background:#242424;color:#9a9a9a;z-index:1;text-align:center}",
    ".tv-sheet thead .tv-corner{z-index:3}",
    ".tv-c{cursor:pointer}.tv-c:hover{background:#222}.tv-c.sel{outline:2px solid #3a6df0;outline-offset:-2px}",
    ".cs-changed{background:#3a2f12;color:#ffd98a}.cs-added{background:#16301c;color:#9ff0b0}.cs-removed{background:#331717;color:#f0a0a0}",
    ".rs-added .tv-rownum{color:#5fd07a}.rs-removed .tv-rownum{color:#ec6a6a}",
    "@media (max-width:640px){.tv-drow{flex-direction:column}.tv-half{border-right:0;border-bottom:1px solid #222}.tv-doc,.tv-doc-w{padding:16px 16px}}",
    /* a squeezed table column breaks Korean one character per line: words stay whole, the table scrolls in its own box */
    "@media (max-width:720px),(max-width:1023px) and (pointer:coarse),(max-width:1023px) and (pointer:none){.tv-doc .doc-table{overflow-x:auto}.tv-doc td,.tv-doc th{word-break:keep-all}}",
    ".tv-mode button,.tv-lay button,.tv-file{transition:background-color .18s cubic-bezier(.2,.9,.3,1.2),color .18s ease}",
    ".tv-anchor,.tv-selbtn{animation:tvpop .22s cubic-bezier(.2,.9,.3,1.2)}",
    "@keyframes tvpop{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}",
    "@media (prefers-reduced-motion:reduce){.tv-mode button,.tv-lay button,.tv-file{transition:opacity .15s ease}.tv-anchor,.tv-selbtn{animation:tvfade .15s ease}@keyframes tvfade{from{opacity:0}to{opacity:1}}}",
  ].join("\n");
  document.head.appendChild(css);
})();
