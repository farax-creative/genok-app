// Genok web UI, cut from v2.js: 홈 and the screens around it: 소식, 자리 비운 사이, 아침 한 화면, 활동, the info panel, 회고, 즐겨찾기, 순서, 고정, 보관.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- 받은함 · 소식: what happened that asks nothing of me ----------
// When 소식 was last opened (the old 알림 marker, same server field): lines after it are unread.
let alertsSeen = ""; try { alertsSeen = localStorage.getItem("v2-alerts-seen") || ""; } catch {}
function seeAlerts(at, tell = true) {
  alertsSeen = at; try { localStorage.setItem("v2-alerts-seen", at); } catch {}
  // The marker lives on the server too (prefs.alerts_seen): read on the phone, read on the PC.
  if (tell && at) post("/api/alerts-seen", {at}).catch(() => {});
}
const after = (at, t) => !t || (at && new Date(at) > new Date(t));
const NEWS_H = 72;                         // hours of 소식 kept in view
const recent = (at, h = NEWS_H) => at && Date.now() - new Date(at) < h * 36e5;
// Read-only: pushes that are not waiting on me (already handled, or put aside), departments
// that took or read a request, sessions that finished or stopped with their last line.
// Whatever needs me is on 할 것 instead, so the two lists never hold the same thing.
function newsList() {
  const todo = new Set(myTurn().map(iid));
  return [
    ...D.items.filter((x) => recent(x.at) && !todo.has(iid(x))).map((x) => ({c:"blue", i:"lib", t:tl("newsList.1", {p0: gname(x), jo: jo(x.v, "를", "을")}), s:`${x.title} · ${stName(x)}`, at:x.at, item:iid(x)})),
    ...D.board.filter((b) => b.state === "delivered" && recent(b.asked)).map((b) => ({c:"grey", i:"check", t:tl("newsList.2", {jo: jo(pname(b.dept), "가", "이")}), s:b.title, at:b.asked, item:iid(b)})),
    // Past "delivered": the session said it read every line, so the fix is under way.
    ...D.board.filter((b) => b.state === "ack" && recent(b.asked)).map((b) => ({c:"green", i:"check", t:tl("newsList.3", {jo: jo(pname(b.dept), "가", "이")}), s:b.title, at:b.asked, item:iid(b)})),
  ].sort((a, b) => (b.at || "").localeCompare(a.at || ""));
}
// A row read on its own (prefs.news_read on the server, so the phone and the PC agree); the
// marker still reads everything before it.
let newsRead = new Set(); try { newsRead = new Set(JSON.parse(localStorage.getItem("v2-news-read") || "[]")); } catch {}
const newsKey = (a) => `${a.item || a.talk || a.t}|${a.at}`;
const newsNew = (a) => after(a.at, alertsSeen) && !newsRead.has(newsKey(a));
function readNews(keys, tell = true) {
  keys.forEach((k) => newsRead.add(k)); try { localStorage.setItem("v2-news-read", JSON.stringify([...newsRead].slice(-400))); } catch {}
  if (tell) post("/api/alerts-seen", {read: keys}).catch(() => {});
}
const newsUnread = () => newsList().filter(newsNew).length;

// ---------- 자리 비운 사이: what happened while I was away, by rules from stored data ----------
// The last moment the app was on screen is kept in this browser and on the server (prefs.seen_at),
// so a look on the phone counts for the PC too. Back after two hours: one line per department.
// Until 다 봤어요 the "since" stays pending, and a bar on home and 받은함 leads back to it.
const AWAY_MS = 2 * 36e5;
const lsGet = (k) => { try { return localStorage.getItem(k) || ""; } catch { return ""; } };
const lsSet = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch {} };
const later = (a, b) => !a ? b : !b ? a : new Date(a) > new Date(b) ? a : b;
let catchSince = lsGet("v2-catch"), awayFrom = "", catchData = null, herePost = 0;
// Heartbeat: this browser every call, the server at most every five minutes (or when forced).
function hereNow(force) {
  if (FLOAT) return;
  const at = new Date().toISOString(); lsSet("v2-seen-at", at);
  if (!force && Date.now() - herePost < 3e5) return; herePost = Date.now();
  fetch("/api/seen-at", {method: "POST", keepalive: true, headers: {"Content-Type": "application/json"}, body: JSON.stringify({at})}).catch(() => {});
}
const catchGet = (since) => get("/api/catchup?since=" + encodeURIComponent(since)).then((d) => (catchData = {...d, since}), () => null);
async function awayCheck(last) {
  if (brief || !last || Date.now() - new Date(last) < AWAY_MS) return;
  awayFrom = last;
  // An older unseen stretch still counts: the sheet covers both.
  if (!catchSince || new Date(last) < new Date(catchSince)) { catchSince = last; lsSet("v2-catch", last); }
  const d = await catchGet(catchSince); if (!d) return;
  if (!d.depts.length) return catchDone(true);
  catchRedraw();
  const busy = document.getElementById("sheet").classList.contains("on") || document.activeElement?.matches?.("input,textarea,gk-select") || document.querySelector(".vw,.stk");
  if (!busy) catchOpen();
}
function catchDone(quiet) {
  catchSince = ""; catchData = null; lsSet("v2-catch", ""); hereNow(true);
  if (!quiet) catchRedraw();
}
const catchRedraw = () => { if (!detail && cur === "inbox") SCREENS.inbox(inTab); };
const awayTxt = (t) => { const h = (Date.now() - new Date(t)) / 36e5; return h < 1 ? tl("awayTxt.1") : h < 24 ? tl("awayTxt.2", {p0: Math.round(h)}) : tl("awayTxt.3", {p0: Math.round(h / 24)}); };
const vShort = (v) => { const n = parseInt(String(v).replace(/\D/g, ""), 10); return isNaN(n) ? v : "v" + n; };
const SESS_T = LT(() => ({finished: tl("SESS_T.1"), stopped: tl("SESS_T.2"), blocked: tl("SESS_T.3"), stuck: tl("SESS_T.4")}));
function catchLine(r) {
  const vs = r.versions || [], hot = r.session === "blocked" || r.session === "stuck" || r.asked;
  const bits = [vs.length ? tl("catchLine.2", {p0: vs.slice(-3).map((x) => vShort(x.v)).join("·"), p1: vs.length > 3 ? tl("catchLine.1", {p0: vs.length - 3}) : ""}) : "",
    r.session ? SESS_T[r.session] : "", r.asked ? tl("catchLine.3", {asked: r.asked}) : "", r.claimed ? tl("catchLine.4", {claimed: r.claimed}) : "", r.lint ? tl("catchLine.5", {lint: r.lint}) : ""].filter(Boolean);
  // A session line opens that department's conversation on the project page.
  const go = (hot || !r.item) && r.talk ? roomGo(r.dept, r.talk) : r.item ? "item/" + r.item : "inbox";
  const sub = r.said || [...new Set(vs.map((x) => x.title))].slice(0, 2).join(" · ");
  return `<button class="row press" data-cgo="${esc(go)}"><span class="ico sm c-${hot ? "red" : r.session ? "teal" : "blue"}">${ic(r.talk && !vs.length ? "chat" : "lib")}</span>
    <span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}<span class="cbits">${bits.map((b) => `<i>${esc(b)}</i>`).join("")}</span></div>${sub ? `<div class="s">${esc(sub)}</div>` : ""}</span><span class="chev">${ic("chev")}</span></button>`;
}
async function catchOpen() {
  const since = catchSince || awayFrom || new Date(Date.now() - 8 * 36e5).toISOString();
  const d = catchData?.since === since ? catchData : await catchGet(since);
  if (!d) return toast(tl("catchOpen.1"));
  const L = d.depts;
  sheet(`<h2 style="margin:0 0 4px">${tl("catchOpen.5")}</h2><p class="hint" style="margin:0 0 12px">${awayTxt(since)} · ${L.length ? tl("catchOpen.3", {n: L.length, p1: d.more ? tl("catchOpen.2", {more: d.more}) : ""}) : tl("catchOpen.4")}</p>
    <div class="catchl">${L.map(catchLine).join("")}</div>
    <div class="catchf"><button class="btn press" data-cok>${tl("catchOpen.6")}</button></div>`, (box) => {
    box.querySelectorAll("[data-cgo]").forEach((b) => b.onclick = (e) => { e.stopPropagation(); closeSheet(); nav(b.dataset.cgo); });
    box.querySelector("[data-cok]").onclick = (e) => { e.stopPropagation(); closeSheet(); catchDone(); toast(tl("catchOpen.7"), 2200, "confirm"); };
  });
}
// While a stretch is unseen: a slim bar that reopens it, or closes it for good.
function catchBar() {
  if (!catchSince) return "";
  const n = catchData?.since === catchSince ? catchData.depts.length : 0;
  return `<div class="card catchbar"><span class="ico sm c-blue">${ic("clock")}</span><span class="tx"><div class="t">${tl("catchOpen.5")}</div><div class="s">${awayTxt(catchSince)}${n ? tl("catchBar.1", {n}) : ""}</div></span>
    <button class="btn sm press" data-catch>${tl("catchBar.2")}</button><button class="btn sm weak press" data-catchok>${tl("catchOpen.6")}</button></div>`;
}
// ---------- 아침 한 화면: the first look of a day after a quiet night ----------
// digest.py decides it is due (shared by the phone and the PC) and lists what finished since
// the night began; what waits is read here from the lists home counts, so the numbers agree.
// Put away once, it does not come back that day. While it stands, it is home.
const BRIEF_QUIET = 5 * 36e5;
let brief = null, briefAsk = 0, actPost = 0, bWalk = null;
const isoAt = (t) => typeof t === "number" ? (t ? new Date(t < 1e12 ? t * 1e3 : t).toISOString() : "") : t || "";
function briefWait() {
  const room = (sid) => attL("rooms").find((r) => r.key === sid), T = todoSecs(), of = (k) => T.find((s) => s.k === k).L;
  const rows = PERM.map((p) => { const r = room(p.sid);
    return {k: "perm", t: permWho(p), s: tl("home.v.allow"), lead: deptIco(r || {}, "ico sm"), go: r ? roomGo(r.dept, p.sid) : "inbox", at: isoAt(p.at)}; })
    .concat(of("blocked").map((a) => ({k: a.needs === "permission prompt" ? "allow" : "answer", t: pname(a.dept), go: roomGo(a.dept, a.session),
      s: a.needs === "permission prompt" ? tl("home.v.allow") : tl("home.v.answer"), lead: deptIco(room(a.session) || a, "ico sm"), at: (room(a.session) || {}).active || ""})))
    .concat(homeChecks().map((c) => ({k: c.ask ? "ask" : "look", t: c.x.title, go: "item/" + iid(c.x), s: c.ask ? tl("home.v.answer") : esc(pname(gname(c.x))), lead: homeThumb(c.x), at: c.x.at})));
  return window.LOOP_BRIEF ? window.LOOP_BRIEF.order(rows) : rows;
}
// Asked at boot, and again when the app comes back (shown, focused, or first touched) after a
// stretch long enough to be a night; the server keeps the last use across devices.
async function briefCheck(boot) {
  if (FLOAT || document.hidden || brief) return;
  const last = lsGet("v2-act-at");
  if (!boot && last && Date.now() - new Date(last) < BRIEF_QUIET) return;
  if (Date.now() - briefAsk < 3e4) return; briefAsk = Date.now();
  const d = await post("/api/digest/brief", last ? {last} : {}).catch(() => null);
  lsSet("v2-act-at", new Date().toISOString()); actPost = Date.now();
  if (!d?.due) return;
  if (attP) await attP.catch(() => {});
  if (!d.done.length && !briefWait().length) return post("/api/digest/brief/done", {day: d.day}).catch(() => {});
  brief = d;
  catchDone(true);                         // the brief says the same, once
  if (!detail && cur === "home") SCREENS.home();
}
function briefTouch() {
  const last = lsGet("v2-act-at");
  if (last && Date.now() - new Date(last) >= BRIEF_QUIET) return briefCheck();
  lsSet("v2-act-at", new Date().toISOString());
  if (Date.now() - actPost > 3e5) { actPost = Date.now(); post("/api/digest/brief", {act_only: true}).catch(() => {}); }
}
["pointerdown", "keydown"].forEach((t) => addEventListener(t, briefTouch, {capture: true, passive: true}));
addEventListener("focus", () => briefCheck());
function briefDone() {
  if (!brief) return; const day = brief.day; brief = null;
  post("/api/digest/brief/done", {day}).catch(() => {});
}
const briefDoneRow = (r) => `<button class="row press bdone" data-bgo="${esc(r.n && r.item ? "item/" + r.item : r.talk ? roomGo(r.dept, r.talk) : "project/" + encodeURIComponent(r.dept))}">${deptIco(r, "ico sm")}
  <span class="tx"><span class="t">${esc(r.n ? r.title : pname(r.dept))}</span><span class="s">${esc(r.n ? pname(r.dept) + " · " + (r.n > 1 ? tl("brief.n", {n: r.n}) : ago(r.at)) : (r.session === "stopped" ? tl("brief.stopped") : tl("brief.ended")))}</span></span></button>`;
const briefWaitRow = (w) => `<button class="row press" data-bgo="${esc(w.go)}">${w.lead}<span class="tx"><span class="t">${esc(w.t)}</span><span class="s"><b class="pending">${w.s}</b>${w.at ? " · " + ago(w.at) : ""}</span></span></button>`;
function briefScreen() {
  const W = briefWait(), F = brief.done, cap = (L, n) => L.slice(0, L.length > n ? n - 1 : n);
  const Ws = cap(W, 6), Fs = cap(F, W.length ? 3 : 6), more = W.length - Ws.length + F.length - Fs.length;
  V().innerHTML = `<div class="home brief"><h1 class="greet">${tl("brief.title")}</h1>
    <p class="bsub">${esc(awayTxt(brief.since))} · ${tl("brief.sub", {a: F.length, b: W.length})}</p>
    <div class="card blist">${Ws.map(briefWaitRow).join("")}${Fs.map(briefDoneRow).join("")}${more ? `<button class="row press bmore" data-bgo="inbox"><span class="tx"><span class="t">${tl("home.rest", {n: more})}</span></span>${ic("chev", "i go")}</button>` : ""}</div>
    <div class="bacts">${W.length ? `<button class="btn weak press bgo" data-bwalk>${tl("brief.go")}</button>` : ""}<button class="btn press bhome" data-bok>${tl("brief.home")}</button></div></div>`;
  const box = V().querySelector(".brief");
  box.querySelectorAll("[data-bgo]").forEach((b) => b.onclick = () => { briefDone(); nav(b.dataset.bgo); });
  box.querySelector("[data-bwalk]")?.addEventListener("click", () => { bWalk = {L: W.map((w) => w.go), i: 0}; briefDone(); nav(bWalk.L[0]); });
  box.querySelector("[data-bok]").onclick = () => { briefDone(); SCREENS.home(); };
}
// 하나씩 보기: a small pill walks the waits in the brief's order, one press each.
function walkDraw() {
  let el = document.getElementById("bwalk");
  if (!bWalk || (!detail && cur === "home")) { if (el) { el.classList.remove("on"); } if (bWalk && cur === "home" && !detail) bWalk = null; return; }
  if (!el) { el = document.createElement("div"); el.id = "bwalk"; document.body.appendChild(el);
    el.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b || !bWalk) return;
      if (b.dataset.wx !== undefined || bWalk.i >= bWalk.L.length - 1) { bWalk = null; walkDraw(); if (b.dataset.wx === undefined) nav("home"); return; }
      bWalk.i++; nav(bWalk.L[bWalk.i]); }); }
  const last = bWalk.i >= bWalk.L.length - 1;
  el.innerHTML = `<button class="press bwn">${last ? tl("brief.walk.end") : tl("brief.walk", {i: bWalk.i + 1, n: bWalk.L.length})}${last ? "" : ic("chev")}</button><button class="press bwx" data-wx aria-label="${esc(tl("brief.walk.x"))}" title="${esc(tl("brief.walk.x"))}">${ic("x")}</button>`;
  requestAnimationFrame(() => el.classList.add("on"));
}
addEventListener("hashchange", () => setTimeout(walkDraw));
const dueDi = (x) => { const di = dueInfo(x.due); return di ? ` · <b class="opn${di.over ? " over" : ""}">${di.label}</b>` : ""; };
// A meta line as pieces: where it wraps (a phone), no line starts or ends with the dot between them.
const mline = (parts) => `<span class="mlw">${parts.filter(Boolean).map((t) => `<span class="mlp">${t}</span>`).join("")}</span>`;
// lean: a list that already says the project and the unsent comments elsewhere leaves both out.
// Every result is in one project: rows need not name it.
const oneProj = () => new Set(D.items.map(gname)).size === 1;
const itemRow = (x, btn = true, lean = {}) => `<button class="row press" data-item="${esc(iid(x))}">${thumb(x)}<span class="tx"><div class="t">${justIn(x) ? `<em class="jin">${tl("ago.2")}</em>` : ""}${esc(x.title)}</div>
  <div class="s ml">${mline([lean.proj ? "" : deptMark(gname(x)) + esc(pname(gname(x))), esc(x.v), ago(x.at), x.open ? `<b class="opn">${tl("open.1", {n: x.open})}</b>` : "", dueDi(x).slice(3), x.comments && !lean.note?.has(iid(x)) ? noteTag(x).slice(3) : ""])}</div></span>${btn ? (x.new ? `<span class="btn weak">${tl("itemRow.1")}</span>` : `<span class="btn">${tl("itemRow.2")}</span>`) : ""}</button>`;
// Hub rules a push broke (push_review "lint"): an orange tag on the card and the item header;
// tapping it lists them. A span, since it sits inside the card's own button.
const LINTS = {};
const lintTag = (key, lint) => { if (!lint?.length) return ""; LINTS[key] = lint;
  return `<span class="tag lint press" role="button" tabindex="0" data-lint="${esc(key)}" title="${tl("lintTag.1")}">${tl("lintTag.2", {n: lint.length})}</span>`; };
const lintOpen = (e) => { const b = e.target.closest?.("[data-lint]"); if (!b || (e.type === "keydown" && e.key !== "Enter" && e.key !== " ")) return;
  e.preventDefault(); e.stopPropagation();
  sheet(`<h2 style="margin:0 0 4px">${tl("lintTag.1")}</h2><p class="hint" style="margin:0 0 12px">${tl("lintOpen.1")}</p>
    ${(LINTS[b.dataset.lint] || []).map((x) => `<div class="row"><span class="ico sm c-orange">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(x.msg)}</div></span></div>`).join("")}`, () => {}); };
document.addEventListener("click", lintOpen, true);
// The item's status chip opens its one-line reason (a phone has no tooltip).
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-stwhy]"); if (!b) return;
  const l = b.closest(".htitle")?.querySelector(".stwhy"); if (!l) return; l.hidden = !l.hidden; b.setAttribute("aria-expanded", !l.hidden); });
document.addEventListener("keydown", lintOpen, true);
const rs = (t) => { const hr =(t*1000 - Date.now()) / 36e5; return hr < 1 ? tl("rs.1") : hr < 24 ? tl("rs.2", {p0: Math.round(hr)}) : tl("rs.3", {p0: Math.round(hr/24)}); };

const SCREENS = {};
// Extension screens (window.LOOP_TABS, see web/tabs.js). They route by hash exactly like a
// built-in screen: each is registered into SCREENS so the router, the 30s background redraw
// and the rail/tabbar treat it the same. A built-in id is never overwritten.
const extTabs = () => (typeof window.loopTabs === "function" ? window.loopTabs() : []);
// The phone tab bar's share of them: all but the ones that already stand there as a tab (대화)
// and the ones turned off in the menu editor (web/custom.js); search still opens those.
const tabExt = (xt) => xt.filter((t) => !TABS.some(([k]) => k === t.id) && !window.LOOP_MENUHIDE?.ext(t.id));
function syncExtTabs() {
  extTabs().forEach((t) => {
    if (SCREENS[t.id]) return;                 // never shadow a built-in screen
    SCREENS[t.id] = () => {
      const el = V();
      // A screen that keeps its own page up (t.keeps): it brings what is there up to date, on a
      // refresh and on a move inside it alike. Nothing is cleared, so nothing enters a second time.
      if (t.keeps && t.keeps(el)) { el.classList.add("still"); try { return t.draw(el.firstElementChild); } catch (e) { console.error(e); } return; }
      // A refresh keeps what is shown until the extension has its new data (see holdWrites).
      if (softN > 0 && el.firstElementChild) return holdWrites(el, () => t.draw(el), (w) => { const st = viewState(); w(); restoreView(st); });
      el.innerHTML = ""; try { t.draw(el); } catch (e) { console.error(e); }
    };
  });
}
// A project is the name its results were pushed under; its newest push dates it.
const projects = () => { const G = new Map();
  D.items.forEach((x) => { const n = gname(x); if (!G.has(n)) G.set(n, {name: n, icon: x.icon || "", items: []}); G.get(n).items.push(x); });
  return [...G.values()].map((g) => ({...g, at: g.items.map((x) => x.at || "").sort().pop() || "",
    todo: g.items.filter(stMine).length})).sort((a, b) => b.at.localeCompare(a.at)).sort(byPjOrder); };
// The person's own project order (dragged on the project list), kept on this device. Projects not in
// it yet follow, newest first.
const pjOrder = (v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem("v2-pjorder") || "[]"); localStorage.setItem("v2-pjorder", JSON.stringify(v)); } catch { return []; } };
const byPjOrder = (a, b) => { const po = pjOrder(), at = (g) => { const i = po.indexOf(g.name); return i < 0 ? 1e6 : i; }; return at(a) - at(b); };
// Project rows inside box are put in order by dragging (mouse; touch keeps scrolling) or Alt+Up/Down.
// The moved names take the slots they already held in the whole order, so a searched or pinned
// subset moves only among itself and the archived ones stay where they were. The rows ride springs
// (motion.js, C9); custom.js's dragSort stands in when that is missing. redraw repaints the list.
function pjSort(box, sel, redraw) {
  const done = (names) => { const it = names[Symbol.iterator](), at = document.activeElement?.dataset?.dept;
    pjOrder(projects().map((g) => names.includes(g.name) ? it.next().value : g.name)); redraw();
    if (at) [...document.querySelectorAll(sel)].find((r) => r.dataset.dept === at)?.focus(); };
  if (window.Motion?.sort) Motion.sort(box, sel, done, (el) => el.dataset.dept);
  else if (window.LOOP_DRAGSORT) window.LOOP_DRAGSORT(box, sel, "y", done);
}
// ---------- 홈: one line of greeting, what waits to be checked, who is working ----------
// Calm on purpose (picked 2026-10-03). Recent results live on 결과물, activity on 사용량, plan and
// version in the status line and 설정, search in the top bar; home repeats none of them.
const greetKind = () => { const h = new Date().getHours(); return h < 5 ? "night" : h < 12 ? "morning" : h < 18 ? "afternoon" : "evening"; };
// ---------- 홈 > 활동: per-day counts (GET /api/activity), read once a minute at most ----------
const ACT = {val: null, at: 0, req: null};
function getAct() {
  if (ACT.val && Date.now() - ACT.at < 60000) return Promise.resolve(ACT.val);
  return ACT.req = ACT.req || get("/api/activity").then((v) => { ACT.val = v; ACT.at = Date.now(); return v; })
    .catch(() => ACT.val).finally(() => { ACT.req = null; });
}
const actRange = () => ["7", "30"].includes(lsGet("v2-homeact")) ? lsGet("v2-homeact") : "182";
const actNum = (n) => n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + "M" : n >= 1e4 ? Math.round(n / 1e3) + "K" : Number(n || 0).toLocaleString();
const actDate = (ds) => new Date(ds + "T00:00:00").toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {year: "numeric", month: "short", day: "numeric", weekday: "short"});
function drawAct(host, page) {
  const el = host || document.getElementById("homeact"), a = ACT.val; if (!el) return;
  // Nothing recorded yet: no block at all rather than a grid of empty squares.
  if (!a || !a.days || (!a.days.some((d) => d.m + d.r + d.c) && a.claude !== "scanning")) { el.hidden = true; el.innerHTML = ""; return; }
  const on = a.claude === "ok", rg = page ? "182" : actRange(), R = a.ranges[rg] || {};
  // "Active days" out of the days there is any record for (R.span), not out of the whole range.
  const act = R.span ? tl("home.act.of", {a: R.active, n: R.span}) : R.active;
  const stats = on && page
    ? [[tl("home.act.results"), actNum(R.results)], [tl("home.act.checks"), actNum(R.checks)], [tl("home.act.sessions"), actNum(R.sessions)],
       [tl("home.act.msgs"), actNum(R.messages)], [tl("home.act.active"), act], [tl("home.act.peak"), R.peak == null ? "—" : tl("home.act.hour", {h: R.peak})]]
    : on
    ? [[tl("home.act.sessions"), actNum(R.sessions)], [tl("home.act.msgs"), actNum(R.messages)],
       [tl("home.act.tokens"), actNum(R.tokens), tl("home.act.tokens.tip")], [tl("home.act.active"), act],
       [tl("home.act.peak"), R.peak == null ? "—" : tl("home.act.hour", {h: R.peak})], [tl("home.act.results"), actNum(R.results)]]
    : [[tl("home.act.results"), actNum(R.results)], [tl("home.act.checks"), actNum(R.checks)], [tl("home.act.active"), act]];
  // Up to 26 columns of weeks (Monday on top), the last one holding today. The map starts at the
  // week of the first day on record (a.since): the weeks before it are not drawn, since nothing
  // is known about them, and a day before it inside that week is left blank. A day's weight is
  // what was done on it: messages sent + results pushed + results checked (a day known only by
  // its session count still counts as active).
  const by = new Map(a.days.map((d) => [d.d, d])), val = (d) => d ? d.m + d.r + d.c || (d.s ? 1 : 0) : 0;
  const iso = (t) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
  const today = new Date(a.today + "T00:00:00"), start = new Date(today);
  start.setDate(start.getDate() - ((today.getDay() + 6) % 7) - 25 * 7);
  const first = a.since ? new Date(a.since + "T00:00:00") : null, short = !!first && first > start;
  let W = 26;
  if (short) { const mon = new Date(first); mon.setDate(mon.getDate() - ((first.getDay() + 6) % 7));
    W = Math.max(1, Math.round((today - mon) / 6048e5 - ((today.getDay() + 6) % 7) / 7) + 1); start.setTime(mon.getTime()); }
  const old = (i) => i < (W - 16) * 7 ? " old" : "";        // a phone shows the last 16 weeks
  const whole = short ? tl("home.act.since", {d: `${first.getMonth() + 1}/${first.getDate()}`}) : tl("home.act.rall");
  const since = new Date(today); since.setDate(since.getDate() - (+rg - 1));
  const vals = a.days.map(val).filter(Boolean).sort((x, y) => x - y), q = (f) => vals[Math.min(vals.length - 1, Math.floor(vals.length * f))] || 0;
  const cut = [q(.25), q(.5), q(.75)], lvl = (v) => !v ? 0 : v <= cut[0] ? 1 : v <= cut[1] ? 2 : v <= cut[2] ? 3 : 4;
  let cells = "";
  for (let i = 0; i < W * 7; i++) {
    const t = new Date(start); t.setDate(t.getDate() + i);
    const ds = iso(t), d = by.get(ds);
    cells += t > today || (first && t < first) ? `<i class="hc no${old(i)}"></i>`
      : `<i class="hc l${lvl(val(d))}${t < since ? " dim" : ""}${old(i)}" data-d="${ds}"></i>`;
  }
  const src = a.claude === "scanning" ? tl("home.act.src.scan") : !on ? tl("home.act.src.off") : short ? tl("home.act.src.since") : "";   // the usual case needs no line: it is the label's hint
  el.hidden = false;
  el.innerHTML = `<div class="rechead"><div class="hlab" title="${tl("home.act.src.ok")}">${tl("home.act")}</div><span class="sp"></span>
      ${page ? `<span class="hspan">${whole}</span>` : `<div class="seg hseg" role="group" aria-label="${tl("home.act")}">${[["7", tl("home.act.r7")], ["30", tl("home.act.r30")], ["182", whole]].map(([k, n]) => `<button class="press${k === rg ? " on" : ""}" data-actr="${k}" aria-pressed="${k === rg}">${n}</button>`).join("")}</div>`}</div>
    <div class="hact">
      <div class="hstats n${stats.length}">${stats.map(([k, v, tip]) => `<div class="hsv"${tip ? ` title="${esc(tip)}"` : ""}><div class="k">${k}</div><div class="v num">${v}</div></div>`).join("")}</div>
      <div class="hmapw"><div class="hmap" tabindex="0" role="group" aria-label="${tl("home.act.map")}"${W < 26 ? ` style="max-width:${W * 17}px"` : ""}>${cells}</div>
        <div class="hleg"><span class="htip" aria-live="polite"></span><span class="sp"></span>${tl("home.act.less")}<i class="hc l0"></i><i class="hc l1"></i><i class="hc l2"></i><i class="hc l3"></i><i class="hc l4"></i>${tl("home.act.more")}</div></div>
    </div>
    ${src ? `<div class="hsrc">${src}${a.claude === "off" && typeof SCREENS.usage === "function" ? ` <button class="lnk press" data-go="usage">${tl("home.act.enable")}</button>` : ""}</div>` : ""}`;
  el.querySelectorAll("[data-actr]").forEach((b) => b.onclick = () => { lsSet("v2-homeact", b.dataset.actr); drawAct(host, page); el.querySelector(`[data-actr="${b.dataset.actr}"]`)?.focus(); });
  // One day at a time under the pointer or the arrow keys; its date and counts show in the line
  // under the map (no floating box to chase).
  const map = el.querySelector(".hmap"), tip = el.querySelector(".htip"), all = [...map.querySelectorAll(".hc[data-d]")];
  let at = -1;
  const show = (i) => { all[at]?.classList.remove("at"); at = i; const c = all[i]; if (!c) { tip.textContent = ""; return; }
    c.classList.add("at"); const d = by.get(c.dataset.d);
    const parts = d ? [on && (d.m || !d.s ? tl("home.act.tip.m", {n: d.m}) : tl("home.act.tip.s", {n: d.s})), tl("home.act.tip.r", {n: d.r}), tl("home.act.tip.c", {n: d.c})].filter(Boolean).join(" · ") : tl("home.act.tip.none");
    tip.textContent = `${actDate(c.dataset.d)} · ${parts}`; };
  map.onpointermove = (e) => { const i = all.indexOf(e.target); if (i >= 0 && i !== at) show(i); };
  map.onpointerleave = () => { if (document.activeElement !== map) show(-1); };
  map.onfocus = () => { if (at < 0) show(all.length - 1); };
  map.onblur = () => show(-1);
  map.onkeydown = (e) => { const step = {ArrowLeft: -7, ArrowRight: 7, ArrowUp: -1, ArrowDown: 1}[e.key]; if (!step) return;
    e.preventDefault(); const lo = all.findIndex((c) => c.offsetParent !== null); show(Math.max(lo, Math.min(all.length - 1, (at < 0 ? all.length - 1 : at) + step))); };
  if (a.claude === "scanning") setTimeout(() => { if (el.isConnected && (host || (cur === "home" && !detail))) { ACT.at = 0; getAct().then(() => drawAct(host, page)); } }, 4000);
}
// Sessions working right now (attention rooms; empty until reading sessions is allowed), newest first.
const workingRooms = () => attL("rooms").filter((r) => r.job === "working").sort((a, b) => (Date.parse(b.active) || 0) - (Date.parse(a.active) || 0));
const workRows = (W, cap) => W.slice(0, cap).map((r) => `<button class="row press" data-go="${esc(roomGo(r.dept, r.key))}">${deptIco(r, "ico sm")}<span class="tx"><div class="t">${esc(pname(r.dept))}</div><div class="s">${esc(r.said || (r.agent === "codex" ? "Codex" : "Claude"))}</div></span><span class="hwt num">${ago(r.active)}</span></button>`).join("")
  + (W.length > cap ? `<button class="row press todomore" data-go="sessions"><span class="tx"><div class="s">${tl("home.v.more", {n: W.length - cap})}</div></span>${ic("chev", "i go")}</button>` : "");
// 진행 on home: who is at work, as small tiles (a name and how long ago). What each one last said
// is in its chat: a column of those sentences made the page a wall of text.
const workTiles = (W, cap) => W.slice(0, W.length > cap ? cap - 1 : cap).map((r) => `<button class="hwtile press" data-go="${esc(roomGo(r.dept, r.key))}">${deptIco(r, "ico sm")}<span class="tx"><span class="t">${esc(pname(r.dept))}</span><span class="s num">${ago(r.active)}</span></span></button>`).join("")
  + (W.length > cap ? `<button class="hwtile more press" data-go="sessions"><span class="tx"><span class="t">${tl("home.v.more", {n: W.length - cap + 1})}</span></span>${ic("chev", "i go")}</button>` : "");
// What waits to be checked, as results: questions first, then results not looked at yet (the same
// two lists 내 차례 shows).
const homeChecks = () => { const T = todoSecs(), of = (k) => T.find((s) => s.k === k).L;
  return [...of("ask").flatMap((g) => g.items).sort(byAt).map((x) => ({x, ask: 1})), ...of("look").map((x) => ({x}))]; };
// One result on home: a small picture, its title, one quiet line. The first stands alone and a
// little larger (homeLead); the next three are rows in one card. A status is said only where it
// asks for something.
const homeThumb = (x) => `<span class="hth">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.kind === "video" ? `<span class="htp">${ic("play")}</span>` : ""}</span>`;
const homeWhere = (x) => `${esc(pname(gname(x)))} · ${ago(x.at)}`;
// What waits, as tiles of one size (the same shape as the work tiles below): a name and one short
// word under it, nothing else. At most `cap`, the last giving way to "N more" in 알림. The agent
// mark line (badges.js) is left off a result's tile: data-bdg.
const waitTile = (go, lead, t, s) => `<button class="hwtile press" data-tk ${go}>${lead}<span class="tx"><span class="t">${esc(t)}</span><span class="s">${s}</span></span></button>`;
// `one`: every tile is from the same project, so its name under each says nothing - the age does.
const checkTile = (c, one) => waitTile(`data-item="${esc(iid(c.x))}" data-bdg="1"`, homeThumb(c.x), c.x.title, c.ask ? `<b class="pending">${tl("home.v.answer")}</b>` : one ? ago(c.x.at) : esc(pname(gname(c.x))));
// The first result that waits, large: its picture, its name, and the three things one does with it
// (decide, look, put off) without opening it first. A question is answered inside, so it only opens.
const homeHero = (c) => `<div class="hhero"><button class="hhero-pv press" data-item="${esc(iid(c.x))}" aria-label="${esc(c.x.title)}">${homeThumb(c.x)}</button>
  <div class="hhero-tx"><span class="k">${tl("nextCard.3")}</span><span class="t">${esc(c.x.title)}</span><span class="s">${homeWhere(c.x)}</span>
  <div class="hhero-acts">${c.ask ? `<button class="btn fill press" data-item="${esc(iid(c.x))}">${tl("askCard.4")}</button>` : `<button class="btn fill press" data-happ="${esc(iid(c.x))}">${tl("STATUS_T.4")}</button><button class="btn press" data-item="${esc(iid(c.x))}">${tl("search.3")}</button>`}<button class="btn weak press hhero-later" data-later="${esc(iid(c.x))}">${tl("palActs.2")}</button></div></div></div>`;
const waitTiles = (L, cap) => L.slice(0, L.length > cap ? cap - 1 : cap).join("")
  + (L.length > cap ? `<button class="hwtile more press" data-go="inbox"><span class="tx"><span class="t">${tl("home.rest", {n: L.length - cap + 1})}</span></span>${ic("chev", "i go")}</button>` : "");
const homeRow = (c, tk = true) => `<button class="hrow press"${tk ? " data-tk" : ""} data-item="${esc(iid(c.x))}">${homeThumb(c.x)}<span class="tx"><span class="t">${esc(c.x.title)}</span><span class="s">${homeWhere(c.x)}</span></span>${c.ask ? `<span class="hst pending">${tl("home.v.answer")}</span>` : ""}</button>`;
// A session that cannot go on without the person (a permission, a question) comes first: it is
// the shortest thing to clear and an agent sits idle until it is.
const homeNeed = (a) => waitTile(`data-go="${esc(roomGo(a.dept, a.session))}"`, deptIco(attL("rooms").find((r) => r.key === a.session) || a, "ico sm"), pname(a.dept), `<b class="pending">${a.needs === "permission prompt" ? tl("home.v.allow") : tl("home.v.answer")}</b>`);
// 사용량 screen: the 26-week block home used to carry (web/usage.js calls this after it paints).
window.LOOP_ACT_SEC = (root) => {
  if (!root || root.querySelector(".hactsec")) return;
  const el = document.createElement("section"); el.className = "hactsec"; el.hidden = true; root.appendChild(el);
  if (ACT.val) drawAct(el, true);
  getAct().then(() => { if (el.isConnected) drawAct(el, true); });
};
// A row on home that opens a page of 설정 (the empty home's 연결 확인하기).
document.addEventListener("click", (e) => {
  const s = e.target.closest?.("[data-homeset]");
  if (s) { setPage = s.dataset.homeset; setShowPage = true; location.hash = "#settings"; }
});
SCREENS.home = function () {
  if (brief) return briefScreen();
  const name = D.profile_name || "", items = D.items || [];
  // A permission prompt stops the session outright, so it leads; among those, the longest wait first.
  const since = (a) => (attL("rooms").find((r) => r.key === a.session) || {}).active || "";
  const C = window.GQ ? [] : homeChecks(), W = workingRooms(), B = window.GQ ? [] : todoSecs().find((s) => s.k === "blocked").L.slice().sort((x, y) =>
    (y.needs === "permission prompt") - (x.needs === "permission prompt") || (since(x) || "9").localeCompare(since(y) || "9")), n = window.GQ ? GQ.count() : C.length + B.length, num = `<b class="num">${n}</b>`;
  // literal keys (not built by concatenation) so the i18n test sees every key used
  const g = {night: tl("ui.greet.night"), morning: tl("ui.greet.morning"), afternoon: tl("ui.greet.afternoon"), evening: tl("ui.greet.evening")}[greetKind()];
  // The greeting is the count. With nothing pushed yet there is nothing to count: a plain hello.
  const greet = !items.length ? (name ? tl("ui.greet.name", {name: esc(name), g: g}) : g)
    : n ? (name ? tl("home.g.n.name", {name: esc(name), n: num}) : tl("home.g.n", {n: num}))
    : name ? tl("home.g.none.name", {name: esc(name)}) : tl("home.g.none");
  // What waits: up to four tiles, the rest one tap away in 알림.
  // Nothing waits: the three newest results take the place, so the page is never a bare line.
  const rest = B.map(homeNeed).concat(C.slice(1).map((c) => checkTile(c, oneProj())));
  // The board (lab): what to check next beside what else waits, then the newest results beside the counts.
  const lead = C.length ? iid(C[0].x) : "", R = items.slice().sort(byAt).filter((x) => iid(x) !== lead);
  const dCard = (x, cls = "") => `<button class="dcard${cls} press" data-item="${esc(iid(x))}">${homeThumb(x)}<span class="cap"><b>${esc(x.title)}</b><span>${homeWhere(x)}</span></span></button>`;
  const side = rest.length ? waitTiles(rest, 3) : R.slice(C.length ? 0 : 1, C.length ? 3 : 4).map((x) => checkTile({x}, oneProj())).join("");
  const cards = R.slice(side && !rest.length ? (C.length ? 3 : 4) : C.length ? 0 : 1).slice(0, 4);
  const sum = (num, name, go) => `<button class="dsc press" data-go="${go}"><span class="k">${name}</span><b class="num">${num}</b></button>`;
  const stat = `<div class="dsum">${sum(n, tl("home.now.wait"), "inbox")}${sum(C.length, tl("home.now.check"), "inbox")}${sum(B.length, tl("SESS_T.3"), "inbox")}${sum(W.length, tl("st.work"), "project")}</div>`;
  // Lab 3: the kit's dashboard markup itself (kit-d2.css), filled with what waits and the newest results.
  const d2img = (x, cls) => x && x.thumb ? `<img class="${cls}" src="${esc(x.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : "";
  const d2st = (attr, lead, t, s) => `<button class="d2-stacked-item press" ${attr}><span class="d2-stacked-left"><span class="d2-stacked-thumb">${lead}</span><span class="d2-stacked-info"><span class="d2-stacked-title">${esc(t)}</span><span class="d2-stacked-sub">${s}</span></span></span>${ic("chev", "i d2-stacked-arrow")}</button>`;
  const d2res = (x) => d2st(`data-item="${esc(iid(x))}"`, homeThumb(x), x.title, homeWhere(x));
  const H3 = C.length ? C[0] : items.length ? {x: items.slice().sort(byAt)[0]} : null;
  const used3 = new Set(C.map((c) => iid(c.x)).concat(H3 ? [iid(H3.x)] : []));
  const R3 = items.slice().sort(byAt).filter((x) => !used3.has(iid(x)));
  const st3 = B.map((a) => d2st(`data-go="${esc(roomGo(a.dept, a.session))}"`, deptIco(a, "ico sm"), pname(a.dept), (a.needs === "permission prompt" ? tl("home.v.allow") : tl("home.v.answer")) + (since(a) ? " · " + ago(since(a)) : ""))).concat(C.slice(1).map((c) => d2res(c.x)));
  // Fewer than three wait: the sessions at work stand there, each one press from its chat. An old
  // result as filler read like a second "recent" list.
  const held = new Set(B.map((a) => a.dept)), W3 = W.filter((w) => !held.has(w.dept)), nW = Math.max(0, Math.min(3 - st3.length, W3.length));
  W3.slice(0, nW).forEach((w) => st3.push(d2st(`data-go="${esc(roomGo(w.dept, w.key))}"`, deptIco(w, "ico sm"), pname(w.dept), `${tl("st.work")} · ${ago(w.active)}`)));
  const Wb = W3.slice(nW);
  // Still short of three: the newest results, newest first.
  while (st3.length < 3 && R3.length) st3.push(d2res(R3.shift()));
  const board3 = !H3 ? "" : `<div class="d2-row-upper"><section class="d2-hero-card"><div class="d2-hero-glow"></div>
      <div class="d2-hero-top-bar"><div class="d2-hero-badges"><span class="d2-popular-pill">${C.length ? tl("nextCard.3") : tl("ui.recent")}</span></div>${C.length > 1 ? `<div class="d2-carousel-dashes">${C.slice(0, 3).map((c, i) => `<span class="d2-dash${i ? "" : " active"}"></span>`).join("")}</div>` : ""}</div>
      <div class="d2-hero-content"><h2 class="d2-hero-title">${esc(H3.x.title)}</h2><p class="d2-hero-desc">${homeWhere(H3.x)}</p>
        <div class="d2-social-proof">${C.length && !H3.ask ? `<button class="d2-reviews-pill press" data-happ="${esc(iid(H3.x))}">${tl("STATUS_T.4")}</button>` : ""}<button class="d2-reviews-pill d2-ghost press" data-item="${esc(iid(H3.x))}">${H3.ask ? tl("askCard.4") : tl("search.3")}</button></div></div>
      <div class="d2-hero-character-wrap">${d2img(H3.x, "d2-hero-character-img")}</div></section>
      <div class="d2-stacked-list">${st3.slice(0, 3).join("")}</div></div>
    ${(() => { const L = Wb.slice(0, 3), x = L.length ? null : R3[0] || null; if (!L.length && !x) return "";
      // Redesign round (web/glass.css): with no session at work, the newest results stand as picture cards.
      if (RD && !L.length) return `<div class="d2-row-bottom rdbot"><div class="d2-section-head"><h3 class="d2-section-title">${tl("TABS.3")}</h3><button type="button" class="d2-see-more" data-go="lib">${tl("ui.viewall")}</button></div>
      <div class="rdcards">${R3.slice(0, 4).map((y) => window.RdV ? RdV.card(y) : dCard(y)).join("")}</div></div>`;
      const bar = (attr, lead, t, sub, at, more) => `<button class="d2-downloads-bar press" ${attr}><span class="d2-download-glow-wave"></span><span class="d2-download-left"><span class="d2-fifa-icon-box">${lead}</span><span class="d2-fifa-meta"><span class="d2-fifa-title">${esc(t)}</span><span class="d2-fifa-tag">${sub}</span></span></span>
        <span class="d2-download-right"><span class="d2-download-progress-text"><span class="d2-download-time num">${at}</span>${more ? `<span class="d2-download-size">+${more}</span>` : ""}</span><span class="d2-download-actions"><span class="d2-dl-close-btn">${ic("chev")}</span></span></span></button>`;
      return `<div class="d2-row-bottom"><div class="d2-section-head"><h3 class="d2-section-title">${L.length ? tl("st.work") : tl("TABS.3")}</h3><button type="button" class="d2-see-more" data-go="${L.length ? "project" : "lib"}">${tl("ui.viewall")}</button></div>
      <div class="k3bars">${L.length ? L.map((w, i) => bar(`data-go="${esc(roomGo(w.dept, w.key))}"`, deptIco(w, "d2-fifa-ico"), pname(w.dept), tl("st.work"), ago(w.active), i === L.length - 1 ? Wb.length - L.length : 0)).join("")
        : bar(`data-item="${esc(iid(x))}"`, homeThumb(x), x.title, homeWhere(x), ago(x.at), 0)}</div></div>`; })()}`;
  const board = items.length ? `<div class="drow">${C.length ? homeHero(C[0]) : dCard(R[0], " big")}${side ? `<div class="dstack">${side}</div>` : ""}</div>
      ${stat}
      <section class="dnew"><div class="rechead"><h2 class="hsub">${tl("ui.recent")}</h2><span class="sp"></span><button class="lnk press" data-go="lib">${tl("ui.viewall")}</button></div>
        <div class="dcards">${cards.map((x) => dCard(x)).join("")}</div></section>`
    : `<div class="homeempty">${window.genokBeta?.("pai") ? `<p class="het">${tl("ui.home.empty")}</p><p class="hes">${tl("home.empty.src")}</p>` : `<p>${tl("ui.home.empty")}</p>`}<button class="btn sm press" data-homeset="connect">${tl("home.empty.go")}</button></div>`;
  const top = LAB3 ? (items.length ? board3 : board) : n ? `${C.length ? homeHero(C[0]) : ""}${rest.length ? `<div class="hwtiles${rest.length < 3 ? " few" : ""}">${waitTiles(rest, 4)}</div>` : ""}`
    : items.length ? `<div class="rechead"><h2 class="hsub">${tl("ui.recent")}</h2><span class="sp"></span><button class="lnk press" data-go="lib">${tl("ui.viewall")}</button></div>
      <div class="card hlist">${items.slice().sort(byAt).slice(0, 3).map((x) => homeRow({x}, false)).join("")}</div>`
    : `<div class="homeempty">${window.genokBeta?.("pai") ? `<p class="het">${tl("ui.home.empty")}</p><p class="hes">${tl("home.empty.src")}</p>` : `<p>${tl("ui.home.empty")}</p>`}<button class="btn sm press" data-homeset="connect">${tl("home.empty.go")}</button></div>`;
  // A narrow window has no sidebar: the way to the projects is one row here (hidden where the sidebar shows).
  const pj = projects();
  V().innerHTML = `<div class="home${LAB3 && items.length ? " d2-main-area d2home" : ""}">
    ${LAB3 && items.length ? `<header class="d2-header"><h1 class="d2-header-greeting">${greet}</h1><div class="d2-header-center"><button class="d2-search-bar press" data-go="search">${ic("search")}<span class="d2-search-input">${tl("MENUS.5")}</span><kbd>${tl("ui.ctrlk")}</kbd></button></div><div class="d2-header-right"><button type="button" class="d2-head-icon-btn" data-sync title="${esc(tl("ui.tb.refresh"))}" aria-label="${esc(tl("ui.tb.refresh"))}">${ic("sync")}</button><button type="button" class="d2-head-icon-btn" data-bell data-go="inbox" title="${esc(tl("TABS.1"))}" aria-label="${esc(tl("TABS.1"))}">${ic("bell")}${todoCount() ? `<span class="d2-head-dot"></span>` : ""}</button></div></header>` : LAB3 && items.length ? `<div class="dhead"><h1 class="greet">${greet}</h1><button class="dsearch press" data-go="search">${ic("search")}<span>${tl("MENUS.5")}</span><kbd>${tl("ui.ctrlk")}</kbd></button></div>` : `<h1 class="greet">${greet}</h1>`}
    <div id="homerec">${top}</div>
    ${LAB3 && items.length ? "" : W.length ? `<div class="rechead"><h2 class="hsub">${tl("st.work")}<b class="num">${W.length}</b></h2></div><div class="hwtiles${LAB3 ? " dwork" : ""}">${workTiles(W, 4)}</div>` : ""}
    ${LAB3 && items.length ? "" : pj.length ? `<button class="card hrow hpjr press" data-go="depts"><span class="ico sm c-grey">${ic("folders")}</span><span class="tx"><span class="t">${esc(unitWord())}<b class="num">${pj.length}</b></span></span>${ic("chev", "i go")}</button>` : ""}
  </div>`;
  V().querySelector("[data-happ]")?.addEventListener("click", () => approveMany([C[0].x]));
  const pc = (window.GQ ? GQ.home() : permCard()) + (window.LOOP_HOME_FIRST ? window.LOOP_HOME_FIRST() : "") + (window.GQ ? "" : fixCard()), hm = pc && V().querySelector(".home"), hd = hm && hm.querySelector(".d2-header");
  if (hd) hd.insertAdjacentHTML("afterend", pc); else if (hm) hm.insertAdjacentHTML("afterbegin", pc);
  triMark();
  // First-run / empty-state track fills the empty home via this hook.
  if (!items.length && typeof window.LOOP_HOME_EMPTY === "function") {
    // The first-use card (3 steps + the line to paste into a session) comes back as HTML. The
    // hook's "nothing to do" card is not for here.
    try {
      const html = window.LOOP_HOME_EMPTY(document.getElementById("homerec"));
      if (typeof html === "string" && html.includes('class="card oh"')) {
        const rec = document.getElementById("homerec");
        rec.innerHTML = html; V().querySelector(".home").classList.add("first");
      }
    } catch (e) { console.error(e); }
  }
};
// ---------- right info panel (refern's OVERVIEW column), per screen ----------
// ---------- 회고: one week at a glance, paged back a week at a time ----------
const retroLabel = (n) => n === 0 ? tl("day.week") : n === 1 ? tl("retro.last") : tl("retro.ago", {n});
const mdShort = (t) => new Date(t).toLocaleDateString(LANG() === "en" ? "en-US" : "ko-KR", {month: "long", day: "numeric"});
SCREENS.retro = function () {
  const end = Date.now() - retroWk * 7 * 864e5, start = end - 7 * 864e5;
  const inWk = (x) => x.at && new Date(x.at) > start && new Date(x.at) <= end;
  const done = D.items.filter((x) => x.status === "approved" && inWk(x)).sort(byAt);
  const asked = D.items.filter((x) => x.status === "changes" && inWk(x)).sort(byAt);
  const made = D.items.filter(inWk);
  const by = {}; made.forEach((x) => { const k = gname(x); by[k] = (by[k] || 0) + 1; });
  const depts = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 8), top = depts[0]?.[1] || 1;
  const none = `<div class="fun">${tl("retro.none", {wk: retroLabel(retroWk)})}</div>`;
  V().innerHTML = `<div class="wknav"><button class="ib press" data-wk="1" aria-label="${tl("retro.prev")}">${ic("back")}</button>
      <div class="wkl"><b>${retroLabel(retroWk)}</b><span>${mdShort(start + 864e5)} – ${mdShort(end)}</span></div>
      <button class="ib press" data-wk="-1" aria-label="${tl("retro.next")}" ${retroWk === 0 ? `disabled title="${tl("retro.next.none")}"` : ""}>${ic("chev")}</button></div>
    <div class="grid2">
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.ok", {wk: retroLabel(retroWk)})}</div><div class="v num" style="font-size:28px">${done.length}</div><div class="s">${tl("retro.of", {n: made.length})}</div></span></div></div>
      <div class="card"><div class="fig" style="padding:22px"><span class="tx"><div class="s">${tl("retro.changes")}</div><div class="v num" style="font-size:28px">${asked.length}</div><div class="s">${asked.length ? tl("retro.fixing") : tl("retro.clear")}</div></span></div></div></div>
    <div class="card"><div class="ch"><h2>${tl("retro.bydept")}</h2></div><div class="bars">${depts.map(([n, c]) => `<div class="bar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(pname(n))}</span><span class="tr"><i style="width:${c / top * 100}%"></i></span><span class="num">${c}</span></div>`).join("") || none}</div></div>
    <div class="card"><div class="ch"><h2>${tl("retro.done")}</h2><span class="n num">${done.length}</span></div>${done.slice(0, 12).map((x) => itemRow(x, false)).join("") || none}<div style="height:8px"></div></div>
    ${asked.length ? `<div class="card"><div class="ch"><h2>${tl("retro.asked")}</h2><span class="n num">${asked.length}</span></div>${asked.slice(0, 8).map((x) => itemRow(x, false)).join("")}<div style="height:8px"></div></div>` : ""}`;
  V().querySelectorAll("[data-wk]").forEach((b) => b.onclick = () => { retroWk = Math.max(0, retroWk + (+b.dataset.wk)); SCREENS.retro(); scrollTo(0, 0); });
};
const infoPair = (k, v) => `<div class="ipk">${esc(k)}</div><div class="ipv">${v == null || v === "" ? "—" : esc(String(v))}</div>`;
// A clickable overview row: the number is a filter, not a repeat of the home tiles beside it.
const infoLink = (go, k, v) => `<button class="ipl press" data-go="${esc(go)}"><span class="ipk">${esc(k)}</span><span class="ipv num">${esc(String(v))}</span></button>`;
const infoSec = (label, pairs) => `<div class="iplab">${esc(label).toUpperCase()}</div>${pairs}`;
function infoPanel(screen) {
  const el = document.getElementById("info"); if (!el) return;
  const it = D.items || [];
  const open = it.reduce((s, x) => s + (x.open || 0), 0);
  let title = "", sub = "", body = "";
  if (screen === "inbox") {
    title = tl("TABS.1");
    const T = window.GQ && GQ.tiers();   // 지금 필요한 일: the side overview counts the queue's own tiers
    body = infoSec(tl("ui.info.overview"), T ? infoPair(tl("gq.t0"), T[0]) + infoPair(tl("gq.t1"), T[1]) : infoPair(tl("ui.stat.pending"), myTurn().length) + infoPair(tl("ui.stat.open"), open));
    // Lab 3: the column under the overview carries who is working now and the latest news, in the kit's drawer rows.
    if (LAB3) { const W = workingRooms(), N = newsList().slice(0, 5);
      body += (W.length ? infoSec(tl("room.bgBusy"), `<div class="k3side">${workRows(W, 4)}</div>`) : "")
        + (N.length ? infoSec(tl("bellSearch.1"), `<div class="k3side">${N.map((a) => `<button class="drawer-item${newsNew(a) ? " unread" : ""} press" ${a.item ? `data-item="${esc(a.item)}"` : `data-go="inbox/news"`}><span class="drawer-item-dot"></span><span class="tx"><div class="drawer-item-title">${esc(a.t)}</div><div class="drawer-item-desc">${esc(a.s || "")}</div><div class="drawer-item-time">${ago(a.at)}</div></span></button>`).join("")}</div>`) : ""); }
  } else { el.hidden = true; el.innerHTML = ""; return; }
  el.hidden = false;
  setHTML(el, `<div class="iptitle">${esc(title)}</div>${sub ? `<div class="ipsub">${esc(sub)}</div>` : ""}${body}`);
}
// One /api/update read serves drawStatus, drawChrome callers and the first drawUpdate: a request made
// within 10s of the last one shares its answer (the server caches the check anyway). force skips it.
let updReq = null, updReqAt = 0;
function getUpd(force) {
  const go = () => fetch("/api/update" + (force ? "?force=1" : "")).then((r) => r.ok ? r.json() : null).catch(() => null);
  if (force) return go();
  if (updReq && Date.now() - updReqAt < 10000) return updReq;
  updReqAt = Date.now(); return updReq = go();
}
async function drawStatus() {
  const s = document.getElementById("status"); if (!s) return;
  if (D.ver === undefined) { const u = await getUpd(); D.ver = u?.current || ""; }
  // The corner names the plan the way the store does - Lite (free), Pro, Trial - then the version.
  // /api/plan decides (license.js keeps window.LOOP_PLAN and calls this again when it changes).
  // The version is also the everyday way to ask "is there a newer one?": a button beside it runs the
  // same check as 설정 > 지금 버전 and says the answer in a toast (the title-bar pill takes over when
  // a newer build can be installed).
  const h = `<span>${esc(D.ver ? planVer() : "Genok")}</span>${D.ver ? `<button class="stupd press" data-stupd aria-label="${tl("upd.check")}" title="${tl("upd.check")}">${ic("dl")}<span>${tl("upd.check")}</span></button>` : ""}`;
  // On a PC there is no status row: the same line is the button beside 설정 at the foot of the rail.
  document.querySelectorAll(".railver").forEach((x) => { const t = D.ver ? planVer() : ""; if (x.textContent !== t) x.textContent = t; });
  if (s._was === h && s.firstChild) return;            // every refresh round calls this: same line, same nodes
  s.innerHTML = h; s._was = h;
  s.removeAttribute("aria-hidden");
}
addEventListener("click", async (e) => {
  const b = e.target.closest?.("[data-stupd]"); if (!b || b.disabled) return;
  const say = b.querySelector("span");               // the rail's button has no words of its own: it only dims
  b.disabled = true; b.classList.add("busy"); if (say) say.textContent = tl("upd.checking");
  const u = await getUpd(true);
  b.disabled = false; b.classList.remove("busy"); if (say) say.textContent = tl("upd.check");
  if (!u || (!u.found && u.error)) return toastFail(tl("upd.nocheck"), tl("err.ver.meta"), 5000, 4000);
  takeUpd(u);
  if (u.packaged) return toast(tl("upd.store", {cur: u.current}), 4000);
  if (!u.found) return toast(tl("update.5", {cur: u.current}), 3000);
  // A newer build opens the popover under the pill: what's new, then the person presses 업데이트
  // there. Checking never downloads or installs by itself (it used to, when the pill was not drawn yet).
  if (u.can_apply) return requestAnimationFrame(() => updPop(true) || toast(tl("update.4", {cur: u.current, v: u.latest}), 4000));
  toast(u.blocked ? tl("upd.blocked", {cur: u.current, v: u.latest}) : tl("update.4", {cur: u.current, v: u.latest}), 4000);
});
addEventListener("loop:plan", () => drawStatus());
const deptRow = (g) => `<button class="row press" data-dept="${esc(g.name)}">${deptIco(g)}<span class="tx"><div class="t">${esc(pname(g.name))}</div>
  <div class="s">${liveTag(g.name) || (window.HookDot ? HookDot(g.name) : "")}${tl("deptRow.2", {n: g.items.length, p4: g.at ? " · " + ago(g.at) : ""})}</div></span>
  ${g.todo ? `<span class="btn weak">${tl("deptRow.1", {todo: g.todo})}</span>` : ""}${pinBtn(g.name, "inrow")}${archBtn(g.name, "inrow")}</button>`;

// ---------- 즐겨찾기: the menus kept under "자주 쓰는", chosen by the user ----------
// Never set means the defaults; the list lives in the server prefs so phone and PC agree.
// 대화 sits right under 홈 by default. A saved list that is just the old default (saved by a
// star toggled on and off again) counts as never set, so it follows the new default; any other
// saved list is the person's own and is left alone.
// 홈 is always the first one and cannot be taken out (FAV_LOCK). 내 차례 left the menu for the bell,
// and 결과물 came up in its place: a list saved before that (no FAV_V marker in it) gets 결과물 once,
// where 내 차례 stood or at the end. The marker rides in the saved list itself, so a list saved
// since then - with 결과물 taken out on purpose - is left as the person made it.
const FAV_DEF = ["home", "project", "lib", "search"];
const FAV_OLD = [["home", "inbox", "search"], ["home", "project", "inbox", "search"]];
const FAV_LOCK = "home", FAV_V = "~v2";
const favClean = (L) => [...new Set(L.map(menuKey))].filter((k) => MENUS.some((m) => m.k === k));
const favNorm = (saved) => {
  if (!Array.isArray(saved)) return FAV_DEF;
  let L = [...new Set(saved.filter((k) => typeof k === "string").map(menuKey))];
  if (!saved.includes(FAV_V)) {
    if (FAV_OLD.some((o) => o.join() === L.join())) return FAV_DEF;
    if (!L.includes("lib")) L = L.includes("inbox") ? L.map((k) => k === "inbox" ? "lib" : k) : [...L, "lib"];
  }
  return [FAV_LOCK, ...favClean(L).filter((k) => k !== FAV_LOCK)];
};
const favs = () => favNorm(D.favs);
// A list the person just made is one made since the move: it carries the marker from the start.
const favSet = (L) => { D.favs = [...L.filter((k) => k !== FAV_V), FAV_V]; };

// 설정 lives at the foot of the sidebar unless the person put it somewhere themselves.
const settingsAtFoot = () => !isFav("settings") && !(knob("menu_order") || []).includes("settings");
const isFav = (k) => favs().includes(k);
// "자주 쓰는" first, then every group without what is already up there. The 사용 방식 knobs rename
// both titles, hide menus (still reachable from 전체, G keys and 자주 쓰는) and move some up.
const favTitle = () => prefName("favs") || tl("chrome.1");
const menuGroups = () => { const F = favs(), gs = [...new Set(MENUS.map((m) => m.g))], hid = knob("menu_hide") || [];
  const ord = knob("menu_order") || [], at = (k) => (ord.includes(k) ? ord.indexOf(k) - ord.length : MENUS.findIndex((m) => m.k === k));
  return [[favTitle(), F.map((k) => M(k))], ...gs.map((g) => [prefName("menus") || g,
    MENUS.filter((m) => m.g === g && !F.includes(m.k) && !hid.includes(m.k)).sort((a, b) => at(a.k) - at(b.k))])].filter(([, L]) => L.length); };
const favBtn = (k, cls = "") => { if (k === FAV_LOCK) return "";
  const on = isFav(k), t = on ? tl("favBtn.1") : tl("favBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb favb press ${cls} ${on ? "on" : ""}" data-fav="${k}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("star")}</${tag}>`; };
async function toggleFav(k, undo = true) {
  if (menuKey(k) === FAV_LOCK) return;
  const was = favs(), on = !was.includes(k), n = M(k)?.n || k;
  favSet(on ? [...was, k] : was.filter((x) => x !== k));
  redrawFavs();
  if (undo) toastAct(on ? tl("toggleFav.1", {n}) : tl("toggleFav.2", {n}), tl("toggleFav.3"), () => { favSet(was); saveFavs(); }, 5000, on ? "fav" : "unfav");
  saveFavs();
}
async function saveFavs() {
  redrawFavs();
  try { D.favs = (await post("/api/favs", {favs: [...favs(), FAV_V]})).favs; } catch (e) { toast(e.message); }
}
function redrawFavs() { drawChrome(); }

// ---------- 순서 바꾸기: pinned departments and favourite menus, dragged into place ----------
// The row follows the pointer 1:1, the others make room as it passes their middle, and on
// release it settles into the gap. With a mouse the whole row drags (rail); by touch only the
// handle does, so the list still scrolls under a finger.
function sortable(box, done, mouseOnly = false) {
  box.onpointerdown = (e) => {
    const items = [...box.children].filter((c) => !("fixed" in c.dataset)), it = items.find((c) => c.contains(e.target));
    if (!it || e.button || items.length < 2 || (mouseOnly && e.pointerType !== "mouse")) return;
    if (e.target.closest("[data-fav],[data-pin]") || (e.pointerType !== "mouse" && !e.target.closest(".grab"))) return;
    if (e.pointerType !== "mouse") e.preventDefault();
    const y0 = e.clientY, i0 = items.indexOf(it), R = items.map((c) => c.getBoundingClientRect());
    const step = R[1].top - R[0].top, lo = R[0].top - R[i0].top, hi = R.at(-1).top - R[i0].top;
    let on = false, to = i0;
    const move = (ev) => { const dy = Math.max(lo, Math.min(hi, ev.clientY - y0));
      if (!on) { if (Math.abs(ev.clientY - y0) < 5) return; on = true; box.classList.add("sorting"); it.classList.add("lift"); }
      ev.preventDefault();
      it.style.transform = `translateY(${dy}px)`;
      const cy = R[i0].top + R[i0].height / 2 + dy;
      to = items.filter((c, j) => j !== i0 && R[j].top + R[j].height / 2 < cy).length;
      items.forEach((c, j) => { if (j === i0) return; const sh = j > i0 && j <= to ? -step : j < i0 && j >= to ? step : 0; c.style.transform = sh ? `translateY(${sh}px)` : ""; });
    };
    const up = () => { removeEventListener("pointermove", move); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
      if (!on) return;
      // The click that ends a drag is not a press on the row.
      const eat = (ev) => { ev.stopPropagation(); ev.preventDefault(); }; addEventListener("click", eat, true); setTimeout(() => removeEventListener("click", eat, true), 60);
      it.classList.add("settle"); it.style.transform = `translateY(${(to - i0) * step}px)`;
      setTimeout(() => { items.forEach((c) => { c.style.transform = ""; c.classList.remove("lift", "settle"); }); box.classList.remove("sorting");
        if (to === i0) return; const o = items.slice(); o.splice(to, 0, o.splice(i0, 1)[0]); o.forEach((c) => box.appendChild(c)); done([...box.children].map((c) => c.dataset.key)); }, RM() ? 0 : 220);
    };
    addEventListener("pointermove", move, {passive: false}); addEventListener("pointerup", up); addEventListener("pointercancel", up);
  };
}
async function reorder(kind, keys) {
  if (kind === "favs") { favSet(keys); return saveFavs(); }
  const was = D.pins; D.pins = keys;
  try { D.pins = (await post("/api/pins", {pins: keys})).pins; } catch (e) { D.pins = was; toast(e.message); }
  drawChrome();
}
// On a phone there is no rail: the same lists in a sheet, each row with a handle.
const SNZ = () => { const d = new Date(), at = (days, h) => { const t = new Date(d); t.setDate(t.getDate() + days); t.setHours(h, 0, 0, 0); return t / 1000; };
  const mon = (8 - d.getDay()) % 7 || 7;
  return [[tl("SNZ.1"), d / 1000 + 3 * 3600], ...(d.getHours() < 17 ? [[tl("SNZ.2"), at(0, 18)]] : []), [tl("SNZ.3"), at(1, 9)], [tl("SNZ.4"), at(mon, 9)], [tl("SNZ.5"), d / 1000 + 30 * 86400]]; };
const snzWhen = (e) => e.until - Date.now() / 1000 > 20 * 86400 ? tl("snzWhen.1") : new Date(e.until * 1000).toLocaleString(LANG() === "en" ? "en-US" : "ko-KR", {month: "numeric", day: "numeric", weekday: "short", hour: "numeric"});
function snoozeSheet(key) {
  const x = D.items.find((y) => iid(y) === key); if (!x) return;
  sheet(`<h2 style="margin:0 0 4px">${tl("snoozeSheet.1")}</h2><p class="hint" style="margin:0 0 12px">${tl("snoozeSheet.2", {esc: esc(x.title)})}</p>
    <div class="snzl">${SNZ().map(([t, u], i) => `<button class="row press" data-snzat="${u}"><span class="ico sm">${ic("clock")}</span><span class="tx"><div class="t">${t}</div></span><kbd class="num">${i + 1}</kbd></button>`).join("")}</div>`,
    (box) => { box.querySelectorAll("[data-snzat]").forEach((b) => b.onclick = () => { closeSheet(); snooze(key, +b.dataset.snzat); });
      box.addEventListener("keydown", (e) => { const b = box.querySelectorAll("[data-snzat]")[+e.key - 1]; if (b) { e.preventDefault(); b.click(); } }); });
}
async function snooze(key, until, mark) {
  const x = D.items.find((y) => iid(y) === key), was = {...(D.snooze || {})};
  D.snooze = {...was}; if (until) D.snooze[key] = {until, v: x?.v || null, ...(mark == null ? {} : {mark})}; else delete D.snooze[key];
  redrawTurn();
  if (until) toastAct(until === SNZ_OPEN ? tl("later.done") : tl("snooze.1", {snzWhen: snzWhen(D.snooze[key])}), tl("toggleFav.3"), () => snooze(key, null));
  else toast(tl("snooze.2"));
  try { D.snooze = (await post("/api/snooze", {key, until: until || null, v: x?.v || null, mark})).snooze || {}; } catch (e) { D.snooze = was; toast(e.message); redrawTurn(); }
}
// Several rows at once, as [key, entry | null] (null = back to 할 일). One redraw; the store takes
// them one after another, and a failure leaves the screen on what the server last said it holds.
async function snoozeMany(rows) {
  const was = {...(D.snooze || {})}; let got = was;
  D.snooze = {...was}; rows.forEach(([key, e]) => { if (e) D.snooze[key] = e; else delete D.snooze[key]; });
  redrawTurn();
  try { for (const [key, e] of rows) got = (await post("/api/snooze", {key, until: e ? e.until : null, v: e ? e.v : null, mark: e ? e.mark : undefined})).snooze || {}; D.snooze = got; }
  catch (err) { D.snooze = got; toast(err.message); redrawTurn(); }
}
// The rows of the given sections of 할 일 put aside at once, each the way its own clock does it -
// a result until its next version, any other row until what it stood on changes. 되돌리기 puts
// back exactly these rows, each to the entry it had before.
const laterRows = (T) => T.flatMap((s) => (s.k === "ask" ? s.L.flatMap((g) => g.items) : s.L).map((r) => SEC_ROW[s.k] ? SEC_ROW[s.k](r) : [iid(r), null, r.v]));
function laterAll(T, said) {
  const rows = laterRows(T), was = D.snooze || {};
  if (!rows.length) return;
  const back = rows.map(([key]) => [key, was[key] || null]);
  const put = snoozeMany(rows.map(([key, mark, v]) => [key, {until: SNZ_OPEN, v: v || null, ...(mark == null ? {} : {mark})}]));
  // The way back waits for the last of the writes above: one still on its way would hide the row again.
  toastAct(said, tl("toggleFav.3"), () => put.then(() => { snoozeMany(back); toast(tl("snooze.2")); }));
}
// 할 일 in the two kinds the result lists have: 신규 (a version not opened yet) and 답변 (everything
// that waits for the person's move). One split, so the two numbers always add up to the bell's.
const turnKinds = (T) => { const isNew = (s, x) => s.k === "look" && stOf(x) === "fresh";
  return {fresh: T.map((s) => ({...s, L: s.L.filter((x) => isNew(s, x))})), reply: T.map((s) => ({...s, L: s.L.filter((x) => !isNew(s, x))}))}; };
// 모두 읽음 on 신규: each is marked opened (as opening it does) and leaves 할 일 until its next version.
function readFresh(T) {
  T.find((s) => s.k === "look").L.forEach((x) => { x.new = false; post("/api/seen", {p: x.project, i: x.id, v: x.v}).catch(() => {}); });
  laterAll(T, tl("sx.allread.done"));
}
const redrawTurn = () => { if (!detail && cur === "inbox") SCREENS.inbox(inTab); else if (!detail && cur === "home") SCREENS.home(); drawChrome(); };
// The quiet action on every row of 할 일 (and the way back on 나중에). A result's keeps the class
// the skins already dress (.snzb); `mark` is given for the rows that are not results.
const laterBtn = (key, mark) => `<span class="${mark == null ? "snzb" : "ltrb"} press" role="button" tabindex="0" data-later="${esc(key)}"${mark == null ? "" : ` data-mark="${esc(mark)}"`} aria-label="${tl("snoozeSheet.1")}" title="${tl("snoozeSheet.1")}">${ic("clock")}</span>`;
const backBtn = (key) => `<span class="ltrb press" role="button" tabindex="0" data-unsnz="${esc(key)}" aria-label="${tl("inboxDo.6")}" title="${tl("inboxDo.6")}">${ic("undo")}</span>`;
function sortSheet(kind) {
  const L = kind === "favs" ? favs().map((k) => ({k, n: M(k).n, i: menuIco(M(k), "ico sm")}))
    : (D.pins || []).map((d) => ({k: d, n: d, i: `<span class="ico sm">${ic("star")}</span>`}));
  sheet(`<h2 style="margin:0 0 4px">${tl("sortSheet.3", {p0: kind === "favs" ? tl("sortSheet.1") : tl("sortSheet.2")})}</h2><p class="hint" style="margin:0 0 12px">${tl("sortSheet.4")}</p>
    <div class="slist" data-sort="${kind}">${L.map((x) => `<div class="srow" data-key="${esc(x.k)}"${kind === "favs" && x.k === FAV_LOCK ? " data-fixed" : ""}>${x.i}<span class="tx">${esc(x.n)}</span><span class="grab" aria-hidden="true">${ic(kind === "favs" && x.k === FAV_LOCK ? "lock" : "grip")}</span></div>`).join("")}</div>`,
    (box) => sortable(box.querySelector(".slist"), (keys) => reorder(kind, keys)));
}

// ---------- 고정: departments kept at the top of every list, like a browser's bookmarks bar ----------
// Kept on the server (prefs) so the phone and the PC show the same ones, in the order pinned.
const isPinned = (dept) => (D.pins || []).includes(dept);
// Inside a row that is itself a button it has to be a span: a button in a button is torn apart.
const pinBtn = (dept, cls = "") => { const on = isPinned(dept), t = on ? tl("pinBtn.1") : tl("pinBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb press ${cls} ${on ? "on" : ""}" data-pin="${esc(dept)}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("star")}</${tag}>`; };
async function togglePin(dept, undo = true) {
  const on = !isPinned(dept), was = D.pins || [];
  D.pins = on ? [...was.filter((d) => d !== dept), dept] : was.filter((d) => d !== dept);
  pinsRedraw();
  if (undo) toastAct(on ? tl("togglePin.1", {dept}) : tl("togglePin.2", {dept}), tl("toggleFav.3"), () => togglePin(dept, false), 5000, on ? "fav" : "unfav");
  try { D.pins = (await post("/api/pin", {dept, on})).pins; } catch (e) { D.pins = was; toast(e.message); }
  pinsRedraw();
}
const pinsRedraw = () => { drawChrome(); if (!detail && cur === "dept") SCREENS.dept(); };

// ---------- 보관: projects folded away, like the hub's collapsible "…도 보기" line ----------
// A hidden project drops out of the sidebar, the chips and the pickers into one "보관 N" line
// that expands in place. Kept on the server (prefs.hidden_projects) so phone and PC agree.
const isArch = (dept) => (D.hidden || []).includes(dept);
let showArch = false;   // the 보관 N line is folded until clicked
// A department the register put away (an archived 부서, or one imported from the hub as finished)
// folds into the same 보관 line; only the person's own hide is undone from here (archBtn).
const inShelf = (dept) => isArch(dept) || (D.shelved || []).includes(dept);
// The folded line says what is inside by register number, on one line: "12 · 31 · 45".
const shelfNums = (gs) => gs.map((g) => (D.placeNums || {})[g.name]).filter(Boolean).sort((a, b) => a - b).join(" · ");
// The fold opens in place (no redraw), so the spring can be caught and reversed mid-way.
const shelfFold = (rows) => `<div class="shfold${showArch ? " on" : ""}"${showArch ? "" : " inert"}><div class="shfin">${rows}</div></div>`;
const toggleShelf = () => { showArch = !showArch;
  document.querySelectorAll("[data-archx]").forEach((b) => { b.setAttribute("aria-expanded", showArch); b.classList.toggle("on", showArch); });
  document.querySelectorAll(".shfold").forEach((f) => { f.classList.toggle("on", showArch); f.inert = !showArch; }); };
const archBtn = (dept, cls = "") => { const on = isArch(dept), t = on ? tl("archBtn.1") : tl("archBtn.2"), tag = cls.includes("inrow") ? "span" : "button";
  return `<${tag} class="pinb archb press ${cls} ${on ? "on" : ""}" data-arch="${esc(dept)}" ${tag === "span" ? `role="button" tabindex="0"` : ""} aria-pressed="${on}" aria-label="${t}" title="${t}">${ic("archive")}</${tag}>`; };
async function toggleArchive(dept, undo = true) {
  const on = !isArch(dept), was = D.hidden || [];
  D.hidden = on ? [...was.filter((d) => d !== dept), dept] : was.filter((d) => d !== dept);
  archRedraw();
  if (undo) toastAct(on ? tl("toggleArch.1", {dept}) : tl("toggleArch.2", {dept}), tl("toggleFav.3"), () => toggleArchive(dept, false), 5000, on ? "archive" : "restore");
  try { D.hidden = (await post("/api/project-hide", {project: dept, on})).hidden_projects; } catch (e) { D.hidden = was; toast(e.message); }
  archRedraw();
}
const archRedraw = () => { drawChrome(); if (!detail && cur === "dept") SCREENS.dept(); else if (detail?.[0] === "dept") deptView(detail[1]); };
// A row held down on a phone opens its menu, pin included (web/railmenu.js).
