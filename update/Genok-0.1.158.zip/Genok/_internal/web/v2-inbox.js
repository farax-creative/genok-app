// Genok web UI, cut from v2.js: 부서, 대화, the sheet, 검색 · 명령, 받은함.
// A classic script in the page's shared scope; v2.html loads the v2*.js parts in order.
// ---------- 부서 ----------
// Forty-odd departments: a state chip narrows to one kind, typing narrows by name or bundle.
// The 30s refresh redraws only the list, so the search box keeps its focus and text.
let deptQ = "";
SCREENS.dept = function () {
  if (!document.getElementById("dpq")) {
    V().innerHTML = `<div class="field">${ic("search")}<input id="dpq" type="search" enterkeyhint="search" placeholder="${tl("dept.1")}" autocomplete="off"></div><div id="dls"></div>`;
    const i = document.getElementById("dpq"); i.value = deptQ;
    i.oninput = () => { deptQ = i.value; SCREENS.dept(); };
  }
  const q = deptQ.trim().toLowerCase(), all = projects().filter((g) => !q || Chosung.has(g.name, q) || Chosung.has(pname(g.name), q));
  const L = all.filter((g) => !inShelf(g.name)), arc = all.filter((g) => inShelf(g.name)), an = shelfNums(arc);
  const P = L.filter((g) => isPinned(g.name)), rest = L.filter((g) => !isPinned(g.name));
  const card = (h, xs, more = "") => xs.length ? `<div class="card" data-pjsort><div class="ch">${h}<span class="n num">${xs.length}</span><span class="sp"></span>${more}</div>${xs.map(deptRow).join("")}<div style="height:10px"></div></div>` : "";
  // Archived projects collapse into one card that opens on click, mirroring the sidebar fold.
  // Shelved ones sit at the bottom: one line naming them by number, opening in place.
  const archCard = arc.length ? `<div class="card"><button class="ch archfold press" data-archx aria-expanded="${showArch}">${ic("archive")}<h2>${tl("archFold.2")}</h2><span class="n num">${arc.length}</span>${an ? `<span class="shnums num">${esc(an)}</span>` : `<span class="sp"></span>`}${ic("chev")}</button>${shelfFold(arc.map(deptRow).join("") + `<div style="height:10px"></div>`)}</div>` : "";
  document.getElementById("dls").innerHTML = all.length
    ? card(`<h2 class="pinh">${tl("dept.2", {ic: ic("star")})}</h2>`, P, P.length > 1 ? `<button class="link" data-sortsheet="pins">${tl("dept.3")}</button>` : "") + card(tl("dept.4"), rest) + archCard
    : `<div class="card plan none"><p>${D.items.length ? tl("dept.5", {esc: esc(deptQ)}) : tl("dept.6")}</p></div>`;
  // The pinned and the other projects are each put in order within their own card.
  document.querySelectorAll("#dls [data-pjsort]").forEach((c) => pjSort(c, ".row[data-dept]", SCREENS.dept));
};
// The project page is a result grid, like the library scoped to one department: status filter
// chips, a card for every result (all of them, never a silent cap), per-card approve/맡기기/치우기,
// and a select mode for approving several at once. deptF/deptSel are kept per department; they
// reset when the reader opens another one.
let deptF = "all", deptKey = "", deptSel = null, deptReqSig = "";
// 목록 or 보드 (web/boardview.js), kept per device; with the "board" beta also 릴 (web/board-spread.js).
const reelOk = () => !!(window.genokBeta?.("board") && window.BoardSpread);
const deptV = (v) => { try { if (v === undefined) { v = localStorage.getItem("v2-dview"); return v === "board" ? "board" : v === "reel" && reelOk() ? "reel" : "list"; } localStorage.setItem("v2-dview", v); } catch { return "list"; } };
const redrawDept = () => { if (detail && detail[0] === "dept") deptView(detail[1]); };
function deptView(key) {
  const g = projects().find((x) => x.name === key);
  if (!g) { V().innerHTML = `<div class="card plan none"><p>${tl("deptView.1")}</p></div>`; head(""); return; }
  if (deptKey !== key) { deptKey = key; deptF = "all"; deptSel = null; }
  const all = g.items.filter((x) => !libHide.has(iid(x))).sort(byAt);
  const reqs = D.board.filter((b) => b.dept === g.name);
  head(esc(pname(g.name)));
  const brd = deptV() === "board" && !!window.BoardView;   // the board shows every result: its cards carry their own state
  const rel = deptV() === "reel", mode = rel ? "reel" : brd ? "board" : "list", whole = brd || rel;
  const its = all.filter((x) => whole || deptF === "all" || stOf(x) === deptF);
  if (whole) deptSel = null;
  // An unchanged board is left as it is on a refresh (as SCREENS.board does): only the header's age moves.
  const rsig = JSON.stringify(reqs);
  // So is the reel (it redraws itself only when the reel changed).
  const rlbox = rel && document.getElementById("rlbox");
  if (softN > 0 && rsig === deptReqSig && (brd && its.length && BoardView.same(document.getElementById("bdhost"), key, its) || rlbox)) {
    if (rlbox) BoardSpread.reel(rlbox, key);
    const h = V().querySelector(".deptpage .phs"); if (h) h.innerHTML = tl("deptView.5", {n: all.length, p3: g.at ? " · " + ago(g.at).replace(/ /g, "\u00a0") : ""});
    return;
  }
  deptReqSig = rsig;
  if (!deptSel) selOff("dept");
  const sel = deptSel && its.filter((x) => deptSel.has(iid(x)));
  const gcard = (x) => `<div class="gw"><button class="gi press${deptSel?.has(iid(x)) ? " picked" : ""}" ${deptSel ? `data-dpick="${esc(iid(x))}" aria-pressed="${deptSel.has(iid(x))}"` : `data-item="${esc(iid(x))}"`}>
      <div class="th">${ic((KIND[x.kind] || ["doc"])[0])}${x.thumb ? imgTag(x.thumb) : ""}${x.kind === "video" ? `<span class="vbadge">${ic("play")}</span>` : ""}${stK(x) !== "approved" ? `<span class="tag ${stCls(x)}"${stTip(x)}>${stName(x)}</span>` : ""}${apprTag(x)}${deptSel ? `<span class="pk">${ic("check")}</span>` : ""}</div>
      <div class="tx"><div class="t">${esc(x.title)}</div><div class="s gm"><span class="gmn">${gname(x) === g.name ? "" : `<span class="gpn">${esc(pname(gname(x)))}</span>`}<span class="grest">${gname(x) === g.name ? "" : " · "}${vShort(x.v)} · ${ago(x.at)}${window.resMeta ? resMeta(x) : ""}</span></span></div></div></button>${deptSel ? "" : gmore(x)}</div>`;
  // A full-width project page: a plain header (no card), an optional 보낸 요청 line only when
  // there is one, then the results as a proper full-width grid — not squeezed into a side column.
  V().innerHTML = `<div class="deptpage">
    <div class="pagehead">${deptIco(g, "ico phic")}<div class="phtx"><h1 class="pht">${esc(pname(g.name))}</h1><div class="phs">${tl("deptView.5", {n: all.length, p3: g.at ? " · " + ago(g.at).replace(/ /g, "\u00a0") : ""})}</div></div><span class="sp"></span>${window.ApprovedReel ? ApprovedReel.btn(g) : ""}<button class="btn sm weak press" data-go="project/${esc(g.name)}">${tl("menu.chat")}</button>${pinBtn(g.name, "big")}${archBtn(g.name, "big")}</div>
    ${reqs.length ? `<div class="card reqcard"><div class="ch"><h2>${tl("deptView.6")}</h2><span class="n num">${reqs.length}</span></div>${reqs.map((b) => `<div class="row">${thumb(b, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(b.title)}</div><div class="s">${{waiting:tl("deptView.2"),delivered:tl("itemView.123"),ack:tl("deptView.3"),done:tl("hitRow.1")}[b.state] || ""} · ${ago(b.asked)}</div></span></div>`).join("")}<div style="height:8px"></div></div>` : ""}
    <div class="ch rhead"><h2>${tl("TABS.3")}</h2><span class="n num">${all.length}</span><span class="sp"></span>${all.length && window.BoardView ? `<div class="seg dvseg" role="group" aria-label="${tl("board.view")}">${[["list", tl("res.tab.list")], ["board", tl("board.board")], ...reelOk() ? [["reel", tl("bdx.reel")]] : []].map(([k, n]) => `<button class="press${k === mode ? " on" : ""}" aria-pressed="${k === mode}" data-dview="${k}">${n}</button>`).join("")}</div>` : ""}${window.Scenes ? Scenes.toggle(whole, all.length) : ""}${all.length > 1 && !whole ? `<button class="btn sm weak press" data-dsel>${deptSel ? tl("libDraw.12") : tl("libDraw.13")}</button>` : ""}</div>
    ${whole ? "" : stTabs(all, deptF, "df")}
    ${deptSel ? `<div class="selrow"><span>${sel.length ? `<b class="num">${sel.length}</b>${tl("libDraw.10")}` : tl("libDraw.11", {n: its.length})}</span><button class="lnk press" data-dall>${its.length && sel.length === its.length ? tl("libDraw.15") : tl("libDraw.16")}</button>${window.Scenes ? Scenes.tagBtn(sel.length) : ""}${sel.length && !selHold ? `<button class="btn sm fill press" data-dok>${tl("libDraw.20", {size: sel.length})}</button>` : ""}</div>` : ""}
    ${rel ? `<div id="rlbox">${loadingHtml("", {quiet: true})}</div>` : its.length ? brd ? `<div class="bdhost" id="bdhost"></div>` : (window.Scenes && Scenes.list(key, its, gcard)) || `<div class="gal z-m dgal">${its.map(gcard).join("")}</div>` : `<div class="card plan none">${stNone(deptF)}</div>`}
    ${deptSel && selHold ? `<div class="ctapad"></div>` : ""}
  </div>`;
  // Begun with a long press, the picking has the results' bar at the foot of the screen as well.
  selBar(deptSel && selHold ? sel.length : null, () => { deptSel = null; deptView(key); }, () => { const xs = sel.slice(); deptSel = null; approveMany(xs); redrawDept(); });
  stStrip(V());
  V().querySelectorAll("[data-df]").forEach((b) => b.onclick = () => { deptF = b.dataset.df; deptSel = null; deptView(key); });
  V().querySelectorAll("[data-dview]").forEach((b) => b.onclick = () => { deptV(b.dataset.dview); deptView(key); });
  if (brd && its.length) BoardView.draw(document.getElementById("bdhost"), key, its);
  if (rel) BoardSpread.reel(document.getElementById("rlbox"), key);
  V().querySelector("[data-dsel]")?.addEventListener("click", () => { deptSel = deptSel ? null : new Set(); deptView(key); });
  V().querySelectorAll("[data-dpick]").forEach((b) => b.onclick = () => { const k = b.dataset.dpick; deptSel.has(k) ? deptSel.delete(k) : deptSel.add(k); if (!deptSel.size && selHold) deptSel = null; deptView(key); });
  V().querySelector("[data-dall]")?.addEventListener("click", () => { const on = its.length && its.every((x) => deptSel.has(iid(x))); its.forEach((x) => on ? deptSel.delete(iid(x)) : deptSel.add(iid(x))); deptView(key); });
  V().querySelector("[data-dok]")?.addEventListener("click", () => { const xs = sel.slice(); deptSel = null; approveMany(xs); redrawDept(); });
  triMark();
}

// ---------- 대화: Claude departments and Codex threads, one list, one pane ----------
let talkQ = "", talkSeg = "all";
// The list beside a conversation takes the width it is dragged to (names were cut at 360px).
// It follows the pointer 1:1, a double click puts it back, arrows nudge it; kept per device.
const CLW = [260, 300, 720];
const clw = (v) => { try { if (v === undefined) return +localStorage.getItem("v2-clw") || CLW[1]; localStorage.setItem("v2-clw", Math.round(v)); } catch { return CLW[1]; } };
const clampW = (w) => Math.max(CLW[0], Math.min(w, CLW[2], innerWidth - railRoom() - 420));
const setClw = (w) => document.documentElement.style.setProperty("--clw", clampW(w) + "px");
setClw(clw());
addEventListener("resize", () => setClw(clw()));
// The item page's right column (comments, versions) drags wider the same way, from its left edge.
const IPW = [320, 320, 760];
// Untouched, the panel leaves the result 520px (defIpw); dragged, it may take 80 more in a window
// under 1280, or the menu's 248 leaves the grip 12px of travel at 1100 (feedback E9). Putting it
// back on the default (double-click) forgets the stored width, so the default follows the window.
const ipwRoom = (keep) => innerWidth - railRoom() - keep;
const defIpw = () => Math.max(IPW[0], Math.min(IPW[1], ipwRoom(520)));
const clampIpw = (w) => Math.max(IPW[0], Math.min(w, IPW[2], ipwRoom(innerWidth < 1280 ? 440 : 520)));
const ipw = (v) => { try { if (v === undefined) { const k = +localStorage.getItem("v2-ipw"); return k ? clampIpw(k) : defIpw(); }
  if (Math.round(v) === Math.round(defIpw())) localStorage.removeItem("v2-ipw"); else localStorage.setItem("v2-ipw", Math.round(v)); } catch { return defIpw(); } };
// One splitter behaviour for every column edge that drags (the item page's panel, the conversation
// screen's list and results): 1:1 with the pointer, double-click puts the default back, arrows
// step it. `o`: range [min, default, max], dir (+1 when dragging right widens the panel, -1 when
// it narrows it), width() the panel's width now, apply(w) -> the clamped width it set, save(w).
function wireColGrip(g, o) {
  // The separator reports the panel width it controls, so a screen reader hears where a drag put
  // it. min/max are the panel's own bounds, not the raw range which the viewport also clamps.
  g.setAttribute("aria-valuemin", o.range[0]); g.setAttribute("aria-valuemax", o.range[2]);
  const set = (w) => { w = o.apply(w); g.setAttribute("aria-valuenow", Math.round(w)); return w; };
  let x0 = 0, w0 = 0, w = o.width(); g.setAttribute("aria-valuenow", Math.round(w));
  g.onpointerdown = (e) => { if (e.button) return; e.preventDefault(); g.setPointerCapture(e.pointerId); x0 = e.clientX; w0 = o.width(); document.body.classList.add("gripping"); };
  g.onpointermove = (e) => { if (g.hasPointerCapture(e.pointerId)) w = set(w0 + o.dir * (e.clientX - x0)); };
  g.onpointerup = g.onpointercancel = (e) => { if (!g.hasPointerCapture(e.pointerId)) return; g.releasePointerCapture(e.pointerId); document.body.classList.remove("gripping"); o.save(w); };
  g.ondblclick = () => { w = set(o.range[1]); o.save(w); };
  g.onkeydown = (e) => { const d = {ArrowLeft: -24, ArrowRight: 24}[e.key]; if (!d) return; e.preventDefault(); w = set(o.width() + o.dir * d); o.save(w); };
}
function wireItemGrip() {
  const g = document.getElementById("igrip"), box = g?.parentElement; if (!g) return;
  wireColGrip(g, {range: [IPW[0], defIpw(), IPW[2]], dir: -1, width: () => box.lastElementChild.getBoundingClientRect().width,
    apply: (w) => { w = clampIpw(w); box.style.setProperty("--ipw", w + "px"); return w; }, save: ipw});
}
function closeResult() {
  const s = document.getElementById("rsheet"); if (!s || !s.classList.contains("on")) return;
  s.classList.remove("in"); if (stageMount && s.contains(stageMount.el)) stageMount = null;
  setTimeout(() => { if (!s.classList.contains("in")) { s.classList.remove("on"); s.innerHTML = ""; } }, 260);
}
let vwClose = null;               // closes the full-screen viewer when one is up
// ---------- sheet: bottom sheet on the phone, centred card on the PC ----------
let sheetFrom = null;
// Phone: an open sheet is one step of history, so Back (the browser's, Android's) closes the sheet and
// stays on the screen under it, as the full-screen viewer and compare do. The id of that entry; 0 = none.
let sheetHist = 0;
addEventListener("popstate", () => { if (!sheetHist || history.state?.sheet === sheetHist) return; sheetHist = 0; closeSheet(); });
function sheet(html, wire) {
  const s = document.getElementById("sheet");
  if (!s.classList.contains("on")) sheetFrom = document.activeElement;
  // An entry still on top from a sheet that just closed (or went with the screen) is taken over, not stacked.
  if (!wide() && !sheetHist && window.genokBeta?.("pai")) try { if (history.state?.sheet) sheetHist = history.state.sheet; else history.pushState({sheet: sheetHist = Date.now()}, ""); } catch (e) { /* no history: X, scrim and drag still close it */ }
  s.innerHTML = `<div class="scrim" data-sclose></div><div class="sbox" role="dialog" aria-modal="true"><div class="sgrab" aria-hidden="true"></div><button class="ib sx press" data-sclose aria-label="${tl("itemView.114")}">${ic("x")}</button>${html}</div>`;
  s.classList.add("on");
  const box = s.querySelector(".sbox");
  // The scrim fades with .in; on the phone the sheet itself springs up from below the edge (PC's
  // centred dialog keeps its CSS scale/fade). Springing from a real pixel offset, not the CSS 100%,
  // so an interrupted present reads a value the spring understands.
  if (wide()) requestAnimationFrame(() => s.classList.add("in"));
  else { s.classList.add("in"); box.style.transition = "none"; box.style.transform = `translateY(${box.offsetHeight}px)`;
    requestAnimationFrame(() => springSheet(box, 0)); }
  wire(box);
  liftSheet(box);
  dragSheet(box);
  // Keys stay inside the sheet: Tab goes round its own buttons, not the page behind it.
  box.tabIndex = -1;
  if (!box.contains(document.activeElement)) box.focus({preventScroll: true});
  box.addEventListener("keydown", (e) => { if (e.key !== "Tab") return;
    const f = [...box.querySelectorAll("button,a[href],input,textarea,gk-select")].filter((x) => !x.disabled && x.offsetParent !== null); if (!f.length) return;
    const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === a || document.activeElement === box)) { e.preventDefault(); z.focus(); }
    else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } });
}
// The sheet's vertical motion is a critically-damped spring (damping ratio 1.0), so it never
// overshoots the closed edge and leaves a gap under the sheet. It always starts from the value
// on screen right now, so grabbing it mid-flight and re-targeting is seamless, and it takes the
// finger's release velocity so drag and animation share one continuous motion. Reduced motion
// jumps to the target (the scrim's opacity fade carries the change). translateY only, so the
// keyboard lift (bottom/max-height) still composes.
const sboxY = (box) => { const m = /translateY\(([-\d.]+)px\)/.exec(box.style.transform); return m ? +m[1] : 0; };
function springSheet(box, target, vel = 0, done) {
  cancelAnimationFrame(box._spr || 0);
  if (RM()) { box.style.transition = "none"; box.style.transform = target ? `translateY(${target}px)` : ""; box._spr = 0; done?.(); return; }
  const k = 190, c = 2 * Math.sqrt(k);            // c = 2√k → damping ratio 1.0, response ~0.3s
  let y = sboxY(box), v = vel, last = performance.now();
  box.style.transition = "none";
  const step = (t) => { const dt = Math.min(0.032, (t - last) / 1000); last = t;
    v += (-k * (y - target) - c * v) * dt; y += v * dt;
    if (Math.abs(y - target) < 0.5 && Math.abs(v) < 10) { box.style.transform = target ? `translateY(${target}px)` : ""; box._spr = 0; return done?.(); }
    box.style.transform = `translateY(${y}px)`; box._spr = requestAnimationFrame(step); };
  box._spr = requestAnimationFrame(step);
}
// Where a flick would come to rest (scroll-style exponential projection), used to decide dismiss vs snap-back.
const projectY = (v) => (v / 1000) * 0.998 / (1 - 0.998);
// Drag the grabber (or the strip around it) down to dismiss, the iOS way: 1:1 with the finger,
// let go where its momentum would carry it past the halfway edge and it drops the rest of the way
// at that same speed, otherwise it springs back. PC's centered dialog keeps its close button only.
function dragSheet(box) {
  if (wide()) return;
  const grab = box.querySelector(".sgrab"); if (!grab) return;
  let base = 0, dy = 0, vy = 0, ly = 0, lt = 0, on = false;
  grab.addEventListener("pointerdown", (e) => { on = true;
    cancelAnimationFrame(box._spr || 0);           // grab it mid-flight: carry on from where it is
    base = e.clientY - sboxY(box); dy = sboxY(box); vy = 0; ly = e.clientY; lt = e.timeStamp || performance.now();
    box.style.transition = "none"; grab.setPointerCapture?.(e.pointerId); });
  grab.addEventListener("pointermove", (e) => { if (!on) return; dy = Math.max(0, e.clientY - base);
    const now = e.timeStamp || performance.now(), d = now - lt; if (d > 0) vy = (e.clientY - ly) / d * 1000;
    ly = e.clientY; lt = now; box.style.transform = "translateY(" + dy + "px)"; });
  const up = () => { if (!on) return; on = false;
    // Project where the flick lands; past half the sheet it dismisses, and either way the spring
    // continues at the release velocity.
    (dy + projectY(vy) > box.offsetHeight * 0.4) ? closeSheet(vy) : springSheet(box, 0, vy); };
  grab.addEventListener("pointerup", up); grab.addEventListener("pointercancel", up);
}
// A phone keyboard covers the bottom of the screen, and a bottom sheet with it: sit the
// sheet on top of the keys and fit it in what is left, as sheet.js does for the old page.
function liftSheet(box) {
  const vv = window.visualViewport; if (!vv || wide()) return;
  const lift = () => {
    if (!box.isConnected) { vv.removeEventListener("resize", lift); vv.removeEventListener("scroll", lift); return; }
    const kb = Math.max(0, innerHeight - vv.height - vv.offsetTop);
    box.style.bottom = kb > 80 ? kb + "px" : "";
    box.style.maxHeight = kb > 80 ? Math.max(0, vv.height - 16) + "px" : "";
  };
  vv.addEventListener("resize", lift); vv.addEventListener("scroll", lift);
  lift();                       // the keyboard may already be up before the sheet opens
}
// A yes/no question in the app's own sheet (the browser's confirm() box looked like another program).
// Resolves true only from the main button; any other way the sheet goes away (scrim, X, Esc) is a no.
// "다시 묻지 않기": kinds of harmless, reversible confirms the person switched off, kept in this browser.
// Never offered on anything that deletes or stops. 설정 › 화면·알림 turns them all back on.
const NOASK = "genok.noask";
const noAsk = () => { try { return JSON.parse(localStorage.getItem(NOASK) || "{}") || {}; } catch (e) { return {}; } };
const noAskSet = (k) => { try { localStorage.setItem(NOASK, JSON.stringify({...noAsk(), [k]: 1})); } catch (e) { /* asks again next time */ } };
const noAskClear = () => { try { localStorage.removeItem(NOASK); } catch (e) { /* nothing was kept */ } };
// The text's first question becomes the one-line title, what follows it the dim line; `go` names the button.
function askSheet(title, text, danger, go) {
  const m = /^(.*?\?)\s+(\S.*)$/s.exec(text || "");
  return new Promise((resolve) => {
    let done = false;
    const host = document.getElementById("sheet");
    const end = (v) => { if (done) return; done = true; obs.disconnect(); resolve(v); };
    const obs = new MutationObserver(() => { if (!host.classList.contains("on")) end(false); });
    sheet(`<div class="cf"><h3>${esc(m ? m[1] : title)}</h3><p class="cf-sub" style="white-space:pre-line">${esc(m ? m[2] : text)}</p>
      <div class="cf-acts"><button class="btn xl ${danger ? "danger" : "fill"} press" id="ask-go">${esc(go || title)}</button><button class="btn xl press" data-sclose>${tl("libDraw.22")}</button></div></div>`, (box) => {
      box.querySelector("#ask-go").onclick = () => { end(true); closeSheet(); };
    });
    obs.observe(host, {attributes: true, attributeFilter: ["class"]});
  });
}
function closeSheet(vel = 0) { const s = document.getElementById("sheet"); if (!s.classList.contains("on")) return; s.classList.remove("in");
  // Closed by X, scrim, drag or a button: take our history entry back. A moment later, so a nav() right
  // after this call is not undone (it pushes its own entry and the check below then leaves it be).
  const h = sheetHist; sheetHist = 0;
  if (h) setTimeout(() => { if (history.state?.sheet === h && sheetHist !== h && !navOffSheet) history.back(); });
  const from = sheetFrom; sheetFrom = null; if (from?.isConnected && from !== document.body) from.focus({preventScroll: true});
  const box = s.querySelector(".sbox"), clear = () => { if (!s.classList.contains("in")) { s.classList.remove("on"); s.innerHTML = ""; } };
  // Phone: spring the sheet down (carrying any release velocity) and clear once it lands. PC keeps the CSS fade.
  if (box && !wide()) springSheet(box, box.offsetHeight, vel, clear);
  else setTimeout(clear, 260); }

// ---------- 검색 (overlay) · 명령 ----------
// Ctrl+K also gets things done: ↑↓ pick a row, Enter opens it, and a picked result or
// department shows what can be done to it right there, each with its Alt key. The actions
// are the ones the lists and pages already run.
const itemIt = (x) => ({id: iid(x), p: x.project, i: x.id, v: x.v, dept: x.dept, reject: x.reject || [], status: x.status, latest: false});
// 맞아 on every claimed fix in view: the result page's own button when it is open, else per result.
async function allOk(C) {
  const b = detail?.[0] === "item" && (document.querySelector(".dall") || (C.length === 1 && document.querySelector(".dir .dyes")));
  if (b) return b.click();
  const G = new Map(); C.forEach((c) => { const k = iid(c.it); G.set(k, [...(G.get(k) || []), c.id]); });
  for (const [k, ids] of G) await verdict(k, ids, true);
}
const palActs = (row) => {
  const x = row.dataset.item && D.items.find((y) => iid(y) === row.dataset.item);
  if (!x || (x.status === "approved" && !turnOf(x))) return [];
  return [["ok", tl("STATUS_T.4"), "A", () => approveMany([x])], ["no", tl("palActs.1"), "R", () => rejectSheet(itemIt(x))], ["snz", tl("palActs.2"), "H", () => snoozeSheet(iid(x))]];
};
const palCmds = () => { const C = detail?.[0] === "item" && openItem ? claimedDirs().filter((c) => iid(c.it) === openItem.id) : claimedDirs(), n = stackQueue().length;
  return [["inbox", tl("palCmds.1"), "G I", () => nav("inbox"), true, "bell"],["lib", tl("palCmds.2"), "G L", () => nav("lib"), true, "lib"],
    ["pending", tl("palCmds.3"), "", () => nav("lib?f=pending"), true, "check"],
    n && ["stack", tl("palCmds.4", {n}), "", () => stackOpen(), false, "full"],
    C.length && ["allok", tl("palCmds.5", {n: C.length}), "", () => allOk(C), false, "check"],
  ].filter(Boolean); };
// Leaving the palette first: opened as the #search page, going back is a hash change, and
// that closes any sheet - so what opens a sheet waits for it.
function palRun(fn, goes) {
  if (goes) return fn();
  if (location.hash === "#search" && history.length > 1) { addEventListener("hashchange", () => setTimeout(fn), {once: true}); search(false); history.back(); }
  else { search(false); fn(); }
}
// Where the keyboard was when search opened; a search that is closed (not one that opened a result) gives it back.
let searchFrom = null;
function search(on, back) {
  const o = document.getElementById("ov");
  // The overlay is a modal dialog: the role/label go on while it is up so a screen reader treats
  // it as one and names it, and come off when it closes so the hidden shell is not announced.
  // What is behind the overlay (title bar, tabs, the page) is out of reach while it is up.
  const behind = (off) => document.querySelectorAll(".app,#tabbar").forEach((el) => { el.inert = off; });
  if (!on) { const was = o.classList.contains("on"); o.classList.remove("on"); o.removeAttribute("role"); o.removeAttribute("aria-modal"); o.removeAttribute("aria-label");
    // Only a search that was up gives the page back: a close on every redraw used to undo the
    // first-run wizard's hold, so Tab walked out of it into the screen behind.
    if (was) behind(false);
    if (was && back && searchFrom?.isConnected) searchFrom.focus({preventScroll: true});
    searchFrom = null; return; }
  if (o.classList.contains("on")) return;
  searchFrom = document.activeElement === document.body ? null : document.activeElement;
  behind(true);
  o.innerHTML = `<div class="top" style="background:var(--bg)"><div class="field" style="flex:1;margin:0;background:var(--card)">${ic("search")}<input id="q" placeholder="${tl("search.1")}" autocomplete="off"></div><button class="btn" data-close title="Esc" style="background:none;color:var(--t2)">${tl("itemView.114")}</button></div><div id="qr"></div><div class="qhint"><span><kbd>↑</kbd><kbd>↓</kbd> ${tl("search.2")}</span><span><kbd>Enter</kbd> ${tl("search.3")}</span></div>`;
  // Lab 3: search sits in the kit's palette over a blurred backdrop instead of a full opaque sheet.
  if (LAB3) { const pal = document.createElement("div"); pal.className = "glass-search-palette k3pal"; pal.append(...o.childNodes); o.append(pal);
    pal.querySelector(".top").classList.add("search-input-wrap"); pal.querySelector("#q").classList.add("search-input-field"); pal.querySelector("#qr").classList.add("search-results-list");
    o.classList.add("k3ov"); o.onmousedown = (e) => { if (e.target === o) pal.querySelector("[data-close]").click(); }; }
  o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true"); o.setAttribute("aria-label", tl("MENUS.5"));
  o.classList.add("on"); const q = document.getElementById("q"), qr = document.getElementById("qr"); q.focus();
  let sel = -1, acts = [], cmds = [];
  const rowsOf = () => [...qr.querySelectorAll(".row")];
  const pick = (i, scroll = true) => { const R = rowsOf(); qr.querySelector(".pact")?.remove(); R.forEach((r) => r.classList.remove("kfoc")); acts = [];
    if (!R.length) return (sel = -1);
    sel = (i + R.length) % R.length; const r = R[sel]; r.classList.add("kfoc");
    acts = r.dataset.cmd ? [] : palActs(r);
    if (acts.length) r.insertAdjacentHTML("afterend", `<div class="pact">${acts.map(([k, n, key]) => `<button class="chip press" data-pa="${k}">${n}<kbd>Alt ${key}</kbd></button>`).join("")}</div>`);
    if (scroll) (acts.length ? qr.querySelector(".pact") : r).scrollIntoView({block: "nearest"}); };
  const draw = () => { const s = q.value.trim().toLowerCase();
    cmds = palCmds().filter(([, n]) => !s || Chosung.has(n, s)).slice(0, s ? 4 : 5);
    const ms = MENUS.filter((m) => m.k !== "search" && (!s || Chosung.has(m.n + m.d, s))).slice(0, s ? 5 : 6);
    // Extension screens are found by name, so one that is off in the menu still opens from here.
    const xs = s ? extTabs().filter((t) => !M(t.id) && Chosung.has(t.label, s)).slice(0, 3) : [];
    const ds = s ? projects().filter((g) => Chosung.has(g.name + " " + pname(g.name), s)).slice(0, 5) : [];
    const is = s ? D.items.filter((x) => Chosung.has(x.title + x.dept + pname(x.dept || ""), s)).slice(0, 6) : myTurn().slice(0, 3);
    qr.innerHTML =
      (is.length && !s ? `<div class="sec">${tl("search.4")}</div><div class="card">${is.map((x) => itemRow(x, false)).join("")}</div>` : "")
      + (cmds.length ? `<div class="sec">${tl("search.5")}</div><div class="card">${cmds.map(([k, n, key, , , i]) => `<button class="row press" data-cmd="${k}" style="min-height:56px"><span class="ico sm c-grey">${ic(i)}</span><span class="tx"><div class="t" style="font-size:16px">${esc(n)}</div></span>${key ? `<span class="pkey">${key.split(" ").map((x) => `<kbd>${x}</kbd>`).join(" ")}</span>` : ""}</button>`).join("")}</div>` : "")
      + (ms.length + xs.length ? `<div class="sec">${s ? tl("search.6") : tl("search.7")}</div><div class="card">${ms.map((m) => `<button class="row press" data-go="${m.k}" style="min-height:60px">${menuIco(m, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${m.n}</div></span></button>`).join("")}${xs.map((t) => `<button class="row press" data-go="${esc(t.id)}" style="min-height:60px"><span class="ico sm c-grey">${ic(t.icon)}</span><span class="tx"><div class="t" style="font-size:16px">${esc(t.label)}</div></span></button>`).join("")}</div>` : "")
      + (ds.length ? `<div class="sec">${esc(unitWord())}</div><div class="card">${ds.map(deptRow).join("")}</div>` : "")
      + (is.length && s ? `<div class="sec">${tl("TABS.3")}</div><div class="card">${is.map((x) => itemRow(x, false)).join("")}</div>` : "")
      + (!cmds.length && !ms.length && !xs.length && !ds.length && !is.length ? `<div class="plan" id="qnone"${s.length >= 2 ? ` style="display:none"` : ""}>${mEmpty("emptySearch")}<p>${tl("search.8", {esc: esc(s)})}</p></div>` : "")
      + `<div id="qhits"></div>`;
    // A mouse or keyboard gets the first row picked; a finger just taps.
    if (matchMedia("(hover:hover)").matches) pick(0, false); else sel = -1;
    // Comments and summaries (and finished results the lists no longer carry) come from the server.
    // Nothing local is not yet "nothing": the empty line waits for the server, and a slow or failed
    // server search says so instead of passing for no match.
    clearTimeout(qT); clearTimeout(qW); const ask = ++qAsk; if (s.length < 2) return;
    const hitBox = () => ask === qAsk ? document.getElementById("qhits") : null;
    qW = setTimeout(() => { const b = hitBox(); if (b) b.innerHTML = `<div class="sec" role="status">${tl("search.10")}</div>`; }, 700);
    qT = setTimeout(() => get(`/api/search?q=${encodeURIComponent(s)}`).then((r) => {
      const hs = (r.hits || []).filter((h) => h.where !== "제목" || !D.items.some((x) => iid(x) === h.project + "/" + h.id)).slice(0, 12);
      clearTimeout(qW); const box = hitBox(); if (!box) return;
      if (!hs.length) { box.innerHTML = ""; const n = document.getElementById("qnone"); if (n) n.style.display = ""; return; }
      document.getElementById("qnone")?.remove();
      box.innerHTML = `<div class="sec">${tl("search.9")}</div><div class="card">${hs.map((h) => hitRow(h, s)).join("")}</div>`;
      if (sel < 0 && matchMedia("(hover:hover)").matches) pick(0, false);
    }).catch(() => { clearTimeout(qW); const box = hitBox(); if (!box) return;
      box.innerHTML = `<div class="plan"><p>${tl("search.11")}</p><p><button class="btn weak press" id="qretry">${tl("upd.retry")}</button></p></div>`;
      document.getElementById("qretry").onclick = draw; }), 200); };
  let qT, qW, qAsk = 0;
  const act = (a) => a && palRun(a[3], a[4]);
  q.oninput = draw;
  // A press on the bare backdrop (not a row, the field or the hint bar) leaves the search.
  o.onclick = (e) => { if (e.target === o || e.target === qr) { search(false, true); if (history.length > 1 && location.hash === "#search") history.back(); } };
  // Tab goes round the palette's own field, buttons and rows, not out to the title bar or page.
  o.onkeydown = (e) => { if (e.key !== "Tab") return;
    const f = [...o.querySelectorAll("button,a[href],input")].filter((x) => !x.disabled && x.offsetParent !== null); if (!f.length) return;
    const a = f[0], z = f[f.length - 1], cur = document.activeElement;
    if (e.shiftKey && (cur === a || !o.contains(cur))) { e.preventDefault(); z.focus(); }
    else if (!e.shiftKey && (cur === z || !o.contains(cur))) { e.preventDefault(); a.focus(); } };
  q.onkeydown = (e) => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); pick(sel < 0 && e.key === "ArrowDown" ? 0 : sel + (e.key === "ArrowDown" ? 1 : -1)); }
    else if (e.key === "Enter" && !e.altKey) { const r = rowsOf()[Math.max(sel, 0)]; if (r) { e.preventDefault(); r.click(); } }
    else if (e.altKey && !e.ctrlKey && !e.metaKey && /^Key[A-Z]$/.test(e.code)) { const a = acts.find(([, , k]) => "Key" + k === e.code); if (a) { e.preventDefault(); act(a); } }
  };
  qr.onclick = (e) => { const c = e.target.closest("[data-cmd]"), p = e.target.closest("[data-pa]");
    if (c) { e.stopPropagation(); act(cmds.find(([k]) => k === c.dataset.cmd)); }
    else if (p) { e.stopPropagation(); act(acts.find(([k]) => k === p.dataset.pa)); } };
  draw();
}

// The same lists the 내 차례 page counts, so the two numbers agree.
const claimedDirs = () => D.items.filter((x) => !x.finished && (x.claimed || []).length).flatMap((x) => x.claimed.map((c) => ({...c, it: x})));
// Departments standing still until I act - a question, a prompt, a stuck session, a failed job.
// Results to look at, fixes to confirm and doubled sessions wait without holding anyone up, so
// they stay on 내 차례 but out of the red count.
// 고쳤다고 한 지시, one block per result: each ask with 맞아 / 아직 right there, and 모두 맞아
// for a result whose fixes were already seen in its newest version.
const claimCard = () => { const C = claimedDirs(); if (!C.length) return "";
  const G = new Map(); C.forEach((c) => { const k = iid(c.it); if (!G.has(k)) G.set(k, []); G.get(k).push(c); });
  return `<div class="card"><div class="ch"><h2>${tl("claimCard.2")}</h2><span class="n num">${C.length}</span></div>
    ${[...G].map(([k, L]) => `<div class="clg"><button class="row press clh" data-item="${esc(k)}">${thumb(L[0].it, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(L[0].it.title)}</div><div class="s">${tl("claimCard.1", {esc: esc(L[0].it.dept || ""), esc2: esc(L[0].fixed_in)})}</div></span>${ic("chev", "i go")}</button>
      ${L.map((c) => `<div class="row note dir claimed"${cur === "inbox" ? " data-tk" : ""}><span class="tx"><div class="nt">${esc((c.text || "").split(/\s+/).join(" ").slice(0, 90))}</div></span><span class="dbtns"><button class="btn sm fill press" data-dv="${esc(c.id)}" data-dk="${esc(k)}" data-ok="1">${tl("itemView.10")}</button><button class="btn sm weak press" data-dv="${esc(c.id)}" data-dk="${esc(k)}" data-ok="">${tl("itemView.11")}</button></span></div>`).join("")}
      ${L.length > 1 ? `<div class="clall"><button class="btn sm press" data-dvall="${esc(k)}">${tl("itemView.14", {n: L.length})}</button></div>` : ""}</div>`).join("")}<div style="height:8px"></div></div>`; };
// Home's line for the same asks: one row per result (never one per ask - that flooded the
// list), three at most, each opening the result with its 요청 fold open.
const fixCard = () => { const G = new Map(); claimedDirs().forEach((c) => { const k = iid(c.it); if (!G.has(k)) G.set(k, []); G.get(k).push(c); });
  return G.size ? `<section class="permcard fixcard" aria-label="${tl("claimCard.2")}"><h2>${tl("claimCard.2")}<b class="num">${G.size}</b></h2>${[...G].slice(0, 3).map(([k, L]) => `<div class="permit"><div class="tx"><span class="t">${esc(L[0].it.title)}<i>${esc(pname(L[0].it.dept || ""))}</i></span><span class="s">${tl("fixCard.s", {v: esc(L[0].fixed_in || ""), n: L.length})}</span></div><div class="acts"><button class="btn sm fill press" data-item="${esc(k)}" data-fixgo>${tl("fixCard.go")}</button></div></div>`).join("")}</section>` : ""; };
document.addEventListener("click", (e) => { const b = e.target.closest?.("[data-fixgo]"); if (b) dirsOpenOf = b.dataset.item; }, true);
// A verdict from a list: the same call the result page makes, then the row goes at once.
async function verdict(key, ids, ok) {
  const [p, ...r] = key.split("/"), it = D.items.find((x) => iid(x) === key);
  // A verdict names the version that claimed the fix and the directive's own rev - the ones
  // this row showed. Only a row from an older board without them reads the item first.
  const cl = (id) => (it?.claimed || []).find((c) => c.id === id);
  const shown = ids.every((id) => cl(id)?.rev != null && cl(id)?.fixed_in);
  const det = shown ? null : await itemDetail(p, r.join("/")), ds = det?.directives || [];
  const dOf = (id) => (shown ? cl(id) : ds.find((d) => d.id === id) || cl(id)) || {};
  try { for (const id of ids) await post("/api/directive", {p, i: r.join("/"), id, v: dOf(id).fixed_in || it?.v, ok, verdict: ok ? "ok" : "again", rev: dOf(id).rev});
    if (it) it.claimed = (it.claimed || []).filter((c) => !ids.includes(c.id));
    toast(ok ? (ids.length > 1 ? tl("itemView.99", {n: ids.length}) : tl("verdict.1")) : tl("itemView.100"), 2200, ok ? "confirm" : "resent"); }
  catch (e) { if (isConflict(e)) conflictSheet(e.body, {v: it?.v, log: det?.log, reload: () => nav("item/" + key)}); else toast(e.message); }
  if (cur === "inbox" && !detail) SCREENS.inbox(inTab); drawChrome();
}
// ---------- 받은함 · 할 것: everything waiting on me, one list per kind ----------
// The one place the count comes from: the tab badge, the rail, the page title, home and the
// list itself all add up these same lists, so no two of them can disagree.
// Results pushed with a question (--ask), one group per project.
// Only while the question is still the reader's move (status.js): one sent back in words, with
// its question left open, is in the session's hands and in none of the 내 차례 lists.
// 오래된 순 on 할 것: the longest wait first. Kept in this browser ("genok-oldfirst").
// Beta "pai" off: no toggle, the old order.
const oldFirst = (set) => { if (!window.genokBeta?.("pai")) return false; try { if (set !== undefined) localStorage.setItem("genok-oldfirst", set ? "1" : "0"); return localStorage.getItem("genok-oldfirst") === "1"; } catch (e) { return false; } };
const byWait = (a, b) => oldFirst() ? byAt(b, a) : byAt(a, b);
// How long it has waited: 오늘, or N일 (web/queue-core.js age). "" with no time.
const waitAge = (at) => { const n = GQCore.age(at); return n == null ? "" : n ? tl("age.days", {n}) : tl("age.today"); };
const askQ = (x) => x.asked > 0 && stK(x) === "ask";
const askMine = () => D.items.filter((x) => askQ(x) && !snoozeOf(x));
const askGroups = (L = askMine()) => { const G = new Map();
  L.sort(byWait).forEach((x) => {
    const n = gname(x); if (!G.has(n)) G.set(n, {dept: n, items: []}); G.get(n).items.push(x); });
  return [...G.values()]; };
const askCard = ({dept, items}, btn = () => "") => `<div class="row"><span class="tx"><div class="t" style="font-size:16px">${esc(dept || tl("askCard.1"))}</div><div class="s"><span class="warn">${tl("askCard.2")}</span></div></span></div>`
  + items.map((x) => `<button class="turnr press" data-item="${esc(iid(x))}">${thumb(x, "ico sm")}<span class="tx"><div class="rt">${esc(x.title)}</div><div class="rs">${tl("askCard.3", {esc: esc(x.v || x.project || ""), asked: x.asked, ago: window.genokBeta?.("pai") ? waitAge(x.at) : ago(x.at)})}</div></span><span class="tag pending">${tl("askCard.4")}</span>${btn(x)}</button>`).join("");
// Session and routine kinds (attention.py): held lines, waiting/stuck/doubled sessions, failed
// routines. Part of the red number, so fetched whatever page is open, at most once a minute.
let att = null, attAt = 0;
const attL = (k) => (att && att[k]) || [];
// A session just answered from the chat screen (web/project.js keeps when) is not "my turn" in a
// fresh read either, until it has done something after the answer.
const attAns = () => { const f = window.PjAnswered; if (f && att) attL("rooms").forEach((r) => { if (r.turn && f(r.key, r.active)) r.turn = false; }); };
const attSig = () => att ? ["lost", "blocked", "stuck", "dup", "fail"].map((k) => attL(k).length).join() + "|" + attL("rooms").map((r) => r.key + ":" + r.unread + (r.turn ? "t" : "")).join() : "";
// While the page boots, the first fill must not redraw: the render that follows load() already
// includes it (boot waits for attP, up to half a second), so a redraw here is a second home draw.
let attP = null, attBooting = true;
function refreshAtt(force) {
  if (!force && Date.now() - attAt < 60e3) return;
  attAt = Date.now();
  attP = get("/api/attention" + (force ? "?fresh=1" : "")).then((d) => { const was = attSig(); att = d; attAns(); readOpenRoom(); const now = attSig();
    // The first fill of a quiet account changes nothing on screen (no signature -> all zero): no redraw.
    if (was !== now && !(was === "" && now === "0,0,0,0,0|")) { drawChrome(); if (!attBooting && (cur === "inbox" || cur === "home" || cur === "sessions" || cur === "lib" || cur === "dept")) redraw(); } }).catch(() => { attAt = Date.now() - 50e3; });   // asked again in 10 s, not a minute
}
// Claude permission prompts waiting for a press (permreq.py), answered in place. Asked every few
// seconds only on a PC where the permission hook has run; elsewhere once a minute.
// permHttp: whether the direct HTTP hooks (설정 › 연결 › 폰에서 허용·거절) are on; null until asked.
let PERM = [], permOn = false, permAt = 0, permHttp = null;
function refreshPerm() {
  if (document.hidden || Date.now() - permAt < (permOn ? 4e3 : 60e3)) return;
  permAt = Date.now();
  get("/api/permission").then((d) => { const was = PERM.map((p) => p.id).join(); permHttp = d.http ?? null; permOn = !!d.on || permHttp === true;
    // When Claude stops waiting for a press and asks in its own window: at + wait, in this screen's clock.
    const skew = Date.now() - (d.now ? d.now * 1e3 : Date.now());
    PERM = (d.pending || []).map((p) => { const w = p.wait ?? d.wait; return {...p, end: p.at && w ? (p.at + w) * 1e3 + skew : 0}; });
    if (was !== PERM.map((p) => p.id).join()) permDrawn(); }).catch(() => {});
}
const permDrawn = () => { drawChrome(); if (!detail && (cur === "inbox" || cur === "home")) redraw(); };
const permWho = (p) => { const r = attL("rooms").find((x) => x.key === p.sid); return r ? pname(r.dept) : p.cwd.split(/[\\/]/).filter(Boolean).pop() || "Claude"; };
// "1:52 뒤 Claude 창에서 물어요": counted down each second while the card is on screen.
const permLeft = (end) => { const s = Math.max(0, Math.ceil((end - Date.now()) / 1e3));
  return s ? tl("perm.left", {t: `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`}) : tl("perm.left0"); };
setInterval(() => document.querySelectorAll("[data-perm-end]").forEach((el) => { const t = permLeft(+el.dataset.permEnd); if (el.textContent !== t) el.textContent = t; }), 1e3);
const permCard = () => PERM.length ? `<section class="permcard" aria-label="${tl("perm.h")}"><h2>${tl("perm.h")}<b class="num">${PERM.length}</b></h2>${PERM.map((p) => `<div class="permit"><div class="tx"><span class="t">${esc(permWho(p))}<i>${esc(p.tool)}</i></span><code>${esc(p.text)}</code>${p.end ? `<span class="pleft num" data-perm-end="${Math.round(p.end)}">${permLeft(p.end)}</span>` : ""}${p.info ? `<span class="pleft">${tl("hook.info")}</span>` : ""}</div>${p.info ? "" : `<div class="acts"><button class="btn sm press" data-perm="${esc(p.id)}" data-allow="0">${tl("perm.deny")}</button><button class="btn sm fill press" data-perm="${esc(p.id)}" data-allow="1">${tl("perm.allow")}</button></div>`}</div>`).join("")}</section>` : "";
document.addEventListener("click", async (e) => {
  const b = e.target.closest?.("[data-perm]"); if (!b) return;
  const id = b.dataset.perm; (b.closest(".permit") || b.parentNode).querySelectorAll("button").forEach((x) => x.disabled = true);
  // 이 대화에서 허용 (data-scope) and the reason typed under 거절하고 이유 말하기 (data-note) go with the press.
  const note = "note" in b.dataset ? b.parentNode.querySelector("input").value.trim() : "";
  try { await post("/api/permission/answer", {id, allow: b.dataset.allow === "1", session: b.dataset.scope === "session" || undefined, note: note || undefined}); } catch (err) { toast(err.message); }
  PERM = PERM.filter((p) => p.id !== id); permDrawn();
});
setInterval(refreshPerm, 2e3);
// A room link: the department's session in the project page.
const roomGo = (dept, sid) => "project/" + encodeURIComponent(dept) + (sid ? "/" + sid : "");
// The session rail (wide screens): every conversation that is up, as its project's face and a
// state dot, fixed on the right. A press opens its chat in a pane beside the rail: the same chat
// as the room screen (project.js's pjEmbed). Where that chat is already on the page (the room
// screen, an item's chat tab) the press goes to the room instead: one chat a page.
const SR_ORD = {ask: 0, stuck: 1, work: 2, idle: 3};
const SR_T = LT(() => ({ask: tl("SESS_T.3"), stuck: tl("SESS_T.4"), work: tl("room.fBusy"), idle: tl("room.bgIdle")}));
// A session that ended on an error is over, not stuck: it kept its place in the column for good.
const srRooms = () => { const K = new Set(attL("stuck").map((r) => r.key));
  return attL("rooms").map((r) => ({r, s: globalThis.HookS?.(r) || (K.has(r.key) && r.state !== "ended" ? "stuck" : r.job === "blocked" || r.turn ? "ask" : r.job === "working" ? "work" : "idle")}))
    .sort((a, b) => SR_ORD[a.s] - SR_ORD[b.s] || (Date.parse(b.r.active) || 0) - (Date.parse(a.r.active) || 0)); };
let srOpen = "";
function drawSrail() {
  const el = document.getElementById("srail"); if (!el) return;
  const L = srRooms().slice(0, 10);
  el.hidden = !LAB3 || !L.length || cur === "project";
  if (el.hidden) { if (!LAB3 || cur === "project") srClose(); return; }
  el.setAttribute("aria-label", tl("srail.label"));
  setHTML(el, L.map(({r, s}) => `<button class="sb press${srOpen === r.key ? " on" : ""}" data-sr="${esc(r.key)}" data-s="${s}" title="${esc(pname(r.dept))} · ${esc(SR_T[s])}" aria-label="${esc(pname(r.dept))}, ${esc(SR_T[s])}">${r.icon ? esc(r.icon) : ic("chat")}<span class="sn">${esc(pname(r.dept))}</span><i></i></button>${s === "ask" || s === "stuck" ? `<span class="sk" data-s="${s}">${esc(SR_T[s])}</span>` : ""}`).join("")
    + `<span class="sp"></span><button class="sb all press" data-go="project" title="${esc(tl("menu.chat"))}" aria-label="${esc(tl("menu.chat"))}">${ic("rooms")}<span class="sn">${esc(tl("menu.chat"))}</span></button>`);
  if (!el.onclick) el.onclick = (e) => { const b = e.target.closest("[data-sr]"); if (b) srShow(b.dataset.sr); };
}
// An open pane's header follows the page: the state word in the language now chosen, and the
// state the chat is in now (it was drawn once, when the pane opened).
function srHeadSync() {
  const p = document.getElementById("spop"); if (!srOpen || !p || p.hidden) return;
  const x = srRooms().find((q) => q.r.key === srOpen), st = p.querySelector(".spop-h .s"); if (!st) return;
  const s = x ? x.s : st.dataset.s; st.dataset.s = s; st.textContent = SR_T[s] || "";
  const set = (sel, k) => { const e = p.querySelector(sel); if (e) { e.title = tl(k); e.setAttribute("aria-label", tl(k)); } };
  set("[data-srbig]", "room.bigger"); set("[data-srx]", "ui.close");
}
function srClose() { const p = document.getElementById("spop"); if (!p || p.hidden) return;
  srOpen = ""; p.hidden = true; p.replaceChildren();
  document.querySelectorAll("#srail .sb.on,#k3r .on").forEach((b) => b.classList.remove("on")); }
// `key` is a live session; without one (lab 3's column also lists projects with no chat up)
// `dept` names the project and the pane finds its session itself.
function srShow(key, dept) {
  const id = key || "d:" + dept;
  if (srOpen === id) return srClose();
  const x = key ? srRooms().find((q) => q.r.key === key) : null; if (!x && !dept) return;
  const r = x ? x.r : {dept, key: "", icon: (projects().find((g) => g.name === dept) || {}).icon || ""}, s = x ? x.s : "", p = document.getElementById("spop");
  srClose();
  if (typeof window.pjEmbed !== "function" || document.getElementById("pj-msgs")) return nav(roomGo(r.dept, r.key));
  srOpen = id;
  p.setAttribute("aria-label", pname(r.dept));
  p.innerHTML = `<div class="spop-h">${deptIco(r, "ico sm")}<span class="tx"><b class="t">${esc(pname(r.dept))}</b><span class="s" data-s="${s}">${esc(SR_T[s] || "")}</span></span><button class="ib press" data-srbig title="${esc(tl("room.bigger"))}" aria-label="${esc(tl("room.bigger"))}">${ic("full")}</button><button class="ib press" data-srx title="${esc(tl("ui.close"))}" aria-label="${esc(tl("ui.close"))}">${ic("x")}</button></div><div class="spop-b"></div>`;
  p.hidden = false;
  p.querySelector("[data-srbig]").onclick = () => { srClose(); nav(roomGo(r.dept, r.key)); };
  p.querySelector("[data-srx]").onclick = srClose;
  if (key) document.querySelector(`#srail [data-sr="${CSS.escape(key)}"]`)?.classList.add("on");
  [...document.querySelectorAll("#k3r [data-k3n]")].find((b) => (b.dataset.k3k || "d:" + b.dataset.k3n) === id)?.classList.add("on");
  const body = p.querySelector(".spop-b");
  let tries = 0;
  const load = () => window.pjEmbed(body, {sid: key, name: r.dept}).then((v) => {
    if (srOpen !== id || !body.isConnected || (v && v.session && (!key || v.session.id === key))) return;
    // A new node, not new contents: the chat that was drawn in the old one stops reading with it.
    const gone = body.cloneNode(false); gone.innerHTML = `<p class="spop-e">${tl("fl.gone")}</p>`; body.replaceWith(gone);
  }).catch(() => { if (srOpen === id && body.isConnected) setTimeout(load, ++tries < 5 ? 2000 : 10000); });
  load();
}
addEventListener("hashchange", srClose);
addEventListener("keydown", (e) => { if (e.key === "Escape" && srOpen) srClose(); }, true);
addEventListener("pointerdown", (e) => { if (srOpen && e.target.closest?.("#main, #rail, #k3l")) srClose(); });
// Rooms whose session said something since the room was last read, newest first.
// What counts as an unread conversation: one opened here before (r.seen) whose session has
// answered since and has finished its turn. Not counted: a session still mid-work, one never
// opened here (there is no "since last visit"), and one that ended more than a day ago.
const ROOM_STALE = 864e5;
const roomUnread = (r) => r.unread > 0 && r.seen !== false && r.job !== "working"
  && !(r.state === "ended" && Date.now() - (Date.parse(r.active) || 0) > ROOM_STALE);
// Mark conversations read (session ids; none given = every unread one). The count drops at
// once everywhere; the server moves the same marker that opening the conversation moves.
async function roomsRead(keys) {
  const K = keys || unreadRooms().map((r) => r.key);
  if (!K.length) return;
  attL("rooms").forEach((r) => { if (K.includes(r.key)) { r.unread = 0; r.seen = true; } });
  drawChrome();
  try { await post("/api/room-read-all", {keys: K}); } catch (e) { refreshAtt(true); }
}
// Opening a conversation reads it: its number goes from the sidebar and the list right away.
function readOpenRoom() {
  let h; try { h = decodeURIComponent(location.hash.slice(1)).split("/"); } catch { return; }
  if (h[0] !== "project" || !h[2] || document.hidden) return;
  const ids = h[2].split(","), K = attL("rooms").filter((r) => ids.includes(r.key) && r.unread > 0).map((r) => r.key);
  if (K.length) roomsRead(K);
}
addEventListener("hashchange", readOpenRoom);
const unreadRooms = () => attL("rooms").filter(roomUnread).sort((a, b) => (Date.parse(b.active) || 0) - (Date.parse(a.active) || 0));
async function nextUnread() {
  const d = await get("/api/attention?fresh=1").catch(() => null); if (d) { att = d; attAns(); attAt = Date.now(); }
  if (att && !att.sessions) return toast(tl("nextUnread.off"));
  const R = unreadRooms(); if (!R.length) return toast(tl("nextUnread.none"));
  let here = ""; try { const h = decodeURIComponent(location.hash.slice(1)).split("/"); if (h[0] === "project") here = h[2] || ""; } catch {}
  const r = R[(R.findIndex((x) => x.key === here) + 1) % R.length];
  closeSheet(); vwClose?.(); nav(roomGo(r.dept, r.key));
}
// Sessions that cannot go on without the person: the permission waits `claude agents` names, plus
// every room the server says is their turn (a question, a plan, a result waiting for 승인),
// once each. Working sessions are never in it (sessions_ctl.waits_on_person).
const blockedL = () => { const L = attL("blocked").filter((a) => a.needs && !PERM.some((p) => p.sid === a.session)), seen = new Set(L.map((a) => a.session).filter(Boolean));
  return L.concat(attL("rooms").filter((r) => r.turn && !seen.has(r.key)).map((r) => ({dept: r.dept, session: r.key, needs: r.needs || "input needed", agent: r.agent, mark: r.mark}))); };
// The rows of 할 일 that are not results, as [key, mark] for 나중에 보기 (asideOf).
const SEC_ROW = {
  unsent: (x) => ["u:" + iid(x), x.v + "|" + x.unsent], undeliv: (b) => ["w:" + iid(b), String(b.asked || "")],
  lost: (r) => ["l:" + r.dept + "/" + (r.session || ""), r.n + "|" + r.at], blocked: (a) => ["s:" + (a.session || a.dept), a.needs + "|" + (a.mark || "")],
  stuck: (r) => ["k:" + r.key, String(r.stuck || "")], dup: (r) => ["d:" + r.dept, String(r.extra)], fail: (t) => ["f:" + t.id, String(t.last || "")]};
const secAside = (k, r) => !!asideOf(...SEC_ROW[k](r));
// z: the same sections holding only what was put aside (the 나중에 tab).
const todoSecs = (z = false) => {
  const zi = z ? D.items.filter(snoozeOf) : [], asks = z ? zi.filter(askQ) : askMine(), asked = new Set(asks.map(iid));
  return [
    // Grouped by project for the list, counted by result: every other kind counts its rows too.
    {k: "ask", n: tl("todoSecs.1"), i: "ask", hot: 1, L: askGroups(asks), cnt: (L) => L.reduce((a, g) => a + g.items.length, 0), peek: (g) => g.dept},
    // No "claim" kind: a request a session says it fixed is checked on the result page, when the
    // person looks at that version. Listed here it flooded 내 차례 (user, 2026-10-02).
    {k: "look", n: tl("search.4"), i: "lib", L: z ? zi.filter((x) => stMine(x) && !asked.has(iid(x)) && !libHide.has(iid(x))).sort(byWait) : (window.genokBeta?.("pai") ? myTurn().filter((x) => !asked.has(iid(x))).sort(byWait) : myTurn().filter((x) => !asked.has(iid(x)))), peek: (x) => x.title},
    {k: "unsent", n: tl("itemView.128"), i: "up", L: D.items.filter((x) => x.unsent > 0).sort(byWait), peek: (x) => x.title},
    // Sent, but the department has not taken it yet. Ones still unsent are the row above.
    {k: "undeliv", n: tl("todoSecs.2"), i: "wait", L: D.board.filter((b) => b.state === "waiting" && !(b.unsent > 0)).sort((a, b) => (b.asked || "").localeCompare(a.asked || "")), peek: (b) => b.title},
    // Lines typed into a room that no session took: they sit there until one is woken.
    {k: "lost", n: tl("todoSecs.lost"), i: "chat", hot: 1, c: "orange", L: attL("lost"), peek: (r) => r.dept},
    // Only waits that name what they need (a permission, a question). A session that has merely
    // finished its turn is chat state: it is the quiet unread mark on 모든 대화, never counted here.
    {k: "blocked", n: tl("todoSecs.blocked"), i: "shield", hot: 1, c: "blue", L: blockedL(), peek: (a) => a.dept},
    {k: "stuck", n: tl("todoSecs.stuck"), i: "warn", hot: 1, L: attL("stuck"), peek: (r) => r.dept},
    {k: "dup", n: tl("todoSecs.dup"), i: "copy", L: attL("dup"), peek: (r) => r.dept},
    {k: "fail", n: tl("todoSecs.fail"), i: "clock", hot: 1, L: attL("fail"), peek: (t) => t.name},
  ].map((s) => turnHid(s.k) ? {...s, L: []} : SEC_ROW[s.k] ? {...s, L: s.L.filter((r) => secAside(s.k, r) === z)} : s);
};
// 알림 고르기: the kinds of 내 차례 the person keeps. A kind switched off is gone from the list,
// the count and home, and makes no sound - the work itself is still under 결과물 and 대화.
const TURN_KINDS = {look: ["look"], ask: ["ask"], send: ["unsent", "undeliv"], session: ["lost", "blocked", "stuck", "dup"], routine: ["fail"]};
const turnOffL = () => window.LOOP_TURN?.off() || [];
const turnHid = (k) => turnOffL().some((g) => TURN_KINDS[g]?.includes(k));
function turnSheet() {
  const sw = (on, attr, label) => `<button type="button" class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" ${attr} aria-label="${esc(label)}"></button>`;
  const row = (t, d, s, c = "") => `<div class="tkrow${c}"><div class="tx"><div class="t">${esc(t)}</div><div class="s">${esc(d)}</div></div>${s}</div>`;
  const off = turnOffL();
  const N = {look: [tl("turn.k.look"), tl("turn.k.look.d")], ask: [tl("turn.k.ask"), tl("turn.k.ask.d")], send: [tl("turn.k.send"), tl("turn.k.send.d")],
    session: [tl("turn.k.session"), tl("turn.k.session.d")], routine: [tl("turn.k.routine"), tl("turn.k.routine.d")]};
  sheet(`<h2 style="margin:0 0 4px">${tl("turn.h")}</h2><p class="hint" style="margin:0 0 12px">${tl("turn.d")}</p>
    ${Object.keys(TURN_KINDS).map((g) => row(N[g][0], N[g][1], sw(!off.includes(g), `data-turnk="${g}"`, N[g][0]))).join("")}
    ${row(tl("mode.k.wait"), tl("mode.k.wait.d"), sw(!!window.LOOP_TURN?.wait(), "data-turnwait", tl("mode.k.wait")), " tkwait")}`, (box) => {
    box.addEventListener("click", (e) => {
      const b = e.target.closest("[data-turnk],[data-turnwait]");
      if (!b || !window.LOOP_TURN) return;
      const on = b.getAttribute("aria-checked") !== "true";
      const paint = (v) => { b.classList.toggle("on", v); b.setAttribute("aria-checked", String(v)); };
      paint(on);
      const body = b.dataset.turnk
        ? {turn_off: Object.keys(TURN_KINDS).filter((g) => g === b.dataset.turnk ? !on : turnOffL().includes(g))}
        : {session_wait_notify: on};
      const after = () => { try { drawChrome(); if (cur === "inbox" || cur === "home") render(); } catch {} };
      window.LOOP_TURN.set(body).catch((er) => { paint(!on); after(); toast(er.message); });
      after();
    });
  });
}
// What a waiting session needs, in the person's language (the CLI names it in English).
// 허용 / 거절 can be answered here only for Codex; a Claude Code session is answered in its own window.
const needsText = (n, agent) => n === "permission prompt" ? (agent === "codex" ? tl("att.needs.perm") : tl("att.needs.perm.open")) : n === "input needed" ? tl("att.needs.input") : n || tl("att.blocked.s");
const secN = (s) => s.cnt ? s.cnt(s.L) : s.L.length;
const todoTotal = (T) => T.reduce((a, s) => a + secN(s), 0);
const todoCount = () => { refreshAtt(); return window.GQ ? GQ.count() : todoTotal(todoSecs()); };   // 지금 필요한 일 (web/queue.js): 결정 only
// The number on the installed app's icon, two switches, both on until turned off: "res" counts what
// concerns a result (questions, results to look at, feedback not yet taken), "chat" the sessions
// that wait. v2-badge is the earlier three-way choice (off | res), read until a switch is touched.
const BADGE_RES = ["ask", "look", "unsent", "undeliv"];
const badgeOn = (k) => { const v = lsGet("v2-badge-" + k), old = lsGet("v2-badge");
  return v ? v === "1" : old !== "off" && !(old === "res" && k === "chat"); };
const badgeCount = () => window.GQ ? (badgeOn("res") || badgeOn("chat") ? GQ.count() : 0) : todoTotal(todoSecs().filter((s) => badgeOn(BADGE_RES.includes(s.k) ? "res" : "chat"))) + (badgeOn("chat") ? PERM.length : 0);

// ---------- 받은함: 할 것 · 소식 · 기록 (Linear's Inbox; HEY's Imbox · Feed · Paper Trail) ----------
const INBOX_T = LT(() => ([["do", tl("INBOX_T.1")], ["later", tl("palActs.2")], ["news", tl("bellSearch.1")], ["log", tl("itemView.20")]]));
let inTab = "do";
SCREENS.inbox = function (tab) {
  inTab = INBOX_T.some(([k]) => k === tab) ? tab : "do";
  const T = todoSecs(), todo = todoTotal(T), news = newsUnread(), unread = news || unreadRooms().length;
  const Z = window.GQ ? null : todoSecs(true), aside = window.GQ ? GQ.asideCount() : todoTotal(Z), now = window.GQ ? GQ.count() : todo;
  const tabs = `<div class="chips ibtabs" data-sk="ibt" role="tablist">${INBOX_T.map(([k, n]) => `<button class="chip press ${inTab === k ? "on" : ""}" role="tab" aria-selected="${inTab === k}" data-ibt="${k}">${k === "do" && window.GQ ? `<span class="gq-tl">${tl("gq.tab")}</span><span class="gq-ts">${tl("gq.tab.s")}</span>` : n}${k === "do" && now ? ` <em class="num">${now}</em>` : k === "news" && news ? ` <em class="num">${news}</em>` : k === "later" && aside ? ` <i class="ltn">${aside}</i>` : ""}</button>`).join("")}
    <span class="sp"></span><span class="ibtools">${inTab === "do" && stackQueue().length ? `<button class="chip press ibcatch" data-stack aria-label="${tl("inbox.2")}" title="${tl("inbox.2")}">${ic("stack")}<span>${tl("stackOpen.2")}</span></button>` : ""}${inTab === "news" ? `<button class="chip press ibcatch" data-iball aria-label="${tl("sx.allread")}" title="${tl("sx.allread")}"${unread ? "" : " disabled"}>${icl("read")}<span>${tl("sx.allread")}</span></button>` : ""}<button class="chip press ibcatch${turnOffL().length ? " has" : ""}" data-turnpick aria-label="${tl("turn.h")}" title="${tl("turn.h")}">${ic("bell")}<span>${turnOffL().length ? tl("turn.offn", {n: turnOffL().length}) : tl("turn.btn")}</span></button>${inTab === "do" && window.genokBeta?.("pai") ? `<button class="chip press ibcatch${oldFirst() ? " on" : ""}" data-oldfirst aria-pressed="${oldFirst()}" aria-label="${tl("age.sort")}" title="${tl("age.sort.h")}">${ic("sort")}<span>${tl("age.sort")}</span></button>` : ""}<button class="chip press ibcatch" data-catch aria-label="${tl("inbox.3")}" title="${tl("inbox.3")}">${ic("clock")}<span>${tl("inbox.3")}</span></button></span></div>`;
  if (window.GQ && inTab === "do") GQ.inbox(tabs + catchBar());
  else if (window.GQ && inTab === "later") GQ.aside(tabs);
  else if (inTab === "later") inboxDo(tabs, Z, aside, true);
  else (inTab === "news" ? inboxNews : inTab === "log" ? inboxLog : inboxDo)(tabs + catchBar(), T, todo);
  const of = V().querySelector("[data-oldfirst]"); if (of) of.onclick = () => { oldFirst(!oldFirst()); SCREENS.inbox(inTab); };
  // 모두 읽음 (소식 only; 할 일 has its own on 신규 and 전부 나중에 on 답변): the news marker and every unread conversation at once.
  const ra = V().querySelector("[data-iball]"); if (ra) ra.onclick = async () => {
    seeAlerts(new Date().toISOString());
    await roomsRead();
    toast(tl("sx.allread.done")); SCREENS.inbox(inTab); drawChrome();
  };
  return {right: bellSearch()};
};
// 할 것: questions first, then what to look at, then what is stuck. Every row can be walked
// with J/K and acted on in place; 하나씩 takes the first three kinds as a stack of cards.
function inboxDo(top, T, n, back = false) {
  const S = Object.fromEntries(T.map((s) => [s.k, s.L]));
  // back: the 나중에 tab, where the action brings the row back to 할 일.
  const act = (k, r) => { const [key, mark] = SEC_ROW[k] ? SEC_ROW[k](r) : [iid(r)]; return back ? backBtn(key) : laterBtn(key, mark); };
  const sec = (k, row, more = "", L = S[k]) => { const s = T.find((x) => x.k === k);
    return L.length ? `<div class="card">${more === null ? `<div style="height:8px"></div>` : `<div class="ch"><h2>${s.n}</h2><span class="n num">${L.length}</span><span class="sp"></span>${more}</div>`}${L.map((r) => row(r, act(k, r))).join("")}<div style="height:8px"></div></div>` : ""; };
  // Kinds that are answered the same way share one card: comments on their way out, and sessions
  // that need a look. Each row says in its own line what it is.
  const grp = (name, parts) => { const rows = parts.map(([k, row]) => S[k].map((r) => row(r, act(k, r))).join("")).join(""), cnt = parts.reduce((a, [k]) => a + S[k].length, 0);
    return cnt ? `<div class="card"><div class="ch"><h2>${name}</h2><span class="n num">${cnt}</span></div>${rows}<div style="height:8px"></div></div>` : ""; };
  // 할 일 only: 신규 above 답변, each head with its number and its one bulk action.
  const K = turnKinds(T), nNew = back ? 0 : todoTotal(K.fresh), lean = {proj: oneProj(), note: new Set(back ? [] : (S.unsent || []).map(iid))},
    look = (L) => sec("look", (x, b) => itemRow(x, false, lean).replace('class="row press"', 'class="row press" data-tk').replace(/<\/button>$/, b + "</button>"), back ? "" : null, L);   // under 신규 / 답변 the head above names the card
  // Lab 4: what waits for a look stands as verdict cards (web/verdict.js), one bar over both lists.
  const rdW = RD && !back && window.RdV, rdL = rdW ? {fresh: RdV.list(K.fresh.find((s) => s.k === "look").L, "fresh"), reply: RdV.list(K.reply.find((s) => s.k === "look").L, "reply")} : null;
  const rdTop = rdW && rdL.fresh.full.length + rdL.reply.full.length ? RdV.bar([...rdL.fresh.full, ...rdL.reply.full]) : "";
  const lookAt = (w, L) => rdW ? (rdL[w].shown.length ? `<div data-rdw="${w}">${RdV.grid(rdL[w].shown)}</div>` : "") : look(L);
  const head = (name, cnt, attr, label, icon) => `<div class="sec ibsec"><span>${name}</span><em class="num">${cnt}</em><span class="sp"></span><button class="ib press" ${attr} aria-label="${label}" title="${label}">${icon}</button></div>`;
  const sendRow = (x, b) => `<div class="row">${thumb(x, "ico sm")}<button class="tx press" data-item="${esc(iid(x))}" style="text-align:left"><div class="t" style="font-size:16px">${esc(x.title)}</div><div class="s">${tl("inboxDo.1", {esc: esc(pname(x.dept)), unsent: x.unsent}).replace(/^\s*·\s*/, "")}</div></button><button class="btn sm fill press" data-sendc="${esc(iid(x))}">${tl("nextCard.6")}</button>${b}</div>`;
  const waitRow = (b, lb) => `<button class="row press" data-tk data-item="${esc(iid(b))}">${thumb(b, "ico sm")}<span class="tx"><div class="t" style="font-size:16px">${esc(b.title)}</div><div class="s">${tl("inboxDo.2", {esc: esc(pname(b.dept)), ago: ago(b.asked)})}</div></span><span class="tag pending">${tl("deptView.2")}</span>${lb}</button>`;
  const lostRow = (r, b) => `<div class="row" data-tk><span class="ico sm c-orange">${ic("chat")}</span><button class="tx press" data-go="${esc(roomGo(r.dept, r.session))}" style="text-align:left"><div class="t" style="font-size:16px">${esc(pname(r.dept))}</div><div class="s"><span class="warn">${tl("att.lost.n", {n: r.n})}</span> · ${ago(r.at)}</div></button><button class="btn sm press" data-lostdrop="${esc(r.dept)}" data-lostses="${esc(r.session || "")}">${tl("att.lost.drop")}</button>${b}</div>`;
  const blockRow = (a, b) => `<button class="row press" data-tk data-go="${esc(roomGo(a.dept, a.session))}"><span class="ico sm c-blue">${ic(a.needs === "permission prompt" ? "shield" : "chat")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(pname(a.dept))}</div><div class="s">${esc(needsText(a.needs, a.agent))}</div></span>${b}${ic("chev", "i go")}</button>`;
  const stuckRow = (r, b) => `<button class="row press" data-tk data-go="${esc(roomGo(r.dept, r.key))}"><span class="ico sm c-red">${ic("warn")}</span><span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}</div><div class="s">${esc(r.stuck_hint || r.stuck || "")}</div></span>${b}${ic("chev", "i go")}</button>`;
  const dupRow = (r, b) => `<button class="row press" data-tk data-go="${esc(roomGo(r.dept))}"><span class="ico sm c-teal">${ic("copy")}</span><span class="tx"><div class="t" style="font-size:16px">${r.icon ? esc(r.icon) + " " : ""}${esc(pname(r.dept))}</div><div class="s">${tl("att.dup.s", {n: r.extra + 1})}</div></span>${b}${ic("chev", "i go")}</button>`;
  const failRow = (t, b) => `<button class="row press" data-tk data-go="routines"><span class="ico sm c-red">${ic("clock")}</span><span class="tx"><div class="t" style="font-size:16px">${esc(t.name)}</div><div class="s">${t.last ? ago(t.last) : ""}${t.note ? " · " + esc(t.note) : ""}</div></span>${b}${ic("chev", "i go")}</button>`;
  // 답변 counts what sits right under it (results and questions): the cards after have their own number.
  const nRep = back ? 0 : K.reply.find((s) => s.k === "look").L.length + secN(T.find((s) => s.k === "ask"));
  const pc = back ? "" : permCard();
  V().innerHTML = top + rdTop + pc + (n || pc ? "" : back ? `<div class="card plan none"><p>${tl("later.none")}</p></div>` : (window.LOOP_HOME_EMPTY ? window.LOOP_HOME_EMPTY() : `<div class="card plan none"><p>${tl("inboxDo.3")}</p></div>`))
    + (nNew ? head(tl("st.fresh"), nNew, "data-readnew", tl("sx.allread"), icl("read")) + lookAt("fresh", K.fresh.find((s) => s.k === "look").L) : "")
    + (!back && nRep ? head(tl("st.reply"), nRep, "data-laterall", tl("later.all"), ic("clock")) : "")
    + (back ? look(S.look) : lookAt("reply", K.reply.find((s) => s.k === "look").L))
    + (S.ask.length ? `<div class="card"><div class="ch"><h2>${tl("inboxDo.4")}</h2><span class="n num">${secN(T.find((s) => s.k === "ask"))}</span></div>${S.ask.map((g) => `<div class="askg" data-tk>${askCard(g, (x) => act("ask", x))}</div>`).join("")}<div style="height:8px"></div></div>` : "")
    + grp(tl("inbox.g.send"), [["unsent", sendRow], ["undeliv", waitRow]])
    + grp(tl("inbox.g.sess"), [["blocked", blockRow], ["lost", lostRow], ["stuck", stuckRow], ["dup", dupRow], ["fail", failRow]])
    + (n ? listKeyBar() : "");
  V().querySelectorAll("[data-sendc]").forEach((b) => b.onclick = async (e) => { e.stopPropagation();
    const [p, ...r] = b.dataset.sendc.split("/"), it = D.items.find((x) => iid(x) === b.dataset.sendc); b.disabled = true;
    try { const d = await post("/api/comments/send", {p, i: r.join("/"), v: it?.v});
      toast(d.entry?.live ? tl("inboxDo.8", {p0: pname(it?.dept || "") || tl("sendNow.1")}) : tl("inboxDo.9", {jo: jo(pname(it?.dept || "") || tl("sendNow.1"), "가", "이")})); await load(); SCREENS.inbox("do"); drawChrome(); }
    catch (err) { toast(err.message); b.disabled = false; } });
  const rn = V().querySelector("[data-readnew]"); if (rn) rn.onclick = () => readFresh(K.fresh);
  const la = V().querySelector("[data-laterall]"); if (la) la.onclick = () => laterAll(K.reply.filter((s) => s.k === "look" || s.k === "ask"), tl("later.all.done", {n: nRep}));
  triMark();
}
// 소식: read only, newest first by day. A row is read when it is opened or ticked on its own;
// 모두 읽음 reads the rest (the old 알림 marker).
function inboxNews(top) {
  const L = newsList(), groups = {}; L.forEach((a) => (groups[day(a.at)] ||= []).push(a));
  V().innerHTML = top + (Object.entries(groups).map(([d, xs]) => `<div class="sec">${d}</div><div class="card">${xs.map((a) => `<div class="nrow" data-nk="${esc(newsKey(a))}"><button class="row press" ${a.item ? `data-item="${esc(a.item)}"` : a.talk ? `data-talk="${esc(a.talk)}"` : ""}>${menuIco(a, "ico sm")}<span class="tx"><div class="t" style="font-size:16px;white-space:normal">${newsNew(a) ? `<i class="nd" aria-label="${tl("inboxNews.1")}"></i>` : ""}${esc(a.t)}</div><div class="s">${esc(a.s)} · ${ago(a.at)}</div></span></button>${newsNew(a) ? `<button class="ib press nread" aria-label="${tl("inboxNews.read")}" title="${tl("inboxNews.read")}">${ic("check")}</button>` : ""}</div>`).join("")}</div>`).join("")
    || `<div class="card plan none">${mEmpty("emptyDone")}<p>${tl("inboxNews.2", {p0: NEWS_H / 24})}</p></div>`);
  V().querySelectorAll(".nrow").forEach((r) => {
    r.querySelector(".row").addEventListener("click", () => { if (r.querySelector(".nd")) readNews([r.dataset.nk]); });
    // Ticked in place: the dot and the tick go, the counts follow, nothing else is redrawn.
    r.querySelector(".nread")?.addEventListener("click", () => { readNews([r.dataset.nk]); r.querySelector(".nd").remove(); r.querySelector(".nread").remove();
      const n = newsUnread(), em = V().querySelector('[data-ibt="news"] em');
      if (n) em.textContent = n; else em.remove();
      V().querySelector("[data-iball]").disabled = !n && !unreadRooms().length; drawChrome(); }); });
}
// 기록 (paper trail): what I handed off and how far each got, and what I approved lately.
const TRAIL_C = LT(() => ([["waiting", tl("deptView.2"), "pending", tl("TRAIL_C.1")], ["delivered", tl("itemView.123"), "", tl("TRAIL_C.2")], ["ack", tl("deptView.3"), "work", tl("TRAIL_C.3")], ["approved", tl("STATUS_T.4"), "approved", tl("TRAIL_C.4")]]));
let trailF = null;
function inboxLog(top) {
  const of = (k) => k === "approved" ? D.items.filter((x) => x.status === "approved" && recent(x.at, 24 * 7)).sort(byAt)
    : D.board.filter((b) => b.state === k).sort((a, b) => (b.asked || "").localeCompare(a.asked || ""));
  if (!trailF || !TRAIL_C.some(([k]) => k === trailF)) trailF = (TRAIL_C.find(([k]) => of(k).length) || TRAIL_C[1])[0];
  const [, name, tag, hint] = TRAIL_C.find(([k]) => k === trailF), L = of(trailF);
  V().innerHTML = top + `<div class="chips lfil" data-sk="trailf">${TRAIL_C.map(([k, n]) => `<button class="chip press ${trailF === k ? "on" : ""}" data-trail="${k}">${n} <em class="num">${of(k).length}</em></button>`).join("")}</div>
    ${L.length ? `<div class="card">${L.slice(0, 40).map((b) => `<button class="row press treq" data-item="${esc(iid(b))}">${thumb(b, "ico sm")}<span class="tx">
      <div class="t">${esc(b.title)}</div>${b.said ? `<div class="said">${esc(b.said)}</div>` : ""}
      <div class="s">${esc(pname(gname(b)))} · ${b.v ? esc(b.v) + " · " : ""}${ago(b.asked || b.at)}</div></span>${tag ? `<span class="tag ${tag}">${name}</span>` : ""}</button>`).join("")}<div style="height:6px"></div></div>`
    : `<div class="card plan"><span class="ico c-grey">${ic("check")}</span><p>${tl("inboxLog.1", {name})}</p></div>`}
    <p class="foot-hint">${tl("inboxLog.2", {hint})}</p>`;
  V().querySelectorAll("[data-trail]").forEach((c) => c.onclick = () => { trailF = c.dataset.trail; SCREENS.inbox("log"); });
}

const same = (a, b) => (a || "").replace(/[\\/]+$/, "").toLowerCase() === (b || "").replace(/[\\/]+$/, "").toLowerCase();
const pref = (k, v) => { try { if (v === undefined) return localStorage.getItem("v2-" + k) === "1"; localStorage.setItem("v2-" + k, v ? "1" : "0"); } catch { return false; } };
