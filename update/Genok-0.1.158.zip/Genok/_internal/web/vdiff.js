// Pure helpers for the code / document / spreadsheet viewers, shared by the DOM code in
// types.js (loaded as a browser global before it) and the node tests. No DOM here on purpose:
// the math and the "what changed" reading live here where they can be tested, matching how
// vcompare.js splits the pixel math off from the canvas work.

// ---- line diff (code, plain text) ---------------------------------------------------------
// Longest-common-subsequence over lines, with the shared head and tail trimmed first so the
// quadratic table only covers the part that actually differs. Returns rows in reading order:
//   {type: "same"|"add"|"del", a: <1-based old line no|null>, b: <1-based new line no|null>, text}
// A change shows as a "del" row then an "add" row, which the side-by-side and unified views pair.
function lineDiff(aText, bText) {
  const a = splitLines(aText), b = splitLines(bText);
  const rows = [];
  let i0 = 0, j0 = 0, ia = a.length, ib = b.length;
  while (i0 < ia && j0 < ib && a[i0] === b[j0]) { rows.push(mk("same", i0 + 1, j0 + 1, a[i0])); i0++; j0++; }
  const tail = [];
  while (ia > i0 && ib > j0 && a[ia - 1] === b[ib - 1]) { ia--; ib--; tail.push([ia, ib]); }
  const mid = lcsRows(a, b, i0, ia, j0, ib);
  for (const r of mid) rows.push(r);
  for (let k = tail.length - 1; k >= 0; k--) rows.push(mk("same", tail[k][0] + 1, tail[k][1] + 1, a[tail[k][0]]));
  return rows;
}

function mk(type, a, b, text) { return {type, a: a || null, b: b || null, text: text == null ? "" : text}; }
function splitLines(t) { return (t == null ? "" : String(t)).replace(/\r\n?/g, "\n").split("\n"); }

// LCS table over a[loA..hiA) vs b[loB..hiB); emits del/add/same rows for that window.
function lcsRows(a, b, loA, hiA, loB, hiB) {
  const n = hiA - loA, m = hiB - loB;
  if (n === 0 && m === 0) return [];
  if (n === 0) { const r = []; for (let j = loB; j < hiB; j++) r.push(mk("add", null, j + 1, b[j])); return r; }
  if (m === 0) { const r = []; for (let i = loA; i < hiA; i++) r.push(mk("del", i + 1, null, a[i])); return r; }
  // dp[i][j] = LCS length of a[loA+i..) and b[loB+j..)
  const dp = [];
  for (let i = 0; i <= n; i++) dp.push(new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = a[loA + i] === b[loB + j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const rows = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[loA + i] === b[loB + j]) { rows.push(mk("same", loA + i + 1, loB + j + 1, a[loA + i])); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { rows.push(mk("del", loA + i + 1, null, a[loA + i])); i++; }
    else { rows.push(mk("add", null, loB + j + 1, b[loB + j])); j++; }
  }
  while (i < n) { rows.push(mk("del", loA + i + 1, null, a[loA + i])); i++; }
  while (j < m) { rows.push(mk("add", null, loB + j + 1, b[loB + j])); j++; }
  return rows;
}

// Pair diff rows into side-by-side lines: {left:{no,text}|null, right:{no,text}|null, type}.
// A del immediately followed by an add is shown on the same line (a changed line); lone dels and
// adds keep their own side.
function sideBySide(rows) {
  const out = [];
  for (let k = 0; k < rows.length; k++) {
    const r = rows[k];
    if (r.type === "same") { out.push({type: "same", left: {no: r.a, text: r.text}, right: {no: r.b, text: r.text}}); }
    else if (r.type === "del") {
      const nx = rows[k + 1];
      if (nx && nx.type === "add") { out.push({type: "chg", left: {no: r.a, text: r.text}, right: {no: nx.b, text: nx.text}}); k++; }
      else out.push({type: "del", left: {no: r.a, text: r.text}, right: null});
    } else { out.push({type: "add", left: null, right: {no: r.b, text: r.text}}); }
  }
  return out;
}

// Counts for a "+N -M" badge.
function diffStat(rows) {
  let add = 0, del = 0;
  for (const r of rows) { if (r.type === "add") add++; else if (r.type === "del") del++; }
  return {add, del};
}

// ---- word diff (documents) ----------------------------------------------------------------
// LCS over word/space tokens. Returns runs {type:"same"|"add"|"del", text} so a document compare
// can paint added and removed text inline. Whitespace is its own token so wording, not spacing,
// drives the match.
function wordDiff(aText, bText) {
  const a = tokenizeWords(aText), b = tokenizeWords(bText);
  const n = a.length, m = b.length;
  if (!n && !m) return [];
  const dp = [];
  for (let i = 0; i <= n; i++) dp.push(new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const runs = [];
  const push = (type, text) => {
    const last = runs[runs.length - 1];
    if (last && last.type === type) last.text += text; else runs.push({type, text});
  };
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { push("same", a[i]); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { push("del", a[i]); i++; }
    else { push("add", b[j]); j++; }
  }
  while (i < n) { push("del", a[i]); i++; }
  while (j < m) { push("add", b[j]); j++; }
  return runs;
}

function tokenizeWords(t) { return (t == null ? "" : String(t)).match(/\s+|[^\s]+/g) || []; }

// ---- spreadsheet ---------------------------------------------------------------------------
// Column letters from a 0-based index: 0->A, 25->Z, 26->AA. A1 reference from 0-based row/col.
function colName(idx) {
  let n = Math.max(0, Math.floor(idx)), s = "";
  do { s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26) - 1; } while (n >= 0);
  return s;
}
function cellRef(row, col) { return colName(col) + (Math.floor(row) + 1); }

// Parse CSV/TSV text into rows of string cells (RFC 4180: quoted fields may hold the separator,
// newlines and doubled quotes). `sep` is "," or "\t"; a trailing blank line is dropped.
function parseDSV(text, sep) {
  sep = sep || ",";
  const s = (text == null ? "" : String(text)).replace(/\r\n?/g, "\n");
  const rows = [];
  let row = [], cell = "", q = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === '"') { if (s[i + 1] === '"') { cell += '"'; i++; } else q = false; }
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === sep) { row.push(cell); cell = ""; }
    else if (c === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  if (rows.length && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === "") rows.pop();
  return rows;
}

// Cell-by-cell compare of two sheets (arrays of row arrays). Rows are matched by index, which is
// what a "changed cells" review wants; extra rows/cols on either side are marked added/removed.
// Returns {rows: [{cells:[{ref,a,b,status}], status}], cols, addedRows, removedRows, addedCols,
// removedCols, changed} where status is "same"|"changed"|"added"|"removed".
function sheetDiff(aRows, bRows) {
  aRows = aRows || []; bRows = bRows || [];
  const nRows = Math.max(aRows.length, bRows.length);
  const wA = aRows.reduce((m, r) => Math.max(m, r.length), 0);
  const wB = bRows.reduce((m, r) => Math.max(m, r.length), 0);
  const cols = Math.max(wA, wB);
  const out = {rows: [], cols, addedRows: 0, removedRows: 0, addedCols: Math.max(0, wB - wA), removedCols: Math.max(0, wA - wB), changed: 0};
  for (let r = 0; r < nRows; r++) {
    const ra = aRows[r], rb = bRows[r];
    let rstatus = "same";
    if (ra == null) { rstatus = "added"; out.addedRows++; }
    else if (rb == null) { rstatus = "removed"; out.removedRows++; }
    const cells = [];
    for (let c = 0; c < cols; c++) {
      const av = ra && c < ra.length ? String(ra[c]) : null;
      const bv = rb && c < rb.length ? String(rb[c]) : null;
      let status = "same";
      if (av == null && bv == null) status = "same";
      else if (av == null) status = "added";
      else if (bv == null) status = "removed";
      else if (av !== bv) status = "changed";
      if (status !== "same") { out.changed++; if (rstatus === "same") rstatus = "changed"; }
      cells.push({ref: cellRef(r, c), a: av, b: bv, status});
    }
    out.rows.push({cells, status: rstatus});
  }
  return out;
}

// ---- lightweight syntax highlight ---------------------------------------------------------
// A generic tokenizer, no per-language grammar beyond a keyword set: it paints line and block
// comments, strings, numbers and keywords, which is enough to read a diff. Returns, per input
// line, a list of {t, v} tokens (t: "com"|"str"|"num"|"kw"|"txt"). Deliberately small; it never
// runs the code and cannot emit HTML.
const KEYWORDS = {
  js: "await async break case catch class const continue default delete do else export extends finally for from function if import in instanceof let new of return static super switch this throw try typeof var void while yield null true false undefined",
  py: "and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield None True False self",
  c: "auto break case char const continue default do double else enum extern float for goto if int long return short signed sizeof static struct switch typedef union unsigned void volatile while bool true false include define",
  go: "break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var nil true false",
  rust: "as break const continue crate else enum extern fn for if impl in let loop match mod move mut pub ref return self struct super trait type unsafe use where while true false",
  css: "important media keyframes import from to and not only screen print",
  sql: "select from where insert update delete into values create table drop alter join left right inner outer on group by order having limit as and or not null distinct",
  shell: "if then else elif fi for while do done case esac function return export local echo cd exit",
};
const LANG_BY_EXT = {
  ".js": "js", ".mjs": "js", ".cjs": "js", ".jsx": "js", ".ts": "js", ".tsx": "js", ".json": "js",
  ".py": "py", ".pyw": "py",
  ".c": "c", ".h": "c", ".cpp": "c", ".cc": "c", ".hpp": "c", ".cs": "c", ".java": "c", ".kt": "c", ".swift": "c",
  ".go": "go", ".rs": "rust",
  ".css": "css", ".scss": "css", ".less": "css",
  ".sql": "sql",
  ".sh": "shell", ".bash": "shell", ".zsh": "shell",
};
const LINE_COMMENT = {js: "//", c: "//", go: "//", rust: "//", py: "#", shell: "#", sql: "--", css: null};

function langOf(filename) {
  const ext = "." + String(filename || "").split(".").pop().toLowerCase();
  return LANG_BY_EXT[ext] || null;
}

// Highlight a whole source string; carries block-comment state across lines. Returns an array
// (one entry per line) of token arrays.
function highlight(code, lang) {
  const kw = new Set((KEYWORDS[lang] || "").split(" ").filter(Boolean));
  const lc = LINE_COMMENT[lang] === undefined ? "//" : LINE_COMMENT[lang];
  const lines = splitLines(code);
  const out = [];
  let inBlock = false;
  for (const line of lines) out.push(hlLine(line, kw, lc, () => inBlock, (v) => { inBlock = v; }));
  return out;
}

function hlLine(line, kw, lc, getBlock, setBlock) {
  const toks = [];
  let i = 0, buf = "";
  const flush = () => { if (buf) { toks.push({t: "txt", v: buf}); buf = ""; } };
  const word = () => {
    let j = i; while (j < line.length && /[A-Za-z0-9_$]/.test(line[j])) j++;
    const w = line.slice(i, j);
    if (/^\d/.test(w) && /^[\d._eExXa-fA-F]+$/.test(w)) { flush(); toks.push({t: "num", v: w}); }
    else if (kw.has(w)) { flush(); toks.push({t: "kw", v: w}); }
    else buf += w;
    i = j;
  };
  while (i < line.length) {
    if (getBlock()) {
      const end = line.indexOf("*/", i);
      if (end === -1) { flush(); toks.push({t: "com", v: line.slice(i)}); i = line.length; }
      else { flush(); toks.push({t: "com", v: line.slice(i, end + 2)}); i = end + 2; setBlock(false); }
      continue;
    }
    const two = line.slice(i, i + 2);
    if (two === "/*") { flush(); setBlock(true); continue; }
    if (lc && line.startsWith(lc, i)) { flush(); toks.push({t: "com", v: line.slice(i)}); i = line.length; continue; }
    const ch = line[i];
    if (ch === '"' || ch === "'" || ch === "`") {
      flush();
      let j = i + 1;
      while (j < line.length) { if (line[j] === "\\") j += 2; else if (line[j] === ch) { j++; break; } else j++; }
      toks.push({t: "str", v: line.slice(i, j)}); i = j; continue;
    }
    if (/[A-Za-z0-9_$]/.test(ch)) { word(); continue; }
    buf += ch; i++;
  }
  flush();
  return toks;
}

// ---- unified diff / patch ------------------------------------------------------------------
// Parse a git-style unified diff (a .diff/.patch pushed as one file) into rows the viewer paints:
//   {type: "hunk"|"add"|"del"|"ctx"|"meta", text, a: <old line no|null>, b: <new line no|null>}
// Line numbers are tracked from each "@@ -l,s +l,s @@" header so a click on a row can anchor to a
// real file line. File headers (diff/index/---/+++) come back as "meta" rows for context.
function parsePatch(text) {
  const rows = [];
  let a = 0, b = 0;
  for (const line of splitLines(text)) {
    const hm = /^@@+\s*-(\d+)(?:,\d+)?\s+\+(\d+)(?:,\d+)?\s*@@/.exec(line);
    if (hm) { a = +hm[1]; b = +hm[2]; rows.push({type: "hunk", text: line, a: null, b: null}); continue; }
    if (/^(diff |index |--- |\+\+\+ |new file|deleted file|similarity |rename |Binary )/.test(line)) {
      rows.push({type: "meta", text: line, a: null, b: null}); continue;
    }
    const c = line[0];
    if (c === "+") { rows.push({type: "add", text: line.slice(1), a: null, b: b++}); }
    else if (c === "-") { rows.push({type: "del", text: line.slice(1), a: a++, b: null}); }
    else if (c === "\\") { rows.push({type: "meta", text: line, a: null, b: null}); }  // "\ No newline"
    else { rows.push({type: "ctx", text: line.replace(/^ /, ""), a: a++, b: b++}); }
  }
  return rows;
}

if (typeof module !== "undefined")
  module.exports = {lineDiff, sideBySide, diffStat, wordDiff, colName, cellRef, parseDSV, sheetDiff, highlight, langOf, tokenizeWords, parsePatch};
