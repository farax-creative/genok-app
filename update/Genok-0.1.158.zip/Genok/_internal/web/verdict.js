// Redesign round (lab 4, web/glass.css): a result as a card with three verdicts, after the Style Lab
// review page. The verdicts are statuses a result already has - 승인 (approved), 고치기 (changes,
// a note is asked for), 보류 (hold) - so nothing new is stored on the server.
// - A verdict shows at once and goes after five seconds, under one 되돌리기 toast for all of the
//   verdicts made in that time (Gmail's undo send); leaving the page sends them at once.
// - A note waits in this device's drafts (the same ones the result's own box keeps) until
//   메모 보내기 sends every note on the list in one go.
// - 봤음 folds a card on this device; a newer version unfolds it again and says it changed since
//   it was last looked at (GitHub's Viewed mark).
// - 1 / 2 / 3 give the verdict to the card under the pointer or focus (Linear's triage keys).
// - Once a verdict is sent (after its five seconds, or 고치기 once its note went), the card folds
//   to one line - "승인 · v003 · 14:02" - where it stood; a click opens it again. This visit only.
// Loaded after v2.js, whose names (D, iid, tl, post, ...) it uses. Only lab 4 calls into it.
(() => {
  const RDV = ["approved", "changes", "hold"];
  // Spelled out so the i18n checks see each key.
  const vName = (s) => ({approved: tl("rv.v.approved"), changes: tl("rv.v.changes"), hold: tl("rv.v.hold")})[s];
  const stay = new Map();             // judged during this visit -> the list it was judged on
  const ones = new Map();             // iid -> {s, v, at}: sent this visit, shown as one line
  const opened = new Set();           // one-line cards opened again by a click
  let stayOn = "", only = false;
  const pend = new Map();             // iid -> {x, was, s}: verdicts waiting out their five seconds
  let pendT = 0;
  const readJ = (k) => { try { return JSON.parse(lsGet(k) || "{}") || {}; } catch (e) { return {}; } };
  const seen = readJ("genok-rd-seen");      // iid -> the version folded as 봤음
  const said = readJ("genok-rd-said");      // iid -> the version a verdict was given on
  const keep = (k, o) => lsSet(k, JSON.stringify(o));
  const key = (x) => iid(x);
  const judged = (x, all) => stay.has(key(x)) || (all && RDV.includes(x.status));
  const folded = (x) => seen[key(x)] === x.v;
  // A verdict or 봤음 on an earlier version, and a newer one is here now.
  const moved = (x) => { const v = said[key(x)] || seen[key(x)]; return !!v && v !== x.v; };
  const sel = (k) => `[data-gk="${CSS.escape(k)}"]`;
  const note = (k) => cmDraft[k] || "";
  // iid -> a note already posted whose delivery failed: sending again only redoes the delivery.
  const posted = new Map();
  async function postNote(x, k, text) {
    if (posted.get(k) !== text) { await post("/api/comment", {p: x.project, i: x.id, v: x.v, text}); posted.set(k, text); }
    if (!["changes", "approved"].includes(x.status)) await post("/api/status", {p: x.project, i: x.id, v: x.v, status: "changes"}).catch(() => null);
    await post("/api/comments/send", {p: x.project, i: x.id, v: x.v});
    posted.delete(k);
  }

  const kbd = (n) => `<kbd class="rdk" aria-hidden="true">${n}</kbd>`;
  const vbtns = (x, cls = "") => `<div class="rdv ${cls}" role="group" aria-label="${esc(tl("rv.v"))}">${RDV.map((s, n) =>
    `<button type="button" class="rdvb press" data-rdv="${s}" data-gk="${esc(key(x))}" aria-pressed="${x.status === s}"${x.finished ? " disabled" : ""}>${esc(vName(s))}${kbd(n + 1)}</button>`).join("")}</div>`;
  // The verdict sent, its version and the time, on one line.
  const oneOf = (x) => { const o = ones.get(key(x)); return o && !opened.has(key(x)) && o.s === x.status && o.v === x.v && !note(key(x)).trim() ? o : null; };
  const hhmm = (t) => new Date(t).toLocaleTimeString(LANG() === "en" ? "en-US" : "ko-KR", {hour: "2-digit", minute: "2-digit", hour12: false});
  function line(x, o) {
    const k = key(x);
    return `<div class="rdc one" data-gk="${esc(k)}" data-v="${esc(o.s)}" tabindex="-1">
      <button type="button" class="rd1 press" data-rd1="${esc(k)}" aria-expanded="false" aria-label="${esc(x.title + " · " + tl("rv.one.open"))}"><b class="rd1t">${esc(x.title)}</b><span class="rd1s num">${esc(tl("rv.one", {s: vName(o.s), v: o.v || "", t: hhmm(o.at)}))}</span>${ic("chev", "i dn")}</button></div>`;
  }
  function card(x) {
    const o = oneOf(x); if (o) return line(x, o);
    const k = key(x), t = note(k), fold = folded(x);
    return `<div class="rdc${fold ? " fold" : ""}" data-gk="${esc(k)}" data-v="${RDV.includes(x.status) ? x.status : ""}" tabindex="-1">
      <button type="button" class="rdf press" data-item="${esc(k)}"${stTip(x)}>${homeThumb(x)}<span class="stat-summary-badge ${stCls(x)}">${esc(stName(x))}</span>${apprTag(x, "rdchg apprv") || (moved(x) ? `<span class="rdchg">${esc(tl("rv.changed"))}</span>` : "")}</button>
      <button type="button" class="rdz press" data-rdlb="${esc(k)}" aria-label="${esc(tl("rv.zoom"))}" title="${esc(tl("rv.zoom"))}">${ic("full")}</button>
      <div class="rdh"><button type="button" class="rdt press" data-item="${esc(k)}">${esc(x.title)}</button>
        <button type="button" class="rdseen press" data-rdseen="${esc(k)}" aria-pressed="${fold}">${ic("check")}<span>${esc(tl("rv.seen"))}</span></button>
        <span class="rdm num">${homeWhere(x)}</span></div>
      ${vbtns(x)}
      <div class="rdnote"${x.status === "changes" || t ? "" : " hidden"}><textarea class="rdta" data-rdn="${esc(k)}" rows="2" placeholder="${esc(tl("rv.ph"))}">${esc(t)}</textarea><p class="rdsaved"${t.trim() ? "" : " hidden"}>${esc(tl("rv.saved"))}</p></div></div>`;
  }
  // The list as it is reviewed: what was judged here stays where it was until the screen is left,
  // and 안 한 것만 leaves out what has a verdict (all: a set status counts, not only one given here).
  function list(L, where, all) {
    if (stayOn !== cur) { stay.clear(); ones.clear(); opened.clear(); stayOn = cur; }
    const ids = new Set(L.map(key));
    const back = D.items.filter((x) => stay.get(key(x)) === where && !ids.has(key(x)));
    const full = [...L, ...back];
    return {full, shown: only ? full.filter((x) => !judged(x, all)) : full};
  }
  function bar(full, all) {
    const n = full.length, m = full.filter((x) => judged(x, all)).length, f = full.filter(folded).length;
    const notes = full.filter((x) => note(key(x)).trim()).length;
    return `<div class="rdbar" data-all="${all ? 1 : ""}" role="status">
      <span class="rdbn num">${esc(tl("rv.judged", {n, m}))}</span><i class="rdbt"><b style="width:${n ? Math.round(m / n * 100) : 0}%"></b></i>
      <span class="rdbs num"${f ? "" : " hidden"}>${esc(tl("rv.seenn", {s: f, r: n - f}))}</span>
      <button type="button" class="rdchip press" data-rdonly aria-pressed="${only}">${esc(tl("rv.only"))}</button>
      <button type="button" class="rdsend press" data-rdsend${notes ? "" : " hidden"}>${esc(tl("rv.send", {n: notes}))}</button></div>`;
  }
  // Off-screen cards stand in at --rdh (glass.css): one card's real content height at this width,
  // measured after each draw (and once the fonts are in), so the list's height - and a remembered
  // scroll place - stays true.
  let cardH = 0, fitQ = 0;
  function fit() {
    fitQ = 0;
    const c = document.querySelector("#view .rdgrid > .rdc:not(.one):not(.fold):has(> .rdnote[hidden])"); if (!c) return;
    c.style.contentVisibility = "visible";
    const s = getComputedStyle(c), h = c.offsetHeight - ["paddingTop", "paddingBottom", "borderTopWidth", "borderBottomWidth"].reduce((n, k) => n + parseFloat(s[k]), 0);
    c.style.contentVisibility = "";
    if (h > 0 && h !== cardH) { cardH = h; document.querySelectorAll("#view .rdgrid").forEach((g) => g.style.setProperty("--rdh", h + "px")); }
  }
  document.fonts?.ready.then(() => { fitQ ||= requestAnimationFrame(fit); });
  const grid = (L) => { fitQ ||= requestAnimationFrame(fit);
    return `<div class="rdgrid"${cardH ? ` style="--rdh:${cardH}px"` : ""}>${L.map(card).join("")}</div>`; };
  // The bar follows the cards on screen without a redraw.
  function sync() {
    const b = document.querySelector("#view .rdbar"); if (!b) return;
    const all = !!b.dataset.all, xs = document.querySelector("#view .rds") ? stL   // 크게 보기 counts its whole list
      : [...document.querySelectorAll("#view .rdc")].map((c) => D.items.find((x) => key(x) === c.dataset.gk)).filter(Boolean);
    const n = xs.length, m = xs.filter((x) => judged(x, all)).length, f = xs.filter(folded).length, notes = xs.filter((x) => note(key(x)).trim()).length;
    b.querySelector(".rdbn").textContent = tl("rv.judged", {n, m});
    b.querySelector(".rdbt b").style.width = (n ? Math.round(m / n * 100) : 0) + "%";
    const s = b.querySelector(".rdbs"); s.hidden = !f; s.textContent = tl("rv.seenn", {s: f, r: n - f});
    const sd = b.querySelector(".rdsend"); sd.hidden = !notes; sd.textContent = tl("rv.send", {n: notes});
  }
  function paint(x) {
    const k = key(x);
    document.querySelectorAll(`.rdc${sel(k)}`).forEach((c) => { c.dataset.v = RDV.includes(x.status) ? x.status : "";
      const nb = c.querySelector(".rdnote"); if (nb && x.status === "changes") nb.hidden = false; });
    document.querySelectorAll(`[data-rdv]${sel(k)}`).forEach((b) => b.setAttribute("aria-pressed", String(x.status === b.dataset.rdv)));
    sync();
  }
  // A refresh of the same list: on a wide window the cards scroll inside [data-rdw], and a plain
  // draw put that column back at its top after every verdict.
  function redraw() {
    if (detail) return;
    if (cur === "lib") softDraw(() => SCREENS.lib()); else if (cur === "inbox") softDraw(() => SCREENS.inbox(inTab));
  }

  // ---------- verdicts: shown now, sent after five seconds, one 되돌리기 for the batch ----------
  function give(x, s) {
    if (x.finished) return;
    const k = key(x), p = pend.get(k), was = p ? p.was : x.status;
    if (x.status === s) {                       // pressed again: the verdict is taken back
      if (!p) return;
      x.status = was; pend.delete(k); stay.delete(k);
    } else {
      x.status = s; stay.set(k, stayWhere(k));
      if (s === was) pend.delete(k); else pend.set(k, {x, was, s});
    }
    paint(x);
    document.querySelectorAll(`#view .rdc.one${sel(k)}`).forEach(swap);   // a new verdict on a folded line opens it
    if (s === "changes" && x.status === "changes") document.querySelector(`.rdc${sel(k)} .rdta`)?.focus({preventScroll: true});
    clearTimeout(pendT);
    if (!pend.size) return;
    const n = pend.size;
    toastAct(tl("rv.given", {n}), tl("toggleFav.3"), () => {
      clearTimeout(pendT);
      pend.forEach((o) => { o.x.status = o.was; stay.delete(key(o.x)); paint(o.x); });
      pend.clear(); toast(tl("approveMany.3"), 2200, "undo");
    }, 5000, "approve");
    pendT = setTimeout(flush, 5000);
  }
  // A sent verdict folds its card to one line in place: the card fades out, the line fades in.
  function settle(x, s) {
    const k = key(x);
    ones.set(k, {s, v: x.v, at: Date.now()}); opened.delete(k);
    document.querySelectorAll(`#view .rdgrid > .rdc${sel(k)}:not(.one)`).forEach(swap);
  }
  // One card redrawn where it stands (folded or opened again), with a short fade.
  function swap(c) {
    const x = D.items.find((y) => key(y) === c.dataset.gk); if (!x) return;
    const put = () => { if (!c.isConnected) return; const t = document.createElement("template"); t.innerHTML = card(x).trim(); const n = t.content.firstElementChild; n.classList.add("in"); c.replaceWith(n); sync(); };
    if (c.contains(document.activeElement) && document.activeElement.matches("textarea,input")) return;
    const a = c.animate([{opacity: 1}, {opacity: 0}], {duration: RM() ? 90 : 130, easing: "ease-out"});
    a.onfinish = put;
  }
  const stayWhere = (k) => document.querySelector(`#view .rdc${sel(k)}`)?.closest("[data-rdw]")?.dataset.rdw || "lib";
  async function flush() {
    clearTimeout(pendT);
    const L = [...pend.values()]; pend.clear();
    if (!L.length) return;
    const bad = [];
    await Promise.all(L.map(async (o) => {
      const x = o.x;
      try {
        await post("/api/status", {p: x.project, i: x.id, v: x.v, status: o.s,
          ...(o.s === "approved" ? {rev: x.rev ?? await itemRev(x.project, x.id)} : {})});
        said[key(x)] = x.v;
        if (o.s !== "changes") settle(x, o.s);
      } catch (e) { bad.push([o, e]); x.status = o.was; stay.delete(key(x)); paint(x); }
    }));
    keep("genok-rd-said", said);
    if (bad.length) toast(bad.some(([, e]) => isConflict(e)) ? tl("rv.conflict", {n: bad.length}) : tl("sendMany.1", {n: bad.length}), 5000);
    await load();
    if (!document.activeElement?.matches?.("input,textarea,gk-select")) redraw();
  }
  addEventListener("pagehide", () => { flush(); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });

  // ---------- notes: kept as drafts, sent together ----------
  async function sendNotes() {
    await flush();
    const xs = [...document.querySelectorAll("#view .rdc")].map((c) => D.items.find((x) => key(x) === c.dataset.gk)).filter((x) => x && note(key(x)).trim());
    if (!xs.length) return;
    const b = document.querySelector("#view [data-rdsend]"); if (b) b.disabled = true;
    let ok = 0;
    for (const x of xs) {
      try {
        await postNote(x, key(x), note(key(x)).trim());
        delete cmDraft[key(x)]; said[key(x)] = x.v; ok++; settle(x, "changes");
      } catch (e) { toast(e.message); }
    }
    saveDraft(); keep("genok-rd-said", said);
    toast(tl("rv.sent", {n: ok}), 2600, "send");
    await load(); redraw();
  }

  // ---------- 봤음 ----------
  function fold(k) {
    const x = D.items.find((y) => key(y) === k); if (!x) return;
    if (seen[k] === x.v) delete seen[k]; else seen[k] = x.v;
    keep("genok-rd-seen", seen);
    document.querySelectorAll(`.rdc${sel(k)}`).forEach((c) => { c.classList.toggle("fold", seen[k] === x.v);
      c.querySelector(".rdseen")?.setAttribute("aria-pressed", String(seen[k] === x.v)); c.querySelector(".rdchg")?.remove(); });
    sync();
  }

  // ---------- the full-size view: the picture, its verdicts, the one before and after ----------
  let lb = null;
  function viewer(k) {
    const ids = [...document.querySelectorAll("#view .rdc")].map((c) => c.dataset.gk);
    let at = Math.max(0, ids.indexOf(k));
    const from = document.activeElement;
    const o = document.createElement("div");
    o.className = "rdview"; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true");
    document.body.appendChild(o);
    const draw = () => {
      const x = D.items.find((y) => key(y) === ids[at]); if (!x) return close();
      o.setAttribute("aria-label", x.title);
      o.innerHTML = `<button type="button" class="rdlbx press" data-lbx aria-label="${esc(tl("rv.close"))}">${ic("x")}</button>
        <button type="button" class="rdlbn prev press" data-lbs="-1" aria-label="${esc(tl("rv.prev"))}"${at ? "" : " disabled"}>${ic("back")}</button>
        <figure><div class="rdlbm" data-gk="${esc(key(x))}">${pic(x)}</div>
          <figcaption><b>${esc(x.title)}</b><span class="num">${homeWhere(x)} · ${at + 1} / ${ids.length}</span></figcaption>
          ${vbtns(x, "big")}<button type="button" class="lnk press rdlbo" data-item="${esc(key(x))}">${esc(tl("rv.open"))}${ic("chev")}</button></figure>
        <button type="button" class="rdlbn next press" data-lbs="1" aria-label="${esc(tl("rv.next"))}"${at < ids.length - 1 ? "" : " disabled"}>${ic("chev")}</button>`;
      lift(o.querySelector(".rdlbm"), x);
    };
    const step = (d) => { const n = at + d; if (n < 0 || n >= ids.length) return; at = n; draw(); };
    const close = () => { if (!lb) return; lb = null; o.classList.add("out");
      document.removeEventListener("keydown", onKey, true);
      setTimeout(() => o.remove(), RM() ? 150 : 220); if (from?.isConnected) from.focus({preventScroll: true}); };
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); close(); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); step(-1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); step(1); }
      else if (/^[123]$/.test(e.key) && !e.target.matches?.("input,textarea")) { e.preventDefault(); const x = D.items.find((y) => key(y) === ids[at]); if (x) give(x, RDV[+e.key - 1]); }
      else if (e.key === "Tab") { const f = [...o.querySelectorAll("button:not([disabled])")]; if (!f.length) return;
        const i = f.indexOf(document.activeElement), n = e.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : (i + 1) % f.length; e.preventDefault(); f[n].focus(); }
    };
    o.addEventListener("click", (e) => {
      if (e.target === o || e.target.closest("[data-lbx]")) return close();
      const s = e.target.closest("[data-lbs]"); if (s) return step(+s.dataset.lbs);
      if (e.target.closest("[data-item]")) close();
    });
    // A swipe follows the finger 1:1 and moves on when it was flung or pulled past a third.
    let sx = 0, st = 0, dx = 0, drag = false;
    o.addEventListener("pointerdown", (e) => { if (e.pointerType === "mouse" || !e.target.closest(".rdlbm")) return; drag = true; sx = e.clientX; st = performance.now(); dx = 0; });
    o.addEventListener("pointermove", (e) => { if (!drag) return; dx = e.clientX - sx; const m = o.querySelector(".rdlbm"); if (m) { m.style.transition = "none"; m.style.transform = `translateX(${dx}px)`; } });
    const up = () => { if (!drag) return; drag = false; const v = dx / Math.max(1, performance.now() - st), m = o.querySelector(".rdlbm");
      if (m) { m.style.transition = ""; m.style.transform = ""; }
      if (Math.abs(dx) > innerWidth / 3 || Math.abs(v) > 0.5) step(dx < 0 ? 1 : -1); };
    o.addEventListener("pointerup", up); o.addEventListener("pointercancel", up);
    document.addEventListener("keydown", onKey, true);
    lb = o; draw(); requestAnimationFrame(() => o.classList.add("on"));
    o.querySelector("[data-lbx]")?.focus({preventScroll: true});
  }

  // ---------- the original a card stands for: its version's first picture or film, read once ----------
  const orig = new Map();             // iid|v -> Promise<{kind, url} | null>
  function original(x) {
    const k = key(x) + "|" + x.v;
    if (!orig.has(k)) orig.set(k, itemDetail(x.project, x.id).then((d) => {
      const f = (d?.versions || []).find((y) => y.v === x.v)?.files?.find((y) => y.kind === "image" || y.kind === "video");
      return f ? {kind: f.kind, url: f.kind === "video" ? f.play : f.url} : null;
    }));
    return orig.get(k);
  }
  // The thumbnail shows at once and the original takes its place once loaded.
  function lift(box, x) {
    original(x).then((f) => {
      const here = () => box.isConnected && box.dataset.gk === key(x);
      if (!f || !here()) return;
      if (f.kind === "video") { box.innerHTML = `<video src="${esc(f.url)}" controls playsinline preload="metadata"${x.thumb ? ` poster="${esc(x.thumb)}"` : ""}></video>`; return; }
      const im = new Image(); im.alt = ""; im.decoding = "async"; im.draggable = false;
      im.onload = () => { if (here()) box.replaceChildren(im); };
      im.src = f.url;
    });
  }
  const pic = (x) => x.thumb ? imgTag(x.thumb, {lazy: false}) : `<span class="rdlbi">${ic((KIND[x.kind] || ["doc"])[0])}</span>`;

  // ---------- 크게 보기: one result at a time on the results page, judged where it is seen ----------
  // The three verdicts and a feedback line sit under the picture (the notice card's order); a
  // verdict moves on to the next result, 고치기 waits on its line. Left / right and a swipe step.
  let stAt = "", stL = [];
  function stage(L) {
    stL = L;
    if (!L.length) return "";
    let i = L.findIndex((x) => key(x) === stAt);
    if (i < 0) { i = Math.max(0, L.findIndex((x) => !judged(x, true))); stAt = key(L[i]); }
    const x = L[i], k = key(x), t = note(k);
    return `<div class="rds" data-gk="${esc(k)}">
      <div class="rdsv"><div class="rdsm" data-gk="${esc(k)}">${pic(x)}</div>
        <button type="button" class="rdlbn prev press" data-rdstep="-1" aria-label="${esc(tl("rv.prev"))}"${i ? "" : " disabled"}>${ic("back")}</button>
        <button type="button" class="rdlbn next press" data-rdstep="1" aria-label="${esc(tl("rv.next"))}"${i < L.length - 1 ? "" : " disabled"}>${ic("chev")}</button></div>
      <div class="rdsi"><button type="button" class="rdt press" data-item="${esc(k)}">${esc(x.title)}</button><span class="rdm num">${homeWhere(x)}</span><span class="rdsn num">${i + 1} / ${L.length}</span></div>
      ${vbtns(x, "big")}
      <div class="rdsfb"><input class="rdsin" data-rdn="${esc(k)}" maxlength="500" enterkeyhint="send" autocomplete="off" placeholder="${esc(tl("rv.line"))}" aria-label="${esc(tl("rv.line"))}" value="${esc(t)}">
        <button type="button" class="rdsgo press" data-rdsgo="${esc(k)}"${t.trim() ? "" : " disabled"}>${esc(tl("rv.go"))}</button></div></div>`;
  }
  // Called after the screen that holds the stage is drawn.
  function mounted() {
    const m = document.querySelector("#view .rdsm"); if (!m) return;
    const x = D.items.find((y) => key(y) === m.dataset.gk); if (x) lift(m, x);
  }
  function step(d) {
    const el = document.querySelector("#view .rds"); if (!el) return;
    const i = stL.findIndex((x) => key(x) === stAt), n = i + d;
    if (i < 0 || n < 0 || n >= stL.length) return;
    stAt = key(stL[n]);
    const typing = el.contains(document.activeElement) && document.activeElement.matches("input");
    el.outerHTML = stage(stL);
    mounted();
    if (typing) document.querySelector("#view .rdsin")?.focus({preventScroll: true});
  }
  // A verdict that took moves on; 고치기 asks for its line first.
  function judge(x, s) {
    give(x, s);
    if (x.status !== s) return;
    if (s === "changes") return document.querySelector("#view .rdsin")?.focus({preventScroll: true});
    const k = key(x);
    setTimeout(() => { if (stAt === k) step(1); }, RM() ? 0 : 240);
  }
  async function sendOne(k) {
    const x = D.items.find((y) => key(y) === k), text = note(k).trim();
    if (!x || !text) return;
    const b = document.querySelector(`#view [data-rdsgo="${CSS.escape(k)}"]`); if (b) b.disabled = true;
    await flush();
    try {
      await postNote(x, k, text);
    } catch (e) { toastFail(e.message, tl("err.words.meta")); if (b) b.disabled = false; return; }
    delete cmDraft[k]; saveDraft(); said[k] = x.v; keep("genok-rd-said", said); settle(x, "changes");
    stay.set(k, stayWhere(k));
    const i = stL.findIndex((y) => key(y) === k);
    if (i >= 0 && i < stL.length - 1) stAt = key(stL[i + 1]);
    toast(tl("rv.sent", {n: 1}), 2200, "send");
    document.activeElement?.blur?.();
    await load(); redraw();
  }
  // A swipe on the picture follows the finger 1:1 and steps when flung or pulled past a third.
  let sw = null;
  document.addEventListener("pointerdown", (e) => { const m = e.pointerType !== "mouse" && e.target.closest?.("#view .rdsm"); if (m) sw = {m, x: e.clientX, t: performance.now(), dx: 0}; });
  document.addEventListener("pointermove", (e) => { if (!sw) return; sw.dx = e.clientX - sw.x; sw.m.style.transition = "none"; sw.m.style.transform = `translateX(${sw.dx}px)`; });
  const swUp = () => { if (!sw) return; const {m, dx, t} = sw; sw = null; const v = dx / Math.max(1, performance.now() - t);
    m.style.transition = ""; m.style.transform = "";
    if (Math.abs(dx) > m.clientWidth / 3 || Math.abs(v) > 0.5) step(dx < 0 ? 1 : -1); };
  document.addEventListener("pointerup", swUp); document.addEventListener("pointercancel", swUp);

  // ---------- wiring ----------
  document.addEventListener("click", (e) => {
    const v = e.target.closest("[data-rdv]");
    if (v) { e.stopPropagation(); const x = D.items.find((y) => key(y) === v.dataset.gk); if (x) (v.closest(".rds") ? judge : give)(x, v.dataset.rdv); return; }
    const sp = e.target.closest("[data-rdstep]"); if (sp) { e.stopPropagation(); step(+sp.dataset.rdstep); return; }
    const go = e.target.closest("[data-rdsgo]"); if (go) { e.stopPropagation(); sendOne(go.dataset.rdsgo); return; }
    const z = e.target.closest("[data-rdlb]"); if (z) { e.stopPropagation(); viewer(z.dataset.rdlb); return; }
    const one = e.target.closest("[data-rd1]"); if (one) { e.stopPropagation(); const k = one.dataset.rd1; opened.add(k);
      const c = one.closest(".rdc"); swap(c); setTimeout(() => document.querySelector(`#view .rdc${sel(k)}`)?.focus({preventScroll: true}), RM() ? 100 : 140); return; }
    const s = e.target.closest("[data-rdseen]"); if (s) { e.stopPropagation(); fold(s.dataset.rdseen); return; }
    if (e.target.closest("[data-rdonly]")) { e.stopPropagation(); only = !only; redraw(); return; }
    if (e.target.closest("[data-rdsend]")) { e.stopPropagation(); sendNotes(); }
  }, true);
  document.addEventListener("input", (e) => {
    const t = e.target.closest?.(".rdta,.rdsin"); if (!t) return;
    cmDraft[t.dataset.rdn] = t.value; saveDraft();
    const g = t.parentElement.querySelector("[data-rdsgo]"); if (g) g.disabled = !t.value.trim();
    const p = t.parentElement.querySelector(".rdsaved"); if (p) p.hidden = !t.value.trim();
    sync();
  });
  // 1 / 2 / 3 on the card under the pointer or holding the focus (never while typing).
  let over = null;
  document.addEventListener("pointerover", (e) => { over = e.target.closest?.("#view .rdc") || over; });
  document.addEventListener("keydown", (e) => {
    // A card's note goes on Enter; Shift+Enter is a new line.
    if (e.target.matches?.("#view .rdc .rdta") && e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault(); sendOne(e.target.dataset.rdn); return;
    }
    const st = !lb && document.querySelector("#view .rds");
    if (st && e.target.matches?.(".rdsin")) {
      if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); sendOne(e.target.dataset.rdn); }
      else if (e.key === "Escape") e.target.blur();
      return;
    }
    if (st && !e.ctrlKey && !e.metaKey && !e.altKey && !e.target.matches?.("input,textarea,[contenteditable]")) {
      if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); return step(e.key === "ArrowLeft" ? -1 : 1); }
      const x = /^[123]$/.test(e.key) && D.items.find((y) => key(y) === st.dataset.gk);
      if (x) { e.preventDefault(); judge(x, RDV[+e.key - 1]); }
      return;
    }
    if (lb || !/^[123]$/.test(e.key) || e.ctrlKey || e.metaKey || e.altKey || e.target.matches?.("input,textarea,[contenteditable]")) return;
    // On a result's own page the keys are its three verdict buttons (v2.js decide), beside A / C.
    const d = document.querySelector("#view .rdvd [data-decide]");
    if (d && !document.querySelector("#view .rdc")) { const b = document.querySelectorAll("#view .rdvd [data-decide]")[+e.key - 1]; if (b && !b.disabled) { e.preventDefault(); b.click(); } return; }
    const c = document.activeElement?.closest?.("#view .rdc") || (over?.isConnected && over.matches(":hover") ? over : null); if (!c) return;
    const x = D.items.find((y) => key(y) === c.dataset.gk); if (!x) return;
    e.preventDefault(); give(x, RDV[+e.key - 1]);
  });

  window.RdV = {card, grid, list, bar, stage, mounted, reset: () => stay.clear(), name: vName};
})();
