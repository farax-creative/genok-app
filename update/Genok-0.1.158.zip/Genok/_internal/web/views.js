// Pure saved-view engine, shared by web/custom.js (loaded as a browser global before it) and the
// node tests. No DOM here on purpose: the predicates, sorting, grouping and the preset bundles
// live where they can be tested; custom.js enriches each item (x.flow from v2.js flowOf, x.fav
// from D.favs) and does the rendering. A view is {id, name, emoji, screen, filter, group, sort,
// zoom, pin}. Keys and criteria follow docs/qa/hub-qa.md "저장된 보기 — 명세".

const VIEW_HOUR = 36e5, VIEW_DAY = 24 * VIEW_HOUR, VIEW_STALE_H = 48;
// Auto-archive cutoffs mirror hub_store (AUTO_ARCHIVE_DAYS / STALE_CHANGES_DAYS / STALE_HOLD_DAYS).
const ARCH_APPROVED = 3, ARCH_CHANGES = 3, ARCH_HOLD = 14;

// A version whose next move is the department's, not the reader's (mirrors v2.js turnOf).
function vTurn(x) { return x.status === "changes" || (x.status === "pending" && (x.answered || x.handed)); }
function _hoursSince(t, now) { return t ? (now - new Date(t).getTime()) / VIEW_HOUR : Infinity; }
function _daysSince(t, now) { return t ? (now - new Date(t).getTime()) / VIEW_DAY : Infinity; }
// The item's kind bucket for the kind filter (a link reads as a doc, like v2.js kindOf).
function kindBucket(x) { return x.kind === "link" ? "doc" : (x.kind || "file"); }

// The 11 smart filters, each a predicate on an *enriched* item. custom.js sets x.flow (v2.js
// flowOf: work|ask|unread|quiet|old) and x.fav (in D.favs) before calling; x.led comes from the
// server summary (hub_store.ledger_counts). Keys match hub-qa.md "스마트 필터".
const SMART = {
  // 확인 필요: pending and NOT (answered or handed) - the reader's own move (v2.js turnOf 반대).
  need_check:   (x) => x.status === "pending" && !vTurn(x) && !x.finished,
  // 작업 중: changes, or a pending turn the session is actively working on (flowOf work).
  fixing:       (x) => x.flow !== undefined ? vTurn(x) && x.flow === "work" : x.status === "changes",
  // 전달 대기: the session's turn but no session has read the comment yet (status.js undelivered).
  unread:       (x) => vTurn(x) && (x.flow !== undefined ? x.flow === "unread" : x.note === "sent" || x.note === "unsent"),
  // 멈춤: read it, then rested or left with no new version (status.js stalled).
  read_stuck:   (x) => vTurn(x) && x.flow === "quiet",
  // 오래됨: the session's turn, no new version for over a day (status.js old).
  stalled48:    (x, now) => vTurn(x) && (x.flow !== undefined ? x.flow === "old" : _hoursSince(x.handed_at || x.at, now) > VIEW_STALE_H),
  // 세션이 물어봄: the session is blocked waiting for an answer (flowOf ask, v2.js:140).
  session_asks: (x) => vTurn(x) && x.flow === "ask",
  // 검증 대기: a version claimed a fix with no human verdict yet (ledger, incl. auto-passed).
  await_verify: (x) => !!(x.led && x.led.awaiting_verify > 0),
  // 빠진 수정 요청: any directive the core still owes but may hide (ledger K > 0).
  missing_fix:  (x) => !!(x.led && x.led.k > 0),
  // 질문 있음: the newest version asked something still unanswered.
  has_question: (x) => (x.asked || 0) > 0 && !x.finished,
  // 곧 자동 보관: within a day of an auto-archive cutoff, and not kept out by hand.
  soon_archive: (x, now) => !x.kept && !x.finished && (
    (x.status === "approved" && _daysSince(x.at, now) >= ARCH_APPROVED - 1) ||
    ((x.status === "changes" || (x.status === "pending" && vTurn(x))) && _daysSince(x.handed_at || x.at, now) >= ARCH_CHANGES - 1) ||
    (x.status === "hold" && _daysSince(x.at, now) >= ARCH_HOLD - 1)),
  // 내가 고정/즐겨찾기.
  fav:          (x) => !!x.fav,
};

const SMART_KEYS = Object.keys(SMART);

// One base-filter field value against a chosen list. account/role use "" (default account / no role).
function _inList(val, list) { return !list || !list.length || list.indexOf(val) !== -1; }

// The base filters (AND across fields; several values in one field are OR). hub-qa.md 기본 필터.
function matchBase(x, f, now) {
  f = f || {};
  if (f.project && !_inList(x.project, f.project)) return false;
  if (f.account && !_inList(x.account_id || "", f.account)) return false;
  if (f.role && !_inList(x.role || "", f.role)) return false;
  if (f.agent && !_inList(x.agent || "", f.agent)) return false;
  if (f.status && !_inList(x.status, f.status)) return false;
  if (f.kind && !_inList(kindBucket(x), f.kind)) return false;
  if (f.age && f.age !== "all") {
    if (f.age === "today") {
      const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
      if (!x.at || new Date(x.at).getTime() < d0.getTime()) return false;
    } else if (_daysSince(x.at, now) > (f.age === "7" ? 7 : 30)) return false;
  }
  if (f.q) {
    const q = f.q.toLowerCase();
    const hay = [x.title, x.summary, x.dept, x.project].filter(Boolean).join(" ").toLowerCase();
    if (hay.indexOf(q) === -1) return false;
  }
  return true;
}

// archived: hide (default) | include | only.
function _archOk(x, mode) {
  const arch = !!x.archived;
  if (mode === "only") return arch;
  if (mode === "include") return true;
  return !arch;
}

function matchView(x, view, now) {
  now = now || Date.now();
  const f = (view && view.filter) || {};
  if (!_archOk(x, f.archived || "hide")) return false;
  if (!matchBase(x, f, now)) return false;
  if (f.smart && f.smart.length) {
    // A view's smart set is a union (∪): any one of them matching keeps the item.
    if (!f.smart.some((k) => SMART[k] && SMART[k](x, now))) return false;
  }
  return true;
}

function filterItems(items, view, now) {
  now = now || Date.now();
  return (items || []).filter((x) => matchView(x, view, now));
}

// ---- sort ----
function _t(v) { return v ? new Date(v).getTime() : 0; }
const SORTS = {
  new:      (a, b) => _t(b.at) - _t(a.at),
  old:      (a, b) => _t(a.at) - _t(b.at),
  // 오래 기다린 순: the oldest hand-over the reader is still owed on comes first.
  waited:   (a, b) => _t(a.handed_at || a.at) - _t(b.handed_at || b.at),
  versions: (a, b) => (b.count || 0) - (a.count || 0),
};
function sortItems(items, sort) {
  return (items || []).slice().sort(SORTS[sort] || SORTS.new);
}

// The one name an item is filed/grouped under, everywhere (rail, project page, chips, saved-view
// project grouping). "부서" is a team-mode idea only (user rule): in team mode an item files under
// its department, falling back to its folder; in every other mode (자동/병렬/헤드) it files under
// its folder/project. So a folder's items never scatter across dept names outside team mode.
function groupName(x, teamMode) {
  return (teamMode && x.dept) ? x.dept : (x.project || x.dept || "");
}

// ---- group ---- returns [[label, items], ...], groups in first-seen order.
// The bucket names follow the language in the app; node tests (no tl) read the Korean ones.
const _dayNames = () => typeof tl === "function" ? [tl("day.1"), tl("day.2"), tl("day.week"), tl("cv.older")] : ["오늘", "어제", "이번 주", "이전"];
function _dateBucket(at, now) {
  const N = _dayNames();
  if (!at) return N[3];
  const t = new Date(at).getTime(), t0 = new Date(now); t0.setHours(0, 0, 0, 0);
  if (t >= t0.getTime()) return N[0];
  if (t >= t0.getTime() - VIEW_DAY) return N[1];
  return _daysSince(at, now) < 7 ? N[2] : N[3];
}
function groupItems(items, group, now, teamMode) {
  now = now || Date.now();
  if (!group || group === "none") return [["", items || []]];
  const key = {
    // "부서별" and "작업별"/"전부" all group by this one name, which is dept only in team mode.
    project: (x) => groupName(x, teamMode),
    account: (x) => x.account_id || "",
    agent: (x) => x.agent || "",
    role: (x) => x.role || "—",
    session: (x) => x.session || "—",
    status: (x) => x.status || "—",
    date: (x) => _dateBucket(x.at, now),
  }[group];
  if (!key) return [["", items || []]];
  const order = [], m = new Map();
  for (const x of (items || [])) {
    const k = key(x);
    if (!m.has(k)) { m.set(k, []); order.push(k); }
    m.get(k).push(x);
  }
  return order.map((k) => [k, m.get(k)]);
}

// ---- presets: the four work modes' starting view bundles (hub-qa.md 프리셋 넷). A preset is
// only a set of default views + panel settings; each view here is fully editable and deletable. ----
const TODO = ["need_check", "has_question", "await_verify"];   // 확인 필요 ∪ 질문 있음 ∪ 검증 대기
const STUCK = ["unread", "read_stuck", "stalled48"];
const PRESETS = {
  auto: [
    {name: "할 일", emoji: "🔔", screen: "turn", filter: {smart: TODO}, sort: "waited", pin: true},
    {name: "전체", emoji: "🗂", screen: "lib", filter: {}, group: "project", sort: "new", pin: true},
    {name: "멈춘 것", emoji: "⏸", screen: "lib", filter: {smart: STUCK}, group: "status"},
  ],
  parallel: [
    {name: "할 일", emoji: "🔔", screen: "turn", filter: {smart: TODO}, sort: "waited", group: "session", pin: true},
    {name: "작업별", emoji: "🌿", screen: "lib", filter: {}, group: "session", sort: "new"},
    {name: "합칠 것", emoji: "✅", screen: "lib", filter: {status: ["approved"], age: "7"}, group: "session"},
  ],
  team: [
    {name: "할 일", emoji: "🔔", screen: "turn", filter: {smart: TODO}, sort: "waited", group: "project", pin: true},
    {name: "{unit}별", emoji: "🏢", screen: "lib", filter: {}, group: "project"},
    {name: "멈춘 것", emoji: "⏸", screen: "lib", filter: {smart: STUCK}, group: "project"},
    {name: "정리됨", emoji: "📦", screen: "lib", filter: {archived: "only"}},
  ],
  head: [
    {name: "할 일", emoji: "🔔", screen: "turn", filter: {smart: TODO}, sort: "waited", pin: true},
    {name: "역할별", emoji: "🎭", screen: "lib", filter: {}, group: "role"},
    {name: "확인 대기", emoji: "🧾", screen: "lib", filter: {smart: ["await_verify", "missing_fix"]}, group: "role"},
  ],
};

// A fresh id + a deep copy, so a preset bundle becomes editable saved views a person owns.
let _vseq = 0;
function newId() { return "v" + Date.now().toString(36) + (_vseq++).toString(36); }
function presetViews(mode) {
  // A name may say {unit}: it is filled with the unit word of the moment the bundle is seeded.
  // The names are seeded in the language of that moment (a saved view keeps its name afterwards).
  const T = typeof tl === "function" ? {"할 일": tl("views.p.todo"), "전체": tl("views.p.all"), "멈춘 것": tl("views.p.stuck"), "작업별": tl("views.p.bySession"),
    "합칠 것": tl("views.p.merge"), "{unit}별": tl("views.p.byUnit"), "정리됨": tl("views.p.tidied"), "역할별": tl("views.p.byRole"), "확인 대기": tl("views.p.verify")} : null;
  const fill = (n) => T ? (T[n] || n) : n.replace("{unit}", "프로젝트");
  return (PRESETS[mode] || PRESETS.auto).map((v) => Object.assign({id: newId()}, JSON.parse(JSON.stringify(v)), {name: fill(v.name)}));
}

// Strip volatile fields for a shareable export (mirror of custom.py export_views).
function forExport(views) {
  return (views || []).map((v) => { const c = Object.assign({}, v); delete c.id; return c; });
}

if (typeof module !== "undefined") module.exports = {
  SMART, SMART_KEYS, matchBase, matchView, filterItems, sortItems, groupItems, groupName,
  kindBucket, vTurn, PRESETS, presetViews, newId, forExport,
};
