// Beta "dock": on a phone the bottom menu bar floats as a pill and shrinks to the current tab while the
// page is read downward (web/dock.css). Scrolling up, reaching the top, or tapping the small pill opens it.
(function () {
  "use strict";
  if (!window.genokBeta?.("dock")) return;

  // dock:begin
  // One scroller's state {min, dir, ref, last}: dir is 1 down / -1 up, ref the y where the direction last turned.
  // Down by 28px (below the first 64px) shrinks, up by 16px or the top 24px opens. Hysteresis stops a jitter
  // at the turn from flipping it.
  function dockNext(s, y) {
    const dir = y > s.last ? 1 : y < s.last ? -1 : s.dir;
    const ref = dir !== s.dir ? s.last : s.ref;
    let min = s.min;
    if (y <= 24) min = false;
    else if (dir > 0 && y - ref > 28 && y > 64) min = true;
    else if (dir < 0 && ref - y > 16) min = false;
    return {min, dir, ref, last: y};
  }
  // dock:end

  const root = document.documentElement;
  const phone = matchMedia("(max-width:900px)");
  const states = new WeakMap();
  let min = false;

  function set(on) {
    if (on === min) return;
    min = on;
    root.classList.toggle("dock-min", on);
  }

  function onScroll(e) {
    if (!phone.matches) return;
    const t = e.target === document ? document.scrollingElement : e.target;
    if (!t || t.clientHeight < 200) return;           // a small inner list does not move the bar
    const prev = states.get(t) || {min, dir: 0, ref: 0, last: t.scrollTop};
    const next = dockNext({...prev, min}, t.scrollTop);
    states.set(t, next);
    set(next.min);
  }
  addEventListener("scroll", onScroll, {capture: true, passive: true});

  // A tap on the small pill opens it and goes nowhere; the next tap on a tab navigates as before.
  document.addEventListener("click", (e) => {
    if (!min || !e.target.closest("#tabbar")) return;
    e.preventDefault(); e.stopPropagation();
    set(false);
  }, true);

  // On a result's page the bar rides above its decision dock (#cdk), whatever height that has.
  let lifting = 0;
  function lift() {
    lifting = 0;
    const c = document.getElementById("cdk");
    root.style.setProperty("--dock-lift", (c && c.getClientRects().length ? c.offsetHeight : 0) + "px");
  }
  const askLift = () => { if (!lifting) lifting = requestAnimationFrame(lift); };
  new MutationObserver(askLift).observe(document.body, {childList: true, subtree: true});
  addEventListener("resize", askLift); askLift();

  // A tab switch or a new screen starts at the top: the bar opens again.
  addEventListener("hashchange", () => set(false));
  phone.addEventListener("change", () => set(false));
})();
