// 여러 부서 한 번에 켜기: a multi-select mode on the departments screen (loaded after depts.js).
// The toolbar button turns each card into a checkbox row; a sticky bar holds "꺼진 부서 모두" and
// "선택한 부서 켜기". One POST opens them all (the server skips departments that already run and
// never touches a live session) and a sheet lists each department's result. Motion: the bar
// springs in (springTo, from v2.js), the check pops on a soft overshoot, both can be interrupted
// (state-driven), and prefers-reduced-motion turns them into a plain fade.
(function () {
  "use strict";

  const onScreen = () => location.hash.slice(1).split("/")[0] === "depts";
  const S = {on: false, sel: new Set(), up: {}, res: {}, busy: false, entered: false, stop: null};

  (function () {
    if (document.getElementById("bk-css")) return;
    const st = document.createElement("style"); st.id = "bk-css";
    st.textContent = `
    .bk-bar{position:sticky;top:8px;z-index:6;display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 12px;padding:8px 12px;
      border-radius:12px;background:var(--card-hi);border:1px solid var(--line);box-shadow:0 8px 24px rgba(0,0,0,.35);opacity:0;transition:opacity .2s}
    .bk-bar.in{opacity:1}
    .bk-n{flex:1 1 90px;min-width:0;font-size:14px;font-weight:600;color:var(--t1)}
    .bk-to{order:9;flex:1 1 100%;min-width:0;font-size:12px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .bk-to:empty{display:none}
    .bk-bar .btn{height:36px;min-height:0;padding:0 16px;font-size:14px}
    .bk-bar .btn[disabled]{opacity:.45;pointer-events:none}
    @media (max-width:600px){.bk-bar .btn:not(.ib){flex:1 1 130px}}
    .bk-chk{flex:none;width:24px;height:24px;border-radius:50%;border:2px solid var(--t4);display:grid;place-items:center;color:transparent;
      transition:background-color .18s,border-color .18s,transform .42s cubic-bezier(.34,1.56,.64,1)}
    .bk-chk svg{width:14px;height:14px;fill:currentColor;stroke:currentColor;stroke-width:12;stroke-linejoin:round}
    .bk-sel .bk-chk{background:var(--blue);border-color:var(--blue);color:var(--on-blue);transform:scale(1.08)}
    body:not(:has(#view .card.dc)) [data-bk-toggle]{display:none}
    [data-bk-toggle][aria-pressed="true"]{background:var(--blue);color:var(--on-blue)}
    .card.dc.bk-on{cursor:pointer;transition:box-shadow .2s,opacity .2s}
    .card.dc.bk-sel{box-shadow:0 0 0 2px var(--blue)}
    .card.dc.bk-off{opacity:.55;cursor:default}
    .card.dc.bk-on .dc-open{display:none}
    .card.dc.bk-on [data-dmenu],.card.dc.bk-on .dc-foot{pointer-events:none}
    .bk-up{flex:none;font-size:12px;font-weight:600;padding:4px 8px;border-radius:99px;white-space:nowrap;color:var(--green);background:color-mix(in srgb,var(--green) 16%,transparent)}
    .bk-up.run{color:var(--t2);background:var(--btn)}
    .bk-up.no{color:var(--red);background:color-mix(in srgb,var(--red) 16%,transparent)}
    .card.dc.bk-run{box-shadow:0 0 0 2px var(--blue-w)}
    .bk-res{display:flex;flex-direction:column;gap:2px;margin:8px 0 16px}
    .bk-r{display:flex;align-items:flex-start;gap:8px;padding:8px 0;border-top:1px solid var(--line)}
    .bk-r:first-child{border-top:0}
    .bk-r .n{flex:1;min-width:0;font-size:14.5px;color:var(--t1);overflow-wrap:anywhere}
    .bk-r .n small{display:block;margin-top:2px;font-size:12px;color:var(--t3);line-height:1.45}
    .bk-c{flex:none;font-size:12px;font-weight:600;padding:4px 8px;border-radius:99px;background:var(--btn)}
    .bk-c.ok{background:color-mix(in srgb,var(--green) 16%,transparent);color:var(--green)}
    .bk-c.no{background:color-mix(in srgb,var(--red) 16%,transparent);color:var(--red)}
    .bk-list{display:flex;flex-direction:column;gap:2px;margin:8px 0 12px;max-height:min(52vh,420px);overflow-y:auto}
    .bk-row{display:flex;align-items:center;gap:12px;width:100%;min-height:44px;padding:8px;border:0;border-radius:10px;background:none;color:var(--t1);font:inherit;font-size:14.5px;text-align:left;cursor:pointer}
    .bk-row:hover{background:var(--btn)}
    .bk-row .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .bk-row .e{flex:none;width:20px;text-align:center}
    .bk-foot{display:flex;align-items:center;gap:8px}
    .bk-foot .btn.fill{flex:1}
    .bk-foot .btn[disabled]{opacity:.45;pointer-events:none}
    @media (prefers-reduced-motion:reduce){.bk-chk{transition:background-color .15s,border-color .15s}.bk-sel .bk-chk{transform:none}}`;
    document.head.appendChild(st);
  })();

  const cards = () => [...document.querySelectorAll("#view .card.dc")];
  const nameOf = (c) => (c.querySelector("[data-open]") || {dataset: {}}).dataset.open || "";
  // The card's mark as HTML: its styled icon when it has one, else its emoji (not the folder glyph).
  const emojiOf = (c) => { const i = c.querySelector(".dc-ico"); return !i ? "" : i.dataset.icon && window.LOOP_ICONS ? LOOP_ICONS.html(i.dataset.icon) : i.querySelector("svg") ? "" : esc(i.textContent.trim()); };
  const noFolder = (c) => !!c.querySelector(".dc-sub .opn");
  const shelved = (c) => !!c.closest(".dl-fold");            // archived departments stay out
  const pickable = (c) => !S.up[nameOf(c)] && S.res[nameOf(c)] !== "started" && !noFolder(c) && !shelved(c);
  const CHECK = ic("check");
  const shown = (n) => typeof pname === "function" ? pname(n) : n;      // a person's own name for it

  function barHtml() {
    return `<span class="bk-n" id="bk-n" aria-live="polite"></span><span class="bk-to" id="bk-to"></span>
      <button class="btn press" id="bk-off">${tl("bk.off")}</button>
      <button class="btn fill press" id="bk-go">${tl("bk.go")}</button>
      <button class="ib press" id="bk-x" aria-label="${tl("bk.cancel")}" title="${tl("bk.cancel")}">${ic("x")}</button>`;
  }

  function paintBar() {
    const bar = document.getElementById("bk-bar"); if (!bar) return;
    const n = S.sel.size;
    bar.querySelector("#bk-n").textContent = n ? tl("bk.count", {n}) : tl("bk.none");
    // Who gets a session: the picked names, as the screens show them.
    const to = bar.querySelector("#bk-to");
    if (to) { to.textContent = n ? tl("bk.to", {names: [...S.sel].map(shown).join(", ")}) : ""; to.title = to.textContent; }
    const go = bar.querySelector("#bk-go");
    go.disabled = !n || S.busy;
    go.textContent = S.busy ? tl("bk.working") : n ? tl("bk.go_n", {n}) : tl("bk.go");
    bar.querySelector("#bk-off").disabled = S.busy;
  }

  // Idempotent: depts.js calls this after every redraw of the list; toggling the mode calls it too.
  function decorate() {
    const el = document.getElementById("view"); if (!el || !onScreen()) return;
    let bar = document.getElementById("bk-bar");
    if (!S.on) {
      if (bar) bar.remove();
      cards().forEach((c) => {
        c.classList.remove("bk-on", "bk-sel", "bk-off");
        c.removeAttribute("aria-checked"); c.removeAttribute("aria-disabled"); c.removeAttribute("role"); c.removeAttribute("tabindex");
        c.classList.remove("bk-run");
        c.querySelectorAll(".bk-chk,.bk-up").forEach((x) => x.remove());
      });
      return;
    }
    if (!cards().length) return;
    if (!bar) {
      bar = document.createElement("div"); bar.id = "bk-bar"; bar.className = "bk-bar"; bar.innerHTML = barHtml();
      el.insertBefore(bar, el.firstChild);
      if (S.entered) bar.classList.add("in");
      else { S.entered = true; enter(bar); }
    }
    cards().forEach((c) => {
      const name = nameOf(c), ok = pickable(c);
      if (!ok) S.sel.delete(name);
      c.classList.add("bk-on"); c.classList.toggle("bk-off", !ok); c.classList.toggle("bk-sel", S.sel.has(name));
      c.setAttribute("role", "checkbox"); c.setAttribute("aria-checked", S.sel.has(name)); c.tabIndex = ok ? 0 : -1;
      if (ok) c.removeAttribute("aria-disabled"); else c.setAttribute("aria-disabled", "true");
      const head = c.querySelector(".dc-head");
      if (!head) return;
      if (!head.querySelector(".bk-chk")) head.insertAdjacentHTML("afterbegin", `<span class="bk-chk" aria-hidden="true">${CHECK}</span>`);
      // One status chip per card: opening now, this run's result, or already running.
      const running = S.busy && S.sel.has(name), r = S.res[name];
      const chip = running ? ["run", tl("bk.working")] : r === "failed" ? ["no", tl("bk.st_fail")]
        : r === "started" ? ["", tl("bk.st_ok")] : S.up[name] || r === "already" ? ["", tl("bk.up")] : null;
      c.classList.toggle("bk-run", running);
      let el0 = head.querySelector(".bk-up");
      if (!chip) { if (el0) el0.remove(); return; }
      if (!el0) { el0 = document.createElement("span"); head.insertBefore(el0, head.querySelector(".dc-open")); }
      el0.className = "bk-up" + (chip[0] ? " " + chip[0] : ""); el0.textContent = chip[1];
    });
    paintBar();
  }
  window.LOOP_DEPTS_DRAWN = decorate;

  // The bar drops in on a critically damped spring; reduced motion is a plain fade.
  function enter(bar) {
    if (S.stop) { S.stop(); S.stop = null; }
    if (RM() || typeof springTo !== "function") { requestAnimationFrame(() => bar.classList.add("in")); return; }
    let y = -18;
    bar.style.transform = `translateY(${y}px)`; bar.classList.add("in");
    S.stop = springTo(() => y, (v) => { y = v; bar.style.transform = v === 0 ? "" : `translateY(${v}px)`; }, 0, 0, () => { S.stop = null; }, 0.4, 1);
  }

  async function loadUp() {
    try {
      const r = await get("/api/depts/running");
      if (r && r.running) S.up = r.running;
    } catch (e) { /* the server checks again before opening anything */ }
    decorate();
  }

  function setMode(on) {
    if (S.busy && !on) return;                   // results still coming back: keep the marks
    if (S.stop) { S.stop(); S.stop = null; }
    S.on = on; S.sel.clear(); S.res = {}; S.entered = false;
    const t = document.querySelector("[data-bk-toggle]"); if (t) t.setAttribute("aria-pressed", on);
    decorate();
    // Esc or the bar's x removes the focused button with the bar: land back on the toggle.
    const f = document.activeElement;
    if (!on && t && (!f || f === document.body || !f.isConnected)) t.focus({preventScroll: true});
    if (on) loadUp();
  }

  function toggleCard(c) {
    if (S.busy || !pickable(c)) return;
    const name = nameOf(c);
    if (S.sel.has(name)) S.sel.delete(name); else S.sel.add(name);
    c.classList.toggle("bk-sel", S.sel.has(name)); c.setAttribute("aria-checked", S.sel.has(name));
    paintBar();
  }

  async function selectOff() {
    if (S.busy) return;
    await loadUp();
    const off = cards().filter(pickable);
    if (!off.length) return toast(tl("bk.no_off"));
    off.forEach((c) => S.sel.add(nameOf(c)));
    decorate();
  }

  function resultSheet(results, meta) {
    const cnt = {started: 0, already: 0, failed: 0};
    results.forEach((r) => { cnt[r.status] = (cnt[r.status] || 0) + 1; });
    const sum = [cnt.started && tl("bk.sum_ok", {n: cnt.started}), cnt.already && tl("bk.sum_already", {n: cnt.already}),
      cnt.failed && tl("bk.sum_fail", {n: cnt.failed})].filter(Boolean).join(" · ");
    const chip = (r) => r.status === "started" ? `<span class="bk-c ok">${tl("bk.st_ok")}</span>`
      : r.status === "already" ? `<span class="bk-c">${tl("bk.st_already")}</span>` : `<span class="bk-c no">${tl("bk.st_fail")}</span>`;
    // A failure says why; an open that fell back to the app or a terminal says where it went.
    const sub = (r) => r.status === "failed" ? r.reason : r.status === "started" && r.via !== "bg" ? r.note : "";
    const rows = results.map((r) => `<div class="bk-r"><span class="n">${meta[r.name] ? meta[r.name] + " " : ""}${esc(shown(r.name))}${sub(r) ? `<small>${esc(sub(r))}</small>` : ""}</span>${chip(r)}</div>`).join("");
    sheet(`<h3>${tl("bk.res_h")}</h3><p class="hint" style="margin:0">${esc(sum)}</p><div class="bk-res">${rows}</div>
      <button class="btn xl press" data-bk-restore hidden>${tl("bk.restore")}</button>
      <button class="btn xl fill press" data-sclose>${tl("bk.done")}</button>`, () => {});
    if (cnt.started) offerRestore();
  }

  // Something just came on: offer to bring the same back after a restart, unless that is already on.
  async function offerRestore() {
    const r = await loopFetch("/api/depts/restore").catch(() => null);
    const b = document.querySelector("#sheet [data-bk-restore]");
    if (!r || r.on || !b) return;
    b.hidden = false;
    b.onclick = async () => {
      try {
        await loopFetch("/api/depts/restore", {json: {on: true}}); b.remove(); toast(tl("bk.restore_on"));
        // Nothing comes back after a restart unless Genok itself starts at login.
        const au = await loopFetch("/api/autostart").catch(() => null);
        if (au && au.installed && !au.on) await loopFetch("/api/autostart", {json: {on: true}});
      } catch (err) { toast(err.message); }
    };
  }

  async function run() {
    const names = [...S.sel]; if (!names.length || S.busy) return;
    if (window.RLAcct && !(await RLAcct.confirmStart(names))) return;
    const meta = {}; cards().forEach((c) => { meta[nameOf(c)] = emojiOf(c); });
    S.busy = true; S.res = {}; decorate();
    try {
      const res = await loopFetch("/api/depts/start-many", {json: {names}});
      if (res && res.results) {
        S.sel.clear(); res.results.forEach((r) => { S.res[r.name] = r.status; });
        resultSheet(res.results, meta);
      }
      else if (res && res.declined) toast(tl("bk.declined"));
    } catch (err) { toast(err.message); }
    finally { S.busy = false; await loadUp(); }
  }

  // The same start from the chat list (the caret beside 새 세션): a sheet of the folders that are
  // off (project.js hands them over: [{name, mark}]), each a checkbox row. Nothing is ticked at
  // first; starting many is the person's own pick.
  window.LOOP_BULK_START = function (off, again) {
    if (!off.length) return toast(tl("bk.no_off"));
    const MAX = 20, sel = new Set(), meta = {};      // MAX: the server opens no more than this in one call
    off.forEach((d) => { meta[d.name] = d.mark || ""; });
    sheet(`<h3>${tl("bk.pick")}</h3><div class="bk-list" role="group" aria-label="${esc(tl("bk.pick"))}">`
      + off.map((d) => `<button type="button" class="bk-row press" role="checkbox" aria-checked="false" data-bkn="${esc(d.name)}"><span class="bk-chk">${CHECK}</span><span class="e">${meta[d.name]}</span><span class="n">${esc(shown(d.name))}</span></button>`).join("")
      + `</div><div class="bk-foot">${off.length <= MAX ? `<button type="button" class="btn press" id="bks-all">${tl("bk.off")}</button>` : ""}<button type="button" class="btn fill press" id="bks-go" disabled>${tl("bk.none")}</button></div>`, (box) => {
      const go = box.querySelector("#bks-go"), all = box.querySelector("#bks-all");
      const paint = () => {
        box.querySelectorAll("[data-bkn]").forEach((r) => { const on = sel.has(r.dataset.bkn); r.classList.toggle("bk-sel", on); r.setAttribute("aria-checked", on); });
        go.disabled = !sel.size; go.textContent = sel.size ? tl("bk.go_n", {n: sel.size}) : tl("bk.none");
      };
      box.querySelector(".bk-list").onclick = (e) => { const r = e.target.closest("[data-bkn]"); if (!r) return;
        if (sel.has(r.dataset.bkn)) sel.delete(r.dataset.bkn); else if (sel.size >= MAX) return toast(tl("bk.max", {n: MAX})); else sel.add(r.dataset.bkn); paint(); };
      if (all) all.onclick = () => { const full = sel.size === off.length; sel.clear(); if (!full) off.forEach((d) => sel.add(d.name)); paint(); };
      go.onclick = async () => {
        const names = [...sel]; if (!names.length) return;
        if (window.RLAcct && !(await RLAcct.confirmStart(names))) return;
        go.disabled = true; if (all) all.disabled = true; go.textContent = tl("bk.working");
        try {
          const res = await loopFetch("/api/depts/start-many", {json: {names}});
          if (res && res.results) resultSheet(res.results, meta);
          else { if (res && res.declined) toast(tl("bk.declined")); if (all) all.disabled = false; paint(); }
        } catch (err) { toast(err.message); if (all) all.disabled = false; paint(); }
        if (again) again();
      };
    });
  };

  // Capture phase on window: in select mode a tap anywhere on a card only toggles it.
  window.addEventListener("click", (e) => {
    if (!S.on || !onScreen()) return;
    const c = e.target.closest("#view .card.dc");
    if (c) { e.preventDefault(); e.stopPropagation(); toggleCard(c); return; }
    const b = e.target.closest("#bk-off,#bk-go,#bk-x"); if (!b) return;
    e.stopPropagation();
    if (b.id === "bk-off") selectOff(); else if (b.id === "bk-go") run(); else setMode(false);
  }, true);
  window.addEventListener("click", (e) => {
    if (!onScreen() || !e.target.closest("[data-bk-toggle]")) return;
    setMode(!S.on);
  });
  addEventListener("keydown", (e) => {
    if (!S.on || !onScreen()) return;
    const c = e.target.closest && e.target.closest("#view .card.dc");
    if (c && (e.key === " " || e.key === "Enter") && !e.target.closest("button")) { e.preventDefault(); toggleCard(c); }
    else if (e.key === "Escape" && !document.getElementById("sheet").classList.contains("on")) setMode(false);
  });
  addEventListener("hashchange", () => { if (S.on && !onScreen()) { S.on = false; S.sel.clear(); S.res = {}; S.entered = false; } });

  // The toolbar button sits before depts.js's own + button.
  if (typeof SCREENS === "undefined" || !SCREENS.depts) return;
  const orig = SCREENS.depts;
  SCREENS.depts = function () {
    const r = orig.apply(this, arguments) || {};
    if (!S.busy) { S.on = false; S.sel.clear(); S.res = {}; S.entered = false; }
    return Object.assign({}, r, {right: `<button class="ib press" data-bk-toggle aria-pressed="false" aria-label="${tl("bk.pick")}" title="${tl("bk.pick")}">${ic("list")}</button>` + (r.right || "")});
  };
})();
