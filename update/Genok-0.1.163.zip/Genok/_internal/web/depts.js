// 담당 세션: 부서를 만들고, 그 폴더에서 세션을 열고, 서브에이전트 역할을 붙인다.
// A core screen (MENUS key "depts"), not an extension. It reuses the app's own classes and the
// sheet() editor (spring present, drag to dismiss, reduced-motion fade). The create sheet walks
// through steps (일 -> 이름 -> 폴더·도구 -> 역할·묶음·계정 -> 미리보기 -> 결과); the step change is a
// spring (interruptible: a new step starts from where the last one is) and a plain fade under
// reduced motion. All server writes that touch the machine (폴더·파일 만들기, 세션 열기) come back
// through loopFetch, which asks the person in consent.js's dialog first.
(function () {
  "use strict";

  let data = {depts: [], default_root: "", role_pool: [], agents: {}, groups: [], accounts: {}, models: [], rooms: []};
  let query = "", shelfOpen = false;
  const onScreen = () => location.hash.slice(1).split("/")[0] === "depts";
  // 에이전트 모드 (head): one session plus its sub-agents, so the + makes a role, not a 부서.
  const headMode = () => document.documentElement.dataset.mode === "head";

  // loaded: the list on hand came from the server at least once. failed: the last ask did not come back.
  let loaded = false, failed = false;
  async function refresh() {
    try { data = await get("/api/depts"); loaded = true; failed = false; } catch (e) { failed = true; /* keep the last copy */ }
  }

  // ---- consent: loopFetch (consent.js) asks in its dialog, remembers, and sends the same call again ----
  async function act(path, body) {
    const res = await loopFetch(path, {json: body});
    return res && res.declined ? null : res;
  }
  const afterAct = async (res) => { if (!res) return; await refresh(); if (onScreen()) draw(); };


  // Styles for this screen only (the app's own classes carry everything else).
  (function () {
    if (document.getElementById("dp-css")) return;
    const st = document.createElement("style"); st.id = "dp-css";
    st.textContent = `
    .dc{padding:16px 16px;border-left:3px solid var(--dc,var(--blue));display:flex;flex-direction:column;gap:12px}
    .dc-head{display:flex;align-items:center;gap:12px;min-width:0}
    .dc-ico{flex:none;width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-size:22px;background:var(--card-hi)}
    .dc-ico svg{width:20px;height:20px}
    .dc-tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
    .dc-name{font-size:16px;font-weight:600;color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .dc-num{font-size:13px;font-weight:500;color:var(--t3);margin-right:6px;font-variant-numeric:tabular-nums}
    .dc-sub{font-size:13px;color:var(--t3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .dc-role{font-size:14px;color:var(--t2);line-height:1.45;overflow-wrap:anywhere}
    .dc-open{flex:none;height:36px;padding:0 16px;font-size:14px}
    .dc-foot{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding-top:12px;border-top:1px solid var(--line)}
    .dc-roles{flex:1;min-width:0;display:flex;align-items:center;gap:6px;flex-wrap:wrap}
    .dc-none{font-size:13px;color:var(--t3);margin-right:2px}
    .dc-add,.dc-quiet{display:inline-flex;align-items:center;gap:4px;height:30px;padding:0 12px;border-radius:8px;font-size:13px;font-weight:500;color:var(--t3);background:none}
    .dc-add svg{width:14px;height:14px}
    .dp-roles{display:flex;flex-direction:column;gap:6px;margin:12px 0 4px}
    .dp-rrow{display:flex;align-items:center;gap:8px;min-height:44px;padding:0 12px;border:1px solid var(--line);border-radius:10px;background:none;text-align:left;font-size:15px;color:var(--t1)}
    .dp-rrow b{flex:1;min-width:0;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .dp-rrow i{flex:none;font-style:normal;font-size:13px;color:var(--t2)}
    .dp-radd{border-style:dashed;color:var(--t2)}
    .dp-radd svg{flex:none;width:16px;height:16px}
    @media (hover:hover){.dc-add:hover,.dc-quiet:hover{background:var(--btn);color:var(--t1)}}
    .dl-top{display:flex;gap:8px;align-items:center;margin:0 0 12px}
    .dl-q{flex:1;min-width:0;height:40px;border:0;outline:none;border-radius:8px;background:var(--card);padding:0 12px;font:inherit;font-size:16px;color:var(--t1)}
    .dl-g{display:flex;align-items:baseline;gap:8px;margin:20px 4px 8px;font-size:15px;font-weight:600;color:var(--t3)}
    .dl-g:first-child{margin-top:4px}
    .dl-g b{font-weight:500;font-size:13px;font-variant-numeric:tabular-nums}
    .dl-g .dl-gn{align-self:center;width:28px;height:28px;padding:0;justify-content:center} .dl-g .dl-gn svg{width:14px;height:14px} .dl-g .dl-gn::before{left:-8px;right:-8px}
    .dl-shelf{display:flex;align-items:center;gap:8px;width:100%;margin:20px 0 8px;padding:8px 4px;background:none;font:inherit;font-size:15px;font-weight:600;color:var(--t3)}
    .dl-shelf svg{width:16px;height:16px;transition:transform .3s cubic-bezier(.2,.9,.25,1)}
    .dl-shelf[aria-expanded="true"] svg{transform:rotate(90deg)}
    .dl-fold{display:grid;grid-template-rows:0fr;transition:grid-template-rows .34s cubic-bezier(.2,.9,.25,1)}
    .dl-fold.on{grid-template-rows:1fr}
    .dl-fin{min-height:0;overflow:hidden}
    .dl-fold:not(.on) .dl-fin{visibility:hidden}
    .dl-fold .dc{opacity:.78}
    .dl-empty{padding:24px 4px;font-size:14px;color:var(--t3)}
    .sbox.dp{padding:22px 22px calc(20px + env(safe-area-inset-bottom))}
    .sbox.dp .sgrab{margin:-12px -24px 0}
    @media (min-width:1024px),(min-width:721px) and (pointer:fine){.sbox.dp{width:480px}}
    .dp-name{display:flex;gap:8px;align-items:center}
    .dp-name .tin{flex:1;min-width:0}
    .dp-emo{flex:none;width:48px;height:48px;border-radius:8px;background:var(--card-hi);font-size:24px;line-height:1;display:grid;place-items:center;border:1.5px solid transparent;transition:border-color .2s}
    .dp-emo[aria-expanded="true"]{border-color:var(--blue)}
    .dp-sug{display:flex;gap:6px}
    .dp-sug button,.dp-grid button{border-radius:8px;background:var(--card-hi);font-size:22px;line-height:1;display:grid;place-items:center;border:1.5px solid transparent}
    .dp-sug button{flex:1;max-width:48px;height:40px}
    .dp-sug button.on{border-color:var(--blue);background:var(--blue-w)}
    .dp-pick{display:grid;grid-template-rows:0fr;margin-top:-8px;transition:grid-template-rows .32s cubic-bezier(.2,.9,.25,1),margin-top .32s cubic-bezier(.2,.9,.25,1)}
    .dp-pick.on{grid-template-rows:1fr;margin-top:0}
    .dp-pin{min-height:0;overflow:hidden;display:flex;flex-direction:column;gap:8px}
    .dp-pick:not(.on) .dp-pin{visibility:hidden}
    .dp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(38px,1fr));gap:4px;max-height:196px;overflow-y:auto;overscroll-behavior:contain}
    .dp-grid button{height:38px;background:none;font-size:21px}
    @media (hover:hover){.dp-grid button:hover{background:var(--btn)}}
    .dp-none{grid-column:1/-1;padding:16px 0;text-align:center;font-size:13px;color:var(--t3)}
    .dp-path{word-break:break-all}
    .dp-where{display:flex;gap:8px;align-items:stretch;margin:6px 0 8px} .dp-where .tin{flex:1;min-width:0} .dp-where .btn.sm{height:auto;flex:none}
    .dp-bar{display:flex;align-items:center;gap:6px;margin:-2px 0 4px}
    .dp-bar span{flex:1;height:4px;border-radius:2px;background:var(--card-hi);transition:background-color .25s}
    .dp-bar span.on{background-color:var(--blue)}
    .dp-step{display:flex;flex-direction:column;gap:8px;will-change:transform}
    .dp-step[hidden]{display:none}
    .dp-q{font-size:15px;color:var(--t2);margin:4px 0 0;line-height:1.5}
    .dp-nav{display:flex;gap:8px;margin-top:8px}
    .sbox .dp-nav .btn{flex:1;margin-top:0}
    .sbox .dp-nav .btn.back{flex:0 0 auto;padding:0 20px}
    .dp-pv{display:flex;flex-direction:column;gap:0;border-radius:12px;background:var(--card-hi);overflow:hidden}
    .dp-pv>div{display:flex;gap:12px;padding:12px 16px;font-size:14px;line-height:1.45;border-top:1px solid var(--line)}
    .dp-pv>div:first-child{border-top:0}
    .dp-pv span{flex:none;width:72px;color:var(--t3)}
    .dp-pv b{flex:1;min-width:0;font-weight:500;color:var(--t1);overflow-wrap:anywhere}
    .dp-warn{display:flex;gap:8px;align-items:flex-start;padding:8px 12px;border-radius:8px;background:rgba(254,152,0,.12);color:#ffae3d;font-size:13px;line-height:1.45}
    .dp-warn svg{flex:none;width:16px;height:16px;margin-top:1px}
    .dp-err{padding:8px 12px;border-radius:8px;background:rgba(240,68,82,.12);color:#ff6b77;font-size:14px;line-height:1.45}
    .dp-done{display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px 0 4px;text-align:center}
    .dp-done .e{font-size:40px;line-height:1.1}
    .dp-done h4{margin:0;font-size:16px}
    .dp-done p{margin:0;font-size:14px;color:var(--t3);line-height:1.5}
    .dp-rooms{display:flex;flex-direction:column;gap:6px}
    .dp-room{display:flex;gap:6px;align-items:center}
    .dp-room .tin{flex:1;min-width:0}
    .dp-room .ib{flex:none}
    .dp-code{margin:0;padding:12px 16px;border-radius:8px;background:var(--card-hi);font:12.5px/1.55 ui-monospace,Consolas,monospace;color:var(--t2);white-space:pre-wrap;overflow-wrap:anywhere;max-height:200px;overflow:auto}
    .dp-row2{display:flex;gap:8px}
    .dp-row2>*{flex:1;min-width:0}
    .dp-danger{align-self:center;height:36px;padding:0 16px;border-radius:8px;background:none;color:#ff6b77;font-size:14px;font-weight:500}
    @media (hover:hover){.dp-danger:hover{background:rgba(240,68,82,.1)}}
    @media (prefers-reduced-motion:reduce){.dp-pick,.dl-fold,.dl-shelf svg,.dp-bar span{transition:none}}`;
    document.head.appendChild(st);
  })();

  // ---- the list --------------------------------------------------------------------------------
  const agentName = (a) => a === "codex" ? "Codex" : "Claude Code";
  const roleChip = (dept, r) => `<span class="tag ${r.status === "working" ? "" : "weak"} press" role="button" tabindex="0" data-rdept="${esc(dept)}" data-rname="${esc(r.name)}" title="${r.last ? esc(r.last.title) : esc(tl("depts.role.idle"))}">${esc(r.emoji)} ${esc(r.name)}<i> · ${r.status === "working" ? tl("depts.role.working") : tl("depts.role.idle")}</i></span>`;

  // A path shortened to its last two folders; the full path stays in the tooltip.
  const onPc = ["127.0.0.1", "localhost", "::1", "[::1]", ""].includes(location.hostname);
  const sysPick = () => (window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder) ? window.pywebview.api.pick_folder : null;
  const shortPath = (p) => {
    const parts = String(p || "").split(/[\\/]+/).filter(Boolean);
    return parts.length > 3 ? "\u2026\\" + parts.slice(-2).join("\\") : String(p || "");
  };

  // The extra account a 부서 is pinned to (nothing for the default one), by its label.
  const accLabel = (d) => { const a = d.account && ((data.accounts || {})[d.agent] || []).find((x) => x.id === d.account); return a ? a.label : (d.account || ""); };

  // What a 부서 is shown as: a person's own emoji and display name (project identity, the same
  // record the rest of the app reads) over the registry's. The registry name stays the key.
  const ident = (d) => (typeof D !== "undefined" && D.ident && D.ident[d.name]) || {};
  const face = (d) => (window.LOOP_ICONS ? LOOP_ICONS.face(ident(d).icon, shownEmoji(d)) : esc(shownEmoji(d)));
  const shownEmoji = (d) => { const i = ident(d); return i.emoji_set && i.emoji ? i.emoji : d.emoji; };
  const shownName = (d) => ident(d).name || d.name;

  function card(d) {
    const roles = (d.roles || []).map((r) => roleChip(d.name, r)).join("");
    const add = `<button class="dc-add press" data-role="${esc(d.name)}" title="${esc(tl("depts.role.addTip"))}">${ic("plus")}${tl("depts.role.add")}</button>`;
    return `<div class="card dc" style="--dc:${esc(d.color)}">
      <div class="dc-head">
        <span class="dc-ico"${ident(d).icon ? ` data-icon="${esc(ident(d).icon)}"` : ""}>${shownEmoji(d) ? face(d) : ic("folder")}</span>
        <span class="dc-tx"><span class="dc-name">${d.num ? `<span class="dc-num">${esc(d.num)}</span>` : ""}${esc(shownName(d))}</span>
          <span class="dc-sub">${typeof liveTag === "function" ? liveTag(d.name) : ""}${agDot(d.agent)}${agentName(d.agent)}${d.account ? " · " + esc(accLabel(d)) : ""}<span class="dc-path"> · <span title="${esc(d.folder)}">${esc(shortPath(d.folder))}</span></span>${d.exists ? "" : ` · <b class='opn'>${tl("depts.noFolder")}</b>`}</span></span>
        <button class="btn fill press dc-open" data-open="${esc(d.name)}">${tl("room.newTitle")}</button>
        <button class="ib sm press" data-dmenu="${esc(d.name)}" aria-haspopup="menu" aria-label="${esc(tl("depts.more"))}" title="${esc(tl("depts.more"))}">${ic("more")}</button>
      </div>
      ${d.role ? `<div class="dc-role">${esc(d.role)}</div>` : ""}
      <div class="dc-foot">
        <div class="dc-roles">${roles}${(d.roles || []).length ? "" : `<span class="dc-none">${tl("depts.role.none")}</span>`}${add}</div>
        <button class="dc-quiet press" data-hint="${esc(d.name)}" title="${esc(tl("depts.hint.tip"))}">${tl("depts.hint.btn")}</button>
      </div>
    </div>`;
  }

  function emptyState() {
    return `<div class="plan mid"><span class="ico c-teal">${ic("plug")}</span>
      <h2>${tl("depts.empty.h")}</h2>
      <p>${tl("depts.empty.p")}</p>
      <button class="btn xl press" data-new>${tl("depts.create")}</button></div>`;
  }

  function knownHtml(L) {
    const nm = (n) => (typeof pname === "function" ? pname(n) : n);
    return `<div class="dl-known">${L.map((g) => `<button class="row press" data-dept="${esc(g.name)}"${inShelf(g.name) ? " data-arc" : ""}><span class="ico sm c-grey">${g.icon ? esc(g.icon) : ic("folder")}</span><span class="tx"><div class="t">${esc(nm(g.name))}</div><div class="s">${typeof liveTag === "function" ? liveTag(g.name) : ""}${tl("depts.known.n", {n: g.items.length})}${g.todo ? `<span class="dkt"> · <b class="opn">${tl("deptRow.1", {todo: g.todo})}</b></span>` : ""}</div></span>${g.todo ? `<em class="num">${g.todo}</em>` : ""}${ic("chev", "i go")}</button>`).join("")}</div>`;
  }

  const shownGroup = (g) => (typeof gpname === "function" ? gpname(g) : g);
  const hit = (d) => !query || [d.name, shownName(d), d.role, d.group, shownGroup(d.group || ""), d.task, ...(d.roles || []).map((r) => r.name)]
    .some((s) => String(s || "").toLowerCase().includes(query));

  // Groups in the order the person meets them: named groups A-Z, then the ones without a group.
  function grouped(list) {
    const by = new Map();
    list.forEach((d) => { const g = d.group || ""; if (!by.has(g)) by.set(g, []); by.get(g).push(d); });
    return [...by.entries()].sort((a, b) => (!a[0]) - (!b[0]) || a[0].localeCompare(b[0], "ko"));
  }

  function listHtml() {
    const all = data.depts || [];
    const live = all.filter((d) => !d.archived && hit(d)), shelf = all.filter((d) => d.archived && hit(d));
    const groups = grouped(live);
    const named = groups.some(([g]) => g);
    let h = all.length > 3 ? `<div class="dl-top"><input class="dl-q" id="dl-q" type="search" spellcheck="false" value="${esc(query)}" placeholder="${esc(tl("depts.search"))}" aria-label="${esc(tl("depts.search"))}"></div>` : "";
    h += groups.map(([g, ds]) => (named ? `<div class="dl-g">${esc(g ? shownGroup(g) : tl("depts.group.none"))}<b>${ds.length}</b>${g ? `<button class="dc-quiet press dl-gn" data-gren="${esc(g)}" aria-label="${esc(tl("room.groupRename"))}" title="${esc(tl("room.groupRename"))}">${ic("pen")}</button>` : ""}</div>` : "") + ds.map(card).join("")).join("");
    if (!live.length && !shelf.length) h += `<div class="dl-empty">${tl("depts.search.none")}</div>`;
    if (shelf.length) {
      h += `<button class="dl-shelf press" id="dl-shelf" aria-expanded="${shelfOpen}" aria-controls="dl-fold">${ic("chev")}${tl("depts.shelf", {n: shelf.length})}</button>
        <div class="dl-fold${shelfOpen ? " on" : ""}" id="dl-fold"><div class="dl-fin">${shelf.map(card).join("")}</div></div>`;
    }
    return h;
  }

  function draw() {
    const el = V(); if (!el) return;
    if (!loaded && failed) {
      // Never loaded: an empty list here would read as "nothing made yet", which is not known.
      el.innerHTML = `<div class="card plan none"><p>${tl("depts.loadFail")}</p><p><button class="btn weak press" id="dl-retry">${tl("upd.retry")}</button></p></div>`;
      el.querySelector("#dl-retry").onclick = screen;
      return;
    }
    if (!(data.depts || []).length) {
      // Nothing was made here yet, but results may already be grouped under projects (pushed
      // from sessions started elsewhere): show those, the same ones the sidebar lists.
      const known = typeof projects === "function" ? projects() : [];
      el.innerHTML = known.length ? knownHtml(known) : emptyState();
      // This list follows the person's own project order, so its rows are dragged into it (not the archived ones).
      if (known.length) pjSort(el.querySelector(".dl-known"), ".dl-known > .row[data-dept]:not([data-arc])", draw);
      return;
    }
    const had = document.activeElement && document.activeElement.id === "dl-q";
    el.innerHTML = listHtml();
    const qEl = el.querySelector("#dl-q");
    if (qEl) {
      qEl.oninput = () => { query = qEl.value.trim().toLowerCase(); draw(); };
      if (had) { qEl.focus({preventScroll: true}); qEl.setSelectionRange(qEl.value.length, qEl.value.length); }
    }
    const sh = el.querySelector("#dl-shelf");
    if (sh) sh.onclick = () => { shelfOpen = !shelfOpen; sh.setAttribute("aria-expanded", shelfOpen); el.querySelector("#dl-fold").classList.toggle("on", shelfOpen); };
    if (window.LOOP_DEPTS_DRAWN) window.LOOP_DEPTS_DRAWN();
  }

  async function screen() {
    if ((data.depts || []).length) draw(); else V().innerHTML = loadingHtml(tl("depts.loading"), {fill: true});
    await refresh();
    if (!onScreen()) return;
    draw();
    if (failed && loaded) toast(tl("depts.stale"));
  }

  // ---- steps: one visible at a time, a spring between them ----------------------------------------
  // Going forward the next step slides in from the right, going back from the left. A step that
  // is still moving is picked up from where it is, so fast taps never jump.
  function stepper(box, count, onShow) {
    const steps = [...box.querySelectorAll(".dp-step")], dots = box.querySelector(".dp-bar");
    let cur = 0, x = 0, stop = null;
    const paint = (el) => { el.style.transform = x ? `translateX(${x}px)` : ""; el.style.opacity = String(Math.max(0, 1 - Math.abs(x) / 60)); };
    function go(n) {
      if (n < 0 || n >= steps.length || n === cur) return;
      const dir = n > cur ? 1 : -1, el = steps[n];
      steps[cur].hidden = true; el.hidden = false; cur = n;
      if (dots) dots.querySelectorAll("span").forEach((b, i) => b.classList.toggle("on", i <= Math.min(n, count - 1)));
      if (stop) stop();
      if (RM()) {
        x = 0; el.style.transform = ""; el.style.transition = "none"; el.style.opacity = "0";
        requestAnimationFrame(() => { el.style.transition = "opacity .2s"; el.style.opacity = "1"; });
      } else {
        // Carry on from the offset on screen when a spring was already running.
        x = stop ? x + dir * 12 : dir * 36; el.style.transition = "none"; paint(el);
        stop = springTo(() => x, (v) => { x = v; paint(el); }, 0, 0, () => { stop = null; }, 0.34, 1);
      }
      onShow && onShow(n, el);
      const f = el.querySelector("[data-focus]");
      if (f && matchMedia("(hover:hover)").matches) setTimeout(() => f.focus({preventScroll: true}), 30);
      box.scrollTop = 0;
    }
    return {go, cur: () => cur};
  }
  const bar = (n) => `<div class="dp-bar" aria-hidden="true">${Array.from({length: n}, (_, i) => `<span${i ? "" : ' class="on"'}></span>`).join("")}</div>`;
  const nav = (id, next, back = true) => `<div class="dp-nav">${back ? `<button type="button" class="btn xl press back" data-stepback>${tl("depts.step.back")}</button>` : ""}<button type="button" class="btn xl fill press" id="${id}">${next}</button></div>`;
  const pvRow = (k, v) => v ? `<div><span>${k}</span><b>${v}</b></div>` : "";
  const warnHtml = (ws) => (ws || []).map((w) => `<div class="dp-warn">${ic("warn")}<span>${esc(w)}</span></div>`).join("");

  // ---- create sheet: a 부서, or a project of several rooms -----------------------------------------
  function createHtml() {
    const claudeOk = data.agents && data.agents.claude, codexOk = data.agents && data.agents.codex;
    const groups = (data.groups || []).map((g) => `<option value="${esc(g)}">`).join("");
    return `<h3>${tl("depts.create")}</h3>
      <div class="seg wide" id="d-kind" role="radiogroup" aria-label="${esc(tl("depts.kind"))}">
        <button type="button" class="press on" data-kind="one" role="radio" aria-checked="true">${tl("depts.kind.one")}</button>
        <button type="button" class="press" data-kind="proj" role="radio" aria-checked="false">${tl("depts.kind.proj")}</button></div>
      <div id="d-one">
      ${bar(5)}
      <div class="dp-step" data-s="0">
        <p class="dp-q">${tl("depts.step.task")}</p>
        <textarea id="d-task" rows="3" maxlength="200" data-focus placeholder="${esc(tl("depts.step.task.ph"))}" aria-label="${esc(tl("depts.step.task"))}"></textarea>
        <p class="hint">${tl("depts.step.task.hint")}</p>
        ${nav("d-n0", tl("depts.step.next"), false)}
      </div>
      <div class="dp-step" data-s="1" hidden>
        <p class="dp-q">${tl("depts.step.name")}</p>
        <div class="dp-name">
          <button type="button" class="dp-emo press" id="d-emoji" aria-expanded="false" aria-controls="d-pick" title="${esc(tl("depts.emoji.pick"))}">🗂</button>
          <input class="tin" id="d-name" type="text" maxlength="120" spellcheck="false" data-focus placeholder="${esc(tl("depts.name.ph"))}" aria-label="${esc(tl("depts.name"))}">
        </div>
        <div class="dp-sug" id="d-sug" role="group" aria-label="${esc(tl("depts.emoji.sug"))}"></div>
        <div class="dp-pick" id="d-pick"><div class="dp-pin">
          <input class="tin" id="d-eq" type="search" spellcheck="false" placeholder="${esc(tl("depts.emoji.search"))}" aria-label="${esc(tl("depts.emoji.search"))}">
          <div class="dp-grid" id="d-grid" role="listbox" aria-label="${esc(tl("depts.emoji"))}"></div></div></div>
        ${nav("d-n1", tl("depts.step.next"))}
      </div>
      <div class="dp-step" data-s="2" hidden>
        <div class="lbl">${tl("depts.folder")}</div>
        <div class="seg wide" id="d-fmode">
          <button type="button" class="press on" data-fm="new">${tl("depts.folder.new")}</button>
          <button type="button" class="press" data-fm="pick">${tl("depts.folder.pick")}</button></div>
        <div id="d-fwhere"${onPc ? "" : " hidden"}><div class="lbl">${tl("depts.folder.where")}</div>
          <div class="dp-where"><input class="tin" id="d-fpar" type="text" spellcheck="false" autocomplete="off" placeholder="${esc(tl("room.loc.ph"))}" aria-label="${esc(tl("depts.folder.where"))}">
            ${sysPick() ? `<button type="button" class="btn sm press" id="d-fbtn">${tl("room.loc.pick")}</button>` : ""}</div></div>
        <div id="d-fnew" class="hint dp-path"></div>
        <input class="tin" id="d-fpick" type="text" spellcheck="false" placeholder="${esc(tl("depts.folder.ph"))}" aria-label="${esc(tl("depts.folder.ph"))}" hidden>
        <label class="row" id="d-wfrow" style="gap:8px;align-items:center" hidden><input type="checkbox" id="d-wf" checked> <span>${tl("depts.folder.files")}</span></label>
        <div class="lbl">${tl("depts.agent")}</div>
        <div class="seg wide" id="d-agent">
          <button type="button" class="press on" data-ag="claude">${agDot("claude")}Claude Code${claudeOk ? "" : tl("depts.agent.missing")}</button>
          <button type="button" class="press" data-ag="codex">${agDot("codex")}Codex${codexOk ? "" : tl("depts.agent.missing")}</button></div>
        ${nav("d-n2", tl("depts.step.next"))}
      </div>
      <div class="dp-step" data-s="3" hidden>
        <div class="lbl">${tl("depts.role")}</div>
        <input class="tin" id="d-role" type="text" maxlength="${data.role_max || 40}" spellcheck="false" data-focus aria-label="${esc(tl("depts.role"))}">
        <div class="lbl">${tl("depts.group")}</div>
        <input class="tin" id="d-group" type="text" maxlength="40" spellcheck="false" list="d-groups" placeholder="${esc(tl("depts.group.ph"))}" aria-label="${esc(tl("depts.group"))}">
        <datalist id="d-groups">${groups}</datalist>
        <div id="d-accwrap" hidden><div class="lbl">${tl("depts.account")}</div>
          <gk-select id="d-acc" aria-label="${esc(tl("depts.account"))}"></gk-select></div>
        ${nav("d-n3", tl("depts.step.preview"))}
      </div>
      <div class="dp-step" data-s="4" hidden>
        <p class="dp-q">${tl("depts.pv.q")}</p>
        <div id="d-pv"></div>
        ${nav("d-save", tl("depts.pv.make"))}
      </div>
      <div class="dp-step" data-s="5" hidden><div id="d-done"></div></div>
      </div>
      <div id="d-proj" hidden>
      ${bar(2)}
      <div class="dp-step" data-s="0">
        <p class="dp-q">${tl("depts.proj.q")}</p>
        <input class="tin" id="p-name" type="text" maxlength="60" spellcheck="false" data-focus placeholder="${esc(tl("depts.proj.name.ph"))}" aria-label="${esc(tl("depts.proj.name"))}">
        <div class="lbl">${tl("depts.proj.rooms")}</div>
        <div class="dp-rooms" id="p-rooms"></div>
        <button type="button" class="dc-add press" id="p-add" style="align-self:flex-start">${ic("plus")}${tl("depts.proj.addRoom")}</button>
        <div class="lbl">${tl("depts.proj.work")}</div>
        <input class="tin" id="p-work" type="text" spellcheck="false" placeholder="D:\\Work\\..." aria-label="${esc(tl("depts.proj.work"))}">
        <p class="hint">${more1(tl("depts.proj.work.hint"), tl("depts.proj.work.more"))}</p>
        <div class="seg wide" id="p-agent">
          <button type="button" class="press on" data-ag="claude">${agDot("claude")}Claude Code</button>
          <button type="button" class="press" data-ag="codex">${agDot("codex")}Codex</button></div>
        ${nav("p-n0", tl("depts.step.preview"), false)}
      </div>
      <div class="dp-step" data-s="1" hidden>
        <p class="dp-q">${tl("depts.pv.q")}</p>
        <div id="p-pv"></div>
        ${nav("p-save", tl("depts.pv.make"))}
      </div>
      <div class="dp-step" data-s="2" hidden><div id="p-done"></div></div>
      </div>`;
  }

  // What the create call sends back as a preview, as rows the person can read.
  const makesText = (m, doc) => (m || []).map((x) => x === "folder" ? tl("depts.pv.m.folder") : x === ".claude/agents" ? tl("depts.pv.m.agents") : x).join(" · ") || tl("depts.pv.m.none");

  function wireCreate(box) {
    box.classList.add("dp");
    const q = (s) => box.querySelector(s);
    const EM = window.LOOP_EMOJI;
    let emoji = "🗂", agent = "claude", fmode = "new", picked = false;
    const one = stepper(q("#d-one"), 5, (n) => { if (n === 3) fillRole(); if (n === 4) preview(); });
    const nameEl = q("#d-name"), emojiEl = q("#d-emoji"), fnew = q("#d-fnew"), fpick = q("#d-fpick");
    const sugEl = q("#d-sug"), pickEl = q("#d-pick"), gridEl = q("#d-grid"), eqEl = q("#d-eq");
    const taskEl = q("#d-task"), roleEl = q("#d-role"), groupEl = q("#d-group"), accEl = q("#d-acc");
    const taken = () => (data.depts || []).map((d) => d.emoji).filter(Boolean);
    // Where a new folder goes: a field that takes a typed or pasted path (the server checks it);
    // Explorer's chooser is an extra inside the app window, and when it gives nothing back the
    // caret goes to the field.
    const fpar = q("#d-fpar"), fbtn = q("#d-fbtn"), root0 = data.parent || data.default_root || "";
    const par = () => (onPc && fpar.value.trim().replace(/^"+|"+$/g, "").trim()) || root0;
    fpar.value = root0;
    const showFolder = () => { const p = par().replace(/[\\/]+$/, ""); fnew.textContent = shortPath(p + "\\" + (nameEl.value.trim() || tl("depts.name.slot"))); fnew.title = p + "\\" + nameEl.value.trim(); };
    fpar.oninput = showFolder;
    if (fbtn) fbtn.onclick = async () => {
      let p = null;
      try { p = await sysPick()(par()); } catch (e) { /* no dialog */ }
      if (p) { fpar.value = String(p); showFolder(); } else { fpar.focus(); fpar.select(); }
    };
    const setEmoji = (e) => {
      emoji = e; emojiEl.textContent = e;
      sugEl.querySelectorAll("[data-e]").forEach((b) => b.classList.toggle("on", b.dataset.e === e));
    };
    const drawSug = () => {
      const list = EM ? EM.suggest(nameEl.value || taskEl.value, taken(), 6) : [emoji];
      sugEl.innerHTML = list.map((e) => `<button type="button" class="press" data-e="${e}" aria-label="${e}">${e}</button>`).join("");
      if (!picked) emoji = list[0];
      setEmoji(emoji);
    };
    const drawGrid = () => {
      if (!EM) return;
      const res = EM.search(eqEl.value, eqEl.value.trim() ? 400 : 2000);
      gridEl.innerHTML = res.length
        ? res.map((o) => `<button type="button" role="option" data-e="${o.e}" title="${esc(o.n)}" aria-label="${esc(o.n || o.e)}">${o.e}</button>`).join("")
        : `<span class="dp-none">${tl("depts.emoji.none")}</span>`;
    };
    const togglePick = (on) => {
      on = on == null ? !pickEl.classList.contains("on") : on;
      pickEl.classList.toggle("on", on); emojiEl.setAttribute("aria-expanded", on);
      if (on) { if (!gridEl.firstChild) drawGrid(); setTimeout(() => eqEl.focus({preventScroll: true}), 60); }
    };
    const choose = (e) => { picked = true; setEmoji(e); };
    nameEl.oninput = () => { showFolder(); drawSug(); };
    emojiEl.onclick = () => togglePick();
    sugEl.onclick = (ev) => { const b = ev.target.closest("[data-e]"); if (b) choose(b.dataset.e); };
    gridEl.onclick = (ev) => { const b = ev.target.closest("[data-e]"); if (b) { choose(b.dataset.e); togglePick(false); } };
    let qT = 0; eqEl.oninput = () => { clearTimeout(qT); qT = setTimeout(drawGrid, 120); };
    eqEl.onkeydown = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); togglePick(false); emojiEl.focus(); } };
    q("#d-fmode").querySelectorAll("[data-fm]").forEach((b) => b.onclick = () => {
      fmode = b.dataset.fm;
      q("#d-fmode").querySelectorAll("[data-fm]").forEach((x) => x.classList.toggle("on", x.dataset.fm === fmode));
      fnew.hidden = fmode !== "new"; q("#d-fwhere").hidden = fmode !== "new" || !onPc; fpick.hidden = fmode !== "pick"; q("#d-wfrow").hidden = fmode !== "pick";
      if (fmode === "pick") fpick.focus({preventScroll: true});
    });
    const drawAcc = () => {
      const list = (data.accounts || {})[agent] || [];
      q("#d-accwrap").hidden = !list.length;
      accEl.innerHTML = `<option value="">${esc(tl("depts.account.default"))}</option>` + list.map((a) => `<option value="${esc(a.id)}">${esc(a.label)}</option>`).join("");
    };
    q("#d-agent").querySelectorAll("[data-ag]").forEach((b) => b.onclick = () => {
      agent = b.dataset.ag;
      q("#d-agent").querySelectorAll("[data-ag]").forEach((x) => x.classList.toggle("on", x.dataset.ag === agent));
      drawAcc();
    });
    // The role line starts as the task, cut to fit; the person's own edit is kept.
    let roleTouched = false;
    roleEl.oninput = () => { roleTouched = true; };
    const fillRole = () => { if (!roleTouched) roleEl.value = taskEl.value.trim().slice(0, data.role_max || 40); };
    showFolder(); drawSug(); drawAcc();

    const body = (dry) => {
      const b = {name: nameEl.value.trim(), emoji, agent, task: taskEl.value.trim(), role: roleEl.value.trim(), group: groupEl.value.trim(), account: accEl.value};
      if (fmode === "pick") { b.folder = fpick.value.trim(); b.write_files = q("#d-wf").checked; } else { b.create = true; if (onPc) b.parent = par().toLowerCase() === String(data.default_root || "").toLowerCase() ? "" : par(); }
      if (dry) b.dry_run = true;
      return b;
    };
    async function preview() {
      const pv = q("#d-pv"), save = q("#d-save");
      pv.innerHTML = loadingHtml(tl("depts.loading")); save.disabled = true;
      try {
        const p = (await post("/api/depts/create", body(true))).preview;
        pv.innerHTML = `<div class="dp-pv">
          ${pvRow(tl("depts.pv.name"), esc(p.label))}
          ${pvRow(tl("depts.pv.role"), esc(p.role))}
          ${pvRow(tl("depts.pv.folder"), `<span class="dp-path" title="${esc(p.folder)}">${esc(p.folder)}</span>`)}
          ${pvRow(tl("depts.pv.makes"), esc(makesText(p.makes)))}
          ${pvRow(tl("depts.pv.agent"), agDot(p.agent) + esc(agentName(p.agent)) + (p.account_label ? " · " + esc(p.account_label) : ""))}
          ${pvRow(tl("depts.pv.group"), esc(p.group))}
          ${pvRow(tl("depts.pv.first"), esc(p.first_line))}</div>${warnHtml(p.warnings)}`;
        save.disabled = false;
      } catch (err) {
        // The usual one: the folder is another 부서's. Say it, and let the person go back to fix it.
        pv.innerHTML = `<div class="dp-err">${esc(err.message)}</div>`;
      }
    }
    const need = (el, msg) => { if (el.value.trim()) return true; toast(msg); el.focus(); return false; };
    q("#d-n0").onclick = () => { if (!nameEl.value.trim() && EM) drawSug(); one.go(1); };
    q("#d-n1").onclick = () => need(nameEl, tl("depts.err.name")) && one.go(2);
    q("#d-n2").onclick = () => (fmode === "new" || need(fpick, tl("depts.err.folder"))) && one.go(3);
    q("#d-n3").onclick = () => one.go(4);
    q("#d-one").addEventListener("click", (ev) => { if (ev.target.closest("[data-stepback]")) one.go(one.cur() - 1); });
    nameEl.onkeydown = (ev) => { if (ev.key === "Enter" && !ev.isComposing) q("#d-n1").click(); };
    q("#d-save").onclick = async (e) => {
      const btn = e.currentTarget; btn.disabled = true;
      try {
        const res = await act("/api/depts/create", body(false));
        if (!res || !res.dept) { btn.disabled = false; return; }    // cancelled at the consent dialog
        await refresh(); if (onScreen()) draw();
        q("#d-done").innerHTML = doneHtml(res.dept.emoji, tl("depts.done.h", {name: res.dept.name}),
          tl("depts.done.p", {made: makesText(res.made)}), res.warnings) +
          nav("d-openNow", res.dept.agent === "codex" ? tl("depts.done.openTerm") : tl("depts.open"), false) +
          `<button type="button" class="dc-quiet press" data-sclose style="align-self:center">${tl("depts.done.later")}</button>`;
        q("#d-openNow").onclick = (ev) => openDept(res.dept.name, ev.currentTarget, true);
        one.go(5);
      } catch (err) { toast(err.message); btn.disabled = false; }
    };

    // ---- the project kind: rooms under one folder, one group ----
    const proj = stepper(q("#d-proj"), 2, (n) => { if (n === 1) projPreview(); });
    let pAgent = "claude";
    const roomsEl = q("#p-rooms");
    const roomRow = (n, r) => `<div class="dp-room"><input class="tin" type="text" maxlength="40" spellcheck="false" value="${esc(n)}" data-rrole="${esc(r || "")}" aria-label="${esc(tl("depts.proj.room"))}"><button type="button" class="ib sm press" data-rm aria-label="${esc(tl("depts.proj.rmRoom"))}">${ic("x")}</button></div>`;
    roomsEl.innerHTML = (data.rooms || []).map((r) => roomRow(r.name, r.role)).join("");
    roomsEl.onclick = (ev) => { const b = ev.target.closest("[data-rm]"); if (b && roomsEl.children.length > 1) b.parentElement.remove(); };
    q("#p-add").onclick = () => { if (roomsEl.children.length >= 8) return; roomsEl.insertAdjacentHTML("beforeend", roomRow("", "")); roomsEl.lastElementChild.querySelector("input").focus(); };
    q("#p-agent").querySelectorAll("[data-ag]").forEach((b) => b.onclick = () => {
      pAgent = b.dataset.ag; q("#p-agent").querySelectorAll("[data-ag]").forEach((x) => x.classList.toggle("on", x.dataset.ag === pAgent));
    });
    const pBody = (dry) => ({project: q("#p-name").value.trim(), work_path: q("#p-work").value.trim(), agent: pAgent,
      rooms: [...roomsEl.querySelectorAll("input")].map((i) => ({name: i.value.trim(), role: i.dataset.rrole || ""})).filter((r) => r.name), dry_run: dry});
    async function projPreview() {
      const pv = q("#p-pv"), save = q("#p-save");
      pv.innerHTML = loadingHtml(tl("depts.loading")); save.disabled = true;
      try {
        const p = (await post("/api/depts/project", pBody(true))).preview;
        pv.innerHTML = `<div class="dp-pv">
          ${pvRow(tl("depts.pv.name"), esc(p.emoji + " " + p.project))}
          ${pvRow(tl("depts.pv.folder"), `<span class="dp-path">${esc(p.folder)}</span>`)}
          ${pvRow(tl("depts.proj.rooms"), p.rooms.map((r) => esc(r.emoji + " " + r.name)).join("<br>"))}
          ${pvRow(tl("depts.proj.work"), esc(p.work_path))}
          ${pvRow(tl("depts.pv.agent"), agDot(p.agent) + esc(agentName(p.agent)))}</div>${warnHtml(p.warnings)}`;
        save.disabled = false;
      } catch (err) { pv.innerHTML = `<div class="dp-err">${esc(err.message)}</div>`; }
    }
    q("#p-n0").onclick = () => need(q("#p-name"), tl("depts.err.proj")) && proj.go(1);
    q("#d-proj").addEventListener("click", (ev) => { if (ev.target.closest("[data-stepback]")) proj.go(proj.cur() - 1); });
    q("#p-save").onclick = async (e) => {
      const btn = e.currentTarget; btn.disabled = true;
      try {
        const res = await act("/api/depts/project", pBody(false));
        if (!res || !res.depts) { btn.disabled = false; return; }
        await refresh(); if (onScreen()) draw();
        q("#p-done").innerHTML = doneHtml("🗂", tl("depts.proj.done.h", {name: res.project}),
          tl("depts.proj.done.p", {n: res.depts.length})) +
          `<div class="dp-rooms">${res.depts.map((n) => `<button type="button" class="btn press" data-popen="${esc(n)}">${esc(tl("depts.proj.openRoom", {name: n}))}</button>`).join("")}</div>`;
        q("#p-done").onclick = (ev) => { const b = ev.target.closest("[data-popen]"); if (b) openDept(b.dataset.popen, b, false); };
        proj.go(2);
      } catch (err) { toast(err.message); btn.disabled = false; }
    };

    q("#d-kind").querySelectorAll("[data-kind]").forEach((b) => b.onclick = () => {
      const k = b.dataset.kind;
      q("#d-kind").querySelectorAll("[data-kind]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-checked", x === b); });
      q("#d-one").hidden = k !== "one"; q("#d-proj").hidden = k !== "proj";
    });
  }

  const doneHtml = (emoji, h, p, warnings) => `<div class="dp-done"><span class="e">${esc(emoji || "")}</span><h4>${esc(h)}</h4><p>${esc(p)}</p></div>${warnHtml(warnings)}`;

  // Open a 부서's session. A background open that could not start falls back to the app with the
  // first line put on the clipboard, so pasting it is all that is left.
  async function openDept(name, btn, close) {
    if (btn) btn.disabled = true;
    try {
      if (window.RLAcct && !(await RLAcct.confirmStart([name]))) return;
      const res = await act("/api/depts/open", {name});
      if (!res) return;
      if (res.via === "bg" && window.RLAcct) RLAcct.watchStart(name);
      if (close) closeSheet();
      if (res.first) {
        const ok = await copyText(res.first);
        toast((res.why ? res.why + " " : "") + (ok ? tl("depts.open.copied") : res.note), 5200);
      } else toast(res.note || tl("depts.open.done"));
      await afterAct(res);
    } catch (err) { toast(err.message); }
    finally { if (btn && btn.isConnected) btn.disabled = false; }
  }

  const openCreate = () => headMode() ? roleCreate() : sheet(createHtml(), wireCreate);

  // ---- roles: add (with a preview of the file), hand work to one, take one out ------------------
  function roleCreate(dept) {
    const list = (data.depts || []).filter((d) => !d.archived);
    if (!list.length) return sheet(createHtml(), wireCreate);
    const models = (data.models || ["inherit"]).map((m) => `<option value="${esc(m)}">${esc(m === "inherit" ? tl("depts.model.inherit") : m)}</option>`).join("");
    sheet(`<h3>${tl("depts.rc.h")}</h3>
      ${bar(2)}
      <div class="dp-step" data-s="0">
        <p class="dp-q">${tl("depts.rc.q")}</p>
        <div class="lbl">${tl("depts.rc.dept")}</div>
        <gk-select id="r-dept" aria-label="${esc(tl("depts.rc.dept"))}">${list.map((d) => `<option value="${esc(d.name)}"${d.name === dept ? " selected" : ""}>${esc((d.emoji || "") + " " + d.name)}</option>`).join("")}</gk-select>
        <div class="dp-row2">
          <div><div class="lbl">${tl("depts.rc.name")}</div><input class="tin" id="r-name" type="text" maxlength="20" spellcheck="false" data-focus aria-label="${esc(tl("depts.rc.name"))}"></div>
          <div><div class="lbl">${tl("depts.rc.model")}</div><gk-select id="r-model" aria-label="${esc(tl("depts.rc.model"))}">${models}</gk-select></div>
        </div>
        <div class="lbl">${tl("depts.rc.desc")}</div>
        <input class="tin" id="r-desc" type="text" maxlength="120" spellcheck="false" aria-label="${esc(tl("depts.rc.desc"))}">
        ${nav("r-n0", tl("depts.step.preview"), false)}
      </div>
      <div class="dp-step" data-s="1" hidden>
        <p class="dp-q" id="r-where"></p>
        <div id="r-pv"></div>
        ${nav("r-save", tl("depts.rc.make"))}
      </div>`, (box) => {
      box.classList.add("dp");
      const q = (s) => box.querySelector(s);
      const st = stepper(box, 2, (n) => { if (n === 1) pv(); });
      const pool = () => { const d = list.find((x) => x.name === q("#r-dept").value); const used = new Set((d && d.roles || []).map((r) => r.name));
        return (data.role_pool || []).find((r) => !used.has(r)) || ""; };
      const fillName = () => { const n = pool(); q("#r-name").placeholder = n; q("#r-desc").placeholder = (data.role_desc || {})[n] || ""; };
      q("#r-dept").onchange = fillName; fillName();
      q("#r-name").oninput = () => { q("#r-desc").placeholder = (data.role_desc || {})[q("#r-name").value.trim()] || ""; };
      const body = (dry) => ({name: q("#r-dept").value, role: q("#r-name").value.trim(), desc: q("#r-desc").value.trim(), model: q("#r-model").value, dry_run: dry});
      async function pv() {
        const el = q("#r-pv"), save = q("#r-save"); save.disabled = true; el.innerHTML = loadingHtml(tl("depts.loading"));
        try {
          const p = (await post("/api/depts/role", body(true))).preview;
          q("#r-where").textContent = p.file ? tl("depts.rc.file", {file: shortPath(p.file)}) : tl("depts.rc.label");
          el.innerHTML = (p.text ? `<pre class="dp-code">${esc(p.text)}</pre>` : "") + (p.restart ? warnHtml([tl("depts.rc.restart")]) : "");
          save.disabled = false;
        } catch (err) { el.innerHTML = `<div class="dp-err">${esc(err.message)}</div>`; }
      }
      q("#r-n0").onclick = () => st.go(1);
      box.addEventListener("click", (ev) => { if (ev.target.closest("[data-stepback]")) st.go(st.cur() - 1); });
      q("#r-save").onclick = async (e) => {
        const btn = e.currentTarget; btn.disabled = true;
        try {
          const res = await act("/api/depts/role", body(false));
          if (!res || !res.role) { btn.disabled = false; return; }
          closeSheet(); toast(res.restart ? tl("depts.rc.madeRestart", {name: res.role.name}) : tl("depts.rc.made", {name: res.role.name}), 4200);
          await afterAct(res);
        } catch (err) { toast(err.message); btn.disabled = false; }
      };
    });
  }

  function roleSheet(dept, rname) {
    const d = (data.depts || []).find((x) => x.name === dept); if (!d) return;
    const r = (d.roles || []).find((x) => x.name === rname); if (!r) return;
    sheet(`<h3>${esc((r.emoji || "") + " " + r.name)}</h3>
      <p class="hint">${esc(tl("depts.rs.sub", {dept: d.name}))}${r.model && r.model !== "inherit" ? " · " + esc(r.model) : ""}</p>
      ${r.desc ? `<p class="dp-q">${esc(r.desc)}</p>` : ""}
      ${r.file ? `<p class="hint dp-path" title="${esc(r.file)}">${esc(shortPath(r.file))}</p>` : ""}
      <div class="lbl">${tl("depts.rs.task")}</div>
      <textarea id="r-task" rows="3" maxlength="500" placeholder="${esc(tl("depts.rs.task.ph"))}" aria-label="${esc(tl("depts.rs.task"))}"></textarea>
      <button type="button" class="btn xl fill press" id="r-go">${tl("depts.rs.go")}</button>
      <button type="button" class="dp-danger press" id="r-rm">${tl("depts.rs.remove")}</button>`, (box) => {
      box.classList.add("dp");
      const t = box.querySelector("#r-task");
      if (matchMedia("(hover:hover)").matches) setTimeout(() => t.focus({preventScroll: true}), 60);
      box.querySelector("#r-go").onclick = async (e) => {
        const text = t.value.trim(); if (!text) { toast(tl("depts.rs.empty")); t.focus(); return; }
        const btn = e.currentTarget; btn.disabled = true;
        try {
          const res = await act("/api/depts/delegate", {name: dept, role: rname, text});
          if (!res) { btn.disabled = false; return; }
          closeSheet();
          if (res.first) { const ok = await copyText(res.first); toast((res.why ? res.why + " " : "") + (ok ? tl("depts.open.copied") : res.note), 5200); }
          else toast(res.message || res.note || tl("depts.rs.sent"));
          await afterAct(res);
        } catch (err) { toast(err.message); btn.disabled = false; }
      };
      box.querySelector("#r-rm").onclick = async () => {
        try {
          const res = await post("/api/depts/role-remove", {name: dept, role: rname});
          closeSheet(); toast(res.kept ? tl("depts.rs.kept") : tl("depts.rs.removed", {name: rname}), 4200);
          await afterAct(res);
        } catch (err) { toast(err.message); }
      };
    });
  }

  // The folder's roles from the chat list's folder menu: pick one to hand it work, or add one.
  // A folder with none goes straight to making the first.
  function rolesSheet(d) {
    const roles = d.roles || [];
    if (!roles.length) return roleCreate(d.name);
    sheet(`<h3>${esc(tl("depts.rs.sub", {dept: d.name}))}</h3>
      <div class="dp-roles">${roles.map((r) => `<button type="button" class="dp-rrow press" data-pick="${esc(r.name)}"><span>${esc(r.emoji || "")}</span><b>${esc(r.name)}</b><i>${r.status === "working" ? tl("depts.role.working") : tl("depts.role.idle")}</i></button>`).join("")}
        <button type="button" class="dp-rrow dp-radd press" data-radd>${ic("plus")}<b>${tl("depts.role.add")}</b></button></div>`, (box) => {
      box.classList.add("dp");
      box.querySelectorAll("[data-pick]").forEach((b) => { b.onclick = () => roleSheet(d.name, b.dataset.pick); });
      box.querySelector("[data-radd]").onclick = () => roleCreate(d.name);
    });
  }

  // ---- the one-line hint + open picker ---------------------------------------------------------
  function hintSheet(d) {
    sheet(`<h3>${tl("depts.hint.h")}</h3>
      <p class="hint" style="margin:0 0 10px">${tl("depts.hint.p")}</p>
      <textarea id="d-hint" rows="4" spellcheck="false" readonly style="width:100%">${esc(d.push_hint)}</textarea>
      <button class="btn xl fill press" id="d-copy" style="margin-top:10px">${tl("depts.hint.copy")}</button>`, (box) => {
      box.querySelector("#d-copy").onclick = async () => {
        if (await copyText(d.push_hint)) toast(tl("depts.hint.copied")); else toast(tl("depts.hint.copyFail"));
      };
    });
  }

  function groupSheet(d) {
    const groups = (data.groups || []).map((g) => `<option value="${esc(g)}">`).join("");
    sheet(`<h3>${tl("depts.group.h")}</h3>
      <input class="tin" id="g-name" type="text" maxlength="40" spellcheck="false" list="g-list" value="${esc(d.group || "")}" placeholder="${esc(tl("depts.group.ph"))}" aria-label="${esc(tl("depts.group"))}">
      <datalist id="g-list">${groups}</datalist>
      <button class="btn xl fill press" id="g-save">${tl("depts.group.save")}</button>`, (box) => {
      box.classList.add("dp");
      const i = box.querySelector("#g-name");
      const save = async () => {
        try { const res = await post("/api/depts/update", {name: d.name, group: i.value.trim()}); closeSheet(); await afterAct(res); }
        catch (err) { toast(err.message); }
      };
      box.querySelector("#g-save").onclick = save;
      i.onkeydown = (ev) => { if (ev.key === "Enter" && !ev.isComposing) save(); };
    });
  }

  // Name and emoji. This changes what the screens show, nothing on disk: the folder, the
  // registry key and the push target keep the real name, so a running session carries on as it is.
  function renameSheet(d) {
    const EM = window.LOOP_EMOJI;
    sheet(`<h3>${tl("depts.menu.rename")}</h3>
      <div class="dp-name">
        <button type="button" class="dp-emo press" id="n-emoji" aria-expanded="false" aria-controls="n-pick" title="${esc(tl("depts.emoji.pick"))}">${shownEmoji(d) ? face(d) : "🗂"}</button>
        <input class="tin" id="n-name" type="text" maxlength="60" spellcheck="false" value="${esc(shownName(d))}" placeholder="${esc(d.name)}" aria-label="${esc(tl("depts.name"))}">
      </div>
      <div class="dp-pick" id="n-pick"><div class="dp-pin">
        <input class="tin" id="n-eq" type="search" spellcheck="false" placeholder="${esc(tl("depts.emoji.search"))}" aria-label="${esc(tl("depts.emoji.search"))}">
        <div class="dp-grid" id="n-grid" role="listbox" aria-label="${esc(tl("depts.emoji"))}"></div></div></div>
      <p class="hint">${tl("depts.rn.note")}</p>
      <button type="button" class="btn xl fill press" id="n-save">${tl("depts.group.save")}</button>`, (box) => {
      box.classList.add("dp");
      const q = (s) => box.querySelector(s);
      const nameEl = q("#n-name"), emojiEl = q("#n-emoji"), pickEl = q("#n-pick"), gridEl = q("#n-grid"), eqEl = q("#n-eq");
      let emoji = shownEmoji(d) || "", picked = false;
      const drawGrid = () => {
        if (!EM) return;
        const res = EM.search(eqEl.value, eqEl.value.trim() ? 400 : 2000);
        gridEl.innerHTML = res.length
          ? res.map((o) => `<button type="button" role="option" data-e="${o.e}" title="${esc(o.n)}" aria-label="${esc(o.n || o.e)}">${o.e}</button>`).join("")
          : `<span class="dp-none">${tl("depts.emoji.none")}</span>`;
      };
      const togglePick = (on) => {
        on = on == null ? !pickEl.classList.contains("on") : on;
        pickEl.classList.toggle("on", on); emojiEl.setAttribute("aria-expanded", on);
        if (on) { if (!gridEl.firstChild) drawGrid(); setTimeout(() => eqEl.focus({preventScroll: true}), 60); }
      };
      emojiEl.onclick = () => togglePick();
      gridEl.onclick = (ev) => { const b = ev.target.closest("[data-e]"); if (!b) return;
        emoji = b.dataset.e; picked = true; emojiEl.textContent = emoji; togglePick(false); };
      let qT = 0; eqEl.oninput = () => { clearTimeout(qT); qT = setTimeout(drawGrid, 120); };
      eqEl.onkeydown = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); togglePick(false); emojiEl.focus(); } };
      const save = async () => {
        const body = {project: d.name, name: nameEl.value.trim() || d.name};
        if (picked) body.emoji = emoji;
        try {
          await post("/api/custom/identity", body);
          closeSheet(); toast(tl("depts.rn.saved"));
          // Every list reads the same record, so one reload carries the new name everywhere.
          if (typeof load === "function") { await load(); if (typeof drawChrome === "function") drawChrome(); }
          if (onScreen()) draw();
        } catch (err) { toast(err.message); }
      };
      q("#n-save").onclick = save;
      nameEl.onkeydown = (ev) => { if (ev.key === "Enter" && !ev.isComposing) save(); };
      if (matchMedia("(hover:hover)").matches) setTimeout(() => { nameEl.focus({preventScroll: true}); nameEl.select(); }, 60);
    });
  }

  async function setArchived(d, on) {
    try {
      const res = await post("/api/depts/update", {name: d.name, archived: on});
      toast(on ? tl("depts.archived") : tl("depts.unarchived"));
      await afterAct(res);
    } catch (err) { toast(err.message); }
  }

  // ---- delegated controls ----------------------------------------------------------------------
  document.addEventListener("click", async (e) => {
    if (!onScreen()) return;
    const gr = e.target.closest("[data-gren]");
    if (gr && !gr.closest("#sheet") && window.LOOP_GROUP_RENAME) return window.LOOP_GROUP_RENAME(gr.dataset.gren, () => { if (onScreen()) draw(); });
    const a = e.target.closest("[data-new],[data-open],[data-role],[data-hint]");
    if (!a || a.closest("#sheet")) return;
    if (a.hasAttribute("data-new")) return openCreate();
    const name = a.dataset.open || a.dataset.role || a.dataset.hint;
    const d = (data.depts || []).find((x) => x.name === name);
    if (a.dataset.hint) return d && hintSheet(d);
    // one way to start: the card opens the same 새 대화 sheet as everywhere else, on this project
    if (a.dataset.open) return typeof window.LOOP_NEW_CHAT === "function" ? window.LOOP_NEW_CHAT(name) : openDept(name, a, false);
    if (a.dataset.role) return roleCreate(name);
  });
  // The card's ... button: terminal, group, archive, and the destructive action behind a confirm.
  document.addEventListener("click", (e) => {
    if (!onScreen()) return;
    const b = e.target.closest("[data-dmenu]"); if (!b) return;
    const name = b.dataset.dmenu;
    if (typeof window.LOOP_MENU !== "function") return askDelete(name);
    const d = (data.depts || []).find((x) => x.name === name); if (!d) return;
    const openVia = (via) => async () => {
      try { const res = await act("/api/depts/open", {name, via}); if (res) toast(res.note || tl("depts.open.done")); }
      catch (err) { toast(err.message); } };
    const items = d.agent !== "codex" ? [{label: tl("depts.menu.app"), fn: openVia("app")}, {label: tl("depts.menu.term"), fn: openVia("terminal")}] : [];
    items.push({label: tl("depts.menu.rename"), fn: () => renameSheet(d)});
    items.push({label: tl("depts.menu.group"), fn: () => groupSheet(d)});
    items.push({label: d.archived ? tl("depts.menu.unarchive") : tl("depts.menu.archive"), fn: () => setArchived(d, !d.archived)});
    window.LOOP_MENU(b, [...items, {label: tl("depts.menu.delete"), danger: true, fn: () => askDelete(name)}], true);
  });
  function askDelete(name) {
    toastAct(tl("depts.del.q"), tl("depts.menu.delete"), async () => {
      try { await post("/api/depts/remove", {name}); await refresh(); draw(); }
      catch (err) { toast(err.message); } });
  }

  // A role chip opens its sheet: hand it a task, or take it out.
  const chipAt = (e) => { if (!onScreen()) return null; const c = e.target.closest("[data-rname]"); return c && !c.closest("#sheet") ? c : null; };
  document.addEventListener("click", (e) => { const c = chipAt(e); if (c) roleSheet(c.dataset.rdept, c.dataset.rname); });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const c = chipAt(e); if (!c) return; e.preventDefault(); roleSheet(c.dataset.rdept, c.dataset.rname);
  });

  // The same folder actions from the chat list's folder menu (project.js headMenu), so a folder
  // can be renamed, regrouped, archived or taken off the list without coming to this screen.
  window.LOOP_DEPT = async (name, what, again) => {
    await refresh();
    const d = (data.depts || []).find((x) => x.name === name); if (!d) return;
    const done = () => { if (again) again(); };
    if (what === "rename") return renameSheet(d);
    if (what === "group") return groupSheet(d);
    if (what === "roles") return rolesSheet(d);
    if (what === "archive") { await setArchived(d, !d.archived); return done(); }
    if (what === "remove") return toastAct(tl("depts.del.q"), tl("room.offList"), async () => {
      try { await post("/api/depts/remove", {name}); await refresh(); done(); }
      catch (err) { toast(err.message); } });
  };

  // Register the core screen; the toolbar + opens the create sheet (a role in 에이전트 모드).
  if (typeof SCREENS !== "undefined") {
    SCREENS.depts = function () {
      screen();
      const lab = headMode() ? tl("depts.rc.h") : tl("depts.create");
      return {right: `<button class="ib press" data-new aria-label="${esc(lab)}" title="${esc(lab)}">${ic("plus")}</button>`};
    };
  }
})();
