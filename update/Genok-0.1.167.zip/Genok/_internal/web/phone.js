// 폰으로 보기 (design v2 §8): open this PC's screen on the phone through the user's own
// Tailscale - never a public tunnel. The setup shows ONE thing to do at a time, with one button,
// and moves on by itself when the PC's real state says that step is done (web/phonestep.js).
// The same flow sits in Settings (drawn in the page) and in a full-screen panel for the first
// run (window.LOOP_PHONE.open()).
// Uses v2.js globals: tl, post, esc, ic, copyText, toast, loadingHtml, isPhoneW.

// Is the page being viewed from the phone (over serve), not on the PC itself?
const phoneRemote = () => !["127.0.0.1", "localhost", "::1", ""].includes(location.hostname);
// The device token lives in an HttpOnly cookie the PC sets when the code is accepted; the page
// never holds it (the PC says whether this phone is registered: /api/phone "paired").

const PHONE_POLL_MS = 2000;     // how often the PC's state is read again while the flow is on screen
const PHONE_CODE_MS = 240000;   // a pairing code lives 5 minutes; the QR takes a new one before that

let phoneHost = null;      // the element the flow is drawn in (the settings page or the panel)
let phonePage = null;      // the settings page's own flow element (the panel hands the flow back to it)
let phoneData = null;      // last /api/phone payload
let phonePoll = null;      // polling timer
let phoneSig = "";         // what the flow was last drawn from (skip needless redraws)
let phoneShown = "";       // the step on screen (a new step fades in; a redraw of the same one does not)
let phoneBase = null;      // registered-phone count when access came on (to spot a new one)
let phonePaired = false;   // a phone registered itself while this was open
let phoneAdding = false;   // 폰 추가 pressed on the "it is on" view
let phoneCheck = null;     // 연결 점검: {busy: true} while it runs, then {phones: [{name, state}]}
let phoneSkipApp = false;  // "이미 설치했어요": the person says the phone has Tailscale
let phoneShowApp = false;  // the install QR asked for from the scan screen
let phoneCode = null;      // {code, qr, at}: the pairing code the scan screen shows
let phoneCodeBusy = false;
let phoneWait = "";        // the step a press was made on (its line turns into "waiting")
let phoneErr = "";         // one line under the button: what went wrong and what to do
let phoneMore = false;     // 자세히 open
let phoneKeyOpen = false;  // the license key field shown instead of the trial button
let phoneKey = "";         // license key being typed (kept across redraws)
let phoneOpts = {};        // how the panel was opened: {onClose}
let phoneEsc = null;

// A phone registers under the first 40 characters of its browser string, which reads as noise cut
// mid-word ("Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_"). The list names the device instead.
const devName = (n) => !/^Mozilla[/]/.test(n || "") ? n : /iPhone/.test(n) ? "iPhone" : /iPad/.test(n) ? "iPad" : /Android/.test(n) ? "Android" : /Macintosh/.test(n) ? "Mac" : /Windows/.test(n) ? "Windows" : n;
function phoneAndroid() { try { return /Android/i.test(navigator.userAgent); } catch { return false; } }

// Phone access is a Pro feature; until the plan allows it the flow starts with the key/trial.
const phoneLocked = () => !!(window.planCan && !planCan("phone"));

// -------------------------------------------------------------- open / close API
// The first-run wizard and the settings chips both call this.
window.LOOP_PHONE = {
  // opts.onClose runs once when the panel closes; opts.pair is the phone's own "enter the code".
  open(opts) { phoneWizOpen(opts); },
  close() { phoneWizClose(); },
};

function phoneWizOpen(opts) {
  if (document.getElementById("phone-wiz")) return;
  phoneOpts = opts || {};
  // A scanned QR is registering this phone right now: no code screen over it.
  if (phonePairMode(phoneOpts)) return phoneAuto ? undefined : phonePairOpen();
  const w = document.createElement("div");
  w.id = "phone-wiz"; w.className = "pw pw-flow"; w.setAttribute("role", "dialog"); w.setAttribute("aria-modal", "true");
  w.setAttribute("aria-label", tl("phone.title"));
  w.innerHTML = `<div class="pw-panel">
      <div class="pw-top"><button class="pw-x press" data-pwclose>${tl("phone.close")}</button></div>
      <div class="pw-scroll"><div class="pw-col"><div class="pf" id="pw-flow"></div></div></div>
    </div>`;
  document.body.appendChild(w);
  document.body.classList.add("pw-open");    // so a sheet opened from here sits above the panel
  w.querySelector("[data-pwclose]").addEventListener("click", phoneWizClose);
  requestAnimationFrame(() => w.classList.add("in"));
  phoneEsc = (e) => { if (e.key === "Escape") phoneWizClose(); };
  document.addEventListener("keydown", phoneEsc);
  phoneMount(w.querySelector("#pw-flow"));
}

function phoneWizClose() {
  const w = document.getElementById("phone-wiz"); if (!w) return;
  document.body.classList.remove("pw-open");
  if (phoneEsc) { document.removeEventListener("keydown", phoneEsc); phoneEsc = null; }
  w.classList.remove("in");
  setTimeout(() => w.remove(), 240);
  const then = phoneOpts.onClose; phoneOpts = {};
  // The settings page under the panel takes the flow back, at whatever step it is now.
  if (phonePage && phonePage.isConnected) phoneMount(phonePage); else phoneUnmount();
  if (typeof then === "function") setTimeout(then, 260);
}

// Draw the flow in `box` and keep it in step with the PC until the box leaves the page.
function phoneMount(box) {
  phoneHost = box; phoneSig = ""; phoneShown = ""; phoneWait = ""; phoneErr = ""; phoneMore = false;
  phonePaired = false; phoneAdding = false; phoneShowApp = false; phoneBase = null;
  if (phoneData) phoneDraw();
  else box.innerHTML = `<div class="pf-load">${loadingHtml(tl("phone.loading"), {quiet: true})}</div>`;
  phoneTick();
  if (phonePoll) clearInterval(phonePoll);
  phonePoll = setInterval(phoneTick, PHONE_POLL_MS);
}

function phoneUnmount() {
  phoneHost = null;
  if (phonePoll) { clearInterval(phonePoll); phonePoll = null; }
}

async function phoneTick() {
  if (!phoneHost || !phoneHost.isConnected) return phoneUnmount();
  let d; try { d = await fetch("/api/phone").then((r) => r.json()); } catch { return; }
  if (!phoneHost || !phoneHost.isConnected) return phoneUnmount();
  phoneData = d;
  const n = (d.devices || []).length;
  if (d.state !== "on") { phoneBase = null; phoneCode = null; }
  else if (phoneBase === null) phoneBase = n;
  else if (n > phoneBase) { phonePaired = true; phoneBase = n; }
  else phoneBase = n;
  phoneDraw();
}

// -------------------------------------------------------------- register this phone
// A phone that is not registered yet and followed a link needs one thing: the code. The PC's
// steps and the QR (it is already on the phone) stay out; the PC keeps the full guide.
// The same goes for a computer that opened the phone address: it has nothing to set up either.
const phonePairMode = (opts) => !!(opts && opts.pair) && phoneRemote();

function phonePairOpen() {
  const inapp = pairInApp(navigator.userAgent);
  const w = document.createElement("div");
  w.id = "phone-wiz"; w.className = "pw pw-pair"; w.setAttribute("role", "dialog"); w.setAttribute("aria-modal", "true");
  w.setAttribute("aria-labelledby", "pw-pair-h");
  w.innerHTML = `<div class="pw-panel">
      <div class="pw-top">
        <span class="pw-mark">Genok</span>
        <button class="pw-x press" data-pwclose>${tl("phone.close")}</button>
      </div>
      <div class="pw-scroll"><div class="pw-col"><div class="pw-body">
        <h2 class="pw-h" id="pw-pair-h">${tl("phone.pair_t")}</h2>
        <p class="pw-d">${tl("phone.pair_phone_b")}</p>
        ${inapp ? `<div class="pw-card pw-inapp"><p>${phoneAndroid() ? tl("phone.pair_inapp_and") : tl("phone.pair_inapp_ios")}</p>
          <button class="pw-copy press" id="pw-copy">${tl("phone.pair_copy")}</button></div>` : ""}
        <div id="pw-otp"></div>
        <p class="pw-err" id="pw-pair-err" role="alert" hidden></p>
        <button class="pw-btn press" id="pw-pair" disabled>${tl("phone.pair_ok")}</button>
        <p class="pw-hint pw-where">${tl("phone.pair_where")}</p>
      </div></div></div>
    </div>`;
  document.body.appendChild(w);
  document.body.classList.add("pw-open");
  w.querySelector("[data-pwclose]").addEventListener("click", phoneWizClose);
  requestAnimationFrame(() => w.classList.add("in"));
  phoneEsc = (e) => { if (e.key === "Escape") phoneWizClose(); };
  document.addEventListener("keydown", phoneEsc);

  const box = w.querySelector(".pw-body"), pair = w.querySelector("#pw-pair"), err = w.querySelector("#pw-pair-err");
  const bad = (msg) => { err.textContent = msg; err.hidden = !msg; otp.bad(!!msg); inp.setAttribute("aria-invalid", msg ? "true" : "false"); };
  // Six boxes over one real field (web/otp.js).
  const otp = otpField({id: "pw-code-in", label: tl("phone.pair_ph"), describedby: "pw-pair-err", onChange: (v) => { bad(""); pair.disabled = v.length < 6; }});
  w.querySelector("#pw-otp").replaceWith(otp.el);
  const inp = otp.input;
  const go = async () => { const code = inp.value.trim(); if (code.length < 6 || pair.disabled) return; pair.disabled = true;
    try { const r = await post("/api/phone/pair", {code, name: navigator.userAgent.slice(0, 40)});
      // iPhone Safari: adding to the home screen comes next, and only now carries the pairing over.
      if (window.LOOP_PWA?.iosStep()) { box.innerHTML = LOOP_PWA.iosStepHtml(); box.querySelector("#pw-ios-go").onclick = phonePairLeave; return; }
      box.innerHTML = `<div class="pw-ok">${ic("check")}</div><h2 class="pw-h" id="pw-pair-h" role="status">${tl("phone.paired")}</h2><p class="pw-d">${tl("phone.pair_going")}</p>`;
      // After a beat, so the check mark is seen: on to what this phone came for.
      setTimeout(phonePairLeave, 900); }
    // A refused code is not sent twice (tries are counted on the PC): the button waits for a
    // change. A dropped connection (no status) may be tried again as it is.
    catch (e) { bad(e.message); pair.disabled = !!e.status; inp.select(); } };
  pair.addEventListener("click", go);
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); go(); } });
  // The whole address this phone came for, to paste into the phone's own browser.
  const copy = w.querySelector("#pw-copy");
  copy?.addEventListener("click", async () => {
    copy.textContent = (await copyText(location.origin + pairDest(PAIR_LANDED, location.origin))) ? tl("phone.copied") : tl("phone.pair_copy_fail"); });
}

// Registered: open what the phone came for. Only a page of this app on this origin (phonepair.js);
// anything else ends at home.
function phonePairLeave() {
  const u = new URL(pairDest(PAIR_LANDED, location.origin), location.origin);
  // The same page with another #part does not load again by itself.
  if (u.pathname + u.search === location.pathname + location.search) { if (u.hash && u.hash !== location.hash) location.hash = u.hash; location.reload(); }
  else location.replace(u.href);
}

// -------------------------------------------------------------- render
const phoneStepNow = () => phoneStep(phoneData, {locked: phoneLocked(), remote: phoneRemote(), paired: phonePaired,
  adding: phoneAdding, skipApp: phoneSkipApp, showApp: phoneShowApp});

function phoneDraw() {
  const box = phoneHost, d = phoneData; if (!box || !d) return;
  // The install QR was asked for by hand; once a phone of this account shows up it has done its job.
  if (phoneShowApp && d.phone !== "none") phoneShowApp = false;
  const step = phoneStepNow();
  const fresh = step !== phoneShown;
  if (fresh) { phoneErr = ""; phoneWait = ""; phoneMore = false; phoneCheck = null; }
  if (step === "scan" && !phoneRemote()) phoneCodeEnsure();
  phoneDevs(d);
  const plan = window.LOOP_PLAN || {}, tr = plan.trial || {};
  const sig = [step, d.state, d.install, d.has_winget, d.magicdns, d.phone, d.login, d.url, (d.devices || []).length,
    phoneWait, phoneErr, phoneMore, phoneKeyOpen, phoneCode && phoneCode.code, !!plan.pro, !!tr.active, !!tr.used].join("|");
  if (sig === phoneSig) return;
  phoneSig = sig; phoneShown = step;
  box.innerHTML = phoneView(step, d, fresh);
  phoneWire(box, d);
}

// The QR arrives as an <svg> string from the server; load it through an <img src="data:..">
// rather than injecting the markup, so script inside an SVG can never run in the page.
const phoneQr = (svg, alt) => svg
  ? `<div class="pf-qr"><img alt="${esc(alt)}" src="data:image/svg+xml,${encodeURIComponent(svg)}"></div>` : "";
// The phone address with its copy button; long tailnet names wrap instead of pushing the page wide.
const phoneAddr = (url) => url
  ? `<div class="pf-addr"><span>${esc(url.replace(/^https:\/\//, ""))}</span><button class="pf-copy press" id="pf-copy" aria-label="${tl("phone.copy")}">${ic("copy")}</button></div>` : "";
const phoneCaret = () => (window.LOOP_ICONS ? LOOP_ICONS.html("bold/caret-down") : "");

// One screen: a small count, one title, at most one dim line, one button. Everything else that
// could be said sits behind 자세히.
function phoneView(step, d, fresh) {
  const v = {n: PHONE_STEP_N[step] || 0, media: "", h: "", s: "", w: "", extra: "", btn: null, lnk: null, row: "", err: phoneErr};
  const plan = window.LOOP_PLAN || {}, tr = plan.trial || {};
  if (step === "pro") {
    v.h = tl("phone.f_pro_h");
    if (!plan.pro && !tr.active && !tr.used && !phoneKeyOpen) {
      v.s = tl("phone.f_pro_s"); v.btn = ["pf-trial", tl("phone.f_pro_go")]; v.lnk = ["pf-keyopen", tl("phone.f_pro_key")];
    } else {
      v.extra = `<input id="pf-key" class="pf-key" value="${esc(phoneKey)}" aria-label="${tl("license.key_ph")}" placeholder="${tl("license.key_ph")}" autocomplete="off" autocapitalize="off" spellcheck="false">`;
      v.btn = ["pf-keygo", tl("license.apply")];
      const beta = (plan.checkout || {}).beta;
      if (beta) v.row = `<a class="pf-lnk press" data-lic-buy="beta" href="${esc(beta)}" target="_blank" rel="noopener noreferrer">${tl("phone.pro_get")}</a>`;
    }
  } else if (step === "install") {
    v.h = tl("phone.f_install_h");
    const failed = d.install === "failed";
    if (!failed && (d.install === "running" || phoneWait === "winget")) {
      // winget is running: Windows asks for permission in its own window.
      v.w = tl("phone.f_install_run"); v.btn = ["pf-winget", tl("phone.f_install_busy"), true];
    } else if (d.has_winget && !failed) {
      v.s = tl("phone.f_install_s"); v.btn = ["pf-winget", tl("phone.f_install_go")];
    } else {
      if (failed && !v.err) v.err = tl("phone.f_install_fail");
      if (phoneWait === "install") v.w = tl("phone.f_install_dl_w"); else v.s = tl("phone.f_install_s");
      v.btn = ["pf-dl", tl("phone.f_install_dl")];
    }
  } else if (step === "login") {
    v.h = tl("phone.f_login_h");
    if (phoneWait === "login") v.w = tl("phone.f_login_w"); else v.s = tl("phone.f_login_s");
    v.btn = ["pf-login", tl("phone.f_login_go")];
  } else if (step === "start") {
    v.h = tl("phone.f_start_h"); v.btn = ["pf-login", tl("phone.f_on_go")];
  } else if (step === "https") {
    // The one thing only the person can do: a switch on the Tailscale site. Say exactly which.
    v.h = tl("phone.f_https_h");
    const line = d.magicdns === false ? tl("phone.f_https_s2") : tl("phone.f_https_s");
    if (phoneWait === "https") v.w = line; else v.s = line;
    v.btn = ["pf-admin", tl("phone.f_https_go")];
  } else if (step === "on") {
    v.h = tl("phone.f_on_h"); v.s = tl("phone.f_on_s"); v.btn = ["pw-on", tl("phone.f_on_go")];
  } else if (step === "app") {
    v.media = phoneQr(d.qr_app, tl("phone.f_app_h"));
    v.h = tl("phone.f_app_h");
    v.w = d.login ? tl("phone.f_app_s", {login: esc(d.login)}) : tl("phone.f_app_sx");
    v.lnk = ["pf-skipapp", tl("phone.f_app_skip")];
  } else if (step === "scan") {
    v.media = phoneQr((phoneCode && phoneCode.qr) || d.qr_url, tl("phone.f_scan_h"));
    v.h = tl("phone.f_scan_h");
    // Only what is still missing: a phone that is seen online needs no reminder.
    if (d.phone === "offline") v.s = tl("phone.f_scan_off");
    else if (d.phone !== "online") v.s = tl("phone.f_scan_s");
    v.extra = phoneAddr(d.url)
      + (phoneCode ? `<p class="pf-code">${tl("phone.f_scan_code", {code: esc(phoneCode.code.slice(0, 3) + " " + phoneCode.code.slice(3))})}</p>` : "");
    if (phoneAdding) v.lnk = ["pf-addback", tl("phone.f_back")];
  } else if (step === "done") {
    v.media = `<div class="pf-ok">${ic("check")}</div>`;
    v.h = tl("phone.f_done_h"); v.btn = ["pf-done", tl("phone.done")];
  } else {   // live
    v.h = tl("phone.s_on");
    v.extra = phoneAddr(d.url);
    if (!phoneRemote()) v.row = `<div class="pf-row"><button class="pf-btn2 press" id="pf-add">${tl("phone.f_add")}</button><button class="pf-btn2 press" id="pf-off">${tl("phone.turnoff")}</button></div>` + phoneCheckHtml();
  }
  const more = step === "done" || (step === "live" && phoneRemote()) ? "" : phoneMoreHtml(step, d);
  return `<div class="pf-step${fresh ? " new" : ""}" data-step="${step}">`
    + (v.n ? `<div class="pf-n">${v.n} / ${PHONE_STEP_OF}</div>` : "")
    + v.media
    + `<h3 class="pf-h">${v.h}</h3>`
    + (v.w ? `<p class="pf-s pf-w" role="status">${loadingHtml(v.w, {inline: true})}</p>` : v.s ? `<p class="pf-s">${v.s}</p>` : "")
    + v.extra
    + (v.btn ? `<button class="pf-btn press" id="${v.btn[0]}"${v.btn[2] ? " disabled" : ""}>${v.btn[1]}</button>` : "")
    + (v.err ? `<p class="pf-err" role="alert">${esc(v.err)}</p>` : "")
    + (v.lnk ? `<button class="pf-lnk press" id="${v.lnk[0]}">${v.lnk[1]}</button>` : "")
    + v.row + more + `</div>`;
}

// 연결 점검 (the PC only): Tailscale can show a phone as on while nothing reaches it, and the phone
// then says "PC에 닿지 않아요" with this PC looking fine. A real ping per phone says which it is.
function phoneCheckHtml() {
  const c = phoneCheck;
  if (c && c.busy) return `<p class="pf-s pf-w" role="status">${loadingHtml(tl("phone.chk_w"), {inline: true})}</p>`;
  const say = (p) => { const a = {name: esc(p.name)};
    return p.state === "ok" ? tl("phone.chk_ok", a) : p.state === "silent" ? tl("phone.chk_silent", a) : tl("phone.chk_off", a); };
  const lines = !c ? "" : c.phones.length
    ? c.phones.map((p) => `<p class="pf-s">${say(p)}</p>`).join("")
    : `<p class="pf-s">${tl("phone.chk_none")}</p>`;
  return `<div class="pf-chk" role="status">${lines}</div><button class="pf-lnk press" id="pf-check">${tl("phone.chk")}</button>`;
}

// 자세히: what Tailscale is, who can reach this PC, and the few side doors of the step on screen.
function phoneMoreHtml(step, d) {
  let side = "";
  if (step === "install" && d.has_winget && d.install !== "failed") side += `<button class="pf-lnk press" id="pf-dl">${tl("phone.f_install_dl")}</button>`;
  if (step === "scan" && d.phone === "none") side += `<button class="pf-lnk press" id="pf-showapp">${tl("phone.f_more_app")}</button>`;
  if (step === "scan" || step === "app") side += `<button class="pf-lnk press" id="pf-off">${tl("phone.f_more_off")}</button>`;
  return `<button class="pf-more press" id="pf-more" aria-expanded="${phoneMore}" aria-controls="pf-info">${tl("phone.f_more")}${phoneCaret()}</button>`
    + `<div class="pf-info" id="pf-info"${phoneMore ? "" : " hidden"}>
        <p>${tl("phone.f_more_1")}</p><p>${tl("phone.f_more_2")}</p><p>${tl("phone.f_more_3")}</p>
        ${step === "scan" || step === "live" ? `<p>${tl("phone.f_more_home")}</p>` : ""}
        ${side ? `<div class="pf-side">${side}</div>` : ""}</div>`;
}

// Registered phones, under the flow on the settings page. Nothing at all while there are none.
function phoneDevs(d) {
  const box = phoneHost.parentElement && phoneHost.parentElement.querySelector(".pf-devs"); if (!box) return;
  const devs = d.devices || [], sig = JSON.stringify(devs);
  if (box.dataset.sig === sig) return;
  box.dataset.sig = sig;
  box.innerHTML = devs.length ? `<div class="sec">${tl("phone.dev_t")}</div><div class="card">`
    + devs.map((v) => `<div class="row"><span class="tx"><div class="t" style="font-size:16px">${esc(devName(v.name))}</div><div class="s">${esc((v.added || "").slice(0, 10))}</div></span><button class="btn sm press" data-phone-forget="${esc(v.id)}">${tl("phone.dev_remove")}</button></div>`).join("")
    + `<div style="height:6px"></div></div>` : "";
  box.querySelectorAll("[data-phone-forget]").forEach((b) => b.onclick = async () => {
    b.disabled = true; try { await post("/api/phone/forget", {id: b.dataset.phoneForget}); toast(tl("phone.dev_removed")); } catch (e) { toast(e.message); } phoneTick(); });
}

// The scan screen's QR carries a pairing code, so the phone registers by scanning alone. A code
// lives five minutes; a new one is taken before that while the screen is up.
async function phoneCodeEnsure() {
  if (phoneCodeBusy || (phoneCode && Date.now() - phoneCode.at < PHONE_CODE_MS)) return;
  phoneCodeBusy = true;
  try { const r = await post("/api/phone/pair-code", {}); phoneCode = {code: r.code, qr: r.qr || "", at: Date.now()}; }
  catch { /* the plain QR stays; the phone then asks for a code */ }
  phoneCodeBusy = false; phoneDraw();
}

function phoneWire(box, d) {
  const on = (id, fn) => box.querySelectorAll("#" + id).forEach((b) => b.addEventListener("click", fn));
  const redraw = () => { phoneSig = ""; phoneDraw(); };
  const fail = (e) => { phoneWait = ""; phoneErr = (e && e.message) || tl("phone.f_fail"); redraw(); };
  on("pf-more", () => { phoneMore = !phoneMore; redraw(); });
  on("pf-dl", async () => { phoneErr = ""; phoneWait = "install"; redraw();
    try { await post("/api/phone/open", {url: d.win_url}); } catch (e) { fail(e); } });
  on("pf-winget", async () => { phoneErr = ""; phoneWait = "winget"; redraw();
    try { await post("/api/phone/winget", {}); phoneTick(); } catch (e) { fail(e); } });
  // 로그인 opens the sign-in page; 켜기 (Tailscale switched off) is done right here by the same call.
  on("pf-login", async (e) => { e.currentTarget.disabled = true; phoneErr = "";
    try { const r = await post("/api/phone/login", {});
      if (r.already || r.started) return phoneTick();
      if (r.opened) phoneWait = "login"; else phoneErr = tl("phone.f_login_fail");
      redraw(); } catch (er) { fail(er); } });
  on("pf-admin", async () => { phoneErr = ""; phoneWait = "https"; redraw();
    try { await post("/api/phone/open", {url: d.admin_url}); } catch (e) { fail(e); } });
  on("pw-on", phoneConfirmOn);
  on("pf-skipapp", () => { phoneSkipApp = true; phoneShowApp = false; redraw(); });
  on("pf-showapp", () => { phoneShowApp = true; redraw(); });
  on("pf-add", () => { phoneAdding = true; redraw(); });
  on("pf-addback", () => { phoneAdding = false; redraw(); });
  on("pf-check", async () => { phoneCheck = {busy: true}; redraw();
    try { phoneCheck = await post("/api/phone/check", {}); } catch (e) { phoneCheck = null; fail(e); return; }
    redraw(); });
  on("pf-off", async (e) => { e.currentTarget.disabled = true;
    try { await post("/api/phone/off", {}); toast(tl("phone.off_done")); phoneAdding = false; phoneCode = null; phoneTick(); } catch (er) { fail(er); } });
  on("pf-copy", async () => { if (await copyText(d.url)) toast(tl("phone.copied")); });
  // A phone is registered. In the panel that is the end; on the settings page it settles into "it is on".
  on("pf-done", () => { phonePaired = false; phoneAdding = false;
    if (box.closest("#phone-wiz")) phoneWizClose(); else redraw(); });
  // Pro gate: the trial or a key, then straight on to the first step.
  const unlocked = (r) => { window.LOOP_PLAN = r; phoneKey = ""; phoneKeyOpen = false; redraw(); };
  on("pf-trial", async (e) => { e.currentTarget.disabled = true;
    try { unlocked(await post("/api/license/trial", {on: true})); } catch (er) { fail(er); } });
  on("pf-keyopen", () => { phoneKeyOpen = true; redraw(); box.querySelector("#pf-key")?.focus(); });
  const key = box.querySelector("#pf-key"), keygo = box.querySelector("#pf-keygo");
  if (key && keygo) {
    const sync = () => { keygo.disabled = !key.value.trim(); };
    key.addEventListener("input", () => { phoneKey = key.value; sync(); }); sync();
    const go = async () => { const v = key.value.trim(); if (!v) return; keygo.disabled = true;
      try { unlocked(await post("/api/license", {key: v})); }
      catch { phoneErr = tl("phone.pro_bad"); redraw(); box.querySelector("#pf-key")?.select(); } };
    keygo.addEventListener("click", go);
    key.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); go(); } });
  }
}

// 켜기 runs `tailscale serve`. The step itself says what that does (내 기기에서만 열려요) and it is
// turned off again from the same place, so the button is the yes: no second sheet asking again.
async function phoneConfirmOn(e) {
  // Phone access is a Pro feature (pricing.md): a locked plan is shown the key/trial step, and
  // nothing is turned on.
  if (phoneLocked()) { phoneSig = ""; return phoneDraw(); }
  const b = e && e.currentTarget;
  if (b) b.disabled = true;
  phoneErr = "";
  try { await post("/api/phone/on", {}); phoneTick(); }
  catch (err) { phoneErr = err.message; phoneSig = ""; phoneDraw(); }
}

// -------------------------------------------------------------- settings page
// The flow itself, drawn in the page: whatever comes next is already on screen, no panel to open.
// Registered as a callable settings entry tagged page:"phone" so the settings menu lists it.
function phoneCard(box) {
  const wrap = document.createElement("div");
  wrap.innerHTML = `<h2 class="seth">${tl("phone.title")}</h2><div class="pf pf-card" id="phone-flow"></div><div class="pf-devs"></div>`;
  box.appendChild(wrap);
  const el = phonePage = wrap.querySelector("#phone-flow");
  if (document.getElementById("phone-wiz")) return;     // the panel has the flow; it hands it back on close
  // Settings redraws in place while it is open: the flow carries on where it was, without a new fade.
  if (phoneHost && phoneData && !phoneHost.isConnected) { phoneHost = el; phoneSig = ""; phoneDraw(); }
  else phoneMount(el);
}
phoneCard.page = "phone";
phoneCard.open = () => window.LOOP_PHONE.open();

// On the phone, not registered yet: a scanned QR carries the code (#pair=123456), so register with
// it at once; without one, or with one that has run out, ask for the code.
let phoneAuto = null;
if (phoneRemote()) PAIR_RESTORED.then(() => fetch("/api/phone", {cache: "no-store"}).then((r) => r.json()))
  .then((st) => {
    if (st && st.paired) return;
    const ask = () => { phoneAuto = null; try { window.LOOP_PHONE.open({pair: true}); } catch {} };
    const code = pairCodeOf(PAIR_LANDED);
    if (code) phoneAuto = post("/api/phone/pair", {code, name: navigator.userAgent.slice(0, 40)})
      .then(() => phonePairLeave(), ask);
    else setTimeout(ask, 800);
  }, () => {});

// -------------------------------------------------------------- styles
// Kept here so v2.css stays a shared file. Colours are the app's own tokens, so light and dark follow.
(function () {
  const css = `
  .pf-devs .sec { margin-top: 16px; }
  /* --- the flow: one step, centred --- */
  .pf { color: var(--t1); text-align: center; }
  .pf-card { padding: 36px 20px 16px; border-radius: var(--r-lg); background: var(--card-hi); }
  .pf-load { min-height: 180px; display: grid; place-items: center; }
  .pf-step { display: flex; flex-direction: column; align-items: center; max-width: 360px; margin: 0 auto; }
  /* A new step fades in where the last one was; nothing slides. */
  .pf-step.new { animation: pf-in .22s ease both; }
  @keyframes pf-in { from { opacity: 0; } to { opacity: 1; } }
  .pf-n { margin: 0 0 8px; font-size: 12px; font-weight: 600; letter-spacing: .06em; color: var(--t3); font-variant-numeric: tabular-nums; }
  .pf-h { margin: 0; font-size: 20px; font-weight: 600; line-height: 1.3; letter-spacing: -.015em; word-break: keep-all; }
  .pf-s { margin: 6px 0 0; font-size: 14px; line-height: 1.5; color: var(--t3); word-break: keep-all; overflow-wrap: anywhere; }
  .pf-w .ld { display: inline-flex; align-items: center; gap: 8px; text-align: left; }
  .pf-btn { margin: 24px 0 0; min-width: 200px; max-width: 100%; height: 44px; padding: 0 24px; border: 0; border-radius: var(--r-md); cursor: pointer;
    font: inherit; font-size: 15px; font-weight: 600; background: var(--t1); color: var(--bg); }
  .pf-btn:hover { filter: brightness(1.06); }
  .pf-btn:disabled { opacity: .5; cursor: default; filter: none; }
  .pf-btn:focus-visible, .pf-btn2:focus-visible, .pf-lnk:focus-visible, .pf-more:focus-visible, .pf-copy:focus-visible, .pw-x:focus-visible {
    outline: 2px solid var(--blue-t); outline-offset: 2px; }
  .pf-row { display: flex; gap: 8px; margin: 20px 0 0; }
  .pf-chk { margin: 16px 0 0; text-wrap: pretty; }
  .pf-chk:empty { display: none; }
  .pf-btn2 { height: 38px; padding: 0 16px; border: 0; border-radius: var(--r-sm); cursor: pointer; font: inherit; font-size: 14px; font-weight: 600;
    background: var(--btn); color: var(--t1); }
  .pf-btn2:hover { background: var(--btn-hi); }
  .pf-err { margin: 12px 0 0; font-size: 13px; line-height: 1.5; word-break: keep-all; color: color-mix(in srgb, var(--red) 78%, var(--t1)); }
  .pf-lnk { display: inline-flex; align-items: center; min-height: 36px; margin: 8px 0 0; padding: 0 8px; border: 0; background: none; cursor: pointer;
    font: inherit; font-size: 14px; color: var(--t2); text-decoration: underline; text-underline-offset: 3px; text-decoration-color: var(--t4); }
  .pf-lnk:hover { color: var(--t1); }
  .pf-qr { width: 184px; padding: 12px; margin: 0 0 20px; border-radius: 12px; background: #fff; }
  .pf-qr img { display: block; width: 100%; height: auto; }
  .pf-ok { width: 56px; height: 56px; margin: 0 0 16px; border-radius: 50%; display: grid; place-items: center;
    background: color-mix(in srgb, var(--green) 16%, transparent); color: var(--green); }
  .pf-ok svg { width: 28px; height: 28px; }
  .pf-addr { display: flex; align-items: center; gap: 4px; max-width: 100%; margin: 16px 0 0; padding: 2px 2px 2px 12px; border-radius: var(--r-sm);
    background: var(--btn); font-size: 13px; color: var(--t2); }
  .pf-addr span { min-width: 0; overflow-wrap: anywhere; text-align: left; user-select: all; }
  .pf-copy { flex: none; width: 36px; height: 36px; display: grid; place-items: center; border: 0; border-radius: var(--r-xs); background: none; color: var(--t2); cursor: pointer; }
  .pf-copy:hover { background: var(--btn-hi); color: var(--t1); }
  .pf-copy svg { width: 16px; height: 16px; }
  .pf-code { margin: 8px 0 0; font-size: 13px; color: var(--t3); font-variant-numeric: tabular-nums; }
  .pf-key { width: 100%; height: 44px; margin: 16px 0 0; padding: 0 12px; border-radius: var(--r-md); border: 1px solid var(--line);
    background: var(--bg); color: var(--t1); font: inherit; font-size: 16px; text-align: center; }
  .pf-key:focus { outline: 0; border-color: var(--focus-line); box-shadow: 0 0 0 3px var(--focus-glow); }
  .pf-key + .pf-btn { margin-top: 12px; }
  .pf-more { display: inline-flex; align-items: center; gap: 4px; min-height: 36px; margin: 16px 0 0; padding: 0 8px; border: 0; background: none; cursor: pointer;
    font: inherit; font-size: 13px; color: var(--t3); }
  .pf-more:hover { color: var(--t1); }
  .pf-more .phi { width: 11px; height: 11px; fill: currentColor; transition: transform .2s var(--ease); }
  .pf-more[aria-expanded="true"] .phi { transform: rotate(180deg); }
  .pf-info { width: 100%; margin: 4px 0 8px; padding: 12px 16px; border-radius: var(--r-md); background: var(--btn); text-align: left; animation: pf-in .2s ease both; }
  .pf-info p { margin: 0; font-size: 13px; line-height: 1.6; color: var(--t2); word-break: keep-all; }
  .pf-info p + p { margin-top: 6px; }
  .pf-side { display: flex; flex-wrap: wrap; gap: 0 8px; margin: 6px -8px -4px; }
  .pf-side .pf-lnk { margin: 0; font-size: 13px; }
  @media (prefers-reduced-motion: reduce) { .pf-more .phi { transition: none; } }
  @media (max-width: 720px) {
    .pf-card { padding: 28px 16px 12px; }
    .pf-btn { width: 100%; height: 48px; }
    .pf-lnk, .pf-more { min-height: 44px; }
    .pf-btn2 { height: 44px; }
    .pf-copy { width: 44px; height: 44px; }
  }
  /* --- the full-screen panel: the first run, and the phone's own "register this phone" --- */
  .pw { position: fixed; inset: 0; z-index: 90; opacity: 0; transition: opacity .24s ease;
    --fg: var(--t1); --dim: var(--t3); --card2: var(--card-hi); color: var(--t1); }
  .pw.in { opacity: 1; }
  /* A shared .sheet (z-index 40) opened while this panel (90) is up must sit above it, or the
     click looks dead. Same fix the onboarding scrim uses. */
  body.pw-open .sheet { z-index: 9500; }
  .pw-panel { position: absolute; inset: 0; display: flex; flex-direction: column; background: var(--bg); }
  .pw-top { display: flex; align-items: center; gap: 12px; padding: 16px 16px; }
  .pw-mark { font-family: Georgia, "Times New Roman", serif; font-size: 16px; letter-spacing: -.01em; }
  /* One close control, as a word: an X here sat right under the window X of the desktop app. */
  .pw-x { margin-left: auto; background: none; border: 1px solid var(--line); color: var(--t2); cursor: pointer;
    font: inherit; font-size: 13px; padding: 4px 12px; border-radius: 8px; }
  /* Frameless Windows app: keep the row clear of the window buttons in the top-right corner. */
  .os-win body.inapp .pw-top { padding-right: 150px; }
  .pw-scroll { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; }
  .pw-col { max-width: 560px; margin: 0 auto; padding: 8px 16px 40px; box-sizing: border-box; }
  /* The flow in the panel: the step sits in the middle of the window, a size up. */
  .pw-flow .pw-scroll { display: grid; align-items: center; }
  .pw-flow .pw-col { width: 100%; padding: 8px 20px 72px; }
  .pw-flow .pf-h { font-size: 26px; font-weight: 500; }
  .pw-flow .pf-s { font-size: 15px; }
  .pw-flow .pf-btn { height: 48px; min-width: 220px; }
  .pw-h { font-size: 28px; font-weight: 400; letter-spacing: -.01em; margin: 0 0 8px; }
  .pw-d { color: var(--t3); font-size: 15px; line-height: 1.5; margin: 0 0 16px; white-space: normal; }
  .pw-btn { display: block; width: 100%; box-sizing: border-box; margin: 8px 0; padding: 12px 16px; border: 0; border-radius: 8px; cursor: pointer;
    font-size: 15px; font-weight: 600; background: var(--t1); color: var(--bg); }
  .pw-btn:disabled { opacity: .55; cursor: default; }
  .pw-card { border: 1px solid var(--line); border-radius: 8px; padding: 12px 16px; margin: 4px 0 12px;
    font-size: 14px; color: var(--t1); background: var(--card-hi); }
  .pw-hint { color: var(--t3); font-size: 14px; margin: 6px 2px; white-space: normal; }
  .pw-ok { width: 56px; height: 56px; border-radius: 50%; margin: 8px 0 16px; display: flex; align-items: center; justify-content: center;
    background: color-mix(in srgb, var(--green) 16%, transparent); color: var(--green); }
  .pw-ok svg { width: 30px; height: 30px; }
  /* --- "register this phone": the code first, nothing of the PC's setup --- */
  .pw-pair .pw-top { flex-wrap: nowrap; justify-content: space-between;
    padding: calc(10px + env(safe-area-inset-top)) max(20px, env(safe-area-inset-right)) 6px max(20px, env(safe-area-inset-left)); }
  .pw-pair .pw-mark { line-height: 44px; }
  .pw-pair .pw-x { min-height: 44px; padding: 0 16px; font-size: 15px; border-radius: 8px; color: var(--t1); }
  .pw-pair .pw-col { padding: 20px max(20px, env(safe-area-inset-right)) calc(32px + env(safe-area-inset-bottom)) max(20px, env(safe-area-inset-left)); }
  .pw-pair .pw-h { font-size: 28px; line-height: 1.25; margin: 0 0 8px -1px; word-break: keep-all; }
  .pw-pair .pw-d { font-size: 16px; margin: 0 0 24px; color: var(--t2); word-break: keep-all; }
  .pw-pair .pw-err { margin: 8px 0 0; color: color-mix(in srgb, var(--red) 80%, var(--t1)); font-size: 14px; line-height: 1.45; white-space: normal; word-break: keep-all; }
  .pw-pair .pw-btn { min-height: 52px; margin: 16px 0 0; border-radius: 12px; font-size: 16px; background: var(--t1); color: var(--bg); }
  .pw-pair .pw-btn:disabled { opacity: 1; background: var(--btn-hi); color: var(--t2); box-shadow: inset 0 0 0 1px var(--line); }
  .pw-pair .pw-where { margin: 16px 0 0; font-size: 14px; line-height: 1.55; color: var(--t2); word-break: keep-all; }
  .pw-pair .pw-inapp { margin: 0 0 24px; padding: 16px; border-radius: 12px; border-color: color-mix(in srgb, var(--orange) 45%, transparent);
    background: color-mix(in srgb, var(--orange) 9%, var(--card)); }
  .pw-pair .pw-inapp p { margin: 0 0 12px; font-size: 14px; line-height: 1.55; color: var(--t1); white-space: normal; word-break: keep-all; }
  .pw-pair .pw-copy { display: block; width: 100%; min-height: 44px; padding: 0 16px; border-radius: 8px; cursor: pointer;
    font: inherit; font-size: 15px; font-weight: 600; color: var(--t1); background: var(--btn); border: 1px solid var(--line); }
  .pw-pair .pw-ok { margin: 24px 0 16px; }`;
  const s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);
})();

(window.LOOP_SETTINGS = window.LOOP_SETTINGS || []).push(phoneCard);
