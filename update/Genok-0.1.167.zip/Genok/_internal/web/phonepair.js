// Small rules behind the "register this phone" screen (phone.js): where to go once the phone is
// registered, and whether the page sits inside another app's browser. Kept apart so they can be
// tested without a page. Run: node --test tests/phonepair.test.js

// The address the page was opened at. Read here, before v2.js loads: v2.js takes the ?query off
// the address (the version a pushed link asked for rides in it), and a reload would lose it.
const PAIR_LANDED = typeof location === "undefined" ? "/" : location.pathname + location.search + location.hash;

// The code a scanned QR carries: the PC shows the phone address with "#pair=123456" on it, so a
// phone that scans it registers without typing. "" when the address has none.
function pairCodeOf(landed) {
  const m = /#pair=(\d{6})$/.exec(String(landed || ""));
  return m ? m[1] : "";
}
// The code is taken off the address at once (it is kept in PAIR_LANDED): it must not stay in the
// address bar or the history, and v2.js reads the #part as a page.
if (typeof location !== "undefined" && pairCodeOf(PAIR_LANDED)) {
  try { history.replaceState(null, "", location.pathname + location.search); } catch { /* stays */ }
}

// A phone paired by an older build holds its token where page scripts can read it (a plain cookie,
// and a copy in storage). Hand it to the PC once: the PC answers with an HttpOnly cookie, and the
// readable copies go. Resolves when that is done (phone.js waits before it asks "registered?").
const PAIR_RESTORED = (async () => {
  if (typeof location === "undefined" || ["127.0.0.1", "localhost", "::1", ""].includes(location.hostname)) return;
  try {
    const old = (document.cookie.split(";").map((c) => c.trim()).find((c) => c.startsWith("loop_device=")) || "").slice(12);
    const t = old || localStorage.getItem("loop_device") || "";
    if (!/^[\w-]+$/.test(t)) return;
    const r = await fetch("/api/phone/restore", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({token: t})});
    if (r.ok || r.status === 400) localStorage.removeItem("loop_device");   // 400: the PC forgot this phone; the copy is dead
  } catch { /* offline or no storage: the next load tries again */ }
})();

// Pages of this app a registration may hand over to: home, a result link, the old page links.
const PAIR_PAGE = /^\/(?:$|(?:i|p|s)(?:\/|$))/;

// `raw` as a path on this origin, or "/" (home). Never another site: a scheme, "//host", a
// backslash (browsers read it as a slash) or a control character all end at home, and so does a
// path that only turns into "//host" once it is normalised ("/.//host").
function pairSafeNext(raw, origin) {
  if (typeof raw !== "string" || !raw || raw.length > 2048) return "/";
  if (raw[0] !== "/" || raw[1] === "/" || /[\\\u0000-\u001f\u007f]/.test(raw)) return "/";
  let u; try { u = new URL(raw, origin); } catch { return "/"; }
  if (u.origin !== origin || u.pathname[1] === "/" || !PAIR_PAGE.test(u.pathname)) return "/";
  return u.pathname + u.search + u.hash;
}

// Where to go after registering: ?next=<path> when the address carries one, else the address
// the phone was opened at. Both pass through pairSafeNext.
function pairDest(landed, origin) {
  let u; try { u = new URL(String(landed || "/"), origin); } catch { return "/"; }
  if (u.origin !== origin) return "/";
  if (pairCodeOf(u.hash)) u.hash = "";          // the code is not a place to go to
  const next = u.searchParams.get("next");
  return pairSafeNext(next != null ? next : u.pathname + u.search + u.hash, origin);
}

// Opened inside another app (KakaoTalk, Instagram, Facebook, LINE, Naver, Daum, an Android
// WebView)? Such a browser keeps its own cookies, so a registration made there stays there.
function pairInApp(ua) {
  return /KAKAOTALK|Instagram|FBAN|FBAV|FB_IAB|\bLine\/|NAVER\(inapp|DaumApps|; wv\)/.test(String(ua || ""));
}

if (typeof module !== "undefined") module.exports = {PAIR_PAGE, pairSafeNext, pairDest, pairInApp, pairCodeOf};
