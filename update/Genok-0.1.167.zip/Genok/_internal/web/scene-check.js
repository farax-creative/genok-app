// 씬 확인 (scene_check.py, beta "scene"): under the title, the scene this version came from and,
// when one was saved after it, that scene's name. Asked each time the item or version changes,
// because the scene is what moves on after a result goes up.
//
// Classic script: it shares v2.js's globals (tl, esc, get) and attaches through window.LOOP_ITEM_VIEW.
(function () {
  "use strict";
  if (!window.genokBeta?.("scene")) return;

  const got = {};                              // "p/i@v" -> what /api/scene said
  let shown = null;                            // the key on screen, so a late answer is dropped

  const when = (at) => {
    const d = new Date(at * 1000), two = (n) => String(n).padStart(2, "0");
    return `${d.getMonth() + 1}/${d.getDate()} ${two(d.getHours())}:${two(d.getMinutes())}`;
  };
  // A long scene name wraps at its own separators, so "CAM28" never splits in the middle.
  const seams = (name) => name.split(/(?<=[_.-])/).map(esc).join("<wbr>");
  const row = (cls, label, name, at) =>
    `<div class="${cls}"><span>${esc(label)}</span><b title="${esc(name)}">${seams(name)}</b><time class="num">${when(at)}</time></div>`;

  function markup(s) {
    if (!s?.scene && !s?.newer) return "";
    return `<section class="scck" aria-label="${esc(tl("scene.title"))}">`
      + (s.scene ? row("scr", tl("scene.used"), s.scene, s.at) : "")
      + (s.newer ? row("scr late", tl("scene.newer"), s.newer, s.newer_at) : "")
      + `</section>`;
  }

  function paint(box, key) {
    const where = box.querySelector(".detailcols.item .iside > .htitle");
    if (!where) return;
    const html = markup(got[key]), old = box.querySelector(".scck");
    if ((old?.outerHTML || "") === html) return;
    old?.remove();
    if (html) where.insertAdjacentHTML("afterend", html);
  }

  function attach(box, it) {
    const key = `${it.p}/${it.i}@${it.v}`, moved = shown !== key;
    shown = key;
    paint(box, key);
    if (!moved) return;
    get(`/api/scene?p=${encodeURIComponent(it.p)}&i=${encodeURIComponent(it.i)}&v=${encodeURIComponent(it.v)}`).then((s) => {
      if (!s?.on) return;
      got[key] = s;
      if (shown === key && box.isConnected) paint(box, key);
    }).catch(() => {});
  }

  (window.LOOP_ITEM_VIEW = window.LOOP_ITEM_VIEW || []).push(attach);
})();
